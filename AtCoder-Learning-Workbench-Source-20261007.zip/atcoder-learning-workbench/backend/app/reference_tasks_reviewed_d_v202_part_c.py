"""Private ABC437..442 D; exact output, primary constraints, independent oracles."""
from __future__ import annotations
from typing import cast
from bisect import bisect_left,bisect_right
from collections import Counter
from functools import lru_cache
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(437,443));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...];MOD=998244353

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',s) is not None,'integers');values=tuple(map(int,s.split()));require(n is None or len(values)==n,'fields');return values
def line(a:tuple[int,...]|list[int])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc437_d':
  n,m=ints(rows[0],2);require(1<=n<=300000 and 1<=m<=300000 and len(rows)==3,'shape');a=ints(rows[1],n);b=ints(rows[2],m);require(all(1<=v<MOD for v in a+b),'values');return a,b
 if pid=='abc438_d':
  n=ints(rows[0],1)[0];require(3<=n<=300000 and len(rows)==4,'shape');a,b,c=(ints(row,n) for row in rows[1:]);require(all(1<=v<=10**6 for v in a+b+c),'values');return a,b,c
 if pid=='abc439_d':
  n=ints(rows[0],1)[0];require(1<=n<=300000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'values');return (a,)
 if pid=='abc440_d':
  n,q=ints(rows[0],2);require(1<=n<=300000 and 1<=q<=300000 and len(rows)==q+2,'shape');a=ints(rows[1],n);require(len(set(a))==n and all(1<=v<=10**9 for v in a),'distinct');queries=tuple(ints(row,2) for row in rows[2:]);require(all(1<=x<=10**9 and 1<=y<=10**9 for x,y in queries),'queries');return a,queries
 if pid=='abc441_d':
  n,m,l,s,t=ints(rows[0],5);require(1<=n<=200000 and 1<=m<=200000 and 1<=l<=10 and 1<=s<=t<=10**9 and len(rows)==m+1,'shape');edges=tuple(ints(row,3) for row in rows[1:]);require(all(1<=u<=n and 1<=v<=n and 1<=c<=10**8 for u,v,c in edges),'edges');require(all(v<=4 for v in Counter(u for u,_,_ in edges).values()),'outdegree');return n,l,s,t,edges
 n,q=ints(rows[0],2);require(2<=n<=200000 and 1<=q<=500000 and len(rows)==q+2,'shape');a=ints(rows[1],n);require(all(1<=v<=10000 for v in a),'values');queries=[]
 for row in rows[2:]:
  query=ints(row)
  require((len(query)==2 and query[0]==1 and 1<=query[1]<n) or (len(query)==3 and query[0]==2 and 1<=query[1]<=query[2]<=n),'query kind/range');queries.append(query)
 return a,tuple(queries)

def difference_tagged_sweep(a:tuple[int,...],b:tuple[int,...])->int:
 merged=sorted([(v,0) for v in a]+[(v,1) for v in b]);counts=[0,0];sums=[0,0];answer=0
 for v,side in merged:
  opposite=side^1;answer+=v*counts[opposite]-sums[opposite];counts[side]+=1;sums[side]+=v
 return answer%MOD

def snake_prefix_extrema(a:tuple[int,...],b:tuple[int,...],c:tuple[int,...])->int:
 n=len(a);prefix_a=[0];prefix_b=[0]
 for x,y in zip(a,b):prefix_a.append(prefix_a[-1]+x);prefix_b.append(prefix_b[-1]+y)
 suffix_c=[0]*(n+1)
 for i in range(n-1,-1,-1):suffix_c[i]=suffix_c[i+1]+c[i]
 best=-(10**30);answer=best
 for y in range(2,n):best=max(best,prefix_a[y-1]-prefix_b[y-1]);answer=max(answer,best+prefix_b[y]+suffix_c[y])
 return answer

def kadomatsu_position_lists(a:tuple[int,...])->int:
 positions:dict[int,list[int]]={}
 for i,v in enumerate(a):positions.setdefault(v,[]).append(i)
 answer=0
 for value,jlist in positions.items():
  if value%5:continue
  unit=value//5;high=positions.get(unit*7,[]);low=positions.get(unit*3,[])
  for j in jlist:
   before_high=bisect_left(high,j);before_low=bisect_left(low,j);answer+=before_high*before_low+(len(high)-before_high)*(len(low)-before_low)
 return answer

def forbidden_global_missing_rank(a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 ordered=sorted(a);adjusted=[v-i-1 for i,v in enumerate(ordered)];out=[]
 for x,y in queries:
  rank=x-1-bisect_left(ordered,x)+y;out.append(rank+bisect_left(adjusted,rank))
 return out

def paid_walk_join(n:int,l:int,s:int,t:int,edges:tuple[tuple[int,...],...])->list[int]:
 adj:list[list[tuple[int,int]]]=[[] for _ in range(n)]
 for u,v,c in edges:adj[u-1].append((v-1,c))
 half=l//2;prefix=[(0,0)]
 for _ in range(half):prefix=[(v,total+c) for u,total in prefix for v,c in adj[u] if total+c<=t]
 @lru_cache(None)
 def suffix(u:int)->dict[int,list[int]]:
  states=[(u,0)]
  for _ in range(l-half):states=[(v,total+c) for node,total in states for v,c in adj[node] if total+c<=t]
  groups:dict[int,list[int]]={}
  for node,total in states:groups.setdefault(node,[]).append(total)
  for costs in groups.values():costs.sort()
  return groups
 result=set()
 for u,total in prefix:
  for v,costs in suffix(u).items():
   i=bisect_left(costs,s-total)
   if i<len(costs) and costs[i]<=t-total:result.add(v+1)
 return sorted(result)

def swaps_local_prefix(a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 values=list(a);prefix=[0]
 for v in values:prefix.append(prefix[-1]+v)
 out=[]
 for query in queries:
  if query[0]==1:
   x=query[1]-1;prefix[x+1]+=values[x+1]-values[x];values[x],values[x+1]=values[x+1],values[x]
  else:out.append(prefix[query[2]]-prefix[query[1]-1])
 return out

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc437_d':return str(difference_tagged_sweep(*cast(tuple[tuple[int,...],tuple[int,...]],d)))+'\n'
 if pid=='abc438_d':return str(snake_prefix_extrema(*cast(tuple[tuple[int,...],tuple[int,...],tuple[int,...]],d)))+'\n'
 if pid=='abc439_d':return str(kadomatsu_position_lists(cast(tuple[int,...],d[0])))+'\n'
 if pid=='abc440_d':return ''.join(str(v)+'\n' for v in forbidden_global_missing_rank(*cast(tuple[tuple[int,...],tuple[tuple[int,...],...]],d)))
 if pid=='abc441_d':return line(paid_walk_join(*cast(tuple[int,int,int,int,tuple[tuple[int,...],...]],d)))
 return ''.join(str(v)+'\n' for v in swaps_local_prefix(*cast(tuple[tuple[int,...],tuple[tuple[int,...],...]],d)))
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:
  if mode not in (None,'exact'):return False
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc437_d':'''import sys,bisect
r=sys.stdin.buffer;n,m=map(int,r.readline().split());a=list(map(int,r.readline().split()));b=sorted(map(int,r.readline().split()));p=[0]
for v in b:p.append(p[-1]+v)
answer=0
for v in a:
 i=bisect.bisect_left(b,v);answer+=v*i-p[i]+p[-1]-p[i]-v*(m-i)
print(answer%998244353)
''',
'abc438_d':'''import sys
r=sys.stdin.buffer;n=int(r.readline());a=list(map(int,r.readline().split()));b=list(map(int,r.readline().split()));c=list(map(int,r.readline().split()));head=a[0];middle=tail=-10**30
for i in range(1,n):tail=max(middle,tail)+c[i];middle=max(head,middle)+b[i];head+=a[i]
print(tail)
''',
'abc439_d':'''import sys
from collections import Counter
n,*a=map(int,sys.stdin.buffer.read().split());left=Counter();right=Counter(a);answer=0
for v in a:
 right[v]-=1
 if v%5==0:
  t=v//5;answer+=left[7*t]*left[3*t]+right[7*t]*right[3*t]
 left[v]+=1
print(answer)
''',
'abc440_d':'''import sys,bisect
r=sys.stdin.buffer;n,q=map(int,r.readline().split());a=sorted(map(int,r.readline().split()));out=[]
for _ in range(q):
 x,y=map(int,r.readline().split());before=bisect.bisect_left(a,x);low=x;high=x+y+n
 while low<high:
  mid=(low+high)//2;available=mid-x+1-(bisect.bisect_right(a,mid)-before)
  if available>=y:high=mid
  else:low=mid+1
 out.append(str(low))
print('\\n'.join(out))
''',
'abc441_d':'''import sys
r=sys.stdin.buffer;n,m,l,s,t=map(int,r.readline().split());adj=[[] for _ in range(n)]
for _ in range(m):u,v,c=map(int,r.readline().split());adj[u-1].append((v-1,c))
stack=[(0,0,0)];answer=set()
while stack:
 u,steps,cost=stack.pop()
 if steps==l:
  if s<=cost<=t:answer.add(u+1)
  continue
 for v,c in adj[u]:
  if cost+c<=t:stack.append((v,steps+1,cost+c))
print(*sorted(answer))
''',
'abc442_d':'''import sys
r=sys.stdin.buffer;n,q=map(int,r.readline().split());a=list(map(int,r.readline().split()));bit=[0]+a[:]
for i in range(1,n+1):
 j=i+(i&-i)
 if j<=n:bit[j]+=bit[i]
def add(i,v):
 while i<=n:bit[i]+=v;i+=i&-i
def prefix(i):
 total=0
 while i:total+=bit[i];i-=i&-i
 return total
out=[]
for _ in range(q):
 query=list(map(int,r.readline().split()))
 if query[0]==1:
  x=query[1];delta=a[x]-a[x-1];add(x,delta);add(x+1,-delta);a[x-1],a[x]=a[x],a[x-1]
 else:out.append(str(prefix(query[2])-prefix(query[1]-1)))
sys.stdout.write('\\n'.join(out)+('\\n' if out else ''))
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc437_d':
  def pack(a:list[int],b:list[int])->str:return f'{len(a)} {len(b)}\n'+line(a)+line(b)
  raws=[pack([1],[1]),pack([1],[MOD-1]),pack([MOD-1],[1]),pack([1,1],[1,1]),pack([2,1,3],[3,1,2])]
  while len(raws)<16:raws.append(pack([rng.randint(1,MOD-1) for _ in range(len(raws)+1)],[rng.randint(1,MOD-1) for _ in range(2*len(raws))]))
  raws+=[pack(list(range(1,300001)),list(range(300000,0,-1))),pack([MOD-1]*300000,[1]*300000)]
 elif pid=='abc438_d':
  def pack(a:list[int],b:list[int],c:list[int])->str:return str(len(a))+'\n'+line(a)+line(b)+line(c)
  raws=[pack([1]*3,[1]*3,[1]*3),pack([10**6]*3,[1]*3,[1]*3),pack([1]*3,[10**6]*3,[1]*3),pack([1]*3,[1]*3,[10**6]*3),pack([1,10,1,1],[1,1,10,1],[1,1,1,10])]
  while len(raws)<16:
   n=len(raws)+3;raws.append(pack(*[[rng.randint(1,10**6) for _ in range(n)] for _ in range(3)]))
  raws+=[pack([10**6 if i%3==0 else 1 for i in range(300000)],[10**6 if i%3==1 else 1 for i in range(300000)],[10**6 if i%3==2 else 1 for i in range(300000)]),pack([10**6]*300000,[10**6]*300000,[10**6]*300000)]
 elif pid=='abc439_d':
  def pack(a:list[int])->str:return str(len(a))+'\n'+line(a)
  raws=[pack([1]),pack([10**9]),pack([7,5,3]),pack([5,7,3]),pack([7,3,5]),pack([5,7,3,5]),pack([14,10,6]),pack([7,7,5,3,3])]
  while len(raws)<16:raws.append(pack([rng.choice([3,5,7,6,10,14,1,999999999]) for _ in range(2*len(raws))]))
  raws+=[pack([5]*100000+[7]*100000+[3]*100000),pack([5]*100000+[7]*100000+[3]*99999+[10**9])]
 elif pid=='abc440_d':
  def pack(a:list[int],queries:list[tuple[int,int]])->str:return f'{len(a)} {len(queries)}\n'+line(a)+''.join(line(q) for q in queries)
  raws=[pack([1],[(1,1)]),pack([2],[(1,1)]),pack([1],[(2,1)]),pack([1,2,3],[(1,1),(2,1),(4,1)]),pack([3,1,7],[(1,3),(2,3),(8,2)])]
  while len(raws)<16:
   a=rng.sample(range(1,100),len(raws)+1);queries=[(rng.randint(1,100),rng.randint(1,100)) for _ in range(len(raws)+3)];raws.append(pack(a,queries))
  raws+=[pack(list(range(1,300001)),[(i+1,300000-i) for i in range(300000)]),pack(list(range(10**9-299999,10**9+1)),[(10**9,10**9)]*300000)]
 elif pid=='abc441_d':
  def pack(n:int,l:int,s:int,t:int,e:list[tuple[int,int,int]])->str:return f'{n} {len(e)} {l} {s} {t}\n'+''.join(line(v) for v in e)
  raws=[pack(1,1,1,1,[(1,1,1)]),pack(1,1,1,1,[(1,1,2)]),pack(1,10,10,10,[(1,1,1)]),pack(2,2,2,2,[(1,2,1)]),pack(2,3,3,3,[(1,2,1),(2,1,1)]),pack(2,1,1,10,[(1,2,1),(1,2,5)])]
  while len(raws)<16:
   n=len(raws);e=[(u,rng.randint(1,n),rng.randint(1,10)) for u in range(1,n+1) for _ in range(rng.randint(1,4))];raws.append(pack(n,1+len(raws)%10,1,100,e))
  edges=[(p,4*p-2+j,10**8) for p in range(1,5462) for j in range(4)];edges += [(p,21846+j,10**8) for p in range(5462,21846) for j in range(4)];edges += [(p,21850+j,10**8) for p in range(21846,21850) for j in range(4)];edges += [(p,200000,10**8) for p in range(21850,21854) for _ in range(4)]
  edges += [(p,p,10**8) for p in range(21854,21854+200000-len(edges))]
  raws+=[pack(200000,10,10**9,10**9,[(i,i+1,10**8) for i in range(1,200000)]+[(200000,200000,10**8)]),pack(200000,10,1,10**9,edges)]
 else:
  def pack(a:list[int],queries:list[tuple[int,...]])->str:return f'{len(a)} {len(queries)}\n'+line(a)+''.join(line(q) for q in queries)
  raws=[pack([1,1],[(1,1)]),pack([1,1],[(2,1,2)]),pack([1,10000],[(1,1),(2,1,1),(2,2,2),(2,1,2)]),pack([1,2,3],[(1,1),(1,2),(2,1,3)]),pack([10000]*2,[(2,1,2)])]
  while len(raws)<16:
   n=len(raws)+2;a=[rng.randint(1,10000) for _ in range(n)];queries=[]
   for _ in range(len(raws)+5):
    if rng.randrange(2):queries.append((1,rng.randint(1,n-1)))
    else:l,r=sorted((rng.randint(1,n),rng.randint(1,n)));queries.append((2,l,r))
   raws.append(pack(a,queries))
  raws+=[pack(list(range(1,10001))*20,[(1,i%199999+1) for i in range(500000)]),pack([10000]*200000,[(2,1,200000)]*500000)]
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i==16 else 'random'} for i,raw in enumerate(raws)]
HINTS={
'abc437_d':('片方を並べ替えると、各Aより小さいBと大きいBを分けられます。','Bの累積和を用意し、二分探索でA未満の要素数を求めます。両側の差の総和を定数時間で計算できます。','疑似コード: Bをsort、prefix和P。各aでi=lower_bound(B,a)。answer+=a*i-P[i]+P[M]-P[i]-a*(M-i)。answer mod998244353を出力。'),
'abc438_d':('頭・胴・尾の各部分は空にできません。','左から進み、いま頭/胴/尾のどの段階かを持つDPで最大得点を記録します。','疑似コード: head=A[0],mid=tail=-INF。i=1..N-1でnewTail=max(mid,tail)+C[i],newMid=max(head,mid)+B[i],newHead=head+A[i]を同時更新。tailを出力。'),
'abc439_d':('jの値が5tなら、残り二つの値は7tと3tです。','jが最初または最後になるので、両方が左にある組と両方が右にある組を数えます。左右の頻度を更新しながら走査します。','疑似コード: right=全頻度,left=空。各vでright[v]--。v%5==0ならt=v/5、answer+=left[7t]*left[3t]+right[7t]*right[3t]。left[v]++。answer出力。'),
'abc440_d':('Xから候補vまでに存在する、禁止されていない整数の個数を数えます。','禁止リストをsortすると、区間[X,v]にある禁止数を二分探索で求められます。この個数がY以上となる最小vを探します。','疑似コード: before=lower_bound(A,X)。low=X,high=X+Y+N。midでcount=mid-X+1-(upper_bound(A,mid)-before)。count>=Yならhigh=mid、他はlow=mid+1。lowを出力。'),
'abc441_d':('出次数が4以下、移動回数が10以下なので、全ての経路候補を調べられます。','深さLまでDFSし、合計コストが[S,T]に入る終点を集合へ追加します。コストがTを超えた枝は打ち切れます。','疑似コード: stack=[(頂点1,回数0,コスト0)]。回数Lなら範囲内終点を追加。他は各辺でcost+C<=Tの次状態をpush。終点集合をsortし空白区切りで出力、空なら空行。'),
'abc442_d':('隣接交換による各位置の変化量を、区間和を求めるデータ構造へ反映します。','Fenwick木で位置xに差delta、x+1に-deltaを加えます。区間和は二つのprefix和の差です。','疑似コード: FenwickにAを構築。swap xならdelta=A[x+1]-A[x]、add(x,delta),add(x+1,-delta)、Aを交換。sum l rならprefix(r)-prefix(l-1)を出力。')}

TITLES={'abc437_d': 'Sum of Differences', 'abc438_d': 'Tail of Snake', 'abc439_d': 'Kadomatsu Subsequence', 'abc440_d': 'Forbidden List 2', 'abc441_d': 'Paid Walk', 'abc442_d': 'Swap and Range Sum'}
PUBLISHED_SAMPLES={'abc437_d': [{'input': '4 2\n1 6 9 2\n3 1\n', 'expected': '26\n'}, {'input': '8 8\n185991676 311812083 311812083 84357963 185991676 185991676 724020528 369175631\n455049197 387671868 4361724 724020528 724020528 455049197 455049197 724020528\n', 'expected': '529117255\n'}], 'abc438_d': [{'input': '5\n1 4 2 4 3\n2 3 4 2 2\n3 2 4 4 3\n', 'expected': '16\n'}, {'input': '3\n1 1 1\n1 1 1\n1 1 1\n', 'expected': '3\n'}, {'input': '6\n2 10 7 7 7 11\n5 7 9 10 9 12\n6 6 7 10 12 7\n', 'expected': '50\n'}], 'abc439_d': [{'input': '10\n3 10 7 10 7 6 7 6 5 14\n', 'expected': '7\n'}, {'input': '6\n210 210 210 210 210 210\n', 'expected': '0\n'}, {'input': '21\n49 30 50 21 35 15 21 70 35 9 50 70 21 49 30 50 70 15 9 21 30\n', 'expected': '34\n'}], 'abc440_d': [{'input': '5 4\n16 9 2 3 1\n6 10\n12 4\n1 1\n1000000000 1000000000\n', 'expected': '17\n15\n4\n1999999999\n'}, {'input': '10 10\n284008711 658403910 982178205 50598815 694147827 230009803 763277509 509451676 821970166 284008710\n740250292 159734720\n255870361 8400028\n23659634 718117163\n697334729 301140741\n698853172 270344164\n713418715 285312509\n50065000 52368934\n46642556 591869945\n607623561 273664826\n482426028 265015448\n', 'expected': '899985013\n264270388\n741776803\n998475472\n969197337\n998731226\n102433934\n638512505\n881288390\n747441478\n'}], 'abc441_d': [{'input': '5 8 3 80 100\n1 2 20\n1 3 70\n2 1 30\n2 5 10\n3 2 10\n3 4 30\n3 5 20\n5 1 70\n', 'expected': '1 5\n'}, {'input': '10 1 1 1 100\n2 3 1\n', 'expected': '\n'}, {'input': '2 5 3 1 100\n1 1 1\n2 2 100\n1 2 1\n1 2 1\n1 2 100\n', 'expected': '1 2\n'}], 'abc442_d': [{'input': '4 4\n2 7 1 8\n1 2\n2 1 2\n1 1\n2 2 4\n', 'expected': '3\n17\n'}, {'input': '8 10\n22 75 26 45 72 81 47 29\n2 2 7\n2 6 8\n2 4 4\n1 2\n2 1 3\n1 1\n2 2 4\n1 2\n1 4\n2 1 1\n', 'expected': '346\n157\n45\n123\n142\n26\n'}]}
SAMPLE_COUNTS={'abc437_d': 2, 'abc438_d': 3, 'abc439_d': 3, 'abc440_d': 2, 'abc441_d': 3, 'abc442_d': 2}
