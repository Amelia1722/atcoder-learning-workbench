"""Reviewed ABC214--219 C, including semantic bounded magic sequences."""
from __future__ import annotations
from collections import Counter
from heapq import heapify,heappop,heappush
from math import factorial
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(214,220))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc216_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
Point=tuple[int,int]
ALPHABET='abcdefghijklmnopqrstuvwxyz'
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def permutations_count(counts:Counter[str])->int:
    total=factorial(sum(counts.values()))
    for count in counts.values():total//=factorial(count)
    return total
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==214:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==3,'shape');s=ints(rows[1],n);t=ints(rows[2],n);require(all(1<=v<=10**9 for v in s+t),'times');return s,t
    if number==215:
        require(len(rows)==1 and re.fullmatch(r'[a-z]{1,8} [1-9][0-9]*',rows[0]) is not None,'string/rank');s,k=rows[0].split(' ');rank=int(k);require(rank<=permutations_count(Counter(s)),'rank exists');return s,rank
    if number==216:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**18,'balls');return (n,)
    if number==217:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==2,'shape');p=ints(rows[1],n);require(len(set(p))==n and all(1<=v<=n for v in p),'permutation');return (p,)
    if number==218:
        n=ints(rows[0],1)[0];require(1<=n<=200 and len(rows)==2*n+1,'shape');s=tuple(rows[1:n+1]);t=tuple(rows[n+1:]);require(all(len(row)==n and set(row)<={'.','#'} for row in s+t) and any('#' in row for row in s) and any('#' in row for row in t),'nonempty shapes');return s,t
    require(len(rows)>=4,'shape');x=rows[0];n=ints(rows[1],1)[0];names=tuple(rows[2:]);require(len(x)==26 and set(x)==set(ALPHABET) and 2<=n<=50000 and len(names)==n and len(set(names))==n and all(re.fullmatch('[a-z]{1,10}',s) is not None for s in names),'alphabet/names');return x,names

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==214:
        s,t=cast(tuple[tuple[int,...],tuple[int,...]],data);distance=list(t);queue=[(d,j) for j,d in enumerate(t)];heapify(queue)
        while queue:
            d,j=heappop(queue)
            if d!=distance[j]:continue
            v=(j+1)%len(s);candidate=d+s[j]
            if candidate<distance[v]:distance[v]=candidate;heappush(queue,(candidate,v))
        return '\n'.join(map(str,distance))
    if number==215:
        s,k=cast(tuple[str,int],data);counts=Counter(s);answer=''
        for _ in s:
            for ch in sorted(counts):
                if not counts[ch]:continue
                counts[ch]-=1;block=permutations_count(counts)
                if k<=block:answer+=ch;break
                k-=block;counts[ch]+=1
        return answer
    if number==216:
        n=cast(int,data[0]);return 'A'+''.join('B'+('A' if bit=='1' else '') for bit in bin(n)[3:])
    if number==217:
        p=cast(tuple[int,...],data[0]);return ' '.join(str(j+1) for j in sorted(range(len(p)),key=lambda j:p[j]))
    if number==218:
        s,t=cast(tuple[tuple[str,...],tuple[str,...]],data);points=[(r,c) for r,row in enumerate(s) for c,v in enumerate(row) if v=='#'];target=[(r,c) for r,row in enumerate(t) for c,v in enumerate(row) if v=='#']
        if len(points)!=len(target):return 'No'
        def centered(p:list[Point])->set[Point]:
            count=len(p);sr=sum(r for r,c in p);sc=sum(c for r,c in p);return {(count*r-sr,count*c-sc) for r,c in p}
        a,b=centered(points),centered(target)
        for _ in range(4):
            if a==b:return 'Yes'
            a={(-c,r) for r,c in a}
        return 'No'
    x,names=cast(tuple[str,tuple[str,...]],data);children:list[dict[str,int]]=[{}];terminal:dict[int,str]={}
    for name in names:
        node=0
        for ch in name:
            if ch not in children[node]:children[node][ch]=len(children);children.append({})
            node=children[node][ch]
        terminal[node]=name
    ordered=[];stack=[0]
    while stack:
        node=stack.pop()
        if node in terminal:ordered.append(terminal[node])
        stack.extend(children[node][ch] for ch in reversed(x) if ch in children[node])
    return '\n'.join(ordered)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw);token=actual.removesuffix('\n')
        if pid=='abc216_c':
            if re.fullmatch('[AB]{1,120}',token) is None:return False
            value=0
            for ch in token:value=value+1 if ch=='A' else value*2
            return value==data[0]
        return token==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc216_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc214_c':"n=int(input());s=list(map(int,input().split()));t=list(map(int,input().split()))\nfor j in range(2*n):\n i=j%n;t[(i+1)%n]=min(t[(i+1)%n],t[i]+s[i])\nprint(*t,sep='\\n')\n",
'abc215_c':"from itertools import permutations\ns,k=input().split();words=sorted({''.join(p) for p in permutations(s)});print(words[int(k)-1])\n",
'abc216_c':"n=int(input());steps=[]\nwhile n:\n if n%2:steps.append('A');n-=1\n else:steps.append('B');n//=2\nprint(''.join(steps[::-1]))\n",
'abc217_c':"n=int(input());p=list(map(int,input().split()));q=[0]*n\nfor i,v in enumerate(p,1):q[v-1]=i\nprint(*q)\n",
'abc218_c':"n=int(input());s={(r,c) for r in range(n) for c,v in enumerate(input()) if v=='#'};t={(r,c) for r in range(n) for c,v in enumerate(input()) if v=='#'}\ndef normalize(p):\n mr=min(r for r,c in p);mc=min(c for r,c in p);return {(r-mr,c-mc) for r,c in p}\nt=normalize(t);answer=False\nfor _ in range(4):\n if normalize(s)==t:answer=True\n s={(c,-r) for r,c in s}\nprint('Yes' if answer else 'No')\n",
'abc219_c':"x=input();n=int(input());names=[input() for _ in range(n)];rank={ch:i for i,ch in enumerate(x)};names.sort(key=lambda s:tuple(rank[ch] for ch in s));print(*names,sep='\\n')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16400+number)
    if number==214:
        def ring(s:list[int],t:list[int])->str:return f'{len(s)}\n'+line(s)+line(t)
        raws=[ring([1],[1]),ring([10**9],[10**9]),ring([1,1],[10**9,1]),ring([3,4],[5,2])]
        for n in range(3,15):raws.append(ring([rng.randint(1,100) for _ in range(n)],[rng.randint(1,1000) for _ in range(n)]))
        raws.extend([ring([1]*200000,[10**9]*199999+[1]),ring([10**9]*200000,[10**9]*200000)])
    elif number==215:
        pairs=[('a',1),('aa',1),('ab',1),('ab',2),('aab',2),('aabb',6),('abc',4),('aaaaaaa',1),('abcdefgh',1),('abcdefgh',20160),('aabbccdd',2520),('zzzzzzzz',1),('azazazaz',35),('dcba',24),('abcabc',50),('zyx',1),('aaaaaaaz',8),('zyxwvuts',40320)];raws=[f'{s} {k}\n' for s,k in pairs]
    elif number==216:raws=[f'{n}\n' for n in (1,2,3,4,5,14,15,16,17,31,32,33,10**9,2**59-1,2**59,2**59+1,10**18-1,10**18)]
    elif number==217:
        def permutation(p:list[int])->str:return f'{len(p)}\n'+line(p)
        raws=[permutation([1]),permutation([1,2]),permutation([2,1]),permutation([2,3,1])]
        for n in range(4,16):p=list(range(1,n+1));rng.shuffle(p);raws.append(permutation(p))
        p=list(range(1,200001));rng.shuffle(p);raws.extend([permutation(p),permutation(list(range(200000,0,-1)))])
    elif number==218:
        def shape(n:int,s:set[Point],t:set[Point])->str:
            return f'{n}\n'+''.join(''.join('#' if (r,c) in p else '.' for c in range(n))+'\n' for p in (s,t) for r in range(n))
        raws=[shape(1,{(0,0)},{(0,0)}),shape(2,{(0,0)},{(1,1)}),shape(2,{(0,0),(0,1)},{(0,0),(1,0)}),shape(2,{(0,0)},{(0,0),(1,1)})]
        for n in range(3,15):
            s={(r,c) for r in range(n) for c in range(n) if rng.randrange(3)==0};s.add((0,0));t={(c,n-1-r) for r,c in s} if n%2 else {(r,c) for r in range(n) for c in range(n) if rng.randrange(3)==0};t.add((0,n-1)) if not t else None;raws.append(shape(n,s,t))
        s={(r,c) for r in range(200) for c in range(200) if (r*31+c*17)%7<3};raws.extend([shape(200,s,{(c,199-r) for r,c in s}),shape(200,{(r,c) for r in range(200) for c in range(200)},{(r,c) for r in range(200) for c in range(200)})])
    else:
        def names(x:str,a:list[str])->str:return x+'\n'+str(len(a))+'\n'+'\n'.join(a)+'\n'
        raws=[names(ALPHABET,['a','b']),names(ALPHABET[::-1],['a','b']),names(ALPHABET,['a','ab','abc','b']),names(ALPHABET[::-1],['a','ab','abc','b'])]
        for j in range(1,13):
            x=list(ALPHABET);rng.shuffle(x);a=set()
            while len(a)<j+4:a.add(''.join(rng.choice('abcxyz') for _ in range(rng.randint(1,10))))
            raws.append(names(''.join(x),sorted(a)))
        def word(j:int)->str:
            a=[]
            for _ in range(10):a.append(ALPHABET[j%26]);j//=26
            return ''.join(a)
        a=[word(j) for j in range(50000)];raws.extend([names(ALPHABET,a),names(ALPHABET[::-1],a[::-1])])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc214_c':('隣の人から受け取る時刻と、高橋君から受け取る時刻の小さい方が候補です。','初期値をTにし、円周を2周して t[next]=min(t[next],t[i]+S[i]) を更新します。最も早い初期時刻からの伝播も全員に届きます。','疑似コード: answer=T; for j=0..2*N-1: i=j%N; next=(i+1)%N; answer[next]=min(answer[next],answer[i]+S[i]); print each answer on its own line。'),
'abc215_c':('長さは8以下なので、全ての並べ替えを列挙できます。','同じ文字があると同じ文字列が複数回現れます。集合で重複を除いてから辞書順に並べます。','疑似コード: words=sorted(set(join(p) for p in permutations(S))); print(words[K-1])。'),
'abc216_c':('Nから0へ戻す操作を考えます。','奇数なら1を引き、偶数なら2で割ります。対応するAとBを記録して逆順にすれば、120回以内の方法になります。最短でなくても構いません。','疑似コード: steps=[]; while N>0: if N odd: steps.append(A); N-=1; else: steps.append(B); N//=2; print(reverse(steps))。'),
'abc217_c':('Pの各位置から、Qのどの位置へ値を入れるかが直接決まります。','P[i]を添字として、Q[P[i]]=iを全てのiに対して設定します。配列を0始まりで持つ場合は1を引きます。','疑似コード: Q=[0]*N; for i=1..N: Q[P[i]-1]=i; print Q separated by spaces。'),
'abc218_c':('回転は4種類です。それぞれについて、平行移動後に同じ形か調べます。','黒マスの座標集合を作り、最小行・最小列を引いて平行移動を正規化します。Sを90度ずつ回してTと比較します。連結成分全体を一緒に扱います。','疑似コード: target=normalize(T); repeat 4 times: if normalize(S)==target: Yes; S={(c,-r) for (r,c) in S}; if no match: No。'),
'abc219_c':('各文字を、新しい順序で何番目かという番号に変換します。','名前を文字の順位列に変え、その列を辞書順でソートします。接頭辞の短い名前が先になる性質もそのまま使えます。','疑似コード: rank={X[i]:i}; sort names by tuple(rank[ch] for ch in name); print each original name on its own line。')}

TITLES={'abc214_c': 'Distribution', 'abc215_c': 'One More aab aba baa', 'abc216_c': 'Many Balls', 'abc217_c': 'Inverse of Permutation', 'abc218_c': 'Shapes', 'abc219_c': 'Neo-lexicographic Ordering'}
PUBLISHED_SAMPLES={'abc214_c': [{'input': '3\n4 1 5\n3 10 100\n', 'expected': '3\n7\n8\n'}, {'input': '4\n100 100 100 100\n1 1 1 1\n', 'expected': '1\n1\n1\n1\n'}, {'input': '4\n1 2 3 4\n1 2 4 7\n', 'expected': '1\n2\n4\n7\n'}, {'input': '8\n84 87 78 16 94 36 87 93\n50 22 63 28 91 60 64 27\n', 'expected': '50\n22\n63\n28\n44\n60\n64\n27\n'}], 'abc215_c': [{'input': 'aab 2\n', 'expected': 'aba\n'}, {'input': 'baba 4\n', 'expected': 'baab\n'}, {'input': 'ydxwacbz 40320\n', 'expected': 'zyxwdcba\n'}], 'abc216_c': [{'input': '5\n', 'expected': 'AABA\n'}, {'input': '14\n', 'expected': 'BBABBAAAB\n'}], 'abc217_c': [{'input': '3\n2 3 1\n', 'expected': '3 1 2\n'}, {'input': '3\n1 2 3\n', 'expected': '1 2 3\n'}, {'input': '5\n5 3 2 4 1\n', 'expected': '5 3 2 4 1\n'}], 'abc218_c': [{'input': '5\n.....\n..#..\n.###.\n.....\n.....\n.....\n.....\n....#\n...##\n....#\n', 'expected': 'Yes\n'}, {'input': '5\n#####\n##..#\n#..##\n#####\n.....\n#####\n#..##\n##..#\n#####\n.....\n', 'expected': 'No\n'}, {'input': '4\n#...\n..#.\n..#.\n....\n#...\n#...\n..#.\n....\n', 'expected': 'Yes\n'}, {'input': '4\n#...\n.##.\n..#.\n....\n##..\n#...\n..#.\n....\n', 'expected': 'No\n'}], 'abc219_c': [{'input': 'bacdefghijklmnopqrstuvwxzy\n4\nabx\nbzz\nbzy\ncaa\n', 'expected': 'bzz\nbzy\nabx\ncaa\n'}, {'input': 'zyxwvutsrqponmlkjihgfedcba\n5\na\nab\nabc\nac\nb\n', 'expected': 'b\na\nac\nab\nabc\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
