"""Statement-checked three-stage hints for ABC212–214 B."""
HINTS_V118 = {
    'abc212_b': (
        '弱い暗証番号になる条件は2種類あります。「全桁が同じ」と「1ずつ進む」を別々に判定してください。',
        '連続条件では9の次が0に戻ります。隣接する3組について、次の数字が `(現在+1)%10` かを確認します。',
        '''疑似コード:
read X as 4-character string
same = all four digits are equal
sequential = true
for i = 0..2:
  if int(X[i+1]) != (int(X[i]) + 1) % 10:
    sequential = false
if same or sequential:
  print("Weak")
else:
  print("Strong")''',
    ),
    'abc213_b': (
        'スコアが小さいほど上位なので、「下位から2番目」はスコアが2番目に大きい選手です。',
        '選手番号を失わないよう `(スコア, 選手番号)` の組で扱い、スコア順に並べるか、大きい2値を管理します。',
        '''疑似コード:
pairs = [(A[i], i+1) for i = 0..N-1]
sort pairs by score descending
print(pairs[1].player_number)''',
    ),
    'abc214_b': (
        'Sが最大100なので、a,b,cを実際に全て試せる大きさか計算してみてください。',
        '各変数は0以上S以下です。3重ループで全組を列挙し、和と積の2条件を両方満たす組だけ数えます。',
        '''疑似コード:
ans = 0
for a = 0..S:
  for b = 0..S:
    for c = 0..S:
      if a+b+c <= S and a*b*c <= T:
        ans += 1
print(ans)''',
    ),
}
