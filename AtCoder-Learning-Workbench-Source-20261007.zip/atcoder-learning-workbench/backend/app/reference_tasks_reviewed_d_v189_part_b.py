"""Private ABC192--197 D: exact and official numerical contracts."""
from __future__ import annotations
from collections import Counter
from decimal import Decimal,localcontext,DecimalException
from functools import lru_cache
from math import isqrt
from typing import cast
import bisect,random,re
TASKS=tuple(f'abc{n}_d' for n in range(192,198));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc193_d':'numeric_tolerance_1e-5','abc194_d':'numeric_tolerance_1e-6','abc197_d':'float_abs_or_rel_1e-5'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc192_d':
  require(len(r)==2 and re.fullmatch(r'[1-9][0-9]{0,59}',r[0]) is not None,'X');m=ints(r[1],1)[0];require(1<=m<=10**18,'M');return r[0],m
 if pid=='abc193_d':
  require(len(r)==3,'shape');k=ints(r[0],1)[0];require(2<=k<=100000 and all(re.fullmatch('[1-9]{4}#',s) is not None for s in r[1:]),'cards');require(all(c<=k for c in Counter(r[1][:-1]+r[2][:-1]).values()),'deck availability');return k,r[1][:-1],r[2][:-1]
 if pid=='abc194_d':
  require(len(r)==1,'shape');n=ints(r[0],1)[0];require(2<=n<=100000,'N');return (n,)
 if pid=='abc195_d':
  n,m,q=ints(r[0],3);require(1<=min(n,m,q) and max(n,m,q)<=50 and len(r)==n+q+2,'shape');items=tuple(ints(s,2) for s in r[1:n+1]);boxes=ints(r[n+1],m);queries=tuple(ints(s,2) for s in r[n+2:]);require(all(1<=v<=10**6 for item in items for v in item) and all(1<=v<=10**6 for v in boxes) and all(1<=l<=rr<=m for l,rr in queries),'bounds');return items,boxes,queries
 if pid=='abc196_d':
  require(len(r)==1,'shape');h,w,a,b=ints(r[0],4);require(1<=h and 1<=w and h*w<=16 and a>=0 and b>=0 and 2*a+b==h*w,'tiling');return h,w,a,b
 require(len(r)==3,'shape');n=ints(r[0],1)[0];a=ints(r[1],2);b=ints(r[2],2);require(4<=n<=100 and n%2==0 and all(0<=v<=100 for v in a+b) and a!=b,'polygon');return n,a,b
def integer_root(n:int,d:int)->int:
 x=1<<((n.bit_length()+d-1)//d)
 while True:
  y=((d-1)*x+n//x**(d-1))//d
  if y>=x:return x
  x=y
def radix_newton(s:str,m:int)->int:
 digits=list(map(int,s));d=max(digits)
 if len(digits)==1:return int(d<=m)
 def polynomial(base:int)->tuple[int,int]:
  value=derivative=0
  for v in digits:derivative=derivative*base+value;value=value*base+v
  return value,derivative
 if polynomial(d+1)[0]>m:return 0
 upper=integer_root(m//digits[0],len(digits)-1)+1
 while True:
  value,derivative=polynomial(upper);step=(value-m)//derivative
  if step<=0:break
  upper-=step
 while polynomial(upper)[0]>m:upper-=1
 return max(0,upper-d)
def poker_distribution(k:int,s:str,t:str)->Decimal:
 used=Counter(s+t);remaining={str(i):k-used[str(i)] for i in range(1,10)}
 def scores(hand:str)->dict[str,int]:
  counts=Counter(hand);return {d:sum(i*10**(counts[str(i)]+int(str(i)==d)) for i in range(1,10)) for d in remaining}
 ss,ts=scores(s),scores(t);opponents=sorted((ts[d],remaining[d]) for d in remaining);keys=[v for v,c in opponents];prefix=[0]
 for v,c in opponents:prefix.append(prefix[-1]+c)
 numerator=sum(remaining[d]*prefix[bisect.bisect_left(keys,ss[d])] for d in remaining)-sum(remaining[d] for d in remaining if ss[d]>ts[d]);n=9*k-8
 with localcontext() as ctx:ctx.prec=80;return Decimal(numerator)/Decimal(n*(n-1))
@lru_cache(maxsize=128)
def connectivity_euler(n:int)->Decimal:
 with localcontext() as ctx:
  ctx.prec=80;m=n-1;anchor=256;h=sum((Decimal(1)/j for j in range(1,min(m,anchor)+1)),Decimal(0))
  if m>anchor:
   def correction(x:int)->Decimal:
    d=Decimal(x);return 1/(2*d)-1/(12*d**2)+1/(120*d**4)-1/(252*d**6)+1/(240*d**8)-1/(132*d**10)+Decimal(691)/(32760*d**12)
   h+=(Decimal(m)/anchor).ln()+correction(m)-correction(anchor)
  return h*n
def matching_hungarian(items:tuple[tuple[int,int],...],boxes:tuple[int,...])->int:
 n=len(items);m=len(boxes)+n;cost=[[(-v if w<=cap else 10**12) for cap in boxes]+[0]*n for w,v in items];u=[0]*(n+1);v=[0]*(m+1);p=[0]*(m+1);way=[0]*(m+1)
 for i in range(1,n+1):
  p[0]=i;j0=0;minv=[10**30]*(m+1);used=[False]*(m+1)
  while True:
   used[j0]=True;i0=p[j0];delta=10**30;j1=0
   for j in range(1,m+1):
    if used[j]:continue
    cur=cost[i0-1][j-1]-u[i0]-v[j]
    if cur<minv[j]:minv[j]=cur;way[j]=j0
    if minv[j]<delta:delta=minv[j];j1=j
   for j in range(m+1):
    if used[j]:u[p[j]]+=delta;v[j]-=delta
    else:minv[j]-=delta
   j0=j1
   if p[j0]==0:break
  while j0:j1=way[j0];p[j0]=p[j1];j0=j1
 return v[0]
def tiling_edge_subsets(h:int,w:int,a:int,b:int)->int:
 edges=[]
 for r in range(h):
  for c in range(w):
   if r+1<h:edges.append((1<<(r*w+c))|(1<<((r+1)*w+c)))
   if c+1<w:edges.append((1<<(r*w+c))|(1<<(r*w+c+1)))
 states={0:1}
 for edge in edges:
  for used,count in list(states.items()):
   if used&edge==0 and used.bit_count()<2*a:states[used|edge]=states.get(used|edge,0)+count
 return sum(count for used,count in states.items() if used.bit_count()==2*a)
def atan_decimal(z:Decimal)->Decimal:
 term=total=z;j=1
 while True:
  term=-term*z*z;add=term/(2*j+1);total+=add
  if abs(add)<Decimal('1e-75'):return total
  j+=1
@lru_cache(maxsize=128)
def polygon_decimal(n:int,a:tuple[int,int],b:tuple[int,int])->tuple[Decimal,Decimal]:
 with localcontext() as ctx:
  ctx.prec=80;pi=16*atan_decimal(Decimal(1)/5)-4*atan_decimal(Decimal(1)/239);theta=2*pi/n;cos=Decimal(1);sin=theta;tc=Decimal(1);ts=theta;j=1
  while True:
   tc=-tc*theta*theta/((2*j-1)*(2*j));ts=-ts*theta*theta/((2*j)*(2*j+1));cos+=tc;sin+=ts
   if max(abs(tc),abs(ts))<Decimal('1e-75'):break
   j+=1
  x=Decimal(a[0]+b[0])/2;y=Decimal(a[1]+b[1])/2;dx=Decimal(a[0])-x;dy=Decimal(a[1])-y;return x+dx*cos-dy*sin,y+dx*sin+dy*cos
def numeric_tokens(targets:tuple[Decimal,...],actual:str,digits:int)->bool:
 fields=actual.split()
 if len(fields)!=len(targets) or any(re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',s) is None for s in fields):return False
 try:
  with localcontext() as ctx:
   ctx.prec=100;tolerance=Decimal(10)**(-digits)
   for target,field in zip(targets,fields):
    value=Decimal(field);error=abs(value-target)
    if not value.is_finite() or not(error<=tolerance or error<=abs(target)*tolerance):return False
  return True
 except DecimalException:return False
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc192_d':return f'{radix_newton(*cast(tuple[str,int],d))}\n'
 if pid=='abc193_d':return str(poker_distribution(*cast(tuple[int,str,str],d)))+'\n'
 if pid=='abc194_d':return str(connectivity_euler(cast(int,d[0])))+'\n'
 if pid=='abc195_d':
  items,boxes,queries=cast(tuple[tuple[tuple[int,int],...],tuple[int,...],tuple[tuple[int,int],...]],d);return ''.join(f'{matching_hungarian(items,boxes[:l-1]+boxes[r:])}\n' for l,r in queries)
 if pid=='abc196_d':return f'{tiling_edge_subsets(*cast(tuple[int,int,int,int],d))}\n'
 return ' '.join(map(str,polygon_decimal(*cast(tuple[int,tuple[int,int],tuple[int,int]],d))))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc193_d':return numeric_tokens((poker_distribution(*cast(tuple[int,str,str],d)),),actual,5)
  if pid=='abc194_d':return numeric_tokens((connectivity_euler(cast(int,d[0])),),actual,6)
  if pid=='abc197_d':return numeric_tokens(polygon_decimal(*cast(tuple[int,tuple[int,int],tuple[int,int]],d)),actual,5)
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError,DecimalException):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc192_d':'''x=input();m=int(input());d=max(map(int,x))
if len(x)==1:print(int(int(x)<=m))
else:
 def valid(base):
  v=0
  for c in x:
   v=v*base+int(c)
   if v>m:return False
  return True
 low=d;high=m+1
 while high-low>1:
  middle=(low+high)//2
  if valid(middle):low=middle
  else:high=middle
 print(low-d)
''',
'abc193_d':'''from collections import Counter
k=int(input());s=input()[:4];t=input()[:4];cs=Counter(s);ct=Counter(t);remain={str(i):k-cs[str(i)]-ct[str(i)] for i in range(1,10)};win=0
for i in range(1,10):
 for j in range(1,10):
  left=sum(d*10**(cs[str(d)]+(d==i)) for d in range(1,10));right=sum(d*10**(ct[str(d)]+(d==j)) for d in range(1,10))
  if left>right:win+=remain[str(i)]*(remain[str(j)]-(i==j))
n=9*k-8;print(win/(n*(n-1)))
''',
'abc194_d':'''import math
n=int(input());print(math.fsum(n/j for j in range(1,n)))
''',
'abc195_d':'''n,m,q=map(int,input().split());items=[tuple(map(int,input().split())) for _ in range(n)];boxes=list(map(int,input().split()))
for _ in range(q):
 l,r=map(int,input().split());used=[False]*n;answer=0
 for cap in sorted(boxes[:l-1]+boxes[r:]):
  best=-1
  for j,(w,v) in enumerate(items):
   if w<=cap and not used[j] and (best<0 or v>items[best][1]):best=j
  if best>=0:used[best]=True;answer+=items[best][1]
 print(answer)
''',
'abc196_d':'''from functools import lru_cache
h,w,a,b=map(int,input().split());full=(1<<(h*w))-1
@lru_cache(None)
def solve(mask,a,b):
 if mask==full:return int(a==b==0)
 i=next(j for j in range(h*w) if not(mask>>j&1));r,c=divmod(i,w);answer=0
 if b:answer+=solve(mask|(1<<i),a,b-1)
 if a:
  for j in ([i+1] if c+1<w else [])+([i+w] if r+1<h else []):
   if not(mask>>j&1):answer+=solve(mask|(1<<i)|(1<<j),a-1,b)
 return answer
print(solve(0,a,b))
''',
'abc197_d':'''import math
n=int(input());a,b=map(int,input().split());c,d=map(int,input().split());x=(a+c)/2;y=(b+d)/2;radius=math.hypot(a-x,b-y);theta=math.atan2(b-y,a-x)+2*math.pi/n;print(x+radius*math.cos(theta),y+radius*math.sin(theta))
'''}
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(18900+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc192_d':
  pairs=[('1',1),('9',1),('9',9),('9',10**18),('10',1),('10',2),('10',10**18),('22',10),('999',1500),('11',10**18),('99',10**18),('100',10**18),('1'+'0'*59,2**59-1),('1'+'0'*59,2**59),('9'*60,10**18),('123456789',10**18),('1'+'0'*58,10**18),('9'*59+'8',10**18)];raws=[s+'\n'+f'{m}\n' for s,m in pairs]
 elif pid=='abc193_d':
  values=[(2,'1234','5678'),(2,'1144','2233'),(2,'9988','1122'),(6,'1122','2228'),(100000,'3226','3597'),(2,'1122','3344'),(4,'1111','2222'),(8,'1111','1111')]
  for k in range(2,10):
   deck=[str(j) for j in range(1,10) for _ in range(k)];draw=rng.sample(range(len(deck)),8);hand=''.join(deck[j] for j in draw);values.append((k,hand[:4],hand[4:]))
  values+=[(100000,'9999','1111'),(100000,'9999','9999')];raws=[f'{k}\n{s}#\n{t}#\n' for k,s,t in values]
 elif pid=='abc194_d':raws=[f'{n}\n' for n in (2,3,4,5,6,7,8,9,10,100,255,256,257,258,1000,10000,99999,100000)]
 elif pid=='abc195_d':
  def shipping(items:list[tuple[int,int]],boxes:list[int],queries:list[tuple[int,int]])->str:return f'{len(items)} {len(boxes)} {len(queries)}\n'+''.join(line(p) for p in items)+line(boxes)+''.join(line(p) for p in queries)
  raws=[shipping([(1,1)],[1],[(1,1)]),shipping([(1000000,1000000)],[1,1000000],[(1,1)]),shipping([(1,10),(2,100)],[1,2,2],[(2,2),(1,3)])]
  for n in range(2,15):
   boxes=[rng.randint(1,10**6) for _ in range(n+1)];queries=[(rng.randint(1,n+1),n+1) for _ in range(n)];raws.append(shipping([(rng.randint(1,10**6),rng.randint(1,10**6)) for _ in range(n)],boxes,queries))
  raws+=[shipping([(j+1,10**6-j) for j in range(50)],[j+1 for j in range(50)],[(j+1,j+1) for j in range(50)]),shipping([(10**6,10**6)]*50,[10**6]*50,[(50,50)]*50)]
 elif pid=='abc196_d':raws=[line(t) for t in ((1,1,0,1),(1,2,0,2),(1,2,1,0),(2,1,1,0),(2,2,1,2),(2,2,2,0),(3,3,4,1),(1,16,8,0),(16,1,8,0),(2,8,8,0),(8,2,8,0),(4,4,0,16),(4,4,1,14),(4,4,2,12),(4,4,4,8),(4,4,7,2),(4,4,6,4),(4,4,8,0))]
 else:
  values=[(4,(0,0),(0,1)),(4,(1,1),(2,2)),(6,(5,3),(7,4)),(4,(100,100),(0,0)),(100,(0,0),(100,100)),(4,(0,100),(100,0))]
  for n in range(8,28,2):
   a=(rng.randint(0,100),rng.randint(0,100));b=(rng.randint(0,100),rng.randint(0,100));
   if a==b:b=((b[0]+1)%101,b[1])
   values.append((n,a,b))
  values+=[(98,(100,0),(0,100)),(100,(100,100),(0,0))];raws=[f'{n}\n'+line(a)+line(b) for n,a,b in values]
 require(len(raws)==len(set(raws))==18,'distinct18')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc192_d':('一桁のときは、基数を変えても値が変わりません。','二桁以上なら基数が増えるほど値も増えます。最大数字より大きい基数のうち、M以下となる最大を二分探索します。','疑似コード: 一桁ならdigit<=Mを出力; 他はlow=maxdigit,high=M+1; Hornerで基数midの値<=Mならlow=mid、他はhigh=mid; low-maxdigitを出力。'),
'abc193_d':('最後の二枚の数字を1から9で全列挙します。','表向き八枚を除いた各数字の枚数を数えます。二枚が同じ数字なら二枚目の残り枚数を一つ減らし、勝つ組み合わせ数を総抽選数で割ります。','疑似コード: remaining[d]=K-visible[d]; i,j=1..9で各手札scoreを計算; scoreS>scoreTならwin+=remaining[i]*(remaining[j]-(i==j)); win/((9K-8)*(9K-9))を出力。'),
'abc194_d':('グラフが連結になるのは、全頂点を一度は訪れたときです。','未訪問がj個なら、新しい頂点を引くまでの期待操作数はN/jです。最初の頂点以外のN-1個を集める各段階を足します。','疑似コード: answer=sum(N/j for j=1..N-1); 十分な小数桁で出力。'),
'abc195_d':('小さい箱から詰めると、入れられる荷物の選択肢を守れます。','使える箱を容量昇順にし、各箱に収まる未使用荷物のうち最も価値が高いものを選びます。各クエリは独立です。','疑似コード: 各L,Rで箱L..Rを除いて容量sort; usedを初期化; 各箱で入る未使用荷物の価値最大を選んで加算; answerを出力。'),
'abc196_d':('左上から最初の未使用マスに置くタイルを決めます。','半畳、右への畳、下への畳を置ける場合だけ分岐します。使用済みマスをビットマスクで管理します。','疑似コード: solve(mask,A,B); 全マス使用ならA=B=0を判定; 最初の空きiに半畳、右隣畳、下隣畳を再帰; 全分岐の数を足す。'),
'abc197_d':('向かい合う二頂点の中点が正多角形の中心です。','中心からp0へのベクトルを、反時計回りに2π/Nだけ回転します。求めたベクトルに中心を足します。','疑似コード: center=(p0+pN/2)/2; v=p0-center; theta=2π/N; p1=center+(v.x*cos-v.y*sin,v.x*sin+v.y*cos); 二座標を十分な小数桁で出力。')}

TITLES={'abc192_d': 'Base n', 'abc193_d': 'Poker', 'abc194_d': 'Journey', 'abc195_d': 'Shipping Center', 'abc196_d': 'Hanjo', 'abc197_d': 'Opposite'}
PUBLISHED_SAMPLES={'abc192_d': [{'input': '22\n10\n', 'expected': '2\n'}, {'input': '999\n1500\n', 'expected': '3\n'}, {'input': '100000000000000000000000000000000000000000000000000000000000\n1000000000000000000\n', 'expected': '1\n'}], 'abc193_d': [{'input': '2\n1144#\n2233#\n', 'expected': '0.4444444444444444\n'}, {'input': '2\n9988#\n1122#\n', 'expected': '1.0\n'}, {'input': '6\n1122#\n2228#\n', 'expected': '0.001932367149758454\n'}, {'input': '100000\n3226#\n3597#\n', 'expected': '0.6296297942426154\n'}], 'abc194_d': [{'input': '2\n', 'expected': '2.00000000000\n'}, {'input': '3\n', 'expected': '4.50000000000\n'}], 'abc195_d': [{'input': '3 4 3\n1 9\n5 3\n7 8\n1 8 6 9\n4 4\n1 4\n1 3\n', 'expected': '20\n0\n9\n'}], 'abc196_d': [{'input': '2 2 1 2\n', 'expected': '4\n'}, {'input': '3 3 4 1\n', 'expected': '18\n'}, {'input': '4 4 8 0\n', 'expected': '36\n'}], 'abc197_d': [{'input': '4\n1 1\n2 2\n', 'expected': '2.00000000000 1.00000000000\n'}, {'input': '6\n5 3\n7 4\n', 'expected': '5.93301270189 2.38397459622\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
