"""Position lists, component unions, lazy deletion, witness searches and SCCs."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import defaultdict,deque
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(449,455))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank');k=int(pid[3:6])
    if k==449:
        require(len(r)==2,'shape');n,l,u=ints(r[0],3);require(2<=n<=500000 and 1<=l<=u<n and len(r[1])==n and re.fullmatch('[a-z]+',r[1]) is not None,'domain');return l,u,r[1]
    if k==450:
        h,w=ints(r[0],2);require(3<=h<=1000 and 3<=w<=1000 and len(r)==h+1 and all(len(s)==w and set(s)<={'.','#'} for s in r[1:]),'grid');return h,w,tuple(r[1:])
    if k==451:
        q=ints(r[0],1)[0];require(1<=q<=300000 and len(r)==q+1,'queries');queries=tuple(ints(s,2) for s in r[1:]);require(all(t in (1,2) and 1<=h<=10**9 for t,h in queries),'query');return (queries,)
    if k==452:
        n=ints(r[0],1)[0];require(1<=n<=10 and len(r)>=n+3,'shape');bones=tuple(ints(s,2) for s in r[1:n+1]);m=ints(r[n+1],1)[0];words=tuple(r[n+2:]);require(1<=m<=200000 and len(words)==m and len(set(words))==m,'words');require(all(1<=b<=a<=10 for a,b in bones) and all(re.fullmatch('[a-z]{1,10}',s) is not None for s in words),'domain');return n,bones,words
    if k==453:
        require(len(r)==2,'shape');n=ints(r[0],1)[0];a=ints(r[1],n);require(1<=n<=20 and all(1<=x<=10**9 for x in a),'moves');return (a,)
    n,m=ints(r[0],2);require(2<=n<=300000 and 1<=m<=300000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges),'edges');return n,edges

def _trees(queries:tuple[tuple[int,int],...])->str:
    values=sorted({h for t,h in queries});size=1
    while size<len(values):size*=2
    tree=[0]*(2*size);cleared=[False]*(2*size)
    def push(p:int)->None:
        if cleared[p]:
            for child in (2*p,2*p+1):tree[child]=0;cleared[child]=True
            cleared[p]=False
    def update(p:int,left:int,right:int,bound:int,add:bool)->None:
        if add and right-left==1:tree[p]+=1;cleared[p]=False;return
        if not add and right<=bound:tree[p]=0;cleared[p]=True;return
        if not add and left>=bound:return
        push(p);middle=(left+right)//2
        if add:update(2*p if bound<middle else 2*p+1,left if bound<middle else middle,middle if bound<middle else right,bound,True)
        else:update(2*p,left,middle,bound,False);update(2*p+1,middle,right,bound,False)
        tree[p]=tree[2*p]+tree[2*p+1]
    out=[]
    for t,h in queries:update(1,0,size,bisect_left(values,h) if t==1 else bisect_right(values,h),t==1);out.append(str(tree[1]))
    return '\n'.join(out)

def _scc_reach(n:int,edges:tuple[tuple[int,int],...])->int:
    forward=[[] for _ in range(n)];reverse=[[] for _ in range(n)]
    for a,b in edges:forward[a-1].append(b-1);reverse[b-1].append(a-1)
    seen=bytearray(n);order=[]
    for start in range(n):
        if seen[start]:continue
        stack=[(start,False)]
        while stack:
            node,exit_flag=stack.pop()
            if exit_flag:order.append(node);continue
            if seen[node]:continue
            seen[node]=1;stack.append((node,True));stack.extend((v,False) for v in forward[node] if not seen[v])
    groups=[-1]*n;counts=[]
    for start in reversed(order):
        if groups[start]>=0:continue
        group=len(counts);count=0;stack=[start];groups[start]=group
        while stack:
            node=stack.pop();count+=1
            for v in reverse[node]:
                if groups[v]<0:groups[v]=group;stack.append(v)
        counts.append(count)
    dag=[[] for _ in counts];degree=[0]*len(counts)
    for a,b in edges:
        x,y=groups[a-1],groups[b-1]
        if x!=y:dag[x].append(y);degree[y]+=1
    reachable=bytearray(len(counts));reachable[groups[0]]=1;queue=deque(j for j,d in enumerate(degree) if d==0)
    while queue:
        node=queue.popleft()
        for v in dag[node]:
            if reachable[node]:reachable[v]=1
            degree[v]-=1
            if degree[v]==0:queue.append(v)
    return sum(c for c,ok in zip(counts,reachable) if ok)

def oracle(pid:str,raw:str)->str:
    d=validate(pid,raw);k=int(pid[3:6])
    if k==449:
        low,high,s=cast(tuple[int,int,str],d);positions:dict[str,list[int]]=defaultdict(list)
        for j,c in enumerate(s):positions[c].append(j)
        return str(sum(bisect_right(v,j+high)-bisect_left(v,j+low) for v in positions.values() for j in v))
    if k==450:
        h,w,grid=cast(tuple[int,int,tuple[str,...]],d);parent=list(range(h*w));boundary=bytearray(h*w)
        def root(x:int)->int:
            while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
            return x
        for r in range(h):
            for c in range(w):
                if grid[r][c]=='#':continue
                j=r*w+c
                for rr,cc in ((r-1,c),(r,c-1)):
                    if rr>=0 and cc>=0 and grid[rr][cc]=='.':parent[root(j)]=root(rr*w+cc)
        roots=set()
        for r in range(h):
            for c in range(w):
                if grid[r][c]=='.':
                    j=root(r*w+c);roots.add(j)
                    if r in (0,h-1) or c in (0,w-1):boundary[j]=1
        return str(sum(not boundary[j] for j in roots))
    if k==451:return _trees(cast(tuple[tuple[int,int],...],d[0]))
    if k==452:
        n,bones,words=cast(tuple[int,tuple[tuple[int,int],...],tuple[str,...]],d);witnesses=sorted({(len(s),j+1,c) for s in words for j,c in enumerate(s)});answers=[]
        for s in words:
            ok=len(s)==n
            if ok:
                for (a,b),c in zip(bones,s):
                    target=(a,b,c);j=bisect_left(witnesses,target)
                    if j==len(witnesses) or witnesses[j]!=target:ok=False;break
            answers.append('Yes' if ok else 'No')
        return '\n'.join(answers)
    if k==453:
        lengths=cast(tuple[int,...],d[0]);states={1:0}
        for length in lengths:
            new:dict[int,int]={}
            for x,score in states.items():
                for y in (x-2*length,x+2*length):new[y]=max(new.get(y,-1),score+int(x*y<0))
            states=new
        return str(max(states.values()))
    n,edges=cast(tuple[int,tuple[tuple[int,int],...]],d);return str(_scc_reach(n,edges))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc449_c':"n,l,r=map(int,input().split());s=input();counts=[0]*26;answer=0\nfor j,c in enumerate(s):\n if j>=l:counts[ord(s[j-l])-97]+=1\n if j>r:counts[ord(s[j-r-1])-97]-=1\n answer+=counts[ord(c)-97]\nprint(answer)\n",
'abc450_c':"h,w=map(int,input().split());s=[list(input()) for _ in range(h)];answer=0\nfor r in range(h):\n for c in range(w):\n  if s[r][c]!='.':continue\n  s[r][c]='#';stack=[(r,c)];edge=False\n  while stack:\n   x,y=stack.pop();edge|=x in (0,h-1) or y in (0,w-1)\n   for a,b in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):\n    if 0<=a<h and 0<=b<w and s[a][b]=='.':s[a][b]='#';stack.append((a,b))\n  answer+=not edge\nprint(answer)\n",
'abc451_c':"import heapq,sys\nq=int(input());heap=[];out=[]\nfor _ in range(q):\n t,h=map(int,input().split())\n if t==1:heapq.heappush(heap,h)\n else:\n  while heap and heap[0]<=h:heapq.heappop(heap)\n out.append(str(len(heap)))\nprint('\\n'.join(out))\n",
'abc452_c':"n=int(input());bones=[tuple(map(int,input().split())) for _ in range(n)];m=int(input());words=[input() for _ in range(m)];masks=[[0]*10 for _ in range(11)]\nfor s in words:\n for j,c in enumerate(s):masks[len(s)][j]|=1<<(ord(c)-97)\nfor s in words:print('Yes' if len(s)==n and all(masks[a][b-1]>>(ord(c)-97)&1 for (a,b),c in zip(bones,s)) else 'No')\n",
'abc453_c':"n=int(input());a=list(map(int,input().split()));best=0\ndef dfs(j,x,count):\n global best\n if j==n:best=max(best,count);return\n for y in (x-2*a[j],x+2*a[j]):dfs(j+1,y,count+(x*y<0))\ndfs(0,1,0);print(best)\n",
'abc454_c':"n,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):\n a,b=map(int,input().split());g[a-1].append(b-1)\nseen=[False]*n;seen[0]=True;queue=[0]\nfor x in queue:\n for y in g[x]:\n  if not seen[y]:seen[y]=True;queue.append(y)\nprint(len(queue))\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    k=int(pid[3:6]);rng=random.Random(17700+k);raws:list[str]=[]
    if k==449:
        raws=['2 1 1\naa\n','2 1 1\nab\n','3 1 2\naaa\n','3 2 2\naba\n']+[f'{n} {1+n%2} {n-1}\n'+''.join(rng.choice('abc') for _ in range(n))+'\n' for n in range(4,17)]+['500000 1 499999\n'+'a'*500000+'\n']
    elif k==450:
        def grid(rows:list[str])->str:return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'
        raws=[grid(['###']*3),grid(['###','#.#','###']),grid(['...']*3),grid(['#.#','#.#','###'])]+[grid([''.join(rng.choice('.#') for _ in range(n)) for _ in range(n)]) for n in range(4,17)]+[grid(['#'*1000]+['#'+''.join('.' if r%2 and c%2 else '#' for c in range(1,999))+'#' for r in range(1,999)]+['#'*1000])]
    elif k==451:
        def queries(q:list[tuple[int,int]])->str:return f'{len(q)}\n'+''.join(line(v) for v in q)
        raws=[queries([(1,1)]),queries([(2,1)]),queries([(1,10**9),(2,10**9)]),queries([(1,2),(2,1),(1,1),(2,1)])]+[queries([(rng.choice((1,1,2)),rng.randint(1,10)) for _ in range(n)]) for n in range(5,18)]+[queries([(1,10**9)]*150000+[(2,10**9)]*150000)]
    elif k==452:
        def fish(bones:list[tuple[int,int]],words:list[str])->str:return f'{len(bones)}\n'+''.join(line(v) for v in bones)+f'{len(words)}\n'+'\n'.join(words)+'\n'
        raws=[fish([(1,1)],['a']),fish([(2,1)],['a']),fish([(1,1),(1,1)],['ab','a','b']),fish([(2,2),(1,1)],['ab','a'])]
        for j in range(13):
            n=1+j%10;words=sorted({''.join(rng.choice('abc') for _ in range(rng.randint(1,10))) for _ in range(8+j)})
            raws.append(fish([(rng.randint(1,10),1) for _ in range(n)],words))
        def word(j:int)->str:
            chars=[]
            for _ in range(10):chars.append(chr(97+j%26));j//=26
            return ''.join(chars)
        raws.append(fish([(10,10)]*10,[word(j) for j in range(200000)]))
    elif k==453:
        raws=[f'{len(a)}\n'+line(a) for a in ([1],[10**9],[1,1],[100,1,2,3,4])]
        raws += [f'{n}\n'+line([rng.randint(1,20) for _ in range(n)]) for n in range(3,16)];raws.append('20\n'+line([10**9]*20))
    else:
        def graph(n:int,edges:list[tuple[int,int]])->str:return f'{n} {len(edges)}\n'+''.join(line(e) for e in edges)
        raws=[graph(2,[(1,2)]),graph(2,[(2,1)]),graph(3,[(1,2),(2,1)]),graph(3,[(1,2),(1,2)])]
        for n in range(4,17):
            edges=[]
            for _ in range(n*2):
                a=rng.randint(1,n);b=rng.randint(1,n-1);b+=b>=a;edges.append((a,b))
            raws.append(graph(n,edges))
        raws.append(graph(300000,[(j,j+1) for j in range(1,300000)]+[(300000,1)]))
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc449_c':('同じ文字の組だけを数えます。','右端jごとに、距離がL以上R以下の左端の文字数を管理します。','疑似コード: jを左から走査; j-Lを頻度へ追加しj-R-1を除去; S[j]の頻度を答えへ加算。'),
'abc450_c':('白マスの連結成分を調べます。','四方位で探索し、外周に触れた成分を除外します。','疑似コード: 未訪問白マスからDFS; 成分内に外周セルがあるか記録; なければ答えを1増やす。'),
'abc451_c':('小さい高さから削除できる構造を使います。','最小ヒープなら、削除条件を満たす先頭だけを取り除けます。','疑似コード: 1 hならheapへh追加; 2 hなら最小値<=hの間pop; 各クエリ後heapの要素数を出力。'),
'abc452_c':('各肋骨の候補は互いに独立に選べます。','長さと文字位置ごとに現れる文字を記録し、脊椎候補の各文字を検査します。','疑似コード: 全Sの各位置をavailable[長さ][位置]へ登録; |S|=Nかつ各iでS[i]がavailable[A[i]][B[i]-1]ならYes。'),
'abc453_c':('移動方向は各回に2通りです。','Nが20以下なので全方向を探索できます。座標を2倍にして整数で判定します。','疑似コード: DFS(i,x,count); x±2L[i]を次の座標yとし、x*y<0ならcount+1; N回後の最大countを出力。'),
'abc454_c':('交換はAからBへの有向辺です。','アイテム1から到達可能な頂点だけを探索します。','疑似コード: seen[1]=true; queue=[1]; 各頂点の出辺で未訪問先をseenへ登録しqueue追加; 訪問数を出力。')}

TITLES={'abc449_c': 'Comfortable Distance', 'abc450_c': 'Puddles', 'abc451_c': 'Understory', 'abc452_c': 'Fishbones', 'abc453_c': 'Sneaking Glances', 'abc454_c': 'Straw Millionaire'}
PUBLISHED_SAMPLES={'abc449_c': [{'input': '6 2 4\naabcba\n', 'expected': '2\n'}, {'input': '9 3 6\naaaaaaaaa\n', 'expected': '18\n'}, {'input': '10 2 6\naabbccaabb\n', 'expected': '6\n'}], 'abc450_c': [{'input': '5 15\n##########..###\n#...#######.###\n####....###..##\n######.########\n########....###\n', 'expected': '2\n'}, {'input': '10 22\n######################\n####.#################\n###...################\n##.###.##.....########\n##.....##.####.#######\n.######.#......#.....#\n.######.#.####.#.#####\n#########.....##.#####\n################.#####\n################.....#\n', 'expected': '4\n'}], 'abc451_c': [{'input': '5\n1 5\n1 7\n1 8\n2 7\n1 3\n', 'expected': '1\n2\n3\n1\n2\n'}, {'input': '12\n2 256601193\n1 85138616\n1 202564041\n2 276477192\n1 55551662\n1 170271057\n2 754166580\n1 854388209\n1 772036624\n2 651124113\n1 301137866\n2 290875185\n', 'expected': '0\n1\n2\n0\n1\n2\n0\n1\n2\n2\n3\n3\n'}], 'abc452_c': [{'input': '5\n5 3\n5 2\n4 1\n5 1\n3 2\n8\nretro\nchris\nitchy\ntuna\ncrab\nrock\ncod\nash\n', 'expected': 'Yes\nYes\nNo\nNo\nNo\nNo\nNo\nNo\n'}, {'input': '5\n5 1\n5 2\n5 3\n5 4\n5 5\n8\nretro\nchris\nitchy\ntuna\ncrab\nrock\ncod\nash\n', 'expected': 'Yes\nYes\nYes\nNo\nNo\nNo\nNo\nNo\n'}], 'abc453_c': [{'input': '5\n2 5 2 2 1\n', 'expected': '4\n'}, {'input': '5\n100 1 2 3 4\n', 'expected': '1\n'}, {'input': '20\n1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1\n', 'expected': '20\n'}], 'abc454_c': [{'input': '5 5\n1 2\n2 3\n3 4\n2 4\n5 2\n', 'expected': '4\n'}, {'input': '3 2\n2 1\n3 2\n', 'expected': '1\n'}, {'input': '7 8\n2 6\n2 5\n3 6\n1 6\n1 2\n5 6\n2 3\n3 7\n', 'expected': '6\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
