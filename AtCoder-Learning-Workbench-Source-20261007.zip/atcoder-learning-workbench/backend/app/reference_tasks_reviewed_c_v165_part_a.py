"""Six reviewed C tasks: periodic sums, digit allocations, games and exact burn events."""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from itertools import product
from math import comb,gcd
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(220,226))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc223_c':'numeric_tolerance_1e-5'}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==220:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==3,'shape');a=ints(rows[1],n);x=ints(rows[2],1)[0];require(all(1<=v<=10**9 for v in a) and 1<=x<=10**18,'values');return a,x
    if number==221:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**9 and sum(ch!='0' for ch in str(n))>=2,'positive split exists');return (str(n),)
    if number==222:
        n,m=ints(rows[0],2);require(1<=n<=50 and 1<=m<=100 and len(rows)==2*n+1 and all(re.fullmatch('[GCP]+',row) is not None and len(row)==m for row in rows[1:]),'hands');return (tuple(rows[1:]),)
    if number==223:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==n+1,'shape');fuses=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=1000 and 1<=b<=1000 for a,b in fuses),'fuses');return (fuses,)
    if number==224:
        n=ints(rows[0],1)[0];require(3<=n<=300 and len(rows)==n+1,'shape');points=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(len(set(points))==n and all(-10**9<=v<=10**9 for p in points for v in p),'points');return (points,)
    n,m=ints(rows[0],2);require(1<=n<=10000 and 1<=m<=7 and len(rows)==n+1,'shape');matrix=tuple(ints(row,m) for row in rows[1:]);require(all(1<=v<=10**9 for row in matrix for v in row),'calendar');return (matrix,)

def _burn_events(fuses:tuple[Pair,...])->Fraction:
    left=Fraction(0);right=Fraction(sum(a for a,b in fuses));lp=Fraction(0);rp=Fraction(0);l=0;r=len(fuses)-1
    while l<r:
        al,bl=fuses[l];ar,br=fuses[r];step=min((al-lp)/bl,(ar-rp)/br);dl=step*bl;dr=step*br;left+=dl;right-=dr;lp+=dl;rp+=dr
        if lp==al:l+=1;lp=Fraction(0)
        if rp==ar:r-=1;rp=Fraction(0)
    return (left+right)/2

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==220:
        a,x=cast(tuple[tuple[int,...],int],data);prefix=[0]
        for value in a:prefix.append(prefix[-1]+value)
        lo=0;hi=x+1
        while hi-lo>1:
            mid=(lo+hi)//2;total=(mid//len(a))*prefix[-1]+prefix[mid%len(a)]
            if total>x:hi=mid
            else:lo=mid
        return str(hi)
    if number==221:
        counts=Counter(cast(str,data[0]));digits=sorted(counts,reverse=True);answer=0
        for assignment in product(*(range(counts[ch]+1) for ch in digits)):
            left=''.join(ch*amount for ch,amount in zip(digits,assignment));right=''.join(ch*(counts[ch]-amount) for ch,amount in zip(digits,assignment))
            if left and right and left[0]!='0' and right[0]!='0':answer=max(answer,int(left)*int(right))
        return str(answer)
    if number==222:
        hands=cast(tuple[str,...],data[0]);wins=[0]*len(hands);order=list(range(len(hands)));cycle={'G':0,'C':1,'P':2}
        for round_index in range(len(hands[0])):
            for j in range(0,len(order),2):
                a,b=order[j:j+2];delta=(cycle[hands[a][round_index]]-cycle[hands[b][round_index]])%3
                if delta==2:wins[a]+=1
                elif delta==1:wins[b]+=1
            buckets=[[] for _ in range(round_index+2)]
            for j,score in enumerate(wins):buckets[score].append(j)
            order=[j for bucket in reversed(buckets) for j in bucket]
        return '\n'.join(str(j+1) for j in order)
    if number==223:return format(float(_burn_events(cast(tuple[Pair,...],data[0]))),'.15f')
    if number==224:
        points=cast(tuple[Pair,...],data[0]);collinear=0
        for i,(x,y) in enumerate(points):
            directions:Counter[Pair]=Counter()
            for u,v in points[i+1:]:
                dx,dy=u-x,v-y;factor=gcd(dx,dy);dx//=factor;dy//=factor
                if dx<0 or dx==0 and dy<0:dx=-dx;dy=-dy
                directions[dx,dy]+=1
            collinear+=sum(count*(count-1)//2 for count in directions.values())
        return str(comb(len(points),3)-collinear)
    matrix=cast(tuple[tuple[int,...],...],data[0]);origin=divmod(matrix[0][0]-1,7)
    for r,row in enumerate(matrix):
        for c,value in enumerate(row):
            if divmod(value-1,7)!=(origin[0]+r,origin[1]+c):return 'No'
    return 'Yes'

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw);token=actual.removesuffix('\n')
        if pid=='abc223_c':
            if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
            exponent=re.search(r'[eE]([+-]?[0-9]+)$',token)
            if exponent and abs(int(exponent[1]))>1000:return False
            expected=_burn_events(cast(tuple[Pair,...],data[0]));return abs(Fraction(token)-expected)<=max(Fraction(1),abs(expected))/100000
        return token==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError,ZeroDivisionError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc223_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc220_c':"n=int(input());a=list(map(int,input().split()));x=int(input());cycles,remainder=divmod(x,sum(a));answer=cycles*n\nfor value in a:\n answer+=1;remainder-=value\n if remainder<0:break\nprint(answer)\n",
'abc221_c':"s=input();answer=0\nfor mask in range(1,(1<<len(s))-1):\n a=sorted((ch for j,ch in enumerate(s) if mask>>j&1),reverse=True);b=sorted((ch for j,ch in enumerate(s) if not mask>>j&1),reverse=True)\n if a[0]!='0' and b[0]!='0':answer=max(answer,int(''.join(a))*int(''.join(b)))\nprint(answer)\n",
'abc222_c':"n,m=map(int,input().split());hands=[input() for _ in range(2*n)];wins=[0]*(2*n);order=list(range(2*n));beats={('G','C'),('C','P'),('P','G')}\nfor round in range(m):\n for j in range(0,2*n,2):\n  a,b=order[j:j+2];x,y=hands[a][round],hands[b][round]\n  if (x,y) in beats:wins[a]+=1\n  elif (y,x) in beats:wins[b]+=1\n order.sort(key=lambda j:(-wins[j],j))\nprint(*(j+1 for j in order),sep='\\n')\n",
'abc223_c':"n=int(input());fuses=[tuple(map(int,input().split())) for _ in range(n)];remaining=sum(a/b for a,b in fuses)/2;position=0.0\nfor a,b in fuses:\n used=min(remaining,a/b);position+=used*b;remaining-=used\n if remaining<=0:break\nprint(f'{position:.15f}')\n",
'abc224_c':"from itertools import combinations\nn=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];print(sum((b[0]-a[0])*(c[1]-a[1])!=(b[1]-a[1])*(c[0]-a[0]) for a,b,c in combinations(points,3)))\n",
'abc225_c':"n,m=map(int,input().split());a=[list(map(int,input().split())) for _ in range(n)];start=a[0][0];valid=(start-1)%7+m<=7 and all(a[r][c]==start+7*r+c for r in range(n) for c in range(m));print('Yes' if valid else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16500+number)
    if number==220:
        def sequence(a:list[int],x:int)->str:return f'{len(a)}\n'+line(a)+f'{x}\n'
        raws=[sequence([1],1),sequence([2],1),sequence([1],10**18),sequence([2,3],5)]
        for n in range(3,15):raws.append(sequence([rng.randint(1,1000) for _ in range(n)],rng.randint(1,10**18)))
        raws.extend([sequence([1]*100000,10**18),sequence([10**9]*100000,10**18)])
    elif number==221:raws=[f'{n}\n' for n in (11,12,21,101,110,123,1010,1001,999,1234,10203,909090,123456789,998244353,111111111,100000001,909999999,999999999)]
    elif number==222:
        def tournament(a:list[str])->str:return f'{len(a)//2} {len(a[0])}\n'+'\n'.join(a)+'\n'
        raws=[tournament(['G','G']),tournament(['G','C']),tournament(['C','P']),tournament(['P','G'])]
        for j in range(1,13):raws.append(tournament([''.join(rng.choice('GCP') for _ in range(j+1)) for _ in range(2*(j+1))]))
        raws.extend([tournament([''.join(rng.choice('GCP') for _ in range(100)) for _ in range(100)]),tournament(['G'*100]*100)])
    elif number==223:
        def fuses(a:list[Pair])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
        raws=[fuses([(1,1)]),fuses([(1000,1000)]),fuses([(1,1),(1,1000)]),fuses([(1000,1),(1,1000)])]
        for n in range(3,15):raws.append(fuses([(rng.randint(1,1000),rng.randint(1,1000)) for _ in range(n)]))
        raws.extend([fuses([(1,1)]*50000+[(1000,1)]*50000),fuses([(1000,1000)]*100000)])
    elif number==224:
        def points(a:list[Pair])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
        raws=[points([(-10**9,-10**9),(-10**9+1,-10**9),(-10**9,-10**9+1)]),points([(0,0),(1,1),(2,2)]),points([(0,0),(1,0),(0,1)]),points([(0,0),(0,2),(2,0),(2,2)])]
        for n in range(5,17):raws.append(points(rng.sample([(x,y) for x in range(-10,11) for y in range(-10,11)],n)))
        raws.extend([points([(j,j*j) for j in range(300)]),points([(-10**9+j*6000000,-10**9+j*6000000) for j in range(299)]+[(10**9,10**9)])])
    else:
        def calendar(a:list[list[int]])->str:return f'{len(a)} {len(a[0])}\n'+''.join(line(row) for row in a)
        raws=[calendar([[1]]),calendar([[7,8]]),calendar([[1,2],[8,9]]),calendar([[1],[2]])]
        for j in range(1,13):
            n=j+1;m=1+j%7;start=rng.randint(1,1000);a=[[start+7*r+c for c in range(m)] for r in range(n)]
            if j%3==0:a[-1][-1]+=1
            raws.append(calendar(a))
        start=999930001;raws.extend([calendar([[1+7*r+c for c in range(7)] for r in range(10000)]),calendar([[min(10**9,start+7*r+c) for c in range(7)] for r in range(10000)])])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc220_c':('Aを一周するごとに、和はsum(A)だけ増えます。','X//sum(A)周までは超えません。残りについてAを先頭から足し、初めて厳密にXを超える位置を探します。','疑似コード: cycles,rest=divmod(X,sum(A)); answer=cycles*N; for a in A: answer+=1; rest-=a; if rest<0: break; print(answer)。'),
'abc221_c':('各桁を二つのグループのどちらへ入れるかを全列挙できます。','グループが決まれば、その桁を降順に並べた整数が最大です。空グループと0のみのグループを除き、積の最大値を求めます。','疑似コード: for nonempty proper digit mask: a=descending digits in mask; b=descending others; if both start nonzero: answer=max(answer,int(a)*int(b)); print(answer)。'),
'abc222_c':('各ラウンドの順位から次の対戦相手が決まります。','勝数と番号で順位を管理し、隣り合う二人の勝敗を更新してから順位を並べ直します。','疑似コード: order=player IDs; for round: for adjacent pair in order: update winner wins; sort order by (-wins,ID); print order on separate lines。'),
'abc223_c':('全導火線を端から燃やし切る時間を考えます。','左右から同時に燃やすと、出会う時刻は全燃焼時間の半分です。その時間だけ左から燃やした距離を求めます。','疑似コード: time=sum(A[i]/B[i])/2; position=0; for (a,b): used=min(time,a/b); position+=used*b; time-=used; if time<=0: break; print(position)。'),
'abc224_c':('三点が一直線上にあると、三角形の面積は0です。','全ての三点の組を選び、二つの差ベクトルの外積が0でないか整数演算で確認します。','疑似コード: answer=0; for three distinct points a,b,c: if (b.x-a.x)*(c.y-a.y)!=(b.y-a.y)*(c.x-a.x): answer+=1; print(answer)。'),
'abc225_c':('横には1、縦には7ずつ増える必要があります。','左上の値から各要素の期待値を計算します。横方向がカレンダーの7列目を越えていないことも確認します。','疑似コード: valid=((start-1)%7+M<=7); for (r,c): valid &= B[r][c]==start+7*r+c; print(Yes if valid else No)。')}

TITLES={'abc220_c': 'Long Sequence', 'abc221_c': 'Select Mul', 'abc222_c': 'Swiss-System Tournament', 'abc223_c': 'Doukasen', 'abc224_c': 'Triangle?', 'abc225_c': 'Calendar Validator'}
PUBLISHED_SAMPLES={'abc220_c': [{'input': '3\n3 5 2\n26\n', 'expected': '8\n'}, {'input': '4\n12 34 56 78\n1000\n', 'expected': '23\n'}], 'abc221_c': [{'input': '123\n', 'expected': '63\n'}, {'input': '1010\n', 'expected': '100\n'}, {'input': '998244353\n', 'expected': '939337176\n'}], 'abc222_c': [{'input': '2 3\nGCP\nPPP\nCCC\nPPC\n', 'expected': '3\n1\n2\n4\n'}, {'input': '2 2\nGC\nPG\nCG\nPP\n', 'expected': '1\n2\n3\n4\n'}], 'abc223_c': [{'input': '3\n1 1\n2 1\n3 1\n', 'expected': '3.000000000000000\n'}, {'input': '3\n1 3\n2 2\n3 1\n', 'expected': '3.833333333333333\n'}, {'input': '5\n3 9\n1 2\n4 6\n1 5\n5 3\n', 'expected': '8.916666666666668\n'}], 'abc224_c': [{'input': '4\n0 1\n1 3\n1 1\n-1 -1\n', 'expected': '3\n'}, {'input': '20\n224 433\n987654321 987654321\n2 0\n6 4\n314159265 358979323\n0 0\n-123456789 123456789\n-1000000000 1000000000\n124 233\n9 -6\n-4 0\n9 5\n-7 3\n333333333 -333333333\n-9 -1\n7 -10\n-1 5\n324 633\n1000000000 -1000000000\n20 0\n', 'expected': '1124\n'}], 'abc225_c': [{'input': '2 3\n1 2 3\n8 9 10\n', 'expected': 'Yes\n'}, {'input': '2 1\n1\n2\n', 'expected': 'No\n'}, {'input': '10 4\n1346 1347 1348 1349\n1353 1354 1355 1356\n1360 1361 1362 1363\n1367 1368 1369 1370\n1374 1375 1376 1377\n1381 1382 1383 1384\n1388 1389 1390 1391\n1395 1396 1397 1398\n1402 1403 1404 1405\n1409 1410 1411 1412\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
