"""Hints re-reviewed against public official statements of ABC092–094 B."""
HINTS_V78={
'abc092_b':('各参加者が食べる日を1日目から並べたとき、何個食べるかを個別に数えてみてください。','参加者iが食べる回数は 1, A_i+1, ... がD以下に何個あるかです。各人について数え、最後に残ったX個を足します。','疑似コード:\nans = X\nfor a in A:\n  ans += (D-1)//a + 1\nprint(ans)'),
'abc093_b':('必要なのは区間全体ではなく、左右の端から近い部分だけです。重なる場合もあります。','A側からK個とB側からK個を集め、重複を除いて昇順に出力します。','疑似コード:\nvalues = set(A .. min(B,A+K-1))\nvalues |= set(max(A,B-K+1) .. B)\nfor x in sorted(values): print(x)'),
'abc094_b':('ゴールは0側とN側の2通りです。どちらへ進むと料金所を何個通るか比べます。','Xより左にある料金所数と、Xより右にある料金所数を数え、その小さい方が答えです。','疑似コード:\nleft = count(a < X for a in A)\nright = count(a > X for a in A)\nprint(min(left,right))')}
