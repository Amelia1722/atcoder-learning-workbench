"""Statement-checked three-stage hints added while reviewing ABC143–145 B."""
HINTS_V95 = {
    'abc143_b': (
        '2個の選び方をすべて考えます。同じ組を順番だけ変えて二度数えないようにしてください。',
        '添字 i<j の組だけを二重ループで選び、d[i]*d[j] を合計すれば十分です。N<=50なのでO(N^2)で間に合います。',
        '''疑似コード:
ans = 0
for i = 0 .. N-1:
  for j = i+1 .. N-1:
    ans += d[i] * d[j]
print(ans)'''
    ),
    'abc144_b': (
        'Nを九九の表のどこかに作れるか、と考えてください。候補となる2整数の範囲は非常に小さいです。',
        '1〜9の i,j を全探索して、i*j==N となる組が1つでもあればYesです。最大81より大きい値でも制約上入力されるので、その場合はNoになります。',
        '''疑似コード:
for i = 1 .. 9:
  for j = 1 .. 9:
    if i*j == N:
      print("Yes"); stop
print("No")'''
    ),
    'abc145_b': (
        '同じ文字列を2回つなげた形なら、文字列の前半と後半にはどんな関係が必要でしょうか。',
        'Nが奇数なら不可能です。Nが偶数ならS[:N//2]とS[N//2:]をそのまま比較します。',
        '''疑似コード:
if N is odd:
  print("No")
else if S[0:N/2] == S[N/2:N]:
  print("Yes")
else:
  print("No")'''
    ),
}
