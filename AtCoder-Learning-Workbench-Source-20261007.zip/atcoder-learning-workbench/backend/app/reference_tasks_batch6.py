"""ABC001 A: exact official constraints, independent arithmetic check, exhaustive edges."""
from __future__ import annotations
from random import Random

BATCH6={
    'abc001_1': {
        'sample_input':'15\n10\n', 'sample_output':'5',
        'source_url':'https://atcoder.jp/contests/abc001/tasks/abc001_1',
        'constraints':'0 <= H1, H2 <= 2000; input: H1 newline H2',
    },
}


def validate(pid:str, data:str)->tuple[int,int]:
    if pid not in BATCH6:raise ValueError('未対応問題ID')
    parts=data.split()
    if len(parts)!=2 or any(not p.isascii() or not p.isdecimal() for p in parts):
        raise ValueError('非負整数が2個必要')
    h1,h2=map(int,parts)
    if not 0<=h1<=2000 or not 0<=h2<=2000:
        raise ValueError('H1/H2の範囲外')
    return h1,h2


def generate(pid:str,count:int,seed:int,include_large:bool)->list[dict[str,str]]:
    if pid not in BATCH6 or not 1<=count<=80:raise ValueError('問題ID/件数不正')
    rng=Random(seed)
    cases=[];seen=set()
    def add(kind:str,h1:int,h2:int):
        text=f'{h1}\n{h2}\n';validate(pid,text)
        if text not in seen:
            seen.add(text);cases.append({'category':kind,'input':text})
        elif kind=='constraint_max':
            next(c for c in cases if c['input']==text)['category']=kind
    for a,b in [(15,10),(0,0),(5,20),(2000,0),(0,2000),(1,0),(0,1),
                (2000,1999),(1999,2000),(1,1),(1999,1999),(123,456),
                (2000,2000),(37,36),(36,37)]:add('boundary',a,b)
    while len(cases)<count:
        add('random',rng.randint(0,2000),rng.randint(0,2000))
    if include_large:
        add('constraint_max',2000,2000)
        maximum=next(c for c in cases if c['category']=='constraint_max')
        return [c for c in cases if c['input']!=maximum['input']][:count]+[maximum]
    return cases[:count]


def independent_check(pid:str,data:str,expected:str)->bool:
    h1,h2=validate(pid,data)
    try:return int(expected.strip())+h2==h1
    except ValueError:return False
