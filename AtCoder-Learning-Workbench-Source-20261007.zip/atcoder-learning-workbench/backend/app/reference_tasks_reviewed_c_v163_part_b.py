"""Six C tasks: semantic conflict, activation components and polygon boundary turns."""
from __future__ import annotations
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(187,193))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc187_c':'semantic'}
Data=tuple[object,...]
Case=dict[str,str]
Pair=tuple[int,int]
Vertex=tuple[int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def boundary_graph(grid:tuple[str,...])->dict[Vertex,set[Vertex]]:
    graph:dict[Vertex,set[Vertex]]={}
    for r,row in enumerate(grid):
        for c,value in enumerate(row):
            if value!='#':continue
            for dr,dc,a,b in ((-1,0,(r,c),(r,c+1)),(1,0,(r+1,c),(r+1,c+1)),(0,-1,(r,c),(r+1,c)),(0,1,(r,c+1),(r+1,c+1))):
                if grid[r+dr][c+dc]=='.':graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
    return graph

def _connected(cells:set[Vertex])->bool:
    if not cells:return False
    remaining=set(cells);pending=[remaining.pop()]
    while pending:
        r,c=pending.pop()
        for neighbor in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
            if neighbor in remaining:remaining.remove(neighbor);pending.append(neighbor)
    return not remaining

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==187:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');words=tuple(rows[1:]);require(all(len(s)<=10 and re.fullmatch(r'!?[a-z]+',s) is not None for s in words),'strings');return (words,)
    if number==188:
        n=ints(rows[0],1)[0];require(1<=n<=16 and len(rows)==2,'shape');a=ints(rows[1],1<<n);require(all(1<=v<=10**9 for v in a) and len(set(a))==len(a),'distinct strengths');return (a,)
    if number==189:
        n=ints(rows[0],1)[0];require(1<=n<=10000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=100000 for v in a),'heights');return (a,)
    if number==190:
        n,m=ints(rows[0],2);require(2<=n<=100 and 1<=m<=100 and len(rows)>=m+2,'shape');edges=tuple(cast(Pair,ints(row,2)) for row in rows[1:m+1]);k=ints(rows[m+1],1)[0];require(1<=k<=16 and len(rows)==m+k+2,'people');choices=tuple(cast(Pair,ints(row,2)) for row in rows[m+2:]);require(all(1<=a<b<=n for a,b in edges+choices),'pairs');return edges,choices
    if number==191:
        h,w=ints(rows[0],2);require(3<=h<=10 and 3<=w<=10 and len(rows)==h+1,'shape');grid=tuple(rows[1:]);require(all(len(row)==w and set(row)<={'.','#'} for row in grid),'cells');require(all(c=='.' for c in grid[0]+grid[-1]) and all(row[0]==row[-1]=='.' for row in grid),'white border');black={(r,c) for r,row in enumerate(grid) for c,value in enumerate(row) if value=='#'};white={(r,c) for r,row in enumerate(grid) for c,value in enumerate(row) if value=='.'}
        require(_connected(black) and _connected(white) and all(len(edges)==2 for edges in boundary_graph(grid).values()),'single nonintersecting polygon');return (grid,)
    require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(0<=n<=10**9 and 0<=k<=100000,'iteration');return n,k

def _activation_area(heights:tuple[int,...])->int:
    n=len(heights);parent=list(range(n));sizes=[1]*n;active=[False]*n;best=0
    def find(j:int)->int:
        while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
        return j
    for j in sorted(range(n),key=lambda j:heights[j],reverse=True):
        active[j]=True
        for neighbor in (j-1,j+1):
            if 0<=neighbor<n and active[neighbor]:
                a,b=find(j),find(neighbor)
                if a!=b:parent[b]=a;sizes[a]+=sizes[b]
        best=max(best,heights[j]*sizes[find(j)])
    return best

def _boundary_turns(grid:tuple[str,...])->int:
    graph=boundary_graph(grid);start=min(graph);previous=start;current=min(graph[start]);route=[start]
    while current!=start:
        route.append(current);following=next(v for v in graph[current] if v!=previous);previous,current=current,following
    total=0
    for j,(r,c) in enumerate(route):
        a=route[j-1];b=route[(j+1)%len(route)];total+=(r-a[0],c-a[1])!=(b[0]-r,b[1]-c)
    return total

def _digit_recurrence(n:int,k:int)->int:
    seen:dict[int,int]={};step=0
    while step<k:
        if n in seen:
            period=step-seen[n];jump=(k-step)//period
            if jump:step+=jump*period;continue
        seen[n]=step;counts=[0]*10;value=n
        if value==0:counts[0]=1
        while value:counts[value%10]+=1;value//=10
        low=high=0
        for d in range(10):
            for _ in range(counts[d]):low=10*low+d
            for _ in range(counts[9-d]):high=10*high+9-d
        n=high-low;step+=1
    return n

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==187:
        words=cast(tuple[str,...],data[0]);positive=sorted(s for s in words if not s.startswith('!'));negative=sorted(s[1:] for s in words if s.startswith('!'));i=j=0
        while i<len(positive) and j<len(negative):
            if positive[i]==negative[j]:return positive[i]
            if positive[i]<negative[j]:i+=1
            else:j+=1
        return 'satisfiable'
    if number==188:
        a=cast(tuple[int,...],data[0]);players=list(enumerate(a,1))
        while len(players)>2:players=[max(players[j:j+2],key=lambda p:p[1]) for j in range(0,len(players),2)]
        return str(min(players,key=lambda p:p[1])[0])
    if number==189:return str(_activation_area(cast(tuple[int,...],data[0])))
    if number==190:
        edges,choices=cast(tuple[tuple[Pair,...],tuple[Pair,...]],data);reachable={0}
        for a,b in choices:reachable={mask|(1<<v) for mask in reachable for v in (a,b)}
        return str(max(sum(bool(mask>>a&1) and bool(mask>>b&1) for a,b in edges) for mask in reachable))
    if number==191:return str(_boundary_turns(cast(tuple[str,...],data[0])))
    return str(_digit_recurrence(*cast(tuple[int,int],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw);token=actual.removesuffix('\n')
        if pid=='abc187_c':
            words=set(cast(tuple[str,...],data[0]))
            return not any('!'+s in words for s in words if not s.startswith('!')) if token=='satisfiable' else re.fullmatch('[a-z]{1,9}',token) is not None and token in words and '!'+token in words
        return token==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc187_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc187_c':"n=int(input());words={input() for _ in range(n)};both=sorted(s for s in words if not s.startswith('!') and '!'+s in words);print(both[0] if both else 'satisfiable')\n",
'abc188_c':"n=int(input());a=list(map(int,input().split()));middle=len(a)//2;loser=min(max(a[:middle]),max(a[middle:]));print(a.index(loser)+1)\n",
'abc189_c':"n=int(input());a=list(map(int,input().split()));stack=[];answer=0\nfor j,h in enumerate(a+[0]):\n start=j\n while stack and stack[-1][1]>h:\n  start,height=stack.pop();answer=max(answer,height*(j-start))\n if not stack or stack[-1][1]<h:stack.append((start,h))\nprint(answer)\n",
'abc190_c':"from itertools import product\nn,m=map(int,input().split());edges=[tuple(map(int,input().split())) for _ in range(m)];k=int(input());choices=[tuple(map(int,input().split())) for _ in range(k)];answer=0\nfor placement in product(*choices):\n occupied=set(placement);answer=max(answer,sum(a in occupied and b in occupied for a,b in edges))\nprint(answer)\n",
'abc191_c':"h,w=map(int,input().split());s=[input() for _ in range(h)];print(sum(sum(s[r+dr][c+dc]=='#' for dr in range(2) for dc in range(2))%2 for r in range(h-1) for c in range(w-1)))\n",
'abc192_c':"n,k=map(int,input().split())\nfor _ in range(k):\n text=sorted(str(n));n=int(''.join(text[::-1]))-int(''.join(text))\nprint(n)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16300+number)
    if number==187:
        def strings(words:list[str])->str:return f'{len(words)}\n'+'\n'.join(words)+'\n'
        raws=[strings(['a']),strings(['!a']),strings(['a','!a']),strings(['a','!a','b','!b'])]+[strings(['a'*j,'!'+'b'*j,'a'*j,'!'+'a'*j] if j<10 else ['a'*j,'b'*j]) for j in range(1,11)]+[strings(['a','!b','c']),strings(['a','a']),strings(['!a','!a'])]
        def word(j:int)->str:
            letters=[]
            for _ in range(9):letters.append(chr(97+j%26));j//=26
            return ''.join(letters)
        raws.append(strings([s for j in range(100000) for s in (word(j),'!'+word(j))]))
    elif number==188:
        def tournament(a:list[int])->str:return f'{len(a).bit_length()-1}\n'+line(a)
        raws=[tournament([1,2]),tournament([2,1]),tournament([1,4,3,2]),tournament([4,3,2,1])]
        for j in range(1,14):n=1+j%5;a=rng.sample(range(1,100000),1<<n);raws.append(tournament(a))
        raws.append(tournament(list(range(10**9-(1<<16)+1,10**9+1))))
    elif number==189:
        def oranges(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[oranges([1]),oranges([100000]),oranges([2,1]),oranges([1,2])]+[oranges([rng.randrange(1,100001) for _ in range(n)]) for n in range(3,15)]+[oranges([j%1000+1 for j in range(10000)]),oranges([100000]*10000)]
    elif number==190:
        def bowls(n:int,edges:list[Pair],choices:list[Pair])->str:return f'{n} {len(edges)}\n'+''.join(line(e) for e in edges)+f'{len(choices)}\n'+''.join(line(c) for c in choices)
        raws=[bowls(2,[(1,2)],[(1,2)]),bowls(2,[(1,2)],[(1,2),(1,2)]),bowls(3,[(1,2),(2,3)],[(1,2),(2,3)]),bowls(3,[(1,3)]*4,[(1,2),(2,3)])]
        for j in range(1,14):
            n=2+j%7;edges=[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(1+j%10)];choices=[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(1+j%8)];raws.append(bowls(n,cast(list[Pair],edges),cast(list[Pair],choices)))
        edges=[(a,b) for a in range(1,17) for b in range(a+1,17)][:100];raws.append(bowls(100,edges,[(2*j+1,2*j+2) for j in range(16)]))
    elif number==191:
        def polygon(h:int,w:int,cells:set[Vertex])->str:return f'{h} {w}\n'+'\n'.join(''.join('#' if (r,c) in cells else '.' for c in range(w)) for r in range(h))+'\n'
        raws=[polygon(3,3,{(1,1)})]
        for length in range(2,9):raws.append(polygon(10,10,{(1,c) for c in range(1,length+1)}))
        for size in range(2,7):raws.append(polygon(10,10,{(r,c) for r in range(1,size+1) for c in range(1,size+1)}))
        for size in range(2,6):raws.append(polygon(10,10,{(r,c) for r in range(1,size+1) for c in range(1,r+1)}))
        raws.append(polygon(10,10,{(r,c) for r in range(1,9) for c in range(1,9)}))
    else:raws=[line(t) for t in ((0,0),(0,1),(1,0),(1,1),(10,1),(100,1),(1000,1),(1111,100000),(314,1),(314,2),(314,100000),(999999999,1),(1000000000,1),(1000000000,2),(987654321,100000),(6174,100000),(999999999,100000),(1000000000,100000))]
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc187_c':('ある文字列と、先頭に!を付けた文字列が両方あるかを調べます。','全入力を集合に入れ、!で始まらない文字列ごとに否定形の存在を確認します。該当するどれを出しても正解です。','疑似コード: words=set(input_strings); for s in words without leading !: if !+s in words: print(s); stop; print(satisfiable)。'),
'abc188_c':('決勝へ進むのは、前半と後半それぞれの最強選手です。','それぞれの最大値を比べ、小さい方の選手番号を出します。全体の二番目に強い選手とは限りません。','疑似コード: left=max(A[:half]); right=max(A[half:]); print(index(min(left,right))+1)。'),
'abc189_c':('ある区間で食べられる個数は、その区間の最小値×長さです。','高さを単調増加に保つスタックに開始位置を持たせ、低い値が来たら終わる長方形の面積を更新します。','疑似コード: for (i,h) in A+[0]: start=i; while stack.top.height>h: (start,old)=pop(); answer=max(answer,old*(i-start)); push_if_new_height(start,h); print(answer)。'),
'abc190_c':('各人の選択肢は二つで、人数は16以下です。','すべての選択を列挙し、置かれた皿の集合から満たされる条件数を数えます。','疑似コード: for placement in product(choices): occupied=set(placement); answer=max(answer,count edges with both endpoints occupied); print(answer)。'),
'abc191_c':('多角形の辺数は、輪郭が曲がる回数と同じです。','2×2のマスに黒が1個または3個ある場所が角です。公式の単純多角形制約のもとで数えます。','疑似コード: answer=0; for each 2x2 block: black=count(#); if black==1 or black==3: answer+=1; print(answer)。'),
'abc192_c':('各操作を、桁の並べ替えとしてそのまま実行します。','桁を昇順・降順に並べた整数の差を、K回更新します。先頭の0は整数変換で消えます。','疑似コード: repeat K times: digits=sort(str(N)); N=int(reverse(digits))-int(digits); print(N)。')}

TITLES={'abc187_c': '1-SAT', 'abc188_c': 'ABC Tournament', 'abc189_c': 'Mandarin Orange', 'abc190_c': 'Bowls and Dishes', 'abc191_c': 'Digital Graffiti', 'abc192_c': 'Kaprekar Number'}
PUBLISHED_SAMPLES={'abc187_c': [{'input': '6\na\n!a\nb\n!c\nd\n!d\n', 'expected': 'a\n'}, {'input': '10\nred\nred\nred\n!orange\nyellow\n!blue\ncyan\n!green\nbrown\n!gray\n', 'expected': 'satisfiable\n'}], 'abc188_c': [{'input': '2\n1 4 2 5\n', 'expected': '2\n'}, {'input': '2\n3 1 5 4\n', 'expected': '1\n'}, {'input': '4\n6 13 12 5 3 7 10 11 16 9 8 15 2 1 14 4\n', 'expected': '2\n'}], 'abc189_c': [{'input': '6\n2 4 4 9 4 9\n', 'expected': '20\n'}, {'input': '6\n200 4 4 9 4 9\n', 'expected': '200\n'}], 'abc190_c': [{'input': '4 4\n1 2\n1 3\n2 4\n3 4\n3\n1 2\n1 3\n2 3\n', 'expected': '2\n'}, {'input': '4 4\n1 2\n1 3\n2 4\n3 4\n4\n3 4\n1 2\n2 4\n2 4\n', 'expected': '4\n'}, {'input': '6 12\n2 3\n4 6\n1 2\n4 5\n2 6\n1 5\n4 5\n1 3\n1 2\n2 6\n2 3\n2 5\n5\n3 5\n1 4\n2 6\n4 6\n5 6\n', 'expected': '9\n'}], 'abc191_c': [{'input': '5 5\n.....\n.###.\n.###.\n.###.\n.....\n', 'expected': '4\n'}], 'abc192_c': [{'input': '314 2\n', 'expected': '693\n'}, {'input': '1000000000 100\n', 'expected': '0\n'}, {'input': '6174 100000\n', 'expected': '6174\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
