"""ABC095–097 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc095_b','abc096_b','abc097_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc095_b':
        if len(lines)<3: raise ValueError('lines')
        first=lines[0].split(' ')
        if len(first)!=2 or any(POS.fullmatch(x) is None for x in first): raise ValueError('header')
        n,x=map(int,first)
        if not (2<=n<=100 and 1<=x<=10**5) or len(lines)!=n+1: raise ValueError('range/lines')
        m=[]
        for s in lines[1:]:
            if POS.fullmatch(s) is None: raise ValueError('mi')
            v=int(s)
            if not 1<=v<=1000: raise ValueError('mi range')
            m.append(v)
        if sum(m)>x: raise ValueError('insufficient powder')
        return n,x,m
    if pid=='abc096_b':
        if len(lines)!=2: raise ValueError('lines')
        first=lines[0].split(' ')
        if len(first)!=3 or any(POS.fullmatch(s) is None for s in first) or POS.fullmatch(lines[1]) is None:
            raise ValueError('format')
        a,b,c=map(int,first); k=int(lines[1])
        if not (1<=a<=50 and 1<=b<=50 and 1<=c<=50 and 1<=k<=10): raise ValueError('range')
        return a,b,c,k
    if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
    x=int(lines[0])
    if not 1<=x<=1000: raise ValueError('range')
    return x


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc095_b':
        n,x,m=value
        remain=x-sum(m); smallest=min(m); extra=0
        # Deliberately use repeated consumption rather than the reference formula.
        while remain>=smallest:
            remain-=smallest; extra+=1
        return output==str(n+extra)
    if pid=='abc096_b':
        a,b,c,k=value
        best=0
        # Enumerate how many doublings each original value receives.
        for ka in range(k+1):
            for kb in range(k-ka+1):
                kc=k-ka-kb
                total=a*(1<<ka)+b*(1<<kb)+c*(1<<kc)
                if total>best: best=total
        return output==str(best)
    x=value
    best=1
    for base in range(2, x+1):
        power=base*base
        if power>x: break
        while power<=x:
            if power>best: best=power
            power*=base
    return output==str(best)


def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc095_b':
        vals=[
            (2,2,[1,1]),(2,3,[1,2]),(2,2000,[1000,1000]),
            (3,1000,[120,100,140]),(4,360,[90,90,90,90]),
            (5,3000,[150,130,150,130,110]),(3,6,[1,2,3]),
            (3,100,[10,20,30]),(10,100,list(range(1,11))),
            (10,1000,[100]*10),(50,5000,[100]*50),(50,100000,[1000]*50),
            (99,99000,[1000]*99),(100,100,[1]*100),(100,1000,[1]*100),
            (100,100000,[1000]*100),(100,99999,[1]+[999]*99),
        ]
        for n,x,m in vals:
            raw=f'{n} {x}\n'+'\n'.join(map(str,m))+'\n'
            add('boundary' if n in (2,99,100) or x in (2,100000) else 'normal',raw)
        add('constraint_max','100 100000\n1\n'+'\n'.join(['1000']*99)+'\n')
    elif pid=='abc096_b':
        vals=[
            (1,1,1,1),(1,1,2,1),(5,3,11,1),(3,3,4,2),(50,1,1,1),
            (1,50,1,2),(1,1,50,3),(2,3,4,10),(50,49,48,1),(50,49,48,10),
            (25,25,25,5),(2,2,1,4),(7,8,9,2),(10,20,30,3),(30,20,10,3),
            (49,50,50,9),(50,50,49,10),
        ]
        for a,b,c,k in vals:
            add('boundary' if 1 in (a,b,c,k) or 50 in (a,b,c) or k==10 else 'normal',f'{a} {b} {c}\n{k}\n')
        add('constraint_max','50 50 50\n10\n')
    else:
        vals=[1,2,3,4,5,7,8,9,10,15,16,31,32,63,64,999,961]
        for x in vals:
            add('boundary' if x in (1,999) else 'normal',f'{x}\n')
        add('constraint_max','1000\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
