"""ABC161–163 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc161_b', 'abc162_b', 'abc163_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
SIGNED = re.compile(r'(?:-1|0|[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc161_b': [
        {'input':'4 1\n5 4 2 1\n','expected':'Yes\n'},
        {'input':'3 2\n380 19 1\n','expected':'No\n'},
        {'input':'12 3\n4 56 78 901 2 345 67 890 123 45 6 789\n','expected':'Yes\n'},
    ],
    'abc162_b': [
        {'input':'15\n','expected':'60\n'},
        {'input':'1000000\n','expected':'266666333332\n'},
    ],
    'abc163_b': [
        {'input':'41 2\n5 6\n','expected':'30\n'},
        {'input':'10 2\n5 6\n','expected':'-1\n'},
        {'input':'11 2\n5 6\n','expected':'0\n'},
        {'input':'314 15\n9 26 5 35 8 9 79 3 23 8 46 2 6 43 3\n','expected':'9\n'},
    ],
}


def _canon_parts(line: str, count: int, *, positive: bool = True) -> list[int]:
    parts = line.split(' ')
    pattern = POS if positive else NONNEG
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc161_b':
        if len(lines) != 2:
            raise ValueError('expected two rows')
        n, m = _canon_parts(lines[0], 2)
        if not (1 <= m <= n <= 100):
            raise ValueError('N/M range')
        a = _canon_parts(lines[1], n)
        if any(x > 1000 for x in a) or len(set(a)) != n:
            raise ValueError('vote range/distinctness')
        return n, m, a
    if pid == 'abc162_b':
        if len(lines) != 1 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected canonical N')
        n = int(lines[0])
        if not 1 <= n <= 10**6:
            raise ValueError('N range')
        return n
    if len(lines) != 2:
        raise ValueError('expected two rows')
    n, m = _canon_parts(lines[0], 2)
    if not (1 <= n <= 10**6 and 1 <= m <= 10**4):
        raise ValueError('N/M range')
    a = _canon_parts(lines[1], m)
    if any(x > 10**4 for x in a):
        raise ValueError('Ai range')
    return n, m, a


def _sum_multiples(n: int, k: int) -> int:
    q = n // k
    return k * q * (q + 1) // 2


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc161_b':
        if output not in ('Yes', 'No'):
            return False
        _, m, a = value
        total = sum(a)
        eligible = sum(4 * m * x >= total for x in a)
        return output == ('Yes' if eligible >= m else 'No')
    if pid == 'abc162_b':
        if NONNEG.fullmatch(output) is None:
            return False
        n = value
        expected = n * (n + 1) // 2 - _sum_multiples(n, 3) - _sum_multiples(n, 5) + _sum_multiples(n, 15)
        return output == str(expected)
    if SIGNED.fullmatch(output) is None:
        return False
    n, _, a = value
    used = sum(a)
    expected = n - used if used <= n else -1
    return output == str(expected)


def _161(n: int, m: int, a: list[int]) -> str:
    return f'{n} {m}\n' + ' '.join(map(str, a)) + '\n'


def _162(n: int) -> str:
    return f'{n}\n'


def _163(n: int, a: list[int]) -> str:
    return f'{n} {len(a)}\n' + ' '.join(map(str, a)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid == 'abc161_b':
        vals = [
            ('sample1',4,1,[5,4,2,1]),
            ('sample2',3,2,[380,19,1]),
            ('sample3',12,3,[4,56,78,901,2,345,67,890,123,45,6,789]),
            ('min',1,1,[1]),
            ('all_select_small_yes',2,2,[1,2]),
            ('all_select_skew_no',4,4,[1,2,3,100]),
            ('boundary_exact',10,2,[200,100,20,40,50,60,70,80,85,95]),
            ('boundary_below',10,2,[200,99,20,40,50,60,70,80,85,95]),
            ('boundary_above',10,2,[200,101,20,40,50,60,70,80,85,95]),
            ('m1_yes',4,1,[100,1,2,3]),
            ('m1_no',6,1,[10,9,8,7,6,5]),
            ('top_two_clear',5,2,[25,24,1,2,3]),
            ('middle_m',6,3,[40,30,20,4,3,2]),
            ('threshold_many',8,4,[40,39,38,37,4,3,2,1]),
            ('high_votes',5,2,[1000,999,500,499,1]),
            ('large_n_m1_no',100,1,list(range(1,101))),
            ('large_n_mid',100,50,list(range(1,101))),
        ]
        for cat,n,m,a in vals: add(cat,_161(n,m,a))
        add('constraint_max',_161(100,100,list(range(901,1001))))
    elif pid == 'abc162_b':
        vals = [
            ('sample1',15),('min',1),('before_three',2),('three',3),('four',4),('five',5),
            ('six',6),('before_fifteen',14),('after_fifteen',16),('before_thirty',29),('thirty',30),
            ('after_thirty',31),('ninety_nine',99),('hundred',100),('nine_ninety_nine',999),
            ('thousand',1000),('near_max',999999),
        ]
        for cat,n in vals: add(cat,_162(n))
        add('constraint_max',_162(10**6))
    else:
        vals = [
            ('sample1',41,[5,6]),
            ('sample2',10,[5,6]),
            ('sample3',11,[5,6]),
            ('sample4',314,[9,26,5,35,8,9,79,3,23,8,46,2,6,43,3]),
            ('min_exact',1,[1]),
            ('min_over',1,[2]),
            ('single_free',10,[1]),
            ('single_exact_large',10000,[10000]),
            ('single_over_large',9999,[10000]),
            ('two_free',10,[2,3]),
            ('two_exact',5,[2,3]),
            ('over_by_one',4,[2,3]),
            ('many_exact',100,[10]*10),
            ('many_free_one',101,[10]*10),
            ('large_exact',10**6,[10000]*100),
            ('large_over_one',999999,[10000]*100),
            ('max_m_small_work',10**6,[1]*10000),
        ]
        for cat,n,a in vals: add(cat,_163(n,a))
        add('constraint_max',_163(10**6,[10000]*10000))
    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
