"""Private reviewed ABC353..358 D tasks and independent exact oracles."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter
import heapq,random,re
from typing import cast

TASKS=tuple(f'abc{n}_d' for n in range(353,359))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
MOD=998244353
Case=dict[str,str];Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None,signed:bool=False)->tuple[int,...]:
 pattern=r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*' if signed else r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*'
 require(re.fullmatch(pattern,row) is not None,'integer fields');values=tuple(map(int,row.split()));require(count is None or len(values)==count,'field count');return values

def line(values:tuple[int,...]|list[int])->str:return ' '.join(map(str,values))+'\n'

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank rows')
 if pid=='abc353_d':
  n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==2,'N/rows');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'Ai');return (a,)
 if pid=='abc354_d':
  require(len(rows)==1,'rows');a,b,c,d=ints(rows[0],4,True);require(all(-10**9<=v<=10**9 for v in (a,b,c,d)) and a<c and b<d,'rectangle');return a,b,c,d
 if pid=='abc355_d':
  n=ints(rows[0],1)[0];require(2<=n<=500000 and len(rows)==n+1,'N/rows');intervals=tuple(ints(row,2) for row in rows[1:]);require(all(0<=l<r<=10**9 for l,r in intervals),'intervals');return (intervals,)
 if pid=='abc356_d':
  require(len(rows)==1,'rows');n,m=ints(rows[0],2);require(0<=n<1<<60 and 0<=m<1<<60,'N/M');return n,m
 if pid=='abc357_d':
  require(len(rows)==1,'rows');n=ints(rows[0],1)[0];require(1<=n<=10**18,'N');return (n,)
 n,m=ints(rows[0],2);require(1<=m<=n<=200000 and len(rows)==3,'N/M/rows');a=ints(rows[1],n);b=ints(rows[2],m);require(all(1<=v<=10**9 for v in a+b),'Ai/Bi');return a,b

def concatenation_suffix_powers(a:tuple[int,...])->int:
 suffix=sum(pow(10,len(str(v)),MOD) for v in a)%MOD;answer=0
 for i,value in enumerate(a):
  suffix=(suffix-pow(10,len(str(value)),MOD))%MOD;answer=(answer+value*suffix+i*value)%MOD
 return answer

def residue_population(start:int,end:int,residue:int,period:int)->int:
 return (end-1-residue)//period-(start-1-residue)//period

def cell_black_doubled(x:int,y:int)->int:
 # Two half-unit triangles represented by interior points (.25,.25), (.75,.75).
 # Crossing x=integer, y=even integer, or x+y=even integer toggles the color.
 return sum((x+y//2+(4*x+4*y+offset)//8)%2==0 for offset in (2,6))

def wallpaper_residue_triangles(a:int,b:int,c:int,d:int)->int:
 return sum(residue_population(a,c,x,4)*residue_population(b,d,y,2)*cell_black_doubled(x,y) for x in range(4) for y in range(2))

def interval_complement_pairs(intervals:tuple[tuple[int,...],...])->int:
 ends=sorted(r for _,r in intervals);disjoint=sum(bisect_left(ends,l) for l,_ in intervals);n=len(intervals);return n*(n-1)//2-disjoint

def masked_popcount_digit_dp(n:int,m:int)->int:
 # State is (number of prefixes, total selected ones), separated by tightness.
 states={True:(1,0)}
 for bit in range(59,-1,-1):
  nxt:dict[bool,tuple[int,int]]={};bound=n>>bit&1
  for tight,(count,total) in states.items():
   for value in range((bound if tight else 1)+1):
    key=tight and value==bound;old_count,old_sum=nxt.get(key,(0,0));nxt[key]=((old_count+count)%MOD,(old_sum+total+count*value*(m>>bit&1))%MOD)
  states=nxt
 return sum(total for _,total in states.values())%MOD

def repeated_block_monoid(n:int)->int:
 block=n%MOD;shift=pow(10,len(str(n)),MOD);result=0;remaining=n
 while remaining:
  if remaining&1:result=(result*shift+block)%MOD
  block=(block*shift+block)%MOD;shift=shift*shift%MOD;remaining//=2
 return result

def boxes_descending_heap(a:tuple[int,...],b:tuple[int,...])->int:
 boxes=sorted(a,reverse=True);requirements=sorted(b,reverse=True);index=0;available:list[int]=[];cost=0
 for need in requirements:
  while index<len(boxes) and boxes[index]>=need:heapq.heappush(available,boxes[index]);index+=1
  if not available:return -1
  cost+=heapq.heappop(available)
 return cost

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc353_d':answer=concatenation_suffix_powers(cast(tuple[int,...],d[0]))
 elif pid=='abc354_d':answer=wallpaper_residue_triangles(*cast(tuple[int,int,int,int],d))
 elif pid=='abc355_d':answer=interval_complement_pairs(cast(tuple[tuple[int,...],...],d[0]))
 elif pid=='abc356_d':answer=masked_popcount_digit_dp(*cast(tuple[int,int],d))
 elif pid=='abc357_d':answer=repeated_block_monoid(cast(int,d[0]))
 else:answer=boxes_descending_heap(cast(tuple[int,...],d[0]),cast(tuple[int,...],d[1]))
 return str(answer)+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  if re.fullmatch(r'-?(?:0|[1-9][0-9]*)\n?',actual) is None:return False
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={
'abc353_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);prefix=0;answer=0;mod=998244353
for i,v in enumerate(it):
 answer=(answer+prefix*pow(10,len(str(v)),mod)+i*v)%mod;prefix=(prefix+v)%mod
print(answer)
''',
'abc354_d':'''a,b,c,d=map(int,input().split());weights=((2,1,0,1),(1,2,1,0))
def pref(x,y):
 qx,rx=divmod(x,4);qy,ry=divmod(y,2)
 total=8*qx*qy
 total+=qx*sum(sum(weights[r]) for r in range(ry))
 total+=qy*sum(weights[r][col] for r in range(2) for col in range(rx))
 total+=sum(weights[r][col] for r in range(ry) for col in range(rx))
 return total
print(pref(c,d)-pref(a,d)-pref(c,b)+pref(a,b))
''',
'abc355_d':'''import heapq,sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);segments=sorted(zip(it,it));active=[];answer=0
for l,r in segments:
 while active and active[0]<l:heapq.heappop(active)
 answer+=len(active);heapq.heappush(active,r)
print(answer)
''',
'abc356_d':'''n,m=map(int,input().split());answer=0;mod=998244353
for bit in range(60):
 if m>>bit&1:
  half=1<<bit;period=half*2;full,remainder=divmod(n+1,period);answer+=full*half+max(0,remainder-half)
print(answer%mod)
''',
'abc357_d':'''n=int(input());mod=998244353;r=pow(10,len(str(n)),mod)
if r==1:print(n*n%mod)
else:print(n%mod*(pow(r,n,mod)-1)*pow(r-1,mod-2,mod)%mod)
''',
'abc358_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);a=sorted(next(it) for _ in range(n));b=sorted(it);i=0;answer=0
for need in b:
 while i<n and a[i]<need:i+=1
 if i==n:print(-1);break
 answer+=a[i];i+=1
else:print(answer)
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(198000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc353_d':
  arrays=[(1,1),(1,10**9),(10**9,1),(9,10,99,100),(1,2,3,4),(10**9,10**9)]
  arrays += [tuple(rng.randint(1,10**9) for _ in range(n)) for n in range(3,13)]
  arrays += [tuple(10**(i%10) for i in range(200000)),(10**9,)*200000];raws=[line((len(a),))+line(a) for a in arrays]
 elif pid=='abc354_d':
  rects=[(0,0,1,1),(-1,-1,0,0),(1,0,2,1),(2,0,3,1),(3,0,4,1),(0,1,1,2),(1,1,2,2),(-5,-3,-1,-1)]
  for i in range(8):a=rng.randint(-100,100);b=rng.randint(-100,100);rects.append((a,b,a+rng.randint(1,30),b+rng.randint(1,30)))
  rects += [(-10**9+1,-10**9+1,10**9-1,10**9-1),(-10**9,-10**9,10**9,10**9)];raws=[line(v) for v in rects]
 elif pid=='abc355_d':
  configurations=[((0,1),(0,1)),((0,1),(1,2)),((0,1),(2,3)),((0,10**9),(0,10**9)),((0,3),(1,2),(2,4)),((999999999,10**9),(0,10**9))]
  for n in range(3,13):
   intervals=[]
   for _ in range(n):l=rng.randint(0,999999999);r=rng.randint(l+1,10**9);intervals.append((l,r))
   configurations.append(tuple(intervals))
  configurations += [tuple((2*i,2*i+1) for i in range(500000)),((0,10**9),)*500000];raws=[line((len(a),))+''.join(line(v) for v in a) for a in configurations]
 elif pid=='abc356_d':
  pairs=[(0,0),(0,(1<<60)-1),(1,0),(1,1),(2,1),(3,2),(7,7),(8,15),(15,8),(1<<59,1<<59)]
  pairs += [(rng.randrange(1<<60),rng.randrange(1<<60)) for _ in range(6)]
  pairs += [((1<<60)-2,(1<<60)-1),((1<<60)-1,(1<<60)-1)];raws=[line(v) for v in pairs]
 elif pid=='abc357_d':
  values=[1,2,9,10,11,99,100,998244353,998244352,10**9,10**9+1,10**10,10**12,10**15,10**17,10**18-2,10**18-1,10**18];raws=[line((n,)) for n in values]
 else:
  configurations=[((1,),(1,)),((1,),(2,)),((10**9,),(10**9,)),((1,1),(1,1)),((1,2),(2,2)),((1,2,3),(2,)),((2,3,3,4),(3,3,2))]
  for n in range(4,13):configurations.append((tuple(rng.randint(1,10**9) for _ in range(n)),tuple(rng.randint(1,10**9) for _ in range(n-2))))
  configurations += [((1,)*200000,(10**9,)*200000),((10**9,)*200000,(10**9,)*200000)];raws=[line((len(a),len(b)))+line(a)+line(b) for a,b in configurations]
 require(len(raws)==len(set(raws))==18,'18 distinct');result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result

HINTS:dict[str,tuple[str,str,str]]={
'abc353_d':('連結は、先の数に後の数の桁数だけ10を掛けてから足す操作です。','右側の数を順に固定します。それより前の数の総和と、前にある個数が分かれば全ペアをまとめて加算できます。','疑似コード: prefix=answer=0; A[j] ごとに answer+=(prefix*10^digits(A[j])+j*A[j]); prefix+=A[j]; 各値を998244353で剰余化。'),
'abc354_d':('模様は横4、縦2の周期を持ちます。負座標でも同じ周期で考えられます。','単位マスの黒面積の2倍は下の行が [2,1,0,1]、次の行が [1,2,1,0] です。原点からの累積値を商と余りで計算します。','疑似コード: F(x,y) は floor(x/4),x mod4,floor(y/2),y mod2 で全周期と残りの行列を加算; answer=F(C,D)-F(A,D)-F(C,B)+F(A,B); 負数も床除算を使う。'),
'abc355_d':('左端の小さい順に区間を見ます。新しい区間と重なる、既に見た区間の数を数えます。','右端を最小ヒープに持ち、右端が今の左端より小さい区間だけ取り除きます。等しい場合は端点で接しているので残します。','疑似コード: intervalsを左端順にsort; heap空,answer=0; (l,r)ごとに heap.min<l の間pop; answer+=heap.size; heapへrをpush。'),
'abc356_d':('AND後の各ビットの寄与を別々に数え、足し合わせられます。','Mのビットが1の位置だけ調べます。kのそのビットは、長さ2^(b+1)の周期の後半だけ1です。','疑似コード: 各b=0..59で Mのbビットが1なら h=2^b; q,r=divmod(N+1,2h); answer+=q*h+max(0,r-h); 最後に998244353の剰余。'),
'abc357_d':('Nの桁数をdとすると、連結で左へずれる倍率は10^dです。','N個の連結は N*(1+r+...+r^(N-1)) です。等比数列を剰余で求めると、巨大な整数を作らず計算できます。','疑似コード: r=10^digits(N) modP; r==1なら N*N modP; それ以外は N*(r^N-1)*inverse(r-1) modP; P=998244353、逆元はpow(r-1,P-2,P)。'),
'abc358_d':('必要なお菓子の数と箱の数を小さい順に並べます。','最も要求の小さい人へ、まだ使っていない最も安い適格な箱を渡します。安すぎて不足する箱は以後の人にも使えません。','疑似コード: A,Bをsort; i=cost=0; Bのneedごとに A[i]<need の間i++; i==Nなら-1; それ以外はcost+=A[i],i++; 最後にcostを出力。')}

TITLES={'abc353_d': 'Another Sigma Problem', 'abc354_d': 'AtCoder Wallpaper', 'abc355_d': 'Intersecting Intervals', 'abc356_d': 'Masked Popcount', 'abc357_d': '88888888', 'abc358_d': 'Souvenirs'}
PUBLISHED_SAMPLES={'abc353_d': [{'input': '3\n3 14 15\n', 'expected': '2044\n'}, {'input': '5\n1001 5 1000000 1000000000 100000\n', 'expected': '625549048\n'}], 'abc354_d': [{'input': '0 0 3 3\n', 'expected': '10\n'}, {'input': '-1 -2 1 3\n', 'expected': '11\n'}, {'input': '-1000000000 -1000000000 1000000000 1000000000\n', 'expected': '4000000000000000000\n'}], 'abc355_d': [{'input': '3\n1 5\n7 8\n3 7\n', 'expected': '2\n'}, {'input': '3\n3 4\n2 5\n1 6\n', 'expected': '3\n'}, {'input': '2\n1 2\n3 4\n', 'expected': '0\n'}], 'abc356_d': [{'input': '4 3\n', 'expected': '4\n'}, {'input': '0 0\n', 'expected': '0\n'}, {'input': '1152921504606846975 1152921504606846975\n', 'expected': '499791890\n'}], 'abc357_d': [{'input': '5\n', 'expected': '55555\n'}, {'input': '9\n', 'expected': '1755646\n'}, {'input': '10000000000\n', 'expected': '468086693\n'}], 'abc358_d': [{'input': '4 2\n3 4 5 4\n1 4\n', 'expected': '7\n'}, {'input': '3 3\n1 1 1\n1000000000 1000000000 1000000000\n', 'expected': '-1\n'}, {'input': '7 3\n2 6 8 9 5 1 11\n3 5 7\n', 'expected': '19\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
