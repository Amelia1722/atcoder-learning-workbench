"""Collect the three independently authored six-problem hint groups."""
from __future__ import annotations
from .reference_tasks_reviewed_c_v176 import PARTS

HINTS_V176: dict[str,tuple[str,str,str]] = {
    pid:part.HINTS[pid] for part in PARTS for pid in part.TASKS
}
