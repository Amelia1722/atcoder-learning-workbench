"""ABC146–148 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc146_b', 'abc147_b', 'abc148_b')
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
UPPER = re.compile(r'[A-Z]+', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc146_b': [
        {'input':'2\nABCXYZ\n','expected':'CDEZAB\n'},
        {'input':'0\nABCXYZ\n','expected':'ABCXYZ\n'},
        {'input':'13\nABCDEFGHIJKLMNOPQRSTUVWXYZ\n','expected':'NOPQRSTUVWXYZABCDEFGHIJKLM\n'},
    ],
    'abc147_b': [
        {'input':'redcoder\n','expected':'1\n'},
        {'input':'vvvvvv\n','expected':'0\n'},
        {'input':'abcdabc\n','expected':'2\n'},
    ],
    'abc148_b': [
        {'input':'2\nip cc\n','expected':'icpc\n'},
        {'input':'8\nhmhmnknk uuuuuuuu\n','expected':'humuhumunukunuku\n'},
        {'input':'5\naaaaa aaaaa\n','expected':'aaaaaaaaaa\n'},
    ],
}

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc146_b':
        if len(lines) != 2 or NONNEG.fullmatch(lines[0]) is None or UPPER.fullmatch(lines[1]) is None:
            raise ValueError('expected N and uppercase S')
        n=int(lines[0]); s=lines[1]
        if not 0 <= n <= 26 or not 1 <= len(s) <= 10_000:
            raise ValueError('N/S range')
        return n,s
    if pid == 'abc147_b':
        if len(lines) != 1 or LOWER.fullmatch(lines[0]) is None or not 1 <= len(lines[0]) <= 100:
            raise ValueError('expected lowercase S length 1..100')
        return lines[0]
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('expected N and S T row')
    n=int(lines[0]); parts=lines[1].split(' ')
    if not 1 <= n <= 100 or len(parts) != 2 or any(LOWER.fullmatch(x) is None or len(x)!=n for x in parts):
        raise ValueError('N/S/T shape or range')
    return n,parts[0],parts[1]

def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value=validate(pid, raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or output != output.strip() or not output:
        return False
    if pid == 'abc146_b':
        n,s=value
        expected=''.join(chr((ord(c)-65+n)%26+65) for c in s)
        return output == expected
    if pid == 'abc147_b':
        if NONNEG.fullmatch(output) is None: return False
        s=value
        return output == str(sum(a!=b for a,b in zip(s,s[::-1]))//2)
    n,s,t=value
    expected=''.join(a+b for a,b in zip(s,t))
    return output == expected

def _abc146(n:int,s:str)->str: return f'{n}\n{s}\n'
def _abc148(s:str,t:str)->str: return f'{len(s)}\n{s} {t}\n'

def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc146_b':
        vals=[
            ('sample1',2,'ABCXYZ'),('sample2',0,'ABCXYZ'),('sample3',13,'ABCDEFGHIJKLMNOPQRSTUVWXYZ'),
            ('min_len_zero',0,'A'),('min_len_one',1,'A'),('wrap_one',1,'Z'),('wrap_two',2,'YZ'),
            ('shift26',26,'AZBY'),('shift25',25,'ABC'),('all_z',7,'ZZZZZ'),('mixed',5,'HELLOWORLD'),
            ('reverse_alpha',3,'ZYXWVUTSRQPONMLKJIHGFEDCBA'),('n12',12,'ATCODER'),('n14',14,'ROTATION'),
            ('len100',9,'ABCDEFGHIJKLMNOPQRSTUVWXYZ'*3+'ABCDEFGHIJKLMNOPQRSTUV'),
            ('len999',4,('AZ'*500)[:-1]),('len9999',17,('ABC'*3333)),
        ]
        for cat,n,s in vals: add(cat,_abc146(n,s))
        add('constraint_max',_abc146(26,'Z'*10000))
    elif pid=='abc147_b':
        vals=[
            ('sample1','redcoder'),('sample2','vvvvvv'),('sample3','abcdabc'),
            ('min','a'),('two_same','aa'),('two_diff','ab'),('odd_pal','abcba'),('odd_one_mismatch','abcaa'),
            ('even_pal','abccba'),('even_all_mismatch','abcdef'),('alternating','abababab'),('all_same_99','z'*99),
            ('one_edge_diff','a'+'b'*98+'c'),('half_half','a'*50+'b'*50),('near_pal_98','a'*48+'bc'+'cb'+'a'*46),
            ('len99_pattern',('abc'*33)),('len100_pal','a'*50+'a'*50),
        ]
        for cat,s in vals: add(cat,s+'\n')
        add('constraint_max',('z'*100)+'\n')
    else:
        vals=[
            ('sample1','ip','cc'),('sample2','hmhmnknk','uuuuuuuu'),('sample3','aaaaa','aaaaa'),
            ('min','a','z'),('two','ab','cd'),('same','xyz','xyz'),('opposite','abc','zyx'),('len10','abcdefghij','jihgfedcba'),
            ('all_a_b','a'*20,'b'*20),('alternating','ab'*15,'ba'*15),('alphabet26','abcdefghijklmnopqrstuvwxyz','zyxwvutsrqponmlkjihgfedcba'),
            ('len50','a'*50,'z'*50),('len75','abc'*25,'xyz'*25),('len98','m'*98,'n'*98),('len99','p'*99,'q'*99),
            ('mixed99',('abc'*33),('xyz'*33)),('mixed100',('abcd'*25),('wxyz'*25)),
        ]
        for cat,s,t in vals: add(cat,_abc148(s,t))
        add('constraint_max',_abc148('a'*100,'z'*100))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
