"""ABC117–120 A/B — task-specific validators, generators, independent oracles.

The eight input contracts and official samples are curated from AtCoder task pages.
"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from math import gcd, isclose
from random import Random
import re

SAMPLES = {
    'abc117_a': ('8 3\n', '2.6666666667', '1<=T,X<=100; absolute or relative error <=1e-3'),
    'abc117_b': ('4\n3 8 5 1\n', 'Yes', '3<=N<=10; 1<=Li<=100'),
    'abc118_a': ('4 12\n', '16', '1<=A<=B<=20'),
    'abc118_b': ('3 4\n2 1 3\n3 1 2 3\n2 3 2\n', '1', '1<=N,M<=30; 1<=Ki<=M; 1<=Aij<=M; each row distinct'),
    'abc119_a': ('2019/04/30\n', 'Heisei', 'S is a valid date in 2019 formatted yyyy/mm/dd'),
    'abc119_b': ('2\n10000 JPY\n0.10000000 BTC\n', '48000.0', '2<=N<=10; JPY integer 1..1e8; BTC 8 decimal places 0.00000001..100.00000000; error<=1e-5'),
    'abc120_a': ('2 11 4\n', '4', '1<=A,B,C<=100'),
    'abc120_b': ('8 12 2\n', '2', '1<=A,B<=100; K>=1; K-th common divisor exists'),
}
BATCH12 = {pid: {'sample_input': inp, 'sample_output': out,
                   'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                   'constraints': cons} for pid, (inp, out, cons) in SAMPLES.items()}
_INT = re.compile(r'[0-9]+\Z')
_BTC = re.compile(r'(?:0|[1-9][0-9]{0,2})\.[0-9]{8}\Z')


def _ints(data: str, count: int | None = None) -> list[int]:
    fields = data.split()
    if not fields or (count is not None and len(fields) != count) or any(_INT.fullmatch(x) is None for x in fields):
        raise ValueError('unexpected integer input shape')
    return list(map(int, fields))


def validate(pid: str, data: str):
    if pid not in BATCH12:
        raise ValueError('unknown task')
    if pid == 'abc119_a':
        fields = data.split()
        if len(fields) != 1 or re.fullmatch(r'2019/[0-9]{2}/[0-9]{2}', fields[0]) is None:
            raise ValueError('yyyy/mm/dd required')
        try:
            d = date.fromisoformat(fields[0].replace('/', '-'))
        except ValueError as exc:
            raise ValueError('invalid calendar date') from exc
        if d.year != 2019:
            raise ValueError('year 2019 required')
        return d
    if pid == 'abc119_b':
        lines = data.strip().splitlines()
        if not lines or _INT.fullmatch(lines[0].strip()) is None:
            raise ValueError('N required')
        n = int(lines[0])
        if not 2 <= n <= 10 or len(lines) != n + 1:
            raise ValueError('N/record count out of range')
        records = []
        for line in lines[1:]:
            pair = line.split()
            if len(pair) != 2 or pair[1] not in ('JPY', 'BTC'):
                raise ValueError('amount and JPY/BTC required')
            raw, unit = pair
            if unit == 'JPY':
                if _INT.fullmatch(raw) is None or not 1 <= int(raw) <= 100_000_000:
                    raise ValueError('JPY integer bound')
            else:
                if _BTC.fullmatch(raw) is None:
                    raise ValueError('BTC must have exactly eight decimal places')
                try:
                    amount = Decimal(raw)
                except InvalidOperation as exc:
                    raise ValueError('invalid BTC') from exc
                if not Decimal('0.00000001') <= amount <= Decimal('100.00000000'):
                    raise ValueError('BTC bound')
            records.append((Decimal(raw), unit))
        return records
    if pid == 'abc118_b':
        rows = data.strip().splitlines()
        if not rows:
            raise ValueError('empty input')
        n, m = _ints(rows[0], 2)
        if not (1 <= n <= 30 and 1 <= m <= 30 and len(rows) == n + 1):
            raise ValueError('N/M/row count out of range')
        foods = []
        for row in rows[1:]:
            z = _ints(row)
            if not (1 <= z[0] <= m and len(z) == z[0] + 1 and
                    all(1 <= v <= m for v in z[1:]) and len(set(z[1:])) == z[0]):
                raise ValueError('food row count, range or uniqueness violation')
            foods.append(z[1:])
        return n, m, foods
    if pid == 'abc117_b':
        lines = data.strip().splitlines()
        if len(lines) != 2:
            raise ValueError('N followed by exactly one row')
        n = _ints(lines[0], 1)[0]
        sides = _ints(lines[1])
        if not 3 <= n <= 10 or len(sides) != n or any(not 1 <= x <= 100 for x in sides):
            raise ValueError('polygon bounds/count')
        return sides
    z = _ints(data, {'abc117_a': 2, 'abc118_a': 2, 'abc120_a': 3, 'abc120_b': 3}[pid])
    if pid == 'abc117_a':
        if any(not 1 <= x <= 100 for x in z):
            raise ValueError('T/X bounds')
    elif pid == 'abc118_a':
        if not 1 <= z[0] <= z[1] <= 20:
            raise ValueError('A/B ordering and bounds')
    elif pid == 'abc120_a':
        if any(not 1 <= x <= 100 for x in z):
            raise ValueError('A/B/C bounds')
    else:
        a,b,k=z
        if not (1 <= a <= 100 and 1 <= b <= 100 and 1 <= k <= sum(a % i == b % i == 0 for i in range(1,min(a,b)+1))):
            raise ValueError('K-th common divisor must exist')
    return tuple(z)


def generate(pid: str, count: int, seed: int, include_large: bool):
    if pid not in BATCH12 or not 1 <= count <= 80:
        raise ValueError('id/count invalid')
    rng = Random(seed)
    cases = []
    seen = set()
    def add(category: str, inp: str):
        validate(pid, inp)
        if inp not in seen:
            seen.add(inp)
            cases.append({'category': category, 'input': inp})
    def nums(category, *z): add(category, ' '.join(map(str,z)) + '\n')
    def sides(category, x): add(category, f'{len(x)}\n' + ' '.join(map(str,x)) + '\n')
    def foods(category, m, rows):
        add(category, f'{len(rows)} {m}\n' + '\n'.join(f'{len(r)} ' + ' '.join(map(str,r)) for r in rows) + '\n')
    def gifts(category, rows): add(category, f'{len(rows)}\n' + '\n'.join(f'{amount} {unit}' for amount,unit in rows) + '\n')
    if pid == 'abc117_a':
        for t,x in ((1,1),(1,100),(100,1),(100,100),(8,3),(99,1),(1,3),(2,3),(99,100),(100,99),(33,33),(59,77)):
            nums('boundary',t,x)
        while len(cases) < count: nums('random',rng.randint(1,100),rng.randint(1,100))
        maximum='100 100\n'
    elif pid == 'abc117_b':
        for a in ([1,1,1],[1,1,2],[1,1,3],[2,2,3],[3,8,5,1],[3,8,4,1],
                  [100,100,100],[100,1,1],[100]*10,[1]*10,[100]+[1]*9,[9,10,20],
                  [99,100,100]):
            sides('boundary',a)
        while len(cases)<count: sides('random',[rng.randint(1,100) for _ in range(rng.randint(3,10))])
        maximum='10\n'+' '.join(['100']*10)+'\n'
    elif pid == 'abc118_a':
        for a,b in ((1,1),(1,20),(20,20),(19,20),(4,12),(8,20),(3,9),(3,10),(10,20),(2,19),(7,14),(20,20)):
            nums('boundary',a,b)
        while len(cases)<count:
            a=rng.randint(1,20);nums('random',a,rng.randint(a,20))
        maximum='20 20\n'
    elif pid == 'abc118_b':
        foods('sample',4,[[1,3],[1,2,3],[3,2]])
        foods('constraint_min',1,[[1]])
        foods('one_person_all',30,[list(range(1,31))])
        foods('one_person_one',30,[[30]])
        foods('all_shared',3,[[1,2,3]]*3)
        foods('none_shared',3,[[1],[2],[3]])
        foods('one_shared',3,[[1,3],[2,3],[3]])
        foods('all_max',30,[list(range(1,31))]*30)
        foods('none_max',30,[[i] for i in range(1,31)])
        foods('minimum_m_many',1,[[1]]*30)
        while len(cases)<count:
            m=rng.randint(1,30);n=rng.randint(1,30)
            foods('random',m,[rng.sample(range(1,m+1),rng.randint(1,m)) for _ in range(n)])
        maximum='30 30\n'+('\n'.join(['30 '+' '.join(map(str,range(1,31)))]*30))+'\n'
    elif pid == 'abc119_a':
        for s in ('2019/01/01','2019/02/28','2019/03/31','2019/04/01','2019/04/29','2019/04/30',
                  '2019/05/01','2019/05/02','2019/06/30','2019/10/01','2019/11/01','2019/12/30'):
            add('boundary',s+'\n')
        while len(cases)<count:
            day=date(2019,1,1)+timedelta(days=rng.randrange(365))
            add('random',day.strftime('%Y/%m/%d')+'\n')
        maximum='2019/12/31\n'
    elif pid == 'abc119_b':
        min_btc='0.00000001'; max_btc='100.00000000'
        gifts('sample',[('10000','JPY'),('0.10000000','BTC')])
        gifts('constraint_min',[('1','JPY'),(min_btc,'BTC')])
        gifts('two_jpy',[('1','JPY'),('100000000','JPY')])
        gifts('two_btc',[(min_btc,'BTC'),(max_btc,'BTC')])
        gifts('many_btc',[(max_btc,'BTC')]*10)
        gifts('many_jpy',[('100000000','JPY')]*10)
        gifts('alternating',[(max_btc,'BTC') if i%2 else ('100000000','JPY') for i in range(10)])
        gifts('small_fraction',[(min_btc,'BTC')]*10)
        gifts('sample2',[('100000000','JPY'),(max_btc,'BTC'),(min_btc,'BTC')])
        while len(cases)<count:
            rows=[]
            for _ in range(rng.randint(2,10)):
                if rng.randrange(2): rows.append((str(rng.randint(1,100_000_000)),'JPY'))
                else:
                    units=rng.randint(1,10_000_000_000)
                    whole,fraction=divmod(units,100_000_000)
                    rows.append((f'{whole}.{fraction:08d}','BTC'))
            gifts('random',rows)
        maximum='10\n'+'\n'.join([f'{max_btc} BTC']*10)+'\n'
    elif pid == 'abc120_a':
        for a,b,c in ((1,1,1),(100,1,100),(1,100,100),(100,100,100),(2,11,4),
                      (3,9,5),(100,1,10),(1,100,1),(7,7,1),(7,6,8),(10,99,9),(10,100,10)):
            nums('boundary',a,b,c)
        while len(cases)<count: nums('random',rng.randint(1,100),rng.randint(1,100),rng.randint(1,100))
        maximum='100 100 100\n'
    else:
        for a,b,k in ((1,1,1),(100,100,1),(100,100,9),(8,12,2),(100,50,4),
                      (99,100,1),(36,48,1),(36,48,3),(60,90,8),(12,12,6),
                      (72,72,12),(2,3,1)):
            nums('boundary',a,b,k)
        while len(cases)<count:
            a,b=rng.randint(1,100),rng.randint(1,100)
            common=[d for d in range(1,min(a,b)+1) if a%d==b%d==0]
            nums('random',a,b,rng.randint(1,len(common)))
        maximum='100 100 9\n'
    if include_large:
        validate(pid,maximum)
        cases=[c for c in cases if c['input']!=maximum][:count]
        cases.append({'category':'constraint_max','input':maximum})
    else:
        cases=cases[:count]
    return cases


def independent_check(pid: str, data: str, expected: str) -> bool:
    value = validate(pid,data)
    if pid == 'abc117_a':
        t,x=value
        try:
            actual=float(expected)
            return isclose(actual,t/x,rel_tol=1e-9,abs_tol=1e-9)
        except ValueError: return False
    if pid == 'abc119_b':
        truth=sum((v if unit=='JPY' else v*Decimal(380000) for v,unit in value),Decimal(0))
        try:
            return abs(Decimal(expected.strip())-truth)<=Decimal('0.00001')
        except InvalidOperation: return False
    if pid == 'abc117_b':
        sides=sorted(value)
        ans='Yes' if sides[-1]<sum(sides[:-1]) else 'No'
    elif pid == 'abc118_a':
        a,b=value
        ans=b+a if b//a*a==b else b-a
    elif pid == 'abc118_b':
        n,m,foods=value
        ans=sum(all(food in person for person in foods) for food in range(1,m+1))
    elif pid == 'abc119_a':
        ans='Heisei' if value <= date(2019,4,30) else 'TBD'
    elif pid == 'abc120_a':
        a,b,c=value
        ans=sum(a*i<=b for i in range(1,c+1))
    else:
        a,b,k=value
        common=[i for i in range(1,min(a,b)+1) if a%i==0 and b%i==0]
        ans=common[-k]
    return str(ans)==expected.strip()
