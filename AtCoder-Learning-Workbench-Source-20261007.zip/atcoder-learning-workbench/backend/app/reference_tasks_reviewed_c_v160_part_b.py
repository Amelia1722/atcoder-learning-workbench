"""Reviewed ABC106--111 C, independent contracts and original input domains."""
from __future__ import annotations
from typing import cast
import random
import re

TASKS=('abc106_c','arc101_a','arc102_a','abc109_c','abc110_c','arc103_a')
CONTESTS=dict(zip(TASKS,(f'abc{n}' for n in range(106,112)),strict=True))
NUMBERS=dict(zip(TASKS,range(106,112),strict=True))
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    result=tuple(map(int,row.split(' ')));require(count is None or len(result)==count,'field count');return result

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank line');number=NUMBERS[pid]
    if number==106:
        require(len(rows)==2 and re.fullmatch('[1-9]{1,100}',rows[0]) is not None,'digits');k=ints(rows[1],1)[0];require(1<=k<=10**18,'rank');require(set(rows[0])!={'1'} or k<=len(rows[0]),'expanded length');return rows[0],k
    if number==108:
        require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=200000,'limits');return n,k
    if number==110:
        require(len(rows)==2 and 1<=len(rows[0])<=200000 and len(rows[0])==len(rows[1]) and all(re.fullmatch('[a-z]+',r) is not None for r in rows),'strings');return rows[0],rows[1]
    if number in (107,109):
        n,k=ints(rows[0],2);require(1<=n<=100000 and len(rows)==2,'shape');xs=ints(rows[1],n)
        if number==107:require(1<=k<=n and all(-10**8<=x<=10**8 for x in xs) and all(a<b for a,b in zip(xs,xs[1:])),'candles')
        else:require(1<=k<=10**9 and all(1<=x<=10**9 and x!=k for x in xs) and len(set(xs))==n,'cities')
        return k,xs
    n=ints(rows[0],1)[0];require(2<=n<=100000 and n%2==0 and len(rows)==2,'shape');vs=ints(rows[1],n);require(all(1<=v<=100000 for v in vs),'values');return (vs,)

def _saturated_power(base:int,exponent:int,cap:int)->int:
    value=1
    while exponent:
        if exponent&1:value=min(cap,value*base)
        base=min(cap,base*base);exponent//=2
    return value

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=NUMBERS[pid]
    if number==106:
        s,k=cast(tuple[str,int],data);prefix=0
        for digit in s:
            prefix+=_saturated_power(int(digit),5*10**15,k)
            if prefix>=k:return digit
        raise ValueError('rank not found')
    if number==107:
        k,xs=cast(tuple[int,tuple[int,...]],data);negative=sorted(-x for x in xs if x<0);positive=sorted(x for x in xs if x>0);zero=int(0 in xs);need=max(0,k-zero);best=10**18
        for left_count in range(max(0,need-len(positive)),min(need,len(negative))+1):
            right_count=need-left_count;left=negative[left_count-1] if left_count else 0;right=positive[right_count-1] if right_count else 0
            best=min(best,left+right+min(left,right))
        return str(best)
    if number==108:
        n,k=cast(tuple[int,int],data);answer=0
        for residue in range(k):
            # a+b=b+c=c+a=0 mod K implies a=b=c and 2a=0.
            if 2*residue%k==0:
                count=(n-residue)//k+1 if residue else n//k
                answer+=max(count,0)**3
        return str(answer)
    if number==109:
        start,xs=cast(tuple[int,tuple[int,...]],data);distances=tuple(abs(x-start) for x in xs);remaining=min(distances);prime=2;answer=1
        while prime*prime<=remaining:
            if remaining%prime==0:
                power=1
                while remaining%prime==0:remaining//=prime;power*=prime
                while not all(d%power==0 for d in distances):power//=prime
                answer*=power
            prime+=1
        if remaining>1 and all(d%remaining==0 for d in distances):answer*=remaining
        return str(answer)
    if number==110:
        s,t=cast(tuple[str,str],data)
        def pattern(text:str)->tuple[int,...]:
            first:dict[str,int]={};return tuple(first.setdefault(c,j) for j,c in enumerate(text))
        return 'Yes' if pattern(s)==pattern(t) else 'No'
    vs=cast(tuple[int,...],data[0]);evens=[0]*100002;odds=[0]*100002
    for j,v in enumerate(vs):(evens if j%2==0 else odds)[v]+=1
    prefix=[0]*100003;suffix=[0]*100003
    for v in range(1,100002):prefix[v+1]=max(prefix[v],odds[v])
    for v in range(100001,0,-1):suffix[v]=max(suffix[v+1],odds[v])
    kept=max(evens[v]+max(prefix[v],suffix[v+1]) for v in range(1,100002));return str(len(vs)-kept)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc106_c':"s=input();k=int(input());answer='1'\nfor j,c in enumerate(s,1):\n if j>k:break\n if c!='1':answer=c;break\nprint(answer)\n",
'arc101_a':"n,k=map(int,input().split());x=list(map(int,input().split()));print(min(min(abs(x[i])*2+abs(x[i+k-1]),abs(x[i])+abs(x[i+k-1])*2) if x[i]<0<x[i+k-1] else max(abs(x[i]),abs(x[i+k-1])) for i in range(n-k+1)))\n",
'arc102_a':"n,k=map(int,input().split());answer=(n//k)**3\nif k%2==0:answer+=((n+k//2)//k)**3\nprint(answer)\n",
'abc109_c':"from math import gcd\nn,x=map(int,input().split());a=list(map(int,input().split()));d=0\nfor v in a:d=gcd(d,abs(v-x))\nprint(d)\n",
'abc110_c':"s=input();t=input();forward={};backward={};ok=True\nfor a,b in zip(s,t):\n if (a in forward and forward[a]!=b) or (b in backward and backward[b]!=a):ok=False\n forward[a]=b;backward[b]=a\nprint('Yes' if ok else 'No')\n",
'arc103_a':"from collections import Counter\nn=int(input());v=list(map(int,input().split()));a=Counter(v[::2]).most_common(2)+[(0,0)];b=Counter(v[1::2]).most_common(2)+[(-1,0)];print(n-max(c+d for x,c in a[:2] for y,d in b[:2] if x!=y))\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    number=NUMBERS[pid];rng=random.Random(16000+number);raws:list[str]=[]
    if number==106:
        pairs=[('1',1),('2',1),('111',3),('1112',3),('1112',4),('1112',10**18),('91',1),('19',2),('1214',4),('123456789',100),('1'*99+'2',99),('1'*99+'2',100),('1'*99+'2',101),('1'*99+'9',10**18),('987654321',9999),('1111113',7),('1'*100,100),('9'*100,10**18)]
        raws=[f'{s}\n{k}\n' for s,k in pairs]
    elif number==107:
        def candles(k:int,x:list[int])->str:return f'{len(x)} {k}\n'+line(x)
        raws=[candles(1,[0]),candles(1,[-10**8]),candles(1,[10**8]),candles(2,[-1,1]),candles(2,[-2,0,5]),candles(2,[-5,0,2])]+[candles(1+j%(j+4),sorted(rng.sample(range(-100,101),j+4))) for j in range(1,11)]+[candles(99999,[-10**8]+list(range(99998))+[10**8]),candles(100000,[-10**8]+list(range(99998))+[10**8])]
    elif number==108:raws=[line(pair) for pair in ((1,1),(1,2),(1,3),(2,2),(3,2),(3,3),(4,2),(5,4),(10,4),(100,3),(100,6),(199999,199999),(200000,1),(200000,2),(1,200000),(200000,199999),(199999,200000),(200000,200000))]
    elif number==109:
        def cities(x:int,values:list[int])->str:return f'{len(values)} {x}\n'+line(values)
        raws=[cities(1,[2]),cities(1,[10**9]),cities(10**9,[1]),cities(100,[88,112]),cities(1,[7,13,19]),cities(100,[82,88,94])]+[cities(1000,[1000+d*j for j in range(1,size+1)]) for d,size in ((6,2),(12,3),(18,4),(24,5),(30,6),(36,7),(42,8),(48,9),(54,10),(60,11))]+[cities(10**9,list(range(1,100001))),cities(10**9,list(range(1,100000))+[999999999])]
    elif number==110:
        pairs=[('a','a'),('a','z'),('ab','aa'),('aa','ab'),('ab','ba'),('abcdefghijklmnopqrstuvwxyz','zyxwvutsrqponmlkjihgfedcba')]+[('abcde'*j,'edcba'*j if j%2 else 'abcda'*j) for j in range(1,11)]+[('a'*199999+'b','x'*199999+'x'),('abcdefghijklmnopqrstuvwxyz'*7692+'abcdefgh','zyxwvutsrqponmlkjihgfedcba'*7692+'zyxwvuts')]
        raws=[f'{s}\n{t}\n' for s,t in pairs]
    else:
        def values(v:list[int])->str:return f'{len(v)}\n'+line(v)
        raws=[values([1,1]),values([1,2]),values([100000,100000]),values([1,2,1,2]),values([1,1,2,2]),values([1,2,2,1])]+[values([rng.randrange(1,1+j%5+1) for _ in range(2*(j+2))]) for j in range(1,11)]+[values([1]*50000+[100000]*50000),values([100000]*100000)]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc106_c':('数字1だけは何日経っても長さが変わりません。','左からK文字までを見て、最初の1以外の数字があれば、その数字の増殖部分がK文字目を覆います。','疑似コード: answer=1; for i in 1..min(K,len(S)): if S[i]!=1: answer=S[i]; break; print(answer)。'),
'arc101_a':('選んだK本の最も左と右だけで必要な移動距離が決まります。','連続するK本を候補にし、左を先に訪れる場合と右を先に訪れる場合を比較します。','疑似コード: for consecutive K candles with endpoints L,R: if L<0<R: cost=min(2*abs(L)+abs(R),abs(L)+2*abs(R)); else: cost=max(abs(L),abs(R)); answer=min(answer,cost)。'),
'arc102_a':('三つの和がKの倍数という条件を、余りで考えます。','三つとも余り0、またはKが偶数なら三つとも余りK/2の場合だけです。各余りの個数を3乗します。','疑似コード: answer=floor(N/K)^3; if K even: answer+=floor((N+K/2)/K)^3; print(answer)。'),
'abc109_c':('到達できる位置は、出発位置と同じDの余りを持ちます。','全ての都市までの距離を割り切る最大のD、つまり距離の最大公約数を求めます。','疑似コード: D=0; for city in cities: D=gcd(D,abs(city-X)); print(D)。'),
'abc110_c':('文字の置き換えは、文字同士の一対一対応になります。','SからTへの対応とTからSへの対応が、各位置で矛盾しないかを調べます。','疑似コード: forward={},backward={}; for (s,t): if existing forward[s]!=t or backward[t]!=s: No; forward[s]=t; backward[t]=s; 全位置無矛盾ならYes。'),
'arc103_a':('偶数番目と奇数番目で、それぞれ最も多い値を残したいです。','二つの位置群は異なる値が必要なので、各群の上位2候補を組み合わせます。','疑似コード: A=top2(frequencies(even_positions)); B=top2(frequencies(odd_positions)); append zero-count distinct candidates; kept=max(a.count+b.count where a.value!=b.value); print(N-kept)。')}

TITLES={'abc106_c': 'To Infinity', 'abc109_c': 'Skip', 'abc110_c': 'String Transformation', 'arc101_a': 'Candles', 'arc102_a': 'Triangular Relationship', 'arc103_a': '/\\/\\/\\/'}
PUBLISHED_SAMPLES={'abc106_c': [{'input': '1214\n4\n', 'expected': '2\n'}, {'input': '3\n157\n', 'expected': '3\n'}, {'input': '299792458\n9460730472580800\n', 'expected': '2\n'}], 'abc109_c': [{'input': '3 3\n1 7 11\n', 'expected': '2\n'}, {'input': '3 81\n33 105 57\n', 'expected': '24\n'}, {'input': '1 1\n1000000000\n', 'expected': '999999999\n'}], 'abc110_c': [{'input': 'azzel\napple\n', 'expected': 'Yes\n'}, {'input': 'chokudai\nredcoder\n', 'expected': 'No\n'}, {'input': 'abcdefghijklmnopqrstuvwxyz\nibyhqfrekavclxjstdwgpzmonu\n', 'expected': 'Yes\n'}], 'arc101_a': [{'input': '5 3\n-30 -10 10 20 50\n', 'expected': '40\n'}, {'input': '3 2\n10 20 30\n', 'expected': '20\n'}, {'input': '1 1\n0\n', 'expected': '0\n'}, {'input': '8 5\n-9 -7 -4 -3 1 2 3 4\n', 'expected': '10\n'}], 'arc102_a': [{'input': '3 2\n', 'expected': '9\n'}, {'input': '5 3\n', 'expected': '1\n'}, {'input': '31415 9265\n', 'expected': '27\n'}, {'input': '35897 932\n', 'expected': '114191\n'}], 'arc103_a': [{'input': '4\n3 1 3 2\n', 'expected': '1\n'}, {'input': '6\n105 119 105 119 105 119\n', 'expected': '0\n'}, {'input': '4\n1 1 1 1\n', 'expected': '2\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}

