"""Private ABC150..155 D domains and independent oracles."""
from __future__ import annotations
from decimal import Decimal,DecimalException,localcontext,MAX_EMAX,MIN_EMIN
from functools import lru_cache
from math import gcd
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(150,156))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc154_d':'numeric_tolerance_1e-6'}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def maze_graph(grid:tuple[str,...])->list[list[int]]:
    cells=[(r,c) for r,row in enumerate(grid) for c,ch in enumerate(row) if ch=='.'];index={v:j for j,v in enumerate(cells)}
    return [[index[(r+dr,c+dc)] for dr,dc in ((0,1),(0,-1),(1,0),(-1,0)) if (r+dr,c+dc) in index] for r,c in cells]

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc150_d':
        require(len(rows)==2,'shape');n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=10**9,'N/M');a=ints(rows[1],n);require(all(2<=v<=10**9 and v%2==0 for v in a),'even Ai');return m,a
    if pid=='abc151_d':
        h,w=ints(rows[0],2);require(1<=h<=20 and 1<=w<=20 and len(rows)==h+1,'H/W/shape');grid=tuple(rows[1:]);require(all(len(row)==w and set(row)<={'.','#'} for row in grid),'grid');adj=maze_graph(grid);require(len(adj)>=2,'two road cells');seen={0};stack=[0]
        while stack:
            for v in adj[stack.pop()]:
                if v not in seen:seen.add(v);stack.append(v)
        require(len(seen)==len(adj),'all road cells connected');return (grid,)
    if pid=='abc152_d' or pid=='abc153_d':
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=(200000 if pid=='abc152_d' else 10**12),'N/H');return (n,)
    require(len(rows)==2,'shape');n,k=ints(rows[0],2)
    if pid=='abc154_d':require(1<=k<=n<=200000,'N/K');a=ints(rows[1],n);require(all(1<=v<=1000 for v in a),'dice');return k,a
    require(2<=n<=200000 and 1<=k<=n*(n-1)//2,'N/K');a=ints(rows[1],n);require(all(-10**9<=v<=10**9 for v in a),'Ai');return k,a

def semi_crt(m:int,a:tuple[int,...])->int:
    residue=0;modulus=1
    for index,value in enumerate(a):
        target=value//2;g=gcd(modulus,value)
        if (target-residue)%g:return 0
        factor=value//g;t=(target-residue)//g*pow(modulus//g,-1,factor)%factor;residue=(residue+modulus*t)%(modulus*factor);modulus*=factor
        if residue>m:return 0
        if modulus>m:return int(residue>=1 and all(residue%other==other//2 for other in a[index+1:]))
    return (m-residue)//modulus+1 if residue>=1 else m//modulus

def maze_bit_waves(grid:tuple[str,...])->int:
    adj=maze_graph(grid);reach=[1<<j for j in range(len(adj))];full=(1<<len(adj))-1;distance=0
    while any(row!=full for row in reach):
        next_reach=[]
        for j,neighbors in enumerate(adj):
            row=reach[j]
            for v in neighbors:row|=reach[v]
            next_reach.append(row)
        reach=next_reach;distance+=1
    return distance

def digit_pair_intervals(n:int)->int:
    counts=[[0]*10 for _ in range(10)]
    for first in range(1,10):
        if first<=n:counts[first][first]+=1
        power=10
        while first*power<=n:
            lower=first*power;upper=min(n,(first+1)*power-1)
            for last in range(1,10):
                beginning=lower+(last-lower)%10
                if beginning<=upper:counts[first][last]+=(upper-beginning)//10+1
            power*=10
    return sum(counts[first][last]*counts[last][first] for first in range(1,10) for last in range(1,10))

@lru_cache(maxsize=128)
def monster_tree(h:int)->int:return 1 if h==1 else 1+2*monster_tree(h//2)

def dice_twice(k:int,a:tuple[int,...])->int:
    current=sum(a[:k])+k;best=current
    for right in range(k,len(a)):current+=a[right]-a[right-k];best=max(best,current)
    return best

def numeric_dice_valid(raw:str,actual:str)->bool:
    try:
        data=cast(tuple[int,tuple[int,...]],validate('abc154_d',raw));token=actual.strip()
        if re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
        value=Decimal(token)
        if not value.is_finite():return False
        with localcontext() as ctx:
            ctx.prec=max(64,len(value.as_tuple().digits)+20);ctx.Emax=MAX_EMAX;ctx.Emin=MIN_EMIN;expected=Decimal(dice_twice(*data))/2;difference=abs(value-expected);tolerance=Decimal('0.000001')
            return difference<=tolerance or difference<=abs(expected)*tolerance
    except (ValueError,TypeError,IndexError,DecimalException):return False

def product_cross_count(a:list[int],b:list[int],limit:int)->int:
    right=len(b)-1;count=0
    for value in a:
        while right>=0 and value*b[right]>limit:right-=1
        count+=right+1
    return count

def product_same_count(a:list[int],limit:int)->int:
    left=0;right=len(a)-1;count=0
    while left<right:
        if a[left]*a[right]<=limit:count+=right-left;left+=1
        else:right-=1
    return count

def product_partition_rank(k:int,a:tuple[int,...])->int:
    negative=sorted(-v for v in a if v<0);positive=sorted(v for v in a if v>0);zero=len(a)-len(negative)-len(positive);negative_pairs=len(negative)*len(positive)
    if k<=negative_pairs:
        rank=negative_pairs-k+1;low=-1;high=10**18
        while low+1<high:
            middle=(low+high)//2
            if product_cross_count(negative,positive,middle)>=rank:high=middle
            else:low=middle
        return -high
    k-=negative_pairs;zero_pairs=zero*(len(a)-zero)+zero*(zero-1)//2
    if k<=zero_pairs:return 0
    k-=zero_pairs;low=-1;high=10**18
    while low+1<high:
        middle=(low+high)//2
        if product_same_count(negative,middle)+product_same_count(positive,middle)>=k:high=middle
        else:low=middle
    return high

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc150_d':return str(semi_crt(*cast(tuple[int,tuple[int,...]],data)))
    if pid=='abc151_d':return str(maze_bit_waves(cast(tuple[str,...],data[0])))
    if pid=='abc152_d':return str(digit_pair_intervals(cast(int,data[0])))
    if pid=='abc153_d':return str(monster_tree(cast(int,data[0])))
    if pid=='abc154_d':
        value=dice_twice(*cast(tuple[int,tuple[int,...]],data));return str(value//2)+('.5' if value%2 else '.0')
    return str(product_partition_rank(*cast(tuple[int,tuple[int,...]],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc154_d':return numeric_dice_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc154_d':return numeric_dice_valid(raw,expected) and numeric_dice_valid(raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc150_d':"from math import gcd\nn,m=map(int,input().split());a=list(map(int,input().split()));halves=[v//2 for v in a];l=1\nfor value in halves:\n l=l//gcd(l,value)*value\n if l>m:break\nif l>m or any((l//v)%2==0 for v in halves):print(0)\nelse:print((m//l+1)//2)\n",
'abc151_d':"from collections import deque\nh,w=map(int,input().split());g=[input() for _ in range(h)];answer=0\nfor sr in range(h):\n for sc in range(w):\n  if g[sr][sc]=='#':continue\n  d=[[-1]*w for _ in range(h)];d[sr][sc]=0;q=deque([(sr,sc)])\n  while q:\n   r,c=q.popleft();answer=max(answer,d[r][c])\n   for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):\n    nr,nc=r+dr,c+dc\n    if 0<=nr<h and 0<=nc<w and g[nr][nc]=='.' and d[nr][nc]<0:d[nr][nc]=d[r][c]+1;q.append((nr,nc))\nprint(answer)\n",
'abc152_d':"n=int(input());counts=[[0]*10 for _ in range(10)]\nfor value in range(1,n+1):s=str(value);counts[int(s[0])][int(s[-1])]+=1\nprint(sum(counts[a][b]*counts[b][a] for a in range(1,10) for b in range(1,10)))\n",
'abc153_d':"h=int(input());print((1<<h.bit_length())-1)\n",
'abc154_d':"n,k=map(int,input().split());a=list(map(int,input().split()));p=[0]\nfor v in a:p.append(p[-1]+v+1)\nprint(max(p[j+k]-p[j] for j in range(n-k+1))/2)\n",
'abc155_d':"from bisect import bisect_left,bisect_right\nn,k=map(int,input().split());a=sorted(map(int,input().split()))\ndef count(bound):\n total=0\n for i,value in enumerate(a):\n  if value<0:total+=n-bisect_left(a,-((-bound)//value),i+1)\n  elif value>0:total+=bisect_right(a,bound//value,i+1)-(i+1)\n  elif bound>=0:total+=n-i-1\n return total\nlo=-10**18-1;hi=10**18\nwhile lo+1<hi:\n mid=(lo+hi)//2\n if count(mid)>=k:hi=mid\n else:lo=mid\nprint(hi)\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18700+TASKS.index(pid))
    if pid=='abc150_d':
        def seq(m:int,a:list[int])->str:return line((len(a),m))+line(a)
        raws=[seq(1,[2]),seq(1,[4]),seq(10**9,[2]),seq(50,[6,10])];raws.extend(seq(rng.randint(1,10**9),[2*rng.randint(1,5*10**8) for _ in range(n)]) for n in range(2,14));raws[-1]=seq(10**9,[2*(2*j+1) for j in range(100000)]);raws.extend([seq(10**9,[6,10]*50000),seq(10**9,[10**9]*100000)])
    elif pid=='abc151_d':
        def grid(a:list[str])->str:return line((len(a),len(a[0])))+'\n'.join(a)+'\n'
        raws=[grid(['..']),grid(['.','.']),grid(['..','..']),grid(['...','##.'])]
        for n in range(3,15):
            a=[['#']*n for _ in range(n)];r=c=0;a[r][c]='.'
            for _ in range(n*n*3):
                dr,dc=rng.choice(((1,0),(-1,0),(0,1),(0,-1)));r=min(n-1,max(0,r+dr));c=min(n-1,max(0,c+dc));a[r][c]='.'
            raws.append(grid([''.join(row) for row in a]))
        snake=['.'*20 if r%2==0 else '#'*19+'.' if r%4==1 else '.'+'#'*19 for r in range(20)];raws.extend([grid(snake),grid(['.'*20]*20)])
    elif pid=='abc152_d':raws=[f'{n}\n' for n in [1,2,9,10,11,25,99,100,101,999,1000,2020,9999,10000,99999,100000,199999,200000]]
    elif pid=='abc153_d':raws=[f'{h}\n' for h in [1,2,3,4,7,8,9,15,16,17,2**20-1,2**20,2**20+1,2**39-1,2**39,2**39+1,10**12-1,10**12]]
    elif pid=='abc154_d':
        def dice(k:int,a:list[int])->str:return line((len(a),k))+line(a)
        raws=[dice(1,[1]),dice(1,[1000]),dice(1,[1,2]),dice(2,[1,1000])];raws.extend(dice(rng.randint(1,n),[rng.randint(1,1000) for _ in range(n)]) for n in range(3,15));raws.extend([dice(100000,[j%1000+1 for j in range(200000)]),dice(200000,[1000]*200000)])
    else:
        def pairs(k:int,a:list[int])->str:return line((len(a),k))+line(a)
        raws=[pairs(1,[0,0]),pairs(1,[-10**9,10**9]),pairs(1,[-10**9,-10**9]),pairs(1,[10**9,10**9])];raws.extend(pairs(rng.randint(1,n*(n-1)//2),[rng.randint(-10**9,10**9) for _ in range(n)]) for n in range(3,15));raws.extend([pairs(9999900000,[-10**9]*100000+[10**9]*100000),pairs(19999900000,[10**9]*200000)])
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc150_d':('条件は、Xをa_i/2で割った商がすべて奇数となることです。','a_i/2の最小公倍数Lを求め、L/(a_i/2)が全て奇数か確認します。条件が合えばLの奇数倍を数えます。','疑似コード: half=a/2; Lをgcdで更新; L>Mなら0; L/halfのいずれかが偶数なら0; 他は(floor(M/L)+1)//2を出力。'),
'abc151_d':('最短距離が最大になる開始マスと終了マスを探します。道のマスは最大400個です。','各道のマスからBFSし、全マスへの最短距離の最大値を比較します。','疑似コード: 各roadをstartにする; distance=-1で初期化しBFS; 未訪問の隣接roadへdistance+1を設定; 全探索中の最大distanceを出力。'),
'abc152_d':('整数の条件は、先頭と末尾の数字だけで決まります。末尾0の整数は相手がありません。','先頭i・末尾jの個数を数えると、対応する順序付き組はcount[i][j]*count[j][i]個です。','疑似コード: v=1..Nを文字列にし先頭/末尾をcountへ加算; i,j=1..9の全組でcount[i][j]*count[j][i]を合計して出力。'),
'abc153_d':('体力が1なら一度の攻撃で倒せます。体力が2以上なら、攻撃後に同じ体力floor(H/2)の敵が2体できます。','敵の分裂は同じ深さで終わる完全二分木です。体力のビット長が木の段数になります。','疑似コード: depth=Hのbit_length; 攻撃回数=(1<<depth)-1を整数で出力。'),
'abc154_d':('面数pのサイコロの期待値は(p+1)/2です。期待値の和は各期待値の和になります。','隣接K個の(p+1)の和を累積和から計算し、その最大値を2で割ります。','疑似コード: prefix[0]=0; prefixへp_i+1を累積; j=0..N-Kのprefix[j+K]-prefix[j]の最大を取る; 最大/2を出力。'),
'abc155_d':('積のK番目の値は、値x以下の積が何個あるかを数えて二分探索できます。','Aをsortし、各A_iについて相手A_jの境界を二分探索します。負数では不等号が反転し、0はx>=0のときだけ数えます。','疑似コード: count(x): i<jだけ対象; A_i>0ならA_j<=floor(x/A_i),A_i<0ならA_j>=ceil(x/A_i),A_i=0ならx>=0を判定; count(mid)>=Kとなる最小midを[-1e18,1e18]でbinary search。')}

TITLES={'abc150_d': 'Semi Common Multiple', 'abc151_d': 'Maze Master', 'abc152_d': 'Handstand 2', 'abc153_d': 'Caracal vs Monster', 'abc154_d': 'Dice in Line', 'abc155_d': 'Pairs'}
PUBLISHED_SAMPLES={'abc150_d': [{'input': '2 50\n6 10\n', 'expected': '2\n'}, {'input': '3 100\n14 22 40\n', 'expected': '0\n'}, {'input': '5 1000000000\n6 6 2 6 2\n', 'expected': '166666667\n'}], 'abc151_d': [{'input': '3 3\n...\n...\n...\n', 'expected': '4\n'}, {'input': '3 5\n...#.\n.#.#.\n.#...\n', 'expected': '10\n'}], 'abc152_d': [{'input': '25\n', 'expected': '17\n'}, {'input': '1\n', 'expected': '1\n'}, {'input': '100\n', 'expected': '108\n'}, {'input': '2020\n', 'expected': '40812\n'}, {'input': '200000\n', 'expected': '400000008\n'}], 'abc153_d': [{'input': '2\n', 'expected': '3\n'}, {'input': '4\n', 'expected': '7\n'}, {'input': '1000000000000\n', 'expected': '1099511627775\n'}], 'abc154_d': [{'input': '5 3\n1 2 2 4 5\n', 'expected': '7.000000000000\n'}, {'input': '4 1\n6 6 6 6\n', 'expected': '3.500000000000\n'}, {'input': '10 4\n17 13 13 12 15 20 10 13 17 11\n', 'expected': '32.000000000000\n'}], 'abc155_d': [{'input': '4 3\n3 3 -4 -2\n', 'expected': '-6\n'}, {'input': '10 40\n5 4 3 2 -1 0 0 0 0 0\n', 'expected': '6\n'}, {'input': '30 413\n-170202098 -268409015 537203564 983211703 21608710 -443999067 -937727165 -97596546 -372334013 398994917 -972141167 798607104 -949068442 -959948616 37909651 0 886627544 -20098238 0 -948955241 0 -214720580 277222296 -18897162 834475626 0 -425610555 110117526 663621752 0\n', 'expected': '448283280358331064\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
