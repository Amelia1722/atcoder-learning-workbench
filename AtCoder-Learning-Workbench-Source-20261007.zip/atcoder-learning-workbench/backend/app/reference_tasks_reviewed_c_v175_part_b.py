"""Prefix integrals, radix palindromes, reverse reachability and capacity areas."""
from __future__ import annotations
from bisect import bisect_right
from collections import Counter
from functools import lru_cache
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(413,419))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[int,...],...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');number=int(pid[3:6]);require(number==416 or all(rows),'blank')
    if number==413:
        q=ints(rows[0],1)[0];require(1<=q<=200000 and len(rows)==q+1,'shape');size=0;queries=[]
        for row in rows[1:]:
            a=ints(row);require(a[0] in (1,2) and len(a)==(3 if a[0]==1 else 2),'query')
            if a[0]==1:require(1<=a[1]<=10**9 and 1<=a[2]<=10**9,'append');size+=a[1]
            else:require(1<=a[1]<=min(10**9,size),'remove');size-=a[1]
            queries.append(a)
        return tuple(queries),
    if number==414:
        require(len(rows)==2,'shape');a,n=ints(rows[0],1)[0],ints(rows[1],1)[0];require(2<=a<=9 and 1<=n<=10**12,'palindromes');return a,n
    if number==415:
        t=ints(rows[0],1)[0];require(1<=t<=40000 and len(rows)==2*t+1,'shape');cases=[];total=0
        for j in range(t):
            n=ints(rows[2*j+1],1)[0];s=rows[2*j+2];require(1<=n<=18 and len(s)==(1<<n)-1 and re.fullmatch('[01]+',s) is not None,'states');total+=len(s);cases.append((n,s))
        require(total<=500000,'aggregate');return tuple(cases),
    if number==416:
        n,k,x=ints(rows[0],3);require(1<=n<=10 and 1<=k<=5 and 1<=x<=n**k and len(rows)==n+1,'shape');strings=tuple(rows[1:]);require(all(0<=len(s)<=10 and re.fullmatch('[a-z]*',s) is not None for s in strings),'words');return k,x,strings
    if number==417:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=200000 and all(1<=v<=200000 for v in a),'values');return (a,)
    n,q=ints(rows[0],2);require(1<=n<=300000 and 1<=q<=300000 and len(rows)==q+2,'shape');a=ints(rows[1],n);b=tuple(ints(row,1)[0] for row in rows[2:]);upper=min(10**6,sum(a));require(all(1<=v<=10**6 for v in a) and all(1<=v<=upper for v in b),'capacities');return a,b

@lru_cache(maxsize=64)
def palindrome_sum(base:int,limit:int)->int:
    answer=0;length=1;power=1
    while power<=limit:
        half=(length+1)//2
        for prefix in range(base**(half-1),base**half):
            value=prefix;remaining=prefix//base if length%2 else prefix
            while remaining:value=value*base+remaining%base;remaining//=base
            if value>limit:break
            text=str(value)
            if text==text[::-1]:answer+=value
        length+=1;power*=base
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==413:
        qs=cast(Queries,data[0]);ends=[0];areas=[0];values=[]
        for q in qs:
            if q[0]==1:ends.append(ends[-1]+q[1]);areas.append(areas[-1]+q[1]*q[2]);values.append(q[2])
        def integral(count:int)->int:
            j=bisect_right(ends,count)-1
            return areas[j]+((count-ends[j])*values[j] if j<len(values) else 0)
        removed=0;out=[]
        for q in qs:
            if q[0]==2:out.append(str(integral(removed+q[1])-integral(removed)));removed+=q[1]
        return '\n'.join(out)
    if number==414:return str(palindrome_sum(*cast(tuple[int,int],data)))
    if number==415:
        out=[]
        for n,s in cast(tuple[tuple[int,str],...],data[0]):
            full=(1<<n)-1;visited=set();stack=[full] if s[-1]=='0' else []
            while stack:
                mask=stack.pop()
                if mask in visited:continue
                visited.add(mask);bits=mask
                while bits:
                    bit=bits&-bits;bits-=bit;previous=mask^bit
                    if previous==0 or s[previous-1]=='0':stack.append(previous)
            out.append('Yes' if 0 in visited else 'No')
        return '\n'.join(out)
    if number==416:
        k,x,strings=cast(tuple[int,int,tuple[str,...]],data);words=Counter(strings);states=Counter({'':1})
        for _ in range(k):
            following:Counter[str]=Counter()
            for prefix,count in states.items():
                for suffix,multiplicity in words.items():following[prefix+suffix]+=count*multiplicity
            states=following
        for word,count in sorted(states.items()):
            if x<=count:return word
            x-=count
        raise ValueError('rank')
    if number==417:
        a=cast(tuple[int,...],data[0]);left=Counter(j+v for j,v in enumerate(a));right=Counter(j-v for j,v in enumerate(a));return str(sum(count*right[value] for value,count in left.items()))
    a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);maximum=max(a);frequency=Counter(a);atleast=len(a);areas=[0]*(maximum+1)
    for level in range(1,maximum+1):areas[level]=areas[level-1]+atleast;atleast-=frequency[level]
    return '\n'.join(str(areas[difficulty-1]+1) if difficulty<=maximum else '-1' for difficulty in b)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc413_c':"from collections import deque\nq=int(input());queue=deque()\nfor _ in range(q):\n a=list(map(int,input().split()))\n if a[0]==1:queue.append([a[1],a[2]])\n else:\n  left=a[1];answer=0\n  while left:\n   count,value=queue[0];take=min(left,count);left-=take;answer+=take*value\n   if take==count:queue.popleft()\n   else:queue[0][0]-=take\n  print(answer)\n",
'abc414_c':"a=int(input());n=int(input());answer=0\ndef in_base(value):\n digits=[]\n while value:digits.append(value%a);value//=a\n return digits==digits[::-1]\nfor seed in range(1,1000000):\n text=str(seed)\n if int(text+text[-2::-1])>n:break\n for word in (text+text[-2::-1],text+text[::-1]):\n  value=int(word)\n  if value<=n and in_base(value):answer+=value\nprint(answer)\n",
'abc415_c':"t=int(input())\nfor _ in range(t):\n n=int(input());s=input();reachable=bytearray(1<<n);reachable[0]=1\n for mask in range(1,1<<n):\n  if s[mask-1]=='1':continue\n  bits=mask\n  while bits:\n   bit=bits&-bits;bits-=bit\n   if reachable[mask^bit]:reachable[mask]=1;break\n print('Yes' if reachable[-1] else 'No')\n",
'abc416_c':"from itertools import product\nn,k,x=map(int,input().split());s=[input() for _ in range(n)];print(sorted(''.join(row) for row in product(s,repeat=k))[x-1])\n",
'abc417_c':"n=int(input());a=list(map(int,input().split()));counts={};answer=0\nfor j,v in enumerate(a):answer+=counts.get(j-v,0);counts[j+v]=counts.get(j+v,0)+1\nprint(answer)\n",
'abc418_c':"from bisect import bisect_left\nn,q=map(int,input().split());a=sorted(map(int,input().split()));prefix=[0]\nfor v in a:prefix.append(prefix[-1]+v)\nfor _ in range(q):\n b=int(input())\n if b>a[-1]:print(-1)\n else:p=bisect_left(a,b-1);print(prefix[p]+(n-p)*(b-1)+1)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17500+number)
    if number==413:
        def query(qs:list[str])->str:return f'{len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[query(qs) for qs in (['1 1 1'],['1 1 1','2 1'],['1 2 3','2 1','2 1'],['1 2 3','1 3 4','2 3'])]
        for n in range(3,15):
            size=0;qs=[]
            for _ in range(n+5):
                if size and rng.randrange(2):k=rng.randint(1,size);qs.append(f'2 {k}');size-=k
                else:c=rng.randint(1,20);qs.append(f'1 {c} {rng.randint(1,30)}');size+=c
            raws.append(query(qs))
        raws.extend([query(['1 1000000000 1000000000']*100000+['2 1000000000']*100000),query(['1 1000000000 1000000000']+['2 1']*199999)])
    elif number==414:raws=[f'{a}\n{n}\n' for a,n in ((2,1),(9,9),(2,10),(8,414),(2,100),(3,1000),(4,2000),(5,9999),(6,10000),(7,50000),(8,100000),(9,999999),(2,10**7),(3,10**8),(8,10**9),(6,10**10),(2,10**12),(9,10**12))]
    elif number==415:
        def chemicals(cases:list[tuple[int,str]])->str:return f'{len(cases)}\n'+''.join(f'{n}\n{s}\n' for n,s in cases)
        raws=[chemicals(cases) for cases in ([(1,'0')],[(1,'1')],[(2,'000')],[(2,'001')])]
        for n in range(3,15):raws.append(chemicals([(n,''.join(rng.choice('01') for _ in range((1<<n)-1)))]))
        raws.extend([chemicals([(1,'0')]*40000),chemicals([(18,'0'*((1<<18)-1)),(17,'0'*((1<<17)-1)),(16,'0'*((1<<16)-1)),(15,'0'*((1<<15)-1)),(13,'0'*((1<<13)-1))]+[(1,'0')]*293)])
    elif number==416:
        def words(k:int,x:int,s:list[str])->str:return f'{len(s)} {k} {x}\n'+'\n'.join(s)+'\n'
        raws=[words(k,x,s) for k,x,s in ((1,1,['']),(5,1,['a']),(2,2,['a','aa']),(2,3,['ab','a']))]
        for n in range(2,14):s=[''.join(rng.choice('abc') for _ in range(rng.randint(1,5))) for _ in range(min(n,10))];k=1+n%5;raws.append(words(k,rng.randint(1,len(s)**k),s))
        raws.extend([words(5,1,['a'*9+chr(97+j) for j in range(10)]),words(5,100000,['z'*10]*10)])
    elif number==417:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[1,1],[1,1,1],[2,1,1,2])];raws.extend(arr([rng.randint(1,20) for _ in range(n)]) for n in range(4,16));raws.extend([arr([1]*200000),arr([200000]*200000)])
    else:
        def tea(a:list[int],b:list[int])->str:return f'{len(a)} {len(b)}\n'+line(a)+''.join(f'{v}\n' for v in b)
        raws=[tea(a,b) for a,b in (([1],[1]),([2],[1,2]),([1,1],[2]),([2,3],[1,2,3,4,5]))]
        for n in range(4,16):a=[rng.randint(1,20) for _ in range(n)];raws.append(tea(a,[rng.randint(1,sum(a)) for _ in range(n+1)]))
        raws.extend([tea(list(range(1,300001)),list(range(1,300001))),tea([10**6]*300000,[10**6]*300000)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc413_c':('同じ値が連続する部分を個数と値の組で持ちます。','先頭を削除するときは先頭の塊から必要な個数だけ取り、個数×値を足します。','疑似コード: 追加(c,x)をdeque末尾へ; 削除kで先頭からtake=min(k,count)を取りanswer+=take*x; 空になった塊をpopし残りkを続ける。'),
'abc414_c':('十進法の回文は前半だけ決めれば生成できます。','Nは10^12以下なので、前半が6桁以下の奇数長・偶数長回文を列挙し、A進法でも回文か調べます。','疑似コード: seed=1..999999; seed文字列を奇数長と偶数長へ鏡映; value<=NならAで割った余り列を作り回文か確認; 条件を満たすvalueを加算。'),
'abc415_c':('薬品の集合をbitmaskで表します。','安全な集合maskへ到達できるのは、1種類取り除いた集合に到達できる場合です。','疑似コード: reachable[0]=true; mask昇順で危険ならskip; mask内のbitを一つ除いたreachableがtrueなら現在もtrue; fullの到達可否。'),
'abc416_c':('数列は最大10^5通りなので、全ての連結結果を作れます。','同じ文字列ができても数列が異なれば別の順位として残します。','疑似コード: SからK個選ぶ全直積を列挙して連結; 重複を残してsort; X-1番目を出力。'),
'abc417_c':('条件をi+A[i]=j-A[j]へ変形します。','左から処理し、過去のi+A[i]の出現回数を持つとjの答えをすぐ足せます。','疑似コード: countを空にする; 各jでanswer+=count.get(j-A[j],0); count[j+A[j]]++; answer出力。'),
'abc418_c':('負ける渡し方では、各フレーバーを高々b-1個しか渡せません。','勝つための最小個数はsum(min(A[i],b-1))+1です。最大Aがb未満なら不可能です。','疑似コード: Aをsortしprefix和; 各b>max(A)なら-1; 他はp=lower_bound(A,b-1), prefix[p]+(N-p)*(b-1)+1を出力。')}

TITLES={'abc413_c': 'Large Queue', 'abc414_c': 'Palindromic in Both Bases', 'abc415_c': 'Mixture', 'abc416_c': 'Concat (X-th)', 'abc417_c': 'Distance Indicators', 'abc418_c': 'Flush'}
PUBLISHED_SAMPLES={'abc413_c': [{'input': '5\n1 2 3\n1 4 5\n2 3\n1 6 2\n2 5\n', 'expected': '11\n19\n'}, {'input': '10\n1 75 22\n1 81 72\n1 2 97\n1 84 82\n1 2 32\n1 39 57\n2 45\n1 40 16\n2 32\n2 42\n', 'expected': '990\n804\n3024\n'}, {'input': '10\n1 160449218 954291757\n2 17217760\n1 353195922 501899080\n1 350034067 910748511\n1 824284691 470338674\n2 180999835\n1 131381221 677959980\n1 346948152 208032501\n1 893229302 506147731\n2 298309896\n', 'expected': '16430766442004320\n155640513381884866\n149721462357295680\n'}], 'abc414_c': [{'input': '8\n1000\n', 'expected': '2155\n'}, {'input': '8\n999999999999\n', 'expected': '914703021014\n'}, {'input': '6\n999999999999\n', 'expected': '283958331810\n'}], 'abc415_c': [{'input': '5\n3\n0010000\n3\n0010110\n1\n1\n2\n100\n4\n001110010101110\n', 'expected': 'Yes\nNo\nNo\nYes\nYes\n'}], 'abc416_c': [{'input': '3 2 6\nabc\nxxx\nabc\n', 'expected': 'abcxxx\n'}, {'input': '5 5 416\na\naa\naaa\naa\na\n', 'expected': 'aaaaaaa\n'}], 'abc417_c': [{'input': '9\n3 1 4 1 5 9 2 6 5\n', 'expected': '3\n'}, {'input': '3\n123456 123456 123456\n', 'expected': '0\n'}, {'input': '30\n8 3 6 4 9 6 5 6 5 6 3 4 7 3 7 4 9 8 5 8 3 6 8 8 4 5 5 5 6 5\n', 'expected': '17\n'}], 'abc418_c': [{'input': '4 5\n4 1 8 4\n1\n8\n5\n2\n10\n', 'expected': '1\n17\n14\n5\n-1\n'}, {'input': '5 3\n13 13 13 13 2\n5\n12\n13\n', 'expected': '19\n47\n51\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
