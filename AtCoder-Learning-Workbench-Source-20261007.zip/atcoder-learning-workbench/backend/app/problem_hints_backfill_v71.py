"""Evidence-bound backfill for ABC021–023 B; public statements checked."""
HINTS_BACKFILL_V71 = {
    'abc021_b': (
        '最短経路なら、同じ町を途中で2回通る必要はありません。出発町a・経由町・到着町bを全部並べて重複がないか見てください。',
        '列 `[a] + P + [b]` に同じ町が2回出れば、その間を取り除いてより短い経路にできるのでNOです。全て異なれば、その経路だけを道路として持つ構成を作れるためYESです。',
        '''疑似コード:\nroute=[a] + P + [b]\nif len(set(route)) == len(route): print('YES')\nelse: print('NO')''',
    ),
    'abc022_b': (
        'i番目の花が受粉するのは、同じ種類をそれ以前に1回でも訪れているときです。初登場かどうかだけ覚えれば十分です。',
        'seenというsetを持ちます。A_iがseenにあれば答えを1増やし、その後A_iをseenへ追加します。2回目以降は毎回受粉として数えます。',
        '''疑似コード:\nseen=set(); answer=0\nfor x in A:\n  if x in seen: answer += 1\n  seen.add(x)\nprint(answer)''',
    ),
    'abc023_b': (
        '完成形は手順0の`b`から、左右に2文字ずつ追加して一意に決まります。与えられたSと同じ長さになるまで同じ操作を再現できます。',
        '手順番号を1,2,0(mod 3)で見て、左右に `(a,c)`, `(c,a)`, `(b,b)` を順番に追加します。長さがNを超えた、または長さNでSと違えば-1です。',
        '''疑似コード:\ncur='b'\nstep=0\nwhile len(cur)<N:\n  step += 1\n  if step%3==1: cur='a'+cur+'c'\n  elif step%3==2: cur='c'+cur+'a'\n  else: cur='b'+cur+'b'\nif cur==S: print(step)\nelse: print(-1)''',
    ),
}
