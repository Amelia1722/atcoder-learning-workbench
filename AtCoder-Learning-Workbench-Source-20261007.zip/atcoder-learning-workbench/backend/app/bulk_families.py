"""Explicitly reviewed, reusable input families for independently checked ABC tasks.

These are NOT inferred from a title or technique tag. Each listed ID's limits,
format and published examples must be reviewed against its official statement.
"""
from __future__ import annotations

import random
import re
from typing import Any

# Explicit allowlist: a reusable grammar is not a claim that arbitrary ABC tasks
# sharing that grammar have the same semantics or valid inputs.
FAMILIES: dict[str, dict[str, Any]] = {
    'abc178_c': {'family':'scalar','low':1,'high':1_000_000},
    'abc242_c': {'family':'scalar','low':2,'high':1_000_000},
    'abc275_d': {'family':'scalar','low':0,'high':10**18},
    'abc340_c': {'family':'scalar','low':2,'high':10**17},
    'abc261_c': {'family':'word_lines','low':1,'high':200_000,'alphabet':'abcdefghijklmnopqrstuvwxyz','word_max':10},
    'abc295_d': {'family':'digit_string','low':1,'high':500_000,'alphabet':'0123456789'},
    'abc126_e': {'family':'parity_graph','low':2,'high':100_000,'max_edges':100_000,'max_weight':100},
}


def validate(pid: str, data: str) -> None:
    """Fail closed on lexical rules, count, alphabet and bounds, without split of big input."""
    spec=FAMILIES[pid]
    kind=spec['family']
    if kind=='scalar':
        if not re.fullmatch(r'[0-9]+\n?',data,flags=re.ASCII):
            raise ValueError('単一の非負10進整数が必要です')
        n=int(data)
        if not spec['low']<=n<=spec['high']:
            raise ValueError('整数の範囲外')
        return
    if kind=='digit_string':
        s=data.removesuffix('\n')
        if not spec['low']<=len(s)<=spec['high'] or any(c not in spec['alphabet'] for c in s):
            raise ValueError('数字列の長さ・文字種が不正')
        return
    if kind=='parity_graph':
        # Verify even/odd constraints as well as counts and distinct undirected
        # edges: random triples alone could violate this task's solvability promise.
        rows=data.splitlines()
        if not rows or len(rows[0].split())!=2:
            raise ValueError('先頭行にN Mが必要')
        try:
            n,m=map(int,rows[0].split())
        except ValueError as exc:
            raise ValueError('N Mは整数です') from exc
        if not spec['low']<=n<=spec['high'] or not 1<=m<=min(spec['max_edges'],n*(n-1)//2):
            raise ValueError('頂点数または辺数が制約外')
        if len(rows)!=m+1:
            raise ValueError('辺行数がMと一致しません')
        adj=[[] for _ in range(n)]
        used=set()
        for line in rows[1:]:
            fields=line.split()
            if len(fields)!=3:
                raise ValueError('各辺はX Y Zの3整数')
            try:
                x,y,z=map(int,fields)
            except ValueError as exc:
                raise ValueError('辺の値が整数ではありません') from exc
            if not 1<=x<y<=n or not 1<=z<=spec['max_weight'] or (x,y) in used:
                raise ValueError('辺・重み範囲外または重複')
            used.add((x,y))
            adj[x-1].append((y-1,z&1))
            adj[y-1].append((x-1,z&1))
        colors=[-1]*n
        for start in range(n):
            if colors[start]!=-1:continue
            colors[start]=0
            stack=[start]
            while stack:
                v=stack.pop()
                for u,parity in adj[v]:
                    expected=colors[v]^parity
                    if colors[u]==-1:
                        colors[u]=expected
                        stack.append(u)
                    elif colors[u]!=expected:
                        raise ValueError('偶奇条件に矛盾があります')
        return
    if kind=='word_lines':
        # Only the first line is parsed as an integer. Never use unbounded split()
        # on multi-megabyte inputs solely to check their shape.
        first,sep,tail=data.partition('\n')
        if not sep or not re.fullmatch(r'[0-9]+',first,flags=re.ASCII):
            raise ValueError('先頭行にNが必要')
        n=int(first)
        if not spec['low']<=n<=spec['high']:
            raise ValueError('Nの範囲外')
        rows=tail.removesuffix('\n').split('\n')
        if len(rows)!=n or any(not 1<=len(s)<=spec['word_max'] or
                               any(ch not in spec['alphabet'] for ch in s) for s in rows):
            raise ValueError('文字列行数・長さ・文字種が不正')
        return
    raise ValueError('未登録の入力ファミリー')


def generate(pid: str,count: int,seed: int,include_large: bool) -> list[dict[str,str]]:
    """Reusable min, boundary, typical, deterministic random, and true-size cases."""
    if not 1<=count<=80:
        raise ValueError('count=1..80')
    sp=FAMILIES[pid]
    rng=random.Random(f'{seed}:{pid}')
    if sp['family']=='parity_graph':
        rng=random.Random(f'{seed}:{pid}')
        results=[]
        seen=set()
        choices=[(2,1,'constraint_min',0),(3,2,'boundary',1),
                 (4,1,'boundary',2),(20,1,'typical',0),
                 (20,19,'typical',1),(20,70,'typical',2),
                 (200,199,'random',0),(200,1000,'random',1),
                 (500,250,'random',2),(2000,1999,'random',0),
                 (2000,3000,'random',1),(10_000,1,'boundary',0),
                 (10_000,10_000,'random',1),(100_000,1,'boundary',0)]
        for n,m,category,variant in choices[:count]:
            m=min(m,n*(n-1)//2,sp['max_edges'])
            edges=[]; used=set()
            if variant==0 and m==1:
                edges=[(1,n)]
            elif variant==2:
                # Insert disjoint pairs first; then fill with other pairs.
                edges=[(i,i+1) for i in range(1,n,2)][:m]
            elif variant==1:
                edges=[(1,j) for j in range(2,min(n,m+1)+1)]
            else:
                edges=[(i,i+1) for i in range(1,min(n,m+1))]
            used.update(edges)
            if len(edges)<m:
                # Deterministic linear fill; no unbounded rejection sampling.
                for i in range(1,n):
                    if len(edges)==m:break
                    for j in range(i+1,n+1):
                        if (i,j) in used:continue
                        used.add((i,j));edges.append((i,j))
                        if len(edges)==m:break
            if len(edges)!=m:raise ValueError('合法な辺数を生成できません')
            hidden=[rng.randrange(2) for _ in range(n)]
            lines=[f'{n} {m}']
            for i,j in edges:
                z=rng.randrange(1,51)*2-(hidden[i-1]^hidden[j-1])
                # z has parity equal to XOR(hidden_i,hidden_j):
                # even -> even (2k); odd -> odd (2k-1).
                lines.append(f'{i} {j} {z}')
            text='\n'.join(lines)+'\n'
            add_case={'input':text,'category':category}
            validate(pid,text)
            if text not in seen:
                seen.add(text);results.append(add_case)
        if include_large:
            n=sp['high'];m=sp['max_edges']
            # Long chain plus one additional edge: n=100000, m=100000.
            lines=[f'{n} {m}']
            lines.extend(f'{i} {i+1} 2' for i in range(1,n))
            lines.append('1 3 2')
            text='\n'.join(lines)+'\n'
            validate(pid,text)
            if text not in seen:results.append({'input':text,'category':'constraint_max'})
            else:next(c for c in results if c['input']==text)['category']='constraint_max'
        return results
    lo,hi=sp['low'],sp['high']
    result:list[dict[str,str]]=[]
    seen:set[str]=set()

    def add(text:str,category:str)->None:
        validate(pid,text)
        if text not in seen:
            seen.add(text)
            result.append({'input':text,'category':category})

    def make(n:int,variant:int)->str:
        family=sp['family']
        if family=='scalar':return f'{n}\n'
        if family=='digit_string':
            if variant%5==0:return '0'*n+'\n'
            if variant%5==1:return '9'*n+'\n'
            if variant%5==2:return ('0123456789'*(n//10+1))[:n]+'\n'
            if variant%5==3:return ('01'*(n//2+1))[:n]+'\n'
            return ''.join(str(rng.randrange(10)) for _ in range(n))+'\n'
        if family=='word_lines':
            if variant%5==0:rows=['a']*n
            elif variant%5==1:rows=['abcdefghij']*n
            elif variant%5==2:rows=['a' if i%2 else 'b' for i in range(n)]
            elif variant%5==3:rows=[chr(97+i%26) for i in range(n)]
            else:rows=[''.join(chr(97+rng.randrange(26)) for _ in range(rng.randint(1,10))) for _ in range(n)]
            return f'{n}\n'+'\n'.join(rows)+'\n'
        raise ValueError(family)

    boundaries=[(lo,'constraint_min'),(lo+1,'boundary'),(max(lo,hi//2),'typical'),
                (max(lo,hi-1),'boundary'),(hi,'constraint_max')]
    # Do not consume the entire case budget on huge inputs; large is an opt-in extra.
    for j,(n,cat) in enumerate(boundaries[:4]):
        if len(result)>=count:break
        add(make(n,j),cat)
    attempts=0
    while len(result)<count and attempts<count*35+100:
        attempts+=1
        # Limit random case size for fast independent differential checks.
        n=rng.randint(lo,min(hi,max(lo,200 if sp['family']!='scalar' else 100_000)))
        add(make(n,rng.randrange(5)),'random')
    if include_large:
        # Ensure one genuine maximum constraint case (even when count is 1).
        maximum=make(hi,2 if sp['family']!='scalar' else 0)
        if maximum not in seen:
            add(maximum,'constraint_max')
        else:
            next(c for c in result if c['input']==maximum)['category']='constraint_max'
    if not result:raise ValueError('合法な入力が生成できません')
    return result
