"""ABC128–130 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc128_b', 'abc129_b', 'abc130_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
CITY = re.compile(r'[a-z]{1,10}', re.ASCII)


def _split_positive(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(token) is None for token in parts):
        raise ValueError('noncanonical positive integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc128_b':
        if not lines or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N')
        n = int(lines[0])
        if not 1 <= n <= 100 or len(lines) != n + 1:
            raise ValueError('N/row count range')
        rows: list[tuple[str, int]] = []
        seen_scores: set[int] = set()
        for line in lines[1:]:
            parts = line.split(' ')
            if len(parts) != 2 or CITY.fullmatch(parts[0]) is None or NONNEG.fullmatch(parts[1]) is None:
                raise ValueError('restaurant row')
            city, score_text = parts
            score = int(score_text)
            if not 0 <= score <= 100 or score in seen_scores:
                raise ValueError('score range/uniqueness')
            seen_scores.add(score)
            rows.append((city, score))
        return rows

    if pid == 'abc129_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and one weight row')
        n = int(lines[0])
        if not 2 <= n <= 100:
            raise ValueError('N range')
        weights = _split_positive(lines[1], n)
        if any(w > 100 for w in weights):
            raise ValueError('weight range')
        return weights

    if len(lines) != 2:
        raise ValueError('expected header and lengths')
    head = _split_positive(lines[0], 2)
    n, x = head
    if not 1 <= n <= 100 or not 1 <= x <= 10000:
        raise ValueError('N/X range')
    lengths = _split_positive(lines[1], n)
    if any(length > 100 for length in lengths):
        raise ValueError('length range')
    return n, x, lengths


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc128_b':
        rows = value
        out_rows = output.split('\n')
        if len(out_rows) != len(rows) or any(POS.fullmatch(row) is None for row in out_rows):
            return False
        actual = list(map(int, out_rows))
        if sorted(actual) != list(range(1, len(rows) + 1)):
            return False
        # Group by city first, then choose the remaining highest score repeatedly.
        # This is intentionally different from the tuple-sort reference solution.
        grouped: dict[str, list[tuple[int, int]]] = {}
        for index, (city, score) in enumerate(rows, 1):
            grouped.setdefault(city, []).append((score, index))
        expected: list[int] = []
        for city in sorted(grouped):
            remaining = grouped[city][:]
            while remaining:
                best = max(range(len(remaining)), key=lambda i: remaining[i][0])
                _, index = remaining.pop(best)
                expected.append(index)
        return actual == expected

    if pid == 'abc129_b':
        if output != '0' and POS.fullmatch(output) is None:
            return False
        weights = value
        candidates = []
        for t in range(1, len(weights)):
            left = sum(weights[:t])
            right = sum(weights[t:])
            candidates.append(abs(left - right))
        return output == str(min(candidates))

    if output != '0' and POS.fullmatch(output) is None:
        return False
    n, x, lengths = value
    positions = [0]
    for i in range(n):
        positions.append(sum(lengths[:i + 1]))
    return output == str(sum(position <= x for position in positions))


def _restaurants(rows: list[tuple[str, int]]) -> str:
    return str(len(rows)) + '\n' + ''.join(f'{city} {score}\n' for city, score in rows)


def _weights(weights: list[int]) -> str:
    return f'{len(weights)}\n' + ' '.join(map(str, weights)) + '\n'


def _bounding(x: int, lengths: list[int]) -> str:
    return f'{len(lengths)} {x}\n' + ' '.join(map(str, lengths)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc128_b':
        fixed = [
            ('sample1', [('khabarovsk',20),('moscow',10),('kazan',50),('kazan',35),('moscow',60),('khabarovsk',40)]),
            ('sample2', [('yakutsk',10),('yakutsk',20),('yakutsk',30),('yakutsk',40),('yakutsk',50),('yakutsk',60),('yakutsk',70),('yakutsk',80),('yakutsk',90),('yakutsk',100)]),
            ('single_zero', [('a',0)]),
            ('single_hundred', [('zzzzzzzzzz',100)]),
            ('two_cities_reverse_input', [('z',0),('a',100)]),
            ('same_city_unsorted', [('tokyo',5),('tokyo',100),('tokyo',0),('tokyo',50)]),
            ('lex_prefixes', [('b',1),('aa',2),('a',3),('ab',4),('aaa',5),('ba',6)]),
            ('mixed_groups', [('z',3),('a',5),('z',7),('a',9),('b',1)]),
            ('length_ten_names', [('aaaaaaaaaa',0),('zzzzzzzzzz',100)]),
            ('score_boundaries', [('c',0),('b',100),('a',50)]),
            ('three_groups', [('c',10),('a',90),('b',30),('a',80),('c',20),('b',40)]),
            ('city_order_dominates_score', [('b',100),('a',0),('c',50)]),
            ('descending_input_cities', [('e',1),('d',2),('c',3),('b',4),('a',5)]),
            ('repeated_city_blocks', [('b',11),('a',12),('b',13),('a',14),('c',15),('c',16)]),
            ('ten_unique_cities', [(chr(ord('a')+i), i) for i in range(10)]),
            ('ten_same_city', [('m', i*10) for i in range(10)]),
            ('mixed_name_lengths', [('abc',21),('ab',22),('a',23),('abcd',24),('b',25)]),
        ]
        for category, rows in fixed:
            add(category, _restaurants(rows))
        add('constraint_max', _restaurants([('a', score) for score in range(100)]))

    elif pid == 'abc129_b':
        fixed = [
            ('sample1', [1,2,3]), ('sample2', [1,3,1,1]),
            ('sample3', [27,23,76,2,3,5,62,52]),
            ('two_equal', [1,1]), ('two_skew_left', [100,1]), ('two_skew_right', [1,100]),
            ('four_equal', [25,25,25,25]), ('odd_equal', [7,7,7]),
            ('ascending', list(range(1,11))), ('descending', list(range(10,0,-1))),
            ('first_heavy', [100,1,1,1,1]), ('last_heavy', [1,1,1,1,100]),
            ('alternating', [100,1,100,1,100,1]), ('exact_middle', [10,20,30,60]),
            ('near_middle', [10,20,31,60]), ('many_ones', [1]*20),
            ('varying', [3,1,4,1,5,9,2,6,5,3]),
        ]
        for category, weights in fixed:
            add(category, _weights(weights))
        add('constraint_max', _weights([100]*100))

    else:
        fixed = [
            ('sample1', 6, [3,4,5]), ('sample2', 9, [3,3,3,3]),
            ('single_exact', 1, [1]), ('single_over', 1, [100]), ('single_large_x', 10000, [100]),
            ('first_exact', 5, [5,1,1]), ('first_over', 4, [5,1,1]),
            ('all_within', 100, [1,2,3,4,5]), ('stop_middle', 6, [2,2,3,1]),
            ('uniform_exact', 9, [3,3,3]), ('uniform_before_exact', 8, [3,3,3]),
            ('many_ones_50', 50, [1]*100), ('many_ones_max_x', 10000, [1]*100),
            ('large_steps_small_x', 1, [100]*10), ('large_steps_exact', 1000, [100]*10),
            ('mixed', 37, [5,10,1,20,2,30]), ('x_one_min_lengths', 1, [1,1,1,1]),
        ]
        for category, x, lengths in fixed:
            add(category, _bounding(x, lengths))
        add('constraint_max', _bounding(10000, [100]*100))

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
