"""Private ABC108--113 D tasks with explicit semantic construction verifiers."""
from __future__ import annotations
from typing import cast
import random,re
TASKS=('arc102_b','abc109_d','abc110_d','arc103_b','abc112_d','abc113_d')
CONTESTS=dict(zip(TASKS,('abc108','abc109','abc110','abc111','abc112','abc113')))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'arc102_b':'semantic','abc109_d':'semantic','arc103_b':'semantic'}
CHECKER_IDS={p:p for p in OUTPUT_MODES}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc102_b':
        require(len(rows)==1,'shape');l=ints(rows[0],1)[0];require(2<=l<=10**6,'paths');return (l,)
    if pid=='abc109_d':
        h,w=ints(rows[0],2);require(1<=h<=500 and 1<=w<=500 and len(rows)==h+1,'shape');a=tuple(ints(row,w) for row in rows[1:]);require(all(0<=v<=9 for row in a for v in row),'coins');return (a,)
    if pid=='abc110_d':
        require(len(rows)==1,'shape');n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=10**9,'product');return n,m
    if pid=='arc103_b':
        n=ints(rows[0],1)[0];require(1<=n<=1000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(-10**9<=v<=10**9 for p in a for v in p),'points');return (a,)
    if pid=='abc112_d':
        require(len(rows)==1,'shape');n,m=ints(rows[0],2);require(1<=n<=100000 and n<=m<=10**9,'partition');return n,m
    require(len(rows)==1,'shape');h,w,k=ints(rows[0],3);require(1<=h<=100 and 1<=w<=8 and 1<=k<=w,'ladder');return h,w,k

def paths_graph(l:int)->str:
    # Binary Horner construction: [0,p) doubles into [0,2p), then a
    # direct source edge supplies the extra singleton for a set binary bit.
    count=1;edges:list[tuple[int,int,int]]=[];n=1
    for bit in bin(l)[3:]:
        nxt=n+1;edges.extend(((n,nxt,0),(n,nxt,count)))
        if bit=='1':edges.append((1,nxt,2*count))
        count=2*count+(bit=='1');n=nxt
    return f'{n} {len(edges)}\n'+''.join(line(edge) for edge in edges).removesuffix('\n')

def paths_valid(l:int,actual:str)->bool:
    try:
        rows=actual.removesuffix('\n').split('\n');n,m=ints(rows[0],2);require(1<=n<=20 and 0<=m<=60 and len(rows)==m+1,'graph shape');graph:list[list[tuple[int,int]]]=[[] for _ in range(n)]
        for row in rows[1:]:
            u,v,w=ints(row,3);require(1<=u<v<=n and 0<=w<=10**6,'graph edge');graph[u-1].append((v-1,w))
        # Polynomial coefficients saturated at2, represented by reachability
        # and duplicate-length bitsets. Out-of-range paths must also propagate.
        mask=(1<<l)-1;reach=[0]*n;duplicates=[0]*n;overflow=[False]*n;reach[0]=1
        for u in range(n):
            for v,w in graph[u]:
                shifted=reach[u]<<w;overflow[v]|=overflow[u] or bool(shifted>>l);incoming=shifted&mask;duplicates[v]|=(duplicates[u]<<w)&mask;duplicates[v]|=reach[v]&incoming;reach[v]|=incoming
        return reach[-1]==mask and duplicates[-1]==0 and not overflow[-1]
    except (ValueError,TypeError,IndexError,OverflowError):return False

def coin_moves(a:tuple[tuple[int,...],...])->str:
    h,w=len(a),len(a[0]);board=[list(row) for row in a];path=[(r,c) for c in range(w) for r in (range(h) if c%2==0 else range(h-1,-1,-1))];moves=[]
    for (r,c),(rr,cc) in zip(path,path[1:]):
        if board[r][c]%2:board[r][c]-=1;board[rr][cc]+=1;moves.append((r+1,c+1,rr+1,cc+1))
    return str(len(moves))+(''+''.join('\n'+' '.join(map(str,move)) for move in moves))

def coins_valid(a:tuple[tuple[int,...],...],actual:str)->bool:
    try:
        h,w=len(a),len(a[0]);rows=actual.removesuffix('\n').split('\n');n=ints(rows[0],1)[0];require(0<=n<=h*w and len(rows)==n+1,'moves shape');board=[list(row) for row in a];chosen:set[tuple[int,int]]=set()
        for row in rows[1:]:
            r,c,rr,cc=ints(row,4);require(1<=r<=h and 1<=rr<=h and 1<=c<=w and 1<=cc<=w and abs(r-rr)+abs(c-cc)==1,'adjacent move');source=(r-1,c-1);require(source not in chosen and board[r-1][c-1]>=1,'unique positive source');chosen.add(source);board[r-1][c-1]-=1;board[rr-1][cc-1]+=1
        return sum(v%2 for row in board for v in row)==sum(v for row in a for v in row)%2
    except (ValueError,TypeError,IndexError):return False

def prime_factors(m:int)->list[tuple[int,int]]:
    factors=[];p=2
    while p*p<=m:
        e=0
        while m%p==0:m//=p;e+=1
        if e:factors.append((p,e))
        p+=1 if p==2 else 2
    if m>1:factors.append((m,1))
    return factors

def divisor_list(m:int)->list[int]:
    divisors=[1]
    for p,e in prime_factors(m):
        old=divisors[:];power=1
        for _ in range(e):power*=p;divisors.extend(d*power for d in old)
    return sorted(divisors)

def product_convolution(n:int,m:int)->int:
    # Dirichlet-convolution exponentiation counts ordered products directly,
    # without prime-exponent stars-and-bars or binomial coefficients.
    divisors=divisor_list(m);index={v:j for j,v in enumerate(divisors)};pairs:list[list[tuple[int,int]]]=[[] for _ in divisors]
    for j,d in enumerate(divisors):
        for i,v in enumerate(divisors):
            if v>d:break
            if d%v==0:pairs[j].append((i,index[d//v]))
    def multiply(a:list[int],b:list[int])->list[int]:return [sum(a[i]*b[k] for i,k in row)%MOD for row in pairs]
    result=[1]+[0]*(len(divisors)-1);base=[1]*len(divisors)
    while n:
        if n&1:result=multiply(result,base)
        n//=2
        if n:base=multiply(base,base)
    return result[-1]

def arms_construct(points:tuple[tuple[int,int],...])->str:
    parity={(x+y)%2 for x,y in points}
    if len(parity)>1:return '-1'
    even=next(iter(parity))==0;lengths=([1] if even else [])+[1<<j for j in range(31)];s=(1<<31)-1;rows=[]
    for x,y in points:
        if even:x-=1
        u=(x+y+s)//2;v=(x-y+s)//2;chars=['R'] if even else []
        for j in range(31):chars.append('R' if u>>j&1 and v>>j&1 else 'U' if u>>j&1 else 'D' if v>>j&1 else 'L')
        rows.append(''.join(chars))
    return f'{len(lengths)}\n'+line(lengths)+'\n'.join(rows)

def arms_valid(points:tuple[tuple[int,int],...],actual:str)->bool:
    try:
        value=actual.removesuffix('\n')
        if value=='-1':return len({(x+y)%2 for x,y in points})>1
        rows=value.split('\n');m=ints(rows[0],1)[0];require(1<=m<=40 and len(rows)==len(points)+2,'arms shape');lengths=ints(rows[1],m);require(all(1<=d<=10**12 for d in lengths),'arm lengths')
        for (x,y),modes in zip(points,rows[2:]):
            require(len(modes)==m and set(modes)<={'L','R','U','D'},'modes');dx=sum(d if ch=='R' else -d if ch=='L' else 0 for d,ch in zip(lengths,modes));dy=sum(d if ch=='U' else -d if ch=='D' else 0 for d,ch in zip(lengths,modes));require((dx,dy)==(x,y),'endpoint')
        return True
    except (ValueError,TypeError,IndexError):return False

def partition_divisors(n:int,m:int)->int:return max(d for d in divisor_list(m) if d<=m//n)

def ladder_matrix(h:int,w:int,k:int)->int:
    # Independent-set Fibonacci counts give the three possible row moves.
    f=[1,2]
    for _ in range(8):f.append(f[-1]+f[-2])
    transition=[[0]*w for _ in range(w)]
    for j in range(w):
        transition[j][j]=f[max(0,j-1)]*f[max(0,w-j-2)]
        if j:transition[j][j-1]=f[max(0,j-2)]*f[max(0,w-j-2)]
        if j+1<w:transition[j][j+1]=f[max(0,j-1)]*f[max(0,w-j-3)]
    def multiply(a:list[list[int]],b:list[list[int]])->list[list[int]]:return [[sum(a[i][s]*b[s][j] for s in range(w))%MOD for j in range(w)] for i in range(w)]
    result=[[int(i==j) for j in range(w)] for i in range(w)]
    while h:
        if h&1:result=multiply(result,transition)
        h//=2
        if h:transition=multiply(transition,transition)
    return result[0][k-1]

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc102_b':return paths_graph(cast(int,data[0]))
    if pid=='abc109_d':return coin_moves(cast(tuple[tuple[int,...],...],data[0]))
    if pid=='abc110_d':return str(product_convolution(*cast(tuple[int,int],data)))
    if pid=='arc103_b':return arms_construct(cast(tuple[tuple[int,int],...],data[0]))
    if pid=='abc112_d':return str(partition_divisors(*cast(tuple[int,int],data)))
    return str(ladder_matrix(*cast(tuple[int,int,int],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='arc102_b':return paths_valid(cast(int,data[0]),actual)
        if pid=='abc109_d':return coins_valid(cast(tuple[tuple[int,...],...],data[0]),actual)
        if pid=='arc103_b':return arms_valid(cast(tuple[tuple[int,int],...],data[0]),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'arc102_b':"l=int(input());n=l.bit_length();edges=[]\nfor j in range(n-1):edges.extend(((j+1,j+2,0),(j+1,j+2,1<<j)))\ncurrent=1<<(n-1)\nfor j in range(n-2,-1,-1):\n if l>>j&1:edges.append((j+1,n,current));current+=1<<j\nprint(n,len(edges))\nfor edge in edges:print(*edge)\n",
'abc109_d':"h,w=map(int,input().split());a=[list(map(int,input().split())) for _ in range(h)];path=[(r,c) for r in range(h) for c in (range(w) if r%2==0 else range(w-1,-1,-1))];moves=[]\nfor (r,c),(rr,cc) in zip(path,path[1:]):\n if a[r][c]%2:a[r][c]-=1;a[rr][cc]+=1;moves.append((r+1,c+1,rr+1,cc+1))\nprint(len(moves))\nfor move in moves:print(*move)\n",
'abc110_d':"from math import comb\nn,m=map(int,input().split());p=2;ans=1\nwhile p*p<=m:\n exponent=0\n while m%p==0:m//=p;exponent+=1\n if exponent:ans=ans*comb(n+exponent-1,exponent)%1000000007\n p+=1\nif m>1:ans=ans*n%1000000007\nprint(ans)\n",
'arc103_b':"n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];parity={(x+y)%2 for x,y in points}\nif len(parity)>1:print(-1)\nelse:\n even=next(iter(parity))==0;lengths=([1] if even else [])+[1<<j for j in range(30,-1,-1)];print(len(lengths));print(*lengths)\n for x,y in points:\n  modes='R' if even else ''\n  if even:x-=1\n  for d in lengths[int(even):]:\n   if abs(x)>=abs(y):\n    if x>=0:modes+='R';x-=d\n    else:modes+='L';x+=d\n   else:\n    if y>=0:modes+='U';y-=d\n    else:modes+='D';y+=d\n  print(modes)\n",
'abc112_d':"from math import isqrt\nn,m=map(int,input().split());answer=1\nfor d in range(1,isqrt(m)+1):\n if m%d==0:\n  if d*n<=m:answer=max(answer,d)\n  if (m//d)*n<=m:answer=max(answer,m//d)\nprint(answer)\n",
'abc113_d':"h,w,k=map(int,input().split());patterns=[m for m in range(1<<(w-1)) if not m&(m<<1)];dp=[1]+[0]*(w-1)\nfor _ in range(h):\n nxt=[0]*w\n for mask in patterns:\n  for j in range(w):\n   dest=j-1 if j and mask>>(j-1)&1 else j+1 if j+1<w and mask>>j&1 else j;nxt[dest]=(nxt[dest]+dp[j])%1000000007\n dp=nxt\nprint(dp[k-1])\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18400+TASKS.index(pid));raws:list[str]=[]
    if pid=='arc102_b':raws=[f'{l}\n' for l in (2,3,4,5,7,8,9,15,16,17,255,256,257,524287,524288,524289,999999,1000000)]
    elif pid=='abc109_d':
        def grid(a:list[list[int]])->str:return f'{len(a)} {len(a[0])}\n'+''.join(line(row) for row in a)
        raws=[grid([[0]]),grid([[1]]),grid([[9]]),grid([[1,1]]),grid([[1],[0]]),grid([[9]*5])]
        for h in range(2,12):raws.append(grid([[rng.randrange(10) for _ in range(h+1)] for _ in range(h)]))
        a=[[8]*500 for _ in range(500)];a[0][0]=1;raws+=[grid(a),grid([[9]*500 for _ in range(500)])]
    elif pid=='abc110_d':raws=[f'{n} {m}\n' for n,m in ((1,1),(1,10**9),(2,1),(2,6),(3,12),(100000,1),(1,999999937),(2,999999937),(3,1<<29),(100000,1<<29),(2,73513440),(100000,73513440),(3,963460800),(100000,963460800),(99999,999999999),(100000,999999999),(99999,10**9),(100000,10**9))]
    elif pid=='arc103_b':
        def points(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
        raws=[points([(0,0)]),points([(1,0)]),points([(0,1)]),points([(-1,0)]),points([(0,0),(1,0)]),points([(1,1),(1,1)]),points([(10**9,10**9)]),points([(-10**9,-10**9)]),points([(10**9,10**9-1)])]
        for n in range(2,9):
            a=[(rng.randint(-10**9,10**9),rng.randint(-10**9,10**9)) for _ in range(n)];parity=n%2;a=[(x,y if (x+y)%2==parity else y+1 if y<10**9 else y-1) for x,y in a];raws.append(points(a))
        raws+=[points([(10**9,-10**9)]*999+[(0,1)]),points([(10**9 if j%2 else -10**9,10**9 if j%3 else -10**9) for j in range(1000)])]
    elif pid=='abc112_d':raws=[f'{n} {m}\n' for n,m in ((1,1),(1,10**9),(2,2),(2,3),(3,14),(10,123),(100000,100000),(99999,100000),(2,999999937),(100000,999999937),(1,73513440),(100000,73513440),(2,963460800),(100000,963460800),(99999,999999999),(100000,999999999),(99999,10**9),(100000,10**9))]
    else:raws=[f'{h} {w} {k}\n' for h,w,k in ((1,1,1),(100,1,1),(1,2,1),(1,2,2),(1,3,1),(1,3,2),(1,3,3),(2,3,3),(2,3,1),(7,1,1),(15,8,5),(99,8,1),(99,8,8),(100,2,2),(100,7,4),(100,8,1),(100,8,7),(100,8,8))]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'arc102_b':('2本の辺の選択で、連続した範囲のパス長を作れます。','0と2^jの長さの辺を連ねると0から2^k-1までを一度ずつ作れます。Lの残りを2進数のブロックに分け、途中から終点への辺を追加します。','疑似コード: N=bit_length(L); i→i+1に重み0,2^(i-1)を追加; base=2^(N-1); Lの残りのsetbit jを降順に見てj+1→Nへ重みbaseを追加; base+=2^j; グラフを出力。'),
'abc109_d':('奇数枚のマスから隣へ1枚渡すと、そのマスは偶数になります。','全マスを行方向に蛇行する順序に並べ、最後以外の奇数マスから次のマスへ1枚渡します。各マスを移動元に選ぶのは一度だけです。','疑似コード: 行ごとに向きを反転してpathを作る; 連続するu,vについてa[u]が奇数ならa[u]--,a[v]++,操作(u,v)を記録; 操作数と操作列を出力。'),
'abc110_d':('Mの各素因数の指数をN個の要素へ分配します。','素因数pの指数がeなら、非負整数N個の和がeとなる分け方はC(N+e-1,e)通りです。各素因数は独立なので掛け合わせます。','疑似コード: Mを試し割りで素因数分解; answer=1; 各指数eに対してanswer*=comb(N+e-1,e) mod1e9+7; answerを出力。'),
'arc103_b':('同じ腕の長さなら、到達点のX+Yの偶奇は全て同じになります。','偶奇が混在したら不可能です。統一できる場合は2^30から1までの腕を使い、残り座標の絶対値が大きい軸へ向けます。偶数の点には長さ1の腕を先頭に足します。','疑似コード: parity混在なら-1; evenなら先頭腕1をRにしてX--; 残り腕を2^30..1; 各dでabs(X)>=abs(Y)ならXの符号方向へ進みXを更新、他はYを更新; 共通の腕と各モード文字列を出力。'),
'abc112_d':('最大公約数gはMの約数であり、全要素がg以上なのでN*g<=Mです。','この二条件を満たす約数なら、N-1個をg、残りをM-(N-1)gとすれば実現できます。','疑似コード: d=1..isqrt(M)についてM%d==0ならd,M/dを候補にする; N*候補<=Mの最大候補を出力。'),
'abc113_d':('一段の横棒の置き方は、隣り合う横棒がないビット列で表せます。','Wは8以下なので一段の有効な全マスクを列挙できます。現在の縦線の位置を状態にし、H段の遷移を繰り返します。','疑似コード: mask&(mask<<1)==0の全maskを列挙; dp[0]=1; H回、各mask/現在列jの左棒ならj-1、右棒ならj+1、他ならjへdp[j]を加算mod; dp[K-1]を出力。')}

TITLES={'arc102_b': 'All Your Paths are Different Lengths', 'abc109_d': 'Make Them Even', 'abc110_d': 'Factorization', 'arc103_b': 'Robot Arms', 'abc112_d': 'Partition', 'abc113_d': 'Number of Amidakuji'}
PUBLISHED_SAMPLES={'arc102_b': [{'input': '4\n', 'expected': '8 10\n1 2 0\n2 3 0\n3 4 0\n1 5 0\n2 6 0\n3 7 0\n4 8 0\n5 6 1\n6 7 1\n7 8 1\n'}, {'input': '5\n', 'expected': '5 7\n1 2 0\n2 3 1\n3 4 0\n4 5 0\n2 4 0\n1 3 3\n3 5 1\n'}], 'abc109_d': [{'input': '2 3\n1 2 3\n0 1 1\n', 'expected': '3\n2 2 2 3\n1 1 1 2\n1 3 1 2\n'}, {'input': '3 2\n1 0\n2 1\n1 0\n', 'expected': '3\n1 1 1 2\n1 2 2 2\n3 1 3 2\n'}, {'input': '1 5\n9 9 9 9 9\n', 'expected': '2\n1 1 1 2\n1 3 1 4\n'}], 'abc110_d': [{'input': '2 6\n', 'expected': '4\n'}, {'input': '3 12\n', 'expected': '18\n'}, {'input': '100000 1000000000\n', 'expected': '957870001\n'}], 'arc103_b': [{'input': '3\n-1 0\n0 3\n2 -1\n', 'expected': '2\n1 2\nRL\nUU\nDR\n'}, {'input': '5\n0 0\n1 0\n2 0\n3 0\n4 0\n', 'expected': '-1\n'}, {'input': '2\n1 1\n1 1\n', 'expected': '2\n1 1\nRU\nUR\n'}, {'input': '3\n-7 -3\n7 3\n-3 -7\n', 'expected': '5\n3 1 4 1 5\nLRDUL\nRDULR\nDULRD\n'}], 'abc112_d': [{'input': '3 14\n', 'expected': '2\n'}, {'input': '10 123\n', 'expected': '3\n'}, {'input': '100000 1000000000\n', 'expected': '10000\n'}], 'abc113_d': [{'input': '1 3 2\n', 'expected': '1\n'}, {'input': '1 3 1\n', 'expected': '2\n'}, {'input': '2 3 3\n', 'expected': '1\n'}, {'input': '2 3 1\n', 'expected': '5\n'}, {'input': '7 1 1\n', 'expected': '1\n'}, {'input': '15 8 5\n', 'expected': '437760187\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
