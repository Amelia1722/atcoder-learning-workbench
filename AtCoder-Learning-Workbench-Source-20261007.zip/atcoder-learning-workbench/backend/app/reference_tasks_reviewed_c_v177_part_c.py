"""Private reviewed C tasks: group deletion, intervals and offline dominance."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import Counter
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(455,461))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==455:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=k<=n<=300000 and all(1<=v<=10**9 for v in a),'domain');return k,a
    if number in (456,458):
        require(len(rows)==1 and re.fullmatch('[abc]+' if number==456 else '[A-Z]+',rows[0]) is not None,'letters');s=rows[0];require(len(s)<= (300000 if number==456 else 500000),'length');return (s,)
    if number==457:
        n,k=ints(rows[0],2);require(1<=n<=200000 and len(rows)==n+2,'shape');a=[];total=0
        for row in rows[1:-1]:
            values=ints(row);length=values[0];require(1<=length<=200000 and len(values)==length+1 and all(1<=v<=10**9 for v in values[1:]),'sequence');a.append(values[1:]);total+=length
        c=ints(rows[-1],n);require(total<=200000 and all(1<=v<=10**9 for v in c) and 1<=k<=sum(len(v)*count for v,count in zip(a,c)),'total/index');return k,tuple(a),c
    if number==459:
        n,q=ints(rows[0],2);require(1<=n<=300000 and 1<=q<=300000 and len(rows)==q+1,'shape');queries=tuple(ints(row,2) for row in rows[1:]);require(all(t in (1,2) and 1<=v<=(n if t==1 else 300000) for t,v in queries) and any(t==2 for t,v in queries),'queries');return n,queries
    require(len(rows)==3,'shape');n,m=ints(rows[0],2);a=ints(rows[1],n);b=ints(rows[2],m);require(1<=n<=200000 and 1<=m<=200000 and all(1<=v<=10**9 for v in a+b),'domain');return a,b
class Fenwick:
    def __init__(self,n:int)->None:self.tree=[0]*(n+1)
    def add(self,j:int,v:int)->None:
        while j<len(self.tree):self.tree[j]+=v;j+=j&-j
    def prefix(self,j:int)->int:
        total=0
        while j>0:total+=self.tree[j];j-=j&-j
        return total
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==455:
        k,a=cast(tuple[int,tuple[int,...]],data);masses=[v*c for v,c in Counter(a).items()];total=sum(masses)
        if k>=len(masses):return '0'
        lo,hi=1,max(masses)
        while lo<hi:
            mid=(lo+hi+1)//2
            if sum(v>=mid for v in masses)>=k:lo=mid
            else:hi=mid-1
        removed=sum(v for v in masses if v>lo)+lo*(k-sum(v>lo for v in masses));return str(total-removed)
    if number==456:
        s=cast(str,data[0]);breaks=[0]+[j for j in range(1,len(s)) if s[j]==s[j-1]]+[len(s)];return str(sum((r-l)*(r-l+1)//2 for l,r in zip(breaks,breaks[1:]))%998244353)
    if number==457:
        k,a,c=cast(tuple[int,tuple[tuple[int,...],...],tuple[int,...]],data);prefix=[0]
        for values,count in zip(a,c):prefix.append(prefix[-1]+len(values)*count)
        j=bisect_left(prefix,k)-1;return str(a[j][(k-prefix[j]-1)%len(a[j])])
    if number==458:
        s=cast(str,data[0]);prefix=[0]
        for v in s:prefix.append(prefix[-1]+(v=='C'))
        return str(sum(prefix[len(s)-radius]-prefix[radius] for radius in range((len(s)+1)//2)))
    if number==459:
        n,queries=cast(tuple[int,tuple[tuple[int,int],...]],data);size=1
        while size<n:size*=2
        minimum=[10**9]*(2*size)
        for j in range(n):minimum[size+j]=0
        for j in range(size-1,0,-1):minimum[j]=min(minimum[2*j],minimum[2*j+1])
        heights=[0]*n;events=[];asks=[]
        for time,(kind,v) in enumerate(queries,1):
            if kind==1:
                old=heights[v-1];heights[v-1]+=1;new=old+1;events.extend(((old,time,-1),(new,time,1)));j=size+v-1;minimum[j]=new
                while j>1:j//=2;minimum[j]=min(minimum[2*j],minimum[2*j+1])
            else:asks.append((minimum[1]+v,time,len(asks)))
        events.sort(reverse=True);asks.sort(reverse=True);tree=Fenwick(len(queries));out=[0]*len(asks);p=0
        for threshold,time,index in asks:
            while p<len(events) and events[p][0]>=threshold:
                height,eventtime,delta=events[p];tree.add(eventtime,delta);p+=1
            out[index]=tree.prefix(time)
        return '\n'.join(map(str,out))
    a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);rice=sorted(a);toppings=sorted(b,reverse=True);deficit=max(0,len(b)-len(a))
    for j,v in enumerate(toppings,1):deficit=max(deficit,j-(len(a)-bisect_left(rice,(v+1)//2)))
    return str(len(b)-deficit)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc455_c':"from collections import Counter\nn,k=map(int,input().split());a=list(map(int,input().split()));m=sorted((v*c for v,c in Counter(a).items()),reverse=True);print(sum(m[k:]))\n",
'abc456_c':"s=input();answer=length=0;previous=''\nfor v in s:\n length=length+1 if v!=previous else 1;answer=(answer+length)%998244353;previous=v\nprint(answer)\n",
'abc457_c':"n,k=map(int,input().split());a=[]\nfor _ in range(n):row=list(map(int,input().split()));a.append(row[1:])\nc=list(map(int,input().split()))\nfor values,count in zip(a,c):\n length=len(values)*count\n if k<=length:print(values[(k-1)%len(values)]);break\n k-=length\n",
'abc458_c':"s=input();print(sum(min(j+1,len(s)-j) for j,v in enumerate(s) if v=='C'))\n",
'abc459_c':"n,q=map(int,input().split());height=[0]*n;freq=[0]*(q+2);freq[0]=n;tree=[0]*(q+3);minimum=0\ndef add(j,v):\n j+=1\n while j<len(tree):tree[j]+=v;j+=j&-j\ndef prefix(j):\n total=0\n while j>0:total+=tree[j];j-=j&-j\n return total\nadd(0,n)\nfor _ in range(q):\n kind,v=map(int,input().split())\n if kind==1:\n  j=v-1;old=height[j];height[j]+=1;freq[old]-=1;freq[old+1]+=1;add(old,-1);add(old+1,1)\n  while freq[minimum]==0:minimum+=1\n else:print(n-prefix(min(q+2,minimum+v)))\n",
'abc460_c':"n,m=map(int,input().split());a=sorted(map(int,input().split()));b=sorted(map(int,input().split()));j=0\nfor v in a:\n if j<m and b[j]<=2*v:j+=1\nprint(j)\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17700+number)
    if number==455:
        def vanish(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[vanish(k,a) for k,a in ((1,[1]),(2,[1,1]),(1,[1,2]),(2,[1,1,3]))];raws.extend(vanish(rng.randint(1,n),[rng.randint(1,10) for _ in range(n)]) for n in range(3,15));raws.extend([vanish(1,list(range(1,300001))),vanish(300000,[10**9]*300000)])
    elif number==456:
        raws=[s+'\n' for s in ('a','aa','abc','aba')];raws.extend(''.join(rng.choice('abc') for _ in range(n))+'\n' for n in range(5,17));raws.extend(['a'*300000+'\n','abc'*100000+'\n'])
    elif number==457:
        def sequence(k:int,a:list[list[int]],c:list[int])->str:return f'{len(a)} {k}\n'+''.join(f'{len(v)} '+line(v) for v in a)+line(c)
        raws=[sequence(k,a,c) for k,a,c in ((1,[[1]],[1]),(2,[[1,2]],[1]),(3,[[1,2]],[2]),(3,[[1],[2],[3]],[1,1,1]))]
        for n in range(3,15):
            a=[[rng.randint(1,100) for _ in range(rng.randint(1,5))] for _ in range(n)];c=[rng.randint(1,9) for _ in range(n)];raws.append(sequence(rng.randint(1,sum(len(v)*count for v,count in zip(a,c))),a,c))
        raws.extend([sequence(200000*10**9,[[10**9]*200000],[10**9]),sequence(200000*10**9,[[10**9]]*200000,[10**9]*200000)])
    elif number==458:
        raws=[s+'\n' for s in ('A','C','CCC','ACA')];raws.extend(''.join(rng.choice('ABCZ') for _ in range(n))+'\n' for n in range(5,17));raws.extend(['A'*249999+'C'+'A'*250000+'\n','C'*500000+'\n'])
    elif number==459:
        def blocks(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{t} {v}\n' for t,v in a)
        raws=[blocks(n,a) for n,a in ((1,[(2,1)]),(1,[(1,1),(2,1)]),(2,[(1,1),(2,1)]),(2,[(1,1),(1,2),(2,1)]))]
        for n in range(3,15):
            a=[(1,rng.randint(1,n)) if rng.randrange(2) else (2,rng.randint(1,20)) for _ in range(50)]+[(2,300000)];raws.append(blocks(n,a))
        raws[15]=blocks(2,[(1,1)]*299999+[(2,1)]);raws.extend([blocks(150000,[(1,j) for j in range(1,150001)]+[(2,1)]*150000),blocks(300000,[(2,300000)]*300000)])
    else:
        def sushi(a:list[int],b:list[int])->str:return f'{len(a)} {len(b)}\n'+line(a)+line(b)
        raws=[sushi(a,b) for a,b in (([1],[1]),([1],[3]),([1],[2]),([1,2],[3,4]))];raws.extend(sushi([rng.randint(1,100) for _ in range(n)],[rng.randint(1,200) for _ in range(n+1)]) for n in range(3,15));raws.extend([sushi([1]*200000,[10**9]*200000),sushi([10**9]*200000,[10**9]*200000)])
    require(len(raws)==len(set(raws))==18,'unique');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc455_c':('同じ値は一度の操作ですべて0になります。','値ごとの合計寄与を数え、大きいK種類を消します。種類がK以下なら全て消せます。','疑似コード: Counter(A); masses=降順sort(value*count); masses[K:]の合計を出力。'),
'abc456_c':('異なる隣接文字が続く間は、有効な末尾部分文字列が1つずつ増えます。','直前と同じ文字なら有効な末尾長を1へ戻し、それ以外は1増やします。','疑似コード: length=0; 各文字cで length=(前文字と異なるならlength+1、同じなら1); answer+=length を998244353で剰余。'),
'abc457_c':('非常に長いBを実際に作る必要はありません。','各Aiのブロック長はLi*Ciです。Kの属するブロックを探し、Liで割った余りを使います。','疑似コード: i順に length=Li*Ci; K>lengthならK-=length; それ以外ならAi[(K-1)%Li]を出力して終了。'),
'abc458_c':('中央のCを決めると、左右へ同じ長さだけ伸ばせます。','添字i（0開始）を中央とする部分文字列の数はmin(i+1,N-i)です。','疑似コード: answer=0; 全iでS[i]=Cならanswer+=min(i+1,N-i); answerを出力。'),
'abc459_c':('全マスから引いた回数を別に持つと、高さの一斉更新を避けられます。','追加回数の最小値が除去回数です。高さ別人数をFenwickで持ち、y+最小値以上の人数を求めます。','疑似コード: 列追加時に高さ別freqとFenwickを更新; freq[min]=0の間min++; 問合せはN-Fenwickの高さ<y+minの人数。'),
'abc460_c':('軽いネタから使い、各シャリに載る最も軽い未使用ネタを選びます。','双方を昇順に並べ、ネタの重さが2*A以下なら組を作ります。','疑似コード: A,B昇順sort; j=0; 各aでj<MかつB[j]<=2*aならj++; 最後jを出力。')}

TITLES={'abc455_c': 'Vanish', 'abc456_c': 'Not Adjacent', 'abc457_c': 'Long Sequence', 'abc458_c': 'C Stands for Center', 'abc459_c': 'Drop Blocks', 'abc460_c': 'Sushi'}
PUBLISHED_SAMPLES={'abc455_c': [{'input': '6 2\n7 2 7 2 2 9\n', 'expected': '6\n'}, {'input': '8 6\n1 2 3 4 1 2 3 4\n', 'expected': '0\n'}, {'input': '10 2\n3 3 4 1 1 3 3 1 5 1\n', 'expected': '8\n'}], 'abc456_c': [{'input': 'abbc\n', 'expected': '6\n'}, {'input': 'cabcabcbcaccacbcbcaabacbacaabccacbccbcacbacbacabcacabcaccaaaaabababcbabacaccabbcacbcbcbcababcbcbabca\n', 'expected': '760\n'}], 'abc457_c': [{'input': '3 9\n3 1 3 2\n1 3\n2 4 3\n1 3 2\n', 'expected': '4\n'}, {'input': '3 1\n1 7\n1 111\n1 5\n1 100 10000\n', 'expected': '7\n'}, {'input': '3 3163812\n5 1 2 3 4 5\n4 9 8 7 6\n2 10 11\n87043 908415 9814\n', 'expected': '9\n'}], 'abc458_c': [{'input': 'ABCCA\n', 'expected': '5\n'}, {'input': 'XYZ\n', 'expected': '0\n'}, {'input': 'SMBCPROGRAMMINGCONTEST\n', 'expected': '11\n'}], 'abc459_c': [{'input': '3 7\n1 1\n1 3\n1 3\n2 1\n2 2\n1 2\n2 1\n', 'expected': '2\n1\n1\n'}], 'abc460_c': [{'input': '4 5\n4 2 1 8\n14 9 3 2 9\n', 'expected': '3\n'}, {'input': '3 3\n5 5 3\n11 1000 1000\n', 'expected': '0\n'}, {'input': '8 7\n2 3 4 4 4 3 2 3\n8 5 5 9 9 7 1\n', 'expected': '5\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
