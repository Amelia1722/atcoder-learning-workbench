"""Statement-checked three-stage hints for ABC188–190 B."""
HINTS_V110={
 'abc188_b':(
  '2つのベクトルが直交する条件は、各成分の積を全部足した内積が0になることです。',
  'zip(A, B)で対応する要素を組にし、a*bを合計します。Nは最大10^5なので1回走査で十分です。',
  '疑似コード:\nans = 0\nfor i = 0..N-1:\n  ans += A[i] * B[i]\nprint("Yes" if ans == 0 else "No")',
 ),
 'abc189_b':(
  'アルコール量は V_i × P_i / 100 ml ですが、小数を使わず両辺を100倍すると安全です。',
  '累積値sumをΣ(V_i×P_i)として持ち、各杯の後に sum > 100×X ならその1-indexedの杯番号を出します。「等しい」だけでは酔いません。',
  '疑似コード:\nlimit = 100 * X\nsum = 0\nfor i = 1..N:\n  sum += V[i] * P[i]\n  if sum > limit:\n    print(i); 終了\nprint(-1)',
 ),
 'abc190_b':(
  'ダメージを与えられる呪文は「詠唱時間がS未満」かつ「威力がDより大きい」の両方を満たす必要があります。',
  '各呪文を1回ずつ見て X_i < S and Y_i > D を満たすものが1つでもあればYesです。境界のSちょうど・Dちょうどは不可です。',
  '疑似コード:\nfor (X, Y) in spells:\n  if X < S and Y > D:\n    print("Yes"); 終了\nprint("No")',
 ),
}
