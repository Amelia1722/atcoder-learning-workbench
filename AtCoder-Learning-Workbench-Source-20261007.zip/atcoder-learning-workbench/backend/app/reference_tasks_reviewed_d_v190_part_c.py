"""Private ABC216..221 D reviewed exact domains and independent algorithms."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import Counter
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(216,222))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
MOD=998244353
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');v=tuple(map(int,row.split(' ')));require(n is None or len(v)==n,'fields');return v
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc216_d':
        n,m=ints(rows[0],2);require(1<=n<=200000 and 2<=m<=200000 and len(rows)==2*m+1,'N/M/shape');tubes=[];frequency=Counter()
        for j in range(m):
            size=ints(rows[1+2*j],1)[0];require(1<=size<=2*n,'size');tube=ints(rows[2+2*j],size);require(all(1<=v<=n for v in tube),'color');frequency.update(tube);tubes.append(tube)
        require(len(frequency)==n and all(v==2 for v in frequency.values()),'exactly2 of eachcolor');return n,tuple(tubes)
    if pid=='abc217_d':
        length,q=ints(rows[0],2);require(1<=length<=10**9 and 1<=q<=200000 and len(rows)==q+1,'shape');queries=tuple(ints(row,2) for row in rows[1:]);cuts:set[int]=set()
        for kind,x in queries:
            require(kind in (1,2) and 1<=x<length and x not in cuts,'uncut query')
            if kind==1:cuts.add(x)
        return length,queries
    if pid=='abc218_d':
        n=ints(rows[0],1)[0];require(4<=n<=2000 and len(rows)==n+1,'shape');points=tuple(ints(row,2) for row in rows[1:]);require(len(set(points))==n and all(0<=x<=10**9 and 0<=y<=10**9 for x,y in points),'distinct coordinates');return (points,)
    if pid=='abc219_d':
        n=ints(rows[0],1)[0];require(1<=n<=300 and len(rows)==n+2,'N/shape');x,y=ints(rows[1],2);boxes=tuple(ints(row,2) for row in rows[2:]);require(1<=x<=300 and 1<=y<=300 and all(1<=a<=300 and 1<=b<=300 for a,b in boxes),'range');return x,y,boxes
    if pid=='abc220_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=100000 and all(0<=v<=9 for v in a),'range');return (a,)
    n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');intervals=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<=10**9 and 1<=b<=10**9 for a,b in intervals),'range');return (intervals,)

def balls_precedence(n:int,tubes:tuple[tuple[int,...],...])->bool:
    graph:list[list[int]]=[[] for _ in range(n)];incoming=[0]*n
    for tube in tubes:
        for above,below in zip(tube,tube[1:]):graph[above-1].append(below-1);incoming[below-1]+=1
    queue=[j for j,d in enumerate(incoming) if d==0]
    for color in queue:
        for next_color in graph[color]:
            incoming[next_color]-=1
            if incoming[next_color]==0:queue.append(next_color)
    return len(queue)==n

def wood_reverse_union(length:int,queries:tuple[tuple[int,...],...])->list[int]:
    cuts=[0]+sorted(x for kind,x in queries if kind==1)+[length];parent=list(range(len(cuts)-1));sizes=[v-u for u,v in zip(cuts,cuts[1:])]
    def root(j:int)->int:
        while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
        return j
    answers=[]
    for kind,x in reversed(queries):
        if kind==2:answers.append(sizes[root(bisect_right(cuts,x)-1)])
        else:
            j=bisect_left(cuts,x);left,right=root(j-1),root(j);parent[right]=left;sizes[left]+=sizes[right]
    return answers[::-1]

def rectangles_ypairs(points:tuple[tuple[int,...],...])->int:
    columns:dict[int,list[int]]={}
    for x,y in points:columns.setdefault(x,[]).append(y)
    if len(columns)<2:return 0
    seen:Counter[tuple[int,int]]=Counter();answer=0
    for ys in columns.values():
        ys.sort()
        for j,y in enumerate(ys):
            for other in ys[j+1:]:pair=(y,other);answer+=seen[pair];seen[pair]+=1
    return answer

def lunch_cardinality(x:int,y:int,boxes:tuple[tuple[int,...],...])->int:
    if sum(a for a,b in boxes)<x or sum(b for a,b in boxes)<y:return -1
    # dp[count][capped taiyaki] maximises takoyaki, unlike minimum count at two food axes.
    dp=[[-1]*(y+1) for _ in range(len(boxes)+1)];dp[0][0]=0
    for index,(a,b) in enumerate(boxes):
        for count in range(index+1,0,-1):
            source=dp[count-1];target=dp[count]
            for taiyaki,takoyaki in enumerate(source):
                if takoyaki>=0:
                    next_y=min(y,taiyaki+b);target[next_y]=max(target[next_y],takoyaki+a)
    return next(count for count,row in enumerate(dp) if row[y]>=x)

def operations_backward(a:tuple[int,...])->list[int]:
    matrix=[[int(start==end) for end in range(10)] for start in range(10)]
    for digit in reversed(a[1:]):
        matrix=[[(left+right)%MOD for left,right in zip(matrix[(start+digit)%10],matrix[(start*digit)%10])] for start in range(10)]
    return matrix[a[0]]

def login_heap(intervals:tuple[tuple[int,...],...])->list[int]:
    starts=sorted((a,a+b) for a,b in intervals);cursor=0;active:list[int]=[];previous=starts[0][0];histogram=[0]*(len(intervals)+1)
    while cursor<len(starts) or active:
        next_start=starts[cursor][0] if cursor<len(starts) else 10**20;next_end=active[0] if active else 10**20;day=min(next_start,next_end);histogram[len(active)]+=day-previous
        while active and active[0]==day:heapq.heappop(active)
        while cursor<len(starts) and starts[cursor][0]==day:heapq.heappush(active,starts[cursor][1]);cursor+=1
        previous=day
    return histogram[1:]

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc216_d':return 'Yes' if balls_precedence(*cast(tuple[int,tuple[tuple[int,...],...]],data)) else 'No'
    if pid=='abc217_d':return '\n'.join(map(str,wood_reverse_union(*cast(tuple[int,tuple[tuple[int,...],...]],data))))
    if pid=='abc218_d':return str(rectangles_ypairs(cast(tuple[tuple[int,...],...],data[0])))
    if pid=='abc219_d':return str(lunch_cardinality(*cast(tuple[int,int,tuple[tuple[int,...],...]],data)))
    if pid=='abc220_d':return '\n'.join(map(str,operations_backward(cast(tuple[int,...],data[0]))))
    return ' '.join(map(str,login_heap(cast(tuple[tuple[int,...],...],data[0]))))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc216_d':"from collections import deque\nn,m=map(int,input().split());tubes=[]\nfor _ in range(m):k=int(input());tubes.append(list(map(int,input().split())))\nposition=[0]*m;visible=[[] for _ in range(n+1)];queue=deque()\nfor j,tube in enumerate(tubes):\n visible[tube[0]].append(j)\n if len(visible[tube[0]])==2:queue.append(tube[0])\nremoved=0\nwhile queue:\n color=queue.popleft();removed+=1\n for j in visible[color]:\n  position[j]+=1\n  if position[j]<len(tubes[j]):\n   nextcolor=tubes[j][position[j]];visible[nextcolor].append(j)\n   if len(visible[nextcolor])==2:queue.append(nextcolor)\nprint('Yes' if removed==n else 'No')\n",
'abc217_d':"from bisect import bisect_left\nl,q=map(int,input().split());queries=[tuple(map(int,input().split())) for _ in range(q)];coordinates=sorted({0,l}|{x for c,x in queries});index={v:j+1 for j,v in enumerate(coordinates)};tree=[0]*(len(coordinates)+1)\ndef add(j):\n while j<len(tree):tree[j]+=1;j+=j&-j\ndef prefix(j):\n total=0\n while j:total+=tree[j];j-=j&-j\n return total\ndef kth(k):\n j=0;step=1<<(len(tree).bit_length()-1)\n while step:\n  nextj=j+step\n  if nextj<len(tree) and tree[nextj]<k:k-=tree[nextj];j=nextj\n  step//=2\n return coordinates[j]\nadd(index[0]);add(index[l])\nfor kind,x in queries:\n if kind==1:add(index[x])\n else:\n  left_count=prefix(index[x]-1);print(kth(left_count+1)-kth(left_count))\n",
'abc218_d':"n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];lookup=set(points);answer=0\nfor j,(x,y) in enumerate(points):\n for xx,yy in points[j+1:]:\n  if x!=xx and y!=yy and (x,yy) in lookup and (xx,y) in lookup:answer+=1\nprint(answer//2)\n",
'abc219_d':"n=int(input());x,y=map(int,input().split());boxes=[tuple(map(int,input().split())) for _ in range(n)];dp=[[1000]*(y+1) for _ in range(x+1)];dp[0][0]=0\nfor a,b in boxes:\n for i in range(x,-1,-1):\n  for j in range(y,-1,-1):\n   if dp[i][j]<1000:\n    ni=min(x,i+a);nj=min(y,j+b);dp[ni][nj]=min(dp[ni][nj],dp[i][j]+1)\nprint(dp[x][y] if dp[x][y]<1000 else -1)\n",
'abc220_d':"n=int(input());a=list(map(int,input().split()));mod=998244353;dp=[0]*10;dp[a[0]]=1\nfor digit in a[1:]:\n nextdp=[0]*10\n for value,count in enumerate(dp):nextdp[(value+digit)%10]+=count;nextdp[(value*digit)%10]+=count\n dp=[v%mod for v in nextdp]\nprint(*dp,sep='\\n')\n",
'abc221_d':"from collections import defaultdict\nn=int(input());events=defaultdict(int)\nfor _ in range(n):a,b=map(int,input().split());events[a]+=1;events[a+b]-=1\nanswer=[0]*(n+1);current=0;previous=0\nfor day in sorted(events):answer[current]+=day-previous;current+=events[day];previous=day\nprint(*answer[1:])\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(19000+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc216_d':
        def tubes(n:int,a:list[list[int]])->str:return f'{n} {len(a)}\n'+''.join(f'{len(tube)}\n'+line(tube) for tube in a)
        raws=[tubes(1,[[1],[1]]),tubes(2,[[1,2],[1,2]]),tubes(2,[[1,2],[2,1]]),tubes(2,[[1,1],[2],[2]])]
        for n in range(3,15):
            balls=[j for j in range(1,n+1) for _ in range(2)];rng.shuffle(balls);m=rng.randint(2,2*n);cuts=[0]+sorted(rng.sample(range(1,2*n),m-1))+[2*n];raws.append(tubes(n,[balls[u:v] for u,v in zip(cuts,cuts[1:])]))
        raws += [tubes(200000,[list(range(1,200001))]*2),tubes(200000,[[j,j+1] for j in range(1,200000,2) for _ in range(2)])]
    elif pid=='abc217_d':
        def wood(l:int,q:list[tuple[int,int]])->str:return f'{l} {len(q)}\n'+''.join(line(v) for v in q)
        raws=[wood(2,[(2,1)]),wood(2,[(1,1)]),wood(3,[(2,1),(1,1),(2,2)]),wood(10**9,[(1,1),(2,2),(1,999999999)])]
        for n in range(3,15):
            length=n*10;cutset=set();queries=[]
            for _ in range(n):available=[x for x in range(1,length) if x not in cutset];x=rng.choice(available);kind=rng.randint(1,2);queries.append((kind,x));cutset.add(x) if kind==1 else None
            raws.append(wood(length,queries))
        raws += [wood(10**9,[(1,2*j+1) if i%2==0 else (2,2*j+2) for i in range(200000) for j in [i//2]]),wood(10**9,[(2,999999999)]*200000)]
    elif pid=='abc218_d':
        def points(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[points([(0,0),(0,1),(1,0),(1,1)]),points([(0,j) for j in range(4)]),points([(j,j) for j in range(4)]),points([(0,0),(0,10**9),(10**9,0),(10**9,10**9)])]
        for n in range(5,17):a=rng.sample([(x,y) for x in range(n) for y in range(n)],n);raws.append(points(a))
        raws += [points([(x,y) for x in (0,10**9) for y in range(1000)]),points([(10**9-j,10**9-j) for j in range(2000)])]
    elif pid=='abc219_d':
        def lunch(x:int,y:int,a:list[tuple[int,int]])->str:return f'{len(a)}\n{x} {y}\n'+''.join(line(v) for v in a)
        raws=[lunch(1,1,[(1,1)]),lunch(300,300,[(1,1)]),lunch(300,300,[(300,300)]),lunch(2,2,[(1,1),(1,1)])]
        for n in range(2,14):raws.append(lunch(rng.randint(1,300),rng.randint(1,300),[(rng.randint(1,300),rng.randint(1,300)) for _ in range(n)]))
        raws += [lunch(300,300,[(1,1)]*300),lunch(300,300,[(300,300)]*300)]
    elif pid=='abc220_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([0,0]),seq([9,9]),seq([0,1]),seq([1,0])]+[seq([rng.randint(0,9) for _ in range(n)]) for n in range(3,15)]+[seq([j%10 for j in range(100000)]),seq([9]*100000)]
    else:
        def logins(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[logins([(1,1)]),logins([(10**9,10**9)]),logins([(1,1),(2,1)]),logins([(1,2),(2,2)])]+[logins([(rng.randint(1,10**9),rng.randint(1,10**9)) for _ in range(n)]) for n in range(2,14)]+[logins([(j+1,2) for j in range(200000)]),logins([(10**9,10**9)]*200000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc216_d':('同色の二個が異なる筒の一番上にあれば、その二個を捨てられます。','各色が見えている筒を管理し、二本で見えた色をキューに入れます。捨てた後に新しく露出した色も同じように更新します。','疑似コード: visible[color]へ各筒の先頭indexを追加; visibleが2本のcolorをqueue; colorを取り出し両筒の先頭を進め新colorをvisibleへ追加; 全N色を捨てられればYes、他No。'),
'abc217_d':('切った地点の中で、問い合わせ位置の直前と直後を見つければ長さが分かります。','全クエリの座標を圧縮し、切った地点をFenwick木に1で登録します。問い合わせ位置より左の切れ目数から、隣の二つの切れ目を順位検索します。','疑似コード: coordinates=sort({0,L}とquery座標); Fenwickへ0,L登録; cutは座標へadd1; queryはcount=prefix(xより左); kth(count+1)-kth(count)を出力。'),
'abc218_d':('長方形の対角の二点を選ぶと、残り二点の座標が決まります。','xもyも異なる二点について、入れ替えた二点が点集合に存在するか調べます。対角は二通りなので最後に2で割ります。','疑似コード: pointsの全unordered二点(x,y),(xx,yy); x!=xx,y!=yyかつ(x,yy),(xx,y)がset内ならanswer++; answer//2を出力。'),
'abc219_d':('各弁当は一度しか使えません。二種類の個数は目標以上を同じ状態にまとめられます。','dp[takoyaki][taiyaki]を必要な弁当の最小個数にします。各弁当ごとに大きい状態から小さい状態へ更新すれば、二回購入を避けられます。','疑似コード: dp[0][0]=0,他INF; 各(A,B)でx,yを降順走査しdp[min(X,x+A)][min(Y,y+B)]=min(現値,dp[x][y]+1); dp[X][Y]がINFなら-1、他その値。'),
'abc220_d':('左端の値としてあり得る状態は0から9の十種類だけです。','次の数字を一つずつ取り込み、和の余りと積の余りへ現在の通り数を加えます。同じ結果でも操作FとGは別の手順です。','疑似コード: dp[A0]=1; 各次digitでnext0初期化; value=0..9からnext[(value+digit)%10]+=dp[value],next[value*digit%10]+=dp[value]; 全てMOD; 最後dp[0..9]を各行出力。'),
'abc221_d':('ログイン人数が変化するのは開始日Aと、その期間が終わる日A+Bです。','開始日で+1、終了日で-1のイベントをまとめて時刻順に走査します。前のイベントからの日数を、その間の人数の答えへ加えます。','疑似コード: events[A]+=1,events[A+B]-=1; current=0,previous=0; day昇順でanswer[current]+=day-previous; current+=events[day]; previous=day; answer[1..N]を空白区切り出力。')}

TITLES={'abc216_d': 'Pair of Balls', 'abc217_d': 'Cutting Woods', 'abc218_d': 'Rectangles', 'abc219_d': 'Strange Lunchbox', 'abc220_d': 'FG operation', 'abc221_d': 'Online games'}
PUBLISHED_SAMPLES={'abc216_d': [{'input': '2 2\n2\n1 2\n2\n1 2\n', 'expected': 'Yes\n'}, {'input': '2 2\n2\n1 2\n2\n2 1\n', 'expected': 'No\n'}], 'abc217_d': [{'input': '5 3\n2 2\n1 3\n2 2\n', 'expected': '5\n3\n'}, {'input': '5 3\n1 2\n1 4\n2 3\n', 'expected': '2\n'}, {'input': '100 10\n1 31\n2 41\n1 59\n2 26\n1 53\n2 58\n1 97\n2 93\n1 23\n2 84\n', 'expected': '69\n31\n6\n38\n38\n'}], 'abc218_d': [{'input': '6\n0 0\n0 1\n1 0\n1 1\n2 0\n2 1\n', 'expected': '3\n'}, {'input': '4\n0 1\n1 2\n2 3\n3 4\n', 'expected': '0\n'}, {'input': '7\n0 1\n1 0\n2 0\n2 1\n2 2\n3 0\n3 2\n', 'expected': '1\n'}], 'abc219_d': [{'input': '3\n5 6\n2 1\n3 4\n2 3\n', 'expected': '2\n'}, {'input': '3\n8 8\n3 4\n2 3\n2 1\n', 'expected': '-1\n'}], 'abc220_d': [{'input': '3\n2 7 6\n', 'expected': '1\n0\n0\n0\n2\n1\n0\n0\n0\n0\n'}, {'input': '5\n0 1 2 3 4\n', 'expected': '6\n0\n1\n1\n4\n0\n1\n1\n0\n2\n'}], 'abc221_d': [{'input': '3\n1 2\n2 3\n3 1\n', 'expected': '2 2 0\n'}, {'input': '2\n1000000000 1000000000\n1000000000 1000000000\n', 'expected': '0 1000000000\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
