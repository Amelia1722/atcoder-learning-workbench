"""ABC158–160 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc158_b', 'abc159_b', 'abc160_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc158_b': [
        {'input':'8 3 4\n','expected':'4\n'},
        {'input':'8 0 4\n','expected':'0\n'},
        {'input':'6 2 4\n','expected':'2\n'},
    ],
    'abc159_b': [
        {'input':'akasaka\n','expected':'Yes\n'},
        {'input':'level\n','expected':'No\n'},
        {'input':'atcoder\n','expected':'No\n'},
    ],
    'abc160_b': [
        {'input':'1024\n','expected':'2020\n'},
        {'input':'0\n','expected':'0\n'},
        {'input':'1000000000\n','expected':'2000000000\n'},
    ],
}

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc158_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        parts = lines[0].split(' ')
        if len(parts) != 3 or POS.fullmatch(parts[0]) is None or any(NONNEG.fullmatch(x) is None for x in parts[1:]):
            raise ValueError('expected canonical N A B')
        n, a, b = map(int, parts)
        if not (1 <= n <= 10**18 and 0 <= a <= 10**18 and 0 <= b <= 10**18):
            raise ValueError('range')
        if not (0 < a + b <= 10**18):
            raise ValueError('cycle range')
        return n, a, b
    if pid == 'abc159_b':
        if len(lines) != 1 or LOWER.fullmatch(lines[0]) is None:
            raise ValueError('expected lowercase string')
        s = lines[0]
        if not (3 <= len(s) <= 99 and len(s) % 2 == 1):
            raise ValueError('length range/oddness')
        return s
    if len(lines) != 1 or NONNEG.fullmatch(lines[0]) is None:
        raise ValueError('expected canonical X')
    x = int(lines[0])
    if not 0 <= x <= 10**9:
        raise ValueError('X range')
    return x

def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc158_b':
        if NONNEG.fullmatch(output) is None:
            return False
        n, a, b = value
        cycle = a + b
        expected = (n // cycle) * a + min(n % cycle, a)
        return output == str(expected)
    if pid == 'abc159_b':
        s = value
        n = len(s)
        left = s[:(n-1)//2]
        right = s[(n+3)//2-1:]
        expected = s == s[::-1] and left == left[::-1] and right == right[::-1]
        return output == ('Yes' if expected else 'No')
    if NONNEG.fullmatch(output) is None:
        return False
    x = value
    five_hundred = x // 500
    rest = x - five_hundred * 500
    expected = five_hundred * 1000 + (rest // 5) * 5
    return output == str(expected)

def _158(n: int, a: int, b: int) -> str:
    return f'{n} {a} {b}\n'

def _159(s: str) -> str:
    return f'{s}\n'

def _160(x: int) -> str:
    return f'{x}\n'

def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid == 'abc158_b':
        vals = [
            ('sample1',8,3,4),('sample2',8,0,4),('sample3',6,2,4),
            ('min',1,1,0),('red_only_single',1,0,1),('only_blue',10,5,0),
            ('exact_cycle',7,3,4),('partial_blue',2,3,4),('partial_red',5,3,4),
            ('two_cycles',14,3,4),('cycle_plus_blue',15,3,4),('cycle_plus_red',18,3,4),
            ('huge_half',10**18,1,1),('huge_zero_blue',10**18,0,10**18),
            ('sum_max_partial',10**18-1,10**18-1,1),
            ('sum_max_exact',10**18,10**18-1,1),
            ('large_irregular',999999999999999937,123456789,987654321),
        ]
        for cat,n,a,b in vals: add(cat,_158(n,a,b))
        add('constraint_max',_158(10**18,10**18,0))
    elif pid == 'abc159_b':
        vals = [
            ('sample1','akasaka'),('sample2','level'),('sample3','atcoder'),
            ('min_yes','aba'),('min_no','abc'),('all_same5','aaaaa'),
            ('whole_only','abcba'),('halves_only','abacaca'),('strong9','abbaxabba'),
            ('strong11','abcbazabcba'),('whole_pal_half_bad','abcdcba'),('all_same7','aaaaaaa'),
            ('strong13','abccbamabccba'),('random','qwertyu'),('near_max_yes','z'*97),
            ('near_max_no','a'*98+'b'),('center_change_still_yes','a'*49+'z'+'a'*49),
        ]
        for cat,s in vals: add(cat,_159(s))
        add('constraint_max',_159('a'*99))
    else:
        vals = [
            ('sample1',1024),('sample2',0),('one_yen',1),('under_five',4),('first_five',5),
            ('before_500',499),('exact_500',500),('after_500',501),('before_next_five',504),
            ('one_five_after',505),('before_1000',999),('exact_1000',1000),('after_1000',1004),
            ('next_five',1005),('medium',12345),('large',123456789),('near_max',999999999),
        ]
        for cat,x in vals: add(cat,_160(x))
        add('constraint_max',_160(10**9))
    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
