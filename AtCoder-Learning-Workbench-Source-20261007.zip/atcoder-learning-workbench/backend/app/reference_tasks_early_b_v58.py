"""ABC032–034 B: reviewed public statements, independent validators and oracles.

The statement pages were inspected via public Web results; HTML originals are not
archived/authenticated. The narrow validators cover canonical generated inputs.
"""
from __future__ import annotations

import random
import re

TASKS = ('abc032_b', 'abc033_b', 'abc034_b')
LOWER = re.compile(r'[a-z]+', re.ASCII)
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'0|[1-9][0-9]*', re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unsupported task or malformed line endings')
    lines = raw[:-1].split('\n')
    if pid == 'abc032_b':
        if (len(lines) != 2 or not 1 <= len(lines[0]) <= 300 or
                not LOWER.fullmatch(lines[0]) or not POS.fullmatch(lines[1])):
            raise ValueError('invalid substring input')
        k = int(lines[1])
        if k > 300:
            raise ValueError('substring length exceeds official limit')
        return lines[0], k
    if pid == 'abc034_b':
        if len(lines) != 1 or not POS.fullmatch(lines[0]):
            raise ValueError('invalid pair index')
        n = int(lines[0])
        if n > 10**9:
            raise ValueError('pair index exceeds official limit')
        return n
    if len(lines) < 3 or not POS.fullmatch(lines[0]):
        raise ValueError('invalid city count')
    n = int(lines[0])
    if not 2 <= n <= 1000 or len(lines) != n + 1:
        raise ValueError('city count does not match rows')
    names = set()
    result = []
    for line in lines[1:]:
        tokens = line.split(' ')
        if (len(tokens) != 2 or not 1 <= len(tokens[0]) <= 20 or
                not LOWER.fullmatch(tokens[0]) or not POS.fullmatch(tokens[1])):
            raise ValueError('invalid city row')
        name, population = tokens[0], int(tokens[1])
        if name in names or population > 100000:
            raise ValueError('duplicate name or population out of range')
        names.add(name)
        result.append((name, population))
    return result


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        data = validate(pid, raw)
    except (ValueError, TypeError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc032_b':
        s, k = data
        if k > len(s):
            count = 0
        else:
            # Sorting adjacent suffix-length windows is a distinct counting
            # implementation from the reference's hash set.
            windows = sorted(s[i:i+k] for i in range(len(s)-k+1))
            count = 1
            for i in range(1, len(windows)):
                if windows[i] != windows[i-1]:
                    count += 1
        return output == str(count)
    if pid == 'abc034_b':
        # Convert zero-based pair index by flipping its least significant bit.
        answer = ((data - 1) ^ 1) + 1
        return output == str(answer)
    towns = data
    # An exact-half population must NOT be accepted (official sample 2).
    largest_name, largest_population = max(towns, key=lambda entry: entry[1])
    others = sum(p for name, p in towns if name != largest_name)
    answer = largest_name if largest_population > others else 'atcoder'
    return output == answer


def generate(pid: str, seed: int = 58) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unsupported task')
    rng = random.Random(f'abc-v58:{pid}:{seed}')
    rows = []
    seen = set()

    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            rows.append({'category': category, 'input': raw})
            seen.add(raw)

    if pid == 'abc032_b':
        presets = [
            ('a', 1), ('a', 300), ('aaaaa', 1), ('aaaaa', 5),
            ('aaaaa', 6), ('abcabc', 2), ('abcabc', 3),
            ('abcdefghijklmnopqrstuvwxyz', 1),
            ('abcdefghijklmnopqrstuvwxyz', 26),
            ('abcdefghijklmnopqrstuvwxyz', 27),
            ('abababab', 2), ('zzzzzzzz', 7),
            ('a'*300, 1), ('a'*300, 299),
            ('ab'*150, 2), ('ab'*150, 299),
        ]
        for s, k in presets:
            add('boundary' if k in (1, len(s), 300) or k > len(s) else 'normal',f'{s}\n{k}\n')
        while len(rows) < 17:
            s = ''.join(rng.choices('abcdefghijklmnopqrstuvwxyz', k=rng.randint(1,300)))
            add('random',f'{s}\n{rng.randint(1,300)}\n')
        add('constraint_max',f'{"abcdefghijklmnopqrstuvwxyz"*11 + "abcdefghijklmn"}\n300\n')
    elif pid == 'abc034_b':
        for n in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                  99, 100, 123456789, 123456790, 999999997, 999999998, 999999999]:
            add('boundary' if n <= 2 or n >= 999999997 else 'normal',f'{n}\n')
        add('constraint_max','1000000000\n')
    else:
        def fmt(towns):
            return f'{len(towns)}\n' + ''.join(f'{name} {p}\n' for name,p in towns)
        def names(n):
            # Distinct names for 1 <= n <= 1000, length <= 20.
            return [f'city{chr(97+(i//676)%26)}{chr(97+(i//26)%26)}{chr(97+i%26)}'
                    for i in range(n)]
        presets = [
            [('a',1),('b',1)], [('a',2),('b',1)], [('a',1),('b',2)],
            [('a',100000),('b',100000)], [('a',100000),('b',1)],
            [('a',1),('b',100000)], [('a',1),('b',1),('c',2)],
            [('a',1),('b',2),('c',4)], [('a',99999),('b',1),('c',100000)],
            [('a',100000),('b',1),('c',1)],
            [(name,1) for name in names(1000)],
            [(name,100000) for name in names(1000)],
            [(name,1 if i else 100000) for i,name in enumerate(names(1000))],
            [(name,100000 if i%2 else 1) for i,name in enumerate(names(1000))],
        ]
        for towns in presets:
            add('boundary' if len(towns) in (2,1000) else 'normal',fmt(towns))
        while len(rows) < 17:
            n=rng.randint(2,1000)
            populations=[rng.randint(1,100000) for _ in range(n)]
            add('random',fmt(list(zip(names(n),populations))))
        add('constraint_max',fmt([(name,100000 if i==999 else 1)
                                 for i,name in enumerate(names(1000))]))
    if len(rows) != 18 or rows[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: not exactly 18 unique cases: {len(rows)}')
    return rows
