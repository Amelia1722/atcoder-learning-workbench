"""Statement-checked three-stage hints for ABC263–265 B."""
HINTS_V135 = {
 'abc263_b': (
  '人Nから親を1人ずつ辿ると、番号は必ず小さくなるので、いつか必ず人1に到達します。何回親へ移ったかを数えれば答えです。',
  'P_iは人iの親です。現在の人をcurとして、curが1でない間は cur=P_cur と更新し、更新回数を数えます。入力配列はP_2から始まるので添字ずれに注意します。',
  '疑似コード:\nparents = P_2..P_N\ncur = N\nans = 0\nwhile cur != 1:\n  cur = parents[cur-2]\n  ans += 1\nprint(ans)',
 ),
 'abc264_b': (
  '色は15×15の同心正方形ごとに交互です。外側から何層目のマスかが分かれば色を決められます。',
  '上・左・下・右の端までの距離の最小値を考えます。0層目がblack、1層目がwhite、2層目がblack…なので、その最小距離の偶奇だけを見ればよいです。',
  '疑似コード:\nlayer = min(R-1, C-1, 15-R, 15-C)\nif layer % 2 == 0:\n  print("black")\nelse:\n  print("white")',
 ),
 'abc265_b': (
  '部屋1から順番にしか進めないので、そのままシミュレーションできます。移動の直後に持ち時間が0以下になるなら、その移動はできません。',
  'ボーナスは「その部屋に到達した直後」に加算します。部屋番号からボーナス量を引ける辞書を作ると、各移動をO(1)で処理できます。',
  '疑似コード:\nbonus = {X_i: Y_i}\ntime = T\nfor room = 1 .. N-1:\n  time -= A[room]\n  if time <= 0:\n    print("No")\n    終了\n  time += bonus.get(room+1, 0)\nprint("Yes")',
 ),
}
