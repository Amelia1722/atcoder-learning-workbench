"""ABC230–232 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc230_b', 'abc231_b', 'abc232_b')
LOWER = re.compile(r'[a-z]+', re.ASCII)
OX = re.compile(r'[ox]+', re.ASCII)
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc230_b': [
        {'input': 'xoxxoxxo\n', 'expected': 'Yes\n'},
        {'input': 'xxoxxoxo\n', 'expected': 'No\n'},
        {'input': 'ox\n', 'expected': 'Yes\n'},
    ],
    'abc231_b': [
        {'input': '5\nsnuke\nsnuke\ntakahashi\ntakahashi\ntakahashi\n', 'expected': 'takahashi\n'},
        {'input': '5\ntakahashi\ntakahashi\naoki\ntakahashi\nsnuke\n', 'expected': 'takahashi\n'},
        {'input': '1\na\n', 'expected': 'a\n'},
    ],
    'abc232_b': [
        {'input': 'abc\nijk\n', 'expected': 'Yes\n'},
        {'input': 'z\na\n', 'expected': 'Yes\n'},
        {'input': 'ppq\nqqp\n', 'expected': 'No\n'},
        {'input': 'atcoder\natcoder\n', 'expected': 'Yes\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _validate230(raw: str) -> str:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or OX.fullmatch(lines[0]) is None or not 1 <= len(lines[0]) <= 10:
        raise ValueError('S')
    return lines[0]


def _validate231(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) < 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    names = tuple(lines[1:])
    if not 1 <= n <= 100 or len(names) != n:
        raise ValueError('N/shape')
    if any(LOWER.fullmatch(s) is None or not 1 <= len(s) <= 10 for s in names):
        raise ValueError('name')
    counts: dict[str, int] = {}
    for s in names:
        counts[s] = counts.get(s, 0) + 1
    best = max(counts.values())
    if sum(v == best for v in counts.values()) != 1:
        raise ValueError('winner not unique')
    return n, names


def _validate232(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    s, t = lines
    if LOWER.fullmatch(s) is None or LOWER.fullmatch(t) is None:
        raise ValueError('alphabet')
    if len(s) != len(t) or not 1 <= len(s) <= 100000:
        raise ValueError('length')
    return s, t


def validate(pid: str, raw: str):
    if pid == 'abc230_b':
        return _validate230(raw)
    if pid == 'abc231_b':
        return _validate231(raw)
    if pid == 'abc232_b':
        return _validate232(raw)
    raise ValueError('unknown task')


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc230_b':
        if output not in {'Yes', 'No'}:
            return False
        s = value
        # A valid substring must match one of the three phases of the period oxx.
        ok = any(all(ch == 'oxx'[(phase + i) % 3] for i, ch in enumerate(s)) for phase in range(3))
        return (output == 'Yes') == ok
    if pid == 'abc231_b':
        if LOWER.fullmatch(output) is None or not 1 <= len(output) <= 10:
            return False
        _, names = value
        unique = sorted(set(names))
        winner = max(unique, key=lambda x: (sum(y == x for y in names), x))
        # Uniqueness is already enforced, so tie-breaking above is irrelevant.
        return output == winner
    if pid == 'abc232_b':
        if output not in {'Yes', 'No'}:
            return False
        s, t = value
        ok = False
        for k in range(26):
            if all(chr((ord(a) - 97 + k) % 26 + 97) == b for a, b in zip(s, t)):
                ok = True
                break
        return (output == 'Yes') == ok
    return False


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc230_b':
        cases = [
            ('single_o', 'o\n'), ('single_x', 'x\n'), ('two_xx', 'xx\n'),
            ('two_xo', 'xo\n'), ('three_oxx', 'oxx\n'), ('three_xxo', 'xxo\n'),
            ('three_xox_no', 'xox\n'), ('four_wrap', 'xoxx\n'), ('four_no', 'oxxo\n'),
            ('five_valid', 'xxoxx\n'), ('five_no', 'oxxoo\n'), ('len9_valid', 'oxxoxxoxx\n'),
            ('len9_phase2', 'xoxxoxxox\n'), ('len10_no', 'oxxoxxoxxo\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', 'xxoxxoxxox\n')
    elif pid == 'abc231_b':
        cases = [
            ('two_same', '2\na\na\n'),
            ('three_two_one', '3\na\nb\na\n'),
            ('four_three_one', '4\nz\nz\nz\na\n'),
            ('long_names', '5\nabcdefghij\nabcdefghij\nabcdefghij\nzyxwvutsrq\nzyxwvutsrq\n'),
            ('many_candidates', '7\na\nb\nc\na\nd\na\ne\n'),
            ('winner_last_seen', '6\na\nb\nb\nc\nc\nc\n'),
            ('winner_first_seen', '8\nq\nq\nq\nq\na\na\nb\nc\n'),
            ('case_sensitive_not_relevant', '5\nabc\nabc\nab\nabc\nz\n'),
            ('n20_clear', '20\n' + '\n'.join(['x'] * 11 + ['y'] * 9) + '\n'),
            ('n21_clear', '21\n' + '\n'.join(['abc'] * 11 + ['def'] * 10) + '\n'),
            ('n50_clear', '50\n' + '\n'.join(['a'] * 26 + ['b'] * 24) + '\n'),
            ('n99_clear', '99\n' + '\n'.join(['winner'] * 50 + ['other'] * 49) + '\n'),
            ('many_unique', '10\na\nb\nc\nd\ne\nf\ng\nh\ni\na\n'),
            ('length10_winner', '9\nabcdefghij\nabcdefghij\nabcdefghij\nabcdefghij\na\na\na\nb\nc\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '100\n' + '\n'.join(['abcdefghij'] * 51 + ['zyxwvutsrq'] * 49) + '\n')
    else:
        cases = [
            ('single_same', 'a\na\n'), ('single_shift25', 'a\nz\n'), ('single_wrap', 'z\na\n'),
            ('two_shift1', 'az\nba\n'), ('two_shift13', 'an\nna\n'), ('two_no', 'ab\nac\n'),
            ('all_same_shift', 'aaaa\nnnnn\n'), ('mixed_shift25', 'bcda\nabc z\n'.replace(' ','')),
            ('wrap_multi', 'xyz\nzab\n'), ('identity_long', 'abcdefghijklmnopqrstuvwxyz\nabcdefghijklmnopqrstuvwxyz\n'),
            ('rotation_not_shift', 'abcd\nbcda\n'), ('near_valid_one_bad', 'abcde\nfghij\n'),
            ('near_valid_bad_last', 'abcde\nfghik\n'), ('repeated_pattern', 'azazaz\nbababa\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        s = 'a' * 50000 + 'z' * 50000
        t = 'm' * 50000 + 'l' * 50000
        add('constraint_max', s + '\n' + t + '\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
