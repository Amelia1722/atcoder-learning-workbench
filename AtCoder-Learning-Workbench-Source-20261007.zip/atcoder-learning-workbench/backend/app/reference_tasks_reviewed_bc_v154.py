"""Turn 131: fixed mixed B/C batch, canonical inputs and independent verifiers."""
from __future__ import annotations

from collections import Counter
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from fractions import Fraction
from heapq import heappop, heappush
from typing import cast
import math
import random
import re

TASKS = tuple(f'abc{i}_b' for i in range(465, 476)) + tuple(f'abc{i:03}_3' for i in range(1, 8))
LANES = {chr(65+i): TASKS[3*i:3*i+3] for i in range(6)}
OUTPUT_MODES = {'abc002_3': 'numeric_absolute_1e-2', 'abc003_3': 'numeric_tolerance_1e-6', 'abc006_3': 'semantic'}
Data = tuple[int | str | tuple[int, ...] | tuple[str, ...] | tuple[tuple[int | str, ...], ...], ...]
Case = dict[str, str]

def _require(condition: bool, label: str) -> None:
    if not condition:
        raise ValueError(label)

def _ints(line: str, count: int | None = None) -> tuple[int, ...]:
    _require(re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?: -?(?:0|[1-9][0-9]*))*', line) is not None, 'integer syntax')
    result = tuple(map(int, line.split(' ')))
    _require(count is None or len(result) == count, 'integer count')
    return result

def _reachable(grid: tuple[str, ...], start: tuple[int, int], goal: tuple[int, int]) -> bool:
    seen = {start}
    pending = [start]
    while pending:
        r, c = pending.pop()
        for dr, dc in ((1,0),(-1,0),(0,1),(0,-1)):
            v = r+dr, c+dc
            if 0 <= v[0] < len(grid) and 0 <= v[1] < len(grid[0]) and grid[v[0]][v[1]] == '.' and v not in seen:
                seen.add(v); pending.append(v)
    return goal in seen

def validate(pid: str, raw: str) -> Data:
    _require(pid in TASKS, 'unknown task')
    _require(raw.endswith('\n') and '\r' not in raw, 'canonical newline')
    lines = raw[:-1].split('\n')
    _require(all(lines), 'blank row')
    if pid == 'abc465_b':
        _require(len(lines)==1, 'shape')
        x,y,l,r,a,b = _ints(lines[0],6)
        _require(1<=x<=1000 and 1<=y<=1000 and 1<=l<r<=23 and 1<=a<b<=23, 'ranges')
        return x,y,l,r,a,b
    if pid == 'abc466_b':
        n,m = _ints(lines[0],2)
        rows = tuple(_ints(s,2) for s in lines[1:])
        _require(1<=n<=100 and 1<=m<=100 and len(rows)==n and all(1<=c<=m and 1<=s<=100 for c,s in rows), 'balls')
        return n,m,rows
    if pid == 'abc467_b':
        n, = _ints(lines[0],1)
        rows: list[tuple[int | str, ...]] = []
        for line in lines[1:]:
            fields = line.split(' ')
            _require(len(fields)==3 and fields[2] in ('keep','take'), 'purchase')
            a,b = _ints(' '.join(fields[:2]),2)
            _require(1<=a<=b<=100, 'prices')
            rows.append((a,b,fields[2]))
        _require(1<=n<=100 and len(rows)==n, 'N')
        return n,tuple(rows)
    if pid == 'abc468_b':
        _require(len(lines)==2, 'shape')
        m,d = _ints(lines[0],2); s=lines[1]
        _require(0<=d<m<=100 and len(s)==m and set(s)<=set('G.'), 'corridor')
        return m,d,s
    if pid == 'abc469_b':
        _require(len(lines)==2, 'shape')
        n, = _ints(lines[0],1); s=lines[1]
        _require(1<=n<=100 and len(s)==n and set(s)<=set('ox'), 'seats')
        return n,s
    if pid == 'abc471_b':
        n, = _ints(lines[0],1)
        _require(1<=n<=100 and len(lines)==n+1 and all(re.fullmatch('[a-zA-Z]{1,10}',s) for s in lines[1:]), 'answers')
        return n,tuple(lines[1:])
    if pid in ('abc470_b','abc472_b','abc473_b','abc474_b','abc475_b'):
        _require(len(lines)==2, 'shape')
        n, = _ints(lines[0],1); a = _ints(lines[1],n)
        lo = 2 if pid=='abc472_b' else 10 if pid=='abc474_b' else 1
        hi = 1000 if pid=='abc475_b' else 100
        upper = n if pid in ('abc470_b','abc474_b') else 10**5 if pid in ('abc472_b','abc475_b') else 100
        _require(lo<=n<=hi and all(1<=v<=upper for v in a), 'array')
        if pid=='abc474_b': _require(set(a)==set(range(1,n+1)), 'permutation')
        return n,a
    if pid == 'abc001_3':
        _require(len(lines)==1, 'shape'); deg,dis = _ints(lines[0],2)
        _require(0<=deg<3600 and 0<=dis<12000, 'wind')
        return deg,dis
    if pid == 'abc002_3':
        _require(len(lines)==1, 'shape'); a = _ints(lines[0],6)
        _require(all(-1000<=x<=1000 for x in a), 'coordinates')
        x,y,u,v,p,q=a
        _require((u-x)*(q-y)!=(v-y)*(p-x), 'noncollinear')
        return a
    if pid == 'abc003_3':
        _require(len(lines)==2, 'shape'); n,k = _ints(lines[0],2); a = _ints(lines[1],n)
        _require(1<=k<=n<=100 and all(1<=x<=4000 for x in a), 'rating')
        return n,k,a
    if pid == 'abc004_3':
        _require(len(lines)==1, 'shape'); n, = _ints(lines[0],1)
        _require(1<=n<=10**9, 'N'); return (n,)
    if pid == 'abc005_3':
        _require(len(lines)==5, 'shape'); t, = _ints(lines[0],1); n, = _ints(lines[1],1); m, = _ints(lines[3],1)
        a,b = _ints(lines[2],n),_ints(lines[4],m)
        _require(1<=t<=100 and 1<=n<=100 and 1<=m<=100 and all(1<=x<=100 for x in a+b), 'takoyaki')
        _require(tuple(sorted(a))==a and tuple(sorted(b))==b, 'nondecreasing')
        return t,a,b
    if pid == 'abc006_3':
        _require(len(lines)==1, 'shape'); n,m = _ints(lines[0],2)
        _require(1<=n<=10**5 and 1<=m<=5*10**5, 'population'); return n,m
    _require(len(lines)>=4, 'maze shape')
    r,c = _ints(lines[0],2); sy,sx = _ints(lines[1],2); gy,gx = _ints(lines[2],2); grid=tuple(lines[3:])
    _require(1<=r<=50 and 1<=c<=50 and len(grid)==r and all(len(s)==c and set(s)<=set('.#') for s in grid), 'maze size')
    _require(1<=sy<=r and 1<=gy<=r and 1<=sx<=c and 1<=gx<=c and (sy,sx)!=(gy,gx), 'endpoints')
    _require(all(s[0]==s[-1]=='#' for s in grid) and set(grid[0]+grid[-1])=={'#'}, 'wall enclosure')
    _require(grid[sy-1][sx-1]==grid[gy-1][gx-1]=='.' and _reachable(grid,(sy-1,sx-1),(gy-1,gx-1)), 'reachable endpoints')
    return r,c,sy,sx,gy,gx,grid

def oracle(pid: str, raw: str) -> str:
    """Different algorithms from the standalone reference route."""
    d = validate(pid,raw)
    if pid=='abc465_b':
        x,y,l,r,a,b=cast(tuple[int,int,int,int,int,int],d); overlap=max(0,min(r,b)-max(l,a)); return str(overlap*x+(b-a-overlap)*y)
    if pid=='abc466_b':
        n,m,rows=cast(tuple[int,int,tuple[tuple[int,int],...]],d); return ' '.join(str(max((s for c,s in rows if c==k),default=-1)) for k in range(1,m+1))
    if pid=='abc467_b':
        n,rows=cast(tuple[int,tuple[tuple[int,int,str],...]],d); actual=10000; ideal=10000
        for a,b,s in rows:
            ideal-=a; actual-=b
            if s=='take': actual+=b-a
        return str(ideal-actual)
    if pid=='abc468_b':
        m,dist,s=cast(tuple[int,int,str],d); guards=[i for i,ch in enumerate(s) if ch=='G']
        return str(sum(all(abs(i-g)>dist for g in guards) for i in range(m)))
    if pid=='abc469_b':
        n,s=cast(tuple[int,str],d); padded='x'+s+'x'; return str(sum(padded[i:i+3]=='xxx' for i in range(n)))
    if pid=='abc470_b':
        n,a=cast(tuple[int,tuple[int,...]],d); return str(min(sum(x!=c for x in a) for c in range(1,n+1)))
    if pid=='abc471_b':
        n,ss=cast(tuple[int,tuple[str,...]],d); return str(max(sum(x.casefold()==s.casefold() for x in ss) for s in ss))
    if pid=='abc472_b':
        n,a=cast(tuple[int,tuple[int,...]],d); return str(min(abs(sum(a[:i])-sum(a[i:])) for i in range(1,n)))
    if pid=='abc473_b':
        n,a=cast(tuple[int,tuple[int,...]],d); remaining=set()
        for v in a:
            if v in remaining: remaining.remove(v)
            else: remaining.add(v)
        return str(sum(remaining))
    if pid=='abc474_b':
        n,a=cast(tuple[int,tuple[int,...]],d)
        return 'Yes' if all(set(a[i:i+10])==set(range(i+1,min(i+10,n)+1)) for i in range(0,n,10)) else 'No'
    if pid=='abc475_b':
        n,a=cast(tuple[int,tuple[int,...]],d); coins=[0,0,0]
        for price in a:
            change=(math.ceil(price/1000)*1000)-price
            for i,value in reversed(list(enumerate((1,10,100)))):
                while change>=value: coins[i]+=1;change-=value
        return ' '.join(map(str,coins))
    if pid=='abc001_3':
        deg,dis=cast(tuple[int,int],d); speed=(Decimal(dis)/60).quantize(Decimal('.1'),rounding=ROUND_HALF_UP)
        limits=tuple(map(Decimal,('0.2','1.5','3.3','5.4','7.9','10.7','13.8','17.1','20.7','24.4','28.4','32.6')))
        force=sum(speed>x for x in limits)
        dirs='N NNE NE ENE E ESE SE SSE S SSW SW WSW W WNW NW NNW'.split()
        direction='N'
        for i in range(1,16):
            if Decimal('11.25')+Decimal('22.5')*(i-1)<=Decimal(deg)/10<Decimal('11.25')+Decimal('22.5')*i: direction=dirs[i]
        return f'{direction if force else "C"} {force}'
    if pid=='abc002_3':
        x,y,u,v,p,q=cast(tuple[int,int,int,int,int,int],d); return str(abs(x*v+u*q+p*y-y*u-v*p-q*x)/2)
    if pid=='abc003_3':
        n,k,a=cast(tuple[int,int,tuple[int,...]],d)
        # Subsequence DP includes skipping any video and using fewer than K.
        dp: list[Fraction | None]=[Fraction(0)]+[None]*k
        for rating in sorted(a):
            for count in range(k,0,-1):
                if dp[count-1] is not None:
                    candidate=(dp[count-1]+rating)/2
                    dp[count]=max(dp[count],candidate) if dp[count] is not None else candidate
        return str(float(max(x for x in dp if x is not None)))
    if pid=='abc004_3':
        n,=cast(tuple[int],d); turns,tail=divmod(n,5); offset=turns%6; cards=list(range(1,7)); cards=cards[offset:]+cards[:offset]
        # Partial pass moves the first card to position tail, preserving the rest.
        return ''.join(map(str,cards[1:tail+1]+cards[:1]+cards[tail+1:]))
    if pid=='abc005_3':
        t,a,b=cast(tuple[int,tuple[int,...],tuple[int,...]],d); match: dict[int,int]={}
        def augment(customer: int, seen: set[int]) -> bool:
            for cake,cooked in enumerate(a):
                if cooked<=b[customer]<=cooked+t and cake not in seen:
                    seen.add(cake)
                    if cake not in match or augment(match[cake],seen):
                        match[cake]=customer;return True
            return False
        return 'yes' if all(augment(j,set()) for j in range(len(b))) else 'no'
    if pid=='abc006_3':
        n,m=cast(tuple[int,int],d)
        for old in range(n+1):
            rest=m-3*old-2*(n-old)
            if rest%2==0 and 0<=rest//2<=n-old:
                baby=rest//2;return f'{n-old-baby} {old} {baby}'
        return '-1 -1 -1'
    r,c,sy,sx,gy,gx,grid=cast(tuple[int,int,int,int,int,int,tuple[str,...]],d)
    # Heap-based Dijkstra, independently of the reference FIFO implementation.
    heap=[(0,sy-1,sx-1)]; best={(sy-1,sx-1):0}
    while heap:
        dist,y,x=heappop(heap)
        if (y,x)==(gy-1,gx-1):return str(dist)
        if dist!=best[y,x]:continue
        for dy,dx in ((-1,0),(1,0),(0,-1),(0,1)):
            yy,xx=y+dy,x+dx
            if grid[yy][xx]=='.' and dist+1<best.get((yy,xx),10**9):
                best[yy,xx]=dist+1;heappush(heap,(dist+1,yy,xx))
    raise ValueError('unreachable')

def semantic_check_abc006(raw: str, actual: str) -> bool:
    try:
        n,m=cast(tuple[int,int],validate('abc006_3',raw))
        if re.fullmatch(r'(?:-1 -1 -1|(?:0|[1-9][0-9]*) (?:0|[1-9][0-9]*) (?:0|[1-9][0-9]*))\n?',actual) is None:return False
        a,o,b=map(int,actual.split())
        if (a,o,b)==(-1,-1,-1):return m<2*n or m>4*n
        return a+o+b==n and 2*a+3*o+4*b==m
    except (ValueError,TypeError):return False

def independent_check(pid: str, raw: str, actual: str) -> bool:
    validate(pid,raw)
    if pid=='abc006_3':return semantic_check_abc006(raw,actual)
    if pid in ('abc002_3','abc003_3'):
        if re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\n?',actual) is None:return False
        try:
            x,y=Decimal(actual.strip()),Decimal(oracle(pid,raw)); eps=Decimal('.01') if pid=='abc002_3' else Decimal('.000001')
            return x.is_finite() and (abs(x-y)<=eps or (pid=='abc003_3' and abs(x-y)<=eps*abs(y)))
        except InvalidOperation:return False
    return actual.removesuffix('\n')==oracle(pid,raw)

def official_expected_matches_reference(pid: str, raw: str, expected: str, stdout: str) -> bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)

REFERENCE_CODE: dict[str,str] = {}
def _reference(pid: str, body: str) -> None:
    REFERENCE_CODE[pid]='import sys\nfrom collections import Counter, deque\n'+body.strip()+'\n'

_reference('abc465_b','''
x,y,l,r,a,b=map(int,sys.stdin.read().split())
print(sum(x if l<=hour<r else y for hour in range(a,b)))
''')
_reference('abc466_b','''
it=iter(map(int,sys.stdin.read().split()));n,m=next(it),next(it);ans=[-1]*m
for _ in range(n):
 c,s=next(it),next(it);ans[c-1]=max(ans[c-1],s)
print(*ans)
''')
_reference('abc467_b','''
rows=sys.stdin.read().splitlines();ans=0
for row in rows[1:]:
 a,b,s=row.split()
 if s=='keep':ans+=int(b)-int(a)
print(ans)
''')
_reference('abc468_b','''
m,d=map(int,input().split());s=input();watched=set()
for i,ch in enumerate(s):
 if ch=='G':watched.update(range(max(0,i-d),min(m,i+d+1)))
print(m-len(watched))
''')
_reference('abc469_b','''
n=int(input());s=input()
print(sum(s[i]=='x' and (i==0 or s[i-1]=='x') and (i==n-1 or s[i+1]=='x') for i in range(n)))
''')
_reference('abc470_b','''
n=int(input());a=list(map(int,input().split()));print(n-max(Counter(a).values()))
''')
_reference('abc471_b','''
n=int(input());counts=Counter(input().lower() for _ in range(n));print(max(counts.values()))
''')
_reference('abc472_b','''
n=int(input());a=list(map(int,input().split()));total=sum(a);left=0;ans=total
for x in a[:-1]:
 left+=x;ans=min(ans,abs(total-2*left))
print(ans)
''')
_reference('abc473_b','''
n=int(input());counts=Counter(map(int,input().split()));print(sum(x for x,c in counts.items() if c%2))
''')
_reference('abc474_b','''
n=int(input());p=list(map(int,input().split()));print('Yes' if all(i//10==(x-1)//10 for i,x in enumerate(p)) else 'No')
''')
_reference('abc475_b','''
n=int(input());coins=[0,0,0]
for a in map(int,input().split()):
 change=(-a)%1000
 coins[0]+=change%10;coins[1]+=(change//10)%10;coins[2]+=change//100
print(*coins)
''')
_reference('abc001_3','''
deg,dis=map(int,input().split());speed=(dis+3)//6
force=sum(speed>x for x in [2,15,33,54,79,107,138,171,207,244,284,326])
dirs='N NNE NE ENE E ESE SE SSE S SSW SW WSW W WNW NW NNW'.split()
print(dirs[((deg*10+1125)//2250)%16] if force else 'C',force)
''')
_reference('abc002_3','''
x,y,u,v,p,q=map(int,input().split());print(abs((u-x)*(q-y)-(v-y)*(p-x))/2)
''')
_reference('abc003_3','''
n,k=map(int,input().split());ratings=sorted(map(int,input().split()));result=0.0
for r in ratings[-k:]:result=(result+r)/2
print(format(result,'.15f'))
''')
_reference('abc004_3','''
n=int(input());cards=list('123456')
for i in range(n%30):
 j=i%5;cards[j],cards[j+1]=cards[j+1],cards[j]
print(''.join(cards))
''')
_reference('abc005_3','''
t=int(input());n=int(input());a=list(map(int,input().split()));m=int(input());b=list(map(int,input().split()));i=0;ok=True
for arrived in b:
 while i<n and a[i]+t<arrived:i+=1
 if i==n or a[i]>arrived:ok=False;break
 i+=1
print('yes' if ok else 'no')
''')
_reference('abc006_3','''
n,m=map(int,input().split());extra=m-2*n
if extra<0 or extra>2*n:print(-1,-1,-1)
else:
 baby=extra//2;old=extra%2;print(n-baby-old,old,baby)
''')
_reference('abc007_3','''
r,c=map(int,input().split());sy,sx=map(int,input().split());gy,gx=map(int,input().split());grid=[input() for _ in range(r)]
dist=[[-1]*c for _ in range(r)];dist[sy-1][sx-1]=0;q=deque([(sy-1,sx-1)])
while q:
 y,x=q.popleft()
 for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
  yy,xx=y+dy,x+dx
  if grid[yy][xx]=='.' and dist[yy][xx]<0:dist[yy][xx]=dist[y][x]+1;q.append((yy,xx))
print(dist[gy-1][gx-1])
''')

def _array(values: list[int]) -> str:
    return f'{len(values)}\n'+ ' '.join(map(str,values))+'\n'

def _maze(rows: int, cols: int, variant: int) -> str:
    grid=[['#']*cols for _ in range(rows)]
    if variant==0:
        for y in range(1,rows-1):
            for x in range(1,cols-1):grid[y][x]='.'
    else:
        for y in range(1,rows-1):
            if y%2:
                for x in range(1,cols-1):grid[y][x]='.'
            else: grid[y][cols-2 if y%4==2 else 1]='.'
    gy=rows-2 if variant==0 or (rows-2)%2 else rows-3
    gx=cols-2 if variant==0 or gy%4==1 else 1
    if (gy,gx)==(1,1):gx=2
    return f'{rows} {cols}\n2 2\n{gy+1} {gx+1}\n'+'\n'.join(''.join(s) for s in grid)+'\n'

def generate(pid: str) -> list[Case]:
    _require(pid in TASKS, 'pid'); rng=random.Random(154+TASKS.index(pid)); raws: list[str]=[]
    if pid=='abc465_b':
        raws=['1 1 1 2 1 2\n','1000 1 5 10 1 5\n','1 1000 5 10 10 23\n','999 1 5 10 6 9\n','1 999 5 10 1 23\n']
        while len(raws)<17:
            l,r=sorted(rng.sample(range(1,24),2));a,b=sorted(rng.sample(range(1,24),2));raws.append(f'{rng.randint(1,1000)} {rng.randint(1,1000)} {l} {r} {a} {b}\n')
        raws.append('1000 1000 1 23 1 23\n')
    elif pid=='abc466_b':
        raws=['1 1\n1 1\n','1 100\n100 100\n','3 2\n1 5\n1 5\n1 1\n']
        for j in range(14):
            n=4+j;m=2+j;raws.append(f'{n} {m}\n'+''.join(f'{rng.randint(1,m)} {rng.randint(1,100)}\n' for _ in range(n)))
        raws.append('100 100\n'+''.join(f'{i} 100\n' for i in range(1,101)))
    elif pid=='abc467_b':
        raws=['1\n1 1 keep\n','1\n1 100 take\n','1\n1 100 keep\n']
        for j in range(14):
            n=2+j;rows=[]
            for i in range(n):
                a=rng.randint(1,100);b=rng.randint(a,100);rows.append(f'{a} {b} {"take" if i%2 else "keep"}\n')
            raws.append(f'{n}\n'+''.join(rows))
        raws.append('100\n'+'1 100 keep\n'*100)
    elif pid=='abc468_b':
        raws=['1 0\n.\n','1 0\nG\n','5 4\n.....\n','5 4\n..G..\n','7 1\nG.....G\n']
        for j in range(12):
            n=8+j;raws.append(f'{n} {j%n}\n'+''.join(rng.choice('G.') for _ in range(n))+'\n')
        raws.append('100 99\n'+'G'+'.'*99+'\n')
    elif pid=='abc469_b':
        raws=['1\nx\n','1\no\n','3\nxxx\n','3\nxox\n','3\noxo\n']
        for j in range(12):
            n=4+j;raws.append(f'{n}\n'+''.join(rng.choice('ox') for _ in range(n))+'\n')
        raws.append('100\n'+'x'*100+'\n')
    elif pid=='abc471_b':
        raws=['1\nA\n','3\nAbC\naBc\nABC\n','3\na\nb\nc\n']
        for j in range(14):
            n=4+j;raws.append(f'{n}\n'+''.join(rng.choice(('AtCoder','ATCODER','a','B','b','Zz','zz','LongAnswer'))+'\n' for _ in range(n)))
        raws.append('100\n'+'AbCdEfGhIj\n'*100)
    elif pid in ('abc470_b','abc472_b','abc473_b','abc474_b','abc475_b'):
        if pid=='abc470_b':raws=[_array([1]),_array([1,1]),_array([1,2]),_array([1,2,3])];maximum=_array(list(range(1,101)))
        elif pid=='abc472_b':raws=[_array([1,1]),_array([1,100000]),_array([1,1,1]),_array([100000,1,1,1])];maximum=_array([100000]*100)
        elif pid=='abc473_b':raws=[_array([1]),_array([100,100]),_array([100,100,100]),_array([1,2,3,4])];maximum=_array(list(range(1,101)))
        elif pid=='abc474_b':raws=[_array(list(range(1,11))),_array(list(range(10,0,-1))),_array([11]+list(range(1,11))),_array(list(range(1,12)))];maximum=_array(list(range(100,0,-1)))
        else:raws=[_array([1]),_array([1000]),_array([100000]),_array([999,990,900])];maximum=_array([99999]*1000)
        for j in range(13):
            n=12+j if pid=='abc474_b' else 5+j
            if pid=='abc474_b':
                a=list(range(1,n+1))
                if j%2:rng.shuffle(a)
                else:a=list(reversed(a[:10]))+a[10:]
            else:
                upper=n if pid=='abc470_b' else 100000 if pid in ('abc472_b','abc475_b') else 100
                a=[rng.randint(1,upper) for _ in range(n)]
            raws.append(_array(a))
        raws.append(maximum)
    elif pid=='abc001_3':
        raws=[f'{deg} {dis}\n' for deg,dis in [(0,0),(3599,14),(112,15),(113,15),(337,93),(338,93),(562,201),(563,201),(787,327),(788,327),(1012,477),(1013,477),(3487,1958),(3488,1959),(1687,1029),(2587,644),(2048,16),(3599,11999)]]
    elif pid=='abc002_3':
        raws=['0 0 1 0 0 1\n','-1000 -1000 1000 -1000 -1000 1000\n','1000 1000 -1000 1000 1000 -1000\n']
        for j in range(14):
            a=[rng.randint(-1000,1000) for _ in range(6)]
            while (a[2]-a[0])*(a[5]-a[1])==(a[3]-a[1])*(a[4]-a[0]):a=[rng.randint(-1000,1000) for _ in range(6)]
            raws.append(' '.join(map(str,a))+'\n')
        raws.append('-1000 -1000 1000 1000 -1000 1000\n')
    elif pid=='abc003_3':
        raws=['1 1\n1\n','1 1\n4000\n','2 1\n1 4000\n','2 2\n4000 1\n']
        for j in range(13):
            n=3+j;k=1+j%n;raws.append(f'{n} {k}\n'+' '.join(str(rng.randint(1,4000)) for _ in range(n))+'\n')
        raws.append('100 100\n'+' '.join(['4000']*100)+'\n')
    elif pid=='abc004_3':raws=[f'{n}\n' for n in (1,2,4,5,6,9,10,14,15,22,29,30,31,59,60,61,999999999,1000000000)]
    elif pid=='abc005_3':
        def cake(t: int,a: list[int],b: list[int]) -> str:return f'{t}\n{len(a)}\n'+ ' '.join(map(str,a))+f'\n{len(b)}\n'+' '.join(map(str,b))+'\n'
        raws=[cake(1,[1],[1]),cake(1,[1],[2]),cake(1,[1],[3]),cake(1,[2],[1]),cake(1,[1],[1,1]),cake(1,[1,2,3],[1,2,2])]
        for j in range(11):
            n=3+j; a=sorted(rng.randint(1,100) for _ in range(n));b=sorted(rng.randint(1,100) for _ in range(n if j%2 else n//2));raws.append(cake(1+j,a,b))
        raws.append(cake(100,[1]*100,[100]*100))
    elif pid=='abc006_3':raws=[f'{n} {m}\n' for n,m in [(1,1),(1,2),(1,3),(1,4),(1,5),(3,9),(7,23),(10,19),(10,20),(10,21),(10,30),(10,39),(10,40),(10,41),(100000,199999),(100000,200000),(100000,400000),(100000,500000)]]
    else:
        raws=[_maze(3,4,0),_maze(4,3,0),_maze(5,5,0),_maze(5,5,1)]
        raws.extend(_maze(6+j,7+j,j%2) for j in range(13))
        raws.append(_maze(50,50,1))
    _require(len(raws)==len(set(raws))==18, f'{pid}: duplicate/count')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'boundary_{i:02}'} for i,raw in enumerate(raws)]

TITLES = {'abc465_b': 'Parking 2', 'abc466_b': 'Representative Balls', 'abc467_b': 'Keep the Change', 'abc468_b': 'Corridor Watch', 'abc469_b': 'Isolated Seats', 'abc470_b': 'Monocolor', 'abc471_b': 'Survey Tabulation', 'abc472_b': 'Break a Stick', 'abc473_b': 'Old Maid', 'abc474_b': 'Exit Order', 'abc475_b': 'Change', 'abc001_3': '風力観測', 'abc002_3': '直訴', 'abc003_3': 'AtCoderプログラミング講座', 'abc004_3': '入れ替え', 'abc005_3': 'おいしいたこ焼きの売り方', 'abc006_3': 'スフィンクスのなぞなぞ', 'abc007_3': '幅優先探索'}
PUBLISHED_SAMPLES: dict[str, list[Case]] = {'abc465_b': [{'input': '700 300 9 17 7 21\n', 'expected': '7400\n'}, {'input': '600 500 9 17 17 20\n', 'expected': '1500\n'}, {'input': '900 200 12 14 11 13\n', 'expected': '1100\n'}], 'abc466_b': [{'input': '4 5\n1 3\n2 10\n1 7\n4 9\n', 'expected': '7 10 -1 9 -1\n'}, {'input': '5 5\n2 6\n5 12\n5 2\n5 9\n2 7\n', 'expected': '-1 7 -1 -1 12\n'}], 'abc467_b': [{'input': '3\n1 2 keep\n3 6 take\n5 9 keep\n', 'expected': '5\n'}, {'input': '8\n36 49 take\n38 73 keep\n27 85 take\n65 71 take\n52 86 keep\n48 60 keep\n37 98 keep\n5 38 keep\n', 'expected': '175\n'}], 'abc468_b': [{'input': '7 1\n.G...GG\n', 'expected': '1\n'}, {'input': '6 5\n......\n', 'expected': '6\n'}, {'input': '21 2\n....G...GG.....G.....\n', 'expected': '6\n'}], 'abc469_b': [{'input': '8\nxxoxxxox\n', 'expected': '2\n'}, {'input': '5\nooooo\n', 'expected': '0\n'}, {'input': '1\nx\n', 'expected': '1\n'}], 'abc470_b': [{'input': '4\n3 1 2 1\n', 'expected': '2\n'}, {'input': '5\n3 3 3 3 3\n', 'expected': '0\n'}, {'input': '9\n4 2 3 3 4 1 2 7 1\n', 'expected': '7\n'}], 'abc471_b': [{'input': '7\nARC\nabc\nahc\nABC\nbeginner\nAbC\nahc\n', 'expected': '3\n'}, {'input': '10\nx\nx\nx\nx\nx\nx\nx\nx\nx\nx\n', 'expected': '10\n'}], 'abc472_b': [{'input': '4\n5 2 3 8\n', 'expected': '2\n'}, {'input': '7\n31 41 59 26 53 58 97\n', 'expected': '51\n'}, {'input': '10\n67011 35764 33042 24098 63738 98760 17199 68579 21812 45408\n', 'expected': '28105\n'}], 'abc473_b': [{'input': '8\n2 7 1 8 2 8 1 8\n', 'expected': '15\n'}, {'input': '5\n1 2 3 4 5\n', 'expected': '15\n'}, {'input': '15\n58 97 74 16 97 74 97 16 51 52 58 52 74 32 43\n', 'expected': '297\n'}], 'abc474_b': [{'input': '25\n1 6 5 7 8 10 2 4 3 9 15 17 12 11 19 20 18 13 14 16 21 23 24 22 25\n', 'expected': 'Yes\n'}, {'input': '11\n11 10 7 2 1 5 6 4 8 9 3\n', 'expected': 'No\n'}], 'abc475_b': [{'input': '3\n1296 110 1\n', 'expected': '13 18 24\n'}, {'input': '12\n3141 592 65358 9 79 323 84 6264 3 38327 950 28\n', 'expected': '52 59 82\n'}], 'abc001_3': [{'input': '2750 628\n', 'expected': 'W 5\n'}, {'input': '161 8\n', 'expected': 'C 0\n'}, {'input': '3263 15\n', 'expected': 'NNW 1\n'}, {'input': '1462 1959\n', 'expected': 'SE 12\n'}, {'input': '1687 1029\n', 'expected': 'SSE 8\n'}, {'input': '2587 644\n', 'expected': 'WSW 5\n'}, {'input': '113 201\n', 'expected': 'NNE 3\n'}, {'input': '2048 16\n', 'expected': 'SSW 1\n'}], 'abc002_3': [{'input': '1 0 3 0 2 5\n', 'expected': '5.0\n'}, {'input': '-1 -2 3 4 5 6\n', 'expected': '2.0\n'}, {'input': '298 520 903 520 4 663\n', 'expected': '43257.5\n'}], 'abc003_3': [{'input': '2 2\n1000 1500\n', 'expected': '1000.000000\n'}, {'input': '2 1\n1000 1500\n', 'expected': '750\n'}, {'input': '10 5\n2604 2281 3204 2264 2200 2650 2229 2461 2439 2211\n', 'expected': '2820.031250000\n'}], 'abc004_3': [{'input': '1\n', 'expected': '213456\n'}, {'input': '5\n', 'expected': '234561\n'}, {'input': '22\n', 'expected': '615234\n'}, {'input': '100000000\n', 'expected': '345612\n'}], 'abc005_3': [{'input': '1\n3\n1 2 3\n3\n2 3 4\n', 'expected': 'yes\n'}, {'input': '1\n3\n1 2 3\n3\n2 3 5\n', 'expected': 'no\n'}, {'input': '1\n3\n1 2 3\n10\n1 2 3 4 5 6 7 8 9 10\n', 'expected': 'no\n'}, {'input': '1\n3\n1 2 3\n3\n1 2 2\n', 'expected': 'no\n'}, {'input': '2\n5\n1 3 6 10 15\n3\n4 8 16\n', 'expected': 'yes\n'}], 'abc006_3': [{'input': '3 9\n', 'expected': '1 1 1\n'}, {'input': '7 23\n', 'expected': '1 3 3\n'}, {'input': '10 41\n', 'expected': '-1 -1 -1\n'}], 'abc007_3': [{'input': '7 8\n2 2\n4 5\n########\n#......#\n#.######\n#..#...#\n#..##..#\n##.....#\n########\n', 'expected': '11\n'}, {'input': '5 8\n2 2\n2 4\n########\n#.#....#\n#.###..#\n#......#\n########\n', 'expected': '10\n'}, {'input': '50 50\n2 2\n49 49\n##################################################\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n#................................................#\n##################################################\n', 'expected': '94\n'}]}
SAMPLE_COUNTS = {pid: len(rows) for pid, rows in PUBLISHED_SAMPLES.items()}
