"""Statement-checked three-stage hints added while reviewing ABC133 B."""
HINTS_V91 = {
    'abc133_b': (
        '2点間の距離そのものではなく、距離の2乗を計算すると平方根を避けられます。',
        '全ての点の組 i<j を調べ、各座標差の2乗和が完全平方数か判定します。N<=10なので全組合せで十分です。',
        '疑似コード:\nans=0\nfor i=0..N-1:\n  for j=i+1..N-1:\n    s=sum((X[i][k]-X[j][k])^2 for k=0..D-1)\n    r=isqrt(s)\n    if r*r==s: ans+=1\nprint(ans)'
    ),
}
