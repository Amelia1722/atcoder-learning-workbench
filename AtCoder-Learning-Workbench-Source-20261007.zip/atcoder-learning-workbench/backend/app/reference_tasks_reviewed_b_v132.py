"""ABC254–256 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
from math import comb
import re

TASKS = ('abc254_b', 'abc255_b', 'abc256_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc254_b': [
        {'input': '3\n', 'expected': '1\n1 1\n1 2 1\n'},
        {'input': '10\n', 'expected': '1\n1 1\n1 2 1\n1 3 3 1\n1 4 6 4 1\n1 5 10 10 5 1\n1 6 15 20 15 6 1\n1 7 21 35 35 21 7 1\n1 8 28 56 70 56 28 8 1\n1 9 36 84 126 126 84 36 9 1\n'},
    ],
    'abc255_b': [
        {'input': '4 2\n2 3\n0 0\n0 1\n1 2\n2 0\n', 'expected': '2.23606797749978969\n'},
        {'input': '2 1\n2\n-100000 -100000\n100000 100000\n', 'expected': '282842.712474619009\n'},
        {'input': '8 3\n2 6 8\n-17683 17993\n93038 47074\n58079 -57520\n-41515 -89802\n-72739 68805\n24324 -73073\n71049 72103\n47863 19268\n', 'expected': '130379.280458974768\n'},
    ],
    'abc256_b': [
        {'input': '4\n1 1 3 2\n', 'expected': '3\n'},
        {'input': '3\n1 1 1\n', 'expected': '0\n'},
        {'input': '10\n2 2 4 1 1 1 4 2 2 1\n', 'expected': '8\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints(line: str, count: int, pattern: re.Pattern[str] = POS) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate254(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 30:
        raise ValueError('N')
    return n


def _validate255(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    n, k = _ints(lines[0], 2)
    if not 1 <= k < n <= 1000 or len(lines) != n + 2:
        raise ValueError('constraints/shape')
    a = _ints(lines[1], k)
    if any(not 1 <= x <= n for x in a) or any(a[i] >= a[i+1] for i in range(k-1)):
        raise ValueError('light indices')
    pts=[]; seen=set()
    for line in lines[2:]:
        x,y=_ints(line,2,SIGNED)
        if not (-100000 <= x <= 100000 and -100000 <= y <= 100000):
            raise ValueError('coordinate range')
        if (x,y) in seen:
            raise ValueError('duplicate point')
        seen.add((x,y)); pts.append((x,y))
    return tuple(a), tuple(pts)


def _validate256(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n=int(lines[0])
    if not 1 <= n <= 100:
        raise ValueError('N')
    a=_ints(lines[1],n)
    if any(not 1 <= x <= 4 for x in a):
        raise ValueError('A')
    return tuple(a)


def validate(pid: str, raw: str):
    if pid == 'abc254_b': return _validate254(raw)
    if pid == 'abc255_b': return _validate255(raw)
    if pid == 'abc256_b': return _validate256(raw)
    raise ValueError('unknown task')


def _triangle(n: int) -> str:
    return '\n'.join(' '.join(str(comb(i,j)) for j in range(i+1)) for i in range(n))


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value=validate(pid,raw)
    except (ValueError,TypeError,IndexError):
        return False
    if not isinstance(output,str) or not output or output != output.strip():
        return False
    if pid == 'abc254_b':
        return output == _triangle(value)
    if pid == 'abc255_b':
        try:
            actual=Decimal(output)
        except InvalidOperation:
            return False
        if not actual.is_finite() or actual < 0:
            return False
        lights, pts=value
        lit=[pts[i-1] for i in lights]
        max_min_sq=0
        for x,y in pts:
            nearest=min((x-lx)**2+(y-ly)**2 for lx,ly in lit)
            max_min_sq=max(max_min_sq,nearest)
        with localcontext() as ctx:
            ctx.prec=90
            truth=Decimal(max_min_sq).sqrt()
            diff=abs(actual-truth)
            tol=Decimal('1e-5')
            return diff <= tol or diff <= abs(truth)*tol
    a=value
    suffix=0; answer=0
    for x in reversed(a):
        suffix += x
        if suffix >= 4:
            answer += 1
    return output.isdigit() and int(output)==answer


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); out.append({'category':category,'input':raw})
    for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
    if pid == 'abc254_b':
        for n in (1,2,4,5,6,7,8,9,11,12,15,18,20,25,29): add(f'n{n}',f'{n}\n')
        add('constraint_max','30\n')
    elif pid == 'abc255_b':
        def pack(points,lights):
            return f'{len(points)} {len(lights)}\n'+' '.join(map(str,lights))+'\n'+''.join(f'{x} {y}\n' for x,y in points)
        cases=[
            ('min_horizontal',pack([(0,0),(3,0)],[1])),
            ('light_second',pack([(0,0),(3,4)],[2])),
            ('three_one_light',pack([(0,0),(1,0),(10,0)],[1])),
            ('two_lights_middle',pack([(-10,0),(0,0),(10,0)],[1,3])),
            ('square_one',pack([(0,0),(0,10),(10,0),(10,10)],[1])),
            ('square_two',pack([(0,0),(0,10),(10,0),(10,10)],[2,3])),
            ('negative',pack([(-5,-5),(-2,-1),(3,4),(8,-7)],[1,3])),
            ('large_axis',pack([(-100000,0),(100000,0),(0,1)],[3])),
            ('large_corners',pack([(-100000,-100000),(100000,100000),(-100000,100000),(100000,-100000)],[1,2])),
            ('five_three_lights',pack([(0,0),(1,2),(3,7),(8,4),(9,9)],[1,3,5])),
            ('six_sparse',pack([(-20,-10),(-10,30),(0,0),(10,-30),(30,10),(40,40)],[2,4])),
            ('many_lights',pack([(i,i*i%17) for i in range(20)],list(range(1,20)))),
            ('n50',pack([(i-25,(i*37)%101-50) for i in range(50)],[1,10,20,30,40])),
            ('n100',pack([(i-50,(i*97)%211-105) for i in range(100)],list(range(1,101,10)))),
        ]
        for c,r in cases: add(c,r)
        points=[]
        for i in range(1000):
            x=-100000+(i%500)*400
            y=-100000 if i<500 else 100000
            points.append((x,y))
        add('constraint_max',pack(points,list(range(1,1000))))
    else:
        cases=[
            ('one1','1\n1\n'),('one2','1\n2\n'),('one3','1\n3\n'),('one4','1\n4\n'),
            ('four_ones','4\n1 1 1 1\n'),('mixed_short','5\n1 2 1 3 2\n'),('all_twos','6\n2 2 2 2 2 2\n'),
            ('all_threes','6\n3 3 3 3 3 3\n'),('all_fours','6\n4 4 4 4 4 4\n'),
            ('alternating','8\n1 4 1 4 1 4 1 4\n'),('late_score','7\n1 1 1 1 1 1 1\n'),
            ('early_big','7\n4 1 1 1 1 1 1\n'),('pattern','12\n1 2 3 4 4 3 2 1 1 2 3 4\n'),
            ('n50','50\n'+' '.join(str(i%4+1) for i in range(50))+'\n'),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max','100\n'+' '.join(['4']*100)+'\n')
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
