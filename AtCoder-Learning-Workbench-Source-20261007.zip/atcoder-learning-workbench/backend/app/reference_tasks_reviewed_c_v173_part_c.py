"""Reviewed C tasks: score buckets, stride bitsets, edit band and snake digit DP."""
from __future__ import annotations
from bisect import bisect_right
from collections import defaultdict
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(384,390))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==384:
        require(len(rows)==1,'shape');a=ints(rows[0],5);require(100<=a[0]<=a[1]<=a[2]<=a[3]<=a[4]<=2718,'scores');return (a,)
    if number in (385,388):
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n)
        if number==385:require(1<=n<=3000 and all(1<=v<=3000 for v in a),'buildings')
        else:require(2<=n<=500000 and all(1<=v<=10**9 for v in a) and all(x<=y for x,y in zip(a,a[1:])),'mochi')
        return (a,)
    if number==386:
        require(len(rows)==3 and rows[0]=='1' and all(1<=len(s)<=500000 and re.fullmatch('[a-z]+',s) is not None for s in rows[1:]),'edit strings');return tuple(rows[1:])
    if number==387:
        require(len(rows)==1,'shape');l,r=ints(rows[0],2);require(10<=l<=r<=10**18,'range');return l,r
    q=ints(rows[0],1)[0];require(1<=q<=300000 and len(rows)==q+1,'shape');active=0;queries=[]
    for row in rows[1:]:
        a=ints(row);kind=a[0];require(kind in (1,2,3) and len(a)==(1 if kind==2 else 2),'query')
        if kind==1:require(1<=a[1]<=10**9,'length');active+=1
        elif kind==2:require(active>0,'nonempty');active-=1
        else:require(1<=a[1]<=active,'rank')
        queries.append(a)
    return (tuple(queries),)
def edit_one(s:str,t:str)->bool:
    if abs(len(s)-len(t))>1:return False
    previous={j:j for j in range(min(1,len(t))+1)}
    for i,c in enumerate(s,1):
        current:dict[int,int]={}
        for j in range(max(0,i-1),min(len(t),i+1)+1):current[j]=min(2,previous.get(j,2)+1,current.get(j-1,2)+1,previous.get(j-1,2)+(c!=t[j-1]) if j else 2)
        previous=current
    return previous.get(len(t),2)<=1
def snakes_upto(limit:int)->int:
    if limit<10:return 0
    states={(0,0,True):1}
    for bound in map(int,str(limit)):
        following:dict[tuple[int,int,bool],int]=defaultdict(int)
        for (lead,length,tight),ways in states.items():
            for digit in range((bound if tight else 9)+1):
                if length and digit>=lead:continue
                newlead=lead if length else digit;newlength=length+1 if length or digit else 0;following[newlead,newlength,tight and digit==bound]+=ways
        states=following
    return sum(ways for (lead,length,tight),ways in states.items() if length>=2)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==384:
        a=cast(tuple[int,...],data[0]);buckets:dict[int,list[str]]=defaultdict(list);names=[('',0)]
        for letter,score in zip('ABCDE',a):names+=[(name+letter,total+score) for name,total in names]
        for name,total in names[1:]:buckets[total].append(name)
        return '\n'.join(name for total in sorted(buckets,reverse=True) for name in sorted(buckets[total]))
    if number==385:
        a=cast(tuple[int,...],data[0]);groups:dict[int,list[int]]=defaultdict(list)
        for j,v in enumerate(a):groups[v].append(j)
        answer=1
        for positions in groups.values():
            if len(positions)<=answer:continue
            bits=sum(1<<j for j in positions);differences={right-left for i,left in enumerate(positions) for right in positions[i+1:]}
            for stride in differences:
                active=bits;length=0
                while active:length+=1;active &= active<<stride
                answer=max(answer,length)
        return str(answer)
    if number==386:return 'Yes' if edit_one(*cast(tuple[str,str],data)) else 'No'
    if number==387:
        l,r=cast(tuple[int,int],data);return str(snakes_upto(r)-snakes_upto(l-1))
    if number==388:
        a=cast(tuple[int,...],data[0]);return str(sum(bisect_right(a,v//2) for v in a))
    queries=cast(Queries,data[0]);tree=[0]*(len(queries)+1);added=0;removed=0;out=[]
    def prefix(count:int)->int:
        value=0
        while count:value+=tree[count];count-=count&-count
        return value
    for q in queries:
        if q[0]==1:
            added+=1;p=added
            while p<len(tree):tree[p]+=q[1];p+=p&-p
        elif q[0]==2:removed+=1
        else:out.append(str(prefix(removed+q[1]-1)-prefix(removed)))
    return '\n'.join(out)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc384_c':"a=list(map(int,input().split()));names=[]\nfor mask in range(1,32):\n name=''.join('ABCDE'[j] for j in range(5) if mask>>j&1);score=sum(a[j] for j in range(5) if mask>>j&1);names.append((-score,name))\nprint(*(name for score,name in sorted(names)),sep='\\n')\n",
'abc385_c':"n=int(input());a=list(map(int,input().split()));answer=1\nfor stride in range(1,n):\n dp=[1]*n\n for j in range(stride,n):\n  if a[j]==a[j-stride]:dp[j]=dp[j-stride]+1;answer=max(answer,dp[j])\nprint(answer)\n",
'abc386_c':"k=int(input());s=input();t=input()\nif len(s)==len(t):ok=sum(x!=y for x,y in zip(s,t))<=1\nelif abs(len(s)-len(t))!=1:ok=False\nelse:\n if len(s)>len(t):s,t=t,s\n j=0\n while j<len(s) and s[j]==t[j]:j+=1\n ok=s[j:]==t[j+1:]\nprint('Yes' if ok else 'No')\n",
'abc387_c':"def count(x):\n if x<10:return 0\n digits=list(map(int,str(x)));n=len(digits);answer=sum(lead**(length-1) for length in range(2,n) for lead in range(1,10))\n first=digits[0];answer+=sum(lead**(n-1) for lead in range(1,first))\n for j in range(1,n):\n  answer+=min(first,digits[j])*first**(n-j-1)\n  if digits[j]>=first:return answer\n return answer+1\nl,r=map(int,input().split());print(count(r)-count(l-1))\n",
'abc388_c':"n=int(input());a=list(map(int,input().split()));right=0;answer=0\nfor v in a:\n while right<n and a[right]<2*v:right+=1\n answer+=n-right\nprint(answer)\n",
'abc389_c':"q=int(input());prefix=[0];head=0\nfor _ in range(q):\n a=list(map(int,input().split()))\n if a[0]==1:prefix.append(prefix[-1]+a[1])\n elif a[0]==2:head+=1\n else:print(prefix[head+a[1]-1]-prefix[head])\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17300+number)
    if number==384:raws=[line(a) for a in ([100]*5,[100,100,100,100,101],[100,200,300,400,500],[100,100,200,200,400])];raws.extend(line(sorted(rng.randint(100,2718) for _ in range(5))) for _ in range(12));raws.extend([line([2714,2715,2716,2717,2718]),line([2718]*5)])
    elif number==385:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[1,1],[1,2],[1,2,1,2,1])];raws.extend(arr([rng.randint(1,6) for _ in range(n)]) for n in range(3,15));raws.extend([arr([1,3000]*1500),arr([3000]*3000)])
    elif number==386:
        def edit(s:str,t:str)->str:return '1\n'+s+'\n'+t+'\n'
        raws=[edit(s,t) for s,t in (('a','a'),('a','b'),('a','ab'),('ab','a'))]
        for n in range(3,15):s=''.join(rng.choice('abc') for _ in range(n));t=s if n%4==0 else s[:-1]+rng.choice('xyz') if n%4==1 else s+'a' if n%4==2 else s[:-2]+'zz';raws.append(edit(s,t))
        raws.extend([edit('a'*500000,'a'*499998+'bb'),edit('z'*500000,'z'*500000)])
    elif number==387:raws=[f'{l} {r}\n' for l,r in ((10,10),(11,11),(10,99),(98,101),(100,200),(201,202),(10,1000),(999,10000),(10,99999),(12345,67890),(10,10**6),(10**9-1,10**9+1),(10**12,10**12+1000),(10**15,10**15+10**6),(10**17,10**17+1),(10**18,10**18),(10**18-1,10**18),(10,10**18))]
    elif number==388:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1,1],[1,2],[2,3],[1,1,2,2])];raws.extend(arr(sorted(rng.randint(1,100) for _ in range(n))) for n in range(3,15));raws.extend([arr([1]*250000+[10**9]*250000),arr([10**9]*500000)])
    else:
        def queue(qs:list[str])->str:return f'{len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[queue(qs) for qs in (['1 1'],['1 1','3 1'],['1 1','2'],['1 2','1 3','3 2','2','3 1'])]
        for n in range(3,15):
            active=0;qs=[]
            for _ in range(n+5):
                kind=rng.randint(1,3) if active else 1
                if kind==1:qs.append(f'1 {rng.randint(1,100)}');active+=1
                elif kind==2:qs.append('2');active-=1
                else:qs.append(f'3 {rng.randint(1,active)}')
            raws.append(queue(qs))
        raws.extend([queue(['1 1000000000']*100000+['2']*99999+['1 1000000000']+['3 2']*100000),queue(['1 1000000000']*299999+['3 299999'])])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc384_c':('参加者は5問題の空でない部分集合です。','31通りの名前と得点を作り、得点の降順・名前の昇順で並べます。','疑似コード: mask=1..31で選ばれた文字を名前、対応配点の和をscoreにする; (-score,name)をsortしnameを各行へ出力。'),
'abc385_c':('選ぶビルの間隔を固定してみましょう。','間隔dについて、同じ高さのビルがd個前から何棟連続するかDPで求めます。','疑似コード: d=1..N-1; dp[i]=1; H[i]=H[i-d]ならdp[i]=dp[i-d]+1; 全dpの最大を出力。'),
'abc386_c':('1回の編集では文字列長の差は高々1です。','同長なら相違位置は高々1。長さが1違うなら最初の不一致で長い方の1文字だけ飛ばします。','疑似コード: 同長なら相違数<=1; 長さ差>1ならNo; 他は短いSと長いTで共通prefix長jを求め、S[j:]=T[j+1:]かを判定。'),
'abc387_c':('先頭の数字が決まれば、残りの各桁はそれ未満です。','x以下の個数を数え、count(R)-count(L-1)とします。短い桁数は先頭dに対しdの累乗で数えられます。','疑似コード: xより短い全長と先頭dのd^(長さ-1)を加算; 同長で先頭が小さい場合も加算; xと同先頭のprefixを走査し小さい次桁の選択数*残りの累乗を加算、条件を破れば終了。'),
'abc388_c':('小さい餅ごとに、2倍以上の大きな餅が何個あるか数えます。','配列が昇順なので、条件を満たす最初の位置は単調に右へ動きます。','疑似コード: right=0; 各A[i]でA[right]<2*A[i]の間right++; N-rightを答えへ加算。'),
'abc389_c':('追加された全ヘビの長さの累積和を保持すると頭の座標が分かります。','先頭から何匹抜けたかをheadで管理し、累積座標から抜けた長さを引きます。','疑似コード: prefix=[0],head=0; 追加lでprefix末尾へprefix[-1]+l; 削除でhead++; k照会でprefix[head+k-1]-prefix[head]を出力。')}

TITLES={'abc384_c': 'Perfect Standings', 'abc385_c': 'Illuminate Buildings', 'abc386_c': 'Operate 1', 'abc387_c': 'Snake Numbers', 'abc388_c': 'Various Kagamimochi', 'abc389_c': 'Snake Queue'}
PUBLISHED_SAMPLES={'abc384_c': [{'input': '400 500 600 700 800\n', 'expected': 'ABCDE\nBCDE\nACDE\nABDE\nABCE\nABCD\nCDE\nBDE\nADE\nBCE\nACE\nBCD\nABE\nACD\nABD\nABC\nDE\nCE\nBE\nCD\nAE\nBD\nAD\nBC\nAC\nAB\nE\nD\nC\nB\nA\n'}, {'input': '800 800 900 900 1000\n', 'expected': 'ABCDE\nACDE\nBCDE\nABCE\nABDE\nABCD\nCDE\nACE\nADE\nBCE\nBDE\nABE\nACD\nBCD\nABC\nABD\nCE\nDE\nAE\nBE\nCD\nAC\nAD\nBC\nBD\nAB\nE\nC\nD\nA\nB\n'}, {'input': '128 256 512 1024 2048\n', 'expected': 'ABCDE\nBCDE\nACDE\nCDE\nABDE\nBDE\nADE\nDE\nABCE\nBCE\nACE\nCE\nABE\nBE\nAE\nE\nABCD\nBCD\nACD\nCD\nABD\nBD\nAD\nD\nABC\nBC\nAC\nC\nAB\nB\nA\n'}], 'abc385_c': [{'input': '8\n5 7 5 7 7 5 7 7\n', 'expected': '3\n'}, {'input': '10\n100 200 300 400 500 600 700 800 900 1000\n', 'expected': '1\n'}, {'input': '32\n3 1 4 1 5 9 2 6 5 3 5 8 9 7 9 3 2 3 8 4 6 2 6 4 3 3 8 3 2 7 9 5\n', 'expected': '3\n'}], 'abc386_c': [{'input': '1\nabc\nagc\n', 'expected': 'Yes\n'}, {'input': '1\nabc\nawtf\n', 'expected': 'No\n'}, {'input': '1\nabc\nac\n', 'expected': 'Yes\n'}, {'input': '1\nback\nblack\n', 'expected': 'Yes\n'}, {'input': '1\nsame\nsame\n', 'expected': 'Yes\n'}, {'input': '1\nleap\nread\n', 'expected': 'No\n'}], 'abc387_c': [{'input': '97 210\n', 'expected': '6\n'}, {'input': '1000 9999\n', 'expected': '2025\n'}, {'input': '252509054433933519 760713016476190692\n', 'expected': '221852052834757\n'}], 'abc388_c': [{'input': '6\n2 3 4 4 7 10\n', 'expected': '8\n'}, {'input': '3\n387 388 389\n', 'expected': '0\n'}, {'input': '32\n1 2 4 5 8 10 12 16 19 25 33 40 50 64 87 101 149 175 202 211 278 314 355 405 412 420 442 481 512 582 600 641\n', 'expected': '388\n'}], 'abc389_c': [{'input': '7\n1 5\n1 7\n3 2\n1 3\n1 4\n2\n3 3\n', 'expected': '5\n10\n'}, {'input': '3\n1 1\n2\n1 3\n', 'expected': '\n'}, {'input': '10\n1 15\n1 10\n1 5\n2\n1 5\n1 10\n1 15\n2\n3 4\n3 2\n', 'expected': '20\n5\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
