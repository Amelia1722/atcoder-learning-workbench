"""ABC056–058 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS = ('abc056_b','abc057_b','abc058_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)',re.ASCII)
LOWER = re.compile(r'[a-z]+',re.ASCII)

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc056_b':
        if len(lines)!=1: raise ValueError('line count')
        tokens=lines[0].split(' ')
        if len(tokens)!=3 or any(INT.fullmatch(x) is None for x in tokens): raise ValueError('integer tokens')
        w,a,bb=map(int,tokens)
        if not all(1<=v<=100000 for v in (w,a,bb)): raise ValueError('value range')
        return w,a,bb
    if pid == 'abc057_b':
        if not lines: raise ValueError('no dimensions')
        counts=lines[0].split(' ')
        if len(counts)!=2 or any(INT.fullmatch(x) is None for x in counts): raise ValueError('dimensions')
        n,m=map(int,counts)
        if not (1<=n<=50 and 1<=m<=50) or len(lines)!=1+n+m: raise ValueError('line counts')
        pts=[]
        for line in lines[1:]:
            coords=line.split(' ')
            if len(coords)!=2 or any(SIGNED.fullmatch(v) is None for v in coords): raise ValueError('coords')
            x,y=map(int,coords)
            if not (-100000000<=x<=100000000 and -100000000<=y<=100000000): raise ValueError('coords range')
            pts.append((x,y))
        return pts[:n],pts[n:]
    if len(lines)!=2 or any(LOWER.fullmatch(s) is None for s in lines): raise ValueError('invalid strings')
    o,e=lines
    if not (1<=len(o)<=50 and 1<=len(e)<=50 and len(o)-len(e) in (0,1)):
        raise ValueError('length constraint')
    return o,e

def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value=validate(pid,raw)
    except (ValueError,TypeError,IndexError):
        return False
    if not isinstance(output,str): return False
    if pid=='abc056_b':
        w,a,bb=value
        # Independent interval-gap implementation; a meeting endpoint has gap 0.
        left1,right1=a,a+w
        left2,right2=bb,bb+w
        gap = left2-right1 if right1<left2 else (left1-right2 if right2<left1 else 0)
        return output==str(gap)
    if pid=='abc057_b':
        students,checkpoints=value
        answer=[]
        for x,y in students:
            best_distance=None
            best_index=0
            for index,(cx,cy) in enumerate(checkpoints,1):
                d=abs(cx-x)+abs(cy-y)
                if best_distance is None or d<best_distance:
                    best_distance=d;best_index=index
            answer.append(str(best_index))
        return output=='\n'.join(answer)
    o,e=value
    out=['']*(len(o)+len(e))
    out[::2]=o
    out[1::2]=e
    return output==''.join(out)

def generate(pid: str, seed: int=66)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v66:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw);rows.append({'category':category,'input':raw})
    if pid=='abc056_b':
        fixtures=[(1,1,1),(1,1,2),(1,2,1),(1,1,3),(1,3,1),(3,2,6),(3,1,3),
                  (5,10,1),(5,1,10),(10,25,35),(10,35,25),(100000,1,100000),
                  (1,99999,100000),(100000,100000,1)]
        for w,a,bb in fixtures: add('boundary' if w==1 else 'normal',f'{w} {a} {bb}\n')
        while len(rows)<17:
            add('random',f'{rng.randint(1,100000)} {rng.randint(1,100000)} {rng.randint(1,100000)}\n')
        add('constraint_max','100000 100000 100000\n')
    elif pid=='abc057_b':
        def fmt(students,checkpoints):
            return f'{len(students)} {len(checkpoints)}\n'+''.join(f'{x} {y}\n' for x,y in [*students,*checkpoints])
        fixtures=[([(0,0)],[(0,0)]), ([(0,0)],[(1,0),(-1,0)]),
                  ([(2,0),(0,0)],[(-1,0),(1,0)]),
                  ([(10,10),(-10,-10),(3,3)],[(1,2),(2,3),(3,5),(3,5)]),
                  ([(-100000000,-100000000)],[(100000000,100000000)]),
                  ([(100000000,100000000)],[(100000000,100000000),(-100000000,-100000000)]),
                  ([(0,0),(0,0)],[(1,1),(1,1)]),
                  ([(0,0)],[(-1,0),(1,0),(0,1)]),
                  ([(-1,1),(1,-1)],[(0,0)]),
                  ([(0,0)],[(0,-1),(0,1)]),
                  ([(9,9),(8,8)],[(7,7),(10,10)]),
                  ([(100000000,-100000000)],[(-100000000,100000000)]),
                  ([(4,-4),(5,-5)],[(5,-4),(-5,5)]),
                  ([(1,2),(3,4)],[(1,2),(3,4)])]
        for s,c in fixtures: add('boundary' if len(s)==1 else 'normal',fmt(s,c))
        while len(rows)<17:
            n=rng.randint(1,12);m=rng.randint(1,12)
            s=[(rng.randint(-100000000,100000000),rng.randint(-100000000,100000000)) for _ in range(n)]
            c=[(rng.randint(-100000000,100000000),rng.randint(-100000000,100000000)) for _ in range(m)]
            add('random',fmt(s,c))
        s=[((-1)**i*100000000,(-1)**(i//2)*100000000) for i in range(50)]
        c=[((-1)**(i+1)*100000000,(-1)**((i+1)//2)*100000000) for i in range(50)]
        add('constraint_max',fmt(s,c))
    else:
        fixtures=[('a','a'),('a','b'),('aa','a'),('ab','a'),('ab','cd'),
                  ('xyz','abc'),('abc','ab'),('ab','aa'),('zz','zz'),('abc','abc'),
                  ('aaaa','aaa'),('zxy','abc'),('az','z'),('hello','world')]
        for o,e in fixtures: add('boundary' if len(o)==1 else 'normal',f'{o}\n{e}\n')
        while len(rows)<17:
            n=rng.randint(1,49);k=n-rng.randrange(2)
            o=''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(n))
            e=''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(k))
            add('random',f'{o}\n{e}\n')
        add('constraint_max',f'{"a"*50}\n{"z"*50}\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
