"""Statement-checked three-stage hints added while reviewing ABC137–139 B."""
HINTS_V93 = {
    'abc137_b': (
        '座標Xが黒になるような長さKの連続区間は、左端をどこまで動かせるか考えてください。',
        '最も左に広がる場合はX-K+1、最も右に広がる場合はX+K-1です。その間の全整数が候補になります。',
        '疑似コード:\nleft = X-K+1\nright = X+K-1\nprint(left, left+1, ..., right)'
    ),
    'abc138_b': (
        '求める式をそのまま「各Aiの逆数を足す処理」と「最後にもう一度逆数を取る処理」に分けてください。',
        's = 1/A1 + ... + 1/AN を浮動小数で計算し、答えは1/sです。整数除算 // ではなく / を使います。',
        '疑似コード:\ns=0.0\nfor a in A:\n  s += 1.0/a\nprint(1.0/s)'
    ),
    'abc139_b': (
        '最初から差込口は1口あります。電源タップを1個追加すると、差込口の総数は実質いくつ増えるでしょうか。',
        '1口を使ってA口に置き換えるので純増はA-1です。1 + k*(A-1) >= B を満たす最小kを求めます。',
        '疑似コード:\nans=0\nsockets=1\nwhile sockets < B:\n  sockets += A-1\n  ans += 1\nprint(ans)'
    ),
}
