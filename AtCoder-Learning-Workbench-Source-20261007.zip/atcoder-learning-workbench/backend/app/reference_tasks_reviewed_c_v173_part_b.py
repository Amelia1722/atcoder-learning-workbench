"""Position groups, stone potentials, run lengths and shortest paths."""
from __future__ import annotations
from bisect import bisect_left
from collections import defaultdict
from heapq import heapify,heappop,heappush
from itertools import groupby
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(378,384))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers')
    values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'fields');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==378:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=200000 and all(1<=v<=10**9 for v in a),'values');return (a,)
    if number==379:
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(2<=n<=2*10**9 and 1<=m<=min(n,200000),'size');x,a=ints(rows[1],m),ints(rows[2],m);require(len(set(x))==m and all(1<=v<=n for v in x) and all(1<=v<=2*10**9 for v in a),'stones');return n,x,a
    if number==380:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);s=rows[1];require(1<=n<=500000 and len(s)==n and re.fullmatch('[01]+',s) is not None and 2<=k<=sum(c=='1' for c,_ in groupby(s)),'runs');return k,s
    if number==381:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(1<=n<=200000 and len(s)==n and '/' in s and re.fullmatch('[12/]+',s) is not None,'string');return (s,)
    if number==382:
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(1<=n<=200000 and 1<=m<=200000,'size');a,b=ints(rows[1],n),ints(rows[2],m);require(all(1<=v<=200000 for seq in (a,b) for v in seq),'tastes');return a,b
    h,w,d=ints(rows[0],3);require(1<=h<=1000 and 1<=w<=1000 and 0<=d<=h*w and len(rows)==h+1,'grid');grid=tuple(rows[1:]);require(all(len(row)==w and re.fullmatch('[#.H]+',row) is not None for row in grid),'cells');return h,w,d,grid

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==378:
        a=cast(tuple[int,...],data[0]);groups:dict[int,list[int]]=defaultdict(list)
        for j,v in enumerate(a,1):groups[v].append(j)
        answer=[-1]*len(a)
        for positions in groups.values():
            for previous,current in zip(positions,positions[1:]):answer[current-1]=previous
        return ' '.join(map(str,answer))
    if number==379:
        n,x,a=cast(tuple[int,tuple[int,...],tuple[int,...]],data);pairs=sorted(zip(x,a));stock=0
        if sum(a)!=n:return '-1'
        for position,amount in pairs:
            if stock<position-1:return '-1'
            stock+=amount
        return str(n*(n+1)//2-sum(position*amount for position,amount in pairs))
    if number==380:
        k,s=cast(tuple[int,str],data);runs=[(c,sum(1 for _ in seq)) for c,seq in groupby(s)];ones=0
        for j,(char,_) in enumerate(runs):
            if char=='1':ones+=1
            if ones==k:runs[j-1],runs[j]=runs[j],runs[j-1];break
        return ''.join(char*length for char,length in runs)
    if number==381:
        s=cast(str,data[0]);runs=[(c,sum(1 for _ in seq)) for c,seq in groupby(s)];best=1
        for j in range(1,len(runs)-1):
            if runs[j]==('/',1) and runs[j-1][0]=='1' and runs[j+1][0]=='2':best=max(best,2*min(runs[j-1][1],runs[j+1][1])+1)
        return str(best)
    if number==382:
        a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);people=sorted((v,j) for j,v in enumerate(a,1));queries=sorted((v,j) for j,v in enumerate(b));answer=[-1]*len(b);p=0;first=len(a)+1
        for taste,j in queries:
            while p<len(people) and people[p][0]<=taste:first=min(first,people[p][1]);p+=1
            if first<=len(a):answer[j]=first
        return '\n'.join(map(str,answer))
    h,w,d,grid=cast(tuple[int,int,int,tuple[str,...]],data);inf=h*w+1;distance=[inf]*(h*w);heap=[]
    for r,row in enumerate(grid):
        for c,value in enumerate(row):
            if value=='H':index=r*w+c;distance[index]=0;heap.append((0,index))
    heapify(heap);answer=0
    while heap:
        length,index=heappop(heap)
        if length!=distance[index]:continue
        answer+=1
        if length==d:continue
        r,c=divmod(index,w)
        for nr,nc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
            if 0<=nr<h and 0<=nc<w and grid[nr][nc]!='#':
                target=nr*w+nc
                if length+1<distance[target]:distance[target]=length+1;heappush(heap,(length+1,target))
    return str(answer)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc378_c':"n=int(input());a=list(map(int,input().split()));last={};out=[]\nfor j,v in enumerate(a,1):out.append(last.get(v,-1));last[v]=j\nprint(*out)\n",
'abc379_c':"n,m=map(int,input().split());x=list(map(int,input().split()));a=list(map(int,input().split()));pairs=sorted(zip(x,a));pairs.append((n+1,0));carry=0;answer=0;ok=pairs[0][0]==1\nfor j in range(m):\n p,amount=pairs[j];gap=pairs[j+1][0]-p;carry+=amount\n if carry<gap:ok=False\n answer+=gap*carry-gap*(gap+1)//2;carry-=gap\nprint(answer if ok and carry==0 else -1)\n",
'abc380_c':"n,k=map(int,input().split());s=input();starts=[];ends=[]\nfor j,c in enumerate(s):\n if c=='1' and (j==0 or s[j-1]=='0'):starts.append(j)\n if c=='1' and (j==n-1 or s[j+1]=='0'):ends.append(j+1)\na=ends[k-2];b=starts[k-1];c=ends[k-1];print(s[:a]+s[b:c]+s[a:b]+s[c:])\n",
'abc381_c':"n=int(input());s=input();left=[0]*n;right=[0]*n\nfor j in range(n):\n if s[j]=='1':left[j]=1+(left[j-1] if j else 0)\nfor j in range(n-1,-1,-1):\n if s[j]=='2':right[j]=1+(right[j+1] if j+1<n else 0)\nprint(max(2*min(left[j-1] if j else 0,right[j+1] if j+1<n else 0)+1 for j,c in enumerate(s) if c=='/'))\n",
'abc382_c':"from bisect import bisect_left\nn,m=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));values=[];indices=[];low=200001\nfor j,v in enumerate(a,1):\n if v<low:values.append(-v);indices.append(j);low=v\nfor v in b:\n p=bisect_left(values,-v);print(indices[p] if p<len(values) else -1)\n",
'abc383_c':"from collections import deque\nh,w,d=map(int,input().split());grid=[input() for _ in range(h)];distance=[-1]*(h*w);queue=deque()\nfor r in range(h):\n for c in range(w):\n  if grid[r][c]=='H':distance[r*w+c]=0;queue.append(r*w+c)\nanswer=len(queue)\nwhile queue:\n index=queue.popleft();r,c=divmod(index,w)\n if distance[index]==d:continue\n for nr,nc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):\n  if 0<=nr<h and 0<=nc<w and grid[nr][nc]!='#' and distance[nr*w+nc]<0:\n   target=nr*w+nc;distance[target]=distance[index]+1;queue.append(target);answer+=1\nprint(answer)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17300+number)
    if number==378:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[1,1],[1,2,1],[10**9,1,10**9])];raws.extend(arr([rng.randint(1,7) for _ in range(n)]) for n in range(4,16));raws.extend([arr(list(range(1,200001))),arr([10**9]*200000)])
    elif number==379:
        def stones(n:int,x:list[int],a:list[int])->str:return f'{n} {len(x)}\n'+line(x)+line(a)
        raws=[stones(n,x,a) for n,x,a in ((2,[1],[2]),(2,[2],[2]),(3,[1],[2]),(3,[3,1],[1,2]))]
        for n in range(4,16):
            x=rng.sample(range(1,n+1),rng.randint(1,n));raws.append(stones(n,x,[rng.randint(1,4) for _ in x]))
        raws.extend([stones(200000,list(range(200000,0,-1)),[1]*200000),stones(2*10**9,[1],[2*10**9])])
    elif number==380:
        def move(k:int,s:str)->str:return f'{len(s)} {k}\n{s}\n'
        raws=[move(k,s) for k,s in ((2,'101'),(2,'01010'),(2,'110011'),(3,'10101'))]
        for n in range(4,16):
            s='0'*rng.randint(0,3)+'10'*n+'1'+'0'*rng.randint(0,3);raws.append(move(rng.randint(2,n+1),s))
        raws.extend([move(2,'1'*249999+'0'+'1'*250000),move(250000,'10'*250000)])
    elif number==381:
        def text(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[text(s) for s in ('/','1/2','//','22/11')];raws.extend(text(''.join(rng.choice('12/') for _ in range(n))+'/') for n in range(4,16));raws.extend([text('1'*99999+'/'+'2'*100000),text('/'*200000)])
    elif number==382:
        def sushi(a:list[int],b:list[int])->str:return f'{len(a)} {len(b)}\n'+line(a)+line(b)
        raws=[sushi(a,b) for a,b in (([1],[1]),([2],[1]),([3,1],[2,3]),([1,1],[1,2]))];raws.extend(sushi([rng.randint(1,20) for _ in range(n)],[rng.randint(1,20) for _ in range(n+1)]) for n in range(4,16));raws.extend([sushi(list(range(200000,0,-1)),list(range(1,200001))),sushi([200000]*200000,[200000]*200000)])
    else:
        def office(d:int,grid:list[str])->str:return f'{len(grid)} {len(grid[0])} {d}\n'+'\n'.join(grid)+'\n'
        raws=[office(d,g) for d,g in ((0,['#']),(0,['H']),(1,['H.']),(2,['H#.']))]
        for n in range(4,16):grid=[''.join(rng.choice('#.H') for _ in range(n)) for _ in range(n)];raws.append(office(n//2,grid))
        raws.extend([office(1000000,['H'+'.'*999]+['.'*1000]*999),office(1000000,['H'*1000]*1000)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc378_c':('同じ値を最後に見た位置を記録します。','左から処理し、記録を答えに使ってから現在位置へ更新します。','疑似コード: lastを空にする; 各iでB[i]=last.get(A[i],-1); last[A[i]]=i; Bを出力。'),
'abc379_c':('石は右にしか動かせません。位置を昇順に整理します。','次の石のある位置までのマスを埋め、余った石を右へ運びます。区間の移動回数は等差数列の和で計算します。','疑似コード: (X,A)をsortし(N+1,0)を追加; 最初のXが1でなければ-1; 各区間長gでcarry+=A; carry<gなら不可; answer+=g*carry-g*(g+1)/2; carry-=g; 最後carry=0ならanswer。'),
'abc380_c':('K番目の1の塊と、その直前の0の塊を入れ替えます。','K-1番目の1の末尾、K番目の1の先頭と末尾を見つけると部分文字列で組み立てられます。','疑似コード: a=直前の1塊の終了位置, b=K番目の開始, c=終了（半開区間）; S[:a]+S[b:c]+S[a:b]+S[c:]を出力。'),
'abc381_c':('各/を中央にして、左の連続1と右の連続2を数えます。','両側の短い方に合わせると、その中央で作れる最長の長さが決まります。','疑似コード: left[i]=iで終わる連続1の長さ、right[i]=iで始まる連続2の長さ; 各S[i]=/で2*min(left[i-1],right[i+1])+1を調べ最大値。'),
'abc382_c':('人を左から見て、美食度の最小値が更新される位置だけを残します。','残した値は単調減少します。寿司の美味しさ以下となる最初の位置を二分探索できます。','疑似コード: A[i]がprefix最小を更新したら(-A[i],i)を保存; 各Bで負値列にlower_bound(-B)し、対応するiまたは-1を出力。'),
'abc383_c':('複数の加湿器をすべて距離0の始点にします。','壁を避ける幅優先探索で最寄りの加湿器までの距離を求め、D以内の床を数えます。','疑似コード: 全Hをqueueへ入れdist=0; popしたdist<Dのマスの未訪問な上下左右の床へdist+1で進む; 訪問した床の総数を出力。')}

TITLES={'abc378_c': 'Repeating', 'abc379_c': 'Sowing Stones', 'abc380_c': 'Move Segment', 'abc381_c': '11/22 Substring', 'abc382_c': 'Kaiten Sushi', 'abc383_c': 'Humidifier 3'}
PUBLISHED_SAMPLES={'abc378_c': [{'input': '5\n1 2 1 1 3\n', 'expected': '-1 -1 1 3 -1\n'}, {'input': '4\n1 1000000000 1000000000 1\n', 'expected': '-1 -1 2 1\n'}], 'abc379_c': [{'input': '5 2\n1 4\n3 2\n', 'expected': '4\n'}, {'input': '10 3\n1 4 8\n4 2 4\n', 'expected': '-1\n'}], 'abc380_c': [{'input': '15 3\n010011100011001\n', 'expected': '010011111000001\n'}, {'input': '10 2\n1011111111\n', 'expected': '1111111110\n'}], 'abc381_c': [{'input': '8\n211/2212\n', 'expected': '5\n'}, {'input': '5\n22/11\n', 'expected': '1\n'}, {'input': '22\n/1211/2///2111/2222/11\n', 'expected': '7\n'}], 'abc382_c': [{'input': '3 3\n3 8 2\n5 2 1\n', 'expected': '1\n3\n-1\n'}, {'input': '3 3\n1 1 1\n1 1 1\n', 'expected': '1\n1\n1\n'}, {'input': '10 5\n60 83 76 45 70 91 37 58 94 22\n70 39 52 33 18\n', 'expected': '1\n7\n4\n10\n-1\n'}], 'abc383_c': [{'input': '3 4 1\nH...\n#..H\n.#.#\n', 'expected': '5\n'}, {'input': '5 6 2\n##...H\nH.....\n..H.#.\n.HH...\n.###..\n', 'expected': '21\n'}, {'input': '1 6 3\n...#..\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
