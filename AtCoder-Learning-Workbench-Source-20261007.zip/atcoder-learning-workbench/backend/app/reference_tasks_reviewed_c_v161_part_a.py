"""Reviewed ABC135--140 C: canonical inputs and independent mathematical oracles."""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction
from itertools import islice,permutations
from typing import cast
import random
import re

TASKS=tuple(f'abc{n}_c' for n in range(135,141))
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES={'abc138_c':'numeric_tolerance_1e-5'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'field count');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');n=ints(rows[0],1)[0];number=int(pid[3:6])
    if number==135:
        require(1<=n<=100000 and len(rows)==3,'shape');a=ints(rows[1],n+1);b=ints(rows[2],n)
        require(all(1<=x<=10**9 for x in a+b),'capacities');return a,b
    if number==137:
        require(2<=n<=100000 and len(rows)==n+1,'shape');words=tuple(rows[1:]);require(len(set(words))==n and all(re.fullmatch('[a-z]{10}',s) is not None for s in words),'distinct words');return (words,)
    if number==138:
        require(2<=n<=50 and len(rows)==2,'shape');vs=ints(rows[1],n);require(all(1<=v<=1000 for v in vs),'values');return (vs,)
    if number==140:
        require(2<=n<=100 and len(rows)==2,'shape');b=ints(rows[1],n-1);require(all(0<=v<=100000 for v in b),'bounds');return (b,)
    require(1<=n<=100000 and len(rows)==2,'shape');h=ints(rows[1],n);require(all(1<=v<=10**9 for v in h),'heights');return (h,)

def city_min_cut(a:tuple[int,...],b:tuple[int,...])->int:
    # City side 1 incurs A capacity; hero can be source-side iff both cities are.
    zero=0;one=a[0]
    for j,capacity in enumerate(b):
        zero,one=min(zero,one)+capacity,min(zero+capacity,one)+a[j+1]
    return min(zero,one)

def alchemist_exact(vs:tuple[int,...])->Fraction:
    a=sorted(vs);power=1<<(len(a)-1);numerator=a[0]+a[1]
    for j in range(2,len(a)):numerator+=a[j]*(1<<(j-1))
    return Fraction(numerator,power)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==135:return str(city_min_cut(*cast(tuple[tuple[int,...],tuple[int,...]],data)))
    if number==136:
        h=cast(tuple[int,...],data[0]);maximum=0
        for current in h:
            if maximum>current+1:return 'No'
            maximum=max(maximum,current)
        return 'Yes'
    if number==137:
        words=cast(tuple[str,...],data[0]);signatures=sorted(tuple(word.count(chr(97+j)) for j in range(26)) for word in words);answer=0;run=0;previous:tuple[int,...]|None=None
        for signature in signatures:
            if signature!=previous:run=0;previous=signature
            answer+=run;run+=1
        return str(answer)
    if number==138:return format(float(alchemist_exact(cast(tuple[int,...],data[0]))),'.17g')
    if number==139:
        h=cast(tuple[int,...],data[0]);breaks=[0]+[j for j in range(1,len(h)) if h[j]>h[j-1]]+[len(h)]
        return str(max(b-a-1 for a,b in zip(breaks,breaks[1:])))
    b=cast(tuple[int,...],data[0]);events:dict[int,set[int]]=defaultdict(set)
    for j,value in enumerate(b):events[value].update((j,j+1))
    active=len(b)+1;removed:set[int]=set();previous=0;total=0
    for value,vertices in sorted(events.items()):
        total+=(value-previous)*active;new=vertices-removed;active-=len(new);removed.update(vertices);previous=value
    return str(total)

def numeric_138_valid(raw:str,actual:str)->bool:
    try:
        vs=cast(tuple[int,...],validate('abc138_c',raw)[0]);token=actual.removesuffix('\n')
        if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
        # Bound exponent before Fraction parsing to avoid unbounded integers.
        exponent=re.search(r'[eE]([+-]?[0-9]+)$',token)
        if exponent and abs(int(exponent[1]))>1000:return False
        expected=alchemist_exact(vs);error=abs(Fraction(token)-expected);return error<=max(Fraction(1),abs(expected))/100000
    except (ValueError,TypeError,IndexError,OverflowError,ZeroDivisionError):return False

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc138_c':return numeric_138_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc138_c':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc135_c':"n=int(input());a=list(map(int,input().split()));b=list(map(int,input().split()));answer=0\nfor j in range(n):\n left=min(a[j],b[j]);a[j]-=left;b[j]-=left;right=min(a[j+1],b[j]);a[j+1]-=right;answer+=left+right\nprint(answer)\n",
'abc136_c':"n=int(input());h=list(map(int,input().split()));ok=True\nfor j in range(n-2,-1,-1):\n if h[j]>h[j+1]:h[j]-=1\n if h[j]>h[j+1]:ok=False\nprint('Yes' if ok else 'No')\n",
'abc137_c':"from collections import Counter\nn=int(input());counts=Counter(''.join(sorted(input())) for _ in range(n));print(sum(c*(c-1)//2 for c in counts.values()))\n",
'abc138_c':"n=int(input());v=sorted(map(int,input().split()));value=v[0]\nfor x in v[1:]:value=(value+x)/2\nprint(value)\n",
'abc139_c':"n=int(input());h=list(map(int,input().split()));best=run=0\nfor a,b in zip(h,h[1:]):\n run=run+1 if a>=b else 0;best=max(best,run)\nprint(best)\n",
'abc140_c':"n=int(input());b=list(map(int,input().split()));print(b[0]+b[-1]+sum(min(a,c) for a,c in zip(b,b[1:])))\n"}

def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16100+number);raws:list[str]=[]
    if number==135:
        def city(a:list[int],b:list[int])->str:return f'{len(b)}\n'+line(a)+line(b)
        raws=[city([1,1],[1]),city([1,1],[2]),city([10**9,10**9],[10**9]),city([100,1,1],[1,100])]+[city([rng.randrange(1,101) for _ in range(n+1)],[rng.randrange(1,101) for _ in range(n)]) for n in range(2,14)]+[city([1]*100001,[10**9]*100000),city([10**9]*100001,[10**9]*100000)]
    elif number==137:
        def strings(words:list[str])->str:return f'{len(words)}\n'+'\n'.join(words)+'\n'
        raws=[strings(['a'*10,'b'*10]),strings(['abcdefgxyz','zyxgfedcba']),strings(['a'*9+'b','b'+'a'*9]),strings(['a'*10,'a'*9+'b','a'*8+'bb'])]
        for n in range(4,17):
            words:set[str]=set()
            while len(words)<n:words.add(''.join(rng.choice('abcde') for _ in range(10)))
            raws.append(strings(sorted(words)))
        raws.append(strings([''.join(p) for p in islice(permutations('abcdefghij'),100000)]))
    elif number==138:
        def blend(v:list[int])->str:return f'{len(v)}\n'+line(v)
        raws=[blend([1,1]),blend([1,1000]),blend([1000,1]),blend([1,1,1000])]+[blend([rng.randrange(1,1001) for _ in range(n)]) for n in range(3,15)]+[blend([1]+[1000]*49),blend([1000]*50)]
    elif number==140:
        def bounds(b:list[int])->str:return f'{len(b)+1}\n'+line(b)
        raws=[bounds([0]),bounds([100000]),bounds([0,100000]),bounds([100000,0])]+[bounds([rng.randrange(0,100001) for _ in range(n)]) for n in range(3,15)]+[bounds([0 if j%2 else 100000 for j in range(99)]),bounds([100000]*99)]
    else:
        def heights(h:list[int])->str:return f'{len(h)}\n'+line(h)
        raws=[heights([1]),heights([10**9]),heights([2,1]),heights([3,1])]+[heights([rng.randrange(1,11) for _ in range(n)]) for n in range(2,14)]+[heights([2 if j%2 else 1 for j in range(100000)]),heights([10**9]*100000)]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc135_c':('各勇者が攻撃できる二つの街のうち、左の街を優先します。','左の街の残りを倒せるだけ倒し、能力が余ったら右の街へ使います。次の勇者は左の街に戻れません。','疑似コード: for i: left=min(A[i],B[i]); A[i]-=left; remaining=B[i]-left; right=min(A[i+1],remaining); A[i+1]-=right; answer+=left+right; print(answer)。'),
'abc136_c':('右から左に高さを確定すると、右側の許される高さが分かります。','左側が右より高ければ1だけ下げます。それでも高ければ不可能です。','疑似コード: for i=N-2 down to0: if H[i]>H[i+1]: H[i]-=1; if H[i]>H[i+1]: print(No); stop; print(Yes)。'),
'abc137_c':('アナグラムは文字を並べ替えると同じ文字列になります。','各文字列の文字をソートし、同じ結果がc個あればc(c−1)/2組を加えます。','疑似コード: counts=frequencies(sort_letters(s) for s in words); print(sum(c*(c-1)/2 for c in counts.values()))。'),
'abc138_c':('小さい値は早く混ぜ、大きい値を最後に残すほど有利です。','値を昇順にソートし、最小値から順に次の値との平均へ更新します。','疑似コード: V=sort(V); value=V[0]; for next in V[1:]: value=(value+next)/2; print(value)。'),
'abc139_c':('隣同士が同じ高さでも右へ移動できます。','高さが増えない連続区間の長さを数え、高さが増えたら連続移動数を0に戻します。','疑似コード: run=best=0; for i=1..N-1: run=run+1 if H[i]<=H[i-1] else0; best=max(best,run); print(best)。'),
'abc140_c':('各Aの要素には、左右のBによる上限があります。','端は対応するB、内部は隣接する二つのBの小さい方まで大きくできます。','疑似コード: answer=B[0]+B[-1]+sum(min(B[i-1],B[i]) for i=1..N-2); print(answer)。')}

TITLES={'abc135_c': 'City Savers', 'abc136_c': 'Build Stairs', 'abc137_c': 'Green Bin', 'abc138_c': 'Alchemist', 'abc139_c': 'Lower', 'abc140_c': 'Maximal Value'}
PUBLISHED_SAMPLES={'abc135_c': [{'input': '2\n3 5 2\n4 5\n', 'expected': '9\n'}, {'input': '3\n5 6 3 8\n5 100 8\n', 'expected': '22\n'}, {'input': '2\n100 1 1\n1 100\n', 'expected': '3\n'}], 'abc136_c': [{'input': '5\n1 2 1 1 3\n', 'expected': 'Yes\n'}, {'input': '4\n1 3 2 1\n', 'expected': 'No\n'}, {'input': '5\n1 2 3 4 5\n', 'expected': 'Yes\n'}, {'input': '1\n1000000000\n', 'expected': 'Yes\n'}], 'abc137_c': [{'input': '3\nacornistnt\npeanutbomb\nconstraint\n', 'expected': '1\n'}, {'input': '2\noneplustwo\nninemodsix\n', 'expected': '0\n'}, {'input': '5\nabaaaaaaaa\noneplustwo\naaaaaaaaba\ntwoplusone\naaaabaaaaa\n', 'expected': '4\n'}], 'abc138_c': [{'input': '2\n3 4\n', 'expected': '3.5\n'}, {'input': '3\n500 300 200\n', 'expected': '375\n'}, {'input': '5\n138 138 138 138 138\n', 'expected': '138\n'}], 'abc139_c': [{'input': '5\n10 4 8 7 3\n', 'expected': '2\n'}, {'input': '7\n4 4 5 6 6 5 5\n', 'expected': '3\n'}, {'input': '4\n1 2 3 4\n', 'expected': '0\n'}], 'abc140_c': [{'input': '3\n2 5\n', 'expected': '9\n'}, {'input': '2\n3\n', 'expected': '6\n'}, {'input': '6\n0 153 10 10 23\n', 'expected': '53\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}

