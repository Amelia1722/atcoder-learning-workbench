"""ABC080–082 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random, re
from collections import Counter

TASKS=('abc080_b','abc081_b','abc082_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER=re.compile(r'[a-z]{1,100}', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc080_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('N')
        n=int(lines[0])
        if not 1<=n<=10**8: raise ValueError('range')
        return n
    if pid=='abc081_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None: raise ValueError('N')
        n=int(lines[0])
        if not 1<=n<=200: raise ValueError('range')
        parts=lines[1].split(' ')
        if len(parts)!=n or any(POS.fullmatch(x) is None for x in parts): raise ValueError('A')
        a=list(map(int,parts))
        if any(not 1<=x<=10**9 for x in a): raise ValueError('range')
        return a
    if len(lines)!=2 or LOWER.fullmatch(lines[0]) is None or LOWER.fullmatch(lines[1]) is None:
        raise ValueError('s/t')
    return lines[0],lines[1]

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc080_b':
        n=value
        s=0; x=n
        while x:
            s += x%10; x//=10
        return output==('Yes' if n%s==0 else 'No')
    if pid=='abc081_b':
        a=value
        # Independent from repeatedly dividing all values: answer is minimum v2(A_i).
        best=100
        for x in a:
            c=0
            while (x & 1)==0:
                c+=1; x>>=1
            best=min(best,c)
        return output==str(best)
    s,t=value
    # Independent from sorted strings: reconstruct extrema from frequency counts.
    cs,ct=Counter(s),Counter(t)
    lo=''.join(chr(c)*cs[chr(c)] for c in range(ord('a'),ord('z')+1))
    hi=''.join(chr(c)*ct[chr(c)] for c in range(ord('z'),ord('a')-1,-1))
    return output==('Yes' if lo<hi else 'No')

def generate(pid:str, seed:int=74)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v74:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc080_b':
        vals=[1,2,9,10,11,12,13,18,19,21,57,99,100,111,1729,9999999,99999999]
        for n in vals: add('boundary' if n in (1,99999999) else 'normal',f'{n}\n')
        add('constraint_max','100000000\n')
    elif pid=='abc081_b':
        vals=[
          [1],[2],[4],[8],[3,6],[8,12,40],[16,24,40],[6,10,14],
          [32,64,96,128],[1024,3072],[999999999],[1000000000],
          [536870912,268435456],[2,4,8,16,32],list(range(1,11)),
          [382253568,723152896,37802240,379425024,404894720,471526144],
          [2**20]*199+[3]
        ]
        for a in vals: add('boundary' if len(a) in (1,199) else 'normal',f'{len(a)}\n'+ ' '.join(map(str,a))+'\n')
        add('constraint_max','200\n'+' '.join(['1000000000']*200)+'\n')
    else:
        vals=[
          ('a','b'),('b','a'),('a','a'),('w','ww'),('ww','w'),('yx','axy'),('ratcode','atlas'),('cd','abc'),
          ('zzz','zzz'),('abc','cba'),('az','za'),('aa','aaa'),('aaa','aa'),('abcd','bcda'),('z','a'),
          ('a'*99,'a'*100),('z'*100,'z'*99)
        ]
        for s,t in vals: add('boundary' if len(s)>=99 or len(t)>=99 else 'normal',f'{s}\n{t}\n')
        add('constraint_max','a'*100+'\n'+'z'*100+'\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
