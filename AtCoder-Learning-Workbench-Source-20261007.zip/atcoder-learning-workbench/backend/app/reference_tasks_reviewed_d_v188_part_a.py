"""Private ABC168..173 D domains and independent oracles."""
from __future__ import annotations
from array import array
from collections import Counter
from functools import lru_cache
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(168,174))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc168_d':'semantic'}
CHECKER_IDS={'abc168_d':'abc168_d'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def graph_distances(n:int,edges:tuple[tuple[int,...],...])->tuple[list[list[int]],list[int]]:
    adj=[[] for _ in range(n)]
    for a,b in edges:adj[a-1].append(b-1);adj[b-1].append(a-1)
    distances=[n+1]*n;distances[0]=0;heap=[(0,0)]
    while heap:
        distance,node=heapq.heappop(heap)
        if distance!=distances[node]:continue
        for neighbor in adj[node]:
            if distances[neighbor]>distance+1:distances[neighbor]=distance+1;heapq.heappush(heap,(distance+1,neighbor))
    return adj,distances

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc168_d':
        n,m=ints(rows[0],2);require(2<=n<=100000 and 1<=m<=200000 and len(rows)==m+1,'N/M/shape');edges=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges),'endpoints');_,distances=graph_distances(n,edges);require(all(d<=n for d in distances),'connected');return n,edges
    if pid=='abc169_d' or pid=='abc172_d':
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=(10**12 if pid=='abc169_d' else 10**7),'N');return (n,)
    if pid=='abc170_d' or pid=='abc173_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require((1 if pid=='abc170_d' else 2)<=n<=200000,'N');a=ints(rows[1],n);require(all(1<=v<=(10**6 if pid=='abc170_d' else 10**9) for v in a),'Ai');return (a,)
    n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)>=3,'N');a=ints(rows[1],n);q=ints(rows[2],1)[0];require(1<=q<=100000 and len(rows)==q+3 and all(1<=v<=100000 for v in a),'Q/A/shape');queries=tuple(ints(row,2) for row in rows[3:]);require(all(1<=b<=100000 and 1<=c<=100000 and b!=c for b,c in queries),'B/C');return a,queries

def shortest_parents_valid(raw:str,actual:str)->bool:
    try:
        n,edges=cast(tuple[int,tuple[tuple[int,...],...]],validate('abc168_d',raw));fields=actual.split()
        if len(fields)!=n or fields[0]!='Yes' or any(re.fullmatch('[1-9][0-9]*',v) is None for v in fields[1:]):return False
        parents=list(map(int,fields[1:]))
        if any(not 1<=parent<=n for parent in parents):return False
        adj,distance=graph_distances(n,edges)
        return all(parent-1 in adj[node] and distance[parent-1]+1==distance[node] for node,parent in enumerate(parents,1))
    except (ValueError,TypeError,IndexError):return False

def div_power_knapsack(n:int)->int:
    exponents=[];p=2
    while p*p<=n:
        exponent=0
        while n%p==0:n//=p;exponent+=1
        if exponent:exponents.append(exponent)
        p+=1
    if n>1:exponents.append(1)
    answer=0
    for exponent in exponents:
        dp=[-100]*(exponent+1);dp[0]=0
        for power in range(1,exponent+1):
            for used in range(exponent,power-1,-1):dp[used]=max(dp[used],dp[used-power]+1)
        answer+=max(dp)
    return answer

@lru_cache(maxsize=1)
def smallest_prime_table()->array:
    n=10**6;spf=array('I',range(n+1))
    for p in range(2,1001):
        if spf[p]==p:
            for multiple in range(p*p,n+1,p):
                if spf[multiple]==multiple:spf[multiple]=p
    return spf

def nondivisible_divisors(a:tuple[int,...])->int:
    frequency=Counter(a);spf=smallest_prime_table();answer=0
    for value,count in frequency.items():
        if count!=1:continue
        current=value;divisors=[1]
        while current>1:
            prime=spf[current];power=1;old=divisors.copy()
            while current%prime==0:
                current//=prime;power*=prime;divisors.extend(d*power for d in old)
        if not any(d!=value and d in frequency for d in divisors):answer+=1
    return answer

def replacing_fenwick(a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
    counts=Counter(a);tree=[0]*100001
    def add(index:int,value:int)->None:
        while index<len(tree):tree[index]+=value;index+=index&-index
    def total()->int:
        index=100000;result=0
        while index:result+=tree[index];index-=index&-index
        return result
    for value,count in counts.items():add(value,value*count)
    answer=[]
    for old,new in queries:
        count=counts.get(old,0);counts[old]=0;counts[new]+=count;add(old,-old*count);add(new,new*count);answer.append(total())
    return answer

def divisor_quotient_blocks(n:int)->int:
    answer=0;left=1
    while left<=n:
        quotient=n//left;right=n//quotient;sum_divisors=(left+right)*(right-left+1)//2;answer+=sum_divisors*quotient*(quotient+1)//2;left=right+1
    return answer

def circle_gap_heap(a:tuple[int,...])->int:
    values=sorted(a,reverse=True);heap=[(-values[0],values[0],values[0])];answer=0
    for value in values[1:]:
        priority,left,right=heapq.heappop(heap);answer-=priority;heapq.heappush(heap,(-min(left,value),left,value));heapq.heappush(heap,(-min(value,right),value,right))
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc168_d':
        n,edges=cast(tuple[int,tuple[tuple[int,...],...]],data);adj,distance=graph_distances(n,edges);parents=[max(v for v in adj[node] if distance[v]+1==distance[node])+1 for node in range(1,n)];return 'Yes\n'+'\n'.join(map(str,parents))
    if pid=='abc169_d':return str(div_power_knapsack(cast(int,data[0])))
    if pid=='abc170_d':return str(nondivisible_divisors(cast(tuple[int,...],data[0])))
    if pid=='abc171_d':return '\n'.join(map(str,replacing_fenwick(*cast(tuple[tuple[int,...],tuple[tuple[int,...],...]],data))))
    if pid=='abc172_d':return str(divisor_quotient_blocks(cast(int,data[0])))
    return str(circle_gap_heap(cast(tuple[int,...],data[0])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc168_d':return shortest_parents_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc168_d':return shortest_parents_valid(raw,expected) and shortest_parents_valid(raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc168_d':"from collections import deque\nn,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):a,b=map(int,input().split());g[a-1].append(b-1);g[b-1].append(a-1)\np=[-1]*n;p[0]=0;q=deque([0])\nwhile q:\n u=q.popleft()\n for v in g[u]:\n  if p[v]<0:p[v]=u+1;q.append(v)\nprint('Yes');print(*p[1:],sep='\\n')\n",
'abc169_d':"n=int(input());answer=0;p=2\nwhile p*p<=n:\n e=0\n while n%p==0:n//=p;e+=1\n take=1\n while e>=take:e-=take;take+=1;answer+=1\n p+=1\nif n>1:answer+=1\nprint(answer)\n",
'abc170_d':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));freq=Counter(a);limit=max(a);blocked=bytearray(limit+1);answer=0\nfor value in sorted(freq):\n if blocked[value]:continue\n if freq[value]==1:answer+=1\n for multiple in range(value*2,limit+1,value):blocked[multiple]=1\nprint(answer)\n",
'abc171_d':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));count=Counter(a);total=sum(a);q=int(input())\nfor _ in range(q):\n b,c=map(int,input().split());moved=count[b];total+=moved*(c-b);count[c]+=moved;count[b]=0;print(total)\n",
'abc172_d':"n=int(input());answer=0\nfor divisor in range(1,n+1):q=n//divisor;answer+=divisor*q*(q+1)//2\nprint(answer)\n",
'abc173_d':"n=int(input());a=sorted(map(int,input().split()),reverse=True);print(sum(a[j//2] for j in range(1,n)))\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18800+TASKS.index(pid))
    if pid=='abc168_d':
        def graph(n:int,a:list[tuple[int,int]])->str:return line((n,len(a)))+''.join(line(p) for p in a)
        raws=[graph(2,[(1,2)]),graph(2,[(2,1),(1,2)]),graph(3,[(2,3),(1,2)]),graph(4,[(1,2),(1,3),(2,4),(3,4)])]
        for n in range(4,16):
            edges=[(rng.randint(1,j-1),j) for j in range(2,n+1)];extras=[(a,b) for a in range(1,n+1) for b in range(a+1,n+1) if (a,b) not in edges];edges+=rng.sample(extras,min(len(extras),n));rng.shuffle(edges);raws.append(graph(n,edges))
        chain=[(j,j+1) for j in range(1,100000)];raws.extend([graph(100000,chain*2+[(1,100000)]*2),graph(100000,[(1,j) for j in range(2,100001)]*2+[(2,3),(3,4)])])
    elif pid=='abc169_d':raws=[f'{n}\n' for n in [1,2,3,4,8,16,24,64,2**15,2**21,2**28,2**36,2**39,997764507000,999999999989,999983**2,10**12-1,10**12]]
    elif pid=='abc170_d':
        arrays=[[1],[10**6],[1,1],[2,3,4]];arrays.extend([rng.randint(1,10**6) for _ in range(n)] for n in range(3,15));arrays.extend([list(range(500001,700001)),[10**6]*200000]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    elif pid=='abc171_d':
        def replacements(a:list[int],queries:list[tuple[int,int]])->str:return f'{len(a)}\n'+line(a)+f'{len(queries)}\n'+''.join(line(q) for q in queries)
        raws=[replacements([1],[(1,2)]),replacements([100000],[(1,100000)]),replacements([1],[(1,100000)]),replacements([1,2],[(1,2),(2,1)])];raws.extend(replacements([rng.randint(1,100000) for _ in range(n)],[(b,(b%100000)+1) for b in [rng.randint(1,100000) for _ in range(n)]]) for n in range(2,14));raws.extend([replacements(list(range(1,100001)),[(j,j+1) for j in range(1,100000)]+[(100000,1)]),replacements([100000]*100000,[(1,100000) if j%2==0 else (100000,1) for j in range(100000)])])
    elif pid=='abc172_d':raws=[f'{n}\n' for n in [1,2,3,4,5,6,10,30,100,999,1000,10000,100000,10**6,2**22,2**23,10**7-1,10**7]]
    else:
        arrays=[[1,1],[1,10**9],[2,2,1,3],[1]*7];arrays.extend([rng.randint(1,10**9) for _ in range(n)] for n in range(3,15));arrays.extend([[j*7919%(10**9)+1 for j in range(200000)],[10**9]*200000]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc168_d':('入口から各部屋への最短距離をBFSで求めます。連結保証があるので配置は存在します。','入口以外の部屋では、最短距離が1小さい隣室を指すようにすれば、必ず最短回数で入口に着きます。','疑似コード: root1をqueueに入れBFS; 未訪問neighborを発見したらparent[neighbor]=current; Yesを出力しroom2..Nのparentを各行出力。'),
'abc169_d':('使える数zは一つの素数のべき乗です。素因数ごとに、指数を何個の異なる正の指数に分けられるか考えます。','操作回数を増やすには小さい指数1,2,3,…から使います。指数eから1+2+…+kを引ける最大kを数えます。','疑似コード: Nを素因数分解; 各指数eにtake=1; e>=takeの間e-=take,answer++,take++; 残り素因数>1も一回数えて出力。'),
'abc170_d':('値の重複があれば、その値のどの要素も他の同じ要素で割り切れます。','値の出現数を数え、小さい値から倍数を無効化します。他の値の倍数でなく、出現一回の値だけ数えます。','疑似コード: frequencyを集計; value昇順で未blockedならfrequency=1のときanswer++; valueの2倍以上をblocked; answerを出力。'),
'abc171_d':('同じ値を持つ要素をまとめて管理すれば、全要素の書き換えは不要です。','Bの個数をCへ移します。総和は、その個数×(C-B)だけ変化します。','疑似コード: countとtotalを初期化; query(B,C)ごとmoved=count[B]; total+=moved*(C-B); count[C]+=moved; count[B]=0; totalを各行出力。'),
'abc172_d':('各整数kの約数を直接調べる代わりに、約数dが寄与する倍数d,2d,…をまとめます。','dの寄与はd*(1+2+…+floor(N/d))です。dを1からNまで足します。','疑似コード: answer=0; d=1..Nでq=N//d; answer+=d*q*(q+1)//2; answerを出力。'),
'abc173_d':('友好度が大きい人から輪に入れます。新しい人を置いたときの得点は、両隣の小さい方です。','最大値は最初の追加で一度使われ、その後は大きい値から順に各二回ずつ使えます。','疑似コード: Aを降順sort; answer=sum(A[j//2],j=1..N-1); answerを出力。')}

TITLES={'abc168_d': '.. (Double Dots)', 'abc169_d': 'Div Game', 'abc170_d': 'Not Divisible', 'abc171_d': 'Replacing', 'abc172_d': 'Sum of Divisors', 'abc173_d': 'Chat in a Circle'}
PUBLISHED_SAMPLES={'abc168_d': [{'input': '4 4\n1 2\n2 3\n3 4\n4 2\n', 'expected': 'Yes\n1\n2\n2\n'}, {'input': '6 9\n3 4\n6 1\n2 4\n5 3\n4 6\n1 5\n6 2\n4 5\n5 6\n', 'expected': 'Yes\n6\n5\n5\n1\n1\n'}], 'abc169_d': [{'input': '24\n', 'expected': '3\n'}, {'input': '1\n', 'expected': '0\n'}, {'input': '64\n', 'expected': '3\n'}, {'input': '1000000007\n', 'expected': '1\n'}, {'input': '997764507000\n', 'expected': '7\n'}], 'abc170_d': [{'input': '5\n24 11 8 3 16\n', 'expected': '3\n'}, {'input': '4\n5 5 5 5\n', 'expected': '0\n'}, {'input': '10\n33 18 45 28 8 19 89 86 2 4\n', 'expected': '5\n'}], 'abc171_d': [{'input': '4\n1 2 3 4\n3\n1 2\n3 4\n2 4\n', 'expected': '11\n12\n16\n'}, {'input': '4\n1 1 1 1\n3\n1 2\n2 1\n3 5\n', 'expected': '8\n4\n4\n'}, {'input': '2\n1 2\n3\n1 100\n2 100\n100 1000\n', 'expected': '102\n200\n2000\n'}], 'abc172_d': [{'input': '4\n', 'expected': '23\n'}, {'input': '100\n', 'expected': '26879\n'}, {'input': '10000000\n', 'expected': '838627288460105\n'}], 'abc173_d': [{'input': '4\n2 2 1 3\n', 'expected': '7\n'}, {'input': '7\n1 1 1 1 1 1 1\n', 'expected': '6\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
