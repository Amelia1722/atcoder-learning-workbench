"""Turn144 aggregate: three independently authored groups, six private lanes."""
from __future__ import annotations
from typing import Protocol,cast
from . import reference_tasks_reviewed_c_v167_part_a as part_a
from . import reference_tasks_reviewed_c_v167_part_b as part_b
from . import reference_tasks_reviewed_c_v167_part_c as part_c

class ReviewedPart(Protocol):
    TASKS: tuple[str,...]
    CONTESTS: dict[str,str]
    TITLES: dict[str,str]
    PUBLISHED_SAMPLES: dict[str,list[dict[str,str]]]
    REFERENCE_CODE: dict[str,str]
    OUTPUT_MODES: dict[str,str]
    HINTS: dict[str,tuple[str,str,str]]
    def generate(self,pid: str) -> list[dict[str,str]]: ...
    def validate(self,pid: str,raw: str) -> object: ...
    def oracle(self,pid: str,raw: str) -> str: ...
    def independent_check(self,pid: str,raw: str,actual: str) -> bool: ...
    def official_expected_matches_reference(self,pid: str,raw: str,expected: str,stdout: str) -> bool: ...

PARTS: tuple[ReviewedPart,...] = tuple(cast(ReviewedPart,p) for p in (part_a,part_b,part_c))
TASKS: tuple[str,...] = tuple(pid for part in PARTS for pid in part.TASKS)
if len(TASKS)!=18 or len(set(TASKS))!=18:
    raise ValueError('v167 requires 18 distinct targets')
OWNERS: dict[str,ReviewedPart] = {pid:part for part in PARTS for pid in part.TASKS}
CONTESTS: dict[str,str] = {pid:part.CONTESTS[pid] for part in PARTS for pid in part.TASKS}
TITLES: dict[str,str] = {pid:part.TITLES[pid] for part in PARTS for pid in part.TASKS}
PUBLISHED_SAMPLES: dict[str,list[dict[str,str]]] = {pid:part.PUBLISHED_SAMPLES[pid] for part in PARTS for pid in part.TASKS}
SAMPLE_COUNTS: dict[str,int] = {pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
REFERENCE_CODE: dict[str,str] = {pid:part.REFERENCE_CODE[pid] for part in PARTS for pid in part.TASKS}
OUTPUT_MODES: dict[str,str] = {pid:mode for part in PARTS for pid,mode in part.OUTPUT_MODES.items()}
CASE_COUNTS: dict[str,int] = {pid:18 for pid in TASKS}
LANES: dict[str,tuple[str,...]] = {chr(65+i):TASKS[3*i:3*i+3] for i in range(6)}

def generate(pid: str) -> list[dict[str,str]]:
    return OWNERS[pid].generate(pid)

def validate(pid: str, raw: str) -> object:
    return OWNERS[pid].validate(pid,raw)

def oracle(pid: str, raw: str) -> str:
    return OWNERS[pid].oracle(pid,raw)

def independent_check(pid: str, raw: str, actual: str) -> bool:
    part=OWNERS.get(pid)
    return part is not None and part.independent_check(pid,raw,actual)

def official_expected_matches_reference(pid: str, raw: str, expected: str, stdout: str) -> bool:
    return OWNERS[pid].official_expected_matches_reference(pid,raw,expected,stdout)
