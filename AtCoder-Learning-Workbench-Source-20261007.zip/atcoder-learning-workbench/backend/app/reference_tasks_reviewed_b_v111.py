"""ABC191–193 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc191_b','abc192_b','abc193_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
LETTERS=re.compile(r'[A-Za-z]+',re.ASCII)

PUBLISHED_SAMPLES={
 'abc191_b':[
  {'input':'5 5\n3 5 6 5 4\n','expected':'3 6 4\n'},
  {'input':'3 3\n3 3 3\n','expected':'\n'},
 ],
 'abc192_b':[
  {'input':'dIfFiCuLt\n','expected':'Yes\n'},
  {'input':'eASY\n','expected':'No\n'},
  {'input':'a\n','expected':'Yes\n'},
 ],
 'abc193_b':[
  {'input':'3\n3 9 5\n4 8 5\n5 7 5\n','expected':'8\n'},
  {'input':'3\n5 9 5\n6 8 5\n7 7 5\n','expected':'-1\n'},
  {'input':'10\n158260522 877914575 602436426\n24979445 861648772 623690081\n433933447 476190629 262703497\n211047202 971407775 628894325\n731963982 822804784 450968417\n430302156 982631932 161735902\n880895728 923078537 707723857\n189330739 910286918 802329211\n404539679 303238506 317063340\n492686568 773361868 125660016\n','expected':'861648772\n'},
 ],
}

def _ints(line:str,count:int)->list[int]:
    p=line.split(' ')
    if len(p)!=count or any(POS.fullmatch(x) is None for x in p): raise ValueError('noncanonical positive integer row')
    return list(map(int,p))

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc191_b':
        if len(lines)!=2: raise ValueError('shape')
        n,x=_ints(lines[0],2)
        if not 1<=n<=100000 or not 1<=x<=10**9: raise ValueError('range')
        a=_ints(lines[1],n)
        if any(not 1<=v<=10**9 for v in a): raise ValueError('A range')
        return x,a
    if pid=='abc192_b':
        if len(lines)!=1 or LETTERS.fullmatch(lines[0]) is None or not 1<=len(lines[0])<=1000: raise ValueError('string shape/range')
        return lines[0]
    if len(lines)<2 or POS.fullmatch(lines[0]) is None: raise ValueError('shape/N')
    n=int(lines[0])
    if not 1<=n<=100000 or len(lines)!=n+1: raise ValueError('range/shape')
    shops=[]
    for line in lines[1:]:
        a,p,x=_ints(line,3)
        if any(v>10**9 for v in (a,p,x)): raise ValueError('shop range')
        shops.append((a,p,x))
    return shops

def _ans191(v)->str:
    x,a=v
    return ' '.join(str(y) for y in a if y!=x)

def _ans192(s:str)->str:
    return 'Yes' if all((c.islower() if i%2==0 else c.isupper()) for i,c in enumerate(s)) else 'No'

def _ans193(shops)->int:
    prices=[p for a,p,x in shops if x>a]
    return min(prices) if prices else -1

def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or '\n' in output: return False
    if pid=='abc191_b': return output==_ans191(v)
    if not output or output!=output.strip(): return False
    if pid=='abc192_b': return output in ('Yes','No') and output==_ans192(v)
    if re.fullmatch(r'-1|[1-9][0-9]*',output,re.ASCII) is None: return False
    return int(output)==_ans193(v)

def _191(x,a): return f'{len(a)} {x}\n'+' '.join(map(str,a))+'\n'
def _193(shops): return f'{len(shops)}\n'+''.join(f'{a} {p} {x}\n' for a,p,x in shops)

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc191_b':
        cases=[
         ('sample1',5,[3,5,6,5,4]),('sample2',3,[3,3,3]),('n1_keep',2,[1]),('n1_remove',1,[1]),
         ('x_min',1,[1,2,1,3,1]),('x_max',10**9,[1,10**9,2,10**9-1]),('none_removed',7,[1,2,3,4,5]),
         ('all_removed_n5',9,[9]*5),('remove_edges',4,[4,1,2,3,4]),('remove_middle',4,[1,4,2,4,3]),
         ('alternating',2,[2,1]*5),('duplicates_other',5,[1,1,5,1,1,5,1]),('n20',10,list(range(1,21))),
         ('n100',50,[50 if i%3==0 else i+1 for i in range(100)]),('n1000_all_keep',10**9,[1]*1000),
         ('n10000_alternating',123,[123 if i%2==0 else 456 for i in range(10000)]),
         ('n50000_most_remove',999,[999]*49999+[1]),
        ]
        for c,x,a in cases:add(c,_191(x,a))
        add('constraint_max',_191(10**9,[10**9 if i%2==0 else 1 for i in range(100000)]))
    elif pid=='abc192_b':
        cases=[
         ('sample1','dIfFiCuLt'),('sample2','eASY'),('sample3','a'),('single_upper','A'),('len2_yes','aB'),('len2_no_first','AB'),
         ('len2_no_second','ab'),('all_lower','abcdef'),('all_upper','ABCDEF'),('yes_short','aBcD'),('wrong_middle','aBCd'),
         ('wrong_last_odd','aBcDE'),('yes_odd','aBcDe'),('yes_10','aBcDeFgHiJ'),('letters_extremes','zYxWvU'),
         ('len100_yes','aB'*50),('len999_yes','aB'*499+'a'),
        ]
        for c,s in cases:add(c,s+'\n')
        add('constraint_max','aB'*500+'\n')
    else:
        cases=[
         ('sample1',[(3,9,5),(4,8,5),(5,7,5)]),('sample2',[(5,9,5),(6,8,5),(7,7,5)]),
         ('sample3',[(158260522,877914575,602436426),(24979445,861648772,623690081),(433933447,476190629,262703497),(211047202,971407775,628894325),(731963982,822804784,450968417),(430302156,982631932,161735902),(880895728,923078537,707723857),(189330739,910286918,802329211),(404539679,303238506,317063340),(492686568,773361868,125660016)]),
         ('n1_available',[(1,1,2)]),('n1_equal_unavailable',[(1,1,1)]),('n1_less_unavailable',[(2,1,1)]),
         ('boundary_available',[(999999999,100,10**9)]),('boundary_equal',[(10**9,100,10**9)]),
         ('cheapest_unavailable',[(5,1,5),(1,100,2)]),('cheapest_available',[(1,1,2),(5,100,5)]),
         ('multiple_available',[(1,300,3),(2,100,4),(3,200,10)]),('price_tie',[(1,50,2),(2,50,3),(3,99,3)]),
         ('large_prices',[(1,10**9,2),(2,10**9-1,3)]),('n20_none',[(i+1,100+i,i+1) for i in range(20)]),
         ('n100_some',[(i+1,1000-i,(i+2 if i%10==0 else i+1)) for i in range(100)]),
         ('n1000_last',[(i+1,500,i+1) for i in range(999)]+[(1000,7,1001)]),
         ('n10000_first',[(1,9,2)]+[(i+2,100,i+2) for i in range(9999)]),
        ]
        for c,shops in cases:add(c,_193(shops))
        add('constraint_max',_193([(10**9,10**9,10**9)]*99999+[(10**9-1,1,10**9)]))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
