"""Evidence-bound hint backfill for ready IDs ABC023 A / ABC024 A / ABC025 A."""
HINTS_BACKFILL_V84={
'abc023_a':(
 '入力は2桁の整数です。十の位と一の位をそれぞれ取り出して足します。',
 '整数演算なら十の位はX//10、一の位はX%10で求められます。',
 '疑似コード:\nX = read_int()\nans = X // 10 + X % 10\nprint(ans)'),
'abc024_a':(
 'まず割引前の合計A*S+B*Tを求めます。割引の有無は人数S+TがK以上かで決まります。',
 '団体割引が適用されるなら、全員それぞれC円引きなのでC*(S+T)を合計から引きます。',
 '疑似コード:\ntotal = A*S + B*T\nif S + T >= K:\n  total -= C * (S + T)\nprint(total)'),
'abc025_a':(
 '候補はSの5文字から1文字目・2文字目を選ぶ25通りです。辞書順では1文字目ごとに5個ずつ並びます。',
 'Nを0始まりのk=N-1へ直すと、1文字目はk//5番目、2文字目はk%5番目の文字です。',
 '疑似コード:\nk = N - 1\nfirst = S[k // 5]\nsecond = S[k % 5]\nprint(first + second)')
}
