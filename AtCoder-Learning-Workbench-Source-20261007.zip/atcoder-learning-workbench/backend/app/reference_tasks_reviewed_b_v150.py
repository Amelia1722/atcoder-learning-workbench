"""Turn 127 reviewed B batch: ABC393 B through ABC410 B."""
from __future__ import annotations
from collections import Counter, deque
from itertools import combinations
import math, re

TASKS=('abc393_b', 'abc394_b', 'abc395_b', 'abc396_b', 'abc397_b', 'abc398_b', 'abc399_b', 'abc400_b', 'abc401_b', 'abc402_b', 'abc403_b', 'abc404_b', 'abc405_b', 'abc406_b', 'abc407_b', 'abc408_b', 'abc409_b', 'abc410_b')
LANES={'A': ('abc393_b', 'abc394_b', 'abc395_b'), 'B': ('abc396_b', 'abc397_b', 'abc398_b'), 'C': ('abc399_b', 'abc400_b', 'abc401_b'), 'D': ('abc402_b', 'abc403_b', 'abc404_b'), 'E': ('abc405_b', 'abc406_b', 'abc407_b'), 'F': ('abc408_b', 'abc409_b', 'abc410_b')}
TITLES={'abc393_b': 'A..B..C',
 'abc394_b': 'cat',
 'abc395_b': 'Make Target',
 'abc396_b': 'Card Pile',
 'abc397_b': 'Ticket Gate Log',
 'abc398_b': 'Full House 3',
 'abc399_b': 'Ranking with Ties',
 'abc400_b': 'Sum of Geometric Series',
 'abc401_b': 'Unauthorized',
 'abc402_b': 'Restaurant Queue',
 'abc403_b': 'Four Hidden',
 'abc404_b': 'Grid Rotation',
 'abc405_b': 'Not All',
 'abc406_b': 'Product Calculator',
 'abc407_b': 'P(X or Y)',
 'abc408_b': 'Compression',
 'abc409_b': 'Citation',
 'abc410_b': 'Reverse Proxy'}
PUBLISHED_SAMPLES={'abc393_b': [{'input': 'AABCC\n', 'expected': '2\n'},
              {'input': 'ARC\n', 'expected': '0\n'},
              {'input': 'AABAAABBAEDCCCD\n', 'expected': '4\n'}],
 'abc394_b': [{'input': '3\ntc\noder\na\n', 'expected': 'atcoder\n'},
              {'input': '4\ncat\nenate\non\nc\n', 'expected': 'concatenate\n'}],
 'abc395_b': [{'input': '11\n',
               'expected': '###########\n'
                           '#.........#\n'
                           '#.#######.#\n'
                           '#.#.....#.#\n'
                           '#.#.###.#.#\n'
                           '#.#.#.#.#.#\n'
                           '#.#.###.#.#\n'
                           '#.#.....#.#\n'
                           '#.#######.#\n'
                           '#.........#\n'
                           '###########\n'},
              {'input': '5\n', 'expected': '#####\n#...#\n#.#.#\n#...#\n#####\n'},
              {'input': '8\n',
               'expected': '########\n#......#\n#.####.#\n#.#..#.#\n#.#..#.#\n#.####.#\n#......#\n########\n'},
              {'input': '2\n', 'expected': '##\n##\n'}],
 'abc396_b': [{'input': '6\n2\n1 4\n1 3\n2\n2\n2\n', 'expected': '0\n3\n4\n0\n'},
              {'input': '5\n2\n2\n2\n2\n2\n', 'expected': '0\n0\n0\n0\n0\n'}],
 'abc397_b': [{'input': 'ioi\n', 'expected': '1\n'},
              {'input': 'iioo\n', 'expected': '2\n'},
              {'input': 'io\n', 'expected': '0\n'}],
 'abc398_b': [{'input': '1 4 1 4 2 1 3\n', 'expected': 'Yes\n'},
              {'input': '11 12 13 10 13 12 11\n', 'expected': 'No\n'},
              {'input': '7 7 7 7 7 7 7\n', 'expected': 'No\n'},
              {'input': '13 13 1 1 7 4 13\n', 'expected': 'Yes\n'}],
 'abc399_b': [{'input': '4\n3 12 9 9\n', 'expected': '4\n1\n2\n2\n'},
              {'input': '3\n3 9 6\n', 'expected': '3\n1\n2\n'},
              {'input': '4\n100 100 100 100\n', 'expected': '1\n1\n1\n1\n'},
              {'input': '8\n87 87 87 88 41 38 41 38\n', 'expected': '2\n2\n2\n1\n5\n7\n5\n7\n'}],
 'abc400_b': [{'input': '7 3\n', 'expected': '400\n'},
              {'input': '1000000 2\n', 'expected': 'inf\n'},
              {'input': '999999999 1\n', 'expected': '1000000000\n'},
              {'input': '998244353 99\n', 'expected': 'inf\n'}],
 'abc401_b': [{'input': '6\nlogin\nprivate\npublic\nlogout\nprivate\npublic\n', 'expected': '1\n'},
              {'input': '4\nprivate\nprivate\nprivate\nlogout\n', 'expected': '3\n'},
              {'input': '20\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'public\n'
                        'logout\n'
                        'logout\n'
                        'logout\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'login\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'login\n'
                        'public\n'
                        'private\n'
                        'logout\n'
                        'private\n',
               'expected': '3\n'}],
 'abc402_b': [{'input': '6\n1 3\n1 1\n1 15\n2\n1 3\n2\n', 'expected': '3\n1\n'},
              {'input': '7\n1 3\n1 1\n1 4\n1 1\n1 5\n1 9\n1 2\n', 'expected': '\n'}],
 'abc403_b': [{'input': 'tak??a?h?\nnashi\n', 'expected': 'Yes\n'},
              {'input': '??e??e\nsnuke\n', 'expected': 'No\n'},
              {'input': '????\naoki\n', 'expected': 'Yes\n'}],
 'abc404_b': [{'input': '4\n###.\n..#.\n..#.\n..#.\n...#\n...#\n###.\n....\n', 'expected': '2\n'},
              {'input': '13\n'
                        '.#..###..##..\n'
                        '#.#.#..#.#.#.\n'
                        '#.#.###..#...\n'
                        '###.#..#.#.#.\n'
                        '#.#.###..##..\n'
                        '.............\n'
                        '..#...#....#.\n'
                        '.##..#.#..##.\n'
                        '#.#..#.#.#.#.\n'
                        '####.#.#.####\n'
                        '..#..#.#...#.\n'
                        '..#...#....#.\n'
                        '.............\n'
                        '.............\n'
                        '.#....#...#..\n'
                        '.#...#.#..#..\n'
                        '####.#.#.####\n'
                        '.#.#.###..#.#\n'
                        '.##....#..##.\n'
                        '.#....#...#..\n'
                        '.............\n'
                        '..##..###.#.#\n'
                        '.#.#.#..#.###\n'
                        '.#.#..###.#.#\n'
                        '.#.#.#..#.#.#\n'
                        '..##..###..#.\n',
               'expected': '5\n'}],
 'abc405_b': [{'input': '5 3\n3 2 3 1 2\n', 'expected': '2\n'},
              {'input': '4 3\n1 3 1 3\n', 'expected': '0\n'},
              {'input': '10 4\n1 3 3 4 2 1 3 1 2 4\n', 'expected': '6\n'}],
 'abc406_b': [{'input': '5 2\n7 13 3 2 5\n', 'expected': '10\n'}, {'input': '2 1\n2 5\n', 'expected': '1\n'}],
 'abc407_b': [{'input': '9 3\n', 'expected': '0.555555555555555555555555555555\n'},
              {'input': '13 6\n', 'expected': '0\n'},
              {'input': '10 3\n', 'expected': '0.5\n'}],
 'abc408_b': [{'input': '4\n3 1 4 1\n', 'expected': '3\n1 3 4\n'},
              {'input': '3\n7 7 7\n', 'expected': '1\n7\n'},
              {'input': '8\n19 5 5 19 5 19 4 19\n', 'expected': '3\n4 5 19\n'}],
 'abc409_b': [{'input': '3\n1 2 1\n', 'expected': '1\n'}, {'input': '7\n1 6 2 10 2 3 2\n', 'expected': '3\n'}],
 'abc410_b': [{'input': '4 5\n2 0 3 0 0\n', 'expected': '2 1 3 4 1\n'},
              {'input': '3 7\n1 1 0 0 0 0 0\n', 'expected': '1 1 2 3 2 3 1\n'},
              {'input': '6 20\n4 6 0 3 4 2 6 5 2 3 0 3 2 5 0 3 5 0 2 0\n',
               'expected': '4 6 1 3 4 2 6 5 2 3 1 3 2 5 1 3 5 4 2 6\n'}]}
SAMPLE_COUNTS={k:len(v) for k,v in PUBLISHED_SAMPLES.items()}
GENERATED_CASES={'abc393_b': [{'input': 'ABC\n', 'category': 'task_specific_01'},
              {'input': 'ARC\n', 'category': 'task_specific_02'},
              {'input': 'AABCC\n', 'category': 'task_specific_03'},
              {'input': 'ABBC\n', 'category': 'task_specific_04'},
              {'input': 'ABCABC\n', 'category': 'task_specific_05'},
              {'input': 'AAAAABCCCC\n', 'category': 'task_specific_06'},
              {'input': 'BAC\n', 'category': 'task_specific_07'},
              {'input': 'CBA\n', 'category': 'task_specific_08'},
              {'input': 'AXBYC\n', 'category': 'task_specific_09'},
              {'input': 'AABBCC\n', 'category': 'task_specific_10'},
              {'input': 'ABXBC\n', 'category': 'task_specific_11'},
              {'input': 'ABCZZZABC\n', 'category': 'task_specific_12'},
              {'input': 'ZABCZ\n', 'category': 'task_specific_13'},
              {'input': 'AABAAABBAEDCCCD\n', 'category': 'task_specific_14'},
              {'input': 'BBBBABC\n', 'category': 'task_specific_15'},
              {'input': 'ACBABC\n', 'category': 'task_specific_16'},
              {'input': 'ABCCCC\n', 'category': 'task_specific_17'},
              {'input': 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC\n',
               'category': 'constraint_max'}],
 'abc394_b': [{'input': '2\nc\ndd\n', 'category': 'task_specific_01'},
              {'input': '3\nfff\nee\nd\n', 'category': 'task_specific_02'},
              {'input': '4\ne\nggg\nff\nhhhh\n', 'category': 'task_specific_03'},
              {'input': '5\njjjjj\niiii\nhhh\ngg\nf\n', 'category': 'task_specific_04'},
              {'input': '6\ng\niii\nkkkkk\nhh\njjjj\nllllll\n', 'category': 'task_specific_05'},
              {'input': '7\nnnnnnnn\nmmmmmm\nlllll\nkkkk\njjj\nii\nh\n', 'category': 'task_specific_06'},
              {'input': '8\ni\nkkk\nmmmmm\nooooooo\njj\nllll\nnnnnnn\npppppppp\n', 'category': 'task_specific_07'},
              {'input': '9\nrrrrrrrrr\nqqqqqqqq\nppppppp\noooooo\nnnnnn\nmmmm\nlll\nkk\nj\n',
               'category': 'task_specific_08'},
              {'input': '10\nk\nmmm\nooooo\nqqqqqqq\nsssssssss\nll\nnnnn\npppppp\nrrrrrrrr\ntttttttttt\n',
               'category': 'task_specific_09'},
              {'input': '11\nvvvvvvvvvvv\nuuuuuuuuuu\nttttttttt\nssssssss\nrrrrrrr\nqqqqqq\nppppp\noooo\nnnn\nmm\nl\n',
               'category': 'task_specific_10'},
              {'input': '12\n'
                        'm\n'
                        'ooo\n'
                        'qqqqq\n'
                        'sssssss\n'
                        'uuuuuuuuu\n'
                        'wwwwwwwwwww\n'
                        'nn\n'
                        'pppp\n'
                        'rrrrrr\n'
                        'tttttttt\n'
                        'vvvvvvvvvv\n'
                        'xxxxxxxxxxxx\n',
               'category': 'task_specific_11'},
              {'input': '13\n'
                        'zzzzzzzzzzzzz\n'
                        'yyyyyyyyyyyy\n'
                        'xxxxxxxxxxx\n'
                        'wwwwwwwwww\n'
                        'vvvvvvvvv\n'
                        'uuuuuuuu\n'
                        'ttttttt\n'
                        'ssssss\n'
                        'rrrrr\n'
                        'qqqq\n'
                        'ppp\n'
                        'oo\n'
                        'n\n',
               'category': 'task_specific_12'},
              {'input': '14\n'
                        'o\n'
                        'qqq\n'
                        'sssss\n'
                        'uuuuuuu\n'
                        'wwwwwwwww\n'
                        'yyyyyyyyyyy\n'
                        'aaaaaaaaaaaaa\n'
                        'pp\n'
                        'rrrr\n'
                        'tttttt\n'
                        'vvvvvvvv\n'
                        'xxxxxxxxxx\n'
                        'zzzzzzzzzzzz\n'
                        'bbbbbbbbbbbbbb\n',
               'category': 'task_specific_13'},
              {'input': '15\n'
                        'ddddddddddddddd\n'
                        'cccccccccccccc\n'
                        'bbbbbbbbbbbbb\n'
                        'aaaaaaaaaaaa\n'
                        'zzzzzzzzzzz\n'
                        'yyyyyyyyyy\n'
                        'xxxxxxxxx\n'
                        'wwwwwwww\n'
                        'vvvvvvv\n'
                        'uuuuuu\n'
                        'ttttt\n'
                        'ssss\n'
                        'rrr\n'
                        'qq\n'
                        'p\n',
               'category': 'task_specific_14'},
              {'input': '16\n'
                        'q\n'
                        'sss\n'
                        'uuuuu\n'
                        'wwwwwww\n'
                        'yyyyyyyyy\n'
                        'aaaaaaaaaaa\n'
                        'ccccccccccccc\n'
                        'eeeeeeeeeeeeeee\n'
                        'rr\n'
                        'tttt\n'
                        'vvvvvv\n'
                        'xxxxxxxx\n'
                        'zzzzzzzzzz\n'
                        'bbbbbbbbbbbb\n'
                        'dddddddddddddd\n'
                        'ffffffffffffffff\n',
               'category': 'task_specific_15'},
              {'input': '17\n'
                        'hhhhhhhhhhhhhhhhh\n'
                        'gggggggggggggggg\n'
                        'fffffffffffffff\n'
                        'eeeeeeeeeeeeee\n'
                        'ddddddddddddd\n'
                        'cccccccccccc\n'
                        'bbbbbbbbbbb\n'
                        'aaaaaaaaaa\n'
                        'zzzzzzzzz\n'
                        'yyyyyyyy\n'
                        'xxxxxxx\n'
                        'wwwwww\n'
                        'vvvvv\n'
                        'uuuu\n'
                        'ttt\n'
                        'ss\n'
                        'r\n',
               'category': 'task_specific_16'},
              {'input': '18\n'
                        's\n'
                        'uuu\n'
                        'wwwww\n'
                        'yyyyyyy\n'
                        'aaaaaaaaa\n'
                        'ccccccccccc\n'
                        'eeeeeeeeeeeee\n'
                        'ggggggggggggggg\n'
                        'iiiiiiiiiiiiiiiii\n'
                        'tt\n'
                        'vvvv\n'
                        'xxxxxx\n'
                        'zzzzzzzz\n'
                        'bbbbbbbbbb\n'
                        'dddddddddddd\n'
                        'ffffffffffffff\n'
                        'hhhhhhhhhhhhhhhh\n'
                        'jjjjjjjjjjjjjjjjjj\n',
               'category': 'task_specific_17'},
              {'input': '50\n'
                        'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n'
                        'wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww\n'
                        'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv\n'
                        'uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu\n'
                        'tttttttttttttttttttttttttttttttttttttttttttttt\n'
                        'sssssssssssssssssssssssssssssssssssssssssssss\n'
                        'rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n'
                        'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n'
                        'pppppppppppppppppppppppppppppppppppppppppp\n'
                        'ooooooooooooooooooooooooooooooooooooooooo\n'
                        'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n'
                        'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n'
                        'llllllllllllllllllllllllllllllllllllll\n'
                        'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n'
                        'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n'
                        'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n'
                        'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n'
                        'ggggggggggggggggggggggggggggggggg\n'
                        'ffffffffffffffffffffffffffffffff\n'
                        'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n'
                        'dddddddddddddddddddddddddddddd\n'
                        'ccccccccccccccccccccccccccccc\n'
                        'bbbbbbbbbbbbbbbbbbbbbbbbbbbb\n'
                        'aaaaaaaaaaaaaaaaaaaaaaaaaaa\n'
                        'zzzzzzzzzzzzzzzzzzzzzzzzzz\n'
                        'yyyyyyyyyyyyyyyyyyyyyyyyy\n'
                        'xxxxxxxxxxxxxxxxxxxxxxxx\n'
                        'wwwwwwwwwwwwwwwwwwwwwww\n'
                        'vvvvvvvvvvvvvvvvvvvvvv\n'
                        'uuuuuuuuuuuuuuuuuuuuu\n'
                        'tttttttttttttttttttt\n'
                        'sssssssssssssssssss\n'
                        'rrrrrrrrrrrrrrrrrr\n'
                        'qqqqqqqqqqqqqqqqq\n'
                        'pppppppppppppppp\n'
                        'ooooooooooooooo\n'
                        'nnnnnnnnnnnnnn\n'
                        'mmmmmmmmmmmmm\n'
                        'llllllllllll\n'
                        'kkkkkkkkkkk\n'
                        'jjjjjjjjjj\n'
                        'iiiiiiiii\n'
                        'hhhhhhhh\n'
                        'ggggggg\n'
                        'ffffff\n'
                        'eeeee\n'
                        'dddd\n'
                        'ccc\n'
                        'bb\n'
                        'a\n',
               'category': 'constraint_max'}],
 'abc395_b': [{'input': '1\n', 'category': 'task_specific_01'},
              {'input': '2\n', 'category': 'task_specific_02'},
              {'input': '3\n', 'category': 'task_specific_03'},
              {'input': '4\n', 'category': 'task_specific_04'},
              {'input': '5\n', 'category': 'task_specific_05'},
              {'input': '6\n', 'category': 'task_specific_06'},
              {'input': '7\n', 'category': 'task_specific_07'},
              {'input': '8\n', 'category': 'task_specific_08'},
              {'input': '9\n', 'category': 'task_specific_09'},
              {'input': '10\n', 'category': 'task_specific_10'},
              {'input': '11\n', 'category': 'task_specific_11'},
              {'input': '12\n', 'category': 'task_specific_12'},
              {'input': '13\n', 'category': 'task_specific_13'},
              {'input': '14\n', 'category': 'task_specific_14'},
              {'input': '15\n', 'category': 'task_specific_15'},
              {'input': '16\n', 'category': 'task_specific_16'},
              {'input': '17\n', 'category': 'task_specific_17'},
              {'input': '50\n', 'category': 'constraint_max'}],
 'abc396_b': [{'input': '2\n1 1\n2\n', 'category': 'task_specific_01'},
              {'input': '2\n1 2\n2\n', 'category': 'task_specific_02'},
              {'input': '2\n1 3\n2\n', 'category': 'task_specific_03'},
              {'input': '2\n1 4\n2\n', 'category': 'task_specific_04'},
              {'input': '2\n1 5\n2\n', 'category': 'task_specific_05'},
              {'input': '2\n1 6\n2\n', 'category': 'task_specific_06'},
              {'input': '2\n1 7\n2\n', 'category': 'task_specific_07'},
              {'input': '2\n1 8\n2\n', 'category': 'task_specific_08'},
              {'input': '2\n1 9\n2\n', 'category': 'task_specific_09'},
              {'input': '2\n1 10\n2\n', 'category': 'task_specific_10'},
              {'input': '2\n1 11\n2\n', 'category': 'task_specific_11'},
              {'input': '2\n1 12\n2\n', 'category': 'task_specific_12'},
              {'input': '2\n1 13\n2\n', 'category': 'task_specific_13'},
              {'input': '2\n1 14\n2\n', 'category': 'task_specific_14'},
              {'input': '2\n1 15\n2\n', 'category': 'task_specific_15'},
              {'input': '2\n1 16\n2\n', 'category': 'task_specific_16'},
              {'input': '2\n1 17\n2\n', 'category': 'task_specific_17'},
              {'input': '100\n'
                        '1 1\n'
                        '1 2\n'
                        '1 3\n'
                        '1 4\n'
                        '1 5\n'
                        '1 6\n'
                        '1 7\n'
                        '1 8\n'
                        '1 9\n'
                        '1 10\n'
                        '1 11\n'
                        '1 12\n'
                        '1 13\n'
                        '1 14\n'
                        '1 15\n'
                        '1 16\n'
                        '1 17\n'
                        '1 18\n'
                        '1 19\n'
                        '1 20\n'
                        '1 21\n'
                        '1 22\n'
                        '1 23\n'
                        '1 24\n'
                        '1 25\n'
                        '1 26\n'
                        '1 27\n'
                        '1 28\n'
                        '1 29\n'
                        '1 30\n'
                        '1 31\n'
                        '1 32\n'
                        '1 33\n'
                        '1 34\n'
                        '1 35\n'
                        '1 36\n'
                        '1 37\n'
                        '1 38\n'
                        '1 39\n'
                        '1 40\n'
                        '1 41\n'
                        '1 42\n'
                        '1 43\n'
                        '1 44\n'
                        '1 45\n'
                        '1 46\n'
                        '1 47\n'
                        '1 48\n'
                        '1 49\n'
                        '1 50\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n',
               'category': 'constraint_max'}],
 'abc397_b': [{'input': 'i\n', 'category': 'task_specific_01'},
              {'input': 'o\n', 'category': 'task_specific_02'},
              {'input': 'io\n', 'category': 'task_specific_03'},
              {'input': 'oi\n', 'category': 'task_specific_04'},
              {'input': 'ii\n', 'category': 'task_specific_05'},
              {'input': 'oo\n', 'category': 'task_specific_06'},
              {'input': 'ioi\n', 'category': 'task_specific_07'},
              {'input': 'oio\n', 'category': 'task_specific_08'},
              {'input': 'iioo\n', 'category': 'task_specific_09'},
              {'input': 'ioio\n', 'category': 'task_specific_10'},
              {'input': 'oooo\n', 'category': 'task_specific_11'},
              {'input': 'iiii\n', 'category': 'task_specific_12'},
              {'input': 'ioioi\n', 'category': 'task_specific_13'},
              {'input': 'oioio\n', 'category': 'task_specific_14'},
              {'input': 'iioioo\n', 'category': 'task_specific_15'},
              {'input': 'ooioii\n', 'category': 'task_specific_16'},
              {'input': 'ioioioio\n', 'category': 'task_specific_17'},
              {'input': 'ioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioioio\n',
               'category': 'constraint_max'}],
 'abc398_b': [{'input': '1 1 1 2 2 3 4\n', 'category': 'task_specific_01'},
              {'input': '1 1 2 2 3 3 4\n', 'category': 'task_specific_02'},
              {'input': '7 7 7 7 7 7 7\n', 'category': 'task_specific_03'},
              {'input': '1 2 3 4 5 6 7\n', 'category': 'task_specific_04'},
              {'input': '13 13 13 1 1 2 3\n', 'category': 'task_specific_05'},
              {'input': '1 1 1 1 2 2 2\n', 'category': 'task_specific_06'},
              {'input': '2 2 2 3 3 3 3\n', 'category': 'task_specific_07'},
              {'input': '1 4 1 4 2 1 3\n', 'category': 'task_specific_08'},
              {'input': '11 12 13 10 13 12 11\n', 'category': 'task_specific_09'},
              {'input': '13 13 1 1 7 4 13\n', 'category': 'task_specific_10'},
              {'input': '5 5 5 6 6 6 7\n', 'category': 'task_specific_11'},
              {'input': '8 8 9 9 10 10 11\n', 'category': 'task_specific_12'},
              {'input': '1 1 1 2 3 4 5\n', 'category': 'task_specific_13'},
              {'input': '1 1 2 2 2 3 4\n', 'category': 'task_specific_14'},
              {'input': '12 12 12 13 13 13 1\n', 'category': 'task_specific_15'},
              {'input': '3 3 3 4 4 5 5\n', 'category': 'task_specific_16'},
              {'input': '6 6 6 6 7 7 8\n', 'category': 'task_specific_17'},
              {'input': '13 13 13 12 12 11 10\n', 'category': 'constraint_max'}],
 'abc399_b': [{'input': '1\n2\n', 'category': 'task_specific_01'},
              {'input': '2\n3 4\n', 'category': 'task_specific_02'},
              {'input': '3\n4 5 8\n', 'category': 'task_specific_03'},
              {'input': '4\n5 6 9 14\n', 'category': 'task_specific_04'},
              {'input': '5\n6 7 10 15 22\n', 'category': 'task_specific_05'},
              {'input': '6\n7 8 11 16 23 32\n', 'category': 'task_specific_06'},
              {'input': '7\n8 9 12 17 24 33 44\n', 'category': 'task_specific_07'},
              {'input': '8\n9 10 13 18 25 34 45 58\n', 'category': 'task_specific_08'},
              {'input': '9\n10 11 14 19 26 35 46 59 74\n', 'category': 'task_specific_09'},
              {'input': '10\n11 12 15 20 27 36 47 60 75 92\n', 'category': 'task_specific_10'},
              {'input': '11\n12 13 16 21 28 37 48 61 76 93 12\n', 'category': 'task_specific_11'},
              {'input': '12\n13 14 17 22 29 38 49 62 77 94 13 34\n', 'category': 'task_specific_12'},
              {'input': '13\n14 15 18 23 30 39 50 63 78 95 14 35 58\n', 'category': 'task_specific_13'},
              {'input': '14\n15 16 19 24 31 40 51 64 79 96 15 36 59 84\n', 'category': 'task_specific_14'},
              {'input': '15\n16 17 20 25 32 41 52 65 80 97 16 37 60 85 12\n', 'category': 'task_specific_15'},
              {'input': '16\n17 18 21 26 33 42 53 66 81 98 17 38 61 86 13 42\n', 'category': 'task_specific_16'},
              {'input': '17\n18 19 22 27 34 43 54 67 82 99 18 39 62 87 14 43 74\n', 'category': 'task_specific_17'},
              {'input': '100\n'
                        '100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 '
                        '100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 100 '
                        '100 100 100 100 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 '
                        '1 1 1 1 1 1 1 1 1 1 1\n',
               'category': 'constraint_max'}],
 'abc400_b': [{'input': '1 1\n', 'category': 'task_specific_01'},
              {'input': '1 100\n', 'category': 'task_specific_02'},
              {'input': '2 1\n', 'category': 'task_specific_03'},
              {'input': '2 2\n', 'category': 'task_specific_04'},
              {'input': '2 29\n', 'category': 'task_specific_05'},
              {'input': '2 30\n', 'category': 'task_specific_06'},
              {'input': '3 5\n', 'category': 'task_specific_07'},
              {'input': '7 3\n', 'category': 'task_specific_08'},
              {'input': '10 8\n', 'category': 'task_specific_09'},
              {'input': '10 9\n', 'category': 'task_specific_10'},
              {'input': '1000 2\n', 'category': 'task_specific_11'},
              {'input': '1000000 2\n', 'category': 'task_specific_12'},
              {'input': '999999999 1\n', 'category': 'task_specific_13'},
              {'input': '1000000000 1\n', 'category': 'task_specific_14'},
              {'input': '5 13\n', 'category': 'task_specific_15'},
              {'input': '998244353 99\n', 'category': 'task_specific_16'},
              {'input': '12345 4\n', 'category': 'task_specific_17'},
              {'input': '1000000000 100\n', 'category': 'constraint_max'}],
 'abc401_b': [{'input': '1\nprivate\n', 'category': 'task_specific_01'},
              {'input': '1\npublic\n', 'category': 'task_specific_02'},
              {'input': '2\nlogin\nprivate\n', 'category': 'task_specific_03'},
              {'input': '2\nlogout\nprivate\n', 'category': 'task_specific_04'},
              {'input': '2\nprivate\nprivate\n', 'category': 'task_specific_05'},
              {'input': '3\nlogin\nlogout\nprivate\n', 'category': 'task_specific_06'},
              {'input': '4\nlogin\nprivate\nlogout\nprivate\n', 'category': 'task_specific_07'},
              {'input': '3\nlogout\nlogout\nprivate\n', 'category': 'task_specific_08'},
              {'input': '3\nlogin\nlogin\nprivate\n', 'category': 'task_specific_09'},
              {'input': '3\npublic\nprivate\npublic\n', 'category': 'task_specific_10'},
              {'input': '5\nprivate\nlogin\nprivate\nlogout\nprivate\n', 'category': 'task_specific_11'},
              {'input': '2\nlogin\nlogout\n', 'category': 'task_specific_12'},
              {'input': '2\nprivate\nlogout\n', 'category': 'task_specific_13'},
              {'input': '3\nlogin\npublic\nprivate\n', 'category': 'task_specific_14'},
              {'input': '3\nlogout\npublic\nprivate\n', 'category': 'task_specific_15'},
              {'input': '4\nprivate\nlogin\nlogout\nprivate\n', 'category': 'task_specific_16'},
              {'input': '5\nlogin\nprivate\nprivate\nlogout\nprivate\n', 'category': 'task_specific_17'},
              {'input': '100\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n'
                        'private\n'
                        'login\n'
                        'private\n'
                        'logout\n',
               'category': 'constraint_max'}],
 'abc402_b': [{'input': '1\n1 1\n', 'category': 'task_specific_01'},
              {'input': '3\n1 2\n1 3\n2\n', 'category': 'task_specific_02'},
              {'input': '5\n1 3\n1 4\n1 5\n2\n2\n', 'category': 'task_specific_03'},
              {'input': '7\n1 4\n1 5\n1 6\n1 7\n2\n2\n2\n', 'category': 'task_specific_04'},
              {'input': '5\n1 5\n1 6\n1 7\n1 8\n1 9\n', 'category': 'task_specific_05'},
              {'input': '7\n1 6\n1 7\n1 8\n1 9\n1 10\n1 11\n2\n', 'category': 'task_specific_06'},
              {'input': '9\n1 7\n1 8\n1 9\n1 10\n1 11\n1 12\n1 13\n2\n2\n', 'category': 'task_specific_07'},
              {'input': '11\n1 8\n1 9\n1 10\n1 11\n1 12\n1 13\n1 14\n1 15\n2\n2\n2\n', 'category': 'task_specific_08'},
              {'input': '9\n1 9\n1 10\n1 11\n1 12\n1 13\n1 14\n1 15\n1 16\n1 17\n', 'category': 'task_specific_09'},
              {'input': '11\n1 10\n1 11\n1 12\n1 13\n1 14\n1 15\n1 16\n1 17\n1 18\n1 19\n2\n',
               'category': 'task_specific_10'},
              {'input': '13\n1 11\n1 12\n1 13\n1 14\n1 15\n1 16\n1 17\n1 18\n1 19\n1 20\n1 21\n2\n2\n',
               'category': 'task_specific_11'},
              {'input': '15\n1 12\n1 13\n1 14\n1 15\n1 16\n1 17\n1 18\n1 19\n1 20\n1 21\n1 22\n1 23\n2\n2\n2\n',
               'category': 'task_specific_12'},
              {'input': '13\n1 13\n1 14\n1 15\n1 16\n1 17\n1 18\n1 19\n1 20\n1 21\n1 22\n1 23\n1 24\n1 25\n',
               'category': 'task_specific_13'},
              {'input': '15\n1 14\n1 15\n1 16\n1 17\n1 18\n1 19\n1 20\n1 21\n1 22\n1 23\n1 24\n1 25\n1 26\n1 27\n2\n',
               'category': 'task_specific_14'},
              {'input': '17\n'
                        '1 15\n'
                        '1 16\n'
                        '1 17\n'
                        '1 18\n'
                        '1 19\n'
                        '1 20\n'
                        '1 21\n'
                        '1 22\n'
                        '1 23\n'
                        '1 24\n'
                        '1 25\n'
                        '1 26\n'
                        '1 27\n'
                        '1 28\n'
                        '1 29\n'
                        '2\n'
                        '2\n',
               'category': 'task_specific_15'},
              {'input': '19\n'
                        '1 16\n'
                        '1 17\n'
                        '1 18\n'
                        '1 19\n'
                        '1 20\n'
                        '1 21\n'
                        '1 22\n'
                        '1 23\n'
                        '1 24\n'
                        '1 25\n'
                        '1 26\n'
                        '1 27\n'
                        '1 28\n'
                        '1 29\n'
                        '1 30\n'
                        '1 31\n'
                        '2\n'
                        '2\n'
                        '2\n',
               'category': 'task_specific_16'},
              {'input': '17\n'
                        '1 17\n'
                        '1 18\n'
                        '1 19\n'
                        '1 20\n'
                        '1 21\n'
                        '1 22\n'
                        '1 23\n'
                        '1 24\n'
                        '1 25\n'
                        '1 26\n'
                        '1 27\n'
                        '1 28\n'
                        '1 29\n'
                        '1 30\n'
                        '1 31\n'
                        '1 32\n'
                        '1 33\n',
               'category': 'task_specific_17'},
              {'input': '100\n'
                        '1 1\n'
                        '1 2\n'
                        '1 3\n'
                        '1 4\n'
                        '1 5\n'
                        '1 6\n'
                        '1 7\n'
                        '1 8\n'
                        '1 9\n'
                        '1 10\n'
                        '1 11\n'
                        '1 12\n'
                        '1 13\n'
                        '1 14\n'
                        '1 15\n'
                        '1 16\n'
                        '1 17\n'
                        '1 18\n'
                        '1 19\n'
                        '1 20\n'
                        '1 21\n'
                        '1 22\n'
                        '1 23\n'
                        '1 24\n'
                        '1 25\n'
                        '1 26\n'
                        '1 27\n'
                        '1 28\n'
                        '1 29\n'
                        '1 30\n'
                        '1 31\n'
                        '1 32\n'
                        '1 33\n'
                        '1 34\n'
                        '1 35\n'
                        '1 36\n'
                        '1 37\n'
                        '1 38\n'
                        '1 39\n'
                        '1 40\n'
                        '1 41\n'
                        '1 42\n'
                        '1 43\n'
                        '1 44\n'
                        '1 45\n'
                        '1 46\n'
                        '1 47\n'
                        '1 48\n'
                        '1 49\n'
                        '1 50\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n'
                        '2\n',
               'category': 'constraint_max'}],
 'abc403_b': [{'input': '????\na\n', 'category': 'task_specific_01'},
              {'input': '????\nabcd\n', 'category': 'task_specific_02'},
              {'input': 'a????\nza\n', 'category': 'task_specific_03'},
              {'input': '????a\naz\n', 'category': 'task_specific_04'},
              {'input': 'a??b??\nab\n', 'category': 'task_specific_05'},
              {'input': '??e??e\nsnuke\n', 'category': 'task_specific_06'},
              {'input': 'tak??a?h?\nnashi\n', 'category': 'task_specific_07'},
              {'input': 'ab????cd\nbc\n', 'category': 'task_specific_08'},
              {'input': '????zz\nzzz\n', 'category': 'task_specific_09'},
              {'input': 'aa????aa\naaaa\n', 'category': 'task_specific_10'},
              {'input': '????abcdef\ndef\n', 'category': 'task_specific_11'},
              {'input': 'abcd????\nabc\n', 'category': 'task_specific_12'},
              {'input': '?a?b?c?d\nabcd\n', 'category': 'task_specific_13'},
              {'input': 'zz????zz\nyy\n', 'category': 'task_specific_14'},
              {'input': '????q\nqq\n', 'category': 'task_specific_15'},
              {'input': 'q????\nqq\n', 'category': 'task_specific_16'},
              {'input': 'abc????xyz\ncdef\n', 'category': 'task_specific_17'},
              {'input': 'abcde????f\nabcdefghij\n', 'category': 'constraint_max'}],
 'abc404_b': [{'input': '1\n.\n.\n', 'category': 'task_specific_01'},
              {'input': '2\n.#\n#.\n..\n#.\n', 'category': 'task_specific_02'},
              {'input': '3\n#..\n..#\n.#.\n.#.\n...\n.#.\n', 'category': 'task_specific_03'},
              {'input': '4\n..#.\n.#..\n#..#\n..#.\n#...\n..#.\n#...\n..#.\n', 'category': 'task_specific_04'},
              {'input': '5\n.#..#\n#..#.\n..#..\n.#..#\n#..#.\n...#.\n.#...\n...#.\n.#...\n...#.\n',
               'category': 'task_specific_05'},
              {'input': '6\n'
                        '#..#..\n'
                        '..#..#\n'
                        '.#..#.\n'
                        '#..#..\n'
                        '..#..#\n'
                        '.#..#.\n'
                        '..#...\n'
                        '#...#.\n'
                        '..#...\n'
                        '#...#.\n'
                        '..#...\n'
                        '#...#.\n',
               'category': 'task_specific_06'},
              {'input': '7\n'
                        '..#..#.\n'
                        '.#..#..\n'
                        '#..#..#\n'
                        '..#..#.\n'
                        '.#..#..\n'
                        '#..#..#\n'
                        '..#..#.\n'
                        '.#...#.\n'
                        '...#...\n'
                        '.#...#.\n'
                        '...#...\n'
                        '.#...#.\n'
                        '...#...\n'
                        '.#...#.\n',
               'category': 'task_specific_07'},
              {'input': '8\n'
                        '.#..#..#\n'
                        '#..#..#.\n'
                        '..#..#..\n'
                        '.#..#..#\n'
                        '#..#..#.\n'
                        '..#..#..\n'
                        '.#..#..#\n'
                        '#..#..#.\n'
                        '#...#...\n'
                        '..#...#.\n'
                        '#...#...\n'
                        '..#...#.\n'
                        '#...#...\n'
                        '..#...#.\n'
                        '#...#...\n'
                        '..#...#.\n',
               'category': 'task_specific_08'},
              {'input': '9\n'
                        '#..#..#..\n'
                        '..#..#..#\n'
                        '.#..#..#.\n'
                        '#..#..#..\n'
                        '..#..#..#\n'
                        '.#..#..#.\n'
                        '#..#..#..\n'
                        '..#..#..#\n'
                        '.#..#..#.\n'
                        '...#...#.\n'
                        '.#...#...\n'
                        '...#...#.\n'
                        '.#...#...\n'
                        '...#...#.\n'
                        '.#...#...\n'
                        '...#...#.\n'
                        '.#...#...\n'
                        '...#...#.\n',
               'category': 'task_specific_09'},
              {'input': '10\n'
                        '..#..#..#.\n'
                        '.#..#..#..\n'
                        '#..#..#..#\n'
                        '..#..#..#.\n'
                        '.#..#..#..\n'
                        '#..#..#..#\n'
                        '..#..#..#.\n'
                        '.#..#..#..\n'
                        '#..#..#..#\n'
                        '..#..#..#.\n'
                        '..#...#...\n'
                        '#...#...#.\n'
                        '..#...#...\n'
                        '#...#...#.\n'
                        '..#...#...\n'
                        '#...#...#.\n'
                        '..#...#...\n'
                        '#...#...#.\n'
                        '..#...#...\n'
                        '#...#...#.\n',
               'category': 'task_specific_10'},
              {'input': '11\n'
                        '.#..#..#..#\n'
                        '#..#..#..#.\n'
                        '..#..#..#..\n'
                        '.#..#..#..#\n'
                        '#..#..#..#.\n'
                        '..#..#..#..\n'
                        '.#..#..#..#\n'
                        '#..#..#..#.\n'
                        '..#..#..#..\n'
                        '.#..#..#..#\n'
                        '#..#..#..#.\n'
                        '.#...#...#.\n'
                        '...#...#...\n'
                        '.#...#...#.\n'
                        '...#...#...\n'
                        '.#...#...#.\n'
                        '...#...#...\n'
                        '.#...#...#.\n'
                        '...#...#...\n'
                        '.#...#...#.\n'
                        '...#...#...\n'
                        '.#...#...#.\n',
               'category': 'task_specific_11'},
              {'input': '12\n'
                        '#..#..#..#..\n'
                        '..#..#..#..#\n'
                        '.#..#..#..#.\n'
                        '#..#..#..#..\n'
                        '..#..#..#..#\n'
                        '.#..#..#..#.\n'
                        '#..#..#..#..\n'
                        '..#..#..#..#\n'
                        '.#..#..#..#.\n'
                        '#..#..#..#..\n'
                        '..#..#..#..#\n'
                        '.#..#..#..#.\n'
                        '#...#...#...\n'
                        '..#...#...#.\n'
                        '#...#...#...\n'
                        '..#...#...#.\n'
                        '#...#...#...\n'
                        '..#...#...#.\n'
                        '#...#...#...\n'
                        '..#...#...#.\n'
                        '#...#...#...\n'
                        '..#...#...#.\n'
                        '#...#...#...\n'
                        '..#...#...#.\n',
               'category': 'task_specific_12'},
              {'input': '13\n'
                        '..#..#..#..#.\n'
                        '.#..#..#..#..\n'
                        '#..#..#..#..#\n'
                        '..#..#..#..#.\n'
                        '.#..#..#..#..\n'
                        '#..#..#..#..#\n'
                        '..#..#..#..#.\n'
                        '.#..#..#..#..\n'
                        '#..#..#..#..#\n'
                        '..#..#..#..#.\n'
                        '.#..#..#..#..\n'
                        '#..#..#..#..#\n'
                        '..#..#..#..#.\n'
                        '...#...#...#.\n'
                        '.#...#...#...\n'
                        '...#...#...#.\n'
                        '.#...#...#...\n'
                        '...#...#...#.\n'
                        '.#...#...#...\n'
                        '...#...#...#.\n'
                        '.#...#...#...\n'
                        '...#...#...#.\n'
                        '.#...#...#...\n'
                        '...#...#...#.\n'
                        '.#...#...#...\n'
                        '...#...#...#.\n',
               'category': 'task_specific_13'},
              {'input': '14\n'
                        '.#..#..#..#..#\n'
                        '#..#..#..#..#.\n'
                        '..#..#..#..#..\n'
                        '.#..#..#..#..#\n'
                        '#..#..#..#..#.\n'
                        '..#..#..#..#..\n'
                        '.#..#..#..#..#\n'
                        '#..#..#..#..#.\n'
                        '..#..#..#..#..\n'
                        '.#..#..#..#..#\n'
                        '#..#..#..#..#.\n'
                        '..#..#..#..#..\n'
                        '.#..#..#..#..#\n'
                        '#..#..#..#..#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n'
                        '..#...#...#...\n'
                        '#...#...#...#.\n',
               'category': 'task_specific_14'},
              {'input': '15\n'
                        '#..#..#..#..#..\n'
                        '..#..#..#..#..#\n'
                        '.#..#..#..#..#.\n'
                        '#..#..#..#..#..\n'
                        '..#..#..#..#..#\n'
                        '.#..#..#..#..#.\n'
                        '#..#..#..#..#..\n'
                        '..#..#..#..#..#\n'
                        '.#..#..#..#..#.\n'
                        '#..#..#..#..#..\n'
                        '..#..#..#..#..#\n'
                        '.#..#..#..#..#.\n'
                        '#..#..#..#..#..\n'
                        '..#..#..#..#..#\n'
                        '.#..#..#..#..#.\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n'
                        '...#...#...#...\n'
                        '.#...#...#...#.\n',
               'category': 'task_specific_15'},
              {'input': '16\n'
                        '..#..#..#..#..#.\n'
                        '.#..#..#..#..#..\n'
                        '#..#..#..#..#..#\n'
                        '..#..#..#..#..#.\n'
                        '.#..#..#..#..#..\n'
                        '#..#..#..#..#..#\n'
                        '..#..#..#..#..#.\n'
                        '.#..#..#..#..#..\n'
                        '#..#..#..#..#..#\n'
                        '..#..#..#..#..#.\n'
                        '.#..#..#..#..#..\n'
                        '#..#..#..#..#..#\n'
                        '..#..#..#..#..#.\n'
                        '.#..#..#..#..#..\n'
                        '#..#..#..#..#..#\n'
                        '..#..#..#..#..#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n'
                        '#...#...#...#...\n'
                        '..#...#...#...#.\n',
               'category': 'task_specific_16'},
              {'input': '17\n'
                        '.#..#..#..#..#..#\n'
                        '#..#..#..#..#..#.\n'
                        '..#..#..#..#..#..\n'
                        '.#..#..#..#..#..#\n'
                        '#..#..#..#..#..#.\n'
                        '..#..#..#..#..#..\n'
                        '.#..#..#..#..#..#\n'
                        '#..#..#..#..#..#.\n'
                        '..#..#..#..#..#..\n'
                        '.#..#..#..#..#..#\n'
                        '#..#..#..#..#..#.\n'
                        '..#..#..#..#..#..\n'
                        '.#..#..#..#..#..#\n'
                        '#..#..#..#..#..#.\n'
                        '..#..#..#..#..#..\n'
                        '.#..#..#..#..#..#\n'
                        '#..#..#..#..#..#.\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n'
                        '.#...#...#...#...\n'
                        '...#...#...#...#.\n',
               'category': 'task_specific_17'},
              {'input': '100\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '####################################################################################################\n'
                        '....................................................................................................\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n'
                        '#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.#.\n',
               'category': 'constraint_max'}],
 'abc405_b': [{'input': '1 1\n1\n', 'category': 'task_specific_01'},
              {'input': '2 2\n1 2\n', 'category': 'task_specific_02'},
              {'input': '3 3\n1 2 3\n', 'category': 'task_specific_03'},
              {'input': '4 4\n1 2 3 4\n', 'category': 'task_specific_04'},
              {'input': '5 4\n1 2 3 4 1\n', 'category': 'task_specific_05'},
              {'input': '6 4\n1 2 3 4 1 2\n', 'category': 'task_specific_06'},
              {'input': '7 4\n1 2 3 4 1 2 3\n', 'category': 'task_specific_07'},
              {'input': '8 4\n1 2 3 4 1 2 3 4\n', 'category': 'task_specific_08'},
              {'input': '9 4\n1 2 3 4 1 2 3 4 1\n', 'category': 'task_specific_09'},
              {'input': '10 4\n1 2 3 4 1 2 3 4 1 2\n', 'category': 'task_specific_10'},
              {'input': '11 4\n1 2 3 4 1 2 3 4 1 2 3\n', 'category': 'task_specific_11'},
              {'input': '12 4\n1 2 3 4 1 2 3 4 1 2 3 4\n', 'category': 'task_specific_12'},
              {'input': '13 4\n1 2 3 4 1 2 3 4 1 2 3 4 1\n', 'category': 'task_specific_13'},
              {'input': '14 4\n1 2 3 4 1 2 3 4 1 2 3 4 1 2\n', 'category': 'task_specific_14'},
              {'input': '15 4\n1 2 3 4 1 2 3 4 1 2 3 4 1 2 3\n', 'category': 'task_specific_15'},
              {'input': '16 4\n1 2 3 4 1 2 3 4 1 2 3 4 1 2 3 4\n', 'category': 'task_specific_16'},
              {'input': '17 4\n1 2 3 4 1 2 3 4 1 2 3 4 1 2 3 4 1\n', 'category': 'task_specific_17'},
              {'input': '100 100\n'
                        '1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 '
                        '35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 '
                        '66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 '
                        '97 98 99 100\n',
               'category': 'constraint_max'}],
 'abc406_b': [{'input': '1 1\n2\n', 'category': 'task_specific_01'},
              {'input': '2 2\n4 6\n', 'category': 'task_specific_02'},
              {'input': '3 3\n6 9 12\n', 'category': 'task_specific_03'},
              {'input': '4 4\n8 12 16 20\n', 'category': 'task_specific_04'},
              {'input': '5 5\n10 15 20 25 30\n', 'category': 'task_specific_05'},
              {'input': '1 6\n12\n', 'category': 'task_specific_06'},
              {'input': '2 1\n9 9\n', 'category': 'task_specific_07'},
              {'input': '3 2\n16 24 32\n', 'category': 'task_specific_08'},
              {'input': '4 3\n18 27 36 45\n', 'category': 'task_specific_09'},
              {'input': '5 4\n20 30 40 50 60\n', 'category': 'task_specific_10'},
              {'input': '1 5\n22\n', 'category': 'task_specific_11'},
              {'input': '2 6\n24 36\n', 'category': 'task_specific_12'},
              {'input': '3 1\n9 9 9\n', 'category': 'task_specific_13'},
              {'input': '4 2\n28 42 56 70\n', 'category': 'task_specific_14'},
              {'input': '5 3\n30 45 60 75 90\n', 'category': 'task_specific_15'},
              {'input': '1 4\n32\n', 'category': 'task_specific_16'},
              {'input': '2 5\n34 51\n', 'category': 'task_specific_17'},
              {'input': '100 18\n'
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999 '
                        '999999999999999999 999999999999999999 999999999999999999 999999999999999999\n',
               'category': 'constraint_max'}],
 'abc407_b': [{'input': '2 0\n', 'category': 'task_specific_01'},
              {'input': '2 6\n', 'category': 'task_specific_02'},
              {'input': '3 0\n', 'category': 'task_specific_03'},
              {'input': '4 1\n', 'category': 'task_specific_04'},
              {'input': '5 2\n', 'category': 'task_specific_05'},
              {'input': '6 3\n', 'category': 'task_specific_06'},
              {'input': '7 4\n', 'category': 'task_specific_07'},
              {'input': '8 5\n', 'category': 'task_specific_08'},
              {'input': '9 3\n', 'category': 'task_specific_09'},
              {'input': '10 3\n', 'category': 'task_specific_10'},
              {'input': '11 2\n', 'category': 'task_specific_11'},
              {'input': '12 1\n', 'category': 'task_specific_12'},
              {'input': '13 0\n', 'category': 'task_specific_13'},
              {'input': '13 6\n', 'category': 'task_specific_14'},
              {'input': '9 0\n', 'category': 'task_specific_15'},
              {'input': '2 5\n', 'category': 'task_specific_16'},
              {'input': '8 2\n', 'category': 'task_specific_17'},
              {'input': '13 5\n', 'category': 'constraint_max'}],
 'abc408_b': [{'input': '1\n2\n', 'category': 'task_specific_01'},
              {'input': '2\n3 10\n', 'category': 'task_specific_02'},
              {'input': '3\n4 11 18\n', 'category': 'task_specific_03'},
              {'input': '4\n5 12 19 6\n', 'category': 'task_specific_04'},
              {'input': '5\n6 13 20 7 14\n', 'category': 'task_specific_05'},
              {'input': '6\n7 14 1 8 15 2\n', 'category': 'task_specific_06'},
              {'input': '7\n8 15 2 9 16 3 10\n', 'category': 'task_specific_07'},
              {'input': '8\n9 16 3 10 17 4 11 18\n', 'category': 'task_specific_08'},
              {'input': '9\n10 17 4 11 18 5 12 19 6\n', 'category': 'task_specific_09'},
              {'input': '10\n11 18 5 12 19 6 13 20 7 14\n', 'category': 'task_specific_10'},
              {'input': '11\n12 19 6 13 20 7 14 1 8 15 2\n', 'category': 'task_specific_11'},
              {'input': '12\n13 20 7 14 1 8 15 2 9 16 3 10\n', 'category': 'task_specific_12'},
              {'input': '13\n14 1 8 15 2 9 16 3 10 17 4 11 18\n', 'category': 'task_specific_13'},
              {'input': '14\n15 2 9 16 3 10 17 4 11 18 5 12 19 6\n', 'category': 'task_specific_14'},
              {'input': '15\n16 3 10 17 4 11 18 5 12 19 6 13 20 7 14\n', 'category': 'task_specific_15'},
              {'input': '16\n17 4 11 18 5 12 19 6 13 20 7 14 1 8 15 2\n', 'category': 'task_specific_16'},
              {'input': '17\n18 5 12 19 6 13 20 7 14 1 8 15 2 9 16 3 10\n', 'category': 'task_specific_17'},
              {'input': '100\n'
                        '1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 '
                        '35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 '
                        '66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 '
                        '97 98 99 100\n',
               'category': 'constraint_max'}],
 'abc409_b': [{'input': '1\n1\n', 'category': 'task_specific_01'},
              {'input': '2\n2 3\n', 'category': 'task_specific_02'},
              {'input': '3\n3 4 7\n', 'category': 'task_specific_03'},
              {'input': '4\n4 5 8 13\n', 'category': 'task_specific_04'},
              {'input': '5\n5 6 9 14 21\n', 'category': 'task_specific_05'},
              {'input': '6\n6 7 10 15 22 6\n', 'category': 'task_specific_06'},
              {'input': '7\n7 8 11 16 23 7 18\n', 'category': 'task_specific_07'},
              {'input': '8\n8 9 12 17 24 8 19 7\n', 'category': 'task_specific_08'},
              {'input': '9\n9 10 13 18 0 9 20 8 23\n', 'category': 'task_specific_09'},
              {'input': '10\n10 11 14 19 1 10 21 9 24 16\n', 'category': 'task_specific_10'},
              {'input': '11\n11 12 15 20 2 11 22 10 0 17 11\n', 'category': 'task_specific_11'},
              {'input': '12\n12 13 16 21 3 12 23 11 1 18 12 8\n', 'category': 'task_specific_12'},
              {'input': '13\n13 14 17 22 4 13 24 12 2 19 13 9 7\n', 'category': 'task_specific_13'},
              {'input': '14\n14 15 18 23 5 14 0 13 3 20 14 10 8 8\n', 'category': 'task_specific_14'},
              {'input': '15\n15 16 19 24 6 15 1 14 4 21 15 11 9 9 11\n', 'category': 'task_specific_15'},
              {'input': '16\n16 17 20 0 7 16 2 15 5 22 16 12 10 10 12 16\n', 'category': 'task_specific_16'},
              {'input': '17\n17 18 21 1 8 17 3 16 6 23 17 13 11 11 13 17 23\n', 'category': 'task_specific_17'},
              {'input': '100\n'
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 '
                        '1000000000 1000000000 1000000000 1000000000\n',
               'category': 'constraint_max'}],
 'abc410_b': [{'input': '2 1\n1\n', 'category': 'task_specific_01'},
              {'input': '3 2\n1 0\n', 'category': 'task_specific_02'},
              {'input': '4 3\n1 0 0\n', 'category': 'task_specific_03'},
              {'input': '5 4\n1 0 0 4\n', 'category': 'task_specific_04'},
              {'input': '6 5\n1 0 0 4 0\n', 'category': 'task_specific_05'},
              {'input': '7 6\n1 0 0 4 0 0\n', 'category': 'task_specific_06'},
              {'input': '1 7\n1 0 0 1 0 0 1\n', 'category': 'task_specific_07'},
              {'input': '2 8\n1 0 0 2 0 0 1 0\n', 'category': 'task_specific_08'},
              {'input': '3 9\n1 0 0 1 0 0 1 0 0\n', 'category': 'task_specific_09'},
              {'input': '4 10\n1 0 0 4 0 0 3 0 0 2\n', 'category': 'task_specific_10'},
              {'input': '5 11\n1 0 0 4 0 0 2 0 0 5 0\n', 'category': 'task_specific_11'},
              {'input': '6 12\n1 0 0 4 0 0 1 0 0 4 0 0\n', 'category': 'task_specific_12'},
              {'input': '7 13\n1 0 0 4 0 0 7 0 0 3 0 0 6\n', 'category': 'task_specific_13'},
              {'input': '1 14\n1 0 0 1 0 0 1 0 0 1 0 0 1 0\n', 'category': 'task_specific_14'},
              {'input': '2 15\n1 0 0 2 0 0 1 0 0 2 0 0 1 0 0\n', 'category': 'task_specific_15'},
              {'input': '3 16\n1 0 0 1 0 0 1 0 0 1 0 0 1 0 0 1\n', 'category': 'task_specific_16'},
              {'input': '4 17\n1 0 0 4 0 0 3 0 0 2 0 0 1 0 0 4 0\n', 'category': 'task_specific_17'},
              {'input': '100 100\n'
                        '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '
                        '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '
                        '0 0 0 0 0 0\n',
               'category': 'constraint_max'}]}
REFERENCE_CODE={'abc393_b': 'S=input().strip();n=len(S);ans=0\n'
             'for j in range(1,n-1):\n'
             " if S[j]=='B':\n"
             '  for d in range(1,min(j+1,n-j)):\n'
             "   if S[j-d]=='A' and S[j+d]=='C':ans+=1\n"
             'print(ans)\n',
 'abc394_b': "N=int(input());a=[input().strip() for _ in range(N)];a.sort(key=len);print(''.join(a))\n",
 'abc395_b': "N=int(input());g=[['?']*N for _ in range(N)]\n"
             'for i in range(1,N+1):\n'
             ' j=N+1-i\n'
             ' if i<=j:\n'
             "  c='#' if i%2 else '.'\n"
             '  for r in range(i-1,j):\n'
             '   for q in range(i-1,j):g[r][q]=c\n'
             "print(*map(''.join,g),sep='\\n')\n",
 'abc396_b': 'Q=int(input());s=[0]*100\n'
             'for _ in range(Q):\n'
             ' a=list(map(int,input().split()))\n'
             ' if a[0]==1:s.append(a[1])\n'
             ' else:print(s.pop())\n',
 'abc397_b': "S=input().strip();ans=0;want='i'\n"
             'for c in S:\n'
             " if c!=want:ans+=1;want='o' if want=='i' else 'i'\n"
             " want='o' if want=='i' else 'i'\n"
             "if want=='o':ans+=1\n"
             'print(ans)\n',
 'abc398_b': 'from collections import Counter\n'
             'a=list(map(int,input().split()));c=Counter(a)\n'
             "print('Yes' if any(c[x]>=3 and c[y]>=2 for x in c for y in c if x!=y) else 'No')\n",
 'abc399_b': 'N=int(input());p=list(map(int,input().split()));r=[0]*N;cur=1\n'
             'for score in sorted(set(p),reverse=True):\n'
             ' ids=[i for i,x in enumerate(p) if x==score]\n'
             ' for i in ids:r[i]=cur\n'
             ' cur+=len(ids)\n'
             "print(*r,sep='\\n')\n",
 'abc400_b': 'N,M=map(int,input().split());s=0;p=1\n'
             'for _ in range(M+1):\n'
             ' s+=p\n'
             ' if s>10**9:break\n'
             ' p*=N\n'
             "print('inf' if s>10**9 else s)\n",
 'abc401_b': 'N=int(input());login=False;ans=0\n'
             'for _ in range(N):\n'
             ' s=input().strip()\n'
             " if s=='login':login=True\n"
             " elif s=='logout':login=False\n"
             " elif s=='private' and not login:ans+=1\n"
             'print(ans)\n',
 'abc402_b': 'from collections import deque\n'
             'Q=int(input());q=deque()\n'
             'for _ in range(Q):\n'
             ' a=list(map(int,input().split()))\n'
             ' if a[0]==1:q.append(a[1])\n'
             ' else:print(q.popleft())\n',
 'abc403_b': 'T=input().strip();U=input().strip();m=len(U)\n'
             "print('Yes' if any(all(a=='?' or a==b for a,b in zip(T[i:i+m],U)) for i in range(len(T)-m+1)) else "
             "'No')\n",
 'abc404_b': 'N=int(input());S=[input().strip() for _ in range(N)];T=[input().strip() for _ in range(N)];ans=10**9\n'
             'for k in range(4):\n'
             ' ans=min(ans,k+sum(S[i][j]!=T[i][j] for i in range(N) for j in range(N)))\n'
             " S=[''.join(S[N-1-j][i] for j in range(N)) for i in range(N)]\n"
             'print(ans)\n',
 'abc405_b': 'N,M=map(int,input().split());A=list(map(int,input().split()))\n'
             'if len(set(A))<M:print(0)\n'
             'else:\n'
             ' first=[N]*M\n'
             ' for i,x in enumerate(A):first[x-1]=min(first[x-1],i)\n'
             ' print(N-max(first))\n',
 'abc406_b': 'N,K=map(int,input().split());A=list(map(int,input().split()));x=1;lim=10**K\n'
             'for a in A:\n'
             ' x*=a\n'
             ' if x>=lim:x=1\n'
             'print(x)\n',
 'abc407_b': 'X,Y=map(int,input().split());c=0\n'
             'for a in range(1,7):\n'
             ' for b in range(1,7):c+=(a+b>=X or abs(a-b)>=Y)\n'
             'print(c/36)\n',
 'abc408_b': 'N=int(input());A=list(map(int,input().split()));B=sorted(set(A));print(len(B));print(*B)\n',
 'abc409_b': 'N=int(input());A=sorted(map(int,input().split()),reverse=True);ans=0\n'
             'for i,a in enumerate(A,1):\n'
             ' if a>=i:ans=i\n'
             'print(ans)\n',
 'abc410_b': 'N,Q=map(int,input().split());X=list(map(int,input().split()));cnt=[0]*N;ans=[]\n'
             'for x in X:\n'
             ' if x==0:\n'
             '  m=min(cnt);b=cnt.index(m)\n'
             ' else:b=x-1\n'
             ' cnt[b]+=1;ans.append(b+1)\n'
             'print(*ans)\n'}
LOWER=re.compile(r'[a-z]+')
UPPER=re.compile(r'[A-Z]+')

def _lines(raw:str):
    if not raw.endswith('\n'): raise ValueError('newline')
    return raw[:-1].split('\n')
def _ints(s:str):
    try:return list(map(int,s.split()))
    except Exception as e: raise ValueError('ints') from e

def validate(pid:str,raw:str):
    if pid not in TASKS: raise ValueError('pid')
    l=_lines(raw)
    if pid=='abc393_b':
        if len(l)!=1 or not(3<=len(l[0])<=100) or UPPER.fullmatch(l[0]) is None: raise ValueError('S')
        return (l[0],)
    if pid=='abc394_b':
        if not l: raise ValueError('shape')
        n=int(l[0]); ss=l[1:]
        if not(2<=n<=50) or len(ss)!=n or any(LOWER.fullmatch(s) is None or not(1<=len(s)<=50) for s in ss) or len({len(s) for s in ss})!=n: raise ValueError('strings')
        return n,tuple(ss)
    if pid=='abc395_b':
        if len(l)!=1: raise ValueError('shape')
        n=int(l[0]);
        if not 1<=n<=50: raise ValueError('N')
        return (n,)
    if pid=='abc396_b':
        if not l: raise ValueError('shape')
        q=int(l[0]); qs=l[1:]
        if not 1<=q<=100 or len(qs)!=q: raise ValueError('Q')
        has2=False
        for s in qs:
            a=_ints(s)
            if a==[2]:has2=True
            elif len(a)==2 and a[0]==1 and 1<=a[1]<=100:pass
            else: raise ValueError('query')
        if not has2: raise ValueError('type2')
        return q,tuple(qs)
    if pid=='abc397_b':
        if len(l)!=1 or not(1<=len(l[0])<=100) or any(c not in 'io' for c in l[0]): raise ValueError('S')
        return (l[0],)
    if pid=='abc398_b':
        if len(l)!=1: raise ValueError('shape')
        a=_ints(l[0]);
        if len(a)!=7 or any(not 1<=x<=13 for x in a): raise ValueError('A')
        return (tuple(a),)
    if pid=='abc399_b':
        if len(l)!=2: raise ValueError('shape')
        n=int(l[0]); a=_ints(l[1])
        if not 1<=n<=100 or len(a)!=n or any(not 1<=x<=100 for x in a): raise ValueError('A')
        return n,tuple(a)
    if pid=='abc400_b':
        if len(l)!=1: raise ValueError('shape')
        a=_ints(l[0]);
        if len(a)!=2 or not(1<=a[0]<=10**9 and 1<=a[1]<=100): raise ValueError('NM')
        return tuple(a)
    if pid=='abc401_b':
        if not l: raise ValueError('shape')
        n=int(l[0]); ops=l[1:]
        if not 1<=n<=100 or len(ops)!=n or any(s not in {'login','logout','public','private'} for s in ops): raise ValueError('ops')
        return n,tuple(ops)
    if pid=='abc402_b':
        if not l: raise ValueError('shape')
        q=int(l[0]); qs=l[1:]
        if not 1<=q<=100 or len(qs)!=q: raise ValueError('Q')
        size=0
        for s in qs:
            a=_ints(s)
            if len(a)==2 and a[0]==1 and 1<=a[1]<=100:size+=1
            elif a==[2] and size>0:size-=1
            else: raise ValueError('query')
        return q,tuple(qs)
    if pid=='abc403_b':
        if len(l)!=2: raise ValueError('shape')
        t,u=l
        if not(4<=len(t)<=10) or any(not(c=='?' or 'a'<=c<='z') for c in t) or t.count('?')!=4: raise ValueError('T')
        if not(1<=len(u)<=len(t)) or LOWER.fullmatch(u) is None: raise ValueError('U')
        return t,u
    if pid=='abc404_b':
        if not l: raise ValueError('shape')
        n=int(l[0]); rows=l[1:]
        if not 1<=n<=100 or len(rows)!=2*n or any(len(s)!=n or any(c not in '.#' for c in s) for s in rows): raise ValueError('grid')
        return n,tuple(rows[:n]),tuple(rows[n:])
    if pid=='abc405_b':
        if len(l)!=2: raise ValueError('shape')
        h=_ints(l[0]); a=_ints(l[1])
        if len(h)!=2: raise ValueError('head')
        n,m=h
        if not(1<=m<=n<=100) or len(a)!=n or any(not 1<=x<=m for x in a): raise ValueError('A')
        return n,m,tuple(a)
    if pid=='abc406_b':
        if len(l)!=2: raise ValueError('shape')
        h=_ints(l[0]); a=_ints(l[1])
        if len(h)!=2: raise ValueError('head')
        n,k=h
        if not(1<=n<=100 and 1<=k<=18) or len(a)!=n or any(not 1<=x<10**k for x in a): raise ValueError('A')
        return n,k,tuple(a)
    if pid=='abc407_b':
        if len(l)!=1: raise ValueError('shape')
        a=_ints(l[0]);
        if len(a)!=2 or not(2<=a[0]<=13 and 0<=a[1]<=6): raise ValueError('XY')
        return tuple(a)
    if pid=='abc408_b':
        if len(l)!=2: raise ValueError('shape')
        n=int(l[0]); a=_ints(l[1])
        if not 1<=n<=100 or len(a)!=n or any(not 1<=x<=100 for x in a): raise ValueError('A')
        return n,tuple(a)
    if pid=='abc409_b':
        if len(l)!=2: raise ValueError('shape')
        n=int(l[0]); a=_ints(l[1])
        if not 1<=n<=100 or len(a)!=n or any(not 0<=x<=10**9 for x in a): raise ValueError('A')
        return n,tuple(a)
    if pid=='abc410_b':
        if len(l)!=2: raise ValueError('shape')
        h=_ints(l[0]); x=_ints(l[1])
        if len(h)!=2: raise ValueError('head')
        n,q=h
        if not(1<=n<=100 and 1<=q<=100) or len(x)!=q or any(not 0<=v<=n for v in x): raise ValueError('X')
        return n,q,tuple(x)
    raise ValueError('pid')

def _oracle(pid:str,raw:str)->str:
    v=validate(pid,raw)
    if pid=='abc393_b':
        s=v[0]; return str(sum(1 for j,c in enumerate(s) if c=='B' for d in range(1,min(j+1,len(s)-j)) if s[j-d]=='A' and s[j+d]=='C'))
    if pid=='abc394_b': return ''.join(sorted(v[1],key=len))
    if pid=='abc395_b':
        n=v[0]; out=[]
        for i in range(n):
            row=''
            for j in range(n):
                layer=min(i,j,n-1-i,n-1-j); row += '#' if layer%2==0 else '.'
            out.append(row)
        return '\n'.join(out)
    if pid=='abc396_b':
        st=[0]*100; out=[]
        for s in v[1]:
            a=_ints(s)
            if a[0]==1: st.append(a[1])
            else: out.append(str(st.pop()))
        return '\n'.join(out)
    if pid=='abc397_b':
        s=v[0]; pos=0; add=0
        for ch in s:
            want='i' if pos%2==0 else 'o'
            if ch!=want: add+=1; pos+=1
            pos+=1
        if pos%2: add+=1
        return str(add)
    if pid=='abc398_b':
        a=v[0]
        for idxs in combinations(range(7),5):
            c=sorted(Counter(a[i] for i in idxs).values())
            if c==[2,3]: return 'Yes'
        return 'No'
    if pid=='abc399_b':
        n,a=v; return '\n'.join(str(1+sum(1 for y in a if y>x)) for x in a)
    if pid=='abc400_b':
        n,m=v; total=0; p=1
        for _ in range(m+1):
            total+=p
            if total>10**9:return 'inf'
            if p>10**9//n: p=10**9+1
            else:p*=n
        return str(total)
    if pid=='abc401_b':
        _,ops=v; login=False; ans=0
        for s in ops:
            if s=='login':login=True
            elif s=='logout':login=False
            elif s=='private' and not login:ans+=1
        return str(ans)
    if pid=='abc402_b':
        _,qs=v; q=deque(); out=[]
        for s in qs:
            a=_ints(s)
            if a[0]==1:q.append(a[1])
            else:out.append(str(q.popleft()))
        return '\n'.join(out)
    if pid=='abc403_b':
        t,u=v
        for i in range(len(t)-len(u)+1):
            if all(t[i+j]=='?' or t[i+j]==u[j] for j in range(len(u))):return 'Yes'
        return 'No'
    if pid=='abc404_b':
        n,s,t=v; g=list(s); best=10**9
        for r in range(4):
            diff=sum(g[i][j]!=t[i][j] for i in range(n) for j in range(n)); best=min(best,r+diff)
            g=[''.join(g[n-1-j][i] for j in range(n)) for i in range(n)]
        return str(best)
    if pid=='abc405_b':
        n,m,a=v
        for d in range(n+1):
            if len(set(a[:n-d]))<m:return str(d)
        return str(n)
    if pid=='abc406_b':
        n,k,a=v; x=1; lim=10**k
        for y in a:
            x*=y
            if x>=lim:x=1
        return str(x)
    if pid=='abc407_b':
        x,y=v; good=sum(1 for a in range(1,7) for b in range(1,7) if a+b>=x or abs(a-b)>=y)
        return repr(good/36)
    if pid=='abc408_b':
        vals=sorted(set(v[1])); return str(len(vals))+'\n'+' '.join(map(str,vals))
    if pid=='abc409_b':
        n,a=v; return str(max(x for x in range(n+1) if sum(y>=x for y in a)>=x))
    if pid=='abc410_b':
        n,q,xs=v; cnt=[0]*n; out=[]
        for x in xs:
            if x==0: idx=min(range(n),key=lambda i:(cnt[i],i))
            else: idx=x-1
            cnt[idx]+=1; out.append(str(idx+1))
        return ' '.join(out)
    raise ValueError(pid)

def _float_ok(actual:str, expected:str, eps=1e-9):
    try:a=float(actual.strip()); b=float(expected.strip())
    except Exception:return False
    return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=eps

def independent_check(pid:str,raw:str,actual:str)->bool:
    try: exp=_oracle(pid,raw)
    except Exception:return False
    if pid=='abc407_b': return _float_ok(actual,exp,1e-9)
    return actual.rstrip('\n')==exp.rstrip('\n')

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc407_b': return _float_ok(stdout,expected,1e-9) and independent_check(pid,raw,expected)
    return stdout.rstrip('\n')==expected.rstrip('\n') and independent_check(pid,raw,expected.rstrip('\n'))

def generate(pid:str):
    validate(pid,GENERATED_CASES[pid][0]['input'])
    return [dict(x) for x in GENERATED_CASES[pid]]
