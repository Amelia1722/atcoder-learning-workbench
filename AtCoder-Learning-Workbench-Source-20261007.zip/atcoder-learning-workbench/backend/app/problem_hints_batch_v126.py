"""Statement-checked three-stage hints for ABC236–238 B."""
HINTS_V126 = {
    'abc236_b': (
        '1からNまでの各数字は本来4枚ずつあります。受け取ったカードでは、ただ1つの数字だけが3枚になっています。',
        '出現回数を数えて3回しか現れない数字を探せます。別解として、本来ある全カードの総和から入力の総和を引いても答えになります。',
        '疑似コード:\ncount = [0] * (N+1)\nfor x in A: count[x] += 1\nfor x = 1 .. N:\n  if count[x] == 3:\n    print(x); stop',
    ),
    'abc237_b': (
        '転置では、元の行と列の役割が入れ替わります。出力のi行j列は、入力のj行i列です。',
        '出力側の行番号iを先に固定し、その中で元行jを1からHまで動かして `A[j][i]` を並べます。',
        '疑似コード:\nfor col = 0 .. W-1:\n  row = []\n  for r = 0 .. H-1:\n    row.append(A[r][col])\n  print(row joined by spaces)',
    ),
    'abc238_b': (
        '切れ込みそのものではなく、0度から見た「切れ込み位置」を記録すると、最後のピザ片の角度を比較できます。',
        '現在角度に各A_iを足して360で割った余りを記録し、0度も加えて昇順にします。隣接する切れ込みの差と、最後から360度を経由して0度へ戻る差の最大を取ります。',
        '疑似コード:\npos = 0; cuts = [0]\nfor a in A:\n  pos = (pos + a) % 360\n  cuts.append(pos)\nsort(cuts)\nans = max(cuts[i+1] - cuts[i])\nans = max(ans, 360 - cuts[-1] + cuts[0])\nprint(ans)',
    ),
}
