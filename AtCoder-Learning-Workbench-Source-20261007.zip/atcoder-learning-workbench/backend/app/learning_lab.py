"""Evidence-aware learning lab and reproducible problem test specifications.

No arbitrary code is executed on the API server. User code runs in a browser Worker.
Unreviewed links and self-reported evidence are never presented as verified.
"""
from __future__ import annotations

import json
import math
import random
import re
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Literal

from fastapi import HTTPException
from pydantic import BaseModel, Field, field_validator, model_validator

from .atlas_state import validate_user_id
from .database import db

LAB_SCHEMA = """
CREATE TABLE IF NOT EXISTS lab_problem_knowledge (
 problem_id TEXT NOT NULL REFERENCES problems(problem_id) ON DELETE CASCADE,
 anchor TEXT NOT NULL REFERENCES knowledge_sections(anchor) ON DELETE CASCADE,
 role TEXT NOT NULL CHECK(role IN ('essential','supporting','alternative')),
 contribution INTEGER NOT NULL CHECK(contribution BETWEEN 0 AND 10),
 status TEXT NOT NULL CHECK(status IN ('verified','user_reviewed','candidate')),
 evidence TEXT NOT NULL DEFAULT '',
 updated_at INTEGER NOT NULL,
 PRIMARY KEY(problem_id,anchor)
);
CREATE INDEX IF NOT EXISTS idx_lab_knowledge_anchor ON lab_problem_knowledge(anchor);
CREATE TABLE IF NOT EXISTS lab_prerequisites (
 anchor TEXT NOT NULL REFERENCES knowledge_sections(anchor) ON DELETE CASCADE,
 prerequisite TEXT NOT NULL REFERENCES knowledge_sections(anchor) ON DELETE CASCADE,
 status TEXT NOT NULL CHECK(status IN ('verified','user_reviewed','candidate')),
 evidence TEXT NOT NULL DEFAULT '',
 PRIMARY KEY(anchor,prerequisite),
 CHECK(anchor <> prerequisite)
);
CREATE TABLE IF NOT EXISTS lab_test_specs (
 problem_id TEXT PRIMARY KEY REFERENCES problems(problem_id) ON DELETE CASCADE,
 spec_json TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('verified','user_defined')),
 evidence TEXT NOT NULL DEFAULT '',
 updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS lab_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id TEXT NOT NULL,
 problem_id TEXT,
 anchor TEXT,
 kind TEXT NOT NULL,
 payload_json TEXT NOT NULL,
 recorded_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lab_events_user ON lab_events(user_id,recorded_at);
CREATE INDEX IF NOT EXISTS idx_lab_events_knowledge ON lab_events(user_id,anchor,recorded_at);
CREATE TABLE IF NOT EXISTS lab_reviews (
 user_id TEXT NOT NULL,
 anchor TEXT NOT NULL REFERENCES knowledge_sections(anchor) ON DELETE CASCADE,
 stage INTEGER NOT NULL DEFAULT 0,
 due_at INTEGER NOT NULL,
 last_result INTEGER,
 updated_at INTEGER NOT NULL,
 PRIMARY KEY(user_id,anchor)
);
CREATE TABLE IF NOT EXISTS lab_search_feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id TEXT NOT NULL,
 query TEXT NOT NULL,
 anchor TEXT NOT NULL,
 helpful INTEGER NOT NULL,
 recorded_at INTEGER NOT NULL
);
"""

# Only manually reviewed pairs with traceable task descriptions. Not extrapolated to all problems.
CURATED_LINKS = [
    ('abc154_c', 'sec-1-3', 'essential', 9, 'ABC154 C: pairwise distinct; set cardinality.'),
    ('abc154_c', 'sec-1-4', 'alternative', 7, 'ABC154 C: counting frequencies can detect duplicates.'),
    ('abc154_c', 'sec-1-7', 'alternative', 6, 'ABC154 C: sort then compare adjacent numbers.'),
    ('abc143_c', 'sec-2-2', 'essential', 9, 'ABC143 C: count contiguous equal-color runs.'),
    ('abc200_c', 'sec-6-7', 'essential', 9, 'ABC200 C: count equal remainder pairs with C(n,2).'),
    ('abc200_c', 'sec-1-4', 'supporting', 7, 'ABC200 C: count occurrences of each remainder.'),
]
CURATED_PREREQS = [
    ('sec-7-2', 'sec-1-5', 'BFS queue using deque.'),
    ('sec-7-2', 'sec-7-1', 'Graph adjacency representation.'),
    ('sec-7-3', 'sec-7-2', 'Multi-source BFS generalizes BFS.'),
    ('sec-7-4', 'sec-7-2', 'Stateful BFS generalizes BFS.'),
    ('sec-7-8', 'sec-7-2', '0-1 BFS extends BFS with 0/1 edge weights.'),
    ('sec-7-7', 'sec-1-6', 'Dijkstra requires priority queue.'),
    ('sec-7-7', 'sec-7-1', 'Dijkstra requires weighted graph representation.'),
    ('sec-7-11', 'sec-7-6', 'Kruskal uses DSU.'),
    ('sec-10-1', 'sec-4-1', 'Fenwick requires prefix aggregation concept.'),
    ('sec-23-14', 'sec-8-7', 'Rerooting extends tree DP.'),
    ('sec-9-2', 'sec-9-1', 'Doubling applies repeated functional transitions.'),
]

# Verified problem input shapes and constraints from the corresponding public AtCoder tasks.
CURATED_SPECS: dict[str, dict[str, Any]] = {
    'abc154_c': {'kind':'integer_array','n_min':2,'n_max':200000,'value_min':1,'value_max':10**9,
       'description':'N / A1 ... AN。任意の2要素が異なるならYES、そうでなければNO。', 'oracle':'distinct',
       'sample_input':'5\n2 6 1 4 5\n','sample_output':'YES',
       'source_url':'https://atcoder.jp/contests/abc154/tasks/abc154_c'},
    'abc200_c': {'kind':'integer_array','n_min':2,'n_max':200000,'value_min':1,'value_max':10**9,
       'description':'N / A1 ... AN。i<j、Ai-Ajが200の倍数となる組数。', 'oracle':'mod200_pairs',
       'sample_input':'6\n123 223 123 523 200 2000\n','sample_output':'4',
       'source_url':'https://atcoder.jp/contests/abc200/tasks/abc200_c'},
    'abc143_c': {'kind':'string','n_min':1,'n_max':100000,'alphabet':'abcdefghijklmnopqrstuvwxyz',
       'description':'N / S。同じ文字の連続区間の個数。','oracle':'runs',
       'sample_input':'10\naabbbbaaca\n','sample_output':'5',
       'source_url':'https://atcoder.jp/contests/abc143/tasks/abc143_c'},
}


def init_lab() -> None:
    """Additive schema migration: existing submissions and user notes are untouched."""
    with db() as con:
        con.executescript(LAB_SCHEMA)
        now = int(time.time())
        for pid, anchor, role, contribution, evidence in CURATED_LINKS:
            if (con.execute('SELECT 1 FROM problems WHERE problem_id=?',(pid,)).fetchone() and
                con.execute('SELECT 1 FROM knowledge_sections WHERE anchor=?',(anchor,)).fetchone()):
                con.execute('''INSERT OR IGNORE INTO lab_problem_knowledge
                  (problem_id,anchor,role,contribution,status,evidence,updated_at)
                  VALUES(?,?,?,?,?,?,?)''', (pid,anchor,role,contribution,'verified',evidence,now))
        for anchor, prereq, evidence in CURATED_PREREQS:
            if all(con.execute('SELECT 1 FROM knowledge_sections WHERE anchor=?',(a,)).fetchone() for a in (anchor,prereq)):
                con.execute('''INSERT OR IGNORE INTO lab_prerequisites(anchor,prerequisite,status,evidence)
                  VALUES(?,?,?,?)''', (anchor,prereq,'verified',evidence))
        for pid, spec in CURATED_SPECS.items():
            if con.execute('SELECT 1 FROM problems WHERE problem_id=?',(pid,)).fetchone():
                con.execute('''INSERT OR IGNORE INTO lab_test_specs(problem_id,spec_json,status,evidence,updated_at)
                  VALUES(?,?,?,?,?)''', (pid,json.dumps(spec,ensure_ascii=False),'verified',spec['source_url'],now))


def _known_problem(con, problem_id: str) -> None:
    if not con.execute('SELECT 1 FROM problems WHERE problem_id=?',(problem_id,)).fetchone():
        raise HTTPException(404,'問題が登録されていません')


def _known_anchor(con, anchor: str) -> None:
    if not con.execute('SELECT 1 FROM knowledge_sections WHERE anchor=?',(anchor,)).fetchone():
        raise HTTPException(404,'Knowledge IDが存在しません')


class LinkEdit(BaseModel):
    anchor: str = Field(min_length=1,max_length=120)
    role: Literal['essential','supporting','alternative']
    contribution: int = Field(ge=0,le=10)
    evidence: str = Field(default='',max_length=2000)


class PrerequisiteEdit(BaseModel):
    anchor: str
    prerequisite: str
    evidence: str = Field(default='',max_length=2000)


class SpecEdit(BaseModel):
    kind: Literal['integer_array','string','tree','graph']
    n_min: int = Field(ge=1,le=1000000)
    n_max: int = Field(ge=1,le=1000000)
    value_min: int = Field(default=1,ge=-10**18,le=10**18)
    value_max: int = Field(default=10**9,ge=-10**18,le=10**18)
    alphabet: str = Field(default='abc',min_length=1,max_length=100)
    m_min: int = Field(default=0,ge=0,le=1000000)
    m_max: int = Field(default=10,ge=0,le=1000000)
    connected: bool = False
    directed: bool = False
    description: str = Field(default='',max_length=2000)

    @model_validator(mode='after')
    def valid_bounds(self):
        if self.n_min>self.n_max or self.value_min>self.value_max or self.m_min>self.m_max:
            raise ValueError('下限は上限以下にしてください')
        if self.kind == 'tree' and self.n_min < 2:
            raise ValueError('この入力テンプレートのtreeはN>=2です')
        if self.kind == 'graph' and self.connected and self.m_max < self.n_min-1:
            raise ValueError('連結グラフのM上限はN-1以上必要です')
        return self


class GenerateRequest(BaseModel):
    count: int = Field(default=12,ge=1,le=80)
    seed: int = Field(default=42,ge=0,le=2**32-1)
    max_n: int = Field(default=30,ge=1,le=200000)
    include_large: bool = False
    force_n: int | None = Field(default=None, ge=1, le=200000)


class ShrinkRequest(BaseModel):
    input: str = Field(min_length=1,max_length=300000)


EVENTS = {'hint_used','editorial_viewed','technique_used','reflection','failure','review','quiz',
          'ac_review','test_failure','code_comparison','search_feedback','virtual_review'}


class EventInput(BaseModel):
    problem_id: str | None = Field(default=None,max_length=80)
    anchor: str | None = Field(default=None,max_length=120)
    kind: str
    payload: dict[str,Any] = Field(default_factory=dict)
    @field_validator('kind')
    @classmethod
    def valid_kind(cls,v):
        if v not in EVENTS:
            raise ValueError('unsupported event kind')
        return v
    @field_validator('payload')
    @classmethod
    def valid_payload(cls,v):
        if len(json.dumps(v,ensure_ascii=False))>4000:
            raise ValueError('payload too large')
        return v


class QuizAnswer(BaseModel):
    answer: int = Field(ge=0,le=10)
    problem_id: str | None = None


class Feedback(BaseModel):
    query: str = Field(min_length=1,max_length=2000)
    anchor: str = Field(min_length=1,max_length=120)
    helpful: bool


# Expert-reviewed, unambiguous quizzes; no generated "correct answers" for unsupported topics.
QUIZZES: dict[str,list[dict]] = {
 'sec-1-3': [
  {'id':'set-unique','q':'A=[2,6,1,4,2]。すべての要素が異なるかをどう判定する？',
   'options':['len(set(A)) == len(A)','len(set(A)) > len(A)','2 in A が False','A.sort() が True'],
   'answer':0,'explanation':'setは重複を取り除く。元の長さと等しいとき全要素が異なる。'},
  {'id':'set-order','q':'setに変換すると失う情報はどれ？',
   'options':['存在判定能力','重複個数と元の順序','要素の型','要素の値'],
   'answer':1,'explanation':'setは順序・重複回数を保持しない。'},
 ],
 'sec-1-4': [{'id':'counter-count','q':'Counter([1,1,2])[1] の値は？',
  'options':['1','2','3','KeyError'],'answer':1,'explanation':'値1の出現回数は2回。'}],
 'sec-4-1': [{'id':'prefix','q':'S[i]=A[0:i]の和のとき、A[l:r]の和は？',
  'options':['S[r]-S[l]','S[r+1]-S[l]','S[l]-S[r]','S[r]+S[l]'],
  'answer':0,'explanation':'半開区間[l,r)はS[r]-S[l]。'}],
 'sec-7-2': [{'id':'bfs-weight','q':'通常のBFSで辺数が最小の経路を求められる条件は？',
  'options':['負の辺がある','すべての辺コストが等しい','任意の非負重み','頂点数が偶数'],
  'answer':1,'explanation':'各辺の移動コストが等しければ層順に確定する。'}],
 'sec-7-8': [{'id':'01bfs','q':'0-1 BFSでコスト0の遷移先はdequeのどこへ追加する？',
  'options':['右端','左端','追加しない','任意の位置'],'answer':1,'explanation':'0コストならappendleft、1コストならappend。'}],
 'sec-7-7': [{'id':'dijkstra-neg','q':'通常のDijkstra法について正しい説明は？',
  'options':['負辺を含んでも常に正しい','辺の重みが非負なら使用できる','BFSと同じ距離順','必ずO(N²)'],
  'answer':1,'explanation':'通常Dijkstra法は非負辺重みが前提。'}],
 'sec-8-3': [{'id':'knapsack-direction','q':'0/1ナップサックの1次元DPで同じ品物を二重使用しない更新順は？',
  'options':['容量の昇順','容量の降順','任意順','ソート不要'],'answer':1,
  'explanation':'降順に更新すると今回の品物で更新した値を再利用しない。'}],
 'sec-10-1': [{'id':'bit-range','q':'Fenwick Treeで区間[l,r)の和を求める式は？',
  'options':['sum(r)-sum(l)','sum(r)+sum(l)','sum(l)-sum(r)','sum(r-l)'],
  'answer':0,'explanation':'累積和の差を取る。'}],
}


def _oracle(spec:dict,input_text:str)->str|None:
    kind=spec.get('oracle')
    if not kind:
        return None
    lines=input_text.split()
    if not lines: raise ValueError('empty input')
    n=int(lines[0]); data=lines[1:]
    if kind=='distinct': return 'YES' if len(set(map(int,data)))==n else 'NO'
    if kind=='mod200_pairs':
        counts=[0]*200
        for x in data: counts[int(x)%200]+=1
        return str(sum(c*(c-1)//2 for c in counts))
    if kind=='runs':
        s=data[0]
        return str(1+sum(a!=b for a,b in zip(s,s[1:])))
    return None


def _format_case(spec:dict,content:Any)->str:
    kind=spec['kind']
    if kind=='integer_array': return f'{len(content)}\n'+ ' '.join(map(str,content))+'\n'
    if kind=='string': return f'{len(content)}\n{content}\n'
    if kind in ('tree','graph'):
        n,edges=content
        head = f'{n}\n' if kind=='tree' else f'{n} {len(edges)}\n'
        return head + ''.join(f'{u} {v}\n' for u,v in edges)
    raise ValueError('unsupported kind')


def _parse_case(spec:dict,raw:str)->Any:
    tokens=raw.split(); kind=spec['kind']
    if not tokens: raise ValueError('入力が空です')
    n=int(tokens[0]); lo=int(spec['n_min']); hi=int(spec['n_max'])
    if not lo<=n<=hi: raise ValueError('Nが制約外です')
    if kind=='integer_array':
        if len(tokens)!=n+1: raise ValueError('配列の個数がNと一致しません')
        a=list(map(int,tokens[1:])); low=int(spec['value_min']); high=int(spec['value_max'])
        if any(not low<=x<=high for x in a): raise ValueError('Aiが制約外です')
        return a
    if kind=='string':
        if len(tokens)!=2 or len(tokens[1])!=n or any(c not in spec['alphabet'] for c in tokens[1]):
            raise ValueError('文字列の長さまたは文字種が制約外です')
        return tokens[1]
    if kind in ('tree','graph'):
        m = n-1 if kind=='tree' else int(tokens[1])
        pos=1 if kind=='tree' else 2
        if kind=='graph' and not spec['m_min']<=m<=spec['m_max']:
            raise ValueError('Mが制約外です')
        if len(tokens)!=pos+2*m: raise ValueError('辺の本数が一致しません')
        edges=[(int(tokens[pos+2*i]),int(tokens[pos+2*i+1])) for i in range(m)]
        if any(not 1<=u<=n or not 1<=v<=n or u==v for u,v in edges):raise ValueError('辺の端点が不正です')
        directed=bool(spec.get('directed',False))
        keys=[(u,v) if directed else tuple(sorted((u,v))) for u,v in edges]
        if len(keys)!=len(set(keys)):raise ValueError('重複辺があります')
        if kind=='tree' or spec.get('connected'):
            parent=list(range(n+1))
            def find(x):
                while parent[x]!=x: parent[x]=parent[parent[x]];x=parent[x]
                return x
            for u,v in edges: parent[find(u)]=find(v)
            if len({find(i) for i in range(1,n+1)})!=1:raise ValueError('連結条件を満たしません')
        return (n,edges)
    raise ValueError('unsupported kind')


def _case_record(spec:dict,content:Any,category:str)->dict:
    raw=_format_case(spec,content)
    return {'input':raw,'expected':_oracle(spec,raw),'category':category,
            'judge': 'verified_oracle' if spec.get('oracle') else 'unverified'}


def generate_cases(spec:dict, req:GenerateRequest)->list[dict]:
    """Deterministic constrained generation; no inference from free-form prose."""
    r=random.Random(req.seed)
    lo,hi=spec['n_min'],min(spec['n_max'],req.max_n)
    if lo>hi: raise HTTPException(422,'指定された最大Nが問題の最小Nより小さいです')
    kind=spec['kind']; cases=[]
    if kind in ('integer_array','string'):
        unit=(max(len(str(spec['value_min'])),len(str(spec['value_max'])))+1) if kind=='integer_array' else 4
        # Reject pathological requests BEFORE materializing millions of Python integers.
        if req.count*hi*unit>12_000_000:
            raise HTTPException(413,'通常テストの指定件数×最大Nが大きすぎます。最大規模は専用チェックで1ケース追加してください')
    for i in range(req.count):
        typ=['min_n','max_n','all_min','all_max','all_equal','unique','alternating','sorted','reversed','random','one_duplicate','near_min','near_max'][i%13]
        n=req.force_n if req.force_n is not None else (lo if typ=='min_n' else hi if typ=='max_n' else r.randint(lo,hi))
        if not lo<=n<=hi:raise HTTPException(422,'指定Nが制約外です')
        if kind in ('tree','graph') and n>150:
            raise HTTPException(422,'グラフ・木の生成v1はN<=150まで対応です。最大Nを下げてください')
        if kind=='integer_array':
            vmin,vmax=spec['value_min'],spec['value_max']; span=vmax-vmin+1
            if typ=='all_min': a=[vmin]*n
            elif typ=='near_min': a=[min(vmax,vmin+1)]*n
            elif typ=='all_max': a=[vmax]*n
            elif typ=='near_max': a=[max(vmin,vmax-1)]*n
            elif typ=='all_equal': a=[r.randint(vmin,vmax)]*n
            elif typ=='unique': a=[vmin+j for j in range(n)] if span>=n else [vmin+(j%span) for j in range(n)]
            elif typ=='alternating': a=[vmin if j%2 else vmax for j in range(n)]
            elif typ=='one_duplicate':
                a=[vmin+j for j in range(n)] if span>=n else [vmin+(j%span) for j in range(n)]
                if n>=2:a[-1]=a[0]
            elif typ in ('sorted','reversed'):
                a=sorted([r.randint(vmin,vmax) for _ in range(n)],reverse=typ=='reversed')
            elif typ=='random':
                pool=[r.randint(vmin,vmax) for _ in range(min(n,5))]
                a=[r.choice(pool) for _ in range(n)]
            else: a=[r.randint(vmin,vmax) for _ in range(n)]
            label='unique_unavailable_value_range' if typ=='unique' and span<n else 'single_element_no_duplicate' if typ=='one_duplicate' and n<2 else typ
            cases.append(_case_record(spec,a,label))
        elif kind=='string':
            alphabet=spec['alphabet']; k=len(alphabet)
            if typ in ('all_min','all_equal','near_min'): s=alphabet[0]*n
            elif typ in ('all_max','near_max'):s=alphabet[-1]*n
            elif typ=='alternating':s=''.join(alphabet[(j%2)*(k-1)] for j in range(n))
            elif typ=='unique':s=''.join(alphabet[j%k] for j in range(n))
            elif typ=='one_duplicate':
                s=''.join(alphabet[j%k] for j in range(n))
                if n>=2:s=s[:-1]+s[0]
            elif typ in ('sorted','reversed'):
                s=''.join(sorted((r.choice(alphabet) for _ in range(n)),reverse=typ=='reversed'))
            else:s=''.join(r.choice(alphabet) for _ in range(n))
            label='unique_unavailable_alphabet' if typ=='unique' and k<n else 'single_character_alphabet' if typ=='alternating' and k<2 else 'single_element_no_duplicate' if typ=='one_duplicate' and n<2 else typ
            cases.append(_case_record(spec,s,label))
        else:
            # simple undirected/directed graph; valid for the declared structural constraints
            edges=[]; used=set(); directed=bool(spec.get('directed',False))
            def add(u,v):
                key=(u,v) if directed else tuple(sorted((u,v)))
                if u!=v and key not in used:
                    used.add(key);edges.append((u,v))
            if kind=='tree' or spec.get('connected'):
                for v in range(2,n+1):add(v,r.randint(1,v-1) if typ!='max_n' else v-1)
            if kind=='graph':
                maximum = n*(n-1) if directed else n*(n-1)//2
                lower=max(len(edges),spec['m_min']); upper=min(spec['m_max'],maximum)
                if lower>upper:raise HTTPException(422,'このNで可能な辺数がM制約と矛盾しています')
                target=upper if typ=='max_n' else lower if typ=='min_n' else r.randint(lower,upper)
                # No potentially endless rejection-sampling loop for dense graphs.
                remaining=[(u,v) for u in range(1,n+1) for v in range(1,n+1)
                           if u!=v and ((u,v) if directed else tuple(sorted((u,v)))) not in used]
                if not directed: remaining=[(u,v) for u,v in remaining if u<v]
                r.shuffle(remaining)
                for u,v in remaining[:target-len(edges)]:add(u,v)
            cases.append(_case_record(spec,(n,edges),typ))
    if req.include_large:
        if req.force_n is not None:
            raise HTTPException(422,'最大規模テストとN固定は同時に指定できません')
        if spec['n_max']>200000:
            raise HTTPException(422,'制約最大Nが200,000を超えています。現行版では最大規模を安全に生成できません')
        if kind in ('tree','graph') and spec['n_max']>150:
            raise HTTPException(422,'グラフ・木の最大規模生成は現行版ではN≤150に限定しています')
        # Request a single full-size case; other cases use the user-selected small/medium size.
        full=GenerateRequest(count=1,seed=req.seed,max_n=spec['n_max'],force_n=spec['n_max'])
        large=generate_cases(spec,full)[0]
        large['category']='constraint_max_n'
        cases.append(large)
    total_bytes=sum(len(item['input'].encode('utf-8'))+len((item['expected'] or '').encode('utf-8')) for item in cases)
    if total_bytes>8_000_000:
        raise HTTPException(413,'生成データが8MBを超えます。件数・最大Nを減らし、最大規模は専用チェックで1件だけ追加してください')
    return cases


def test_spec(problem_id:str)->dict:
    with db() as con:
        _known_problem(con,problem_id)
        row=con.execute('SELECT * FROM lab_test_specs WHERE problem_id=?',(problem_id,)).fetchone()
    if not row:return {'problem_id':problem_id,'spec':None,'status':'missing','verified_oracle':False}
    spec=json.loads(row['spec_json'])
    return {'problem_id':problem_id,'spec':spec,'status':row['status'],
            'verified_oracle':row['status']=='verified' and bool(spec.get('oracle')),'evidence':row['evidence']}


def set_spec(problem_id:str,payload:SpecEdit)->dict:
    # Setting an experimental spec always removes the verified oracle and official status.
    spec=payload.model_dump()
    with db() as con:
        _known_problem(con,problem_id)
        con.execute('''INSERT INTO lab_test_specs(problem_id,spec_json,status,evidence,updated_at)
          VALUES(?,?,?,?,?) ON CONFLICT(problem_id) DO UPDATE SET spec_json=excluded.spec_json,
          status=excluded.status,evidence=excluded.evidence,updated_at=excluded.updated_at''',
          (problem_id,json.dumps(spec,ensure_ascii=False),'user_defined','ユーザー入力（未監査）',int(time.time())))
    return test_spec(problem_id)


def reset_spec(problem_id:str)->dict:
    with db() as con:
        _known_problem(con,problem_id)
        con.execute('DELETE FROM lab_test_specs WHERE problem_id=?',(problem_id,))
    init_lab()
    return test_spec(problem_id)


def get_cases(problem_id:str,req:GenerateRequest)->dict:
    item=test_spec(problem_id)
    if not item['spec']:raise HTTPException(409,'入力仕様が未登録です。仕様を確認して登録してください')
    spec=item['spec']
    if item['status']!='verified':spec={k:v for k,v in spec.items() if k!='oracle'}
    return {'problem_id':problem_id,'status':item['status'],'seed':req.seed,
            'cases':generate_cases(spec,req)}


def shrink_cases(problem_id:str,raw:str)->dict:
    item=test_spec(problem_id)
    if not item['spec']:raise HTTPException(409,'入力仕様が未登録です')
    spec=item['spec']; kind=spec['kind']
    if kind not in ('integer_array','string'):
        raise HTTPException(422,'反例縮小v1は整数列・文字列の入力形式のみ対応です')
    try: contents=_parse_case(spec,raw)
    except (ValueError,IndexError) as ex: raise HTTPException(422,str(ex)) from ex
    n=len(contents);lo=spec['n_min']; options=[]; seen={raw.strip()}
    def add(data,reason):
        try:
            candidate=_case_record(spec,data,reason)
            _parse_case(spec,candidate['input'])
        except (ValueError,IndexError):return
        key=candidate['input'].strip()
        if key not in seen and len(candidate['input'])<=len(raw):
            seen.add(key);options.append(candidate)
    # Prefix/suffix/blocks; shrinking only when structure remains valid.
    for block in sorted({max(1,n//2),max(1,n//4),1},reverse=True):
        for start in sorted({0,max(0,(n-block)//2),n-block}):
            if start<0 or n-block<lo:continue
            add(contents[:start]+contents[start+block:],f'要素[{start}:{start+block}]を削除')
    if kind=='integer_array':
        for i in sorted({0,n//2,n-1}):
            for value in (spec['value_min'], 0, 1, contents[0]):
                if spec['value_min']<=value<=spec['value_max'] and contents[i]!=value:
                    a=contents[:];a[i]=value;add(a,f'位置{i}を{value}に変更')
    else:
        for i in sorted({0,n//2,n-1}):
            if contents[i]!=spec['alphabet'][0]:
                a=list(contents);a[i]=spec['alphabet'][0];add(''.join(a),f'文字{i}を最初の文字へ')
    return {'cases':options[:30], 'note':'各候補について元の不一致が再現するか、ブラウザで再実行してください。'}


def problem_links(problem_id:str)->dict:
    with db() as con:
        _known_problem(con,problem_id)
        links=[dict(x) for x in con.execute('''SELECT l.*,k.heading FROM lab_problem_knowledge l
                 JOIN knowledge_sections k ON k.anchor=l.anchor WHERE l.problem_id=?
                 ORDER BY CASE l.role WHEN 'essential' THEN 0 WHEN 'supporting' THEN 1 ELSE 2 END,l.contribution DESC''',(problem_id,))]
        tags=[x['tag'] for x in con.execute('SELECT DISTINCT tag FROM tags WHERE problem_id=?',(problem_id,))]
        guesses=[];seen={x['anchor'] for x in links}
        for tag in tags:
            for row in con.execute('''SELECT l.anchor,k.heading,l.source FROM knowledge_tag_links l
                      JOIN knowledge_sections k ON k.anchor=l.anchor WHERE l.tag=? ORDER BY l.rank LIMIT 3''',(tag,)):
                if row['anchor'] not in seen:
                    guesses.append({'anchor':row['anchor'],'heading':row['heading'],'tag':tag,'status':'candidate',
                                    'role':None,'contribution':None,'source':row['source']})
                    seen.add(row['anchor'])
    return {'links':links,'candidates':guesses[:25],
            'note':'候補はタグの機械的対応です。レビューするまで習熟度や推薦に使用しません。'}


def set_problem_link(problem_id:str,payload:LinkEdit)->dict:
    with db() as con:
        _known_problem(con,problem_id);_known_anchor(con,payload.anchor)
        old=con.execute('SELECT status FROM lab_problem_knowledge WHERE problem_id=? AND anchor=?',
                        (problem_id,payload.anchor)).fetchone()
        if old and old['status']=='verified':
            raise HTTPException(409,'検証済みの組は上書きできません。別途監査で修正してください')
        con.execute('''INSERT INTO lab_problem_knowledge(problem_id,anchor,role,contribution,status,evidence,updated_at)
          VALUES(?,?,?,?,?,?,?) ON CONFLICT(problem_id,anchor) DO UPDATE SET role=excluded.role,
          contribution=excluded.contribution,status=excluded.status,evidence=excluded.evidence,updated_at=excluded.updated_at''',
          (problem_id,payload.anchor,payload.role,payload.contribution,'user_reviewed',payload.evidence,int(time.time())))
    return problem_links(problem_id)


def get_prerequisites(anchor:str)->dict:
    with db() as con:
        _known_anchor(con,anchor)
        rows=[dict(x) for x in con.execute('''SELECT p.prerequisite,k.heading,p.status,p.evidence
             FROM lab_prerequisites p JOIN knowledge_sections k ON k.anchor=p.prerequisite
             WHERE p.anchor=? ORDER BY k.heading''',(anchor,))]
    return {'anchor':anchor,'prerequisites':rows}


def set_prerequisite(payload:PrerequisiteEdit)->dict:
    with db() as con:
        _known_anchor(con,payload.anchor);_known_anchor(con,payload.prerequisite)
        if payload.anchor==payload.prerequisite:raise HTTPException(422,'自己循環は登録できません')
        # Reachability from prerequisite back to anchor would create a cycle.
        edges=con.execute('SELECT anchor,prerequisite FROM lab_prerequisites').fetchall()
        graph=defaultdict(list)
        for x in edges:graph[x['anchor']].append(x['prerequisite'])
        seen=set();todo=[payload.prerequisite]
        while todo:
            v=todo.pop()
            if v==payload.anchor:raise HTTPException(422,'前提知識の循環が発生します')
            if v not in seen:
                seen.add(v);todo.extend(graph[v])
        existing=con.execute('SELECT status FROM lab_prerequisites WHERE anchor=? AND prerequisite=?',
                             (payload.anchor,payload.prerequisite)).fetchone()
        if existing and existing['status']=='verified':raise HTTPException(409,'検証済みの前提は上書きできません')
        con.execute('INSERT INTO lab_prerequisites(anchor,prerequisite,status,evidence) VALUES(?,?,?,?)',
                    (payload.anchor,payload.prerequisite,'user_reviewed',payload.evidence)) if not existing else None
    return get_prerequisites(payload.anchor)


def audit_report()->dict:
    with db() as con:
        total=con.execute('SELECT COUNT(*) FROM problems').fetchone()[0]
        knowledge_count=con.execute("SELECT COUNT(*) FROM knowledge_sections WHERE anchor LIKE 'sec-%'").fetchone()[0]
        tagged=con.execute('SELECT COUNT(DISTINCT problem_id) FROM tags').fetchone()[0]
        reviewed=con.execute('SELECT COUNT(DISTINCT problem_id) FROM lab_problem_knowledge').fetchone()[0]
        verified=con.execute("SELECT COUNT(DISTINCT problem_id) FROM lab_problem_knowledge WHERE status='verified'").fetchone()[0]
        specs=con.execute('SELECT status,COUNT(*) AS n FROM lab_test_specs GROUP BY status').fetchall()
        candidates=con.execute("SELECT COUNT(*) FROM knowledge_tag_links WHERE source='fallback'").fetchone()[0]
        bad=[dict(x) for x in con.execute('''SELECT l.tag,l.anchor FROM knowledge_tag_links l
                 LEFT JOIN knowledge_sections k ON k.anchor=l.anchor WHERE k.anchor IS NULL LIMIT 30''')]
        no_links=[x[0] for x in con.execute('''SELECT DISTINCT t.tag FROM tags t LEFT JOIN knowledge_tag_links l ON l.tag=t.tag
                 WHERE l.anchor IS NULL ORDER BY t.tag LIMIT 30''')]
        link_status=[dict(x) for x in con.execute('SELECT status,COUNT(*) AS n FROM lab_problem_knowledge GROUP BY status')]
        example_count=0; example_failures=[]
        for pid,spec in CURATED_SPECS.items():
            try:
                actual=_oracle(spec,spec['sample_input'])
                if actual==spec['sample_output']:example_count+=1
                else:example_failures.append({'problem_id':pid,'expected':spec['sample_output'],'actual':actual})
            except Exception as ex:example_failures.append({'problem_id':pid,'error':str(ex)})
    return {'problems_total':total,'knowledge_topics':knowledge_count,'tagged_problems':tagged,
            'reviewed_problem_links':reviewed,'verified_problems':verified,'problems_pending_review':max(0,total-reviewed),
            'test_specs':{r['status']:r['n'] for r in specs},'fallback_tag_links':candidates,
            'dangling_knowledge_links':bad,'unlinked_tags_sample':no_links,'link_status':link_status,
            'official_sample_oracle_passed':example_count,'official_sample_oracle_failures':example_failures,
            'limitations':['タグリンクの存在は意味的な正確性を証明しません。',
             '3問の公式例＋専用オラクルのみ確認。他の問題には正解を自動生成しません。',
             'Atlasの293トピックとDBの補足を含むsec-*見出し数は一致しません。全トピックの任意コード実行は未検証です。']}


def record_event(user_id:str,payload:EventInput)->dict:
    validate_user_id(user_id)
    body=payload.payload
    if payload.kind in ('hint_used','editorial_viewed','technique_used','failure','reflection','ac_review','quiz','review','test_failure') and not payload.problem_id and not payload.anchor:
        raise HTTPException(422,'問題IDまたはKnowledge IDを指定してください')
    if payload.kind=='hint_used':
        raise HTTPException(422,'ヒント開示と問題別DB記録は /api/lab/problems/{problem_id}/hints を使用してください')
    if payload.kind=='failure' and body.get('code') not in [f'K{i}' for i in range(1,9)]:
        raise HTTPException(422,'失敗原因はK1〜K8から選んでください')
    if payload.kind in ('reflection','ac_review'):
        for key in ('idea','implementation','complexity'):
            if key in body and (type(body[key]) is not int or not 0<=body[key]<=2):
                raise HTTPException(422,'自己評価は0〜2です')
    if payload.kind in ('quiz','review') and not body.get('graded_by_server'):
        raise HTTPException(422,'クイズ結果は採点用APIから登録してください')
    with db() as con:
        if payload.problem_id:_known_problem(con,payload.problem_id)
        if payload.anchor:_known_anchor(con,payload.anchor)
        con.execute('INSERT INTO lab_events(user_id,problem_id,anchor,kind,payload_json,recorded_at) VALUES(?,?,?,?,?,?)',
                    (user_id,payload.problem_id,payload.anchor,payload.kind,json.dumps(body,ensure_ascii=False),int(time.time())))
    return {'ok':True}


def get_events(user_id:str,problem_id:str|None=None,limit:int=80)->list[dict]:
    validate_user_id(user_id)
    with db() as con:
        if problem_id:
            _known_problem(con,problem_id)
            rows=con.execute('''SELECT * FROM lab_events WHERE user_id=? AND problem_id=? ORDER BY id DESC LIMIT ?''',
                             (user_id,problem_id,limit))
        else:rows=con.execute('SELECT * FROM lab_events WHERE user_id=? ORDER BY id DESC LIMIT ?', (user_id,limit))
        return [{**dict(x),'payload':json.loads(x['payload_json'])} for x in rows]


def available_quizzes(anchor:str)->list[dict]:
    with db() as con:_known_anchor(con,anchor)
    return [{k:v for k,v in q.items() if k not in ('answer',)} for q in QUIZZES.get(anchor,[])]


def _update_review(con,user_id:str,anchor:str,correct:bool,now:int)->dict:
    row=con.execute('SELECT stage FROM lab_reviews WHERE user_id=? AND anchor=?',(user_id,anchor)).fetchone()
    stage=(min(5,row['stage']+1) if row else 1) if correct else 0
    # Failure: next day; successes: 1,3,7,14,30 days.
    days=[1,1,3,7,14,30][stage]
    due=now+days*86400
    con.execute('''INSERT INTO lab_reviews(user_id,anchor,stage,due_at,last_result,updated_at)
        VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,anchor) DO UPDATE SET stage=excluded.stage,
        due_at=excluded.due_at,last_result=excluded.last_result,updated_at=excluded.updated_at''',
        (user_id,anchor,stage,due,int(correct),now))
    return {'stage':stage,'due_at':due,'correct':correct}


def answer_quiz(user_id:str,anchor:str,quiz_id:str,answer:QuizAnswer)->dict:
    validate_user_id(user_id)
    quiz=next((q for q in QUIZZES.get(anchor,[]) if q['id']==quiz_id),None)
    if not quiz:raise HTTPException(404,'採点可能なクイズがありません')
    if answer.problem_id:
        with db() as con:_known_problem(con,answer.problem_id)
    correct=answer.answer==quiz['answer'];now=int(time.time())
    with db() as con:
        _known_anchor(con,anchor)
        # never trust client-provided grade.
        con.execute('INSERT INTO lab_events(user_id,problem_id,anchor,kind,payload_json,recorded_at) VALUES(?,?,?,?,?,?)',
            (user_id,answer.problem_id,anchor,'quiz',json.dumps({'quiz_id':quiz_id,'answer':answer.answer,
                 'correct':correct,'graded_by_server':True},ensure_ascii=False),now))
        review=_update_review(con,user_id,anchor,correct,now)
    return {'correct':correct,'correct_answer':quiz['answer'],'explanation':quiz['explanation'],'review':review}


def mastery(user_id:str)->dict:
    validate_user_id(user_id)
    with db() as con:
        events=con.execute('SELECT * FROM lab_events WHERE user_id=? AND anchor IS NOT NULL ORDER BY id',(user_id,)).fetchall()
        review_rows=con.execute('''SELECT r.*, k.heading FROM lab_reviews r JOIN knowledge_sections k ON k.anchor=r.anchor
                     WHERE r.user_id=? ORDER BY r.due_at''',(user_id,)).fetchall()
        headings={r['anchor']:r['heading'] for r in con.execute('SELECT anchor,heading FROM knowledge_sections')}
    scores=defaultdict(lambda:{'idea':[],'implementation':[],'complexity':[],'retention':[],
                              'evidence_count':0,'quiz_count':0,'self_reports':0,'hints':0})
    for e in events:
        anchor=e['anchor'];s=scores[anchor];body=json.loads(e['payload_json']);kind=e['kind']
        if kind in ('reflection','ac_review'):
            s['self_reports']+=1
            for domain in ('idea','implementation','complexity'):
                if domain in body:s[domain].append(float(body[domain])/2)
        if kind=='quiz':
            # A quiz is evidence of a narrow concept check, not full mastery.
            s['quiz_count']+=1;s['retention'].append(float(bool(body['correct'])))
        if kind=='hint_used':s['hints']+=1
        if kind=='technique_used':s['implementation'].append(.5) # used: not necessarily independently implemented
        if kind=='failure':
            for domain in {'K1':['idea'],'K2':['idea'],'K3':['complexity'],'K5':['implementation'],'K6':['implementation'],'K7':['implementation']}.get(body.get('code'),[]):
                s[domain].append(0.)
        s['evidence_count']+=1
    rows=[]
    for anchor,s in scores.items():
        domain={k:round(sum(s[k])/len(s[k]),2) if s[k] else None for k in ('idea','implementation','complexity','retention')}
        rows.append({'anchor':anchor,'heading':headings.get(anchor,anchor),'domains':domain,
                     'evidence_count':s['evidence_count'],'quiz_count':s['quiz_count'],
                     'self_reports':s['self_reports'],'hints':s['hints'],
                     'confidence':'limited' if s['quiz_count']<2 else 'moderate',
                     'note':'自己評価と短いクイズの暫定指標。自動で習得済みとは判定しません。'})
    rows.sort(key=lambda x: x['heading'])
    reviews=[dict(x) for x in review_rows]
    now=int(time.time())
    return {'knowledge':rows,'reviews':reviews,'due':[x for x in reviews if x['due_at']<=now],
            'note':'提出ACだけを根拠に知識を習得済みとはしません。評価値は公式の難易度指標ではありません。'}


def lab_recommendations(user_id:str,limit:int=30)->list[dict]:
    from .service import get_recommendations
    base=get_recommendations(user_id,200)
    master=mastery(user_id)['knowledge']
    observed={x['anchor']:x for x in master}
    with db() as con:
        links=defaultdict(list)
        for x in con.execute("SELECT * FROM lab_problem_knowledge WHERE status IN ('verified','user_reviewed')"):
            links[x['problem_id']].append(dict(x))
    result=[]
    for row in base:
        if row['is_ac']:continue
        score=float(row['recommendation_score']); reasons=list(row['recommendation_reasons'])
        for l in links[row['problem_id']]:
            metric=observed.get(l['anchor'])
            if not metric:continue
            values=[v for v in metric['domains'].values() if v is not None]
            if not values:continue
            shortfall=max(0.,1.-sum(values)/len(values))
            boost=shortfall*l['contribution']*.4
            score+=boost
            if boost>0.5:reasons.append('確認済み対応Knowledgeの復習候補: '+metric['heading'])
        item=dict(row);item['recommendation_score']=round(score,3);item['recommendation_reasons']=reasons
        result.append(item)
    result.sort(key=lambda x:(not bool(x.get('transfer_review_reasons')), -x['recommendation_score'],x['contest_number'],x['problem_index']))
    return result[:limit]


def search_feedback(user_id:str,payload:Feedback)->dict:
    validate_user_id(user_id)
    with db() as con:
        _known_anchor(con,payload.anchor)
        con.execute('INSERT INTO lab_search_feedback(user_id,query,anchor,helpful,recorded_at) VALUES(?,?,?,?,?)',
                   (user_id,payload.query,payload.anchor,int(payload.helpful),int(time.time())))
    return {'ok':True,'note':'フィードバックは記録しました。ランキングへの自動学習反映は未実装です。'}

# Optional extensions: local templates and extractive source-backed question lookup.
EXTRA_LAB_SCHEMA = """
CREATE TABLE IF NOT EXISTS lab_templates (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id TEXT NOT NULL,
 anchor TEXT NOT NULL,
 label TEXT NOT NULL,
 code TEXT NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lab_templates ON lab_templates(user_id,anchor,created_at);
"""

class TemplateInput(BaseModel):
    anchor: str = Field(min_length=1,max_length=120)
    label: str = Field(min_length=1,max_length=100)
    code: str = Field(min_length=1,max_length=40000)

class LocalQuestion(BaseModel):
    question: str = Field(min_length=2,max_length=500)


def init_lab_extensions() -> None:
    with db() as con:
        con.executescript(EXTRA_LAB_SCHEMA)


def save_template(user_id: str, item: TemplateInput) -> dict:
    validate_user_id(user_id)
    with db() as con:
        _known_anchor(con,item.anchor)
        cur=con.execute('INSERT INTO lab_templates(user_id,anchor,label,code,created_at) VALUES(?,?,?,?,?)',
                    (user_id,item.anchor,item.label,item.code,int(time.time())))
        return {'id':cur.lastrowid,'ok':True,'note':'履歴として新規保存しました。既存の版は上書きしません。'}


def templates(user_id: str,anchor:str|None=None) -> list[dict]:
    validate_user_id(user_id)
    with db() as con:
        if anchor:
            _known_anchor(con,anchor)
            rows=con.execute('SELECT * FROM lab_templates WHERE user_id=? AND anchor=? ORDER BY id DESC LIMIT 80',(user_id,anchor))
        else:
            rows=con.execute('SELECT * FROM lab_templates WHERE user_id=? ORDER BY id DESC LIMIT 80',(user_id,))
        return [dict(r) for r in rows]


def delete_template(user_id:str,template_id:int)->dict:
    validate_user_id(user_id)
    with db() as con:
        result=con.execute('DELETE FROM lab_templates WHERE user_id=? AND id=?',(user_id,template_id))
        if not result.rowcount:raise HTTPException(404,'このユーザーのテンプレートが見つかりません')
    return {'ok':True}


def source_question(question:str)->dict:
    """Search local Knowledge text; quote actual passages only. Not a generative LLM."""
    import unicodedata
    q=unicodedata.normalize('NFKC',question).strip()
    ascii_words=re.findall(r'[A-Za-z][A-Za-z0-9_-]{1,30}',q)
    kanji_chunks=re.findall(r'[一-龠ぁ-んァ-ヶ]{2,}',q)
    tokens=[x.casefold() for x in ascii_words]+kanji_chunks
    # Japanese compounds need character bigrams when the user writes new phrasing.
    chars=''.join(kanji_chunks)
    tokens+=list(dict.fromkeys(chars[i:i+2] for i in range(len(chars)-1)))
    with db() as con:
        rows=con.execute("SELECT anchor,heading,body_markdown FROM knowledge_sections WHERE anchor LIKE 'sec-%'").fetchall()
    candidates=[]
    for row in rows:
        heading=row['heading'];body=row['body_markdown']
        # Paragraph-sized evidence rather than entire documents with universal wording.
        paragraphs=[re.sub(r'[`*_#<>]','',p).strip() for p in re.split(r'\n\s*\n',body)]
        paragraphs=[p for p in paragraphs if 25<=len(p)<=1100 and not p.startswith('```')]
        if not paragraphs:continue
        best=max(paragraphs,key=lambda p:sum((5 if t in heading.casefold() else 1) for t in tokens if t in p.casefold()))
        score=sum((5 if t in heading.casefold() else 1) for t in tokens if t in best.casefold())
        if score>=2:candidates.append({'anchor':row['anchor'],'heading':heading,
                    'passage':best[:750],'score':score,'source':'backend/data/knowledge_tag_supplement.md' if row['anchor'].startswith('sec-37-') else 'backend/data/knowledge_guide.md'})
    candidates.sort(key=lambda x:(-x['score'],-len(x['heading'])))
    return {'question':question,'evidence':candidates[:5],
            'answer':'該当する資料の抜粋を表示します。資料に根拠がない場合は回答を生成しません。' if candidates else '一致する根拠を確認できませんでした。',
            'mode':'extractive_not_generative'}


def similar_problems(problem_id:str,limit:int=15)->dict:
    with db() as con:
        _known_problem(con,problem_id)
        selected=[dict(x) for x in con.execute("SELECT anchor,role FROM lab_problem_knowledge WHERE problem_id=? AND status IN ('verified','user_reviewed')",(problem_id,))]
        related=[]
        if selected:
            anchors={r['anchor'] for r in selected}
            for item in con.execute('''SELECT l.problem_id,p.title,l.anchor,l.status FROM lab_problem_knowledge l
                  JOIN problems p ON p.problem_id=l.problem_id WHERE l.problem_id<>? AND l.status IN ('verified','user_reviewed')''',(problem_id,)):
                if item['anchor'] in anchors:
                    related.append({'problem_id':item['problem_id'],'title':item['title'],
                                    'evidence':item['anchor'],'status':'reviewed_knowledge_overlap'})
        else:
            tags={r[0] for r in con.execute('SELECT tag FROM tags WHERE problem_id=?',(problem_id,))}
            if tags:
                scored=[]
                for row in con.execute('SELECT p.problem_id,p.title,t.tag FROM problems p JOIN tags t ON t.problem_id=p.problem_id WHERE p.problem_id<>?',(problem_id,)):
                    if row['tag'] in tags:scored.append((row['problem_id'],row['title'],row['tag']))
                related=[{'problem_id':pid,'title':title,'evidence':tag,'status':'unverified_tag_overlap'} for pid,title,tag in scored]
    unique={r['problem_id']:r for r in related}
    return {'problem_id':problem_id,'problems':list(unique.values())[:limit],
            'note':'同じ知識リンクまたはタグを持つ候補です。問題の標準解法が同じである保証はありません。'}


VERIFIED_CODE_FIXTURES = [
 ('sec-1-3', 'A=[1,2,1]\nprint(len(set(A)) == len(A))', 'False'),
 ('sec-1-4', 'from collections import Counter\nprint(Counter([1,1,2])[1])', '2'),
 ('sec-4-1', 'A=[3,1,4,1,5]\np=[0]\nfor x in A: p.append(p[-1]+x)\nprint(p[4]-p[1])', '6'),
 ('sec-7-2', 'from collections import deque\ng=[[1,2],[0,3],[0],[1]]\nd=[-1]*4\nd[0]=0\nq=deque([0])\nwhile q:\n v=q.popleft()\n for nv in g[v]:\n  if d[nv]<0:d[nv]=d[v]+1;q.append(nv)\nprint(d)', '[0, 1, 1, 2]'),
 ('sec-10-1', 'a=[3,1,4,1,5]\nb=[0]*6\nfor i,x in enumerate(a,1):\n j=i\n while j<6:b[j]+=x;j+=j&-j\ndef pre(r):\n s=0\n while r:s+=b[r];r-=r&-r\n return s\nprint(pre(4)-pre(1))', '6'),
]


def audit_code_fixtures()->dict:
    """Execute only allowlisted constant code, never user-authored code, in a subprocess."""
    import ast
    import subprocess
    import sys
    ok=0;errors=[]
    for anchor,code,expected in VERIFIED_CODE_FIXTURES:
        try:
            ast.parse(code)
            run=subprocess.run([sys.executable,'-I','-c',code],capture_output=True,text=True,timeout=6)
            if run.returncode==0 and run.stdout.strip()==expected:
                ok+=1
            else:errors.append({'anchor':anchor,'message':(run.stderr or 'unexpected output')[:250]})
        except (SyntaxError, subprocess.TimeoutExpired) as exc:errors.append({'anchor':anchor,'message':str(exc)[:250]})
    # Syntax scanning of source snippets is deliberately reported separately from execution.
    with db() as con:
        sections=con.execute("SELECT anchor,body_markdown FROM knowledge_sections WHERE anchor LIKE 'sec-%' AND level=2").fetchall()
    inspected=0;syntax_ok=0;invalid=[]
    for section in sections:
        for source in re.findall(r'```python\s*\n(.*?)\n```',section['body_markdown'],re.S|re.I):
            inspected+=1
            try:ast.parse(source);syntax_ok+=1
            except SyntaxError as exc:
                if len(invalid)<30:invalid.append({'anchor':section['anchor'],'line':exc.lineno,'message':exc.msg})
    return {'allowlisted_examples':len(VERIFIED_CODE_FIXTURES),'passed':ok,'failures':errors,
        'source_python_snippets':inspected,'syntax_parse_passed':syntax_ok,
        'syntax_failures_sample':invalid,
        'limitation':'資料のコードは構文解析と5つの独立した固定サンプルのみ確認。構文が正しくても実行可能・正答とは限りません。'}
