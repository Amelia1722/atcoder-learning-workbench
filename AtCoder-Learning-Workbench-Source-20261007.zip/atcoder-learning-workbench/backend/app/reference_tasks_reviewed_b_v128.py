"""ABC242–244 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re
from collections import Counter

TASKS = ('abc242_b', 'abc243_b', 'abc244_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)
SR = re.compile(r'[SR]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc242_b': [
        {'input': 'aba\n', 'expected': 'aab\n'},
        {'input': 'zzzz\n', 'expected': 'zzzz\n'},
    ],
    'abc243_b': [
        {'input': '4\n1 3 5 2\n2 3 1 4\n', 'expected': '1\n2\n'},
        {'input': '3\n1 2 3\n4 5 6\n', 'expected': '0\n0\n'},
        {'input': '7\n4 8 1 7 9 5 6\n3 5 1 7 8 2 6\n', 'expected': '3\n2\n'},
    ],
    'abc244_b': [
        {'input': '4\nSSRS\n', 'expected': '2 -1\n'},
        {'input': '20\nSRSRSSRSSSRSRRRRRSRR\n', 'expected': '0 1\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _row(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate242(raw: str) -> str:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or LOWER.fullmatch(lines[0]) is None:
        raise ValueError('shape/S')
    s = lines[0]
    if not 1 <= len(s) <= 200_000:
        raise ValueError('len')
    return s


def _validate243(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 3 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 1000:
        raise ValueError('N')
    a = _row(lines[1], n); b = _row(lines[2], n)
    if any(not 1 <= x <= 10**9 for x in a+b):
        raise ValueError('range')
    if len(set(a)) != n or len(set(b)) != n:
        raise ValueError('distinct')
    return n, tuple(a), tuple(b)


def _validate244(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0]); t = lines[1]
    if not 1 <= n <= 100_000 or len(t) != n or SR.fullmatch(t) is None:
        raise ValueError('N/T')
    return n, t


def validate(pid: str, raw: str):
    if pid == 'abc242_b': return _validate242(raw)
    if pid == 'abc243_b': return _validate243(raw)
    if pid == 'abc244_b': return _validate244(raw)
    raise ValueError('unknown task')


def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value = validate(pid, raw)
    except (ValueError, TypeError, IndexError): return False
    if not isinstance(output, str) or not output or output != output.strip(): return False
    if pid == 'abc242_b':
        s = value
        c = Counter(s)
        expected = ''.join(chr(code) * c.get(chr(code), 0) for code in range(ord('a'), ord('z')+1))
        return output == expected
    if pid == 'abc243_b':
        n,a,b = value
        pos = {x:i for i,x in enumerate(a)}
        exact = sum(a[i] == b[i] for i in range(n))
        wrong = sum(x in pos and pos[x] != i for i,x in enumerate(b))
        return output == f'{exact}\n{wrong}'
    n,t = value
    x=y=0; dx,dy=1,0
    for ch in t:
        if ch == 'S': x,y = x+dx,y+dy
        else: dx,dy = dy,-dx
    return output == f'{x} {y}'


def _case243(a: list[int], b: list[int]) -> str:
    return f'{len(a)}\n' + ' '.join(map(str,a)) + '\n' + ' '.join(map(str,b)) + '\n'

def _case244(t: str) -> str: return f'{len(t)}\n{t}\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(category, raw):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); out.append({'category':category,'input':raw})
    for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}', row['input'])
    if pid == 'abc242_b':
        cases=[
            ('single_a','a\n'),('single_z','z\n'),('reverse_alpha','zyxwvutsrqponmlkjihgfedcba\n'),
            ('already_sorted','aabbccddeeff\n'),('all_same','mmmmmmmm\n'),('mixed','competitiveprogramming\n'),
            ('many_a_z','zzzzaaaa\n'),('palindromeish','abccba\n'),('alphabet','abcdefghijklmnopqrstuvwxyz\n'),
            ('alphabet_twice','abcdefghijklmnopqrstuvwxyz'*2+'\n'),('descending_repeat','cba'*100+'\n'),
            ('large_two_chars','b'*1000+'a'*1000+'\n'),('large_pattern','qwerty'*1000+'\n'),
            ('near_max','z'*199999+'\n'),('max_two_halves','z'*100000+'a'*100000+'\n')]
        for c,r in cases: add(c,r)
        add('constraint_max','z'*200000+'\n')
    elif pid == 'abc243_b':
        cases=[
            ('single_same',_case243([1],[1])),('single_diff',_case243([1],[2])),
            ('all_exact',_case243([1,2,3,4],[1,2,3,4])),('all_wrong_positions',_case243([1,2,3,4],[2,3,4,1])),
            ('partial_overlap',_case243([10,20,30,40,50],[10,30,70,80,20])),
            ('no_overlap_large',_case243([10**9,999999999],[1,2])),('reversed',_case243(list(range(1,11)),list(range(10,0,-1)))),
            ('one_exact_rest_absent',_case243([1,2,3,4,5],[6,2,7,8,9])),
            ('one_wrong',_case243([1,2,3],[4,1,5])),('n100_rotation',_case243(list(range(1,101)),list(range(2,101))+[1])),
            ('n100_disjoint',_case243(list(range(1,101)),list(range(1001,1101)))),
            ('n500_half_overlap',_case243(list(range(1,501)),list(range(251,751)))),
            ('n999_all_exact',_case243(list(range(1,1000)),list(range(1,1000)))),
            ('n1000_reverse',_case243(list(range(1,1001)),list(range(1000,0,-1))))]
        for c,r in cases: add(c,r)
        add('constraint_max',_case243(list(range(1,1001)), list(range(999999001,1000000001))))
    else:
        cases=[
            ('single_s',_case244('S')),('single_r',_case244('R')),('four_turns',_case244('RRRR')),
            ('all_straight',_case244('S'*10)),('south',_case244('RS'*5)),('square',_case244('SRSRSRSR')),
            ('turn_then_move',_case244('RRSSS')),('mixed_short',_case244('SRRSRSSR')),
            ('many_turns',_case244('R'*99+'S')),('alternating',_case244('SR'*50)),
            ('cycle_blocks',_case244('SSRSSRSSRR'*100)),('long_straight',_case244('S'*1000)),
            ('long_turns',_case244('R'*1000)),('large_pattern',_case244('SSRSR'*10000)),
            ('near_max',_case244('S'*99999))]
        for c,r in cases: add(c,r)
        add('constraint_max',_case244('SR'*50000))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
