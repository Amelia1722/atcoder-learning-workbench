"""ABC197–199 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc197_b','abc198_b','abc199_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NONNEG=re.compile(r'0|[1-9][0-9]*',re.ASCII)

PUBLISHED_SAMPLES={
 'abc197_b':[
  {'input':'4 4 2 2\n##..\n...#\n#.#.\n.#.#\n','expected':'4\n'},
  {'input':'3 5 1 4\n#....\n#####\n....#\n','expected':'4\n'},
  {'input':'5 5 4 2\n.#..#\n#.###\n##...\n#..#.\n#.###\n','expected':'3\n'},
 ],
 'abc198_b':[
  {'input':'1210\n','expected':'Yes\n'},
  {'input':'777\n','expected':'Yes\n'},
  {'input':'123456789\n','expected':'No\n'},
 ],
 'abc199_b':[
  {'input':'2\n3 2\n7 5\n','expected':'3\n'},
  {'input':'3\n1 5 3\n10 7 3\n','expected':'0\n'},
  {'input':'3\n3 2 5\n6 9 8\n','expected':'2\n'},
 ],
}

def _ints(line:str,count:int,allow_zero:bool=False)->list[int]:
    p=line.split(' ')
    pat=NONNEG if allow_zero else POS
    if len(p)!=count or any(pat.fullmatch(x) is None for x in p): raise ValueError('noncanonical integer row')
    return list(map(int,p))

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc197_b':
        if not lines: raise ValueError('shape')
        h,w,x,y=_ints(lines[0],4)
        if not (1<=h<=100 and 1<=w<=100 and 1<=x<=h and 1<=y<=w) or len(lines)!=h+1: raise ValueError('range/shape')
        g=lines[1:]
        if any(len(row)!=w or any(c not in '.#' for c in row) for row in g): raise ValueError('grid')
        if g[x-1][y-1]!='.': raise ValueError('start blocked')
        return h,w,x-1,y-1,g
    if pid=='abc198_b':
        if len(lines)!=1 or NONNEG.fullmatch(lines[0]) is None: raise ValueError('integer syntax')
        n=int(lines[0])
        if n>10**9: raise ValueError('range')
        return n
    if len(lines)!=3 or POS.fullmatch(lines[0]) is None: raise ValueError('shape/N')
    n=int(lines[0])
    if not 1<=n<=100: raise ValueError('N range')
    a=_ints(lines[1],n); b=_ints(lines[2],n)
    if any(not (1<=x<=y<=1000) for x,y in zip(a,b)): raise ValueError('interval range')
    return a,b

def _ans197(v):
    h,w,x,y,g=v; ans=1
    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
        i,j=x+dx,y+dy
        while 0<=i<h and 0<=j<w and g[i][j]=='.':
            ans+=1; i+=dx; j+=dy
    return ans

def _ans198(n:int)->str:
    s=str(n).rstrip('0')
    return 'Yes' if s==s[::-1] else 'No'

def _ans199(v)->int:
    a,b=v; lo=max(a); hi=min(b)
    return max(0,hi-lo+1)

def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or '\n' in output or output!=output.strip(): return False
    if pid=='abc197_b': return POS.fullmatch(output) is not None and int(output)==_ans197(v)
    if pid=='abc198_b': return output in ('Yes','No') and output==_ans198(v)
    return NONNEG.fullmatch(output) is not None and int(output)==_ans199(v)

def _grid(h,w,x,y,g): return f'{h} {w} {x} {y}\n'+'\n'.join(g)+'\n'
def _199(a,b): return f'{len(a)}\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n'

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc197_b':
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        cases=[
          ('single',_grid(1,1,1,1,['.'])),
          ('row_open',_grid(1,5,1,3,['.....'])),
          ('row_blocked',_grid(1,5,1,3,['.#.#.'])),
          ('col_open',_grid(5,1,3,1,['.','.','.','.','.'])),
          ('col_blocked',_grid(5,1,3,1,['.','#','.','#','.'])),
          ('corner_open',_grid(4,4,1,1,['....']*4)),
          ('corner_walls',_grid(4,4,1,1,['.#..','##..','....','....'])),
          ('center_open',_grid(5,5,3,3,['.....']*5)),
          ('center_near_walls',_grid(5,5,3,3,['.....','..#..','.#.#.','..#..','.....'])),
          ('wide',_grid(2,100,1,50,['.'*100,'#'*100])),
          ('tall',_grid(100,2,50,1,['..']*100)),
          ('checker',_grid(9,9,5,5,[''.join('.' if (i+j)%2==0 else '#' for j in range(9)) for i in range(9)])),
          ('edges',_grid(3,7,2,4,['###.###','.......','###.###'])),
          ('mixed20',_grid(20,20,10,10,['.'*20 for _ in range(20)])),
        ]
        for c,raw in cases:add(c,raw)
        g=['.'*100 for _ in range(100)]; add('constraint_max',_grid(100,100,50,50,g))
    elif pid=='abc198_b':
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        for c,n in [
          ('zero',0),('one',1),('ten',10),('hundred',100),('pal_even',1221),('pal_odd',12321),
          ('needs_two_zeros',1200),('no_after_trim',1230),('internal_zero',1001),('many_trailing',100000000),
          ('near_max_yes',999999999),('near_max_no',999999998),('leading_pattern',1001000),('two_digit_no',12),
        ]: add(c,f'{n}\n')
        add('constraint_max','1000000000\n')
    else:
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        cases=[
          ('n1_single',_199([1],[1])),('n1_wide',_199([1],[1000])),('touch',_199([5,1],[10,5])),
          ('empty_by_one',_199([6,1],[10,5])),('all_same',_199([500]*5,[500]*5)),
          ('nested',_199([1,2,3,4],[1000,900,800,700])),('lo1000',_199([1000,999],[1000,1000])),
          ('hi1',_199([1,1],[1,2])),('n10_overlap',_199(list(range(1,11)),[20]*10)),
          ('n10_empty',_199([10]*9+[20],[15]*9+[20])),('boundary_full',_199([1]*20,[1000]*20)),
          ('single_point_mid',_199([1,500,400],[700,500,900])),('stagger',_199([100,200,300],[800,700,600])),
          ('n99',_199([i%1000+1 for i in range(99)],[1000]*99)),
        ]
        for c,raw in cases:add(c,raw)
        add('constraint_max',_199([1]*100,[1000]*100))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
