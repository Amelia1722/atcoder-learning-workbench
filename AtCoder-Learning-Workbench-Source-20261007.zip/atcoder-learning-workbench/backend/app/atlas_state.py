"""Small, optional persistence adapter for the browser-only Knowledge Atlas."""
from __future__ import annotations
import json
import re
import time
from typing import Literal

from fastapi import HTTPException
from pydantic import BaseModel, Field, field_validator, model_validator
from .database import db

TOPIC = re.compile(r"^sec-\d+-\d+$")
USER = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")

class AtlasState(BaseModel):
    progress: dict[str, Literal['learning','mastered']] = Field(default_factory=dict)
    bookmarks: list[str] = Field(default_factory=list)
    notes: dict[str,str] = Field(default_factory=dict)

    @model_validator(mode='after')
    def bounded_export(self):
        if len(self.model_dump_json().encode('utf-8')) > 2_000_000:
            raise ValueError('Atlas export exceeds 2 MB import limit')
        return self

    @field_validator('progress')
    @classmethod
    def valid_progress(cls, value:dict[str,str]):
        if len(value)>1000 or any(not TOPIC.fullmatch(k) for k in value):
            raise ValueError('invalid topic ids in progress')
        return value

    @field_validator('bookmarks')
    @classmethod
    def valid_bookmarks(cls,value:list[str]):
        if len(value)>1000 or any(not TOPIC.fullmatch(k) for k in value):
            raise ValueError('invalid topic ids in bookmarks')
        return list(dict.fromkeys(value))

    @field_validator('notes')
    @classmethod
    def valid_notes(cls,value:dict[str,str]):
        if len(value)>1000 or any(not TOPIC.fullmatch(k) or len(v)>10000 for k,v in value.items()):
            raise ValueError('invalid notes')
        return value


def validate_user_id(user_id:str)->str:
    if not USER.fullmatch(user_id):
        raise HTTPException(status_code=400,detail='A valid AtCoder user ID is required')
    return user_id


def load_state(user_id:str)->dict:
    with db() as con:
        row=con.execute('SELECT state_json FROM atlas_learning_state WHERE user_id=?',(validate_user_id(user_id),)).fetchone()
    return {'state':json.loads(row['state_json']) if row else None}


def store_state(user_id:str, state:AtlasState)->dict:
    raw=state.model_dump_json()
    with db() as con:
        con.execute('INSERT INTO atlas_learning_state(user_id,state_json,updated_at) VALUES(?,?,?) '
                    'ON CONFLICT(user_id) DO UPDATE SET state_json=excluded.state_json,updated_at=excluded.updated_at',
                    (validate_user_id(user_id),raw,int(time.time())))
    return {'ok':True}
