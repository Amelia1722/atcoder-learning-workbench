"""Reviewed C tasks: interval intersection, imbalance transport and SCC skills."""
from __future__ import annotations
from collections import defaultdict,deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(419,425))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pairs=tuple[tuple[int,int],...]
Updates=tuple[tuple[str,int,int],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==419:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for pair in a for v in pair),'positions');return (a,)
    if number==420:
        n,q=ints(rows[0],2);require(1<=n<=200000 and 1<=q<=200000 and len(rows)==q+3,'shape');a,b=ints(rows[1],n),ints(rows[2],n);require(all(1<=v<=10**9 for seq in (a,b) for v in seq),'values');qs=[]
        for row in rows[3:]:fields=row.split(' ');require(len(fields)==3 and fields[0] in ('A','B'),'query');x,v=ints(' '.join(fields[1:]),2);require(1<=x<=n and 1<=v<=10**9,'update');qs.append((fields[0],x,v))
        return a,b,tuple(qs)
    if number==421:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(1<=n<=500000 and len(s)==2*n and set(s)<=set('AB') and s.count('A')==s.count('B')==n,'balanced');return (s,)
    if number==422:
        t=ints(rows[0],1)[0];require(1<=t<=200000 and len(rows)==t+1,'shape');a=tuple(ints(row,3) for row in rows[1:]);require(all(0<=v<=10**9 for triple in a for v in triple),'letters');return (a,)
    if number==423:
        require(len(rows)==2,'shape');n,r=ints(rows[0],2);a=ints(rows[1],n);require(2<=n<=200000 and 0<=r<=n and all(v in (0,1) for v in a),'doors');return r,a
    n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(pair==(0,0) or all(1<=v<=n for v in pair) for pair in a),'skills');return (a,)
def skill_scc_count(a:Pairs)->int:
    n=len(a);adj=[[] for _ in range(n)];reverse=[[] for _ in range(n)];seeds=[]
    for j,pair in enumerate(a):
        if pair==(0,0):seeds.append(j)
        else:
            for v in pair:adj[j].append(v-1);reverse[v-1].append(j)
    visited=[False]*n;order=[]
    for root in range(n):
        if visited[root]:continue
        stack=[(root,False)]
        while stack:
            v,closing=stack.pop()
            if closing:order.append(v);continue
            if visited[v]:continue
            visited[v]=True;stack.append((v,True))
            for w in adj[v]:
                if not visited[w]:stack.append((w,False))
    component=[-1]*n;sizes=[]
    for root in reversed(order):
        if component[root]>=0:continue
        label=len(sizes);size=0;component[root]=label;stack=[root]
        while stack:
            v=stack.pop();size+=1
            for w in reverse[v]:
                if component[w]<0:component[w]=label;stack.append(w)
        sizes.append(size)
    dependents=[[] for _ in sizes]
    for v,seq in enumerate(adj):
        for w in seq:
            if component[v]!=component[w]:dependents[component[w]].append(component[v])
    reached={component[v] for v in seeds};pending=deque(reached)
    while pending:
        for c in dependents[pending.popleft()]:
            if c not in reached:reached.add(c);pending.append(c)
    return sum(sizes[c] for c in reached)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==419:
        a=cast(Pairs,data[0]);low=-1;high=10**9
        while high-low>1:
            middle=(low+high)//2;rl=cl=1;rr=cr=10**9
            for r,c in a:rl=max(rl,r-middle);rr=min(rr,r+middle);cl=max(cl,c-middle);cr=min(cr,c+middle)
            if rl<=rr and cl<=cr:high=middle
            else:low=middle
        return str(high)
    if number==420:
        a,b,qs=cast(tuple[tuple[int,...],tuple[int,...],Updates],data);events:dict[int,list[tuple[int,str,int]]]=defaultdict(list);delta=[0]*len(qs);total=(sum(a)+sum(b)-sum(abs(x-y) for x,y in zip(a,b)))//2
        for t,(kind,x,v) in enumerate(qs):events[x-1].append((t,kind,v))
        for j,seq in events.items():
            x,y=a[j],b[j]
            for t,kind,v in seq:
                old=x+y-abs(x-y)
                if kind=='A':x=v
                else:y=v
                delta[t]=(x+y-abs(x-y)-old)//2
        out=[]
        for change in delta:total+=change;out.append(str(total))
        return '\n'.join(out)
    if number==421:
        s=cast(str,data[0]);count=0;cost=[0,0]
        for j,ch in enumerate(s,1):count+=ch=='A';cost[0]+=abs(count-(j+1)//2);cost[1]+=abs(count-j//2)
        return str(min(cost))
    if number==422:
        a=cast(tuple[tuple[int,int,int],...],data[0]);out=[]
        for x,y,z in a:
            low=0;high=min(x,z)+1
            while high-low>1:
                middle=(low+high)//2
                if x+z+y-2*middle>=middle:low=middle
                else:high=middle
            out.append(str(low))
        return '\n'.join(out)
    if number==423:
        r,a=cast(tuple[int,tuple[int,...]],data);answer=0;needed=False
        for v in a[:r]:
            if v==0:needed=True
            if needed:answer+=1 if v==0 else 2
        needed=False
        for v in reversed(a[r:]):
            if v==0:needed=True
            if needed:answer+=1 if v==0 else 2
        return str(answer)
    return str(skill_scc_count(cast(Pairs,data[0])))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc419_c':"n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];rows=[r for r,c in a];cols=[c for r,c in a];print((max(max(rows)-min(rows),max(cols)-min(cols))+1)//2)\n",
'abc420_c':"n,q=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));answer=sum(min(x,y) for x,y in zip(a,b))\nfor _ in range(q):\n kind,x,v=input().split();x=int(x)-1;v=int(v);answer-=min(a[x],b[x])\n if kind=='A':a[x]=v\n else:b[x]=v\n answer+=min(a[x],b[x]);print(answer)\n",
'abc421_c':"n=int(input());s=input();positions=[j for j,c in enumerate(s) if c=='A'];print(min(sum(abs(p-(2*j+start)) for j,p in enumerate(positions)) for start in (0,1)))\n",
'abc422_c':"t=int(input())\nfor _ in range(t):a,b,c=map(int,input().split());print(min(a,c,(a+b+c)//3))\n",
'abc423_c':"n,r=map(int,input().split());a=list(map(int,input().split()));opened=[j for j,v in enumerate(a) if v==0]\nif not opened:print(0)\nelse:\n left=min(opened[0],r);right=max(opened[-1]+1,r);print(2*(right-left)-len(opened))\n",
'abc424_c':"from collections import deque\nn=int(input());dependent=[[] for _ in range(n)];known=[False]*n;queue=deque()\nfor j in range(n):\n a,b=map(int,input().split())\n if a==b==0:known[j]=True;queue.append(j)\n else:dependent[a-1].append(j);dependent[b-1].append(j)\nwhile queue:\n for v in dependent[queue.popleft()]:\n  if not known[v]:known[v]=True;queue.append(v)\nprint(sum(known))\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17500+number)
    if number==419:
        def people(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(f'{r} {c}\n' for r,c in a)
        raws=[people(a) for a in ([(1,1)],[(1,1),(1,2)],[(1,1),(2,2)],[(1,1),(4,7)])];raws.extend(people([(rng.randint(1,100),rng.randint(1,100)) for _ in range(n)]) for n in range(3,15));raws.extend([people([(1,1),(10**9,10**9)]*100000),people([(10**9,10**9)]*200000)])
    elif number==420:
        def minimums(a:list[int],b:list[int],qs:list[tuple[str,int,int]])->str:return f'{len(a)} {len(qs)}\n'+line(a)+line(b)+''.join(f'{k} {x} {v}\n' for k,x,v in qs)
        raws=[minimums(a,b,qs) for a,b,qs in (([1],[1],[('A',1,1)]),([1],[2],[('A',1,3)]),([2],[1],[('B',1,3)]),([1,2],[2,1],[('A',2,1),('B',1,1)]))];raws.extend(minimums([rng.randint(1,100) for _ in range(n)],[rng.randint(1,100) for _ in range(n)],[(rng.choice('AB'),rng.randint(1,n),rng.randint(1,100)) for _ in range(n+5)]) for n in range(3,15));raws.extend([minimums([1]*200000,[10**9]*200000,[('A',j+1,10**9) for j in range(200000)]),minimums([10**9]*200000,[10**9]*200000,[('B',200000,10**9)]*200000)])
    elif number==421:
        def balanced(s:str)->str:return f'{len(s)//2}\n{s}\n'
        raws=[balanced(s) for s in ('AB','BA','AABB','ABBA')]
        for n in range(3,15):a=list('A'*n+'B'*n);rng.shuffle(a);raws.append(balanced(''.join(a)))
        raws.extend([balanced('AB'*500000),balanced('A'*500000+'B'*500000)])
    elif number==422:
        def contests(a:list[tuple[int,int,int]])->str:return f'{len(a)}\n'+''.join(f'{x} {y} {z}\n' for x,y,z in a)
        raws=[contests(a) for a in ([(0,0,0)],[(1,1,1)],[(1,0,1)],[(2,0,1),(1,0,2)])];raws.extend(contests([(rng.randint(0,100),rng.randint(0,100),rng.randint(0,100)) for _ in range(n)]) for n in range(3,15));raws.extend([contests([(10**9,0,10**9)]*200000),contests([(10**9,10**9,10**9)]*200000)])
    elif number==423:
        def doors(r:int,a:list[int])->str:return f'{len(a)} {r}\n'+line(a)
        raws=[doors(r,a) for r,a in ((0,[0,0]),(2,[1,1]),(1,[0,1]),(0,[1,0,1]))];raws.extend(doors(rng.randint(0,n),[rng.randrange(2) for _ in range(n)]) for n in range(3,15));raws.extend([doors(0,[1]*199999+[0]),doors(200000,[1]*200000)])
    else:
        def skills(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(f'{x} {y}\n' for x,y in a)
        raws=[skills(a) for a in ([(0,0)],[(1,1)],[(0,0),(1,1)],[(2,2),(1,1),(0,0)])];raws.extend(skills([(0,0) if rng.randrange(4)==0 else (rng.randint(1,n),rng.randint(1,n)) for _ in range(n)]) for n in range(3,15));raws.extend([skills([(0,0)]+[(j,j) for j in range(1,200000)]),skills([(j+1 if j<200000 else 1,j+1 if j<200000 else 1) for j in range(1,200001)])])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc419_c':('縦方向と横方向に同時に移動できます。','必要時間は、それぞれの座標幅の半分を切り上げたものの最大です。','疑似コード: widthR=max(R)-min(R),widthC=max(C)-min(C); (max(widthR,widthC)+1)//2を出力。'),
'abc420_c':('1要素の変更で変わる寄与はその添字のminだけです。','変更前のminを総和から引き、変更後のminを足します。','疑似コード: total=sum(min(A[i],B[i])); 各変更xで古いminを引く; 対象A/BをVへ変更; 新しいminを足しtotal出力。'),
'abc421_c':('最終形はABAB...またはBABA...の2通りです。','Aの出現順は変えずに、各Aを偶数または奇数位置へ運ぶ距離の合計を求めます。','疑似コード: Aの0始まり位置p[j]を抽出; start=0,1についてsum(abs(p[j]-(2*j+start)))を計算し最小を出力。'),
'abc422_c':('各コンテストは最低1つずつのA,Cと合計3文字を使います。','A数、C数、全文字数の3分の1が上限で、この最小値を実現できます。','疑似コード: 各testcaseでmin(nA,nC,(nA+nB+nC)//3)を出力。'),
'abc423_c':('開いたドアのうち最も外側まで行き、帰りながら閉じればよいです。','初期部屋と全開ドアを含む範囲内で、開ドアは1回、閉ドアは開閉の2回必要です。','疑似コード: 開ドアなしなら0; left=min(最左開ドア,R), right=max(最右開ドア+1,R); 2*(right-left)-開ドア数を出力。'),
'abc424_c':('習得済みスキルから、そのスキルを条件とするスキルへ進めます。','条件の逆引き一覧を作り、初期習得済みの全スキルから幅優先探索します。','疑似コード: 各iをdependent[A[i]],dependent[B[i]]へ追加; (0,0)をknownにしてqueueへ; popしたスキルのdependentで未知をknownにしqueue追加; known数を出力。')}

TITLES={'abc419_c': "King's Summit", 'abc420_c': 'Sum of Min Query', 'abc421_c': 'Alternated', 'abc422_c': 'AtCoder AAC Contest', 'abc423_c': 'Lock All Doors', 'abc424_c': 'New Skill Acquired'}
PUBLISHED_SAMPLES={'abc419_c': [{'input': '3\n2 3\n5 1\n8 1\n', 'expected': '3\n'}, {'input': '5\n6 7\n6 7\n6 7\n6 7\n6 7\n', 'expected': '0\n'}, {'input': '6\n91 999999986\n53 999999997\n32 999999932\n14 999999909\n49 999999985\n28 999999926\n', 'expected': '44\n'}], 'abc420_c': [{'input': '4 3\n3 1 4 1\n2 7 1 8\nA 2 3\nB 3 3\nA 1 7\n', 'expected': '7\n9\n9\n'}, {'input': '1 3\n1\n1000000000\nA 1 1\nA 1 1\nA 1 1\n', 'expected': '1\n1\n1\n'}, {'input': '5 3\n100 100 100 100 100\n100 100 100 100 100\nA 4 21\nA 2 99\nB 4 57\n', 'expected': '421\n420\n420\n'}], 'abc421_c': [{'input': '3\nAABBBA\n', 'expected': '2\n'}, {'input': '3\nAAABBB\n', 'expected': '3\n'}, {'input': '17\nAAABABABBBABABBABABABABBAAABABABBA\n', 'expected': '15\n'}], 'abc422_c': [{'input': '5\n3 1 2\n100 0 0\n1000000 1000000 1000000\n31 41 59\n1000000000 10000 1\n', 'expected': '2\n0\n1000000\n31\n1\n'}], 'abc423_c': [{'input': '6 3\n1 0 0 1 0 0\n', 'expected': '6\n'}, {'input': '2 1\n0 0\n', 'expected': '2\n'}, {'input': '8 2\n0 1 0 0 1 0 1 1\n', 'expected': '8\n'}], 'abc424_c': [{'input': '6\n0 0\n1 3\n3 2\n5 5\n4 6\n6 4\n', 'expected': '3\n'}, {'input': '4\n0 0\n0 0\n0 0\n0 0\n', 'expected': '4\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
