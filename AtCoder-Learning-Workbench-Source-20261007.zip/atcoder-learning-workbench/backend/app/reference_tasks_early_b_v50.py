"""ABC008 B / ABC012 B: manually reviewed domain and independent oracles.

No authenticated official HTML. Multiple winners in ABC008 B are all valid.
"""
from __future__ import annotations
import random
import re

TASKS=('abc008_2','abc012_2')
DIGITS=re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
NAME=re.compile(r'[a-z]{1,50}',re.ASCII)


def validate(pid:str,raw:str)->list[str]|int:
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('invalid problem id or input framing')
    lines=raw[:-1].split('\n')
    if pid=='abc012_2':
        if len(lines)!=1 or not DIGITS.fullmatch(lines[0]) or int(lines[0])>86399:
            raise ValueError('seconds must be 0..86399')
        return int(lines[0])
    if not lines or not DIGITS.fullmatch(lines[0]):
        raise ValueError('invalid voter count')
    n=int(lines[0])
    if not 1<=n<=50 or len(lines)!=n+1 or any(not NAME.fullmatch(s) for s in lines[1:]):
        raise ValueError('voters or names outside official input constraints')
    return lines[1:]


def semantic_check_vote(raw:str, output:str)->bool:
    try: names=validate('abc008_2',raw)
    except ValueError:return False
    if (not isinstance(output,str) or len(output)>51 or not output.endswith('\n')
            or not NAME.fullmatch(output[:-1])):
        return False
    # Independent of the reference program's Counter implementation.
    chosen=output[:-1]
    chosen_votes=sum(name==chosen for name in names)
    return chosen_votes>0 and all(chosen_votes>=sum(name==other for name in names) for other in names)


def independent_check(pid:str, raw:str, output:str)->bool:
    if pid=='abc008_2':return isinstance(output,str) and semantic_check_vote(raw,output+'\n')
    if pid!='abc012_2':return False
    try:n=validate(pid,raw)
    except ValueError:return False
    # Independent arithmetic: subtract full hours and minutes from the original total.
    h=n//3600
    m=(n-h*3600)//60
    s=n-h*3600-m*60
    return isinstance(output,str) and output==f'{h:02d}:{m:02d}:{s:02d}'


def generate(pid:str,seed:int=50)->list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unknown task')
    rng=random.Random(f'abc-v50:{pid}:{seed}')
    cases=[];seen=set()
    def add(category:str, raw:str):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw);cases.append({'category':category,'input':raw})
    if pid=='abc012_2':
        values=[0,1,2,9,10,59,60,61,119,3599,3600,3601,3661,35999,36000,43199,43200,86399]
        for n in values:add('constraint_max' if n==86399 else ('boundary' if n in (0,1,59,60,3599,3600) else 'normal'),f'{n}\n')
    else:
        presets=[['a'],['z'],['x'*50],['a','b'],['b','a'],['a','b','b'],
                 ['b','a','b','a'],['a']*10+['b']*10,['x']*49+['y'],
                 ['q']+['w']*49,['a']*25+['b']*25,['z']*50,
                 ['a','b','c','c','b','c','b','d','e'],['a']*26+['b']*24]
        for names in presets:
            add('boundary' if len(names) in (1,50) else 'normal',f'{len(names)}\n'+'\n'.join(names)+'\n')
        alphabet='abcdefghijklmnopqrstuvwxyz'
        while len(cases)<17:
            n=rng.randint(1,50)
            pool=[''.join(rng.choice(alphabet) for _ in range(rng.randint(1,50))) for _ in range(rng.randint(1,5))]
            votes=[rng.choice(pool) for _ in range(n)]
            add('normal',f'{n}\n'+'\n'.join(votes)+'\n')
        maximum=['a'*50]*25+['z'*50]*25
        raw='50\n'+'\n'.join(maximum)+'\n'
        cases=[c for c in cases if c['input']!=raw][:17]
        add('constraint_max',raw)
    if len(cases)!=18 or len({c['input'] for c in cases})!=18 or cases[-1]['category']!='constraint_max':
        raise ValueError('missing 18 distinct cases and a maximum-size candidate')
    return cases
