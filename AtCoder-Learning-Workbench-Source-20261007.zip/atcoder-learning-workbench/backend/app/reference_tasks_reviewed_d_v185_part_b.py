"""Private reviewed ABC120--125 D contracts and independent oracles."""
from __future__ import annotations
from collections import deque
from itertools import product
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(120,126))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a
def line(a:tuple[int,...]|list[int])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc120_d':
  n,m=ints(r[0],2);require(2<=n<=100000 and 1<=m<=100000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=a<b<=n for a,b in edges) and len(set(edges))==m,'simple graph');adj:list[list[int]]=[[] for _ in range(n)]
  for a,b in edges:adj[a-1].append(b-1);adj[b-1].append(a-1)
  seen={0};stack=[0]
  while stack:
   for v in adj[stack.pop()]:
    if v not in seen:seen.add(v);stack.append(v)
  require(len(seen)==n,'initial connectivity');return n,edges
 if pid=='abc121_d':
  require(len(r)==1,'shape');a,b=ints(r[0],2);require(0<=a<=b<=10**12,'range');return a,b
 if pid=='abc122_d':
  require(len(r)==1,'shape');n=ints(r[0],1)[0];require(3<=n<=100,'length');return (n,)
 if pid=='abc123_d':
  x,y,z,k=ints(r[0],4);require(1<=min(x,y,z) and max(x,y,z)<=1000 and 1<=k<=min(3000,x*y*z) and len(r)==4,'shape');arrays=tuple(ints(s,c) for s,c in zip(r[1:],(x,y,z)));require(all(1<=a<=10**10 for row in arrays for a in row),'value');return arrays,k
 if pid=='abc124_d':
  n,k=ints(r[0],2);require(1<=n<=100000 and 1<=k<=100000 and len(r)==2 and len(r[1])==n and set(r[1])<={'0','1'},'binary');return r[1],k
 n=ints(r[0],1)[0];require(2<=n<=100000 and len(r)==2,'shape');a=ints(r[1],n);require(all(-10**9<=v<=10**9 for v in a),'values');return (a,)
def bridge_members(n:int,edges:tuple[tuple[int,int],...])->list[int]:
 labels=list(range(n));members=[[i] for i in range(n)];missing=n*(n-1)//2;out=[]
 for a,b in reversed(edges):
  out.append(missing);a=labels[a-1];b=labels[b-1]
  if a==b:continue
  if len(members[a])<len(members[b]):a,b=b,a
  missing-=len(members[a])*len(members[b])
  for v in members[b]:labels[v]=a
  members[a].extend(members[b]);members[b]=[]
 return out[::-1]
def xor_bits(a:int,b:int)->int:
 def ones(n:int,t:int)->int:
  q,r=divmod(n,2*t);return q*t+max(0,r-t)
 return sum(1<<j for j in range(40) if (ones(b+1,1<<j)-ones(a,1<<j))%2)
def agc_automaton(n:int)->int:
 patterns={'AGC','ACG','GAC'}|{'A'+c+'GC' for c in 'ACGT'}|{'AG'+c+'C' for c in 'ACGT'}
 prefixes={''}|{p[:j] for p in patterns for j in range(1,len(p))};states=sorted(prefixes);idx={s:j for j,s in enumerate(states)};trans:list[list[int]]=[]
 for s in states:
  row=[]
  for c in 'ACGT':
   t=s+c
   if any(t.endswith(p) for p in patterns):row.append(-1)
   else:row.append(idx[max((q for q in prefixes if t.endswith(q)),key=len)])
  trans.append(row)
 dp=[0]*len(states);dp[idx['']]=1
 for _ in range(n):
  nxt=[0]*len(states)
  for j,v in enumerate(dp):
   for q in trans[j]:
    if q>=0:nxt[q]=(nxt[q]+v)%MOD
  dp=nxt
 return sum(dp)%MOD
def cake_pair_merge(arrays:tuple[tuple[int,...],...],k:int)->list[int]:
 a,b,c=arrays;c=tuple(sorted(c,reverse=True));pairs=sorted((x+y for x in a for y in b),reverse=True)[:k];heap=[(-(v+c[0]),j,0) for j,v in enumerate(pairs)];heapq.heapify(heap);out=[]
 for _ in range(k):
  neg,j,t=heapq.heappop(heap);out.append(-neg)
  if t+1<len(c):heapq.heappush(heap,(-(pairs[j]+c[t+1]),j,t+1))
 return out
def handstand_blocks(s:str,k:int)->int:
 starts=[];ends=[]
 for i,c in enumerate(s):
  if c=='0' and (i==0 or s[i-1]=='1'):starts.append(i)
  if c=='0' and (i+1==len(s) or s[i+1]=='1'):ends.append(i)
 if len(starts)<=k:return len(s)
 return max((starts[j+k] if j+k<len(starts) else len(s))-(ends[j-1]+1 if j else 0) for j in range(len(starts)-k+1))
def adjacent_flip_dp(a:tuple[int,...])->int:
 dp:tuple[int|None,int|None]=(0,None)
 for i,v in enumerate(a):
  nxt:list[int|None]=[None,None]
  for left,score in enumerate(dp):
   if score is None:continue
   for right in (0,) if i==len(a)-1 else (0,1):
    value=score+(v if left==right else -v);old=nxt[right];nxt[right]=value if old is None else max(old,value)
  dp=nxt[0],nxt[1]
 return cast(int,dp[0])
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc120_d':return ''.join(f'{x}\n' for x in bridge_members(cast(int,d[0]),cast(tuple[tuple[int,int],...],d[1])))
 if pid=='abc121_d':return f'{xor_bits(cast(int,d[0]),cast(int,d[1]))}\n'
 if pid=='abc122_d':return f'{agc_automaton(cast(int,d[0]))}\n'
 if pid=='abc123_d':return ''.join(f'{v}\n' for v in cake_pair_merge(cast(tuple[tuple[int,...],...],d[0]),cast(int,d[1])))
 if pid=='abc124_d':return f'{handstand_blocks(cast(str,d[0]),cast(int,d[1]))}\n'
 return f'{adjacent_flip_dp(cast(tuple[int,...],d[0]))}\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  rows=actual.replace('\r\n','\n').splitlines();expected=oracle(pid,raw).splitlines();return len(rows)==len(expected) and all(re.fullmatch(r'-?[0-9]+',s) and int(s)==int(t) for s,t in zip(rows,expected))
 except (ValueError,IndexError,TypeError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE:dict[str,str]={
'abc120_d':'''import sys
r=list(map(int,sys.stdin.buffer.read().split()));n,m=r[:2];e=list(zip(r[2::2],r[3::2]));p=[-1]*n
 def_placeholder
'''.replace(' def_placeholder','''def find(x):
 while p[x]>=0:
  if p[p[x]]>=0:p[x]=p[p[x]]
  x=p[x]
 return x
ans=[];v=n*(n-1)//2
for a,b in e[::-1]:
 ans.append(v);a=find(a-1);b=find(b-1)
 if a!=b:
  if p[a]>p[b]:a,b=b,a
  v-=p[a]*p[b];p[a]+=p[b];p[b]=a
print(*ans[::-1],sep='\\n')'''),
'abc121_d':'''a,b=map(int,input().split())
def f(x):return (x,1,x+1,0)[x%4] if x>=0 else 0
print(f(b)^f(a-1))
''',
'abc122_d':'''n=int(input());mod=1000000007;dp={'TTT':1}
for _ in range(n):
 nd={}
 for s,v in dp.items():
  for c in 'ACGT':
   t=s+c;ok='AGC' not in t
   for j in range(3):
    u=list(t);u[j],u[j+1]=u[j+1],u[j]
    if 'AGC' in ''.join(u):ok=False
   if ok:nd[t[1:]]=(nd.get(t[1:],0)+v)%mod
 dp=nd
print(sum(dp.values())%mod)
''',
'abc123_d':'''import heapq
x,y,z,k=map(int,input().split());a=sorted(map(int,input().split()),reverse=True);b=sorted(map(int,input().split()),reverse=True);c=sorted(map(int,input().split()),reverse=True);h=[(-(a[0]+b[0]+c[0]),0,0,0)];seen={(0,0,0)};out=[]
for _ in range(k):
 v,i,j,t=heapq.heappop(h);out.append(-v)
 for ii,jj,tt in ((i+1,j,t),(i,j+1,t),(i,j,t+1)):
  if ii<x and jj<y and tt<z and (ii,jj,tt) not in seen:seen.add((ii,jj,tt));heapq.heappush(h,(-(a[ii]+b[jj]+c[tt]),ii,jj,tt))
print(*out,sep='\\n')
''',
'abc124_d':'''n,k=map(int,input().split());s=input();left=0;groups=0;ans=0
for right,c in enumerate(s):
 if c=='0' and (right==0 or s[right-1]=='1'):groups+=1
 while groups>k:
  if s[left]=='0' and s[left+1]=='1':groups-=1
  left+=1
 ans=max(ans,right-left+1)
print(ans)
''',
'abc125_d':'''n=int(input());a=list(map(int,input().split()));total=sum(map(abs,a));neg=sum(v<0 for v in a);print(total-(2*min(map(abs,a)) if neg%2 else 0))
'''}
def generate(pid:str)->list[Case]:
 rng=random.Random(18500+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc120_d':
  def graph(n:int,e:list[tuple[int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(p) for p in e)
  raws=[graph(2,[(1,2)]),graph(3,[(1,2),(2,3)]),graph(3,[(1,2),(1,3),(2,3)])]
  for n in range(4,17):
   e=[(i,i+1) for i in range(1,n)];e+=list({(1,i) for i in range(3,n+1)}-set(e)) if n%2 else [];rng.shuffle(e);raws.append(graph(n,e))
  raws+=[graph(100000,[(1,i) for i in range(2,100001)]),graph(100000,[(i,i+1) for i in range(1,100000)]+[(1,100000)])]
 elif pid=='abc121_d':raws=[f'{a} {b}\n' for a,b in ((0,0),(0,1),(1,1),(2,4),(123,456),(0,3),(1,4),(3,3),(4,7),(7,8),(15,16),(2**39-1,2**39),(2**39,2**39+3),(123456789012,123456789012),(999999999997,10**12),(999999999998,10**12),(10**12,10**12),(0,10**12))]
 elif pid=='abc122_d':raws=[f'{n}\n' for n in (3,4,5,6,7,8,9,10,11,12,15,20,30,40,50,75,99,100)]
 elif pid=='abc123_d':
  def cake(a:list[int],b:list[int],c:list[int],k:int)->str:return f'{len(a)} {len(b)} {len(c)} {k}\n'+line(a)+line(b)+line(c)
  raws=[cake([1],[1],[1],1),cake([10**10],[10**10],[10**10],1),cake([1,1],[2,2],[3,3],8),cake([1,10],[2,20],[3,30],1)]
  for n in range(2,14):raws.append(cake([rng.randint(1,10**10) for _ in range(n)],[rng.randint(1,10**10) for _ in range(n+1)],[rng.randint(1,10**10) for _ in range(n+2)],min(3000,n*(n+1)*(n+2))))
  raws+=[cake(list(range(1,1001)),list(range(1000,0,-1)),[10**10]*1000,3000),cake([10**10]*1000,[10**10]*1000,[10**10]*1000,3000)]
 elif pid=='abc124_d':
  pairs=[('0',1),('1',1),('00',1),('01',1),('10',1),('00010',1),('11101010110011',2),('10101',1),('01010',1),('01010',2),('0'*100,100000),('1'*100,1),('01'*100,1),('10'*100,99),('0101010',3),('1010101',2),('01'*50000,1),('0'*100000,100000)];raws=[f'{len(s)} {k}\n{s}\n' for s,k in pairs]
 else:
  arrays=[[0,0],[-1,1],[-1,-1],[1,1],[-10,5,-4],[10,-4,-8,-11,3],[-10**9,0,10**9],[0,-1,0],[-5,2,3],[5,-2,3],[-5,-2,-3],[10**9]*3,[-10**9]*3,[rng.randint(-10**9,10**9) for _ in range(10)],[0]*100,[-10**9]+[10**9]*99998,[10**9]*100000,[-10**9]+[10**9]*99999];raws=[f'{len(a)}\n'+line(a) for a in arrays]
 require(len(raws)==len(set(raws))==18,'distinct18')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc120_d':('橋を崩す順を逆にすると、橋を追加する問題になります。','孤立した島からUnion-Findで成分を併合します。大きさa,bの異なる成分を結ぶと不便さはa*b減ります。','疑似コード: 不便さ=N*(N-1)/2; 橋を逆順に見て現在値を記録; 両端の根が違えばsize積を引いてunion; 記録を逆順出力。'),
'abc121_d':('0からXまでのXORには4個ごとの周期があります。','累積XORはX%4が0,1,2,3の順にX,1,X+1,0です。区間は累積XOR二つをXORして求めます。','疑似コード: prefix(-1)=0; prefix(X)=[X,1,X+1,0][X%4]; prefix(B) xor prefix(A-1)を出力。'),
'abc122_d':('新しい文字を足すとき、直近4文字だけを確認すれば十分です。','直近3文字を状態にします。4文字の中で交換なしと各隣接交換を試し、AGCができる遷移を除きます。','疑似コード: dp[TTT]=1; N回、状態sと追加文字cについてt=s+c; tおよび隣接1交換の全形にAGCがなければnext[tの末尾3文字]+=dp[s] mod; 全状態の和を出力。'),
'abc123_d':('降順に並べれば、添字を一つ増やした組の合計は増えません。','最大ヒープから合計最大の添字組を取り出し、三方向の隣接組を追加します。同じ添字組の重複追加を防ぎます。','疑似コード: A,B,Cを降順; heapに(0,0,0); K回popして合計出力; 各添字を一つ増やす有効未訪問組をpushして訪問記録。'),
'abc124_d':('連続する区間を全部1にするには、その区間の0の塊を反転します。','0の塊がK個以下の最長区間を二ポインタで求めます。右端を伸ばし、塊が多すぎたら左端を進めます。','疑似コード: left=0,zeroGroups=0; rightを順に追加し0の塊開始なら加算; zeroGroups>Kの間leftを進め、0の塊末尾を外したら減算; 区間長の最大を出力。'),
'abc125_d':('隣接する二つの符号を反転しても、負数の個数の偶奇は変わりません。','絶対値の総和から、負数が奇数個なら最小絶対値の2倍を引きます。0がある場合も同じ式で処理できます。','疑似コード: total=sum(abs(A)); 負数個数が奇数ならtotal-=2*min(abs(A)); totalを出力。')}

TITLES={'abc120_d': 'Decayed Bridges', 'abc121_d': 'XOR World', 'abc122_d': 'We Like AGC', 'abc123_d': 'Cake 123', 'abc124_d': 'Handstand', 'abc125_d': 'Flipping Signs'}
PUBLISHED_SAMPLES={'abc120_d': [{'input': '4 5\n1 2\n3 4\n1 3\n2 3\n1 4\n', 'expected': '0\n0\n4\n5\n6\n'}, {'input': '6 5\n2 3\n1 2\n5 6\n3 4\n4 5\n', 'expected': '8\n9\n12\n14\n15\n'}, {'input': '2 1\n1 2\n', 'expected': '1\n'}], 'abc121_d': [{'input': '2 4\n', 'expected': '5\n'}, {'input': '123 456\n', 'expected': '435\n'}, {'input': '123456789012 123456789012\n', 'expected': '123456789012\n'}], 'abc122_d': [{'input': '3\n', 'expected': '61\n'}, {'input': '4\n', 'expected': '230\n'}, {'input': '100\n', 'expected': '388130742\n'}], 'abc123_d': [{'input': '2 2 2 8\n4 6\n1 5\n3 8\n', 'expected': '19\n17\n15\n14\n13\n12\n10\n8\n'}, {'input': '3 3 3 5\n1 10 100\n2 20 200\n1 10 100\n', 'expected': '400\n310\n310\n301\n301\n'}, {'input': '10 10 10 20\n7467038376 5724769290 292794712 2843504496 3381970101 8402252870 249131806 6310293640 6690322794 6082257488\n1873977926 2576529623 1144842195 1379118507 6003234687 4925540914 3902539811 3326692703 484657758 2877436338\n4975681328 8974383988 2882263257 7690203955 514305523 6679823484 4263279310 585966808 3752282379 620585736\n', 'expected': '23379871545\n22444657051\n22302177772\n22095691512\n21667941469\n21366963278\n21287912315\n21279176669\n21160477018\n21085311041\n21059876163\n21017997739\n20703329561\n20702387965\n20590247696\n20383761436\n20343962175\n20254073196\n20210218542\n20150096547\n'}], 'abc124_d': [{'input': '5 1\n00010\n', 'expected': '4\n'}, {'input': '14 2\n11101010110011\n', 'expected': '8\n'}, {'input': '1 1\n1\n', 'expected': '1\n'}], 'abc125_d': [{'input': '3\n-10 5 -4\n', 'expected': '19\n'}, {'input': '5\n10 -4 -8 -11 3\n', 'expected': '30\n'}, {'input': '11\n-1000000000 1000000000 -1000000000 1000000000 -1000000000 0 1000000000 -1000000000 1000000000 -1000000000 1000000000\n', 'expected': '10000000000\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
