"""ABC071–073 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re
import string

TASKS=('abc071_b','abc072_b','abc073_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
LOWER=re.compile(r'[a-z]+',re.ASCII)


def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid in ('abc071_b','abc072_b'):
        if len(lines)!=1 or LOWER.fullmatch(lines[0]) is None or not 1<=len(lines[0])<=100_000:
            raise ValueError('string')
        return lines[0]
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N')
    n=int(lines[0])
    if not 1<=n<=1000 or len(lines)!=n+1:
        raise ValueError('line count/range')
    intervals=[]
    for line in lines[1:]:
        parts=line.split(' ')
        if len(parts)!=2 or any(POS.fullmatch(x) is None for x in parts):
            raise ValueError('interval')
        l,r=map(int,parts)
        if not 1<=l<=r<=100_000:
            raise ValueError('interval range')
        intervals.append((l,r))
    ordered=sorted(intervals)
    for i in range(1,len(ordered)):
        if ordered[i][0] <= ordered[i-1][1]:
            raise ValueError('overlap')
    return intervals


def independent_check(pid:str,raw:str,output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc071_b':
        present=set(value)
        expected=next((c for c in string.ascii_lowercase if c not in present),'None')
        return output==expected
    if pid=='abc072_b':
        expected=''.join(ch for i,ch in enumerate(value,1) if i%2==1)
        return output==expected
    occupied=set()
    for l,r in value:
        for seat in range(l,r+1):
            if seat in occupied:
                return False
            occupied.add(seat)
    return output==str(len(occupied))


def generate(pid:str,seed:int=71)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v71:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc071_b':
        fixtures=[
            'a','z','abc','bcdefghijklmnopqrstuvwxyz','abcdefghijklmnopqrstuvwxyz',
            'atcoderregularcontest','aaaaabbbbbccccc','abcdefghijklmnopqrstuvwxy',
            'bcdefghijklmnopqrstuvwxyza','thequickbrownfoxjumpsoverthelazydog',
            'mmmmmmmmmmmm','azazazaz','abcdefghijklmnopqrstuvwxzz',
        ]
        for s in fixtures:
            add('boundary' if len(s) in (1,26) else 'normal',s+'\n')
        while len(rows)<17:
            length=rng.randint(1,80)
            s=''.join(rng.choice(string.ascii_lowercase) for _ in range(length))
            add('random',s+'\n')
        add('constraint_max','a'*100_000+'\n')
    elif pid=='abc072_b':
        fixtures=['a','ab','abc','abcd','atcoder','aaaa','z','fukuokayamaguchi','abcdefghi','xyxyxyx','python','contest','abcdefghijklmnop']
        for s in fixtures:
            add('boundary' if len(s) in (1,2) else 'normal',s+'\n')
        while len(rows)<17:
            length=rng.randint(1,100)
            s=''.join(rng.choice(string.ascii_lowercase) for _ in range(length))
            add('random',s+'\n')
        add('constraint_max',('ab'*50_000)+'\n')
    else:
        fixtures=[
            [(1,1)],[(24,30)],[(1,100000)],[(3,3),(6,8)],[(1,1),(100000,100000)],
            [(1,10),(11,20)],[(10,20),(30,40),(50,60)],[(2,2),(4,4),(6,6),(8,8)],
            [(1,100),(1000,2000)],[(99990,99999),(100000,100000)],[(100,199),(500,599),(900,999)],
            [(1,2),(4,5),(7,8),(10,11),(13,14)],
        ]
        for intervals in fixtures:
            raw=str(len(intervals))+'\n'+''.join(f'{l} {r}\n' for l,r in intervals)
            add('boundary' if len(intervals)==1 else 'normal',raw)
        while len(rows)<17:
            n=rng.randint(2,20)
            points=sorted(rng.sample(range(1,5000),n))
            intervals=[(x,x) for x in points]
            raw=str(n)+'\n'+''.join(f'{l} {r}\n' for l,r in intervals)
            add('random',raw)
        intervals=[(i*100+1,(i+1)*100) for i in range(1000)]
        raw='1000\n'+''.join(f'{l} {r}\n' for l,r in intervals)
        add('constraint_max',raw)
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
