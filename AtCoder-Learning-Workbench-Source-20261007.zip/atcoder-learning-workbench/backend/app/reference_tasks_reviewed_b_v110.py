"""ABC188–190 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc188_b','abc189_b','abc190_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NONNEG=re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
SIGNED=re.compile(r'(?:0|-?[1-9][0-9]*)',re.ASCII)

PUBLISHED_SAMPLES={
 'abc188_b':[
  {'input':'2\n-3 6\n4 2\n','expected':'Yes\n'},
  {'input':'2\n4 5\n-1 -3\n','expected':'No\n'},
  {'input':'3\n1 3 5\n3 -6 3\n','expected':'Yes\n'},
 ],
 'abc189_b':[
  {'input':'2 15\n200 5\n350 3\n','expected':'2\n'},
  {'input':'2 10\n200 5\n350 3\n','expected':'2\n'},
  {'input':'3 1000000\n1000 100\n1000 100\n1000 100\n','expected':'-1\n'},
 ],
 'abc190_b':[
  {'input':'4 9 9\n5 5\n15 5\n5 15\n15 15\n','expected':'Yes\n'},
  {'input':'3 691 273\n691 997\n593 273\n691 273\n','expected':'No\n'},
  {'input':'7 100 100\n10 11\n12 67\n192 79\n154 197\n142 158\n20 25\n17 108\n','expected':'Yes\n'},
 ],
}

def _ints(line:str,count:int,pattern:re.Pattern[str])->list[int]:
    p=line.split(' ')
    if len(p)!=count or any(pattern.fullmatch(x) is None for x in p): raise ValueError('noncanonical integer row')
    return list(map(int,p))

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc188_b':
        if len(lines)!=3 or POS.fullmatch(lines[0]) is None: raise ValueError('shape/N')
        n=int(lines[0])
        if not 1<=n<=100000: raise ValueError('N range')
        a=_ints(lines[1],n,SIGNED); b=_ints(lines[2],n,SIGNED)
        if any(not -100<=x<=100 for x in a+b): raise ValueError('vector range')
        return a,b
    if pid=='abc189_b':
        if not lines: raise ValueError('missing header')
        n,x=_ints(lines[0],2,NONNEG)
        if not 1<=n<=1000 or not 0<=x<=10**6 or len(lines)!=n+1: raise ValueError('range/shape')
        drinks=[]
        for line in lines[1:]:
            v,p=_ints(line,2,NONNEG)
            if not 1<=v<=1000 or not 0<=p<=100: raise ValueError('drink range')
            drinks.append((v,p))
        return x,drinks
    if not lines: raise ValueError('missing header')
    n,s,d=_ints(lines[0],3,POS)
    if not 1<=n<=100 or not 1<=s<=10**9 or not 1<=d<=10**9 or len(lines)!=n+1: raise ValueError('range/shape')
    spells=[]
    for line in lines[1:]:
        x,y=_ints(line,2,POS)
        if not 1<=x<=10**9 or not 1<=y<=10**9: raise ValueError('spell range')
        spells.append((x,y))
    return s,d,spells

def _ans188(v)->str:
    a,b=v
    return 'Yes' if sum(x*y for x,y in zip(a,b))==0 else 'No'

def _ans189(v)->int:
    x,drinks=v; total=0
    for i,(vol,pct) in enumerate(drinks,1):
        total += vol*pct
        if total > x*100: return i
    return -1

def _ans190(v)->str:
    s,d,spells=v
    return 'Yes' if any(x<s and y>d for x,y in spells) else 'No'

def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or output!=output.strip() or '\n' in output: return False
    if pid=='abc188_b': return output in ('Yes','No') and output==_ans188(v)
    if pid=='abc190_b': return output in ('Yes','No') and output==_ans190(v)
    if re.fullmatch(r'-1|(?:0|[1-9][0-9]*)',output,re.ASCII) is None: return False
    return int(output)==_ans189(v)

def _188(a,b): return f'{len(a)}\n'+ ' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n'
def _189(x,drinks): return f'{len(drinks)} {x}\n'+''.join(f'{v} {p}\n' for v,p in drinks)
def _190(s,d,spells): return f'{len(spells)} {s} {d}\n'+''.join(f'{x} {y}\n' for x,y in spells)

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc188_b':
        cases=[
         ('sample1',[-3,6],[4,2]),('sample2',[4,5],[-1,-3]),('sample3',[1,3,5],[3,-6,3]),
         ('n1_zero',[0],[100]),('n1_nonzero',[100],[100]),('both_zero',[0,0,0],[0,0,0]),
         ('cancel_two',[100,100],[100,-100]),('negative_cancel',[-100,50],[1,2]),('all_positive',[1,2,3],[4,5,6]),
         ('all_negative',[-1,-2,-3],[-4,-5,-6]),('mixed_zero',[2,-3,4],[3,2,0]),('mixed_nonzero',[2,-3,4],[3,2,1]),
         ('n10',[i-5 for i in range(10)],[5-i for i in range(10)]),('n100_zero',[1]*50+[-1]*50,[7]*100),
         ('n1000_sparse',[0]*999+[1],[100]*999+[0]),('n10000_cancel',[1,-1]*5000,[100]*10000),
         ('n50000_nonzero',[1]*50000,[1]*50000),
        ]
        for c,a,b in cases:add(c,_188(a,b))
        a=[100 if i%2==0 else -100 for i in range(100000)]; b=[100]*100000
        add('constraint_max',_188(a,b))
    elif pid=='abc189_b':
        cases=[
         ('sample1',15,[(200,5),(350,3)]),('sample2',10,[(200,5),(350,3)]),('sample3',1000000,[(1000,100)]*3),
         ('x_zero_drunk',0,[(1,1)]),('x_zero_sober',0,[(1000,0)]),('exact_equal',10,[(100,10)]),
         ('one_over',9,[(100,10)]),('drunk_first',1,[(100,100),(1,0)]),('drunk_last',20,[(100,10),(100,10),(1,100)]),
         ('never_zero_percent',1,[(1000,0)]*5),('fraction_avoided',1,[(33,3),(34,3)]),('integer_threshold',9999,[(1000,100)]*10),
         ('n10_mixed',50,[(100,10),(200,20),(300,0),(50,100),(1,1),(999,1),(10,50),(5,20),(40,25),(1000,2)]),
         ('n100_sober',1000000,[(1000,100)]*100),('n100_drunk',500,[(1000,100)]*100),
         ('n500_zero',0,[(1000,0)]*500),('n999_late',998000,[(1000,100)]*999),
        ]
        for c,x,dr in cases:add(c,_189(x,dr))
        add('constraint_max',_189(10**6,[(1000,100)]*1000))
    else:
        cases=[
         ('sample1',9,9,[(5,5),(15,5),(5,15),(15,15)]),('sample2',691,273,[(691,997),(593,273),(691,273)]),('sample3',100,100,[(10,11),(12,67),(192,79),(154,197),(142,158),(20,25),(17,108)]),
         ('minimum_yes',2,1,[(1,2)]),('x_equal_s_no',1,1,[(1,2)]),('y_equal_d_no',2,1,[(1,1)]),
         ('both_boundary_no',1,1,[(1,1)]),('only_fast_no',10,10,[(9,1)]),('only_strong_no',10,10,[(100,11)]),
         ('one_valid_last',10,10,[(10,100),(1,10),(9,11)]),('all_valid',100,100,[(1,101),(2,102),(99,10**9)]),
         ('large_yes',10**9,10**9-1,[(10**9-1,10**9)]),('large_no_x',10**9,1,[(10**9,10**9)]),
         ('large_no_y',10**9,10**9,[(1,10**9)]),('n10_mixed',50,50,[(i*10+1,100-i) for i in range(10)]),
         ('n50_none',500,500,[(500,501)]*50),('n99_one',500,500,[(500,501)]*98+[(499,501)]),
        ]
        for c,s,d,sp in cases:add(c,_190(s,d,sp))
        add('constraint_max',_190(10**9,10**9,[(10**9,10**9)]*99+[(10**9-1,10**9)]))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
