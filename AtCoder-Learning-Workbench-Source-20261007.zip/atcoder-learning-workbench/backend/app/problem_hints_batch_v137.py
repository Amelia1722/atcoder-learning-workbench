"""Statement-checked three-stage hints for ABC269–271 B."""
HINTS_V137 = {
 'abc269_b': (
  '「#」は必ず1つの長方形をちょうど塗りつぶしています。したがって、#が現れる最上段・最下段・最左列・最右列を調べればA,B,C,Dが分かります。',
  '10×10しかないので全100マスを走査して、#の行番号と列番号の最小値・最大値を取れば十分です。行番号・列番号は1始まりで出力します。',
  '疑似コード:\nA=11, B=0, C=11, D=0\nfor i=1..10:\n  for j=1..10:\n    if S[i][j] == "#":\n      A=min(A,i); B=max(B,i)\n      C=min(C,j); D=max(D,j)\nprint(A,B)\nprint(C,D)',
 ),
 'abc270_b': (
  'まず壁Yが原点0とゴールXの間にあるかを判定します。間になければハンマーは不要で、答えは|X|です。',
  '壁が途中にある場合、先にハンマーZへ行ける必要があります。ハンマー自身が壁の向こう側なら到達不能です。届くなら 0→Z→X の距離を足します。',
  '疑似コード:\nif Y が 0 と X の間にない:\n  print(abs(X))\nelse if Y が 0 と Z の間にある:\n  print(-1)\nelse:\n  print(abs(Z) + abs(X-Z))',
 ),
 'abc271_b': (
  '各クエリは「s番目の数列のt番目」を聞くだけです。入力された各数列をそのまま二次元リストとして保持すれば直接参照できます。',
  'Pythonではseq[s-1][t-1]で答えられます。N,Qと要素総数が最大2×10^5なので、全クエリをO(1)参照すれば十分です。',
  '疑似コード:\nread N,Q\nseq=[]\nN回:\n  read L and elements\n  seq.append(elements)\nQ回:\n  read s,t\n  print(seq[s-1][t-1])',
 ),
}
