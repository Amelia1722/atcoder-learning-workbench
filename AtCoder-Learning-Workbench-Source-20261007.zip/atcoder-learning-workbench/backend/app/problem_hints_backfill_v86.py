"""Official-statement-checked three-stage hints backfilled in v86."""
HINTS_BACKFILL_V86 = {
    'abc178_c': (
        '全ての列から、条件を満たさない列を除く方法を考えてください。0がない場合と9がない場合には重なりがあります。',
        '包除原理を使います。全列10^Nから「0を含まない」9^Nと「9を含まない」9^Nを引き、両方含まない8^Nを足し戻します。各項はmodを取ります。',
        '疑似コード:\nMOD = 10**9 + 7\nans = (pow(10,N,MOD) - 2*pow(9,N,MOD) + pow(8,N,MOD)) % MOD\nprint(ans)',
    ),
    'abc242_c': (
        '左から桁を一つずつ決めるとき、次に置ける数字は直前の数字だけで決まります。',
        'DPで、現在の末尾の数字1〜9ごとの通り数を持ちます。次の桁では同じ数字と±1の範囲へ遷移し、998244353でmodを取ります。',
        '疑似コード:\nMOD = 998244353\ndp[1..9] = 1\nrepeat N-1 times:\n  ndp = zeros(10)\n  for d = 1..9:\n    for nd in [d-1,d,d+1] intersect [1,9]:\n      ndp[nd] += dp[d]\n      ndp[nd] %= MOD\n  dp = ndp\nprint(sum(dp) % MOD)',
    ),
    'abc261_c': (
        '同じ名前が何回目に現れたかだけ分かれば、その場で出力を決められます。',
        '辞書で各文字列の過去の出現回数を管理します。初回はそのまま、2回目以降は現在の過去回数を括弧付きで付けてからカウントを増やします。',
        '疑似コード:\ncount = {}\nfor s in S:\n  x = count.get(s, 0)\n  if x == 0: print(s)\n  else: print(s + "(" + str(x) + ")")\n  count[s] = x + 1',
    ),
    'abc275_d': (
        '同じ引数の値が何度も必要になります。一度求めた値を再利用できないか考えてください。',
        'f(0)=1を基底にし、f(x)=f(x//2)+f(x//3)をメモ化再帰または辞書DPで計算します。引数は割り算で急速に小さくなります。',
        '疑似コード:\nmemo = {0: 1}\ndef f(x):\n  if x in memo: return memo[x]\n  memo[x] = f(x//2) + f(x//3)\n  return memo[x]\nprint(f(N))',
    ),
    'abc295_d': (
        '部分文字列を並べ替えて同じ列を2回作れる条件を、各数字の出現回数の偶奇で考えてください。',
        '0〜9の出現回数の偶奇を10bitで持つprefix状態を作ります。区間内で全数字が偶数になるのは、区間両端のprefix bitmaskが同じときです。同じmaskの組数を数えます。',
        '疑似コード:\ncount = {0: 1}\nmask = 0; ans = 0\nfor ch in S:\n  mask ^= 1 << int(ch)\n  ans += count.get(mask, 0)\n  count[mask] = count.get(mask, 0) + 1\nprint(ans)',
    ),
    'abc340_c': (
        'ある整数xを処理した後に生まれる2つの整数について、以後に必要な金額を同じ形の問題として表してみてください。',
        'x>=2の総費用をF(x)とすると、F(x)=x+F(x//2)+F((x+1)//2)、F(1)=0です。同じxが何度も現れるためメモ化して計算します。',
        '疑似コード:\nmemo = {1: 0}\ndef F(x):\n  if x in memo: return memo[x]\n  memo[x] = x + F(x//2) + F((x+1)//2)\n  return memo[x]\nprint(F(N))',
    ),
    'abc126_e': (
        '条件で結ばれたカード同士は、一方の値が分かれば他方も決まります。独立に残るまとまりがいくつあるか考えてください。',
        '各(X_i,Y_i)を辺とする無向グラフの連結成分数が答えです。Z_iは同値/異値の関係を決めますが、必要な魔法回数には影響しません。Union-Findで成分数を数えます。',
        '疑似コード:\ndsu = DSU(N)\nfor X, Y, Z in constraints:\n  dsu.merge(X-1, Y-1)\nanswer = number of distinct dsu.leader(i) for i=0..N-1\nprint(answer)',
    ),
    'abc019_1': (
        '3個の値を小さい順に並べたとき、答えはどの位置にあるか確認してください。',
        '3整数をソートし、中央の要素を出力します。',
        '疑似コード:\nvalues = sorted([a, b, c])\nprint(values[1])',
    ),
    'abc018_2': (
        '各操作は現在の文字列の一部分だけを逆順にします。操作の順番どおりに文字列を更新してください。',
        '1-indexedの[l,r]を0-indexedのsliceへ変換し、S[l-1:r]を反転して前後と連結します。これをN回繰り返します。',
        '疑似コード:\nfor l, r in operations:\n  l -= 1\n  S = S[:l] + reverse(S[l:r]) + S[r:]\nprint(S)',
    ),
    'abc019_2': (
        '同じ文字が連続する区間ごとにまとめ、文字と区間長だけを残してください。',
        'ランレングス圧縮を行います。左から見て同じ文字が続く間は長さを増やし、文字が変わったら「文字+長さ」を答えへ追加します。',
        '疑似コード:\nans = []\ni = 0\nwhile i < len(S):\n  j = i\n  while j < len(S) and S[j] == S[i]: j += 1\n  ans.append(S[i] + str(j-i))\n  i = j\nprint(join(ans))',
    ),
}
