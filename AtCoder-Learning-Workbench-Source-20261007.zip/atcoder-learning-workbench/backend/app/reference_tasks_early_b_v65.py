"""ABC053–055 B: manually reviewed public statements; no archived official HTML."""
from __future__ import annotations
import math
import random
import re

TASKS = ('abc053_b', 'abc054_b', 'abc055_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
UPPER = re.compile(r'[A-Z]+', re.ASCII)
PIXELS = re.compile(r'[.#]+', re.ASCII)
MOD = 10**9 + 7


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown task or noncanonical input')
    lines = raw[:-1].split('\n')
    if pid == 'abc053_b':
        if len(lines) != 1 or not 1 <= len(lines[0]) <= 200000 or UPPER.fullmatch(lines[0]) is None:
            raise ValueError('invalid uppercase string/length')
        s = lines[0]
        if 'A' not in s or 'Z' not in s or s.index('A') >= s.rindex('Z'):
            raise ValueError('guaranteed A ... Z substring does not exist')
        return s
    if pid == 'abc054_b':
        parts = lines[0].split(' ') if lines else []
        if len(parts) != 2 or any(INT.fullmatch(x) is None for x in parts):
            raise ValueError('invalid dimensions')
        n, m = map(int, parts)
        if not 1 <= m <= n <= 50 or len(lines) != 1 + n + m:
            raise ValueError('invalid dimensions or line count')
        a = lines[1:1+n]; b = lines[1+n:]
        if any(len(row) != n or PIXELS.fullmatch(row) is None for row in a):
            raise ValueError('invalid image A')
        if any(len(row) != m or PIXELS.fullmatch(row) is None for row in b):
            raise ValueError('invalid template B')
        return n, m, a, b
    if len(lines) != 1 or INT.fullmatch(lines[0]) is None:
        raise ValueError('invalid integer input')
    n = int(lines[0])
    if not 1 <= n <= 100000:
        raise ValueError('N outside constraints')
    return n


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc053_b':
        s = value
        # Independent from reference find/rfind: scan and retain extremes.
        left = min(i for i, c in enumerate(s) if c == 'A')
        right = max(i for i, c in enumerate(s) if c == 'Z')
        return output == str(right - left + 1)
    if pid == 'abc054_b':
        n, m, a, b = value
        found = False
        for r in range(n-m+1):
            for c in range(n-m+1):
                if all(a[r+i][c+j] == b[i][j] for i in range(m) for j in range(m)):
                    found = True
                    break
            if found:
                break
        return output == ('Yes' if found else 'No')
    # math.factorial uses an independently implemented product tree, rather than
    # the reference program's stepwise modular multiplication.
    return output == str(math.factorial(value) % MOD)


def generate(pid: str, seed: int = 65) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    rng = random.Random(f'abc-v65:{pid}:{seed}')
    rows = []
    seen = set()
    def add(category, raw):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category': category, 'input': raw})
    if pid == 'abc053_b':
        fixtures = [
            'AZ', 'AAZ', 'AZZ', 'ZAZ', 'ZAQZ', 'AQQZ', 'ZAAZZ', 'ZAZZAAZ',
            'A' + 'Q'*100 + 'Z', 'Z'*100 + 'AZ', 'AZ' + 'Q'*200,
            'Q'*1000 + 'A' + 'Q'*1000 + 'Z' + 'Q'*1000,
            'A'*200 + 'Z'*200, 'Z'*100 + 'A'*100 + 'Z'*100,
        ]
        for s in fixtures:
            add('boundary' if len(s) == 2 else 'normal', s+'\n')
        while len(rows) < 17:
            n = rng.randint(3, 400)
            s = list(''.join(rng.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(n)))
            i = rng.randrange(n-1); j = rng.randrange(i+1, n)
            s[i] = 'A'; s[j] = 'Z'
            add('random',''.join(s)+'\n')
        add('constraint_max', 'A' + 'Q'*199998 + 'Z\n')
    elif pid == 'abc054_b':
        def fmt(a, b):
            return f'{len(a)} {len(b)}\n' + '\n'.join(a+b) + '\n'
        fixtures = [
            (['#'], ['#']), (['.'], ['#']), (['.'], ['.']),
            (['#.', '.#'], ['#']), (['#.', '.#'], ['.']),
            (['#.', '.#'], ['#.','. #'.replace(' ', '')]),
            (['#.', '.#'], ['##','##']),
            (['#.#','.#.','#.#'], ['#.','.#']),
            (['####','####','####','####'], ['##','##']),
            (['....','....','....','....'], ['#']),
            (['#..','.#.','..#'], ['#..','.#.','..#']),
            (['#..','.#.','..#'], ['...','...','...']),
            (['..##','..##','##..','##..'], ['##','##']),
            (['#..#','.##.','.##.','#..#'], ['##','##']),
        ]
        for a,b in fixtures:
            add('boundary' if len(a) == 1 else 'normal', fmt(a,b))
        while len(rows) < 17:
            n = rng.randint(2, 12); m = rng.randint(1,n)
            a = [''.join(rng.choice('.#') for _ in range(n)) for _ in range(n)]
            if rng.randrange(2):
                r = rng.randrange(n-m+1); c = rng.randrange(n-m+1)
                b = [a[r+i][c:c+m] for i in range(m)]
            else:
                b = [''.join(rng.choice('.#') for _ in range(m)) for _ in range(m)]
            add('random',fmt(a,b))
        a = [''.join('#' if (i*53+j*37)%7<3 else '.' for j in range(50)) for i in range(50)]
        b = [row[25:50] for row in a[25:50]]
        add('constraint_max', fmt(a,b))
    else:
        fixtures = [1,2,3,4,5,6,7,10,11,12,100,101,1000,10000]
        for n in fixtures:
            add('boundary' if n==1 else 'normal',f'{n}\n')
        while len(rows) < 17:
            add('random',f'{rng.randint(1,99999)}\n')
        add('constraint_max','100000\n')
    if len(rows) != 18 or len(seen) != 18 or rows[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 unique cases ending with max: got {len(rows)}')
    return rows
