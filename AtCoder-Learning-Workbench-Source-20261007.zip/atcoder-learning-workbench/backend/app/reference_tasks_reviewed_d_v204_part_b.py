"""Private official D467..472 with exact integer and graph certificates."""
from __future__ import annotations
from typing import cast
from collections import Counter,deque
from heapq import heappush,heappop
from array import array
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(467,473));CONTESTS={p:p.split('_')[0] for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?: -?(?:0|[1-9][0-9]*))*',row) is not None and '-0' not in row.split(),'integers');v=tuple(map(int,row.split()));require(n is None or len(v)==n,'fields');return v
def line(v:tuple[int,...]|list[int])->str:return ' '.join(map(str,v))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc467_d':
  t=ints(rows[0],1)[0];require(1<=t<=50000 and len(rows)==t+1,'shape');cases=tuple(ints(row,8) for row in rows[1:]);require(all(all(abs(v)<=10**9 for v in c) and c[:2]!=c[2:4] and c[4:6]!=c[6:] for c in cases),'points');return (cases,)
 if pid=='abc468_d':require(len(rows)==1 and re.fullmatch('[a-z]{1,10000}',rows[0]) is not None,'string');return (rows[0],)
 if pid=='abc469_d':
  n,m=ints(rows[0],2);require(2<=n<=200000 and 1<=m<=200000 and len(rows)==m+1,'shape');edges=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<b<=n for a,b in edges),'edges');return n,edges
 if pid=='abc470_d':
  n,q=ints(rows[0],2);require(2<=n<=500000 and 1<=q<=500000 and len(rows)==q+2,'shape');p=ints(rows[1],n);require(set(p)==set(range(1,n+1)),'permutation');queries=tuple(ints(row) for row in rows[2:]);require(all(query==(2,) or len(query)==3 and query[0]==1 and 1<=query[1]<query[2]<=n for query in queries),'queries');return p,queries
 if pid=='abc471_d':
  q,v=ints(rows[0],2);require(1<=q<=300000 and 1<=v<=10**9 and len(rows)==q+1,'shape');queries=tuple(ints(row) for row in rows[1:]);previous=0
  for query in queries:
   require((len(query)==3 and query[0]==1 and 0<=query[2]<=v) or (len(query)==2 and query[0]==2),'query');require(previous<query[1]<=10**9,'time');previous=query[1]
  return v,queries
 h,w,k=ints(rows[0],3);require(1<=h<=500000 and 1<=w<=500000 and h*w<=500000 and 0<=k<h*w and len(rows)==h+1,'shape');grid=tuple(rows[1:]);require(all(re.fullmatch('[.#]{'+str(w)+'}',row) is not None for row in grid),'grid');return h,w,k,grid

def concentric_construct(c:tuple[int,...])->bool:
 px,py,qx,qy,rx,ry,sx,sy=c;dx,dy=qx-px,qy-py;ex,ey=sx-rx,sy-ry;mx,my=px+qx,py+qy;nx,ny=-dy,dx
 denominator=ex*nx+ey*ny
 if denominator:
  delta=sx*sx+sy*sy-rx*rx-ry*ry-ex*mx-ey*my
  cx,cy=mx*denominator+delta*nx,my*denominator+delta*ny;scale=2*denominator
 else:cx,cy=mx,my;scale=2
 def distance(x:int,y:int)->int:return (scale*x-cx)**2+(scale*y-cy)**2
 return distance(px,py)==distance(qx,qy) and distance(rx,ry)==distance(sx,sy)
def near_palindrome_bitsets(s:str)->int:
 n=len(s);positions={ch:0 for ch in set(s)}
 for i,ch in enumerate(s):positions[ch]|=1<<i
 bad_one=[0,0];bad_two=[0,0];answer=0;mask=(1<<n)-1
 for length in range(1,n+1):
  slot=length%2;valid=mask>>(length-1);matches=0
  for bits in positions.values():matches|=bits&(bits>>(length-1))
  mismatch=valid^matches;inner_one=bad_one[slot]>>1;inner_two=bad_two[slot]>>1
  bad_two[slot]=(inner_two|(inner_one&mismatch))&valid;bad_one[slot]=(inner_one|mismatch)&valid
  answer+=n-length+1-bad_two[slot].bit_count()
 return answer
def two_cover_degrees(n:int,edges:tuple[tuple[int,...],...])->int:
 degree=[0]*(n+1);multiplicity=Counter(edges)
 for a,b in edges:degree[a]+=1;degree[b]+=1
 frequencies=Counter(degree[1:]);total=len(edges);answer=0
 for d,count in frequencies.items():
  other=total-d
  if d<other:answer+=count*frequencies.get(other,0)
  elif d==other:answer+=count*(count-1)//2
 for (a,b),count in multiplicity.items():
  if degree[a]+degree[b]==total:answer-=1
  if degree[a]+degree[b]-count==total:answer+=1
 return answer
def permutation_future_conjugation(p:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 future=sum(query==(2,) for query in queries)%2;values=[v-1 for v in p];inverse=[0]*len(p)
 for index,v in enumerate(values):inverse[v]=index
 if future:values,inverse=inverse,values
 for query in queries:
  if query==(2,):future^=1;continue
  x,y=query[1]-1,query[2]-1
  if future:
   left,right=inverse[x],inverse[y];values[left],values[right]=y,x;inverse[x],inverse[y]=right,left
  else:
   left,right=values[x],values[y];values[x],values[y]=right,left;inverse[left],inverse[right]=y,x
 return [v+1 for v in values]
def charge_saturation_events(v:int,queries:tuple[tuple[int,...],...])->list[int]:
 coordinates=sorted({query[2]-query[1] for query in queries if query[0]==1});index={value:i+1 for i,value in enumerate(coordinates)};tree=[0]*(len(coordinates)+1);identities:dict[int,deque[int]]={};active=[];full=[];intercepts=[];events=[];ready=deque();unsaturated=0;answer=[]
 def add(i:int,delta:int)->None:
  while i<len(tree):tree[i]+=delta;i+=i&-i
 def kth(rank:int)->int:
  at=0;step=1<<(len(coordinates).bit_length()-1)
  while step:
   nxt=at+step
   if nxt<len(tree) and tree[nxt]<rank:at=nxt;rank-=tree[nxt]
   step>>=1
  return at+1
 for query in queries:
  time=query[1]
  while events and events[0][0]<=time:
   _,identity=heappop(events)
   if active[identity]:full[identity]=True;add(index[intercepts[identity]],-1);unsaturated-=1;ready.append(identity)
  if query[0]==1:
   identity=len(active);intercept=query[2]-time;active.append(True);full.append(False);intercepts.append(intercept);heappush(events,(time+v-query[2],identity));add(index[intercept],1);unsaturated+=1;identities.setdefault(index[intercept],deque()).append(identity)
  elif ready:active[ready.popleft()]=False;answer.append(v)
  elif unsaturated:
   location=kth(unsaturated);ids=identities[location]
   while not active[ids[0]] or full[ids[0]]:ids.popleft()
   identity=ids.popleft();active[identity]=False;add(location,-1);unsaturated-=1;answer.append(time+intercepts[identity])
  else:answer.append(-1)
 return answer
def safe_reweighted_dial(h:int,w:int,k:int,grid:tuple[str,...])->int:
 cells=''.join(grid);row_ok=[True]*h;column_ok=[True]*w
 for cell,ch in enumerate(cells):
  if ch=='#':row_ok[cell//w]=False;column_ok[cell%w]=False
 if not any(row_ok) or not any(column_ok):return 0
 def nearest(flags:list[bool])->list[int]:
  values=[0 if good else len(flags)+1 for good in flags]
  for i in range(1,len(flags)):values[i]=min(values[i],values[i-1]+1)
  for i in range(len(flags)-2,-1,-1):values[i]=min(values[i],values[i+1]+1)
  return values
 rows=nearest(row_ok);columns=nearest(column_ok);potential=array('i',(rows[i//w]+columns[i%w] for i in range(h*w)));distance=array('i',[10**9])*(h*w);buckets=[deque(),deque(),deque()];pending=0
 for i in range(h*w):
  if potential[i]==0:distance[i]=0;buckets[0].append(i);pending+=1
 current=0
 while pending:
  if not buckets[current%3]:current+=1;continue
  cell=buckets[current%3].popleft();pending-=1
  if distance[cell]!=current:continue
  x=cell%w;neighbors=(cell-w if cell>=w else -1,cell+w if cell<h*w-w else -1,cell-1 if x else -1,cell+1 if x+1<w else -1)
  for nxt in neighbors:
   if nxt<0 or cells[nxt]=='#':continue
   value=current+1+potential[cell]-potential[nxt]
   if value<distance[nxt]:distance[nxt]=value;buckets[value%3].append(nxt);pending+=1
 return sum(ch=='.' and distance[i]+potential[i]<=k for i,ch in enumerate(cells))
def oracle(pid:str,raw:str)->str:
 data=validate(pid,raw)
 if pid=='abc467_d':return ''.join('Yes\n' if concentric_construct(c) else 'No\n' for c in cast(tuple[tuple[int,...],...],data[0]))
 if pid=='abc468_d':return str(near_palindrome_bitsets(cast(str,data[0])))+'\n'
 if pid=='abc469_d':return str(two_cover_degrees(*cast(tuple[int,tuple[tuple[int,...],...]],data)))+'\n'
 if pid=='abc470_d':return line(permutation_future_conjugation(*cast(tuple[tuple[int,...],tuple[tuple[int,...],...]],data)))
 if pid=='abc471_d':return ''.join(str(v)+'\n' for v in charge_saturation_events(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
 return str(safe_reweighted_dial(*cast(tuple[int,int,int,tuple[str,...]],data)))+'\n'
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc467_d':'''import sys
r=sys.stdin.buffer;t=int(r.readline());out=[]
for _ in range(t):
 px,py,qx,qy,rx,ry,sx,sy=map(int,r.readline().split());a=qx-px;b=qy-py;c=sx-rx;d=sy-ry;e=qx*qx+qy*qy-px*px-py*py;f=sx*sx+sy*sy-rx*rx-ry*ry
 out.append('Yes' if a*d-b*c or a*f-c*e==0 and b*f-d*e==0 else 'No')
print('\\n'.join(out))
''',
'abc468_d':'''def solve():
 s=input();n=len(s);answer=0
 for center in range(n):
  for left,right in [(center,center),(center,center+1)]:
   mismatch=0
   while left>=0 and right<n:
    mismatch+=s[left]!=s[right]
    if mismatch>1:break
    answer+=1;left-=1;right+=1
 print(answer)
solve()
''',
'abc469_d':'''import sys
r=sys.stdin.buffer;n,m=map(int,r.readline().split());edges=[tuple(map(int,r.readline().split())) for _ in range(m)];answer=0
for candidate in edges[0]:
 options=None
 for a,b in edges:
  if candidate not in (a,b):options={a,b} if options is None else options&{a,b}
 answer+=n-1 if options is None else len(options)
if all(a in edges[0] or b in edges[0] for a,b in edges):answer-=1
print(answer)
''',
'abc470_d':'''import sys
r=sys.stdin.buffer;n,q=map(int,r.readline().split());p=[x-1 for x in map(int,r.readline().split())];inverse=[0]*n
for i,x in enumerate(p):inverse[x]=i
for _ in range(q):
 query=list(map(int,r.readline().split()))
 if query[0]==2:p,inverse=inverse,p
 else:x,y=query[1]-1,query[2]-1;a,b=p[x],p[y];p[x],p[y]=b,a;inverse[a],inverse[b]=y,x
print(' '.join(str(x+1) for x in p))
''',
'abc471_d':'''import sys,heapq
r=sys.stdin.buffer;q,v=map(int,r.readline().split());heap=[];out=[]
for _ in range(q):
 query=list(map(int,r.readline().split()));time=query[1]
 if query[0]==1:heapq.heappush(heap,time-query[2])
 else:out.append(str(min(v,time-heapq.heappop(heap))) if heap else '-1')
sys.stdout.write('\\n'.join(out)+('\\n' if out else ''))
''',
'abc472_d':'''import sys
from collections import deque
def solve():
 r=sys.stdin.buffer;h,w,k=map(int,r.readline().split());cells=''.join(r.readline().decode().strip() for _ in range(h));size=h*w;row=[True]*h;column=[True]*w
 for i,ch in enumerate(cells):
  if ch=='#':row[i//w]=False;column[i%w]=False
 distance=[-1]*size;queue=deque()
 for i in range(size):
  if row[i//w] and column[i%w]:distance[i]=0;queue.append(i)
 while queue:
  i=queue.popleft()
  if distance[i]==k:continue
  x=i%w
  for j in (i-w if i>=w else -1,i+w if i<size-w else -1,i-1 if x else -1,i+1 if x+1<w else -1):
   if j>=0 and cells[j]=='.' and distance[j]<0:distance[j]=distance[i]+1;queue.append(j)
 print(sum(d>=0 for d in distance))
solve()
'''}
def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc467_d':
  def pack(cases:list[tuple[int,...]])->str:return str(len(cases))+'\n'+''.join(line(c) for c in cases)
  simple=[(0,0,1,0,0,0,1,0),(0,0,1,0,0,0,0,1),(0,0,1,0,0,1,1,1),(0,0,1,0,0,0,2,0),(0,0,0,1,1,0,1,2),(-10**9,-10**9,10**9,10**9,-10**9,10**9,10**9,-10**9),(0,0,2,2,1,0,3,2),(0,0,2,2,0,1,2,3)]
  raws=[pack([c]) for c in simple]
  while len(raws)<16:
   cases=[]
   while len(cases)<15:
    c=tuple(rng.randint(-10**9,10**9) for _ in range(8))
    if c[:2]!=c[2:4] and c[4:6]!=c[6:]:cases.append(c)
   raws.append(pack(cases))
  raws +=[pack([simple[i%8] for i in range(50000)]),pack([simple[5]]*50000)]
 elif pid=='abc468_d':
  values=['a','ab','aa','abcd','abcba','abcdcza','atcoder','iwai']
  while len(values)<15:values.append(''.join(rng.choice('abc') for _ in range(10+len(values))))
  raws=[s+'\n' for s in values+['ab'*5000,'a'*9999+'b','z'*10000]]
 elif pid=='abc469_d':
  def pack(n:int,e:list[tuple[int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(v) for v in e)
  raws=[pack(2,[(1,2)]),pack(3,[(1,2)]),pack(3,[(1,2),(2,3)]),pack(3,[(1,2),(1,3),(2,3)]),pack(4,[(1,2),(3,4)]),pack(5,[(1,2),(3,4),(4,5)]),pack(2,[(1,2)]*10),pack(5,[(1,2),(1,3),(1,4),(1,5)])]
  while len(raws)<16:
   n=10+len(raws);e=[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(25+len(raws))];raws.append(pack(n,e))
  raws +=[pack(200000,[(1,i+2) for i in range(199999)]+[(1,200000)]),pack(200000,[(1,200000)]*200000)]
 elif pid=='abc470_d':
  def pack(p:list[int],queries:list[tuple[int,...]])->str:return f'{len(p)} {len(queries)}\n'+line(p)+''.join(line(q) for q in queries)
  raws=[pack([1,2],[(2,)]),pack([1,2],[(1,1,2)]),pack([2,3,1],[(2,)]),pack([2,3,1],[(1,1,2),(2,)]),pack([2,3,1],[(2,),(1,1,2)]),pack([3,2,1],[(2,),(2,),(1,1,3)])]
  while len(raws)<16:
   n=10+len(raws);p=rng.sample(range(1,n+1),n);queries=[(2,) if rng.randrange(3)==0 else (1,*sorted(rng.sample(range(1,n+1),2))) for _ in range(30+len(raws))];raws.append(pack(p,queries))
  raws +=[pack(list(range(2,500001))+[1],[(2,) if i%3==0 else (1,i%499999+1,500000) for i in range(500000)]),pack(list(range(500000,0,-1)),[(2,)]*500000)]
 elif pid=='abc471_d':
  def pack(v:int,queries:list[tuple[int,...]])->str:return f'{len(queries)} {v}\n'+''.join(line(q) for q in queries)
  raws=[pack(1,[(1,1,0)]),pack(1,[(2,1)]),pack(1,[(1,1,1),(2,2)]),pack(100,[(1,1,20),(1,2,90),(2,3),(2,4),(2,5)]),pack(1,[(1,1,0),(1,2,0),(2,10),(2,11)]),pack(10**9,[(1,1,0),(2,10**9)]),pack(10,[(1,1,10),(1,2,1),(2,3),(2,4)]),pack(10,[(1,1,1),(1,2,2),(2,3)])]
  while len(raws)<16:
   v=rng.randint(1,100);queries=[(1,i+1,rng.randint(0,v)) if rng.randrange(2) else (2,i+1) for i in range(50+len(raws))];raws.append(pack(v,queries))
  raws +=[pack(10**9,[(1,i+1,10**9-i) if i<150000 else (2,i+1) for i in range(300000)]),pack(10**9,[(1,10**9-300000+i+1,10**9) for i in range(300000)])]
 else:
  def pack(k:int,grid:list[str])->str:return f'{len(grid)} {len(grid[0])} {k}\n'+'\n'.join(grid)+'\n'
  raws=[pack(0,['.']),pack(0,['#']),pack(0,['..','.#']),pack(3,['..','.#']),pack(3,['.#','..']),pack(8,['...','.#.','...']),pack(0,['...','...']),pack(8,['###','#.#','###'])]
  while len(raws)<15:
   h,w=5+len(raws)%3,7;grid=[''.join(rng.choice('.#') for _ in range(w)) for _ in range(h)];raws.append(pack(rng.randint(0,h*w-1),grid))
  grid=['.'*500]+['.'+''.join('#' if (i*917+j*103)%17==0 else '.' for j in range(1,500)) for i in range(1,1000)]
  raws +=[pack(499999,grid),pack(0,['.'*500]*1000),pack(499999,['.']*499999+['#'])]
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i>=15 else 'random'} for i,raw in enumerate(raws)]
HINTS:dict[str,tuple[str,str,str]]={
'abc467_d':('共通の中心は、それぞれの2点から等距離にある必要があります。','各組の垂直二等分線が交わるか調べます。平行でなければ交わり、平行なら同一直線かを整数の交差積で確認できます。','疑似コード: 2中心座標についてaX+bY=e,cX+dY=fという等距離式を作る。ad-bc!=0ならYes。平行ならaf-ce==0かつbf-de==0のときだけYes。'),
'abc468_d':('回文にするために必要な変更数は、左右対称な位置の不一致ペア数です。','奇数長と偶数長の各中心から外側へ伸ばし、不一致が2になった時点で打ち切ります。','疑似コード: 各中心のleft/rightからmismatch=0で拡張。S[left]!=S[right]ならmismatch++。mismatch>1ならbreak、それ以外はanswer++してleft--,right++。'),
'abc469_d':('最初の決勝ペアのどちらかは、求める二人に必ず含まれます。','最初の二人それぞれを固定し、その人が出ていない決勝ペアの共通参加者を求めます。固定した人が全決勝に出ていれば、相方は残り全員から選べます。','疑似コード: 最初の二人をcandidateとして順に固定。candidateを含まない各edgeの端点集合をintersectionする。該当edgeがなければN-1、あれば集合サイズを加える。最初の二人が全edgeを覆うなら重複1を引く。'),
'abc470_d':('種類2は、順列を逆順列へ置き換える操作です。','順列と逆順列を両方保持します。交換時には変更される二つの逆位置も更新し、逆順列操作は二配列の参照を交換するだけで処理できます。','疑似コード: inverse[P[i]]=iを構築。type1 x yでa=P[x],b=P[y]を交換しinverse[a]=y,inverse[b]=x。type2ならPとinverseをswap。最後のPを出力。'),
'abc471_d':('挿入時刻tと残量wから、充電中の残量は現在時刻+w-tになります。','w-tが大きいバッテリーほど残量も大きいので、最大ヒープで管理します。満充電なら残量をVで打ち止めにします。','疑似コード: type1でheapへt-wをpush。type2で空なら-1、他はmin(V,currentTime-popMin(heap))を出力。'),
'abc472_d':('爆弾がない行と、爆弾がない列の交点が安全な空マスです。','全安全マスを同時に始点へ入れてBFSすると、各空マスから最寄りの安全マスまでの距離が分かります。','疑似コード: 爆弾のある行/列を記録。どちらも無いマスをdistance=0でqueueへ。非壁の上下左右を未訪問ならdistance+1で訪問。距離Kで拡張を止め、訪問マス数を出力。')}

TITLES={'abc467_d': 'Concentric Circles', 'abc468_d': 'Pre-Palindrome', 'abc469_d': 'The Big Two', 'abc470_d': 'Inverse and Swap', 'abc471_d': 'Chargers', 'abc472_d': 'Bomber Mad'}
PUBLISHED_SAMPLES={'abc467_d': [{'input': '3\n2 0 1 1 -1 0 1 2\n1 0 -1 0 0 1 0 -1\n4 0 3 1 2 0 1 1\n', 'expected': 'Yes\nYes\nNo\n'}], 'abc468_d': [{'input': 'ababa\n', 'expected': '13\n'}, {'input': 'atcoder\n', 'expected': '18\n'}, {'input': 'abccbacbacb\n', 'expected': '40\n'}], 'abc469_d': [{'input': '5 5\n1 2\n3 4\n1 3\n2 3\n2 5\n', 'expected': '1\n'}, {'input': '7 8\n2 4\n1 3\n1 7\n1 3\n1 2\n1 6\n1 5\n1 3\n', 'expected': '2\n'}, {'input': '5 8\n1 2\n2 4\n1 3\n1 3\n1 2\n1 2\n1 5\n1 2\n', 'expected': '2\n'}], 'abc470_d': [{'input': '5 5\n2 1 3 5 4\n1 2 4\n2\n1 2 3\n1 3 4\n2\n', 'expected': '4 5 2 1 3\n'}, {'input': '7 4\n3 7 5 6 4 2 1\n2\n2\n2\n2\n', 'expected': '3 7 5 6 4 2 1\n'}, {'input': '10 8\n7 3 2 4 8 5 10 9 1 6\n2\n1 4 10\n1 6 9\n2\n1 9 10\n1 3 10\n2\n1 4 6\n', 'expected': '3 10 2 8 6 7 1 5 9 4\n'}], 'abc471_d': [{'input': '7 100\n1 15 60\n1 25 80\n2 30\n1 45 0\n2 60\n2 70\n2 80\n', 'expected': '85\n100\n25\n-1\n'}, {'input': '20 380736236\n1 21873985 256702097\n2 86369729\n1 114301317 288304981\n1 147244640 305840435\n2 150951976\n1 331581391 50335458\n1 352989552 47577202\n1 400130024 345362760\n2 458793150\n2 509082216\n1 591375600 197371572\n1 617022014 101276068\n1 679649471 310249627\n1 796351653 268586022\n1 825648347 129608152\n2 908069704\n2 921770319\n1 949684819 372272469\n1 971850999 335461408\n2 986253026\n', 'expected': '321197841\n324955640\n380736236\n380736236\n380736236\n380736236\n380736236\n'}], 'abc472_d': [{'input': '3 3 1\n#..\n...\n..#\n', 'expected': '5\n'}, {'input': '2 3 0\n...\n...\n', 'expected': '6\n'}, {'input': '5 7 2\n..#....\n..#....\n.......\n...#...\n...#...\n', 'expected': '29\n'}]}
SAMPLE_COUNTS={'abc467_d': 1, 'abc468_d': 3, 'abc469_d': 3, 'abc470_d': 3, 'abc471_d': 2, 'abc472_d': 3}
