"""ABC074–076 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS=('abc074_b','abc075_b','abc076_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
GRID=re.compile(r'[.#]+',re.ASCII)


def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc074_b':
        if len(lines)!=3 or any(not line for line in lines): raise ValueError('line count')
        if POS.fullmatch(lines[0]) is None or POS.fullmatch(lines[1]) is None: raise ValueError('N/K')
        n,k=map(int,lines[:2])
        if not (1<=n<=100 and 1<=k<=100): raise ValueError('range')
        parts=lines[2].split(' ')
        if len(parts)!=n or any(POS.fullmatch(x) is None for x in parts): raise ValueError('x')
        xs=list(map(int,parts))
        if any(not 0<x<k for x in xs): raise ValueError('x range')
        return n,k,xs
    if pid=='abc075_b':
        if not lines: raise ValueError('empty')
        head=lines[0].split(' ')
        if len(head)!=2 or any(POS.fullmatch(x) is None for x in head): raise ValueError('H/W')
        h,w=map(int,head)
        if not (1<=h<=50 and 1<=w<=50) or len(lines)!=h+1: raise ValueError('range/lines')
        grid=lines[1:]
        if any(len(row)!=w or GRID.fullmatch(row) is None for row in grid): raise ValueError('grid')
        return h,w,grid
    if len(lines)!=2 or any(POS.fullmatch(x) is None for x in lines): raise ValueError('N/K')
    n,k=map(int,lines)
    if not (1<=n<=10 and 1<=k<=10): raise ValueError('range')
    return n,k


def independent_check(pid:str,raw:str,output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc074_b':
        _,k,xs=value
        total=0
        for x in xs:
            left=x+x
            right=(k-x)+(k-x)
            total += left if left<right else right
        return output==str(total)
    if pid=='abc075_b':
        h,w,g=value
        result=[]
        for r in range(h):
            chars=[]
            for c in range(w):
                if g[r][c]=='#':
                    chars.append('#'); continue
                count=0
                for rr in range(max(0,r-1),min(h,r+2)):
                    for cc in range(max(0,c-1),min(w,c+2)):
                        if (rr!=r or cc!=c) and g[rr][cc]=='#': count+=1
                chars.append(str(count))
            result.append(''.join(chars))
        return output=='\n'.join(result)
    n,k=value
    states={1}
    for _ in range(n):
        states={y for x in states for y in (x*2,x+k)}
    return output==str(min(states))


def generate(pid:str,seed:int=72)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v72:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc074_b':
        fixtures=[
          (1,2,[1]),(1,100,[1]),(1,100,[99]),(2,9,[3,6]),(5,20,[11,12,9,17,12]),
          (4,10,[1,2,8,9]),(3,10,[5,5,5]),(6,7,[1,2,3,4,5,6]),(10,100,[50]*10),
          (3,4,[1,2,3]),(8,20,[1,19,2,18,3,17,4,16]),(5,6,[1,1,5,5,3])]
        for n,k,xs in fixtures:
            add('boundary' if n==1 or min(xs)==1 or max(xs)==k-1 else 'normal',f'{n}\n{k}\n'+ ' '.join(map(str,xs))+'\n')
        while len(rows)<17:
            k=rng.randint(2,100); n=rng.randint(1,30)
            xs=[rng.randint(1,k-1) for _ in range(n)]
            add('random',f'{n}\n{k}\n'+' '.join(map(str,xs))+'\n')
        add('constraint_max','100\n100\n'+' '.join(['50']*100)+'\n')
    elif pid=='abc075_b':
        fixtures=[
          ['.'],['#'],['..'],['##'],['.#.'],['...','...'],['###','...'],['#.#','...','#.#'],
          ['.....','.#.#.','.....'],['#####','#####','#####'],['#..','...','..#'],['.#.','###','.#.']]
        for g in fixtures:
            h=len(g); w=len(g[0])
            add('boundary' if h==1 or w==1 else 'normal',f'{h} {w}\n'+'\n'.join(g)+'\n')
        while len(rows)<17:
            h=rng.randint(2,8); w=rng.randint(2,8)
            g=[''.join('#' if rng.random()<0.35 else '.' for _ in range(w)) for _ in range(h)]
            add('random',f'{h} {w}\n'+'\n'.join(g)+'\n')
        g=[''.join('#' if (r+c)%3==0 else '.' for c in range(50)) for r in range(50)]
        add('constraint_max','50 50\n'+'\n'.join(g)+'\n')
    else:
        for n,k in [(1,1),(1,10),(2,1),(2,10),(3,3),(4,3),(5,2),(5,10),(6,4),(7,5),(8,8),(9,1),(9,9),(10,1),(10,2),(10,9),(4,10)]:
            add('boundary' if n in (1,10) or k in (1,10) else 'normal',f'{n}\n{k}\n')
        add('constraint_max','10\n10\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
