"""ABC119–121 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
import re

TASKS = ('abc119_b', 'abc120_b', 'abc121_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
BTC = re.compile(r'(?:0|[1-9][0-9]{0,2})\.[0-9]{8}', re.ASCII)


def _split_exact(line: str, count: int, pattern: re.Pattern[str]) -> list[str]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(token) is None for token in parts):
        raise ValueError('noncanonical token shape')
    return parts


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc119_b':
        if not lines or POS.fullmatch(lines[0]) is None:
            raise ValueError('N format')
        n = int(lines[0])
        if not 2 <= n <= 10 or len(lines) != n + 1:
            raise ValueError('N/line count')
        gifts: list[tuple[Decimal, str]] = []
        for line in lines[1:]:
            parts = line.split(' ')
            if len(parts) != 2 or parts[1] not in ('JPY', 'BTC'):
                raise ValueError('gift row')
            amount_raw, unit = parts
            if unit == 'JPY':
                if POS.fullmatch(amount_raw) is None:
                    raise ValueError('JPY lexical format')
                amount = Decimal(amount_raw)
                if not Decimal(1) <= amount <= Decimal(100_000_000):
                    raise ValueError('JPY range')
            else:
                if BTC.fullmatch(amount_raw) is None:
                    raise ValueError('BTC lexical format')
                amount = Decimal(amount_raw)
                if not Decimal('0.00000001') <= amount <= Decimal('100.00000000'):
                    raise ValueError('BTC range')
            gifts.append((amount, unit))
        return gifts

    if pid == 'abc120_b':
        if len(lines) != 1:
            raise ValueError('line count')
        a_raw, b_raw, k_raw = _split_exact(lines[0], 3, POS)
        a, b, k = map(int, (a_raw, b_raw, k_raw))
        if not 1 <= a <= 100 or not 1 <= b <= 100:
            raise ValueError('A/B range')
        common = sum(a % d == 0 and b % d == 0 for d in range(1, min(a, b) + 1))
        if not 1 <= k <= common:
            raise ValueError('K-th divisor must exist')
        return a, b, k

    if len(lines) < 3:
        raise ValueError('matrix line count')
    h = _split_exact(lines[0], 3, SIGNED)
    n, m, c = map(int, h)
    if not (1 <= n <= 20 and 1 <= m <= 20 and -100 <= c <= 100 and len(lines) == n + 2):
        raise ValueError('N/M/C/line count')
    b = list(map(int, _split_exact(lines[1], m, SIGNED)))
    rows = [list(map(int, _split_exact(line, m, SIGNED))) for line in lines[2:]]
    if any(not -100 <= x <= 100 for x in b) or any(not -100 <= x <= 100 for row in rows for x in row):
        raise ValueError('matrix coefficient range')
    return n, m, c, b, rows


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError, InvalidOperation):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc119_b':
        try:
            actual = Decimal(output)
        except InvalidOperation:
            return False
        if not actual.is_finite():
            return False
        truth = sum((amount if unit == 'JPY' else amount * Decimal(380000)
                     for amount, unit in value), Decimal(0))
        diff = abs(actual - truth)
        tolerance = Decimal('0.00001')
        return diff <= tolerance or diff <= abs(truth) * tolerance

    if output != '0' and POS.fullmatch(output) is None:
        return False
    if pid == 'abc120_b':
        a, b, k = value
        common = [d for d in range(1, min(a, b) + 1) if a % d == 0 and b % d == 0]
        return output == str(common[-k])

    n, m, c, b, rows = value
    answer = 0
    for row in rows:
        score = c
        for j in range(m):
            score += row[j] * b[j]
        answer += score > 0
    return output == str(answer)


def _gifts(rows: list[tuple[str, str]]) -> str:
    return str(len(rows)) + '\n' + '\n'.join(f'{amount} {unit}' for amount, unit in rows) + '\n'


def _matrix(c: int, b: list[int], rows: list[list[int]]) -> str:
    return (f'{len(rows)} {len(b)} {c}\n' + ' '.join(map(str, b)) + '\n' +
            '\n'.join(' '.join(map(str, row)) for row in rows) + '\n')


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc119_b':
        fixed = [
            ('sample1', [('10000', 'JPY'), ('0.10000000', 'BTC')]),
            ('sample2', [('100000000', 'JPY'), ('100.00000000', 'BTC'), ('0.00000001', 'BTC')]),
            ('minimum_units', [('1', 'JPY'), ('0.00000001', 'BTC')]),
            ('two_jpy_extremes', [('1', 'JPY'), ('100000000', 'JPY')]),
            ('two_btc_extremes', [('0.00000001', 'BTC'), ('100.00000000', 'BTC')]),
            ('tiny_btc_only', [('0.00000001', 'BTC'), ('0.00000002', 'BTC')]),
            ('fractional_yen', [('1', 'JPY'), ('0.00000263', 'BTC')]),
            ('mixed_small', [('123', 'JPY'), ('0.00010000', 'BTC'), ('456', 'JPY')]),
            ('mixed_medium', [('7654321', 'JPY'), ('12.34567890', 'BTC'), ('99999999', 'JPY')]),
            ('all_jpy_ten', [('100000000', 'JPY')] * 10),
            ('alternating_ten', [('100000000', 'JPY') if i % 2 == 0 else ('100.00000000', 'BTC') for i in range(10)]),
            ('all_tiny_btc_ten', [('0.00000001', 'BTC')] * 10),
            ('powers', [('10', 'JPY'), ('0.00001000', 'BTC'), ('1000', 'JPY'), ('1.00000000', 'BTC')]),
            ('btc_decimal_edges', [('99.99999999', 'BTC'), ('100.00000000', 'BTC')]),
            ('jpy_edges', [('99999999', 'JPY'), ('100000000', 'JPY')]),
            ('many_mixed', [('1', 'JPY'), ('0.00000001', 'BTC'), ('2', 'JPY'), ('0.00000002', 'BTC'), ('3', 'JPY'), ('0.00000003', 'BTC'), ('4', 'JPY'), ('0.00000004', 'BTC'), ('5', 'JPY'), ('0.00000005', 'BTC')]),
            ('near_max_mixed', [('100000000', 'JPY')] * 9 + [('99.99999999', 'BTC')]),
        ]
        for category, rows in fixed:
            add(category, _gifts(rows))
        add('constraint_max', _gifts([('100.00000000', 'BTC')] * 10))

    elif pid == 'abc120_b':
        fixed = [
            ('sample1', (8, 12, 2)), ('sample2', (100, 50, 4)), ('sample3', (1, 1, 1)),
            ('coprime', (99, 100, 1)), ('equal_small_first', (12, 12, 1)), ('equal_small_last', (12, 12, 6)),
            ('gcd_only', (36, 48, 1)), ('middle_rank', (36, 48, 3)), ('many_divisors', (60, 90, 8)),
            ('prime_pair_same', (97, 97, 2)), ('one_side_one', (1, 100, 1)), ('both_even', (64, 96, 4)),
            ('nested', (72, 24, 5)), ('small', (2, 4, 2)), ('symmetric', (50, 100, 3)),
            ('gcd_prime', (77, 91, 2)), ('near_max', (96, 100, 2)),
        ]
        for category, (a, b, k) in fixed:
            add(category, f'{a} {b} {k}\n')
        add('constraint_max', '100 100 9\n')

    else:
        fixed = [
            ('sample1', -10, [1, 2, 3], [[3, 2, 1], [1, 2, 2]]),
            ('sample2', -4, [-2, 5], [[100, 41], [100, 40], [-3, 0], [-6, -2], [18, -13]]),
            ('sample3', 0, [100, -100, 0], [[0, 100, 100], [100, 100, 100], [-100, 100, 100]]),
            ('strict_zero', -100, [100], [[1]]),
            ('strict_positive', -99, [100], [[1]]),
            ('strict_negative', -100, [100], [[0]]),
            ('negative_times_negative', 0, [-100, -100], [[-100, -100], [100, 100]]),
            ('zero_vector', 0, [0, 0, 0], [[0, 0, 0], [100, -100, 100]]),
            ('c_positive', 100, [0], [[-100], [0], [100]]),
            ('c_negative', -100, [0], [[-100], [0], [100]]),
            ('mixed_signs', 7, [3, -5, 11], [[-7, 2, 1], [7, -2, -1], [0, 0, 0]]),
            ('all_features_max', 100, [100] * 20, [[100] * 20]),
            ('all_features_min', -100, [-100] * 20, [[100] * 20]),
            ('one_dimension_many', 0, [1], [[-100], [-1], [0], [1], [100]]),
            ('twenty_rows_zero_boundary', 0, [1], [[0]] * 20),
            ('twenty_rows_positive', 0, [1], [[1]] * 20),
            ('twenty_rows_negative', 0, [1], [[-1]] * 20),
        ]
        for category, c, b, rows in fixed:
            add(category, _matrix(c, b, rows))
        add('constraint_max', _matrix(100, [100] * 20, [[100] * 20 for _ in range(20)]))

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
