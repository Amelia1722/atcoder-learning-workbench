"""Six reviewed C tasks: range losses, divisor sets, high-precision route average."""
from __future__ import annotations
from decimal import Decimal,localcontext
from fractions import Fraction
from itertools import permutations
from math import isqrt
from typing import cast
import random,re

TASKS=('abc141_c','abc142_c','abc144_c','abc145_c','abc146_c','abc147_c')
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES={'abc145_c':'numeric_tolerance_1e-6'}
Data=tuple[object,...]
Case=dict[str,str]
Pair=tuple[int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==141:
        n,k,q=ints(rows[0],3);require(2<=n<=100000 and 1<=k<=10**9 and 1<=q<=100000 and len(rows)==q+1,'shape')
        answers=tuple(ints(r,1)[0] for r in rows[1:]);require(all(1<=v<=n for v in answers),'answerer');return n,k,answers
    if number==142:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==2,'shape');a=ints(rows[1],n)
        require(set(a)==set(range(1,n+1)),'permutation');return (a,)
    if number==144:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(2<=n<=10**12,'integer');return (n,)
    if number==145:
        n=ints(rows[0],1)[0];require(2<=n<=8 and len(rows)==n+1,'shape');points=tuple(cast(Pair,ints(r,2)) for r in rows[1:])
        require(len(set(points))==n and all(-1000<=x<=1000 and -1000<=y<=1000 for x,y in points),'coordinates');return (points,)
    if number==146:
        require(len(rows)==1,'shape');a,b,x=ints(rows[0],3);require(1<=a<=10**9 and 1<=b<=10**9 and 1<=x<=10**18,'prices');return a,b,x
    n=ints(rows[0],1)[0];require(1<=n<=15,'people');index=1;claims=[]
    for person in range(1,n+1):
        require(index<len(rows),'missing person');count=ints(rows[index],1)[0];index+=1
        require(0<=count<n and index+count<=len(rows),'claim count');testimony=tuple(cast(Pair,ints(r,2)) for r in rows[index:index+count]);index+=count
        require(all(1<=x<=n and x!=person and y in (0,1) for x,y in testimony) and len({x for x,y in testimony})==count,'testimony');claims.append(testimony)
    require(index==len(rows),'extra line');return (tuple(claims),)

def _divisors(n:int)->list[int]:
    value=n;factors=[];p=2
    while p*p<=value:
        power=0
        while value%p==0:value//=p;power+=1
        if power:factors.append((p,power))
        p=3 if p==2 else p+2
    if value>1:factors.append((value,1))
    divisors=[1]
    for prime,power in factors:divisors=[d*prime**e for d in divisors for e in range(power+1)]
    return divisors

def _path_average(points:tuple[Pair,...])->str:
    with localcontext() as ctx:
        ctx.prec=60;n=len(points)
        distances=[[Decimal((x-a)**2+(y-b)**2).sqrt() for a,b in points] for x,y in points]
        total=Decimal(0);count=0
        for route in permutations(range(n)):
            total+=sum((distances[a][b] for a,b in zip(route,route[1:])),Decimal(0));count+=1
        return str(total/count)

def _honest_closure(claims:tuple[tuple[Pair,...],...])->int:
    n=len(claims);closures=[1<<j for j in range(n)]
    for j,statements in enumerate(claims):
        for person,truth in statements:
            if truth:closures[j]|=1<<(person-1)
    for pivot in range(n):
        for j in range(n):
            if closures[j]>>pivot&1:closures[j]|=closures[pivot]
    negatives=[]
    for closure in closures:
        denied=0
        for j in range(n):
            if closure>>j&1:
                for person,truth in claims[j]:
                    if not truth:denied|=1<<(person-1)
        negatives.append(denied)
    full=(1<<n)-1;best=0
    def visit(honest:int,forbidden:int)->None:
        nonlocal best
        best=max(best,honest.bit_count())
        undecided=full&~(honest|forbidden)
        if not undecided or (honest|undecided).bit_count()<=best:return
        bit=undecided&-undecided;j=bit.bit_length()-1
        added=honest|closures[j];denied=forbidden|negatives[j]
        if not added&denied:visit(added,denied)
        visit(honest,forbidden|bit)
    visit(0,0);return best

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==141:
        n,k,answers=cast(tuple[int,int,tuple[int,...]],data);difference=[0]*(n+1)
        for answer in answers:
            j=answer-1
            if j>0:difference[0]+=1;difference[j]-=1
            if j+1<n:difference[j+1]+=1;difference[n]-=1
        lost=0;result=[]
        for j in range(n):lost+=difference[j];result.append('Yes' if k>lost else 'No')
        return '\n'.join(result)
    if number==142:
        a=cast(tuple[int,...],data[0]);return ' '.join(str(index) for rank,index in sorted((rank,j+1) for j,rank in enumerate(a)))
    if number==144:
        n=cast(int,data[0]);return str(min(d+n//d-2 for d in _divisors(n)))
    if number==145:return _path_average(cast(tuple[Pair,...],data[0]))
    if number==146:
        a,b,x=cast(tuple[int,int,int],data);best=0
        for width in range(1,11):
            candidate=min(10**width-1,10**9,(x-b*width)//a)
            if candidate>=10**(width-1):best=max(best,candidate)
        return str(best)
    return str(_honest_closure(cast(tuple[tuple[Pair,...],...],data[0])))

def _numeric_match(actual:str,expected:str)->bool:
    if len(actual)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',actual) is None:return False
    try:
        a=Decimal(actual);b=Decimal(expected)
        if not a.is_finite() or not b.is_finite() or abs(a.adjusted())>1000:return False
        difference=abs(Fraction(a)-Fraction(b));epsilon=Fraction(1,1000000)
        return difference<=epsilon or difference<=epsilon*abs(Fraction(b))
    except (ValueError,ArithmeticError):return False

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        expected=oracle(pid,raw);actual=actual.removesuffix('\n')
        return _numeric_match(actual,expected) if pid=='abc145_c' else actual==expected
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc145_c':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc141_c':"from collections import Counter\nn,k,q=map(int,input().split());counts=Counter(int(input()) for _ in range(q))\nfor j in range(1,n+1):print('Yes' if k-q+counts[j]>0 else 'No')\n",
'abc142_c':"n=int(input());a=list(map(int,input().split()));order=[0]*n\nfor j,rank in enumerate(a,1):order[rank-1]=j\nprint(*order)\n",
'abc144_c':"from math import isqrt\nn=int(input());d=isqrt(n)\nwhile n%d:d-=1\nprint(d+n//d-2)\n",
'abc145_c':"from math import hypot\nn=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];total=sum(hypot(x-a,y-b) for j,(x,y) in enumerate(points) for a,b in points[j+1:]);print(2*total/n)\n",
'abc146_c':"a,b,x=map(int,input().split());lo=0;hi=1000000001\nwhile hi-lo>1:\n mid=(lo+hi)//2\n if a*mid+b*len(str(mid))<=x:lo=mid\n else:hi=mid\nprint(lo)\n",
'abc147_c':"n=int(input());claims=[]\nfor _ in range(n):\n count=int(input());claims.append([tuple(map(int,input().split())) for _ in range(count)])\nanswer=0\nfor mask in range(1<<n):\n if all((mask>>(person-1)&1)==truth for j,statements in enumerate(claims) if mask>>j&1 for person,truth in statements):answer=max(answer,mask.bit_count())\nprint(answer)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16100+number)
    if number==141:
        def survival(n:int,k:int,answers:list[int])->str:return f'{n} {k} {len(answers)}\n'+''.join(f'{v}\n' for v in answers)
        raws=[survival(2,1,[1]),survival(2,1,[2]),survival(2,2,[1]),survival(2,1,[1,2])]+[survival(n,1+n%4,[rng.randrange(1,n+1) for _ in range(n+2)]) for n in range(3,15)]+[survival(100000,1,[1]*100000),survival(100000,10**9,list(range(1,100001)))]
    elif number==142:
        def permutation(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[permutation([1]),permutation([1,2]),permutation([2,1]),permutation([2,3,1])]
        for n in range(3,16):a=list(range(1,n+1));rng.shuffle(a);raws.append(permutation(a))
        raws.append(permutation(list(range(100000,0,-1))))
    elif number==144:raws=[f'{v}\n' for v in (2,3,4,5,6,7,8,9,10,12,36,999983,10000000019,9999999967,999999999989,999999000000,999999999999,10**12)]
    elif number==145:
        def route(points:list[Pair])->str:return f'{len(points)}\n'+''.join(line(p) for p in points)
        raws=[route([(0,0),(1,0)]),route([(-1000,-1000),(1000,1000)]),route([(0,0),(1,1)]),route([(0,0),(1,0),(0,1)])]
        for j in range(1,14):
            n=2+j%7;points=[]
            while len(points)<n:
                p=(rng.randrange(-1000,1001),rng.randrange(-1000,1001))
                if p not in points:points.append(p)
            raws.append(route(points))
        raws.append(route([(-1000,-1000),(-1000,1000),(1000,-1000),(1000,1000),(0,0),(-999,999),(999,-999),(1000,0)]))
    elif number==146:raws=[line(v) for v in ((1,1,1),(1,1,2),(1,1,10),(1,1,11),(1,1,12),(1,1,100),(1,1,102),(1,1,103),(1,10**9,10**9),(1,10**9,10**9+1),(10**9,1,10**9),(10**9,1,10**9+1),(10**9,10**9,1),(2,1,10**18),(1,1,1000000009),(1,1,1000000010),(10**9,10**9,10**18-1),(10**9,10**9,10**18))]
    else:
        def testimony(claims:list[list[Pair]])->str:return f'{len(claims)}\n'+''.join(f'{len(rows)}\n'+''.join(line(row) for row in rows) for rows in claims)
        raws=[testimony([[]]),testimony([[],[]]),testimony([[(2,1)],[(1,0)]]),testimony([[(2,1)],[(1,1)]])]
        for n in range(3,15):raws.append(testimony([[(j+1,rng.randrange(2)) for j in range(n) if j!=person and rng.randrange(3)==0] for person in range(n)]))
        raws.append(testimony([[] for _ in range(15)]));raws.append(testimony([[(j+1,1) for j in range(15) if j!=person] for person in range(15)]))
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc141_c':('全問題で減る点数と、正解で減らなかった点数を分けます。','参加者iの最終得点はK−Q＋正解数です。0より大きいときに生き残ります。','疑似コード: correct=counts(answerers); for i=1..N: print(Yes if K-Q+correct[i]>0 else No)。'),
'abc142_c':('生徒番号から登校順位への対応を逆にします。','生徒iの値A_iは順位なので、答えのA_i番目にiを書き込みます。','疑似コード: order=[0]*N; for i: order[A[i]-1]=i+1; print(order)。'),
'abc144_c':('到達先の座標は、Nを二つの整数の積に分けたものです。','約数dとN/dの和が最小になるのは、平方根に最も近い約数の組です。','疑似コード: d=isqrt(N); while N%d!=0: d-=1; print(d+N/d-2)。'),
'abc145_c':('二つの町が経路上で隣り合う確率を考えます。','任意の町のペアが隣接する確率は2/Nです。全ペアの距離にこの確率を掛けます。','疑似コード: total=Σ EuclideanDistance(points[i],points[j]) for i<j; print(2*total/N)。'),
'abc146_c':('整数が大きくなると価格は単調に増えます。','0を買えない場合の番兵とし、1から10^9の範囲で二分探索します。','疑似コード: lo=0; hi=10^9+1; while hi-lo>1: mid=(lo+hi)//2; if A*mid+B*digits(mid)<=X: lo=mid; else: hi=mid; print(lo)。'),
'abc147_c':('正直者の集合は2^N通りしかありません。','正直者と仮定した人の証言だけがすべて一致する集合の中で、人数を最大化します。','疑似コード: for honest_mask: if all claims of included persons agree with honest_mask: answer=max(answer,popcount(honest_mask)); print(answer)。')}

TITLES={'abc141_c': 'Attack Survival', 'abc142_c': 'Go to School', 'abc144_c': 'Walk on Multiplication Table', 'abc145_c': 'Average Length', 'abc146_c': 'Buy an Integer', 'abc147_c': 'HonestOrUnkind2'}
PUBLISHED_SAMPLES={'abc141_c': [{'input': '6 3 4\n3\n1\n3\n2\n', 'expected': 'No\nNo\nYes\nNo\nNo\nNo\n'}, {'input': '6 5 4\n3\n1\n3\n2\n', 'expected': 'Yes\nYes\nYes\nYes\nYes\nYes\n'}, {'input': '10 13 15\n3\n1\n4\n1\n5\n9\n2\n6\n5\n3\n5\n8\n9\n7\n9\n', 'expected': 'No\nNo\nNo\nNo\nYes\nNo\nNo\nNo\nYes\nNo\n'}], 'abc142_c': [{'input': '3\n2 3 1\n', 'expected': '3 1 2\n'}, {'input': '5\n1 2 3 4 5\n', 'expected': '1 2 3 4 5\n'}, {'input': '8\n8 2 7 3 4 5 6 1\n', 'expected': '8 2 4 5 6 7 3 1\n'}], 'abc144_c': [{'input': '10\n', 'expected': '5\n'}, {'input': '50\n', 'expected': '13\n'}, {'input': '10000000019\n', 'expected': '10000000018\n'}], 'abc145_c': [{'input': '3\n0 0\n1 0\n0 1\n', 'expected': '2.2761423749\n'}, {'input': '2\n-879 981\n-866 890\n', 'expected': '91.9238815543\n'}, {'input': '8\n-406 10\n512 859\n494 362\n-955 -475\n128 553\n-986 -885\n763 77\n449 310\n', 'expected': '7641.9817824387\n'}], 'abc146_c': [{'input': '10 7 100\n', 'expected': '9\n'}, {'input': '2 1 100000000000\n', 'expected': '1000000000\n'}, {'input': '1000000000 1000000000 100\n', 'expected': '0\n'}, {'input': '1234 56789 314159265\n', 'expected': '254309\n'}], 'abc147_c': [{'input': '3\n1\n2 1\n1\n1 1\n1\n2 0\n', 'expected': '2\n'}, {'input': '3\n2\n2 1\n3 0\n2\n3 1\n1 0\n2\n1 1\n2 0\n', 'expected': '0\n'}, {'input': '2\n1\n2 0\n1\n1 0\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
