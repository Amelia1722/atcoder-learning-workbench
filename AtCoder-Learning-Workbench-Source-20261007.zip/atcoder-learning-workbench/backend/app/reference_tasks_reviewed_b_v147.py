"""Turn 124: reviewed B tasks ABC339 B through ABC356 B.

Public AtCoder statements, constraints, and every published sample were manually reviewed.
Official HTML is not archived/authenticated; entries therefore remain full_size=False.
"""
from __future__ import annotations

import re
from collections import Counter

TASKS = tuple(f"abc{i}_b" for i in range(339, 357))
LANES = {
    "A": ("abc339_b", "abc340_b", "abc341_b"),
    "B": ("abc342_b", "abc343_b", "abc344_b"),
    "C": ("abc345_b", "abc346_b", "abc347_b"),
    "D": ("abc348_b", "abc349_b", "abc350_b"),
    "E": ("abc351_b", "abc352_b", "abc353_b"),
    "F": ("abc354_b", "abc355_b", "abc356_b"),
}
TITLES = {
    "abc339_b": "Langton's Takahashi", "abc340_b": "Append", "abc341_b": "Foreign Exchange",
    "abc342_b": "Which is ahead?", "abc343_b": "Adjacency Matrix", "abc344_b": "Delimiter",
    "abc345_b": "Integer Division Returns", "abc346_b": "Piano", "abc347_b": "Substring",
    "abc348_b": "Farthest Point", "abc349_b": "Commencement", "abc350_b": "Dentist Aoki",
    "abc351_b": "Spot the Difference", "abc352_b": "Typing", "abc353_b": "AtCoder Amusement Park",
    "abc354_b": "AtCoder Janken 2", "abc355_b": "Piano 2", "abc356_b": "Nutrients",
}
INT = re.compile(r"(?:0|[1-9][0-9]*)", re.ASCII)
SINT = re.compile(r"(?:0|-?[1-9][0-9]*)", re.ASCII)
LOWER = re.compile(r"[a-z]+", re.ASCII)

PUBLISHED_SAMPLES = {
"abc339_b":[
{"input":"3 4 5\n","expected":".#..\n##..\n....\n"},
{"input":"2 2 1000\n","expected":"..\n..\n"},
{"input":"10 10 10\n","expected":"##........\n##........\n..........\n..........\n..........\n..........\n..........\n..........\n..........\n#........#\n"}],
"abc340_b":[{"input":"5\n1 20\n1 30\n2 1\n1 40\n2 3\n","expected":"30\n20\n"}],
"abc341_b":[
{"input":"4\n5 7 0 3\n2 2\n4 3\n5 2\n","expected":"5\n"},
{"input":"10\n32 6 46 9 37 8 33 14 31 5\n5 5\n3 1\n4 3\n2 2\n3 2\n3 2\n4 4\n3 3\n3 1\n","expected":"45\n"}],
"abc342_b":[
{"input":"3\n2 1 3\n3\n2 3\n1 2\n1 3\n","expected":"2\n2\n1\n"},
{"input":"7\n3 7 2 1 6 5 4\n13\n2 3\n1 2\n1 3\n3 6\n3 7\n2 4\n3 7\n1 3\n4 7\n1 6\n2 4\n1 3\n1 3\n","expected":"3\n2\n3\n3\n3\n2\n3\n3\n7\n1\n2\n3\n3\n"}],
"abc343_b":[
{"input":"4\n0 1 1 0\n1 0 0 1\n1 0 0 0\n0 1 0 0\n","expected":"2 3\n1 4\n1\n2\n"},
{"input":"2\n0 0\n0 0\n","expected":"\n"},
{"input":"5\n0 1 0 1 1\n1 0 0 1 0\n0 0 0 0 1\n1 1 0 0 1\n1 0 1 1 0\n","expected":"2 4 5\n1 4\n5\n1 2 5\n1 3 4\n"}],
"abc344_b":[
{"input":"3\n2\n1\n0\n","expected":"0\n1\n2\n3\n"},
{"input":"0\n","expected":"0\n"},
{"input":"123\n456\n789\n987\n654\n321\n0\n","expected":"0\n321\n654\n987\n789\n456\n123\n"}],
"abc345_b":[
{"input":"27\n","expected":"3\n"},{"input":"-13\n","expected":"-1\n"},{"input":"40\n","expected":"4\n"},
{"input":"-20\n","expected":"-2\n"},{"input":"123456789123456789\n","expected":"12345678912345679\n"}],
"abc346_b":[
{"input":"3 2\n","expected":"Yes\n"},{"input":"3 0\n","expected":"No\n"},{"input":"92 66\n","expected":"Yes\n"}],
"abc347_b":[
{"input":"yay\n","expected":"5\n"},{"input":"aababc\n","expected":"17\n"},{"input":"abracadabra\n","expected":"54\n"}],
"abc348_b":[
{"input":"4\n0 0\n2 4\n5 0\n3 4\n","expected":"3\n3\n1\n1\n"},
{"input":"6\n3 2\n1 6\n4 5\n1 3\n5 5\n9 8\n","expected":"6\n6\n6\n6\n6\n4\n"}],
"abc349_b":[
{"input":"commencement\n","expected":"Yes\n"},{"input":"banana\n","expected":"No\n"},{"input":"ab\n","expected":"Yes\n"}],
"abc350_b":[
{"input":"30 6\n2 9 18 27 18 9\n","expected":"28\n"},{"input":"1 7\n1 1 1 1 1 1 1\n","expected":"0\n"},
{"input":"9 20\n9 5 1 2 2 2 8 9 2 1 6 2 6 5 8 7 8 5 9 8\n","expected":"5\n"}],
"abc351_b":[
{"input":"3\nabc\ndef\nghi\nabc\nbef\nghi\n","expected":"2 1\n"},{"input":"1\nf\nq\n","expected":"1 1\n"},
{"input":"10\neixfumagit\nvtophbepfe\npxbfgsqcug\nugpugtsxzq\nbvfhxyehfk\nuqyfwtmglr\njaitenfqiq\nacwvufpfvv\njhaddglpva\naacxsyqvoj\neixfumagit\nvtophbepfe\npxbfgsqcug\nugpugtsxzq\nbvfhxyehok\nuqyfwtmglr\njaitenfqiq\nacwvufpfvv\njhaddglpva\naacxsyqvoj\n","expected":"5 9\n"}],
"abc352_b":[
{"input":"abc\naxbxyc\n","expected":"1 3 6\n"},{"input":"aaaa\nbbbbaaaa\n","expected":"5 6 7 8\n"},{"input":"atcoder\natcoder\n","expected":"1 2 3 4 5 6 7\n"}],
"abc353_b":[
{"input":"7 6\n2 5 1 4 1 2 3\n","expected":"4\n"},{"input":"7 10\n1 10 1 10 1 10 1\n","expected":"7\n"},{"input":"15 100\n73 8 55 26 97 48 37 47 35 55 5 17 62 2 60\n","expected":"8\n"}],
"abc354_b":[
{"input":"3\ntakahashi 2\naoki 6\nsnuke 5\n","expected":"snuke\n"},
{"input":"3\ntakahashi 2813\ntakahashixx 1086\ntakahashix 4229\n","expected":"takahashix\n"}],
"abc355_b":[
{"input":"3 2\n3 2 5\n4 1\n","expected":"Yes\n"},{"input":"3 2\n3 1 5\n4 2\n","expected":"No\n"},{"input":"1 1\n1\n2\n","expected":"No\n"}],
"abc356_b":[
{"input":"2 3\n10 20 30\n20 0 10\n0 100 100\n","expected":"Yes\n"},
{"input":"2 4\n10 20 30 40\n20 0 10 30\n0 100 100 0\n","expected":"No\n"}],
}
SAMPLE_COUNTS = {p:len(v) for p,v in PUBLISHED_SAMPLES.items()}


def _lines(raw:str)->list[str]:
    if not isinstance(raw,str) or not raw.endswith("\n") or "\r" in raw: raise ValueError("noncanonical")
    body=raw[:-1]
    if body.endswith("\n"): raise ValueError("extra blank")
    return body.split("\n")

def _ints(line:str,signed=False)->list[int]:
    parts=line.split(" "); pat=SINT if signed else INT
    if not parts or any(pat.fullmatch(x) is None for x in parts) or " ".join(parts)!=line: raise ValueError("integer line")
    return [int(x) for x in parts]

def _one_int(line:str,lo:int,hi:int,signed=False)->int:
    a=_ints(line,signed=signed)
    if len(a)!=1 or not lo<=a[0]<=hi: raise ValueError("integer")
    return a[0]


def validate(pid:str,raw:str):
    l=_lines(raw)
    if pid=="abc339_b":
        a=_ints(l[0]) if len(l)==1 else []
        if len(a)!=3 or not (1<=a[0]<=100 and 1<=a[1]<=100 and 1<=a[2]<=1000): raise ValueError("constraints")
        return tuple(a)
    if pid=="abc340_b":
        if not l: raise ValueError("shape")
        q=_one_int(l[0],1,100)
        if len(l)!=q+1: raise ValueError("Q")
        size=0; qs=[]
        for s in l[1:]:
            a=_ints(s)
            if len(a)!=2 or a[0] not in (1,2): raise ValueError("query")
            if a[0]==1:
                if not 1<=a[1]<=10**9: raise ValueError("x")
                size+=1
            else:
                if not 1<=a[1]<=size: raise ValueError("k")
            qs.append(tuple(a))
        return q,tuple(qs)
    if pid=="abc341_b":
        if len(l)<3: raise ValueError("shape")
        n=_one_int(l[0],2,200000); A=_ints(l[1])
        if len(A)!=n or any(not 0<=x<=10**9 for x in A) or len(l)!=n+1: raise ValueError("A")
        st=[]
        for s in l[2:]:
            a=_ints(s)
            if len(a)!=2 or not 1<=a[1]<=a[0]<=10**9: raise ValueError("ST")
            st.append(tuple(a))
        return n,tuple(A),tuple(st)
    if pid=="abc342_b":
        if len(l)<4: raise ValueError("shape")
        n=_one_int(l[0],1,100); p=_ints(l[1])
        if len(p)!=n or sorted(p)!=list(range(1,n+1)): raise ValueError("P")
        q=_one_int(l[2],1,100)
        if len(l)!=q+3: raise ValueError("Q")
        qs=[]
        for s in l[3:]:
            a=_ints(s)
            if len(a)!=2 or not 1<=a[0]<a[1]<=n: raise ValueError("query")
            qs.append(tuple(a))
        return n,tuple(p),q,tuple(qs)
    if pid=="abc343_b":
        n=_one_int(l[0],2,100) if l else 0
        if len(l)!=n+1: raise ValueError("N")
        mat=[]
        for s in l[1:]:
            a=_ints(s)
            if len(a)!=n or any(x not in (0,1) for x in a): raise ValueError("row")
            mat.append(tuple(a))
        for i in range(n):
            if mat[i][i]!=0: raise ValueError("diag")
            for j in range(n):
                if mat[i][j]!=mat[j][i]: raise ValueError("sym")
        return n,tuple(mat)
    if pid=="abc344_b":
        if not 1<=len(l)<=100: raise ValueError("N")
        a=[]
        for s in l: a.append(_one_int(s,0,10**9))
        if a[-1]!=0 or any(x==0 for x in a[:-1]): raise ValueError("terminator")
        return (tuple(a),)
    if pid=="abc345_b": return (_one_int(l[0],-10**18,10**18,signed=True),) if len(l)==1 else (_ for _ in ()).throw(ValueError("shape"))
    if pid=="abc346_b":
        a=_ints(l[0]) if len(l)==1 else []
        if len(a)!=2 or not (0<=a[0]<=100 and 0<=a[1]<=100 and a[0]+a[1]>=1): raise ValueError("WB")
        return tuple(a)
    if pid=="abc347_b":
        if len(l)!=1 or LOWER.fullmatch(l[0]) is None or not 1<=len(l[0])<=100: raise ValueError("S")
        return (l[0],)
    if pid=="abc348_b":
        n=_one_int(l[0],2,100) if l else 0
        if len(l)!=n+1: raise ValueError("N")
        pts=[]
        for s in l[1:]:
            a=_ints(s,signed=True)
            if len(a)!=2 or any(not -1000<=x<=1000 for x in a): raise ValueError("point")
            pts.append(tuple(a))
        if len(set(pts))!=n: raise ValueError("distinct")
        return n,tuple(pts)
    if pid=="abc349_b":
        if len(l)!=1 or LOWER.fullmatch(l[0]) is None or not 1<=len(l[0])<=100: raise ValueError("S")
        return (l[0],)
    if pid=="abc350_b":
        if len(l)!=2: raise ValueError("shape")
        nq=_ints(l[0]); t=_ints(l[1])
        if len(nq)!=2 or not (1<=nq[0]<=1000 and 1<=nq[1]<=1000) or len(t)!=nq[1] or any(not 1<=x<=nq[0] for x in t): raise ValueError("constraints")
        return nq[0],nq[1],tuple(t)
    if pid=="abc351_b":
        n=_one_int(l[0],1,100) if l else 0
        if len(l)!=1+2*n: raise ValueError("shape")
        A=tuple(l[1:1+n]); B=tuple(l[1+n:])
        if any(len(s)!=n or LOWER.fullmatch(s) is None for s in A+B): raise ValueError("grid")
        diffs=sum(A[i][j]!=B[i][j] for i in range(n) for j in range(n))
        if diffs!=1: raise ValueError("diff count")
        return n,A,B
    if pid=="abc352_b":
        if len(l)!=2 or any(LOWER.fullmatch(s) is None or not 1<=len(s)<=200000 for s in l): raise ValueError("strings")
        s,t=l
        it=iter(t)
        if not all(any(ch==x for ch in it) for x in s): raise ValueError("not subsequence")
        return s,t
    if pid=="abc353_b":
        if len(l)!=2: raise ValueError("shape")
        nk=_ints(l[0]); a=_ints(l[1])
        if len(nk)!=2 or not(1<=nk[0]<=100 and 1<=nk[1]<=100) or len(a)!=nk[0] or any(not 1<=x<=nk[1] for x in a): raise ValueError("constraints")
        return nk[0],nk[1],tuple(a)
    if pid=="abc354_b":
        n=_one_int(l[0],1,100) if l else 0
        if len(l)!=n+1: raise ValueError("N")
        rows=[]; names=[]
        for s in l[1:]:
            p=s.split(" ")
            if len(p)!=2 or LOWER.fullmatch(p[0]) is None or not 3<=len(p[0])<=16 or INT.fullmatch(p[1]) is None or not 1<=int(p[1])<=4229: raise ValueError("row")
            rows.append((p[0],int(p[1]))); names.append(p[0])
        if len(set(names))!=n: raise ValueError("names")
        return n,tuple(rows)
    if pid=="abc355_b":
        if len(l)!=3: raise ValueError("shape")
        nm=_ints(l[0]); A=_ints(l[1]); B=_ints(l[2])
        if len(nm)!=2 or not(1<=nm[0]<=100 and 1<=nm[1]<=100) or len(A)!=nm[0] or len(B)!=nm[1] or any(not 1<=x<=200 for x in A+B) or len(set(A+B))!=len(A)+len(B): raise ValueError("constraints")
        return nm[0],nm[1],tuple(A),tuple(B)
    if pid=="abc356_b":
        if len(l)<3: raise ValueError("shape")
        nm=_ints(l[0]);
        if len(nm)!=2 or not(1<=nm[0]<=100 and 1<=nm[1]<=100) or len(l)!=nm[0]+2: raise ValueError("NM")
        A=_ints(l[1]);
        if len(A)!=nm[1] or any(not 0<=x<=10**7 for x in A): raise ValueError("A")
        X=[]
        for s in l[2:]:
            row=_ints(s)
            if len(row)!=nm[1] or any(not 0<=x<=10**7 for x in row): raise ValueError("X")
            X.append(tuple(row))
        return nm[0],nm[1],tuple(A),tuple(X)
    raise KeyError(pid)


def _oracle(pid:str,data)->str:
    if pid=="abc339_b":
        H,W,N=data; g=[[0]*W for _ in range(H)]; r=c=d=0; dr=(-1,0,1,0); dc=(0,1,0,-1)
        for _ in range(N):
            if g[r][c]==0: g[r][c]=1; d=(d+1)%4
            else: g[r][c]=0; d=(d-1)%4
            r=(r+dr[d])%H; c=(c+dc[d])%W
        return "\n".join("".join("#" if x else "." for x in row) for row in g)
    if pid=="abc340_b":
        _,qs=data; a=[]; out=[]
        for t,x in qs:
            if t==1:a.append(x)
            else:out.append(str(a[len(a)-x]))
        return "\n".join(out)
    if pid=="abc341_b":
        n,A,st=data; a=list(A)
        for i,(s,t) in enumerate(st): a[i+1]+=a[i]//s*t
        return str(a[-1])
    if pid=="abc342_b":
        n,p,q,qs=data; pos={x:i for i,x in enumerate(p)}
        return "\n".join(str(a if pos[a]<pos[b] else b) for a,b in qs)
    if pid=="abc343_b":
        n,m=data; return "\n".join(" ".join(str(j+1) for j,x in enumerate(m[i]) if x) for i in range(n))
    if pid=="abc344_b": return "\n".join(map(str,reversed(data[0])))
    if pid=="abc345_b": return str(-(-data[0]//10))
    if pid=="abc346_b":
        w,b=data; L=w+b; s=("wbwbwwbwbwbw"*((L+24)//12+2))
        return "Yes" if any(seg.count("w")==w for seg in (s[i:i+L] for i in range(12))) else "No"
    if pid=="abc347_b":
        s=data[0]; return str(len({s[i:j] for i in range(len(s)) for j in range(i+1,len(s)+1)}))
    if pid=="abc348_b":
        n,pts=data; out=[]
        for i,(x,y) in enumerate(pts):
            best=(-1,0)
            for j,(u,v) in enumerate(pts):
                if i==j: continue
                d=(x-u)**2+(y-v)**2
                if d>best[0]: best=(d,j)
            out.append(str(best[1]+1))
        return "\n".join(out)
    if pid=="abc349_b":
        f=Counter(data[0]); g=Counter(f.values()); return "Yes" if all(v==2 for v in g.values()) else "No"
    if pid=="abc350_b":
        n,q,t=data; state=[1]*n
        for x in t: state[x-1]^=1
        return str(sum(state))
    if pid=="abc351_b":
        n,A,B=data
        for i in range(n):
            for j in range(n):
                if A[i][j]!=B[i][j]: return f"{i+1} {j+1}"
    if pid=="abc352_b":
        s,t=data; out=[]; j=0
        for i,ch in enumerate(t,1):
            if j<len(s) and ch==s[j]: out.append(str(i)); j+=1
        return " ".join(out)
    if pid=="abc353_b":
        n,k,a=data; rides=1; cur=0
        for x in a:
            if cur+x>k: rides+=1; cur=0
            cur+=x
        return str(rides)
    if pid=="abc354_b":
        n,rows=data; names=sorted(s for s,_ in rows); return names[sum(c for _,c in rows)%n]
    if pid=="abc355_b":
        n,m,A,B=data; aset=set(A); c=sorted(A+B)
        return "Yes" if any(c[i] in aset and c[i+1] in aset for i in range(len(c)-1)) else "No"
    if pid=="abc356_b":
        n,m,A,X=data; sums=[sum(row[j] for row in X) for j in range(m)]
        return "Yes" if all(sums[j]>=A[j] for j in range(m)) else "No"
    raise KeyError(pid)


def independent_check(pid:str,raw:str,actual:str)->bool:
    try: data=validate(pid,raw)
    except (ValueError,KeyError): return False
    oracle=_oracle(pid,data)
    if pid=="abc343_b" and not oracle.strip() and not actual.strip():
        return True
    return actual==oracle

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    try: data=validate(pid,raw)
    except ValueError: return False
    if pid=="abc343_b" and not _oracle(pid,data).strip() and not expected.strip() and not stdout.strip():
        return True
    return stdout==expected and independent_check(pid,raw,expected.removesuffix("\n"))


def _raw339(h,w,n): return f"{h} {w} {n}\n"
def _raw340(qs): return str(len(qs))+"\n"+"\n".join(f"{t} {x}" for t,x in qs)+"\n"
def _raw341(A,st): return f"{len(A)}\n"+" ".join(map(str,A))+"\n"+"\n".join(f"{s} {t}" for s,t in st)+"\n"
def _raw342(p,qs): return f"{len(p)}\n"+" ".join(map(str,p))+f"\n{len(qs)}\n"+"\n".join(f"{a} {b}" for a,b in qs)+"\n"
def _raw343(mat): return f"{len(mat)}\n"+"\n".join(" ".join(map(str,r)) for r in mat)+"\n"
def _raw348(pts): return f"{len(pts)}\n"+"\n".join(f"{x} {y}" for x,y in pts)+"\n"
def _raw351(A,B): return f"{len(A)}\n"+"\n".join(A+B)+"\n"
def _raw354(rows): return f"{len(rows)}\n"+"\n".join(f"{s} {c}" for s,c in rows)+"\n"
def _name(i:int)->str:
    x=i; out=[]
    for _ in range(4): out.append(chr(97+x%26)); x//=26
    return "usr"+"".join(reversed(out))


def _make_cases(pid:str)->list[dict[str,str]]:
    raws=[]
    if pid=="abc339_b":
        vals=[(1,1,1),(1,2,1),(2,1,2),(2,2,3),(3,3,4),(3,4,5),(4,3,6),(5,5,7),(2,3,12),(3,2,13),(10,1,20),(1,10,21),(7,8,50),(8,7,51),(10,10,99),(20,30,200),(50,50,999),(100,100,1000)]
        raws=[_raw339(*v) for v in vals]
    elif pid=="abc340_b":
        patterns=[[(1,i+1),(2,1)] for i in range(16)]
        patterns+=[[(1,1),(1,2),(2,2)],[(1,10),(1,20),(1,30),(2,1),(2,3)]]
        patterns[-1]=[(1,i+1) for i in range(60)]+[(2,(i%60)+1) for i in range(40)]
        raws=[_raw340(x) for x in patterns]
    elif pid=="abc341_b":
        for k in range(17):
            n=2+(k%5); A=[(k+i*3)%20 for i in range(n)]; st=[(2+(i%3),1+(i%2)) for i in range(n-1)]
            raws.append(_raw341(A,st))
        n=200000; raws.append(_raw341([10**9]*n,[(10**9,10**9)]*(n-1)))
    elif pid=="abc342_b":
        for k in range(17):
            n=20; p=list(range(1,n+1)); r=k+1; p=p[r:]+p[:r]; qs=[(1,20),(1+(k%9),10+(k%10))]
            qs=[(min(a,b),max(a,b)) for a,b in qs]
            raws.append(_raw342(p,qs))
        p=list(range(100,0,-1)); qs=[(i,100) for i in range(1,100)]+[(1,2)]; raws.append(_raw342(p,qs))
    elif pid=="abc343_b":
        for k in range(17):
            n=k+2; m=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    if (i+j+k)%3==0:m[i][j]=m[j][i]=1
            raws.append(_raw343(m))
        n=100; m=[[0 if i==j else 1 for j in range(n)] for i in range(n)]; raws.append(_raw343(m))
    elif pid=="abc344_b":
        seqs=[[0],[1,0],[2,1,0],[10,20,0],[10**9,0]]+[[k+1,k+2,k+3,0] for k in range(12)]
        seqs=seqs[:17]+[list(range(1,100))+[0]]; raws=["\n".join(map(str,s))+"\n" for s in seqs]
    elif pid=="abc345_b":
        vals=[0,1,9,10,11,-1,-9,-10,-11,27,-13,40,-20,99,-99,10**18-1,-10**18,10**18]; raws=[f"{x}\n" for x in vals]
    elif pid=="abc346_b":
        vals=[(1,0),(0,1),(1,1),(2,1),(3,2),(3,0),(0,3),(5,3),(6,4),(7,5),(10,7),(20,15),(30,22),(50,35),(70,50),(92,66),(100,99),(100,100)]; raws=[f"{w} {b}\n" for w,b in vals]
    elif pid=="abc347_b":
        vals=["a","aa","ab","aba","abc","yay","aaaaa","aababc","abcabc","zzzzzz","abcdef","abacaba","banana","mississippi","abcdefghijklmnopqrst","xyzxyzxyz","a"*99,"abcdefghijklmnopqrstuvwxyz"*3+"abcdefghijklmnopqrstuv"]
        raws=[s+"\n" for s in vals]
    elif pid=="abc348_b":
        for k in range(17):
            n=2+(k%8); pts=[(i-k,(i*i+3*k)%101-50) for i in range(n)]; raws.append(_raw348(pts))
        pts=[(-1000+i*20, -1000+((i*37)%100)*20) for i in range(100)]; raws.append(_raw348(pts))
    elif pid=="abc349_b":
        vals=["a","ab","aa","aabb","abc","aabbcc","abbccc","aabbcccddd","commencement","banana","zz","abcabc","aabbccddeeff","aaaabbbb","aaaabbbbccccdddd","abababab","abcdefghijklmnopqrstuvwxxy","aabbccddeeffgghhiijjkkllmmnnooppqqrrssttuuvvwwxxyy"]
        vals[-1]=(vals[-1]*2)[:100]; raws=[s+"\n" for s in vals]
    elif pid=="abc350_b":
        for k in range(17):
            n=1+(k%10); q=1+(k%12); t=[1+(i+k)%n for i in range(q)]; raws.append(f"{n} {q}\n"+" ".join(map(str,t))+"\n")
        t=[1+(i%1000) for i in range(1000)]; raws.append("1000 1000\n"+" ".join(map(str,t))+"\n")
    elif pid=="abc351_b":
        for k in range(17):
            n=k+1; A=["a"*n for _ in range(n)]; B=A.copy(); r=k%n;c=(k*3)%n; row=list(B[r]);row[c]="b";B[r]="".join(row); raws.append(_raw351(A,B))
        n=100; A=["a"*n for _ in range(n)]; B=A.copy(); B[-1]="a"*99+"z"; raws.append(_raw351(A,B))
    elif pid=="abc352_b":
        pairs=[("a","a"),("a","ba"),("ab","axb"),("abc","axbxyc"),("aaaa","bbbbaaaa"),("abc","abc"),("az","a"*5+"z"),("xyz","xaybz"),("aba","aaabbbba"),("hello","hxealllo"),("atcoder","atcoder"),("abcde","aabbccddee"),("zz","azbz"),("mnop","mxxnxxoxxp"),("abc","zzabczz"),("aaaaa","aaaaaaaaaa"),("abcd","abcdddd")]
        raws=[s+"\n"+t+"\n" for s,t in pairs]
        s="a"*200000; raws.append(s+"\n"+s+"\n")
    elif pid=="abc353_b":
        for k in range(17):
            n=1+(k%12); cap=1+(k%20); a=[1+((i+k)%cap) for i in range(n)]; raws.append(f"{n} {cap}\n"+" ".join(map(str,a))+"\n")
        raws.append("100 100\n"+" ".join(["100"]*100)+"\n")
    elif pid=="abc354_b":
        for k in range(17):
            n=1+(k%8); rows=[(_name(i+k*10),1+(i*17+k)%4229) for i in range(n)]; raws.append(_raw354(rows))
        rows=[(_name(i),4229) for i in range(100)]; raws.append(_raw354(rows))
    elif pid=="abc355_b":
        for k in range(17):
            n=k+1; m=1; A=list(range(1,n+1)); B=[200-k]
            if B[0] in A: B=[199-k]
            raws.append(f"{n} {m}\n"+" ".join(map(str,A))+"\n"+" ".join(map(str,B))+"\n")
        A=list(range(1,101));B=list(range(101,201)); raws.append(f"100 100\n"+" ".join(map(str,A))+"\n"+" ".join(map(str,B))+"\n")
    elif pid=="abc356_b":
        for k in range(17):
            n=1+(k%5);m=1+((k+1)%5); A=[k%10+j for j in range(m)]; X=[[((i+j+k)*3)%20 for j in range(m)] for i in range(n)]
            raws.append(f"{n} {m}\n"+" ".join(map(str,A))+"\n"+"\n".join(" ".join(map(str,r)) for r in X)+"\n")
        n=m=100; A=[10**7]*m; X=[[10**7]*m for _ in range(n)]; raws.append(f"{n} {m}\n"+" ".join(map(str,A))+"\n"+"\n".join(" ".join(map(str,r)) for r in X)+"\n")
    else: raise KeyError(pid)
    if len(raws)!=18 or len(set(raws))!=18: raise ValueError(f"{pid}: generator did not produce 18 distinct")
    return [{"category":("constraint_max" if i==17 else f"case_{i+1:02d}"),"input":r} for i,r in enumerate(raws)]

def generate(pid:str)->list[dict[str,str]]: return _make_cases(pid)

REFERENCE_CODE = {
"abc339_b":'''H,W,N=map(int,input().split())\ng=[[0]*W for _ in range(H)]\nr=c=d=0\ndr=(-1,0,1,0);dc=(0,1,0,-1)\nfor _ in range(N):\n if g[r][c]==0:g[r][c]=1;d=(d+1)%4\n else:g[r][c]=0;d=(d-1)%4\n r=(r+dr[d])%H;c=(c+dc[d])%W\nfor row in g:print(''.join('#' if x else '.' for x in row))\n''',
"abc340_b":'''Q=int(input());a=[]\nfor _ in range(Q):\n q=list(map(int,input().split()))\n if q[0]==1:a.append(q[1])\n else:print(a[-q[1]])\n''',
"abc341_b":'''N=int(input());A=list(map(int,input().split()))\nfor i in range(N-1):\n s,t=map(int,input().split());A[i+1]+=A[i]//s*t\nprint(A[-1])\n''',
"abc342_b":'''N=int(input());P=list(map(int,input().split()));pos=[0]*(N+1)\nfor i,x in enumerate(P):pos[x]=i\nQ=int(input())\nfor _ in range(Q):\n a,b=map(int,input().split());print(a if pos[a]<pos[b] else b)\n''',
"abc343_b":'''N=int(input());A=[list(map(int,input().split())) for _ in range(N)]\nfor i in range(N):print(*[j+1 for j in range(N) if A[i][j]])\n''',
"abc344_b":'''import sys\na=list(map(int,sys.stdin.read().split()))\nprint(*a[::-1],sep='\\n')\n''',
"abc345_b":'''X=int(input());print(-(-X//10))\n''',
"abc346_b":'''W,B=map(int,input().split());L=W+B;s='wbwbwwbwbwbw'*30\nprint('Yes' if any(s[i:i+L].count('w')==W for i in range(12)) else 'No')\n''',
"abc347_b":'''S=input();print(len({S[i:j] for i in range(len(S)) for j in range(i+1,len(S)+1)}))\n''',
"abc348_b":'''N=int(input());P=[tuple(map(int,input().split())) for _ in range(N)]\nfor i,(x,y) in enumerate(P):\n best=-1;ans=0\n for j,(u,v) in enumerate(P):\n  d=(x-u)**2+(y-v)**2\n  if d>best:best=d;ans=j\n print(ans+1)\n''',
"abc349_b":'''from collections import Counter\nS=input();c=Counter(S);f=Counter(c.values());print('Yes' if all(v==2 for v in f.values()) else 'No')\n''',
"abc350_b":'''N,Q=map(int,input().split());T=list(map(int,input().split()));s=[1]*N\nfor x in T:s[x-1]^=1\nprint(sum(s))\n''',
"abc351_b":'''N=int(input());A=[input() for _ in range(N)];B=[input() for _ in range(N)]\nfor i in range(N):\n for j in range(N):\n  if A[i][j]!=B[i][j]:print(i+1,j+1);raise SystemExit\n''',
"abc352_b":'''S=input();T=input();j=0;ans=[]\nfor i,ch in enumerate(T,1):\n if j<len(S) and ch==S[j]:ans.append(i);j+=1\nprint(*ans)\n''',
"abc353_b":'''N,K=map(int,input().split());A=list(map(int,input().split()));ans=1;cur=0\nfor x in A:\n if cur+x>K:ans+=1;cur=0\n cur+=x\nprint(ans)\n''',
"abc354_b":'''N=int(input());a=[];tot=0\nfor _ in range(N):\n s,c=input().split();a.append(s);tot+=int(c)\na.sort();print(a[tot%N])\n''',
"abc355_b":'''N,M=map(int,input().split());A=list(map(int,input().split()));B=list(map(int,input().split()));sa=set(A);C=sorted(A+B)\nprint('Yes' if any(C[i] in sa and C[i+1] in sa for i in range(len(C)-1)) else 'No')\n''',
"abc356_b":'''N,M=map(int,input().split());A=list(map(int,input().split()));s=[0]*M\nfor _ in range(N):\n row=list(map(int,input().split()))\n for j,x in enumerate(row):s[j]+=x\nprint('Yes' if all(s[j]>=A[j] for j in range(M)) else 'No')\n''',
}
