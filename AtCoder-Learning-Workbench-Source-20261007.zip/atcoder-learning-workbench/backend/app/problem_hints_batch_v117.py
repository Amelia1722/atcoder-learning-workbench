"""Statement-checked three-stage hints for ABC209–211 B."""
HINTS_V117 = {
    'abc209_b': (
        '偶数番目の商品だけ1円引きです。まず全商品を買うのに実際いくら必要かを計算してください。',
        '1-indexedでiが偶数ならA_i-1円、奇数ならA_i円です。必要額の合計が所持金X以下ならYesです。',
        '''疑似コード:
total = 0
for i = 1..N:
  total += A[i]
  if i is even:
    total -= 1
if total <= X:
  print("Yes")
else:
  print("No")''',
    ),
    'abc210_b': (
        '勝敗が決まるのは、山札の上から最初に現れる悪いカード「1」です。',
        '最初の1が1,3,5,...枚目なら高橋君の手番、2,4,6,...枚目なら青木君の手番です。そのカードを引いた人が負けます。',
        '''疑似コード:
for i = 0..N-1:
  if S[i] == "1":
    if i is even:
      print("Takahashi")
    else:
      print("Aoki")
    stop''',
    ),
    'abc211_b': (
        '必要な4種類は H, 2B, 3B, HR です。4入力に重複や欠落がないかを確認します。',
        '入力は必ずこの4種類のどれかなので、4個をsetに入れて種類数が4なら各1個ずつ、4未満なら重複があります。',
        '''疑似コード:
seen = empty set
repeat 4 times:
  read S
  add S to seen
if size(seen) == 4:
  print("Yes")
else:
  print("No")''',
    ),
}
