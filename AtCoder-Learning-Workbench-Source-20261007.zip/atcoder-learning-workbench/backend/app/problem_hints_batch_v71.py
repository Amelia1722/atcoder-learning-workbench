"""Hints based on the public official statements of ABC071–073 B."""
HINTS_V71 = {
    'abc071_b': (
        '英小文字は26種類しかありません。Sに含まれる文字を記録し、aから順に「含まれない文字」を探してください。',
        'Sをsetにして、`abcdefghijklmnopqrstuvwxyz`を先頭から確認します。最初にsetへ無い文字が答えで、26文字すべてある場合だけNoneです。',
        '''疑似コード:\npresent=set(S)\nfor c in 'abcdefghijklmnopqrstuvwxyz':\n  if c not in present:\n    print(c); stop\nprint('None')''',
    ),
    'abc072_b': (
        '先頭を1文字目と数えるので、欲しいのは1,3,5,...文字目です。Pythonの0-indexではどの添字になりますか。',
        '0-indexでは0,2,4,...番目です。スライスなら開始0・刻み2でそのまま取り出せます。',
        '''疑似コード:\nanswer = S[0::2]\nprint(answer)''',
    ),
    'abc073_b': (
        '各団体が使う席はl_iからr_iまで両端を含みます。1団体あたり何席かをまず式にしてください。',
        '区間[l_i,r_i]の席数は `r_i-l_i+1` です。同じ席に複数人はいないので、全団体についてその長さを足すだけです。',
        '''疑似コード:\nanswer=0\nrepeat N times:\n  read l,r\n  answer += r-l+1\nprint(answer)''',
    ),
}
