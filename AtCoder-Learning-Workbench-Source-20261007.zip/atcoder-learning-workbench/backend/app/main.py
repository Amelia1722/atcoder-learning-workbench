from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from .database import get_setting, init_db, set_setting
from .atlas_state import AtlasState, load_state, store_state
from .learning_lab import init_lab, init_lab_extensions
from .problem_hints import init_hint_progress
from .learning_lab_routes import router as learning_lab_router
from .models import NoteUpdate, UserSettings
from .seed import ensure_seeded
from .service import (
    bootstrap_status, cancel_timer, get_or_fetch_source, get_problem, get_problem_rows,
    get_knowledge_audit, get_recommendations, get_stats, list_knowledge, list_roadmap, start_timer,
    sync_external_tags, sync_problem_catalog, sync_submissions, update_note,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    ensure_seeded()
    from .public_catalog import initialize_public_catalog
    initialize_public_catalog()
    init_lab()
    init_lab_extensions()
    init_hint_progress()
    yield


app = FastAPI(title="AtCoder Learning Workbench", version="0.2.0", lifespan=lifespan)
app.include_router(learning_lab_router)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"], allow_headers=["*"], allow_credentials=True,
)


@app.get("/api/health")
def health():
    return {"ok": True, "time": int(time.time())}


@app.get("/api/settings")
def settings():
    return {"user_id": get_setting("user_id", "")}


@app.put("/api/settings")
def save_settings(payload: UserSettings):
    set_setting("user_id", payload.user_id.strip())
    return {"user_id": payload.user_id.strip()}


@app.get("/api/bootstrap")
def bootstrap(user_id: str = ""):
    return bootstrap_status(user_id)


@app.post("/api/sync/problems")
async def sync_problems():
    try:
        return await sync_problem_catalog()
    except Exception as e:
        raise HTTPException(502, f"problem sync failed: {e}")


@app.post("/api/sync/tags")
async def sync_tags():
    try:
        return await sync_external_tags()
    except Exception as e:
        # Optional enrichment source: expose the failure, but do not damage local data.
        raise HTTPException(502, f"tag enrichment failed: {e}")


@app.post("/api/sync/submissions")
async def sync_user_submissions(user_id: str, problem_id: str = "", force: bool = False):
    try:
        return await sync_submissions(user_id, problem_id, force)
    except Exception as e:
        raise HTTPException(502, f"submission sync failed: {e}")


@app.get("/api/problems")
def problems(user_id: str = "", contest_max: int | None = None):
    return get_problem_rows(user_id, contest_max)


@app.get("/api/problems/{problem_id}")
def problem(problem_id: str, user_id: str = ""):
    item = get_problem(problem_id, user_id)
    if not item:
        raise HTTPException(404, "problem not found")
    return item


@app.get("/api/recommendations")
def recommendations(user_id: str = "", limit: int = Query(30, ge=1, le=200)):
    return get_recommendations(user_id, limit)


@app.get("/api/stats")
def stats(user_id: str = ""):
    return get_stats(user_id)


@app.get("/api/knowledge")
def knowledge(q: str = "", limit: int = Query(1200, ge=1, le=1200)):
    return list_knowledge(q, limit)


@app.get("/api/knowledge/audit")
def knowledge_audit():
    return get_knowledge_audit()


@app.get("/api/roadmap")
def roadmap(user_id: str = ""):
    return list_roadmap(user_id)


@app.post("/api/timer/{problem_id}/start")
def timer_start(problem_id: str, user_id: str):
    if not user_id.strip():
        raise HTTPException(400, "user_id is required")
    return start_timer(user_id, problem_id)


@app.post("/api/timer/{problem_id}/cancel")
def timer_cancel(problem_id: str, user_id: str):
    cancel_timer(user_id, problem_id)
    return {"ok": True}


@app.get("/api/submissions/{submission_id}/source")
async def submission_source(submission_id: int):
    try:
        return await get_or_fetch_source(submission_id)
    except KeyError:
        raise HTTPException(404, "submission not found")
    except Exception as e:
        raise HTTPException(502, f"source fetch failed: {e}")


@app.put("/api/problems/{problem_id}/note")
def note(problem_id: str, user_id: str, payload: NoteUpdate):
    if not user_id.strip():
        raise HTTPException(400, "user_id is required")
    update_note(user_id, problem_id, payload.note)
    return {"ok": True}


@app.get("/api/atlas/state")
def atlas_state_get(user_id: str):
    return load_state(user_id)


@app.put("/api/atlas/state")
def atlas_state_put(user_id: str, payload: AtlasState):
    return store_state(user_id, payload)
