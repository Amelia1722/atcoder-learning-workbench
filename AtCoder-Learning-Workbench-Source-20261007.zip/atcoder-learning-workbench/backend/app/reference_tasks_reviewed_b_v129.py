"""ABC245–247 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from collections import Counter
from decimal import Decimal, InvalidOperation, localcontext
import re

TASKS = ('abc245_b', 'abc246_b', 'abc247_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc245_b': [
        {'input': '8\n0 3 2 6 2 1 0 0\n', 'expected': '4\n'},
        {'input': '3\n2000 2000 2000\n', 'expected': '0\n'},
    ],
    'abc246_b': [
        {'input': '3 4\n', 'expected': '0.600000000000 0.800000000000\n'},
        {'input': '1 0\n', 'expected': '1.000000000000 0.000000000000\n'},
        {'input': '246 402\n', 'expected': '0.521964870245 0.852966983083\n'},
    ],
    'abc247_b': [
        {'input': '3\ntanaka taro\ntanaka jiro\nsuzuki hanako\n', 'expected': 'Yes\n'},
        {'input': '3\naaa bbb\nxxx aaa\nbbb yyy\n', 'expected': 'No\n'},
        {'input': '2\ntanaka taro\ntanaka taro\n', 'expected': 'No\n'},
        {'input': '3\ntakahashi chokudai\naoki kensho\nsnu ke\n', 'expected': 'Yes\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _row(line: str, count: int, pattern: re.Pattern[str]) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate245(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 2000:
        raise ValueError('N')
    a = _row(lines[1], n, NONNEG)
    if any(not 0 <= x <= 2000 for x in a):
        raise ValueError('A')
    return tuple(a)


def _validate246(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    a, b = _row(lines[0], 2, NONNEG)
    if not (0 <= a <= 1000 and 0 <= b <= 1000) or (a == 0 and b == 0):
        raise ValueError('A/B')
    return a, b


def _validate247(raw: str):
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N')
    n = int(lines[0])
    if not 2 <= n <= 100 or len(lines) != n + 1:
        raise ValueError('N/shape')
    pairs = []
    for line in lines[1:]:
        parts = line.split(' ')
        if len(parts) != 2 or any(LOWER.fullmatch(x) is None or not 1 <= len(x) <= 10 for x in parts):
            raise ValueError('name row')
        pairs.append((parts[0], parts[1]))
    return tuple(pairs)


def validate(pid: str, raw: str):
    if pid == 'abc245_b':
        return _validate245(raw)
    if pid == 'abc246_b':
        return _validate246(raw)
    if pid == 'abc247_b':
        return _validate247(raw)
    raise ValueError('unknown task')


def _within(actual: Decimal, truth: Decimal) -> bool:
    tol = Decimal('1e-6')
    diff = abs(actual - truth)
    return diff <= tol or diff <= abs(truth) * tol


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc245_b':
        present = sorted(set(value))
        expected = 0
        for x in present:
            if x == expected:
                expected += 1
            elif x > expected:
                break
        return NONNEG.fullmatch(output) is not None and int(output) == expected

    if pid == 'abc246_b':
        parts = output.split(' ')
        if len(parts) != 2:
            return False
        try:
            ox, oy = map(Decimal, parts)
        except InvalidOperation:
            return False
        if not ox.is_finite() or not oy.is_finite():
            return False
        a, b = value
        with localcontext() as ctx:
            ctx.prec = 90
            norm = (Decimal(a * a + b * b)).sqrt()
            tx = Decimal(a) / norm
            ty = Decimal(b) / norm
        return _within(ox, tx) and _within(oy, ty)

    pairs = value
    for i, (s, t) in enumerate(pairs):
        def usable(name: str) -> bool:
            return all(i == j or (name != sj and name != tj) for j, (sj, tj) in enumerate(pairs))
        if not (usable(s) or usable(t)):
            return output == 'No'
    return output == 'Yes'


def _case245(a: list[int]) -> str:
    return f'{len(a)}\n' + ' '.join(map(str, a)) + '\n'


def _case247(pairs: list[tuple[str, str]]) -> str:
    return f'{len(pairs)}\n' + ''.join(f'{s} {t}\n' for s, t in pairs)


def _alpha_name(prefix: str, i: int) -> str:
    return prefix + chr(ord('a') + (i // 26) % 26) + chr(ord('a') + i % 26)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc245_b':
        cases = [
            ('single_zero', _case245([0])),
            ('single_one', _case245([1])),
            ('all_zero', _case245([0, 0, 0, 0])),
            ('no_zero', _case245([1, 2, 3, 4, 5])),
            ('missing_one', _case245([0, 2, 3, 4])),
            ('missing_middle', _case245([0, 1, 2, 4, 5, 6])),
            ('consecutive_ten', _case245(list(range(10)))),
            ('duplicates_below_mex', _case245([0, 1, 1, 2, 2, 3, 3, 7])),
            ('only_max', _case245([2000])),
            ('mixed_extremes', _case245([0, 2000, 1999, 1, 3, 3, 4])),
            ('n100_missing50', _case245([x for x in range(101) if x != 50])),
            ('n500_repeats', _case245([i % 25 for i in range(500)])),
            ('n1000_even_only', _case245([2 * i for i in range(1000)])),
            ('near_max_missing1998', _case245([i for i in range(2000) if i != 1998])),
            ('n2000_all2000', _case245([2000] * 2000)),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', _case245(list(range(2000))))

    elif pid == 'abc246_b':
        cases = [
            ('axis_y', '0 1\n'),
            ('two_zero', '2 0\n'),
            ('zero_two', '0 2\n'),
            ('three_four_scaled', '6 8\n'),
            ('diagonal_one', '1 1\n'),
            ('diagonal_large', '999 999\n'),
            ('asymmetric_small', '2 3\n'),
            ('asymmetric_reverse', '3 2\n'),
            ('near_axis_x', '1000 1\n'),
            ('near_axis_y', '1 1000\n'),
            ('pythagorean_5_12', '5 12\n'),
            ('pythagorean_8_15', '8 15\n'),
            ('large_coprime', '997 991\n'),
            ('large_uneven', '1000 777\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '1000 1000\n')

    else:
        cases = [
            ('two_unique', _case247([('aa', 'ba'), ('ab', 'bb')])),
            ('shared_family_unique_given', _case247([('same', 'alice'), ('same', 'bob')])),
            ('cross_but_possible', _case247([('aa', 'bb'), ('bb', 'cc'), ('dd', 'ee')])),
            ('both_blocked_one_person', _case247([('aa', 'bb'), ('aa', 'cc'), ('dd', 'bb')])),
            ('self_same_unique', _case247([('solo', 'solo'), ('other', 'name')])),
            ('self_same_collides', _case247([('same', 'same'), ('same', 'other')])),
            ('all_unique_four', _case247([('aa', 'ba'), ('ab', 'bb'), ('ac', 'bc'), ('ad', 'bd')])),
            ('cycle_three', _case247([('aa', 'bb'), ('bb', 'cc'), ('cc', 'aa')])),
            ('one_shared_given', _case247([('ax', 'zz'), ('by', 'zz'), ('cz', 'qq')])),
            ('mixed_duplicates_yes', _case247([('aa', 'xx'), ('aa', 'yy'), ('bb', 'yy'), ('cc', 'zz')])),
            ('mixed_duplicates_no', _case247([('aa', 'xx'), ('aa', 'yy'), ('bb', 'xx'), ('cc', 'yy')])),
            ('n20_unique', _case247([(_alpha_name('a', i), _alpha_name('b', i)) for i in range(20)])),
            ('n50_shared_family', _case247([('shared', _alpha_name('c', i)) for i in range(50)])),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', _case247([(_alpha_name('d', i), _alpha_name('e', i)) for i in range(100)]))

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
