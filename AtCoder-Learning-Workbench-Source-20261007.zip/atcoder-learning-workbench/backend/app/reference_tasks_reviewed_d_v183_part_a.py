"""ABC078..083 D canonical public contracts for formal Turn160 checkpoint."""
from __future__ import annotations
from heapq import heappop,heappush
from typing import cast
import random,re
TASKS=('arc085_b','abc079_d','abc080_d','arc086_b','arc087_b','arc088_b')
CONTESTS=dict(zip(TASKS,(f'abc{n:03}' for n in range(78,84))))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'arc086_b':'semantic'}
CHECKER_IDS={'arc086_b':'arc086_b'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc085_b':
        require(len(rows)==2,'shape');n,z,w=ints(rows[0],3);require(1<=n<=2000 and 1<=z<=10**9 and 1<=w<=10**9,'cards');values=ints(rows[1],n);require(all(1<=v<=10**9 for v in values),'values');return z,w,values
    if pid=='abc079_d':
        h,w=ints(rows[0],2);require(1<=h<=200 and 1<=w<=200 and len(rows)==h+11,'shape');costs=tuple(ints(row,10) for row in rows[1:11]);require(all(costs[i][i]==0 and all(1<=costs[i][j]<=1000 for j in range(10) if j!=i) for i in range(10)),'cost');wall=tuple(v for row in rows[11:] for v in ints(row,w));require(all(-1<=v<=9 for v in wall) and any(v!=-1 for v in wall),'wall');return costs,wall
    if pid=='abc080_d':
        n,c=ints(rows[0],2);require(1<=n<=100000 and 1<=c<=30 and len(rows)==n+1,'shape');shows=tuple(ints(row,3) for row in rows[1:]);require(all(1<=s<t<=100000 and 1<=channel<=c for s,t,channel in shows),'shows');bychannel=[[] for _ in range(c)]
        for s,t,channel in shows:bychannel[channel-1].append((s,t))
        for group in bychannel:
            group.sort();require(all(a[1]<=b[0] for a,b in zip(group,group[1:])),'same channel nonoverlap')
        return c,shows
    if pid=='arc086_b':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(2<=n<=50,'n');values=ints(rows[1],n);require(all(-10**6<=v<=10**6 for v in values),'values');return (values,)
    if pid=='arc087_b':
        require(len(rows)==2 and re.fullmatch('[FT]{1,8000}',rows[0]) is not None,'commands');x,y=ints(rows[1],2);require(abs(x)<=len(rows[0]) and abs(y)<=len(rows[0]),'target');return rows[0],x,y
    require(len(rows)==1 and re.fullmatch('[01]{1,100000}',rows[0]) is not None,'bits');return (rows[0],)

def card_game(w:int,a:tuple[int,...])->int:
    # Suffix minimax states: the active player's old card is overwritten, so
    # only the other player's last selected card matters for terminal moves.
    last=a[-1];max_min_state:int|None=None;min_max_state:int|None=None
    for value in reversed(a[:-1]):
        terminal=abs(last-value)
        maximum=max(terminal,max_min_state) if max_min_state is not None else terminal
        minimum=min(terminal,min_max_state) if min_max_state is not None else terminal
        max_min_state=max(max_min_state,minimum) if max_min_state is not None else minimum
        min_max_state=min(min_max_state,maximum) if min_max_state is not None else maximum
    return max(abs(last-w),max_min_state) if max_min_state is not None else abs(last-w)

def operation_valid(raw:str,actual:str)->bool:
    try:
        values=list(cast(tuple[int,...],validate('arc086_b',raw)[0]));rows=actual.removesuffix('\n').split('\n');count=ints(rows[0],1)[0]
        if not 0<=count<=2*len(values) or len(rows)!=count+1:return False
        for row in rows[1:]:
            source,target=ints(row,2)
            if not 1<=source<=len(values) or not 1<=target<=len(values):return False
            values[target-1]+=values[source-1]
        return all(a<=b for a,b in zip(values,values[1:]))
    except (ValueError,TypeError,IndexError):return False

def sign_operations(values:tuple[int,...])->str:
    a=list(values);ops:list[tuple[int,int]]=[]
    if all(x<=y for x,y in zip(a,a[1:])):return '0'
    maximum=max(range(len(a)),key=a.__getitem__);minimum=min(range(len(a)),key=a.__getitem__)
    def add(source:int,target:int)->None:a[target]+=a[source];ops.append((source+1,target+1))
    if a[maximum]>=-a[minimum]:
        for j in range(len(a)):
            if a[j]<0:add(maximum,j)
        for j in range(1,len(a)):
            if a[j]<a[j-1]:add(j-1,j)
    else:
        for j in range(len(a)):
            if a[j]>0:add(minimum,j)
        for j in range(len(a)-2,-1,-1):
            if a[j]>a[j+1]:add(j+1,j)
    return str(len(ops))+''.join('\n'+line(op).removesuffix('\n') for op in ops)

def robot_subset(s:str,x:int,y:int)->bool:
    runs=[0]
    for ch in s:
        if ch=='F':runs[-1]+=1
        else:runs.append(0)
    x-=runs[0]
    def reachable(steps:list[int],target:int)->bool:
        total=sum(steps)
        if abs(target)>total or (total+target)%2:return False
        required=(total+target)//2;bits=1
        for length in steps:bits|=bits<<length
        return bool(bits>>required&1)
    return reachable(runs[2::2],x) and reachable(runs[1::2],y)

def flip_span(s:str)->int:
    n=len(s)
    if n<=10:
        target=sum((ch=='1')<<j for j,ch in enumerate(s))
        for k in range(n,0,-1):
            basis=[0]*n
            for left in range(n):
                for right in range(left+k,n+1):
                    vector=((1<<(right-left))-1)<<left
                    while vector:
                        bit=vector.bit_length()-1
                        if basis[bit]:vector^=basis[bit]
                        else:basis[bit]=vector;break
            vector=target
            while vector:
                bit=vector.bit_length()-1
                if not basis[bit]:break
                vector^=basis[bit]
            if vector==0:return k
        raise ValueError('span')
    # An interval flip toggles its two boundary derivative bits. Boundary
    # vertices distance>=K form one outer component plus isolated inner ones.
    changes=[0]*(n+1)
    for j in range(1,n):changes[j]=changes[j-1]+(s[j]!=s[j-1])
    changes[n]=changes[n-1]
    def feasible(k:int)->bool:
        low=n-k+1;high=k-1
        return low>high or changes[high]-changes[low-1]==0
    low=1;high=n
    while low<high:
        middle=(low+high+1)//2
        if feasible(middle):low=middle
        else:high=middle-1
    return low

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc085_b':return str(card_game(cast(int,data[1]),cast(tuple[int,...],data[2])))
    if pid=='abc079_d':
        costs,wall=cast(tuple[tuple[tuple[int,...],...],tuple[int,...]],data);distance=[10**9]*10;distance[1]=0;queue=[(0,1)]
        while queue:
            value,node=heappop(queue)
            if value!=distance[node]:continue
            for digit in range(10):
                candidate=value+costs[digit][node]
                if candidate<distance[digit]:distance[digit]=candidate;heappush(queue,(candidate,digit))
        return str(sum(distance[v] for v in wall if v!=-1))
    if pid=='abc080_d':
        channels,shows=cast(tuple[int,tuple[tuple[int,int,int],...]],data);events=[]
        for start,end,channel in shows:events.extend(((2*start-1,channel,1),(2*end,channel,-1)))
        events.sort();depth=[0]*(channels+1);active=answer=0
        for time,channel,delta in events:
            before=depth[channel]>0;depth[channel]+=delta;after=depth[channel]>0;active+=after-before;answer=max(answer,active)
        return str(answer)
    if pid=='arc086_b':return sign_operations(cast(tuple[int,...],data[0]))
    if pid=='arc087_b':return 'Yes' if robot_subset(*cast(tuple[str,int,int],data)) else 'No'
    return str(flip_span(cast(str,data[0])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='arc086_b':return operation_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='arc086_b':return operation_valid(raw,expected) and operation_valid(raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'arc085_b':"n,z,w=map(int,input().split());a=list(map(int,input().split()));print(abs(a[-1]-w) if n==1 else max(abs(a[-1]-w),abs(a[-1]-a[-2])))\n",
'abc079_d':"h,w=map(int,input().split());c=[list(map(int,input().split())) for _ in range(10)]\nfor k in range(10):\n for i in range(10):\n  for j in range(10):c[i][j]=min(c[i][j],c[i][k]+c[k][j])\nprint(sum(c[v][1] for _ in range(h) for v in map(int,input().split()) if v!=-1))\n",
'abc080_d':"n,c=map(int,input().split());channels=[[] for _ in range(c)]\nfor _ in range(n):\n s,t,ch=map(int,input().split());channels[ch-1].append((s,t))\ndiff=[0]*200003\nfor group in channels:\n group.sort();merged=[]\n for s,t in group:\n  if merged and s<=merged[-1][1]:merged[-1]=(merged[-1][0],max(t,merged[-1][1]))\n  else:merged.append((s,t))\n for s,t in merged:diff[2*s-1]+=1;diff[2*t]-=1\nactive=answer=0\nfor value in diff:active+=value;answer=max(answer,active)\nprint(answer)\n",
'arc086_b':"n=int(input());a=list(map(int,input().split()));pivot=max(range(n),key=lambda j:abs(a[j]));positive=a[pivot]>=0;operations=[(pivot,j) for j in range(n)]\nif positive:operations.extend((j,j+1) for j in range(n-1))\nelse:operations.extend((j,j-1) for j in range(n-1,0,-1))\nprint(len(operations))\nfor x,y in operations:print(x+1,y+1)\n",
'arc087_b':"s=input();x,y=map(int,input().split());runs=[len(part) for part in s.split('T')];x-=runs[0]\ndef possible(lengths,target):\n positions={0}\n for length in lengths:positions={p+d for p in positions for d in (length,-length)}\n return target in positions\nprint('Yes' if possible(runs[2::2],x) and possible(runs[1::2],y) else 'No')\n",
'arc088_b':"s=input();n=len(s);print(min((max(j,n-j) for j in range(1,n) if s[j]!=s[j-1]),default=n))\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18300+TASKS.index(pid))
    if pid=='arc085_b':
        def cards(z:int,w:int,a:list[int])->str:return line((len(a),z,w))+line(a)
        raws=[cards(1,1,[1]),cards(1,1,[10**9]),cards(10**9,1,[1,10**9]),cards(1,10**9,[10**9,10**9])]
        for n in range(3,15):raws.append(cards(rng.randint(1,1000),rng.randint(1,1000),[rng.randint(1,1000) for _ in range(n)]))
        raws.extend([cards(10**9,1,[1,10**9]*1000),cards(10**9,10**9,[10**9]*2000)])
    elif pid=='abc079_d':
        def wall(cost:int,h:int,w:int,values:list[int],chain:bool=False)->str:
            matrix=[[0 if i==j else cost for j in range(10)] for i in range(10)]
            if chain:
                for j in range(1,10):matrix[j][j-1]=1
                matrix[0][1]=1
            return line((h,w))+''.join(line(row) for row in matrix)+''.join(line(values[j*w:(j+1)*w]) for j in range(h))
        raws=[wall(1,1,1,[0]),wall(1000,1,1,[1]),wall(1000,1,2,[-1,0]),wall(1000,1,1,[9],True)]
        for n in range(2,14):
            values=[rng.randint(-1,9) for _ in range(n*(n+1))];values[0]=rng.randrange(10);raws.append(wall(rng.randint(1,1000),n,n+1,values,n%2==0))
        raws.extend([wall(1000,200,200,[j%11-1 for j in range(40000)],True),wall(1000,200,200,[9]*40000)])
    elif pid=='abc080_d':
        def shows(c:int,a:list[tuple[int,int,int]])->str:return line((len(a),c))+''.join(line(v) for v in a)
        raws=[shows(1,[(1,2,1)]),shows(1,[(1,2,1),(2,3,1)]),shows(2,[(1,2,1),(2,3,2)]),shows(30,[(1,100000,c) for c in range(1,31)])]
        for n in range(3,15):
            c=rng.randint(1,5);next_time=[1]*c;programs=[]
            for j in range(n):
                channel=rng.randrange(c);start=next_time[channel]+rng.randint(0,2);end=start+rng.randint(1,3);next_time[channel]=end;programs.append((start,end,channel+1))
            rng.shuffle(programs);raws.append(shows(c,programs))
        raws.extend([shows(30,[(j+1,j+2,1) for j in range(99999)]+[(1,100000,30)]),shows(30,[(j+1,j+2,j%30+1) for j in range(100000-1)]+[(99999,100000,30)])])
    elif pid=='arc086_b':
        arrays=[[0,0],[-10**6,10**6],[10**6,-10**6],[-1,-3]]
        for n in range(3,15):arrays.append([rng.randint(-100,100) for _ in range(n)])
        arrays.extend([[10**6 if j%2 else -10**6 for j in range(50)],[10**6]*50]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    elif pid=='arc087_b':
        def robot(s:str,x:int,y:int)->str:return s+'\n'+line((x,y))
        raws=[robot('F',1,0),robot('T',0,0),robot('F',-1,0),robot('TF',0,-1)]
        for n in range(3,15):raws.append(robot(''.join(rng.choice('FT') for _ in range(n)),rng.randint(-n,n),rng.randint(-n,n)))
        raws.extend([robot('FT'*4000,0,0),robot('F'*8000,8000,8000)])
    else:
        words=['0','1','01','10']
        for n in range(3,15):words.append(''.join(rng.choice('01') for _ in range(n)))
        words.extend(['0'*50000+'1'*50000,'1'*100000]);raws=[s+'\n' for s in words]
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'arc085_b':('最後のカードを誰が取るか、直前のカードを相手に取らせられるか考えます。','最初に全部取る場合と、最後の1枚だけ残す場合のうち、差が大きい方をXは保証できます。','疑似コード: N==1ならabs(a[-1]-W); 他はmax(abs(a[-1]-W),abs(a[-1]-a[-2]))を出力。'),
'abc079_d':('数字の書き換えを、有向辺のコストと考えます。','直接1へ書き換えるより、別の数字を経由する方が安いこともあります。10数字間の最短距離を求めます。','疑似コード: k,i,jの3重loopでc[i][j]=min(c[i][j],c[i][k]+c[k][j]); 壁で数字v>=0のc[v][1]を合計。'),
'abc080_d':('同じチャンネルで連続する番組は、録画を止めずにつなげられます。','チャンネルごとに接する区間を結合します。その後、各録画が使う区間[s-0.5,t)の同時数を数えます。','疑似コード: channelごとsortして接点区間merge; diff[2*s-1]++,diff[2*t]--; prefix累積の最大値を出力。'),
'arc086_b':('絶対値最大の要素を他の要素へ加えると、全要素を同じ符号にできます。','全て非負なら左から隣へ加算し、全て非正なら右から隣へ加算すると非減少になります。','疑似コード: pivot=argmax(abs(a)); 全jへa[j]+=a[pivot]の操作を出力; pivot>=0ならj→j+1を左から、他はj→j-1を右から; 操作数<=2N。'),
'arc087_b':('Tで区切った連続Fを、x方向とy方向の移動に分けます。','最初のFだけは正のx方向で固定です。他は各区間長を正負どちらにもできます。','疑似コード: runs=S.split(T)の長さ; x-=runs[0]; x用runs[2::2]、y用runs[1::2]; reachable集合を各長さで±更新しx/yを判定。'),
'arc088_b':('操作する区間が長いほど、文字列の中央付近は同時に反転されます。','隣のビットが異なる境界iは、長さKの操作で分けられる必要があります。よってK<=max(i,N-i)です。','疑似コード: answer=N; 全i=1..N-1でS[i]!=S[i-1]ならanswer=min(answer,max(i,N-i)); answerを出力。')}

TITLES={'arc085_b': 'ABS', 'abc079_d': 'Wall', 'abc080_d': 'Recording', 'arc086_b': 'Non-decreasing', 'arc087_b': 'FT Robot', 'arc088_b': 'Wide Flip'}
PUBLISHED_SAMPLES={'arc085_b': [{'input': '3 100 100\n10 1000 100\n', 'expected': '900\n'}, {'input': '3 100 1000\n10 100 100\n', 'expected': '900\n'}, {'input': '5 1 1\n1 1 1 1 1\n', 'expected': '0\n'}, {'input': '1 1 1\n1000000000\n', 'expected': '999999999\n'}], 'abc079_d': [{'input': '2 4\n0 9 9 9 9 9 9 9 9 9\n9 0 9 9 9 9 9 9 9 9\n9 9 0 9 9 9 9 9 9 9\n9 9 9 0 9 9 9 9 9 9\n9 9 9 9 0 9 9 9 9 2\n9 9 9 9 9 0 9 9 9 9\n9 9 9 9 9 9 0 9 9 9\n9 9 9 9 9 9 9 0 9 9\n9 9 9 9 2 9 9 9 0 9\n9 2 9 9 9 9 9 9 9 0\n-1 -1 -1 -1\n8 1 1 8\n', 'expected': '12\n'}, {'input': '5 5\n0 999 999 999 999 999 999 999 999 999\n999 0 999 999 999 999 999 999 999 999\n999 999 0 999 999 999 999 999 999 999\n999 999 999 0 999 999 999 999 999 999\n999 999 999 999 0 999 999 999 999 999\n999 999 999 999 999 0 999 999 999 999\n999 999 999 999 999 999 0 999 999 999\n999 999 999 999 999 999 999 0 999 999\n999 999 999 999 999 999 999 999 0 999\n999 999 999 999 999 999 999 999 999 0\n1 1 1 1 1\n1 1 1 1 1\n1 1 1 1 1\n1 1 1 1 1\n1 1 1 1 1\n', 'expected': '0\n'}, {'input': '3 5\n0 4 3 6 2 7 2 5 3 3\n4 0 5 3 7 5 3 7 2 7\n5 7 0 7 2 9 3 2 9 1\n3 6 2 0 2 4 6 4 2 3\n3 5 7 4 0 6 9 7 6 7\n9 8 5 2 2 0 4 7 6 5\n5 4 6 3 2 3 0 5 4 3\n3 6 2 3 4 2 4 0 8 9\n4 6 5 4 3 5 3 2 0 8\n2 1 3 4 5 7 8 6 4 0\n3 5 2 6 1\n2 5 3 2 1\n6 9 2 5 6\n', 'expected': '47\n'}], 'abc080_d': [{'input': '3 2\n1 7 2\n7 8 1\n8 12 1\n', 'expected': '2\n'}, {'input': '3 4\n1 3 2\n3 4 4\n1 4 3\n', 'expected': '3\n'}, {'input': '9 4\n56 60 4\n33 37 2\n89 90 3\n32 43 1\n67 68 3\n49 51 3\n31 32 3\n70 71 1\n11 12 3\n', 'expected': '2\n'}], 'arc086_b': [{'input': '3\n-2 5 -1\n', 'expected': '2\n2 3\n3 3\n'}, {'input': '2\n-1 -3\n', 'expected': '1\n2 1\n'}, {'input': '5\n0 0 0 0 0\n', 'expected': '0\n'}], 'arc087_b': [{'input': 'FTFFTFFF\n4 2\n', 'expected': 'Yes\n'}, {'input': 'FTFFTFFF\n-2 -2\n', 'expected': 'Yes\n'}, {'input': 'FF\n1 0\n', 'expected': 'No\n'}, {'input': 'TF\n1 0\n', 'expected': 'No\n'}, {'input': 'FFTTFF\n0 0\n', 'expected': 'Yes\n'}, {'input': 'TTTT\n1 0\n', 'expected': 'No\n'}], 'arc088_b': [{'input': '010\n', 'expected': '2\n'}, {'input': '100000000\n', 'expected': '8\n'}, {'input': '00001111\n', 'expected': '4\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
