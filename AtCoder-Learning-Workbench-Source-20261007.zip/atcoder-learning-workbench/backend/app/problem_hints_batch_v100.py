"""Statement-checked three-stage hints for ABC158–160 B."""
HINTS_V100 = {
    'abc158_b': (
        '青A個→赤B個という同じ並びが繰り返されます。まず1周期の長さと、その中の青の個数を考えてください。',
        '1周期はA+B個です。完全な周期の個数だけAを足し、余り部分では先頭の青区間に入った個数だけを加えます。',
        '''疑似コード:
cycle = A + B
full = N // cycle
rest = N % cycle
answer = full * A + min(rest, A)
print(answer)''',
    ),
    'abc159_b': (
        '調べる文字列は全体だけではありません。問題文で指定された左右の部分文字列もそれぞれ取り出してください。',
        'Nは奇数なので中央1文字を除き、全体・左半分・右半分の3つがすべて回文かを確認します。',
        '''疑似コード:
left = S[:N//2]
right = S[N//2+1:]
if S == reverse(S) and left == reverse(left) and right == reverse(right):
  print("Yes")
else:
  print("No")''',
    ),
    'abc160_b': (
        '同じ金額をどの硬貨へ替えると「1円あたりの嬉しさ」が大きいか比較してください。',
        '500円硬貨は1円あたりの嬉しさが最も高いので最大枚数を取り、残額から5円硬貨を最大枚数取れば最適です。',
        '''疑似コード:
coins500 = X // 500
rest = X % 500
coins5 = rest // 5
answer = coins500 * 1000 + coins5 * 5
print(answer)''',
    ),
}
