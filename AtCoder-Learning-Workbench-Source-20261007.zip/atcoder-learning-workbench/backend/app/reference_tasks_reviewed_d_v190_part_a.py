"""Private ABC204..209 D tasks with integer rigid motion and staged Dijkstra oracle."""
from __future__ import annotations
from collections import Counter
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(204,210));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
INF=10**30

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def tree_colors(n:int,edges:tuple[tuple[int,...],...])->list[int]:
    graph=[[] for _ in range(n)]
    for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
    color=[-1]*n;color[0]=0;stack=[0]
    while stack:
        node=stack.pop()
        for neighbor in graph[node]:
            if color[neighbor]<0:color[neighbor]=1-color[node];stack.append(neighbor)
    require(all(v>=0 for v in color),'connected');return color

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc204_d' or pid=='abc206_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=(100 if pid=='abc204_d' else 200000),'N');a=ints(rows[1],n);require(all(1<=v<=(1000 if pid=='abc204_d' else 200000) for v in a),'values');return (a,)
    if pid=='abc205_d':
        n,q=ints(rows[0],2);require(1<=n<=100000 and 1<=q<=100000 and len(rows)==q+2,'N/Q/shape');a=ints(rows[1],n);queries=tuple(ints(row,1)[0] for row in rows[2:]);require(all(1<=v<=10**18 for v in a+queries) and all(x<y for x,y in zip(a,a[1:])),'bounds/sorted');return a,queries
    if pid=='abc207_d':
        n=ints(rows[0],1)[0];require(1<=n<=100 and len(rows)==2*n+1,'N/shape');points=tuple(ints(row,2) for row in rows[1:]);a,b=points[:n],points[n:];require(all(abs(v)<=10 for point in points for v in point) and len(set(a))==len(set(b))==n,'bounds/distinct');return a,b
    if pid=='abc208_d':
        n,m=ints(rows[0],2);require(1<=n<=400 and 0<=m<=n*(n-1) and len(rows)==m+1,'N/M/shape');a=tuple(ints(row,3) for row in rows[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v and 1<=cost<=10**6 for u,v,cost in a) and len({(u,v) for u,v,cost in a})==m,'directed edges');return n,a
    n,q=ints(rows[0],2);require(2<=n<=100000 and 1<=q<=100000 and len(rows)==n+q,'shape');edges=tuple(ints(row,2) for row in rows[1:n]);queries=tuple(ints(row,2) for row in rows[n:]);require(all(1<=a<b<=n for a,b in edges+queries),'ordered distinct endpoints');tree_colors(n,edges);return n,edges,queries

def cooking_grouped_bits(a:tuple[int,...])->int:
    bits=1
    for value,count in Counter(a).items():
        chunk=1
        while count:
            take=min(chunk,count);bits|=bits<<(value*take);count-=take;chunk*=2
    total=sum(a);half=total//2;reachable=bits&((1<<(half+1))-1);best=reachable.bit_length()-1;return total-best

def excluded_offline_gaps(a:tuple[int,...],queries:tuple[int,...])->list[int]:
    answers=[0]*len(queries);index=0;previous=missing=0
    for output,k in sorted(enumerate(queries),key=lambda item:item[1]):
        while index<len(a):
            gap=a[index]-previous-1
            if k<=missing+gap:break
            missing+=gap;previous=a[index];index+=1
        answers[output]=previous+k-missing
    return answers

def palindrome_value_components(a:tuple[int,...])->int:
    graph:dict[int,set[int]]={}
    for left,right in zip(a,a[::-1]):
        graph.setdefault(left,set()).add(right);graph.setdefault(right,set()).add(left)
    visited:set[int]=set();answer=0
    for start in graph:
        if start in visited:continue
        stack=[start];visited.add(start);count=0
        while stack:
            node=stack.pop();count+=1
            for neighbor in graph[node]:
                if neighbor not in visited:visited.add(neighbor);stack.append(neighbor)
        answer+=count-1
    return answer

def rigid_complex_integer(a:tuple[tuple[int,...],...],b:tuple[tuple[int,...],...])->bool:
    if len(a)==1:return True
    ax,ay=a[0];dx,dy=a[1][0]-ax,a[1][1]-ay;norm=dx*dx+dy*dy;offsets=[(x-ax,y-ay) for x,y in a];scaled_b={(x*norm,y*norm) for x,y in b}
    for bx,by in b:
        for ex,ey in ((x-bx,y-by) for x,y in b if (x,y)!=(bx,by)):
            if ex*ex+ey*ey!=norm:continue
            real=ex*dx+ey*dy;imaginary=ey*dx-ex*dy
            transformed={(bx*norm+real*x-imaginary*y,by*norm+imaginary*x+real*y) for x,y in offsets}
            if transformed==scaled_b:return True
    return False

def staged_dijkstra(n:int,edges:tuple[tuple[int,...],...])->int:
    forward:list[list[tuple[int,int]]]=[[] for _ in range(n)];reverse:list[list[tuple[int,int]]]=[[] for _ in range(n)];distances=[[INF]*n for _ in range(n)]
    for j in range(n):distances[j][j]=0
    for a,b,cost in edges:forward[a-1].append((b-1,cost));reverse[b-1].append((a-1,cost));distances[a-1][b-1]=cost
    def to_endpoints(graph:list[list[tuple[int,int]]],source:int)->list[int]:
        values=[INF]*n;values[source]=0;heap=[(0,source)]
        while heap:
            cost,node=heapq.heappop(heap)
            if cost!=values[node] or node>source:continue
            for neighbor,weight in graph[node]:
                candidate=cost+weight
                if candidate<values[neighbor]:
                    values[neighbor]=candidate
                    if neighbor<=source:heapq.heappush(heap,(candidate,neighbor))
        return values
    answer=0;stage_sum=sum(cost for _,_,cost in edges)
    for intermediate in range(n):
        outgoing=to_endpoints(forward,intermediate);incoming=to_endpoints(reverse,intermediate)
        for node,row in enumerate(distances):
            prefix=incoming[node]
            if prefix<INF:
                for endpoint,suffix in enumerate(outgoing):
                    candidate=prefix+suffix
                    previous=row[endpoint]
                    if candidate<previous:
                        stage_sum+=candidate-(previous if previous<INF else 0)
                        row[endpoint]=candidate
        answer+=stage_sum
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc204_d':return str(cooking_grouped_bits(cast(tuple[int,...],data[0])))
    if pid=='abc205_d':return '\n'.join(map(str,excluded_offline_gaps(*cast(tuple[tuple[int,...],tuple[int,...]],data))))
    if pid=='abc206_d':return str(palindrome_value_components(cast(tuple[int,...],data[0])))
    if pid=='abc207_d':return 'Yes' if rigid_complex_integer(*cast(tuple[tuple[tuple[int,...],...],tuple[tuple[int,...],...]],data)) else 'No'
    if pid=='abc208_d':return str(staged_dijkstra(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
    n,edges,queries=cast(tuple[int,tuple[tuple[int,...],...],tuple[tuple[int,...],...]],data);colors=tree_colors(n,edges);return '\n'.join('Town' if colors[a-1]==colors[b-1] else 'Road' for a,b in queries)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc204_d':"n=int(input());a=list(map(int,input().split()));total=sum(a);dp=bytearray(total+1);dp[0]=1;used=0\nfor value in a:\n for j in range(used,-1,-1):\n  if dp[j]:dp[j+value]=1\n used+=value\nprint(min(max(j,total-j) for j in range(total+1) if dp[j]))\n",
'abc205_d':"from bisect import bisect_left\nn,q=map(int,input().split());a=list(map(int,input().split()));gaps=[v-j-1 for j,v in enumerate(a)]\nfor _ in range(q):k=int(input());print(k+bisect_left(gaps,k))\n",
'abc206_d':"n=int(input());a=list(map(int,input().split()));p=list(range(200001));size=[1]*len(p);answer=0\ndef find(u):\n while u!=p[u]:p[u]=p[p[u]];u=p[u]\n return u\nfor x,y in zip(a,a[::-1]):\n x,y=find(x),find(y)\n if x!=y:\n  if size[x]<size[y]:x,y=y,x\n  p[y]=x;size[x]+=size[y];answer+=1\nprint(answer)\n",
'abc207_d':"n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];b=[tuple(map(int,input().split())) for _ in range(n)];found=n==1\nif n>1:\n dx,dy=a[1][0]-a[0][0],a[1][1]-a[0][1];length=dx*dx+dy*dy;invariants=sorted((dx*(x-a[0][0])+dy*(y-a[0][1]),dx*(y-a[0][1])-dy*(x-a[0][0])) for x,y in a)\n for bx,by in b:\n  for ex,ey in ((x-bx,y-by) for x,y in b):\n   if ex*ex+ey*ey!=length:continue\n   signatures=sorted((ex*(x-bx)+ey*(y-by),ex*(y-by)-ey*(x-bx)) for x,y in b)\n   if signatures==invariants:found=True;break\n  if found:break\nprint('Yes' if found else 'No')\n",
'abc208_d':"def solve():\n n,m=map(int,input().split());inf=10**30;d=[[inf]*n for _ in range(n)]\n for i in range(n):d[i][i]=0\n for _ in range(m):a,b,c=map(int,input().split());d[a-1][b-1]=c\n answer=0\n for k in range(n):\n  via=d[k]\n  for i,row in enumerate(d):\n   prefix=row[k]\n   if prefix==inf:continue\n   for j,suffix in enumerate(via):\n    candidate=prefix+suffix\n    if candidate<row[j]:row[j]=candidate\n  answer+=sum(v for row in d for v in row if v<inf)\n print(answer)\nsolve()\n",
'abc209_d':"n,q=map(int,input().split());p=list(range(n));size=[1]*n;color=[0]*n\ndef find(u):\n if p[u]!=u:\n  old=p[u];p[u]=find(old);color[u]^=color[old]\n return p[u]\nfor _ in range(n-1):\n u,v=map(int,input().split());u-=1;v-=1;a,b=find(u),find(v)\n if size[a]<size[b]:a,b=b,a\n p[b]=a;color[b]=color[u]^color[v]^1;size[a]+=size[b]\nfor _ in range(q):\n a,b=map(int,input().split());find(a-1);find(b-1);print('Town' if color[a-1]==color[b-1] else 'Road')\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(19000+TASKS.index(pid))
    if pid=='abc204_d':
        arrays=[[1],[1000],[1,1000],[3,3,3]];arrays.extend([rng.randint(1,1000) for _ in range(n)] for n in range(2,14));arrays.extend([[j*37%1000+1 for j in range(100)],[1000]*100]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    elif pid=='abc205_d':
        def excluded(a:list[int],q:list[int])->str:return line((len(a),len(q)))+line(a)+''.join(f'{k}\n' for k in q)
        raws=[excluded([1],[1]),excluded([10**18],[10**18]),excluded([1,2,3],[1,2]),excluded([3,5,6,7],[2,5,3])];raws.extend(excluded(sorted(rng.sample(range(1,1000),n)),[rng.randint(1,1000) for _ in range(n)]) for n in range(2,14));raws.extend([excluded([j*9999999999999+1 for j in range(100000)],[10**18-j for j in range(100000)]),excluded(list(range(10**18-99999,10**18+1)),[10**18]*100000)])
    elif pid=='abc206_d':
        arrays=[[1],[200000],[1,2],[1,2,1]];arrays.extend([rng.randint(1,200000) for _ in range(n)] for n in range(3,15));arrays.extend([list(range(1,200001)),[200000]*200000]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    elif pid=='abc207_d':
        def points(a:list[tuple[int,int]],b:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a+b)
        raws=[points([(0,0)],[(0,0)]),points([(-10,-10)],[(10,10)]),points([(0,0),(1,0)],[(0,0),(2,0)]),points([(1,0),(1,1),(3,0)],[(-1,0),(-1,1),(-3,0)])]
        pool=[(x,y) for x in range(-5,6) for y in range(-5,6)]
        for n in range(3,15):
            a=rng.sample(pool,n);b=[(-y+2,x-3) if n%2 else (-x,y) for x,y in a];rng.shuffle(b);raws.append(points(a,b))
        a=[(x,y) for x in range(-5,5) for y in range(-5,5)];raws.extend([points(a,[(-y,x) for x,y in a]),points(a,[(-y,x) for x,y in a[:-1]]+[(10,10)])])
    elif pid=='abc208_d':
        def graph(n:int,a:list[tuple[int,int,int]])->str:return line((n,len(a)))+''.join(line(p) for p in a)
        raws=[graph(1,[]),graph(2,[]),graph(2,[(1,2,10**6)]),graph(3,[(1,2,3),(2,3,2)])];raws.extend(graph(n,[(a,b,rng.randint(1,10**6)) for a in range(1,n+1) for b in range(1,n+1) if a!=b and rng.randrange(3)==0]) for n in range(3,15));raws.extend([graph(400,[(a,b,((a*65537+b*17)%10**6)+1) for a in range(1,401) for b in range(1,401) if a!=b]),graph(400,[(a,b,10**6) for a in range(1,401) for b in range(1,401) if a!=b])])
    else:
        def tree(n:int,a:list[tuple[int,int]],q:list[tuple[int,int]])->str:return line((n,len(q)))+''.join(line(v) for v in a+q)
        raws=[tree(2,[(1,2)],[(1,2)]),tree(3,[(1,2),(2,3)],[(1,3)]),tree(3,[(1,2),(1,3)],[(2,3)]),tree(4,[(1,4),(2,4),(2,3)],[(1,2),(1,3)])]
        for n in range(4,16):
            order=list(range(2,n+1));rng.shuffle(order);vertices=[1]+order;edges=[tuple(sorted((vertices[rng.randrange(j)],vertices[j]))) for j in range(1,n)];q=[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(n)];raws.append(tree(n,edges,q))
        raws.extend([tree(100000,[(1,j) for j in range(2,100001)],[(1,j%99999+2) if j%2 else (2,j%99997+3) for j in range(100000)]),tree(100000,[(j,j+1) for j in range(1,100000)],[(1,100000)]*100000)])
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc204_d':('二つのオーブンに分けるため、一方で調理する時間の合計を選びます。','部分和DPで到達できる合計を調べます。合計sとtotal-sの大きい方を最小化します。','疑似コード: dp[0]=true; 各Tでsを降順に見てdp[s+T]|=dp[s]; 到達sのmax(s,total-s)の最小を出力。'),
'abc205_d':('A_iの手前までに欠けている正整数はA_i-i個です（iは1始まり）。','欠けた数KがどのAの間に入るか、累積した欠けた数で二分探索します。','疑似コード: gap[j]=A[j]-j-1（jは0始まり）; 各Kでindex=lower_bound(gap,K); K+indexを出力。'),
'abc206_d':('左右で向き合う値は、最終的に同じ値へ変える必要があります。','値を頂点とし、向き合う二つの値をUnion-Findで結びます。異なる成分を結ぶごとに、一回の置換が必要です。','疑似コード: 各iとN-1-iの値のrootを探す; 違えばunionしanswer++; answerを出力。'),
'abc207_d':('点の重心や基準点を使い、平行移動の影響を取り除きます。回転だけを調べます。','一つの非零基準ベクトルを選び、同じ長さの候補ベクトルへ回します。内積と符号付き外積の一致で回転を整数だけで判定できます。','疑似コード: Aの基準pointとvectorを選ぶ; Bの全基準point/vectorで長さ一致を確認; 各点の(dot(base,offset),cross(base,offset))の集合が一致ならYes; どれもなければNo。'),
'abc208_d':('中継として使える頂点を番号順に追加するFloyd-Warshall法が、そのまま各f(s,t,k)を表します。','頂点kを追加して全距離を更新した後、有限の距離だけを総和へ足します。未到達を0として扱います。','疑似コード: dist[i][i]=0,辺を初期距離へ; k=1..Nでdist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]); 各段階の全有限distを合計し出力。'),
'abc209_d':('木の二頂点間の距離が偶数なら街、奇数なら道路の途中で出会います。','頂点を二色に塗ると、同色の二頂点は距離が偶数、違う色なら奇数です。','疑似コード: rootからDFS/BFSでedge毎にcolorを反転; 各query(c,d)でcolor[c]=color[d]ならTown、他はRoadを出力。')}

TITLES={'abc204_d': 'Cooking', 'abc205_d': 'Kth Excluded', 'abc206_d': 'KAIBUNsyo', 'abc207_d': 'Congruence Points', 'abc208_d': 'Shortest Path Queries 2', 'abc209_d': 'Collision'}
PUBLISHED_SAMPLES={'abc204_d': [{'input': '5\n8 3 7 2 5\n', 'expected': '13\n'}, {'input': '2\n1000 1\n', 'expected': '1000\n'}, {'input': '9\n3 14 15 9 26 5 35 89 79\n', 'expected': '138\n'}], 'abc205_d': [{'input': '4 3\n3 5 6 7\n2\n5\n3\n', 'expected': '2\n9\n4\n'}, {'input': '5 2\n1 2 3 4 5\n1\n10\n', 'expected': '6\n15\n'}], 'abc206_d': [{'input': '8\n1 5 3 2 5 2 3 1\n', 'expected': '2\n'}, {'input': '7\n1 2 3 4 1 2 3\n', 'expected': '1\n'}, {'input': '1\n200000\n', 'expected': '0\n'}], 'abc207_d': [{'input': '3\n0 0\n0 1\n1 0\n2 0\n3 0\n3 1\n', 'expected': 'Yes\n'}, {'input': '3\n1 0\n1 1\n3 0\n-1 0\n-1 1\n-3 0\n', 'expected': 'No\n'}, {'input': '4\n0 0\n2 9\n10 -2\n-6 -7\n0 0\n2 9\n10 -2\n-6 -7\n', 'expected': 'Yes\n'}, {'input': '6\n10 5\n-9 3\n1 -5\n-6 -5\n6 9\n-9 0\n-7 -10\n-10 -5\n5 4\n9 0\n0 -10\n-10 -2\n', 'expected': 'Yes\n'}], 'abc208_d': [{'input': '3 2\n1 2 3\n2 3 2\n', 'expected': '25\n'}, {'input': '3 0\n', 'expected': '0\n'}, {'input': '5 20\n1 2 6\n1 3 10\n1 4 4\n1 5 1\n2 1 5\n2 3 9\n2 4 8\n2 5 6\n3 1 5\n3 2 1\n3 4 7\n3 5 9\n4 1 4\n4 2 6\n4 3 4\n4 5 8\n5 1 2\n5 2 5\n5 3 6\n5 4 5\n', 'expected': '517\n'}], 'abc209_d': [{'input': '4 1\n1 2\n2 3\n2 4\n1 2\n', 'expected': 'Road\n'}, {'input': '5 2\n1 2\n2 3\n3 4\n4 5\n1 3\n1 5\n', 'expected': 'Town\nTown\n'}, {'input': '9 9\n2 3\n5 6\n4 8\n8 9\n4 5\n3 4\n1 9\n3 7\n7 9\n2 5\n2 6\n4 6\n2 4\n5 8\n7 8\n3 6\n5 6\n', 'expected': 'Town\nRoad\nTown\nTown\nTown\nTown\nRoad\nRoad\nRoad\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
