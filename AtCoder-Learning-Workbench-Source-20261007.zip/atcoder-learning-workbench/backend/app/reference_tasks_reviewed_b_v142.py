"""ABC284–286 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc284_b', 'abc285_b', 'abc286_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc284_b': [
        {
            'input': '4\n3\n1 2 3\n2\n20 23\n10\n6 10 4 1 5 9 8 6 5 1\n1\n1000000000\n',
            'expected': '2\n1\n5\n0\n',
        },
    ],
    'abc285_b': [
        {'input': '6\nabcbac\n', 'expected': '5\n1\n2\n0\n1\n'},
    ],
    'abc286_b': [
        {'input': '4\nnaan\n', 'expected': 'nyaan\n'},
        {'input': '4\nnear\n', 'expected': 'near\n'},
        {'input': '8\nnational\n', 'expected': 'nyationyal\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate284(raw: str) -> tuple[tuple[int, ...], ...]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    first = _ints_line(lines[0])
    if len(first) != 1 or not 1 <= first[0] <= 100:
        raise ValueError('T')
    t = first[0]
    pos = 1
    cases: list[tuple[int, ...]] = []
    for _ in range(t):
        if pos + 1 >= len(lines) + 1 or pos >= len(lines):
            raise ValueError('missing case')
        nline = _ints_line(lines[pos]); pos += 1
        if len(nline) != 1 or not 1 <= nline[0] <= 100:
            raise ValueError('N')
        if pos >= len(lines):
            raise ValueError('missing array')
        arr = _ints_line(lines[pos]); pos += 1
        if len(arr) != nline[0] or any(not 1 <= x <= 10**9 for x in arr):
            raise ValueError('A')
        cases.append(tuple(arr))
    if pos != len(lines):
        raise ValueError('extra lines')
    return tuple(cases)


def _validate285(raw: str) -> tuple[int, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    nline = _ints_line(lines[0])
    if len(nline) != 1:
        raise ValueError('N')
    n = nline[0]
    s = lines[1]
    if not 2 <= n <= 5000 or len(s) != n or LOWER.fullmatch(s) is None:
        raise ValueError('constraints')
    return n, s


def _validate286(raw: str) -> tuple[int, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    nline = _ints_line(lines[0])
    if len(nline) != 1:
        raise ValueError('N')
    n = nline[0]
    s = lines[1]
    if not 1 <= n <= 1000 or len(s) != n or LOWER.fullmatch(s) is None:
        raise ValueError('constraints')
    return n, s


def validate(pid: str, raw: str):
    if pid == 'abc284_b': return _validate284(raw)
    if pid == 'abc285_b': return _validate285(raw)
    if pid == 'abc286_b': return _validate286(raw)
    raise ValueError('unknown task')


def _oracle284(cases: tuple[tuple[int, ...], ...]) -> list[int]:
    return [sum(x & 1 for x in arr) for arr in cases]


def _verify285(n: int, s: str, vals: list[int]) -> bool:
    if len(vals) != n - 1:
        return False
    for i, l in enumerate(vals, 1):
        limit = n - i
        if not 0 <= l <= limit:
            return False
        if any(s[k] == s[k+i] for k in range(l)):
            return False
        if l < limit and s[l] != s[l+i]:
            return False
    return True


def _oracle286(s: str) -> str:
    out: list[str] = []
    i = 0
    while i < len(s):
        if i + 1 < len(s) and s[i] == 'n' and s[i+1] == 'a':
            out.append('nya'); i += 2
        else:
            out.append(s[i]); i += 1
    return ''.join(out)


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc284_b':
        parts = output.split('\n')
        if any(INT.fullmatch(x) is None for x in parts):
            return False
        return [int(x) for x in parts] == _oracle284(value)
    if pid == 'abc285_b':
        parts = output.split('\n')
        if any(INT.fullmatch(x) is None for x in parts):
            return False
        return _verify285(value[0], value[1], [int(x) for x in parts])
    return LOWER.fullmatch(output) is not None and output == _oracle286(value[1])


def _multi(cases: list[list[int]]) -> str:
    lines=[str(len(cases))]
    for a in cases:
        lines += [str(len(a)), ' '.join(map(str,a))]
    return '\n'.join(lines)+'\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); out.append({'category':category,'input':raw})
    for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])

    if pid == 'abc284_b':
        custom=[
            ('single_one',_multi([[1]])),
            ('single_even',_multi([[2]])),
            ('single_max_odd',_multi([[999999999]])),
            ('single_max_even',_multi([[1000000000]])),
            ('all_odd',_multi([[1,3,5,7,9]])),
            ('all_even',_multi([[2,4,6,8,10]])),
            ('mixed_edges',_multi([[1,2,999999999,1000000000]])),
            ('two_cases',_multi([[1,2],[3,4,5]])),
            ('many_singletons',_multi([[i] for i in range(1,11)])),
            ('alternating_ten',_multi([[i for i in range(1,11)]])),
            ('repeated_odd',_multi([[7]*100])),
            ('repeated_even',_multi([[8]*100])),
            ('large_values',_multi([[10**9-j for j in range(20)]])),
            ('three_varied',_multi([[1],[2,3,4],[5,6,7,8,9]])),
            ('boundary_n100',_multi([list(range(1,101))])),
            ('t100_small',_multi([[1 if i%2 else 2] for i in range(100)])),
        ]
        for c,r in custom: add(c,r)
        cases=[]
        for t in range(100):
            arr=[1+((t*97+j*7919) % 10**9) for j in range(100)]
            cases.append(arr)
        add('constraint_max',_multi(cases))

    elif pid == 'abc285_b':
        custom=[
            ('n2_equal','2\naa\n'),
            ('n2_diff','2\nab\n'),
            ('all_same','5\naaaaa\n'),
            ('all_distinct','5\nabcde\n'),
            ('alternating','8\nabababab\n'),
            ('period3','9\nabcabcabc\n'),
            ('late_equal','6\nabcdea\n'),
            ('early_equal','6\naabcde\n'),
            ('palindrome','7\nabcdcba\n'),
            ('repeat_tail','10\nabcdefghia\n'),
            ('alphabet','26\nabcdefghijklmnopqrstuvwxyz\n'),
            ('alphabet_twice','52\nabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz\n'),
            ('two_blocks','20\naaaaaaaaaabbbbbbbbbb\n'),
            ('mixed_30','30\nabacabadabacabaeabacabadabacab\n'),
            ('near_max_pattern','100\n'+('abcdefghijklmnopqrstuvwxyz'*4)[:100]+'\n'),
            ('long_all_same','1000\n'+'z'*1000+'\n'),
        ]
        for c,r in custom: add(c,r)
        add('constraint_max','5000\n'+('abcdefghijklmnopqrstuvwxyz'*193)[:5000]+'\n')

    else:
        custom=[
            ('single_n','1\nn\n'),
            ('single_a','1\na\n'),
            ('exact_na','2\nna\n'),
            ('reverse_an','2\nan\n'),
            ('double_na','4\nnana\n'),
            ('overlap_like','5\nnanaa\n'),
            ('many_n','10\nnnnnnnnnnn\n'),
            ('many_a','10\naaaaaaaaaa\n'),
            ('starts_na','7\nnabcxyz\n'),
            ('ends_na','7\nxyzzzna\n'),
            ('middle_na','8\nxxnayyzz\n'),
            ('repeated_words','12\nbananananana\n'),
            ('no_match_long','26\nabcdefghijklmnopqrstuvwxyz\n'),
            ('alternating_an','20\nanananananananananan\n'),
        ]
        for c,r in custom: add(c,r)
        add('constraint_max','1000\n'+'na'*500+'\n')

    if len(out)!=18 or len({r['input'] for r in out})!=18 or out[-1]['category']!='constraint_max':
        raise AssertionError(f'{pid}: expected 18 distinct cases ending in constraint_max, got {len(out)}')
    return out
