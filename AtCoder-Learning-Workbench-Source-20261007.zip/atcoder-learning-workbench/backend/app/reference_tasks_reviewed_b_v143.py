"""ABC287–289 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc287_b', 'abc288_b', 'abc289_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
DIGITS = re.compile(r'[0-9]+', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc287_b': [
        {'input': '3 3\n142857\n004159\n071028\n159\n287\n857\n', 'expected': '2\n'},
        {'input': '5 4\n235983\n109467\n823476\n592801\n000333\n333\n108\n467\n983\n', 'expected': '3\n'},
        {'input': '4 4\n000000\n123456\n987111\n000000\n000\n111\n999\n111\n', 'expected': '3\n'},
    ],
    'abc288_b': [
        {'input': '5 3\nabc\naaaaa\nxyz\na\ndef\n', 'expected': 'aaaaa\nabc\nxyz\n'},
        {'input': '4 4\nz\nzyx\nzzz\nrbg\n', 'expected': 'rbg\nz\nzyx\nzzz\n'},
        {'input': '3 1\nabc\narc\nagc\n', 'expected': 'abc\n'},
    ],
    'abc289_b': [
        {'input': '5 3\n1 3 4\n', 'expected': '2 1 5 4 3\n'},
        {'input': '5 0\n', 'expected': '1 2 3 4 5\n'},
        {'input': '10 6\n1 2 3 7 8 9\n', 'expected': '4 3 2 1 5 6 10 9 8 7\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate287(raw: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 2:
        raise ValueError('shape')
    n, m = head
    if not 1 <= n <= 1000 or not 1 <= m <= 1000 or len(lines) != 1 + n + m:
        raise ValueError('constraints')
    ss = tuple(lines[1:1+n]); ts = tuple(lines[1+n:])
    if any(len(s) != 6 or DIGITS.fullmatch(s) is None for s in ss):
        raise ValueError('S')
    if any(len(t) != 3 or DIGITS.fullmatch(t) is None for t in ts):
        raise ValueError('T')
    return ss, ts


def _validate288(raw: str) -> tuple[int, int, tuple[str, ...]]:
    lines = _canonical_lines(raw)
    head = _ints_line(lines[0]) if lines else []
    if len(head) != 2:
        raise ValueError('shape')
    n, k = head
    if not 1 <= k <= n <= 100 or len(lines) != n + 1:
        raise ValueError('constraints')
    ss = tuple(lines[1:])
    if any(not 1 <= len(s) <= 10 or LOWER.fullmatch(s) is None for s in ss) or len(set(ss)) != n:
        raise ValueError('S')
    return n, k, ss


def _validate289(raw: str) -> tuple[int, tuple[int, ...]]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 2:
        raise ValueError('shape')
    n, m = head
    if not 1 <= n <= 100 or not 0 <= m <= n - 1:
        raise ValueError('constraints')
    if m == 0:
        if len(lines) != 1:
            raise ValueError('shape')
        return n, ()
    if len(lines) != 2:
        raise ValueError('shape')
    a = tuple(_ints_line(lines[1]))
    if len(a) != m or any(not 1 <= x <= n - 1 for x in a) or any(a[i] >= a[i+1] for i in range(m-1)):
        raise ValueError('A')
    return n, a


def validate(pid: str, raw: str):
    if pid == 'abc287_b': return _validate287(raw)
    if pid == 'abc288_b': return _validate288(raw)
    if pid == 'abc289_b': return _validate289(raw)
    raise ValueError('unknown task')


def _oracle287(ss: tuple[str, ...], ts: tuple[str, ...]) -> int:
    exists = [False] * 1000
    for t in ts:
        exists[int(t)] = True
    return sum(exists[int(s[-3:])] for s in ss)


def _lex_lt(a: str, b: str) -> bool:
    for x, y in zip(a, b):
        if x != y:
            return x < y
    return len(a) < len(b)


def _oracle288(k: int, ss: tuple[str, ...]) -> list[str]:
    arr: list[str] = []
    for s in ss[:k]:
        pos = len(arr)
        while pos > 0 and _lex_lt(s, arr[pos-1]):
            pos -= 1
        arr.insert(pos, s)
    return arr


def _oracle289(n: int, a: tuple[int, ...]) -> list[int]:
    parent = list(range(n + 1))
    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(x: int, y: int) -> None:
        x, y = find(x), find(y)
        if x != y:
            parent[y] = x
    for x in a:
        union(x, x + 1)
    groups: dict[int, list[int]] = {}
    for v in range(1, n + 1):
        groups.setdefault(find(v), []).append(v)
    ans: list[int] = []
    used: set[int] = set()
    for v in range(1, n + 1):
        r = find(v)
        if r not in used:
            used.add(r)
            ans.extend(reversed(groups[r]))
    return ans


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc287_b':
        if INT.fullmatch(output) is None:
            return False
        return int(output) == _oracle287(*value)
    if pid == 'abc288_b':
        parts = output.split('\n')
        return all(LOWER.fullmatch(s) is not None for s in parts) and parts == _oracle288(value[1], value[2])
    parts = output.split(' ')
    if any(INT.fullmatch(x) is None for x in parts):
        return False
    vals = [int(x) for x in parts]
    return vals == _oracle289(*value)


def _base26(i: int, width: int = 4) -> str:
    chars = []
    for _ in range(width):
        chars.append(chr(ord('a') + (i % 26)))
        i //= 26
    return ''.join(reversed(chars))


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})
    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc287_b':
        custom = [
            ('single_match', '1 1\n123456\n456\n'),
            ('single_nomatch', '1 1\n123456\n455\n'),
            ('leading_zero_match', '1 2\n000007\n007\n700\n'),
            ('duplicates_t', '2 4\n111222\n333222\n222\n222\n001\n999\n'),
            ('duplicates_s', '4 2\n123999\n123999\n000111\n000111\n999\n111\n'),
            ('suffix_zero', '3 2\n100000\n000000\n999001\n000\n001\n'),
            ('suffix_nines', '3 1\n000999\n999999\n123998\n999\n'),
            ('all_match_one', '5 1\n000123\n111123\n222123\n333123\n444123\n123\n'),
            ('none_match', '5 2\n000001\n000002\n000003\n000004\n000005\n998\n999\n'),
            ('multiple_targets', '6 3\n111001\n222002\n333003\n444004\n555002\n666001\n001\n002\n003\n'),
            ('n10_m10', '10 10\n' + '\n'.join(f'{i:06d}' for i in range(10)) + '\n' + '\n'.join(f'{i:03d}' for i in range(10)) + '\n'),
            ('n1_m10', '1 10\n654321\n' + '\n'.join(f'{i:03d}' for i in [321,1,2,3,4,5,6,7,8,9]) + '\n'),
            ('n20_m3', '20 3\n' + '\n'.join(f'{i:03d}{i%3:03d}' for i in range(20)) + '\n000\n001\n002\n'),
            ('mixed_leading', '6 5\n000001\n010001\n100001\n001010\n010010\n100100\n001\n010\n100\n999\n000\n'),
        ]
        for c, r in custom: add(c, r)
        ss = [f'{i:03d}{(i*37)%1000:03d}' for i in range(1000)]
        ts = [f'{i:03d}' for i in range(1000)]
        add('constraint_max', '1000 1000\n' + '\n'.join(ss + ts) + '\n')

    elif pid == 'abc288_b':
        custom = [
            ('n1_k1', '1 1\na\n'),
            ('k1_first_only', '4 1\nzz\naa\nmm\nbb\n'),
            ('k2_reverse', '4 2\nz\na\nb\nc\n'),
            ('k_all_reverse', '5 5\ne\nd\nc\nb\na\n'),
            ('prefix_order', '5 5\naaaa\na\naa\naaa\nb\n'),
            ('similar_prefix', '5 4\nabc\nab\nabz\naba\nzzz\n'),
            ('length10', '3 3\nabcdefghij\naaaaaaaaaa\nzzzzzzzzzz\n'),
            ('first_k_excludes_small', '5 3\nm\nn\no\na\nb\n'),
            ('first_k_excludes_large', '5 3\na\nb\nc\ny\nz\n'),
            ('mixed_lengths', '6 6\nqwerty\nq\nqq\nabcxyz\nab\nabc\n'),
            ('n10_k5', '10 5\nj\ni\nh\ng\nf\ne\nd\nc\nb\na\n'),
            ('k_middle', '8 4\ndelta\nalpha\ncharlie\nbravo\necho\nfoxtrot\ngolf\nhotel\n'),
            ('single_chars', '6 6\nf\na\ne\nb\nd\nc\n'),
            ('prefix_trap', '6 5\nzzzz\nz\nza\nzz\nzy\na\n'),
        ]
        for c, r in custom: add(c, r)
        ss = [_base26(i, 4) for i in range(100)]
        add('constraint_max', '100 100\n' + '\n'.join(reversed(ss)) + '\n')

    else:
        custom = [
            ('n1_m0', '1 0\n'),
            ('n2_m0', '2 0\n'),
            ('n2_connected', '2 1\n1\n'),
            ('all_connected_small', '5 4\n1 2 3 4\n'),
            ('left_run', '6 3\n1 2 3\n'),
            ('right_run', '6 3\n3 4 5\n'),
            ('middle_run', '7 3\n2 3 4\n'),
            ('alternating_edges', '8 4\n1 3 5 7\n'),
            ('two_runs', '9 5\n1 2 5 6 7\n'),
            ('single_edge_middle', '10 1\n5\n'),
            ('three_components', '10 7\n1 2 3 5 7 8 9\n'),
            ('m_zero_large', '100 0\n'),
            ('almost_all', '100 98\n' + ' '.join(map(str, list(range(1,50)) + list(range(51,100)))) + '\n'),
            ('odd_edges_99', '100 50\n' + ' '.join(str(i) for i in range(1,100,2)) + '\n'),
        ]
        for c, r in custom: add(c, r)
        add('constraint_max', '100 99\n' + ' '.join(map(str, range(1,100))) + '\n')

    if len(out) != 18 or len({r['input'] for r in out}) != 18 or out[-1]['category'] != 'constraint_max':
        raise AssertionError(f'{pid}: expected 18 distinct cases ending in constraint_max, got {len(out)}')
    return out
