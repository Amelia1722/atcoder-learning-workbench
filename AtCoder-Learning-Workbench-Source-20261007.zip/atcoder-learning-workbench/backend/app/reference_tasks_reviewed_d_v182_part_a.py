"""Private exact ABC060..065 D public contracts and independent oracles."""
from __future__ import annotations
from collections import deque
from typing import cast
import random,re
TASKS=('arc073_b','abc061_d','arc074_b','arc075_b','abc064_d','arc076_b')
CONTESTS=dict(zip(TASKS,(f'abc{n:03}' for n in range(60,66))))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc073_b':
        n,w=ints(rows[0],2);require(1<=n<=100 and 1<=w<=10**9 and len(rows)==n+1,'shape');items=tuple(ints(row,2) for row in rows[1:]);base=items[0][0];require(all(1<=weight<=10**9 and base<=weight<=base+3 and 1<=value<=10**7 for weight,value in items),'items');return w,items
    if pid=='abc061_d':
        n,m=ints(rows[0],2);require(2<=n<=1000 and 1<=m<=min(n*(n-1),2000) and len(rows)==m+1,'shape');edges=tuple(ints(row,3) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b and -10**9<=c<=10**9 for a,b,c in edges) and len({(a,b) for a,b,c in edges})==m,'edges');graph=[[] for _ in range(n)]
        for a,b,c in edges:graph[a-1].append(b-1)
        reachable={0};queue=[0]
        for a in queue:
            for b in graph[a]:
                if b not in reachable:reachable.add(b);queue.append(b)
        require(n-1 in reachable,'source sink reachability');return n,edges
    if pid=='arc074_b':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=100000,'n');values=ints(rows[1],3*n);require(all(1<=v<=10**9 for v in values),'values');return n,values
    if pid=='arc075_b':
        n,a,b=ints(rows[0],3);require(1<=n<=100000 and 1<=b<a<=10**9 and len(rows)==n+1,'shape');h=tuple(ints(row,1)[0] for row in rows[1:]);require(all(1<=v<=10**9 for v in h),'health');return a,b,h
    if pid=='abc064_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=100 and len(rows[1])==n and set(rows[1])<=set('()'),'parentheses');return (rows[1],)
    n=ints(rows[0],1)[0];require(2<=n<=100000 and len(rows)==n+1,'shape');points=tuple(ints(row,2) for row in rows[1:]);require(all(0<=x<=10**9 and 0<=y<=10**9 for x,y in points),'coordinates');return (points,)

def max_walk(n:int,edges:tuple[tuple[int,int,int],...])->str:
    graph=[[] for _ in range(n)];reverse=[[] for _ in range(n)]
    for a,b,c in edges:graph[a-1].append((b-1,c));reverse[b-1].append(a-1)
    relevant={n-1};work=[n-1]
    for a in work:
        for b in reverse[a]:
            if b not in relevant:relevant.add(b);work.append(b)
    distances:list[int|None]=[None]*n;distances[0]=0;paths=[frozenset() for _ in range(n)];paths[0]=frozenset((0,));queue=deque((0,));pending={0}
    while queue:
        a=queue.popleft();pending.remove(a);score=distances[a];assert score is not None
        for b,c in graph[a]:
            if b not in relevant:continue
            candidate=score+c
            if distances[b] is None or candidate>cast(int,distances[b]):
                # An improving walk revisiting a vertex contains a positive
                # cycle: that vertex's recorded label never decreases.
                if b in paths[a]:return 'inf'
                distances[b]=candidate;paths[b]=paths[a]|{b}
                if b not in pending:queue.append(b);pending.add(b)
    return str(distances[-1])

class Fenwick:
    def __init__(self,values:tuple[int,...])->None:
        self.values=sorted(set(values));self.rank={v:j+1 for j,v in enumerate(self.values)};self.count=[0]*(len(self.values)+1);self.total=[0]*(len(self.values)+1);self.size=0;self.sum=0
    def add(self,value:int)->None:
        j=self.rank[value];self.size+=1;self.sum+=value
        while j<len(self.count):self.count[j]+=1;self.total[j]+=value;j+=j&-j
    def smallest(self,k:int)->int:
        if not k:return 0
        position=used=answer=0;step=1<<(len(self.values).bit_length()-1)
        while step:
            nextpos=position+step
            if nextpos<len(self.count) and used+self.count[nextpos]<k:position=nextpos;used+=self.count[nextpos];answer+=self.total[nextpos]
            step//=2
        return answer+(k-used)*self.values[position]

def bracket_dp(s:str)->str:
    n=len(s);dp=[['']*(n+1) for _ in range(n+1)]
    for width in range(1,n+1):
        for left in range(n-width+1):
            right=left+width;candidates=[]
            if width==1:candidates.append('()')
            if s[left]=='(':candidates.append('('+dp[left+1][right]+')')
            if s[right-1]==')':candidates.append('('+dp[left][right-1]+')')
            if width>=2 and s[left]=='(' and s[right-1]==')':candidates.append('('+dp[left+1][right-1]+')')
            candidates.extend(dp[left][middle]+dp[middle][right] for middle in range(left+1,right))
            dp[left][right]=min(candidates,key=lambda value:(len(value),value))
    return dp[0][n]

def mst_oracle(points:tuple[tuple[int,int],...])->int:
    n=len(points)
    if n<=300:
        distance=[10**30]*n;distance[0]=0;done=set();answer=0
        for _ in range(n):
            a=min((j for j in range(n) if j not in done),key=distance.__getitem__);done.add(a);answer+=distance[a];x,y=points[a]
            for j,(xx,yy) in enumerate(points):
                if j not in done:distance[j]=min(distance[j],abs(x-xx),abs(y-yy))
        return answer
    orders=[sorted(range(n),key=lambda j:points[j][axis]) for axis in (0,1)];parent=list(range(n));size=[1]*n;components=n;answer=0
    def find(a:int)->int:
        while a!=parent[a]:parent[a]=parent[parent[a]];a=parent[a]
        return a
    while components>1:
        choices:dict[int,tuple[int,int,int]]={}
        for order in orders:
            for a,b in zip(order,order[1:]):
                root_a,root_b=find(a),find(b)
                if root_a==root_b:continue
                weight=min(abs(points[a][0]-points[b][0]),abs(points[a][1]-points[b][1]));edge=(weight,a,b)
                for root in (root_a,root_b):
                    if root not in choices or edge<choices[root]:choices[root]=edge
        assert choices
        for weight,a,b in choices.values():
            a,b=find(a),find(b)
            if a==b:continue
            if size[a]<size[b]:a,b=b,a
            parent[b]=a;size[a]+=size[b];components-=1;answer+=weight
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc073_b':
        capacity,items=cast(tuple[int,tuple[tuple[int,int],...]],data);base=items[0][0];dp=[[-1]*(3*len(items)+1) for _ in range(len(items)+1)];dp[0][0]=0;done=0
        for weight,value in items:
            offset=weight-base
            for count in range(done,-1,-1):
                for extra in range(3*count+1):
                    if dp[count][extra]>=0:dp[count+1][extra+offset]=max(dp[count+1][extra+offset],dp[count][extra]+value)
            done+=1
        return str(max(value for count,row in enumerate(dp) for extra,value in enumerate(row) if count*base+extra<=capacity))
    if pid=='abc061_d':return max_walk(*cast(tuple[int,tuple[tuple[int,int,int],...]],data))
    if pid=='arc074_b':
        n,values=cast(tuple[int,tuple[int,...]],data);tree=Fenwick(values);left=[]
        for j,value in enumerate(values[:2*n]):
            tree.add(value)
            if j>=n-1:left.append(tree.sum-tree.smallest(tree.size-n))
        tree=Fenwick(values);right=[]
        for j,value in enumerate(reversed(values[n:])):
            tree.add(value)
            if j>=n-1:right.append(tree.smallest(n))
        return str(max(a-b for a,b in zip(left,reversed(right))))
    if pid=='arc075_b':
        a,b,health=cast(tuple[int,int,tuple[int,...]],data)
        if len(health)<=5 and max(health)<=20:
            start=tuple(health);queue=deque(((start,0),));seen={start}
            while queue:
                h,turns=queue.popleft()
                if not any(h):return str(turns)
                for center,v in enumerate(h):
                    if not v:continue
                    nxt=tuple(max(0,x-(a if j==center else b)) for j,x in enumerate(h))
                    if nxt not in seen:seen.add(nxt);queue.append((nxt,turns+1))
        extra=a-b
        def insufficient(turns:int)->bool:return sum((h-1-b*turns)//extra+1 for h in health if h>b*turns)>turns
        upper=1
        while insufficient(upper):upper*=2
        answer=-1;bit=1<<(upper.bit_length()-1)
        while bit:
            candidate=answer+bit
            if insufficient(candidate):answer=candidate
            bit//=2
        return str(answer+1)
    if pid=='abc064_d':return bracket_dp(cast(str,data[0]))
    return str(mst_oracle(cast(tuple[tuple[int,int],...],data[0])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'arc073_b':"n,W=map(int,input().split());a=[tuple(map(int,input().split())) for _ in range(n)];base=a[0][0];groups=[[] for _ in range(4)]\nfor w,v in a:groups[w-base].append(v)\nprefix=[]\nfor group in groups:\n group.sort(reverse=True);s=[0]\n for v in group:s.append(s[-1]+v)\n prefix.append(s)\nanswer=0\nfor i in range(len(prefix[0])):\n for j in range(len(prefix[1])):\n  for k in range(len(prefix[2])):\n   weight=i*base+j*(base+1)+k*(base+2)\n   if weight>W:continue\n   l=min(len(prefix[3])-1,(W-weight)//(base+3));answer=max(answer,prefix[0][i]+prefix[1][j]+prefix[2][k]+prefix[3][l])\nprint(answer)\n",
'abc061_d':"n,m=map(int,input().split());edges=[tuple(map(int,input().split())) for _ in range(m)];d=[None]*n;d[0]=0;bad=[False]*n\nfor step in range(2*n):\n changed=False\n for a,b,c in edges:\n  a-=1;b-=1\n  if d[a] is None:continue\n  if d[b] is None or d[b]<d[a]+c:\n   d[b]=d[a]+c;changed=True\n   if step>=n-1:bad[b]=True\n  if bad[a]:bad[b]=True\n if not changed:break\nprint('inf' if bad[-1] else d[-1])\n",
'arc074_b':"from heapq import heapify,heappushpop\nn=int(input());a=list(map(int,input().split()));heap=a[:n];heapify(heap);total=sum(heap);left=[total]\nfor x in a[n:2*n]:total+=x-heappushpop(heap,x);left.append(total)\nheap=[-x for x in a[2*n:]];heapify(heap);total=-sum(heap);right=[total]\nfor x in reversed(a[n:2*n]):total+=x+heappushpop(heap,-x);right.append(total)\nprint(max(x-y for x,y in zip(left,reversed(right))))\n",
'arc075_b':"n,a,b=map(int,input().split());h=[int(input()) for _ in range(n)];lo=0;hi=(max(h)+b-1)//b\nwhile lo<hi:\n mid=(lo+hi)//2;needed=sum(max(0,(x-b*mid+a-b-1)//(a-b)) for x in h)\n if needed<=mid:hi=mid\n else:lo=mid+1\nprint(lo)\n",
'abc064_d':"n=int(input());s=input();balance=minimum=0\nfor ch in s:balance+=1 if ch=='(' else -1;minimum=min(minimum,balance)\nadded=-minimum;print('('*added+s+')'*(balance+added))\n",
'arc076_b':"n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];edges=[]\nfor axis in (0,1):\n order=sorted(range(n),key=lambda j:points[j][axis])\n for a,b in zip(order,order[1:]):edges.append((points[b][axis]-points[a][axis],a,b))\nedges.sort();parent=list(range(n));size=[1]*n\ndef find(a):\n while a!=parent[a]:parent[a]=parent[parent[a]];a=parent[a]\n return a\nanswer=0\nfor w,a,b in edges:\n a,b=find(a),find(b)\n if a==b:continue\n if size[a]<size[b]:a,b=b,a\n parent[b]=a;size[a]+=size[b];answer+=w\nprint(answer)\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18200+TASKS.index(pid))
    if pid=='arc073_b':
        def bag(w:int,items:list[tuple[int,int]])->str:return line((len(items),w))+''.join(line(v) for v in items)
        raws=[bag(1,[(1,1)]),bag(1,[(2,1)]),bag(2,[(1,1),(4,10)]),bag(4,[(1,1),(2,3),(3,4),(4,5)])]
        for n in range(3,15):
            base=rng.randint(1,10);items=[(base,rng.randint(1,30))]+[(base+rng.randint(0,3),rng.randint(1,30)) for _ in range(n-1)];raws.append(bag(rng.randint(1,n*(base+3)),items))
        raws.extend([bag(150,[(1+j%4,10**7-j) for j in range(100)]),bag(10**9,[(10**9,10**7)]*100)])
    elif pid=='abc061_d':
        def graph(n:int,edges:list[tuple[int,int,int]])->str:return line((n,len(edges)))+''.join(line(v) for v in edges)
        raws=[graph(2,[(1,2,-10**9)]),graph(2,[(1,2,1),(2,1,1)]),graph(4,[(1,4,2),(2,3,1),(3,2,1)]),graph(4,[(1,2,1),(2,3,1),(3,2,1),(1,4,5)])]
        for n in range(4,16):
            edges=[(j,j+1,rng.randint(-20,20)) for j in range(1,n)];used={(a,b) for a,b,c in edges}
            for _ in range(n):
                a,b=sorted(rng.sample(range(1,n+1),2))
                if (a,b) not in used:edges.append((a,b,rng.randint(-20,20)));used.add((a,b))
            raws.append(graph(n,edges))
        # Reverse edge ordering forces long-path propagation in the reference.
        edges=[(j,j+1,-10**9) for j in range(1,1000)]+[(j,j+2,-10**9) for j in range(1,999)]+[(1,999,-10**9),(2,1000,-10**9),(3,1000,-10**9)]
        negative=[(j,j+1,-10**9) for j in range(1,1000)]+[(j+1,j,-10**9) for j in range(1,1000)]+[(3,1,-10**9),(4,1,-10**9)]
        raws.extend([graph(1000,list(reversed(negative))),graph(1000,[(a,b,10**9) for a,b,c in edges])])
    elif pid=='arc074_b':
        def numbers(a:list[int])->str:return f'{len(a)//3}\n'+line(a)
        raws=[numbers([1,1,1]),numbers([1,2,3]),numbers([3,2,1]),numbers([1,10**9,1])]
        for n in range(2,14):raws.append(numbers([rng.randint(1,100) for _ in range(3*n)]))
        raws[-1]=numbers([10**9]*100000+[1]*200000)
        raws.extend([numbers([(j*65537)%1000000000+1 for j in range(300000)]),numbers([10**9]*300000)])
    elif pid=='arc075_b':
        def monsters(a:int,b:int,h:list[int])->str:return line((len(h),a,b))+''.join(f'{v}\n' for v in h)
        raws=[monsters(2,1,[1]),monsters(2,1,[3]),monsters(10**9,1,[10**9]),monsters(3,2,[5,5])]
        for n in range(3,15):
            b=rng.randint(1,10);raws.append(monsters(b+rng.randint(1,10),b,[rng.randint(1,100) for _ in range(n)]))
        raws.extend([monsters(2,1,[10**9]*100000),monsters(10**9,10**9-1,[10**9]*100000)])
    elif pid=='abc064_d':
        words=['(',')','()','))']
        for n in range(3,15):words.append(''.join(rng.choice('()') for _ in range(n)))
        words.extend([')'*50+'('*50,'('*100]);raws=[f'{len(s)}\n{s}\n' for s in words]
    else:
        def cities(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[cities([(0,0),(0,0)]),cities([(0,0),(10**9,10**9)]),cities([(0,0),(0,10**9)]),cities([(1,1),(2,3),(3,2)])]
        for n in range(3,15):raws.append(cities([(rng.randint(0,100),rng.randint(0,100)) for _ in range(n)]))
        raws.extend([cities([(j*10000,(j*65537)%1000000001) for j in range(100000)]),cities([(10**9,10**9)]*100000)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'arc073_b':('重さは基準のw1から0〜3だけ増えます。','同じ重さの品物は価値順に並べ、各グループで選ぶ個数だけを決めます。','疑似コード: 重さ4種類ごとsort/value-prefix; 最初の3種類の選択数を全列挙; 残容量に入る4種類目の個数を選び価値最大を出力。'),
'abc061_d':('重みを負にすると最長得点は最短経路に対応します。','正の得点の閉路で、始点から到達でき、そこから終点へも行ける場合だけinfです。','疑似コード: Bellman-Fordで最大scoreをN回緩和; N回目以降の更新頂点とその先をbadにする; 終点badならinf、他はscore[N-1]。'),
'arc074_b':('前半と後半の境界を元の数列の中央N個の位置で試します。','左側から大きいN個、右側から小さいN個を選びます。heapで境界移動時の和を更新できます。','疑似コード: 左prefixにminheapで上位N和、右suffixにmaxheapで下位N和を保存; 全splitでleft[split]-right[split]最大。'),
'arc075_b':('爆発回数tを決めると全員へB*tのダメージを与えたと考えられます。','残りをA-Bの追加ダメージで処理するために必要な中心回数の合計がt以下なら可能です。','疑似コード: need(t)=sum(max(0,ceil((h-B*t)/(A-B)))); need(t)<=tとなる最小tをbinary search。'),
'abc064_d':('元の文字列を左から読んだときの括弧の釣り合いを調べます。','不足する開き括弧を先頭へ入れると辞書順も最小になります。最後に残る開き括弧を末尾の閉じ括弧で埋めます。','疑似コード: balanceを(で+1、)で-1; minimumを更新; left=-minimum,right=balance+left; (×left + S + )×rightを出力。'),
'arc076_b':('全ての街同士の道を考える代わりに、座標順で隣り合う街を考えます。','x順の隣接辺とy順の隣接辺だけで、最小全域木の重みを実現できます。','疑似コード: x/y各sortで隣接2頂点と座標差をedgesへ追加; edges重み順sort; Union-Findで異なる成分を結び重み合計。')}

TITLES={'arc073_b': 'Simple Knapsack', 'abc061_d': 'Score Attack', 'arc074_b': '3N Numbers', 'arc075_b': 'Widespread', 'abc064_d': 'Insertion', 'arc076_b': 'Built?'}
PUBLISHED_SAMPLES={'arc073_b': [{'input': '4 6\n2 1\n3 4\n4 10\n3 4\n', 'expected': '11\n'}, {'input': '4 6\n2 1\n3 7\n4 10\n3 6\n', 'expected': '13\n'}, {'input': '4 10\n1 100\n1 100\n1 100\n1 100\n', 'expected': '400\n'}, {'input': '4 1\n10 100\n10 100\n10 100\n10 100\n', 'expected': '0\n'}], 'abc061_d': [{'input': '3 3\n1 2 4\n2 3 3\n1 3 5\n', 'expected': '7\n'}, {'input': '2 2\n1 2 1\n2 1 1\n', 'expected': 'inf\n'}, {'input': '6 5\n1 2 -1000000000\n2 3 -1000000000\n3 4 -1000000000\n4 5 -1000000000\n5 6 -1000000000\n', 'expected': '-5000000000\n'}], 'arc074_b': [{'input': '2\n3 1 4 1 5 9\n', 'expected': '1\n'}, {'input': '1\n1 2 3\n', 'expected': '-1\n'}, {'input': '3\n8 2 2 7 4 6 5 3 8\n', 'expected': '5\n'}], 'arc075_b': [{'input': '4 5 3\n8\n7\n4\n2\n', 'expected': '2\n'}, {'input': '2 10 4\n20\n20\n', 'expected': '4\n'}, {'input': '5 2 1\n900000000\n900000000\n1000000000\n1000000000\n1000000000\n', 'expected': '800000000\n'}], 'abc064_d': [{'input': '3\n())\n', 'expected': '(())\n'}, {'input': '6\n)))())\n', 'expected': '(((()))())\n'}, {'input': '8\n))))((((\n', 'expected': '(((())))(((())))\n'}], 'arc076_b': [{'input': '3\n1 5\n3 9\n7 8\n', 'expected': '3\n'}, {'input': '6\n8 3\n4 9\n12 19\n18 1\n13 5\n7 6\n', 'expected': '8\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
