"""Statement-checked three-stage hints for ABC179–181 B."""
HINTS_V107 = {
    'abc179_b': (
        '必要なのは「ゾロ目が合計3回」ではなく「3回連続」です。左から順に、現在何回連続しているかだけ持てば十分です。',
        '各行で2個の出目が等しければ連続回数を1増やし、異なれば0へ戻します。連続回数が3になった瞬間にYesです。O(N)です。',
        '''疑似コード:\nstreak = 0\nfor each roll (a,b):\n  if a == b:\n    streak += 1\n  else:\n    streak = 0\n  if streak >= 3:\n    print("Yes") and finish\nprint("No")''',
    ),
    'abc180_b': (
        '3種類の距離は問題文に式がそのまま与えられています。各座標を1回ずつ走査して、絶対値の和・二乗和・絶対値の最大を集計します。',
        'Manhattanはsum(abs(x))、Euclideanはsqrt(sum(x*x))、Chebyshevはmax(abs(x))です。Nは10^5なのでO(N)で十分です。',
        '''疑似コード:\nmanhattan = 0\nsquared = 0\nchebyshev = 0\nfor x in X:\n  manhattan += abs(x)\n  squared += x*x\n  chebyshev = max(chebyshev, abs(x))\nprint(manhattan)\nprint(sqrt(squared))\nprint(chebyshev)''',
    ),
    'abc181_b': (
        '各区間の整数を1個ずつ列挙すると最大10^11個級になり得ます。AからBまでの和を数式で一度に求めてください。',
        '1からxまでの和はx(x+1)/2です。したがってA..Bの和はB(B+1)/2-(A-1)A/2で、これをN区間分足せばO(N)です。',
        '''疑似コード:\nanswer = 0\nfor each (A,B):\n  answer += B*(B+1)//2 - (A-1)*A//2\nprint(answer)''',
    ),
}
