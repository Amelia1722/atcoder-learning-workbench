"""ABC096..101 D, including complete prime-composite and Snuke domains."""
from __future__ import annotations
from functools import lru_cache
from itertools import combinations,product
from math import isqrt
from typing import cast
import random,re
TASKS=('abc096_d','arc097_b','arc098_b','abc099_d','abc100_d','arc099_b')
CONTESTS=dict(zip(TASKS,(f'abc{n:03}' for n in range(96,102))))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc096_d':'semantic'}
CHECKER_IDS={'abc096_d':'abc096_d'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def next_snuke(lower:int)->int:
    width=len(str(lower));best=10**width-1;best_sum=9*width
    for length in (width,width+1):
        bound=str(lower).zfill(length)
        @lru_cache(None)
        def least(position:int,remaining:int,tight:bool)->str|None:
            if position==length:return '' if remaining==0 else None
            digits_left=length-position-1;minimum=max(int(bound[position]) if tight else 0,1 if position==0 else 0,remaining-9*digits_left)
            for digit in range(minimum,min(9,remaining)+1):
                suffix=least(position+1,remaining-digit,tight and digit==int(bound[position]))
                if suffix is not None:return str(digit)+suffix
            return None
        for total in range(1,9*length+1):
            text=least(0,total,True)
            if text is None:continue
            candidate=int(text);comparison=candidate*best_sum-best*total
            if comparison<0 or comparison==0 and candidate<best:best=candidate;best_sum=total
    return best


@lru_cache(maxsize=1)
def snuke_numbers()->tuple[int,...]:
    numbers=[];lower=1
    while True:
        current=next_snuke(lower)
        if current>10**15:return tuple(numbers)
        numbers.append(current);lower=current+1

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc096_d':
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(5<=n<=55,'n');return (n,)
    if pid=='arc097_b':
        n,m=ints(rows[0],2);require(2<=n<=100000 and 1<=m<=100000 and len(rows)==m+2,'shape');p=ints(rows[1],n);require(set(p)==set(range(1,n+1)),'permutation');edges=tuple(ints(row,2) for row in rows[2:]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges) and len({(min(a,b),max(a,b)) for a,b in edges})==m,'edges');return p,edges
    if pid=='arc098_b':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000,'n');a=ints(rows[1],n);require(all(0<=v<1<<20 for v in a),'values');return (a,)
    if pid=='abc099_d':
        n,c=ints(rows[0],2);require(1<=n<=500 and 3<=c<=30 and len(rows)==c+n+1,'shape');costs=tuple(ints(row,c) for row in rows[1:c+1]);require(all(costs[i][i]==0 and all(1<=costs[i][j]<=1000 for j in range(c) if i!=j) for i in range(c)),'costs');grid=tuple(ints(row,n) for row in rows[c+1:]);require(all(1<=v<=c for row in grid for v in row),'grid');return costs,grid
    if pid=='abc100_d':
        n,m=ints(rows[0],2);require(1<=n<=1000 and 0<=m<=n and len(rows)==n+1,'shape');a=tuple(ints(row,3) for row in rows[1:]);require(all(-10**10<=v<=10**10 for point in a for v in point),'cakes');return m,a
    require(len(rows)==1,'shape');k=ints(rows[0],1)[0];require(1<=k<=len(snuke_numbers()),'Kth Snuke <=1e15');return (k,)

@lru_cache(maxsize=1)
def prime_table()->bytes:
    limit=5*55555;table=bytearray(b'\x01')*(limit+1);table[0]=table[1]=0
    for p in range(2,isqrt(limit)+1):
        if table[p]:table[p*p:limit+1:p]=b'\x00'*((limit-p*p)//p+1)
    return bytes(table)

def prime_list_valid(raw:str,actual:str)->bool:
    try:
        n=cast(int,validate('abc096_d',raw)[0]);values=ints(actual.removesuffix('\n'),n);table=prime_table()
        if len(set(values))!=n or any(not 2<=v<=55555 or not table[v] for v in values):return False
        # A nonzero common residue mod5 is sufficient, but not necessary.
        residues={v%5 for v in values}
        if len(residues)==1 and 0 not in residues:return True
        return all(not table[sum(chosen)] for chosen in combinations(values,5))
    except (ValueError,TypeError,IndexError):return False

def trial_prime(n:int)->bool:return n>=2 and all(n%p for p in range(2,isqrt(n)+1))

def color_assignment(costs:tuple[tuple[int,...],...],grid:tuple[tuple[int,...],...])->int:
    c=len(costs);hist=[[0]*c for _ in range(3)]
    for r,row in enumerate(grid):
        for column,value in enumerate(row):hist[(r+column)%3][value-1]+=1
    values=[[sum(hist[group][old]*costs[old][color] for old in range(c)) for color in range(c)] for group in range(3)];dp=[10**30]*8;dp[0]=0
    for color in range(c):
        new=dp.copy()
        for mask in range(8):
            for group in range(3):
                if not mask>>group&1:new[mask|1<<group]=min(new[mask|1<<group],dp[mask]+values[group][color])
        dp=new
    return dp[7]

def cake_cardinality(m:int,a:tuple[tuple[int,...],...])->int:
    if m==0:return 0
    if m==len(a):return sum(abs(sum(point[axis] for point in a)) for axis in range(3))
    if len(a)<=15:return max(sum(abs(sum(point[axis] for point in chosen)) for axis in range(3)) for chosen in combinations(a,m))
    answer=0
    for signs in product((-1,1),repeat=3):
        dp:list[int|None]=[None]*(m+1);dp[0]=0
        for j,point in enumerate(a):
            value=sum(sign*coordinate for sign,coordinate in zip(signs,point))
            for count in range(min(j,m-1),-1,-1):
                old=dp[count]
                if old is not None:
                    candidate=old+value;current=dp[count+1]
                    if current is None or current<candidate:dp[count+1]=candidate
        answer=max(answer,cast(int,dp[m]))
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc096_d':
        n=cast(int,data[0]);primes=[v for v in range(19,55556,5) if trial_prime(v)];return ' '.join(map(str,primes[:n]))
    if pid=='arc097_b':
        permutation,edges=cast(tuple[tuple[int,...],tuple[tuple[int,int],...]],data);n=len(permutation);graph=[[] for _ in range(n)];component=[-1]*n
        for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
        for start in range(n):
            if component[start]!=-1:continue
            component[start]=start;stack=[start]
            while stack:
                for nxt in graph[stack.pop()]:
                    if component[nxt]==-1:component[nxt]=start;stack.append(nxt)
        return str(sum(component[j]==component[value-1] for j,value in enumerate(permutation)))
    if pid=='arc098_b':
        values=cast(tuple[int,...],data[0]);last=[-1]*20;left=answer=0
        for j,value in enumerate(values):
            bits=value
            while bits:
                bit=(bits&-bits).bit_length()-1;left=max(left,last[bit]+1);last[bit]=j;bits&=bits-1
            answer+=j-left+1
        return str(answer)
    if pid=='abc099_d':return str(color_assignment(*cast(tuple[tuple[tuple[int,...],...],tuple[tuple[int,...],...]],data)))
    if pid=='abc100_d':return str(cake_cardinality(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
    return '\n'.join(map(str,snuke_numbers()[:cast(int,data[0])]))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc096_d':return prime_list_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc096_d':return prime_list_valid(raw,expected) and prime_list_valid(raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc096_d':"n=int(input());prime=[True]*55556;prime[0]=prime[1]=False\nfor p in range(2,236):\n if prime[p]:\n  for j in range(p*p,55556,p):prime[j]=False\nprint(*[v for v in range(2,55556) if prime[v] and v%5==1][:n])\n",
'arc097_b':"n,m=map(int,input().split());p=list(map(int,input().split()));parent=list(range(n));size=[1]*n\ndef find(a):\n while a!=parent[a]:parent[a]=parent[parent[a]];a=parent[a]\n return a\nfor _ in range(m):\n a,b=map(int,input().split());a,b=find(a-1),find(b-1)\n if a!=b:\n  if size[a]<size[b]:a,b=b,a\n  parent[b]=a;size[a]+=size[b]\nprint(sum(find(j)==find(v-1) for j,v in enumerate(p)))\n",
'arc098_b':"n=int(input());a=list(map(int,input().split()));left=mask=answer=0\nfor right,value in enumerate(a):\n while mask&value:mask^=a[left];left+=1\n mask|=value;answer+=right-left+1\nprint(answer)\n",
'abc099_d':"from itertools import permutations\nn,c=map(int,input().split());d=[list(map(int,input().split())) for _ in range(c)];hist=[[0]*c for _ in range(3)]\nfor r in range(n):\n for column,v in enumerate(map(int,input().split())):hist[(r+column)%3][v-1]+=1\ncost=[[sum(hist[group][old]*d[old][new] for old in range(c)) for new in range(c)] for group in range(3)]\nprint(min(sum(cost[g][color] for g,color in enumerate(colors)) for colors in permutations(range(c),3)))\n",
'abc100_d':"from itertools import product\nn,m=map(int,input().split());a=[tuple(map(int,input().split())) for _ in range(n)];print(max(sum(sorted((sum(s*v for s,v in zip(signs,point)) for point in a),reverse=True)[:m]) for signs in product((-1,1),repeat=3)))\n",
'arc099_b':"k=int(input());current=step=1\ndef S(n):return sum(map(int,str(n)))\nfor _ in range(k):\n print(current)\n while (current+step)*S(current+10*step)>(current+10*step)*S(current+step):step*=10\n current+=step\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18400+TASKS.index(pid))
    if pid=='abc096_d':raws=[f'{n}\n' for n in [5,6,7,8,*range(9,21),54,55]]
    elif pid=='arc097_b':
        def permutation(p:list[int],edges:list[tuple[int,int]])->str:return line((len(p),len(edges)))+line(p)+''.join(line(v) for v in edges)
        raws=[permutation([1,2],[(1,2)]),permutation([2,1],[(1,2)]),permutation([3,2,1],[(1,2)]),permutation([3,2,1],[(1,2),(2,3)])]
        for n in range(4,16):
            p=list(range(1,n+1));rng.shuffle(p);edges=[(j,j+1) for j in range(1,n) if rng.randrange(2)];edges=edges or [(1,2)];raws.append(permutation(p,edges))
        edges=[(j,j+1) for j in range(1,100000)]+[(1,100000)];raws.extend([permutation(list(range(100000,0,-1)),edges),permutation(list(range(1,100001)),edges)])
    elif pid=='arc098_b':
        arrays=[[0],[1],[(1<<20)-1],[0,1,0]]
        for n in range(2,14):arrays.append([rng.randrange(1<<20) for _ in range(n)])
        arrays.extend([[0]*200000,[(1<<20)-1]*200000]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    elif pid=='abc099_d':
        def grid(n:int,c:int,mode:int)->str:
            costs=[[0 if i==j else rng.randint(1,1000) if mode==1 else 1000 for j in range(c)] for i in range(c)]
            board=[[rng.randint(1,c) if mode==1 else (r+j)%c+1 for j in range(n)] for r in range(n)]
            return line((n,c))+''.join(line(row) for row in costs)+''.join(line(row) for row in board)
        raws=[grid(1,3,0),grid(1,30,0),grid(2,3,0),grid(2,4,1)]
        raws.extend(grid(n,rng.randint(3,10),1) for n in range(3,15));raws.extend([grid(500,30,1),grid(500,30,0)])
    elif pid=='abc100_d':
        def cakes(m:int,a:list[tuple[int,int,int]])->str:return line((len(a),m))+''.join(line(p) for p in a)
        raws=[cakes(0,[(0,0,0)]),cakes(1,[(-10**10,)*3]),cakes(1,[(10**10,)*3]),cakes(1,[(0,0,0),(1,-1,1)])]
        for n in range(2,14):raws.append(cakes(rng.randint(0,n),[tuple(rng.randint(-100,100) for _ in range(3)) for j in range(n)]))
        raws.extend([cakes(500,[tuple(10**10 if j>>axis&1 else -10**10 for axis in range(3)) for j in range(1000)]),cakes(1000,[(10**10,)*3]*1000)])
    else:
        maximum=len(snuke_numbers());raws=[f'{k}\n' for k in [1,2,3,9,*range(10,22),maximum-1,maximum]]
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc096_d':('5個の和を、必ずある小さな素数の倍数にする方法を考えます。','5で割った余りが同じで5以外の素数を集めると、5個の和が5の倍数になり、しかも5より大きくなります。','疑似コード: sieveで55555まで素数を列挙; primeかつp%5==1の先頭N個を出力。'),
'arc097_b':('交換できる添字のつながりをグラフとして考えます。','同じ連結成分内の要素は自由に並べ替えられます。添字iと値p[i]の本来の位置が同じ成分か調べます。','疑似コード: 各交換辺でUnion-Find.merge(x,y); 全iでfind(i)==find(p[i]-1)の個数を出力。'),
'arc098_b':('sumとxorが一致するのは、各ビットが区間内で重複しないときです。','右端を追加してビットが重複したら、重複が消えるまで左端を進めます。各右端で有効な左端数を加算します。','疑似コード: mask=0,left=0; 各vでmask&vが非0ならmask^=A[left],left++; mask|=v; answer+=right-left+1。'),
'abc099_d':('同じ(i+j)%3のマスは、同じ最終色になります。','3グループそれぞれを各色へ塗る費用を集計します。その後、異なる3色の割当を全列挙できます。','疑似コード: count[group][old]を集計; cost[group][new]=sum(count*D[old][new]); 異なるc0,c1,c2の3費用和の最小値。'),
'abc100_d':('3つの和それぞれの符号を決めると、絶対値を外せます。','符号の組合せは8通りです。その符号で評価した各ケーキの値を降順に並べ、上位M個を選びます。','疑似コード: signx,signy,signz各±1を全列挙; score=signx*x+signy*y+signz*zをsort; 上位M和の最大値を出力。'),
'arc099_b':('すぬけ数には末尾に9が並ぶ数が多く現れます。','次の候補current+stepとcurrent+10*stepの値/桁和を比べ、後者が小さければstepを10倍にします。浮動小数点ではなく交差積を使います。','疑似コード: current=step=1; K回currentを出力; (current+step)*S(current+10step)>(current+10step)*S(current+step)ならstep*=10を反復; current+=step。')}

TITLES={'abc096_d': 'Five, Five Everywhere', 'arc097_b': 'Equals', 'arc098_b': 'Xor Sum 2', 'abc099_d': 'Good Grid', 'abc100_d': 'Patisserie ABC', 'arc099_b': 'Snuke Numbers'}
PUBLISHED_SAMPLES={'abc096_d': [{'input': '5\n', 'expected': '3 5 7 11 31\n'}, {'input': '6\n', 'expected': '2 3 5 7 11 13\n'}, {'input': '8\n', 'expected': '2 5 7 13 19 37 67 79\n'}], 'arc097_b': [{'input': '5 2\n5 3 1 4 2\n1 3\n5 4\n', 'expected': '2\n'}, {'input': '3 2\n3 2 1\n1 2\n2 3\n', 'expected': '3\n'}, {'input': '10 8\n5 3 6 8 7 10 9 1 2 4\n3 1\n4 1\n5 9\n2 5\n6 5\n3 5\n8 9\n7 9\n', 'expected': '8\n'}, {'input': '5 1\n1 2 3 4 5\n1 5\n', 'expected': '5\n'}], 'arc098_b': [{'input': '4\n2 5 4 6\n', 'expected': '5\n'}, {'input': '9\n0 0 0 0 0 0 0 0 0\n', 'expected': '45\n'}, {'input': '19\n885 8 1 128 83 32 256 206 639 16 4 128 689 32 8 64 885 969 1\n', 'expected': '37\n'}], 'abc099_d': [{'input': '2 3\n0 1 1\n1 0 1\n1 4 0\n1 2\n3 3\n', 'expected': '3\n'}, {'input': '4 3\n0 12 71\n81 0 53\n14 92 0\n1 1 2 1\n2 1 1 2\n2 2 1 3\n1 1 2 2\n', 'expected': '428\n'}], 'abc100_d': [{'input': '5 3\n3 1 4\n1 5 9\n2 6 5\n3 5 8\n9 7 9\n', 'expected': '56\n'}, {'input': '5 3\n1 -2 3\n-4 5 -6\n7 -8 -9\n-10 11 -12\n13 -14 15\n', 'expected': '54\n'}, {'input': '10 5\n10 -80 21\n23 8 38\n-94 28 11\n-26 -2 18\n-69 72 79\n-26 -86 -54\n-72 -50 59\n21 65 -32\n40 -94 87\n-62 18 82\n', 'expected': '638\n'}, {'input': '3 2\n2000000000 -9000000000 4000000000\n7000000000 -5000000000 3000000000\n6000000000 -1000000000 8000000000\n', 'expected': '30000000000\n'}], 'arc099_b': [{'input': '10\n', 'expected': '1\n2\n3\n4\n5\n6\n7\n8\n9\n19\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
