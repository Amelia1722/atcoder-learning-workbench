"""Four more independently authored ABC problem-specific test generators and checkers."""
from __future__ import annotations

import random
from bisect import bisect_left
from collections import Counter
from math import gcd

EXTRA = {
 'abc152_c': {'sample_input':'5\n4 2 5 1 3\n','sample_output':'3',
  'source_url':'https://atcoder.jp/contests/abc152/tasks/abc152_c',
  'constraints':'1<=N<=200000; P is a permutation of 1..N'},
 'abc174_c': {'sample_input':'101\n','sample_output':'4',
  'source_url':'https://atcoder.jp/contests/abc174/tasks/abc174_c',
  'constraints':'1<=K<=1000000'},
 'abc177_c': {'sample_input':'3\n1 2 3\n','sample_output':'11',
  'source_url':'https://atcoder.jp/contests/abc177/tasks/abc177_c',
  'constraints':'2<=N<=200000; 0<=Ai<=1000000000'},
 'abc231_c': {'sample_input':'3 1\n100 160 130\n120\n','sample_output':'2',
  'source_url':'https://atcoder.jp/contests/abc231/tasks/abc231_c',
  'constraints':'1<=N,Q<=200000; 1<=Ai,Xi<=1000000000'},
}


def validate(pid: str, data: str):
    f=data.split()
    if not f or any(not s.isascii() or not s.isdecimal() for s in f):
        raise ValueError('非負整数以外が含まれています')
    if pid == 'abc174_c':
        if len(f)!=1 or not 1<=int(f[0])<=1_000_000:raise ValueError('K: 1..1000000')
        return (int(f[0]),)
    if pid == 'abc231_c':
        if len(f)<4:raise ValueError('N Q A X が必要です')
        n,q=map(int,f[:2])
        if not 1<=n<=200000 or not 1<=q<=200000 or len(f)!=2+n+q:
            raise ValueError('N Q と個数が不正です')
        a=list(map(int,f[2:2+n])); x=list(map(int,f[2+n:]))
        if any(not 1<=v<=10**9 for v in a+x):raise ValueError('Ai Xi の値域違反')
        return n,q,a,x
    n=int(f[0]);limit=200000
    low=1 if pid=='abc152_c' else 2
    if not low<=n<=limit or len(f)!=1+n:raise ValueError('N と要素数が不正です')
    a=list(map(int,f[1:]))
    if pid=='abc152_c':
        if min(a)!=1 or max(a)!=n or len(set(a))!=n:
            raise ValueError('P は1..Nの順列でなければなりません')
    elif any(not 0<=v<=10**9 for v in a):raise ValueError('Ai の値域違反')
    return n,a


def generate(pid: str,count:int,seed:int,include_large:bool)->list[dict[str,str]]:
    if pid not in EXTRA or not 1<=count<=80:raise ValueError('ID 又は件数が不正です')
    rnd=random.Random(seed)
    cases=[]
    seen=set()
    def add(kind:str,data:str):
        validate(pid,data)
        if data not in seen:
            seen.add(data);cases.append({'category':kind,'input':data})
    def array_case(kind:str,a:list[int]):add(kind,f'{len(a)}\n'+ ' '.join(map(str,a))+'\n')
    if pid=='abc152_c':
        array_case('constraint_min',[1])
        array_case('usual',[4,2,5,1,3])
        array_case('ascending',list(range(1,20)))
        array_case('descending',list(range(20,0,-1)))
        array_case('minimum_last',[*range(2,21),1])
        while len(cases)<count:
            n=rnd.randint(2,40);a=list(range(1,n+1));rnd.shuffle(a)
            array_case('random',a)
        if include_large:
            # Ascending (one record) is also a genuine maximum-scale permutation.
            array_case('constraint_max_n',list(range(1,200001)))
    elif pid=='abc174_c':
        for kind,k in [('constraint_min',1),('typical',101),('impossible_even',2),
                       ('impossible_five',5),('seven',7),('constraint_max',1000000),
                       ('near_max_prime',999983),('three',3),('multiples_of_seven',49)]:
            add(kind,f'{k}\n')
        while len(cases)<count:add('random',f'{rnd.randint(1,1000000)}\n')
    elif pid=='abc177_c':
        array_case('constraint_min',[0,0])
        array_case('usual',[1,2,3])
        array_case('all_zero',[0]*10)
        array_case('all_max',[10**9]*10)
        array_case('alternating',[0,10**9]*10)
        array_case('one_nonzero',[0]*11+[10**9])
        while len(cases)<count:
            n=rnd.randint(2,40)
            array_case('random',[rnd.randint(0,10**9) for _ in range(n)])
        if include_large:array_case('constraint_max_n',[10**9 if i&1 else 0 for i in range(200000)])
    else:
        def query_case(kind:str,a:list[int],x:list[int]):
            add(kind,f'{len(a)} {len(x)}\n'+' '.join(map(str,a))+'\n'+'\n'.join(map(str,x))+'\n')
        query_case('constraint_min',[1],[1])
        query_case('usual',[100,160,130],[120])
        query_case('all_equal',[7]*7,[1,7,8,10**9])
        query_case('boundary',[1,10**9],[1,2,10**9])
        query_case('no_matches',[1]*8,[10**9]*5)
        query_case('all_matches',[10**9]*8,[1]*5)
        while len(cases)<count:
            n=rnd.randint(1,40);q=rnd.randint(1,40)
            query_case('random',[rnd.randint(1,10**9) for _ in range(n)],
                       [rnd.randint(1,10**9) for _ in range(q)])
        if include_large:
            # Both N and Q reach their official maximum; output has 200,000 lines.
            n=200000
            query_case('constraint_max_n_q',[1+(i%100000) for i in range(n)],
                       [1+(i*971)%1000000000 for i in range(n)])
    return cases[:count] + ([c for c in cases[count:] if c['category'].startswith('constraint_max')] if include_large else [])


def independent_check(pid:str,data:str,expected:str)->bool:
    args=validate(pid,data)
    if pid=='abc152_c':
        n,a=args
        # Value-order method: a new prefix minimum at x must occur BEFORE all
        # previously inspected smaller values in the permutation.
        pos=[0]*(n+1)
        for i,x in enumerate(a):pos[x]=i
        best=n;records=0
        for x in range(1,n+1):
            if pos[x]<best:records+=1
            best=min(best,pos[x])
        return expected.strip()==str(records)
    if pid=='abc174_c':
        (k,)=args
        s=expected.strip()
        if s=='-1':return gcd(k,10)!=1
        try: length=int(s)
        except ValueError:return False
        if not 1<=length<=k:return False
        # Divisibility test using modular exponentiation (no giant integer).
        modulus=9*k
        def divisible(size:int)->bool:
            return (7*(pow(10,size,modulus)-1))%modulus==0
        if not divisible(length):return False
        # First solution length is a period: no proper prime-factor quotient
        # may be a solution, otherwise this length is not minimal.
        t=length;p=2
        while p*p<=t:
            if t%p==0:
                if divisible(length//p):return False
                while t%p==0:t//=p
            p+=1
        return not(t>1 and divisible(length//t))
    if pid=='abc177_c':
        n,a=args
        MOD=10**9+7
        result=((sum(a)**2-sum(x*x for x in a))//2)%MOD
        return expected.strip()==str(result)
    n,q,a,x=args
    # Query-sort sweep, independent from bisect-based solution.
    heights=sorted(a,reverse=True)
    queries=sorted(enumerate(x),key=lambda item:-item[1])
    answers=[0]*q;i=0
    for j,threshold in queries:
        while i<n and heights[i]>=threshold:i+=1
        answers[j]=i
    return expected.strip()=='\n'.join(map(str,answers))
