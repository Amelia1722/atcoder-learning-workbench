"""ABC275–277 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc275_b', 'abc276_b', 'abc277_b')
MOD = 998244353
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
CARD = re.compile(r'[A-Z0-9]{2}', re.ASCII)
VALID_CARD = re.compile(r'[HDCS][A2-9TJQK]', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc275_b': [
        {'input': '2 3 5 1 2 4\n', 'expected': '22\n'},
        {'input': '1 1 1000000000 0 0 0\n', 'expected': '1755647\n'},
        {'input': '1000000000000000000 1000000000000000000 1000000000000000000 1000000000000000000 1000000000000000000 1000000000000000000\n', 'expected': '0\n'},
    ],
    'abc276_b': [
        {
            'input': '6 6\n3 6\n1 3\n5 6\n2 5\n1 2\n1 6\n',
            'expected': '3 2 3 6\n2 1 5\n2 1 6\n0\n2 2 6\n3 1 3 5\n',
        },
        {
            'input': '5 10\n1 2\n1 3\n1 4\n1 5\n2 3\n2 4\n2 5\n3 4\n3 5\n4 5\n',
            'expected': '4 2 3 4 5\n4 1 3 4 5\n4 1 2 4 5\n4 1 2 3 5\n4 1 2 3 4\n',
        },
    ],
    'abc277_b': [
        {'input': '4\nH3\nDA\nD3\nSK\n', 'expected': 'Yes\n'},
        {'input': '5\nH3\nDA\nCK\nH3\nS7\n', 'expected': 'No\n'},
        {'input': '4\n3H\nAD\n3D\nKS\n', 'expected': 'No\n'},
        {'input': '5\n00\nAA\nXX\nYY\nZZ\n', 'expected': 'No\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate275(raw: str) -> tuple[int, int, int, int, int, int]:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    vals = _ints_line(lines[0])
    if len(vals) != 6 or any(not 0 <= x <= 10**18 for x in vals):
        raise ValueError('constraints')
    a, b, c, d, e, f = vals
    if a * b * c < d * e * f:
        raise ValueError('product order')
    return a, b, c, d, e, f


def _validate276(raw: str) -> tuple[int, list[tuple[int, int]]]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 2:
        raise ValueError('header')
    n, m = head
    if not (2 <= n <= 10**5 and 1 <= m <= 10**5) or len(lines) != m + 1:
        raise ValueError('constraints')
    edges: list[tuple[int, int]] = []
    seen: set[tuple[int, int]] = set()
    for line in lines[1:]:
        vals = _ints_line(line)
        if len(vals) != 2:
            raise ValueError('edge')
        a, b = vals
        if not (1 <= a < b <= n) or (a, b) in seen:
            raise ValueError('edge constraints')
        seen.add((a, b))
        edges.append((a, b))
    return n, edges


def _validate277(raw: str) -> list[str]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 1:
        raise ValueError('header')
    n = head[0]
    if not 1 <= n <= 52 or len(lines) != n + 1:
        raise ValueError('constraints')
    cards = lines[1:]
    if any(CARD.fullmatch(card) is None for card in cards):
        raise ValueError('card syntax')
    return cards


def validate(pid: str, raw: str):
    if pid == 'abc275_b':
        return _validate275(raw)
    if pid == 'abc276_b':
        return _validate276(raw)
    if pid == 'abc277_b':
        return _validate277(raw)
    raise ValueError('unknown task')


def _oracle275(vals: tuple[int, int, int, int, int, int]) -> int:
    a, b, c, d, e, f = vals
    return (a * b * c - d * e * f) % MOD


def _oracle276(n: int, edges: list[tuple[int, int]]) -> list[list[int]]:
    adj = [set() for _ in range(n)]
    for a, b in edges:
        adj[a - 1].add(b)
        adj[b - 1].add(a)
    return [sorted(s) for s in adj]


def _oracle277(cards: list[str]) -> str:
    return 'Yes' if len(set(cards)) == len(cards) and all(VALID_CARD.fullmatch(card) for card in cards) else 'No'


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc275_b':
        return INT.fullmatch(output) is not None and int(output) == _oracle275(value)
    if pid == 'abc277_b':
        return output in ('Yes', 'No') and output == _oracle277(value)

    n, edges = value
    lines = output.split('\n')
    if len(lines) != n:
        return False
    expected = _oracle276(n, edges)
    for line, want in zip(lines, expected):
        try:
            vals = _ints_line(line)
        except ValueError:
            return False
        if not vals or vals[0] != len(want) or vals[1:] != want:
            return False
    return True


def _graph_input(n: int, edges: list[tuple[int, int]]) -> str:
    return f'{n} {len(edges)}\n' + '\n'.join(f'{a} {b}' for a, b in edges) + '\n'


def _cards_input(cards: list[str]) -> str:
    return f'{len(cards)}\n' + '\n'.join(cards) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc275_b':
        custom = [
            ('all_zero', '0 0 0 0 0 0\n'),
            ('one_minus_zero', '1 1 1 0 0 0\n'),
            ('equal_small', '2 3 4 4 3 2\n'),
            ('one_side_zero', '10 20 30 0 999 999\n'),
            ('mod_exact', f'1 1 {MOD} 0 0 0\n'),
            ('mod_plus_one', f'1 1 {MOD + 1} 0 0 0\n'),
            ('two_mods', f'2 1 {MOD} 0 0 0\n'),
            ('difference_mod', f'{MOD + 10} 2 3 10 2 3\n'),
            ('large_equal', '999999999999999999 999999999999999999 1 999999999999999999 999999999999999999 1\n'),
            ('large_small_rhs', '1000000000000000000 999999999999999999 2 999999999999999999 999999999999999999 2\n'),
            ('mixed_zeros', '1000000000000000000 0 1000000000000000000 0 1000000000000000000 1000000000000000000\n'),
            ('rhs_nonzero', '123456789 987654321 111111111 12345 67890 13579\n'),
            ('near_max', '1000000000000000000 1000000000000000000 999999999999999999 999999999999999999 999999999999999999 999999999999999999\n'),
            ('small_diff', '1000000 1000000 1000000 999999 1000000 1000000\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', '1000000000000000000 1000000000000000000 1000000000000000000 999999999999999999 1000000000000000000 1000000000000000000\n')

    elif pid == 'abc276_b':
        custom_graphs = [
            ('minimum_edge', 2, [(1, 2)]),
            ('three_path', 3, [(1, 2), (2, 3)]),
            ('three_triangle', 3, [(1, 2), (1, 3), (2, 3)]),
            ('four_star', 4, [(1, 2), (1, 3), (1, 4)]),
            ('four_path', 4, [(1, 2), (2, 3), (3, 4)]),
            ('five_cycle', 5, [(1, 2), (2, 3), (3, 4), (4, 5), (1, 5)]),
            ('five_sparse', 5, [(1, 5)]),
            ('six_two_components', 6, [(1, 2), (2, 3), (4, 5), (5, 6)]),
            ('six_complete', 6, [(i, j) for i in range(1, 7) for j in range(i + 1, 7)]),
            ('ten_star_last', 10, [(i, 10) for i in range(1, 10)]),
            ('ten_matching', 10, [(1, 10), (2, 9), (3, 8), (4, 7), (5, 6)]),
            ('twenty_path', 20, [(i, i + 1) for i in range(1, 20)]),
            ('hundred_sparse', 100, [(1, 100), (2, 99), (50, 51)]),
            ('thousand_star', 1000, [(1, i) for i in range(2, 1001)]),
            ('large_chain', 50000, [(i, i + 1) for i in range(1, 50000)]),
        ]
        for category, n, edges in custom_graphs:
            add(category, _graph_input(n, edges))
        max_edges = [(i, i + 1) for i in range(1, 100000)] + [(1, 100000)]
        add('constraint_max', _graph_input(100000, max_edges))

    else:
        valid_deck = [s + r for s in 'HDCS' for r in 'A23456789TJQK']
        custom_cards = [
            ('single_valid', ['HA']),
            ('single_bad_suit', ['XA']),
            ('single_bad_rank', ['H0']),
            ('duplicate_two', ['SA', 'SA']),
            ('all_suits_ace', ['HA', 'DA', 'CA', 'SA']),
            ('all_ranks_hearts', ['H' + r for r in 'A23456789TJQK']),
            ('valid_mixed', ['H2', 'DT', 'CJ', 'SQ', 'HK']),
            ('late_duplicate', ['HA', 'D2', 'C3', 'S4', 'HA']),
            ('bad_suit_middle', ['HA', 'D2', 'Z3', 'S4']),
            ('bad_rank_middle', ['HA', 'D2', 'C1', 'S4']),
            ('digit_first_invalid', ['2A']),
            ('letter_second_invalid', ['HH']),
            ('half_deck_valid', valid_deck[:26]),
        ]
        for category, cards in custom_cards:
            add(category, _cards_input(cards))
        add('constraint_max', _cards_input(valid_deck))

    if len(out) != 18:
        raise AssertionError((pid, len(out), [x['category'] for x in out]))
    return out
