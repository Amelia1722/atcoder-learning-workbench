"""Statement-checked three-stage hints for ABC290–301 B."""
HINTS_V144 = {
    'abc290_b': (
        '左から見て、残せる o の個数は K 個だけです。何文字目まで残したかではなく、これまで残した o の個数だけ持てば十分です。',
        'S を左から走査し、o かつまだ K 個未満なら o を出力して個数を増やします。それ以外は x にします。',
        '疑似コード:\nread N, K, S\nused = 0\nans = empty\nfor ch in S:\n  if ch == o and used < K:\n    append o to ans\n    used += 1\n  else:\n    append x to ans\nprint(ans)',
    ),
    'abc291_b': (
        '5N 個の得点のうち、不要なのは小さい方から N 個と大きい方から N 個です。残る 3N 個だけの平均を求めます。',
        '得点を sort し、添字 N から 4N-1 までを合計して 3N で割ればよいです。',
        '疑似コード:\nread N\nread X[1..5N]\nsort X\nmid = X[N : 4N]\nprint(sum(mid) / (3*N))',
    ),
    'abc292_b': (
        '退場条件は「黄色カード2枚」または「赤カード1枚」です。各選手について、その条件に達したかを管理します。',
        '黄色を +1、赤を即座に2相当として扱えば、問い合わせでは値が2以上かを見るだけです。',
        '疑似コード:\nread N, Q\ncard[1..N] = 0\nrepeat Q times:\n  read c, x\n  if c == 1: card[x] += 1\n  if c == 2: card[x] = 2\n  if c == 3: print(Yes if card[x] >= 2 else No)',
    ),
    'abc293_b': (
        'i 番の人が呼ぶのは「i 番がその時点でまだ呼ばれていない場合」だけです。誰が呼ばれたかを bool 配列で管理してください。',
        '1 から N まで順に見て、i が未呼出なら A_i を呼出済みにします。最後まで未呼出の番号を昇順で出します。',
        '疑似コード:\nread N, A\ncalled[1..N] = false\nfor i = 1..N:\n  if not called[i]:\n    called[A[i]] = true\nans = all i with called[i] == false\nprint(len(ans))\nprint(ans)',
    ),
    'abc294_b': (
        '各マスは独立です。0 だけ特別に .、1〜26 はアルファベットの何文字目かへ変換します。',
        '変換表 `.ABCDEFGHIJKLMNOPQRSTUVWXYZ` を用意すれば、値 x をそのまま添字として文字へ変換できます。',
        '疑似コード:\nread H, W, A\nchars = ".ABCDEFGHIJKLMNOPQRSTUVWXYZ"\nfor each row in A:\n  line = empty\n  for x in row:\n    append chars[x] to line\n  print(line)',
    ),
    'abc295_b': (
        '爆弾が壊す壁はマンハッタン距離が爆発範囲以下のマスです。元盤面にある爆弾を先に列挙しておくと安全です。',
        '各マスについて、いずれかの爆弾 (r,c,p) が `|i-r|+|j-c| <= p` を満たすなら .、そうでなければ元の文字を残します。',
        '疑似コード:\nread R, C, grid\nbombs = all cells containing digit p\nfor i = 0..R-1:\n  for j = 0..C-1:\n    if exists bomb (r,c,p) with abs(i-r)+abs(j-c)<=p:\n      ans[i][j] = .\n    else:\n      ans[i][j] = grid[i][j]\nprint ans',
    ),
    'abc296_b': (
        '必要なのは * の行と列だけです。盤面上の列は左から a〜h、行番号は下から1〜8です。',
        '上から i 行目（0-index）ならチェスの行番号は `8-i`、左から j 列目なら列文字は `chr(ord(a)+j)` です。',
        '疑似コード:\nread 8 rows\nfor i = 0..7:\n  for j = 0..7:\n    if grid[i][j] == *:\n      file = chr(ord(a)+j)\n      rank = 8-i\n      print(file + rank)',
    ),
    'abc297_b': (
        'Yes には2条件あります。2個の B が異なる色のマスにあり、K が2個の R の間にあることです。',
        'B の位置の偶奇が異なることを確認し、さらに R と K だけ抜き出した並びが R,K,R なら条件を満たします。',
        '疑似コード:\nread S\nb = indices where S[i] == B\ncond1 = b[0] % 2 != b[1] % 2\nrk = characters of S that are R or K\ncond2 = (rk == [R,K,R])\nprint(Yes if cond1 and cond2 else No)',
    ),
    'abc298_b': (
        'A は高々4種類の向きしかありません。各向きについて、A の1がある場所で B も1かを確認します。',
        '判定後に A を90度回転する操作を4回繰り返せば全向きを調べられます。回転は `new[j][N-1-i]=old[i][j]` です。',
        '疑似コード:\nread N, A, B\nrepeat 4 times:\n  ok = true\n  for i,j:\n    if A[i][j] == 1 and B[i][j] == 0: ok = false\n  if ok: print Yes; stop\n  A = rotate90(A)\nprint No',
    ),
    'abc299_b': (
        'まず勝敗判定に使う色を決めます。色 T のカードが1枚でもあれば T、なければ1人目の色 C_1 です。',
        '決めた色を持つ人だけを見て、数 R_i が最大の人の番号を保持します。R_i は相異なるので同率処理は不要です。',
        '疑似コード:\nread N, T, C, R\ncolor = T if T exists in C else C[1]\nbest = none\nfor i = 1..N:\n  if C[i] == color and (best is none or R[i] > R[best]):\n    best = i\nprint(best)',
    ),
    'abc300_b': (
        '縦方向のずらし方は H 通り、横方向は W 通りしかありません。全組合せを試しても H*W 個です。',
        'ずらし量 (s,t) を固定し、全マスで `A[(i+s)%H][(j+t)%W] == B[i][j]` か確認します。',
        '疑似コード:\nread H, W, A, B\nfor s = 0..H-1:\n  for t = 0..W-1:\n    ok = true\n    for i,j:\n      if A[(i+s)%H][(j+t)%W] != B[i][j]: ok = false\n    if ok: print Yes; stop\nprint No',
    ),
    'abc301_b': (
        '隣り合う2数 A_i, A_{i+1} の間だけを考えます。差が1なら追加なし、差が大きければ1ずつ近づく整数を挿入します。',
        '各ペアについて最初の値を出力し、その後 `+1` または `-1` しながら次の値の直前まで出力します。最後に A_N を出します。',
        '疑似コード:\nread N, A\nans = empty\nfor i = 1..N-1:\n  append A[i]\n  step = +1 if A[i] < A[i+1] else -1\n  x = A[i] + step\n  while x != A[i+1]:\n    append x\n    x += step\nappend A[N]\nprint(ans)',
    ),
}
