"""Statement-checked three-stage hints for ABC278–280 B."""
HINTS_V140 = {
    'abc278_b': (
        '時刻は1日で1440通りしかありません。現在時刻から1分ずつ進めながら、表示の右上と左下を入れ替えた後も24時間制として有効かを確認できます。',
        '時刻h:mをA B : C Dと見たとき、入れ替え後はAC時BD分です。つまり 10*A+C < 24 かつ 10*B+D < 60 なら見間違えやすい時刻です。',
        '疑似コード:\nrepeat at most 1440 times:\n  split h,m into digits A,B,C,D\n  if 10*A+C < 24 and 10*B+D < 60:\n    print(h,m); stop\n  m += 1\n  if m == 60: m=0; h=(h+1)%24',
    ),
    'abc279_b': (
        '必要なのは部分列ではなく連続部分文字列です。Tの長さ分だけ連続してSと一致する開始位置があるかを調べます。',
        'Pythonなら `T in S` で判定できます。自力で行うなら、Sの各開始位置iについて `S[i:i+len(T)] == T` を調べれば十分です。',
        '疑似コード:\nfor i = 0 .. len(S)-len(T):\n  if S[i:i+len(T)] == T:\n    print("Yes"); stop\nprint("No")',
    ),
    'abc280_b': (
        'S_kはAの先頭からk個までの累積和です。隣り合う累積和を引くと、その位置のAだけが残ります。',
        'A_1=S_1です。2番目以降は `A_i = S_i - S_{i-1}` となるので、左から差分を取れば一意に復元できます。',
        '疑似コード:\nA[1] = S[1]\nfor i = 2 .. N:\n  A[i] = S[i] - S[i-1]\nprint A[1..N]',
    ),
}
