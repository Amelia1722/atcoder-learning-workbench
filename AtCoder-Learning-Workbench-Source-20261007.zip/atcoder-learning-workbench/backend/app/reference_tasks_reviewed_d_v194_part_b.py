"""Private ABC283..288 D: strict inputs and independent exact oracles."""
from __future__ import annotations
from collections import deque
from functools import lru_cache
from math import gcd,isqrt
from typing import cast
import random,re
TASKS=tuple(f'abc{i}_d' for i in range(283,289))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def prime(n:int)->bool:
 if n<2:return False
 for p in (2,3,5,7,11,13,17,19,23,29,31,37):
  if n%p==0:return n==p
 d=n-1;s=0
 while d%2==0:d//=2;s+=1
 for a in (2,325,9375,28178,450775,9780504,1795265022):
  if a%n==0:continue
  x=pow(a,d,n)
  if x in (1,n-1):continue
  for _ in range(s-1):
   x=x*x%n
   if x==n-1:break
  else:return False
 return True
def brent_factor(n:int)->int:
 for p in (2,3,5,7,11,13):
  if n%p==0:return p
 for constant in range(1,100):
  y=2;r=1;g=1;x=ys=0
  while g==1:
   x=y
   for _ in range(r):y=(y*y+constant)%n
   k=0
   while k<r and g==1:
    ys=y;product=1
    for _ in range(min(128,r-k)):y=(y*y+constant)%n;product=product*abs(x-y)%n
    g=gcd(product,n);k+=128
   r*=2
  if g==n:
   g=1
   while g==1:ys=(ys*ys+constant)%n;g=gcd(abs(x-ys),n)
  if g!=n:return g
 raise ValueError('factorization failed')
@lru_cache(maxsize=None)
def prime_square_pair(n:int)->tuple[int,int]:
 factors:list[int]=[];pending=[n]
 while pending:
  v=pending.pop()
  if prime(v):factors.append(v)
  elif v>1:d=brent_factor(v);pending.extend((d,v//d))
 require(len(factors)==3 and len(set(factors))==2,'p2q domain');p=next(p for p in factors if factors.count(p)==2);q=next(q for q in factors if q!=p);return p,q
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc283_d':
  require(len(rows)==1 and re.fullmatch(r'[a-z()]{1,300000}',rows[0]) is not None,'S');depth=0
  for c in rows[0]:
   depth+=(c=='(')-(c==')');require(depth>=0,'good string')
  require(depth==0,'good string');return (rows[0],)
 if pid=='abc284_d':
  t=ints(rows[0],1)[0];require(1<=t<=10 and len(rows)==t+1,'shape');a=tuple(ints(r,1)[0] for r in rows[1:]);require(all(1<=v<=9*10**18 for v in a),'N')
  for v in a:prime_square_pair(v)
  return (a,)
 if pid=='abc285_d':
  n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==n+1,'shape');pairs=[]
  for row in rows[1:]:require(re.fullmatch(r'[a-z]{1,8} [a-z]{1,8}',row) is not None,'names');s,t=row.split();require(s!=t,'distinct pair');pairs.append((s,t))
  require(len({s for s,t in pairs})==n and len({t for s,t in pairs})==n,'unique names');return (tuple(pairs),)
 if pid=='abc286_d':
  n,x=ints(rows[0],2);require(1<=n<=50 and 1<=x<=10000 and len(rows)==n+1,'shape');coins=tuple(ints(r,2) for r in rows[1:]);require(all(1<=a<=100 and 1<=b<=50 for a,b in coins) and len({a for a,b in coins})==n,'coins');return x,coins
 if pid=='abc287_d':require(len(rows)==2 and all(re.fullmatch(r'[a-z?]+',s) is not None for s in rows) and 1<=len(rows[1])<len(rows[0])<=300000,'strings');return rows[0],rows[1]
 n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=min(10,n) and len(rows)>=4,'shape');a=ints(rows[1],n);require(all(abs(v)<=10**9 for v in a),'Ai');q=ints(rows[2],1)[0];require(1<=q<=200000 and len(rows)==q+3,'Q');queries=tuple(ints(r,2) for r in rows[3:]);require(all(1<=l<=r<=n and r-l+1>=k for l,r in queries),'queries');return k,a,queries
def scope_intervals(s:str)->bool:
 stack:list[int]=[];ends=[len(s)]*len(s)
 for i,c in enumerate(s):
  if c=='(':stack.append(i)
  elif c==')':ends[stack.pop()]=i
 stack=[];last_end=[-1]*26
 for i,c in enumerate(s):
  if c=='(':stack.append(ends[i])
  elif c==')':stack.pop()
  else:
   j=ord(c)-97
   if last_end[j]>i:return False
   last_end[j]=stack[-1] if stack else len(s)
 return True
def rename_terminal_pruning(pairs:tuple[tuple[str,str],...])->bool:
 owner={s:i for i,(s,t) in enumerate(pairs)};predecessor:dict[int,int]={};queue=deque();remaining=len(pairs)
 for i,(s,t) in enumerate(pairs):
  if t not in owner:queue.append(i)
  else:predecessor[owner[t]]=i
 while queue:
  i=queue.popleft();remaining-=1
  if i in predecessor:queue.append(predecessor[i])
 return remaining==0
def bounded_coins_residue(x:int,coins:tuple[tuple[int,...],...])->bool:
 reachable=bytearray(x+1);reachable[0]=1
 for value,count in coins:
  updated=bytearray(x+1)
  for residue in range(min(value,x+1)):
   window=0
   for total in range(residue,x+1,value):
    window+=reachable[total]
    old=total-(count+1)*value
    if old>=0:window-=reachable[old]
    updated[total]=int(window>0)
  reachable=updated
 return bool(reachable[x])
def wildcard_intervals(s:str,t:str)->list[bool]:
 n=len(t);lowest=0;highest=n
 for i,c in enumerate(t):
  if c!='?' and s[i]!='?' and c!=s[i]:highest=min(highest,i)
  tail=s[len(s)-n+i]
  if c!='?' and tail!='?' and c!=tail:lowest=max(lowest,i+1)
 return [lowest<=split<=highest for split in range(n+1)]
def polynomial_shift(v:tuple[int,...])->tuple[int,...]:
 if not v:return ()
 last=v[-1];return (-last,)+tuple(x-last for x in v[:-1])
def zeroable_polynomial(k:int,a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[bool]:
 if k==1:return [True]*len(queries)
 prefix=[(0,)*(k-1)]
 for value in a:
  v=list(polynomial_shift(prefix[-1]));v[0]+=value;prefix.append(tuple(v))
 result=[]
 for l,r in queries:
  earlier=prefix[l-1]
  for _ in range((r-l+1)%k):earlier=polynomial_shift(earlier)
  result.append(prefix[r]==earlier)
 return result
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc283_d':return ('Yes' if scope_intervals(cast(str,d[0])) else 'No')+'\n'
 if pid=='abc284_d':return ''.join(f'{p} {q}\n' for p,q in map(prime_square_pair,cast(tuple[int,...],d[0])))
 if pid=='abc285_d':return ('Yes' if rename_terminal_pruning(cast(tuple[tuple[str,str],...],d[0])) else 'No')+'\n'
 if pid=='abc286_d':return ('Yes' if bounded_coins_residue(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])) else 'No')+'\n'
 if pid=='abc287_d':return ''.join(('Yes' if v else 'No')+'\n' for v in wildcard_intervals(cast(str,d[0]),cast(str,d[1])))
 return ''.join(('Yes' if v else 'No')+'\n' for v in zeroable_polynomial(cast(int,d[0]),cast(tuple[int,...],d[1]),cast(tuple[tuple[int,...],...],d[2])))
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc283_d':'''s=input();scopes=[set()];active=set();ok=True
for c in s:
 if c=='(':scopes.append(set())
 elif c==')':active.difference_update(scopes.pop())
 else:
  if c in active:ok=False;break
  active.add(c);scopes[-1].add(c)
print('Yes' if ok else 'No')
''',
'abc284_d':'''from math import isqrt
import sys
data=iter(map(int,sys.stdin.buffer.read().split()));t=next(data)
for _ in range(t):
 n=next(data);d=2
 while n%d:d+=1
 if n%(d*d)==0:p=d;q=n//(d*d)
 else:q=d;p=isqrt(n//d)
 print(p,q)
''',
'abc285_d':'''from collections import deque
n=int(input());edges={};degree={}
for _ in range(n):
 s,t=input().split();edges.setdefault(s,[]).append(t);degree.setdefault(s,0);degree[t]=degree.get(t,0)+1
queue=deque(v for v,d in degree.items() if d==0);count=0
while queue:
 v=queue.popleft();count+=1
 for u in edges.get(v,[]):
  degree[u]-=1
  if degree[u]==0:queue.append(u)
print('Yes' if count==len(degree) else 'No')
''',
'abc286_d':'''n,x=map(int,input().split());bits=1;mask=(1<<(x+1))-1
for _ in range(n):
 a,b=map(int,input().split());chunk=1
 while b:
  take=min(chunk,b);bits=(bits|(bits<<(take*a)))&mask;b-=take;chunk*=2
print('Yes' if bits>>x&1 else 'No')
''',
'abc287_d':'''s=input();t=input();n=len(t)
def match(a,b):return a==b or a=='?' or b=='?'
left=[True]*(n+1);right=[True]*(n+1)
for i in range(n):left[i+1]=left[i] and match(s[i],t[i])
for i in range(n-1,-1,-1):right[i]=right[i+1] and match(s[len(s)-n+i],t[i])
print('\\n'.join('Yes' if left[i] and right[i] else 'No' for i in range(n+1)))
''',
'abc288_d':'''import sys
read=sys.stdin.buffer.readline;n,k=map(int,read().split());a=list(map(int,read().split()));prefix=[[0] for _ in range(k)]
for i,value in enumerate(a):prefix[i%k].append(prefix[i%k][-1]+value)
out=[]
for _ in range(int(read())):
 l,r=map(int,read().split());l-=1;values=[prefix[j][(r+k-1-j)//k]-prefix[j][(l+k-1-j)//k] for j in range(k)]
 out.append('Yes' if len(set(values))==1 else 'No')
print('\\n'.join(out))
'''}
def previous_prime(n:int)->int:
 if n%2==0:n-=1
 while not prime(n):n-=2
 return n
def username(i:int)->str:
 letters=[]
 while True:
  letters.append(chr(97+i%26));i//=26
  if not i:break
 return ''.join(letters)
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'pid');rng=random.Random(194000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc283_d':
  raws=[s+'\n' for s in ['a','aa','()','(a)a','a(a)','((a)ba)','(a(ba))','(((())))','abca','(ab)(ab)','a(b)c(a)','(a(b)c)a','(a)(a)(a)','a()b()a','(abcdefghijklmnopqrstuvwxyz)','a(b(c(d)))a','('*149999+'ab'+')'*149999,'('*150000+')'*150000]]
 elif pid=='abc284_d':
  def factor(a:list[int])->str:return str(len(a))+'\n'+''.join(str(v)+'\n' for v in a)
  primes=[2,3,5,7,11,17,101,997,10007,104149,2000003,2000029];raws=[factor([12]),factor([18]),factor([2023]),factor([1059872604593911])]
  for i in range(12):p=primes[i];q=primes[(i+1)%len(primes)];raws.append(factor([p*p*q]*(2+i%9)))
  p=previous_prime(isqrt(9*10**18//2));q=previous_prime(9*10**18//4)
  raws+=[factor([2000003**2*2000029,2000029**2*2000003]*5),factor([2*p*p,4*q]*5)]
 elif pid=='abc285_d':
  def names(pairs:list[tuple[str,str]])->str:return str(len(pairs))+'\n'+''.join(s+' '+t+'\n' for s,t in pairs)
  raws=[names([('a','b')]),names([('a','b'),('b','a')]),names([('a','b'),('b','c')]),names([('a','b'),('b','c'),('c','a')])]
  for n in range(3,15):order=list(range(n));rng.shuffle(order);pairs=[(username(i),username(i+1)) for i in range(n)];pairs=[pairs[i] for i in order];raws.append(names(pairs))
  raws+=[names([(username(i),username(i+1)) for i in range(100000)]),names([(username(i).ljust(8,'a'),username((i+1)%100000).ljust(8,'a')) for i in range(100000)])]
 elif pid=='abc286_d':
  def coins(x:int,pairs:list[tuple[int,int]])->str:return f'{len(pairs)} {x}\n'+''.join(line(p) for p in pairs)
  raws=[coins(1,[(1,1)]),coins(2,[(1,1)]),coins(10000,[(100,50)]),coins(19,[(2,3),(5,6)])]
  for n in range(2,14):values=rng.sample(range(1,101),n);pairs=[(v,rng.randint(1,50)) for v in values];x=sum(v*rng.randint(0,b) for v,b in pairs);raws.append(coins(max(1,min(10000,x)),pairs))
  raws+=[coins(9999,[(2*i,50) for i in range(1,51)]),coins(10000,[(i,50) for i in range(51,101)])]
 elif pid=='abc287_d':
  raws=['aa\na\n','ab\na\n','??\na\n','a?c\nb?\n']
  for n in range(2,14):t=''.join(rng.choice('ab?') for _ in range(n));s=''.join(rng.choice('ab?') for _ in range(n+rng.randint(1,10)));raws.append(s+'\n'+t+'\n')
  raws+=['?'*300000+'\n'+'a'*299999+'\n','a'*300000+'\n'+'b'*299999+'\n']
 else:
  def array(k:int,a:list[int],queries:list[tuple[int,int]])->str:return f'{len(a)} {k}\n'+line(a)+str(len(queries))+'\n'+''.join(line(q) for q in queries)
  raws=[array(1,[0],[(1,1)]),array(1,[10**9],[(1,1)]),array(2,[1,1],[(1,2)]),array(2,[-1,1],[(1,2)])]
  for n in range(3,15):k=rng.randint(1,min(10,n));a=[rng.randint(-10**9,10**9) for _ in range(n)];queries=[(1,n),(n-k+1,n),(1,k)];raws.append(array(k,a,queries))
  raws+=[array(10,[10**9,-10**9]*100000,[(1,200000),(1,10),(199991,200000)]*66666+[(1,200000),(1,10)]),array(10,[10**9]*200000,[(1,200000),(1,199999)]*100000)]
 require(len(raws)==len(set(raws))==18,'18distinct')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'adversarial_{i:02}'} for i,raw in enumerate(raws)]
HINTS={
'abc283_d':('括弧で囲まれた範囲を抜けると、その範囲で入れたボールが消えます。','現在箱にある文字の集合と、各括弧内で追加した文字の集合をスタックで管理します。','疑似コード: active={},scopes=[{}]; (なら空集合push; )ならpop集合の文字をactiveから削除; 文字がactive内ならNo、それ以外はactiveと最上段へ追加; 最後Yes。'),
'abc284_d':('N=p²qなので、最小の素因数は立方根以下です。','小さい約数dを見つけます。d²で割れるならp=d、そうでなければq=dで残りの整数平方根がpです。','疑似コード: 各Nでd=2からN%d==0まで増加; N%(d*d)==0ならp=d,q=N/(d*d); 他はq=d,p=整数平方根(N/d); p,q出力。'),
'abc285_d':('名前変更の依存関係を有向辺として考えます。','SからTへの有向グラフに閉路があると変更できません。入次数0の頂点から取り除いて判定します。','疑似コード: edges[S]へT追加、indegree[T]++; 入次数0をqueueへ; popし隣のindegree--、0なら追加; 全頂点除去ならYes、残ればNo。'),
'abc286_d':('硬貨の各種類で使える枚数に上限があります。','上限枚数を1,2,4,…と残りに分割すると、各塊を一度だけ使える部分和問題になります。','疑似コード: bits=1; 各(A,B)でchunk=1; take=min(chunk,B)ごとbits|=bits<<(take*A)、Xより上を削除、B-=take、chunk*=2; Xビットが1ならYes。'),
'abc287_d':('先頭から使う部分と、末尾から使う部分を分けます。','先頭からの一致をprefix、末尾からの一致をsuffixへ記録します。?はどちらにあっても一致できます。','疑似コード: prefix[0]=suffix[m]=true; prefix[i+1]=prefix[i]かつmatch(S[i],T[i]); suffix[i]=suffix[i+1]かつmatch(S[|S|-m+i],T[i]); 各xでprefix[x]かつsuffix[x]ならYes。'),
'abc288_d':('連続K要素への加算は、indexをKで割った各余りの総和を同じだけ変えます。','区間内で余り別の総和が全て等しいことが必要十分です。余り別累積和で各クエリをO(K)で判定します。','疑似コード: 各余りjについて対応Aiの累積和作成; query[l,r]で各余りの区間和を累積差で求める; 全て等しければYes、他No。')}

TITLES={'abc283_d': 'Scope', 'abc284_d': 'Happy New Year 2023', 'abc285_d': 'Change Usernames', 'abc286_d': 'Money in Hand', 'abc287_d': 'Match or Not', 'abc288_d': 'Range Add Query'}
PUBLISHED_SAMPLES={'abc283_d': [{'input': '((a)ba)\n', 'expected': 'Yes\n'}, {'input': '(a(ba))\n', 'expected': 'No\n'}, {'input': '(((())))\n', 'expected': 'Yes\n'}, {'input': 'abca\n', 'expected': 'No\n'}], 'abc284_d': [{'input': '3\n2023\n63\n1059872604593911\n', 'expected': '17 7\n3 7\n104149 97711\n'}], 'abc285_d': [{'input': '2\nb m\nm d\n', 'expected': 'Yes\n'}, {'input': '3\na b\nb c\nc a\n', 'expected': 'No\n'}, {'input': '5\naaa bbb\nyyy zzz\nccc ddd\nxxx yyy\nbbb ccc\n', 'expected': 'Yes\n'}], 'abc286_d': [{'input': '2 19\n2 3\n5 6\n', 'expected': 'Yes\n'}, {'input': '2 18\n2 3\n5 6\n', 'expected': 'No\n'}, {'input': '3 1001\n1 1\n2 1\n100 10\n', 'expected': 'Yes\n'}], 'abc287_d': [{'input': 'a?c\nb?\n', 'expected': 'Yes\nNo\nNo\n'}, {'input': 'atcoder\n?????\n', 'expected': 'Yes\nYes\nYes\nYes\nYes\nYes\n'}, {'input': 'beginner\ncontest\n', 'expected': 'No\nNo\nNo\nNo\nNo\nNo\nNo\nNo\n'}], 'abc288_d': [{'input': '7 3\n3 -1 1 -2 2 0 5\n2\n1 6\n2 7\n', 'expected': 'Yes\nNo\n'}, {'input': '20 4\n-19 -66 -99 16 18 33 32 28 26 11 12 0 -16 4 21 21 37 17 55 -19\n5\n13 16\n4 11\n3 12\n13 18\n4 10\n', 'expected': 'No\nYes\nNo\nYes\nNo\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
