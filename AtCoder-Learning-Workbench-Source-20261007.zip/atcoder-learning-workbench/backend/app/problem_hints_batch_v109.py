"""Statement-checked three-stage hints for ABC185–187 B."""
HINTS_V109={
 'abc185_b':(
  'バッテリー残量を時刻ごとに1ずつ追う必要はありません。カフェ間では「経過時間ぶん減る」、カフェ内では「滞在時間ぶん増える」とまとめて更新できます。',
  '現在残量curと直前時刻prevを持ちます。カフェ到着までにcur -= A-prevし、0以下なら即No。滞在後はcur = min(N, cur + B-A)。最後にTまで減らして0より大きければYesです。',
  '疑似コード:\ncur = N\nprev = 0\nfor (A, B) in cafes:\n  cur -= A - prev\n  if cur <= 0: print("No"); 終了\n  cur = min(N, cur + (B - A))\n  prev = B\ncur -= T - prev\nprint("Yes" if cur > 0 else "No")',
 ),
 'abc186_b':(
  '取り除くことしかできないので、最終的に全マスを揃えられる最大の高さは「元の最小値」です。',
  '盤面全体の最小値mを求め、各マスからmを引いた個数を全部足します。追加はできないためmより高い値に揃えることはできません。',
  '疑似コード:\nm = 全A[i][j]の最小値\nans = 0\nfor row in A:\n  for x in row:\n    ans += x - m\nprint(ans)',
 ),
 'abc187_b':(
  '傾きそのものをfloatで計算しなくても判定できます。x座標は必ず異なるので、分母0も起きません。',
  '傾きが-1以上1以下 ⇔ |(y_j-y_i)/(x_j-x_i)| <= 1 ⇔ |y_j-y_i| <= |x_j-x_i| です。全ペアを調べればN<=1000なのでO(N^2)で十分です。',
  '疑似コード:\nans = 0\nfor i = 0..N-1:\n  for j = i+1..N-1:\n    if abs(y[j]-y[i]) <= abs(x[j]-x[i]):\n      ans += 1\nprint(ans)',
 ),
}
