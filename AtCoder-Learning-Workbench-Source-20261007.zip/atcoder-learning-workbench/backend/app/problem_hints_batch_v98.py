"""Statement-checked three-stage hints for ABC152–154 B."""
HINTS_V98 = {
    'abc152_b': (
        '二つの候補を、数値ではなく実際の文字列として作って比較してください。',
        'str(a) を b 回、str(b) を a 回繰り返し、辞書順で小さい方を min で選べます。',
        '''疑似コード:\nx = str(a) * b\ny = str(b) * a\nprint(min(x, y))''',
    ),
    'abc153_b': (
        '各必殺技は高々1回ですが、使わない理由はありません。全て使ったときの総ダメージだけ見れば判定できます。',
        'sum(A) がモンスターの体力 H 以上なら倒せるので Yes、未満なら No です。',
        '''疑似コード:\ntotal = sum(A)\nif total >= H:\n  print("Yes")\nelse:\n  print("No")''',
    ),
    'abc154_b': (
        '元の各文字が何であるかは出力に残りません。必要なのは文字列の長さだけです。',
        'len(S) 個の x を、文字列の繰り返し演算で一度に作れます。',
        '''疑似コード:\nS = input()\nprint("x" * len(S))''',
    ),
}
