"""Statement-checked three-stage hints added while reviewing ABC134–136 B."""
HINTS_V92 = {
    'abc134_b': (
        '監視員1人が連続して何本の木を監視できるかを先に数えてみてください。',
        '木 i に置くと i-D から i+D までなので、最大 2D+1 本を担当できます。端から重ならないように埋めると必要人数を求められます。',
        '疑似コード:\nwidth = 2*D+1\nans = ceil(N/width)\n# 整数なら (N+width-1)//width\nprint(ans)'
    ),
    'abc135_b': (
        '昇順の完成形では、位置 i に値 i が入ります。現在の列と完成形が違う位置だけ数えてみてください。',
        '1回のswapで変えられる位置は2か所です。順列なので、不一致位置が0個なら既に完成、2個ならその2か所を交換して完成できます。',
        "疑似コード:\nbad = count(p[i] != i+1)\nif bad == 0 or bad == 2:\n  print('YES')\nelse:\n  print('NO')"
    ),
    'abc136_b': (
        '1桁、2桁、3桁…のどの範囲を数えるべきか分けて考えてください。',
        'N<=10^5なので1からNまで調べても十分です。各整数を文字列にし、桁数が奇数なら答えを1増やせます。',
        '疑似コード:\nans=0\nfor x=1..N:\n  if len(str(x)) % 2 == 1:\n    ans += 1\nprint(ans)'
    ),
}
