"""ABC047–049 B: task-specific local oracles based on manually viewed public statements.

Official HTML bytes have not been archived or authenticated. Ready means only the
saved generated inputs and transcribed examples were independently crosschecked.
"""
from __future__ import annotations
import random
import re

TASKS = ('abc047_b', 'abc048_b', 'abc049_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
GRID = re.compile(r'[.*]+', re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown problem or noncanonical input')
    lines = raw[:-1].split('\n')
    def numbers(line: str, count: int):
        parts = line.split(' ')
        if len(parts) != count or any(INT.fullmatch(s) is None for s in parts):
            raise ValueError('invalid integer line')
        return tuple(map(int, parts))
    if pid == 'abc047_b':
        w, h, n = numbers(lines[0], 3)
        if not (1 <= w <= 100 and 1 <= h <= 100 and 1 <= n <= 100 and len(lines) == n+1):
            raise ValueError('rectangle or number of operations outside constraints')
        operations=[]
        for line in lines[1:]:
            x,y,a = numbers(line,3)
            if not (0 <= x <= w and 0 <= y <= h and 1 <= a <= 4):
                raise ValueError('invalid paint operation')
            operations.append((x,y,a))
        return w,h,operations
    if pid == 'abc048_b':
        if len(lines) != 1: raise ValueError('one line required')
        a,b,x = numbers(lines[0],3)
        if not (0 <= a <= b <= 10**18 and 1 <= x <= 10**18):
            raise ValueError('interval or divisor outside constraints')
        return a,b,x
    h,w = numbers(lines[0],2)
    if not (1 <= h <= 100 and 1 <= w <= 100 and len(lines) == h+1):
        raise ValueError('grid dimensions or row count outside constraints')
    if any(len(row) != w or GRID.fullmatch(row) is None for row in lines[1:]):
        raise ValueError('grid characters or width invalid')
    return h,w,lines[1:]


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value=validate(pid,raw)
    except (ValueError,TypeError,IndexError):
        return False
    if not isinstance(output,str): return False
    if pid == 'abc047_b':
        w,h,ops=value
        # Pixel-center enumeration: independent of the rectangle clipping reference.
        area=sum(all(not ((kind==1 and col < x) or
                          (kind==2 and col >= x) or
                          (kind==3 and row < y) or
                          (kind==4 and row >= y))
                         for x,y,kind in ops)
                 for row in range(h) for col in range(w))
        return output == str(area)
    if pid == 'abc048_b':
        a,b,x=value
        # First divisible number at/after a, then count the arithmetic progression.
        first=a+(-a)%x
        return output == str(0 if first > b else 1+(b-first)//x)
    h,w,rows=value
    # Index each output row from the corresponding original row; no join duplication.
    expected='\n'.join(rows[r//2] for r in range(2*h))
    return output == expected


def generate(pid: str, seed: int = 63) -> list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unknown problem')
    rng=random.Random(f'abc-v63:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid == 'abc047_b':
        def fmt(w,h,ops):return f'{w} {h} {len(ops)}\n'+''.join(f'{x} {y} {a}\n' for x,y,a in ops)
        fixtures=[(1,1,[(0,0,1)]),(1,1,[(1,1,2)]),(1,1,[(1,1,1)]),
            (5,4,[(2,1,1),(3,3,4)]),(5,4,[(2,1,1),(3,3,4),(1,4,2)]),
            (5,4,[(2,1,1),(2,1,2)]),(5,4,[(2,1,3),(2,1,4)]),
            (10,10,[(0,0,1),(10,10,4)]),(10,10,[(0,0,2)]),
            (10,10,[(10,10,1)]),(7,9,[(3,4,1),(3,4,1)]),
            (7,9,[(3,4,2),(3,4,4)]),(100,1,[(50,0,1)]),
            (1,100,[(0,50,3)])]
        for w,h,ops in fixtures:add('boundary' if w==1 or h==1 else 'normal',fmt(w,h,ops))
        while len(rows)<17:
            w=rng.randint(1,100);h=rng.randint(1,100)
            ops=[(rng.randint(0,w),rng.randint(0,h),rng.randint(1,4)) for _ in range(rng.randint(1,12))]
            add('random',fmt(w,h,ops))
        add('constraint_max',fmt(100,100,[(rng.randint(0,100),rng.randint(0,100),i%4+1) for i in range(100)]))
    elif pid == 'abc048_b':
        fixtures=[(0,0,1),(0,0,10**18),(0,5,1),(1,1,1),(1,1,2),
            (9,9,2),(4,8,2),(1,10**18,3),(0,10**18,1),
            (10**18,10**18,10**18),(10**18-1,10**18,10**18),
            (0,10**18,10**18),(1,10**18,10**18),
            (10**18-10,10**18,7)]
        for a,b,x in fixtures:add('boundary' if a==0 or b==10**18 else 'normal',f'{a} {b} {x}\n')
        while len(rows)<17:
            a=rng.randint(0,10**18);b=rng.randint(a,10**18);x=rng.randint(1,10**18)
            add('random',f'{a} {b} {x}\n')
        add('constraint_max',f'0 {10**18} {10**18-1}\n')
    else:
        def fmt(grid):return f'{len(grid)} {len(grid[0])}\n'+'\n'.join(grid)+'\n'
        fixtures=[['.'],['*'],['*.','.*'],['***.'],['.'*100],['*'*100],
                  ['.','*'],['*','.'],['.*.'*2],['..','..','**'],
                  ['*.'*50],['.*'*50],['.*'*10 for _ in range(10)],
                  ['.'*99+'*']]
        for grid in fixtures:add('boundary' if len(grid)==1 or len(grid[0])==1 else 'normal',fmt(grid))
        while len(rows)<17:
            h=rng.randint(1,30);w=rng.randint(1,100)
            add('random',fmt([''.join(rng.choice('.*') for _ in range(w)) for _ in range(h)]))
        add('constraint_max',fmt([''.join('.*'[(r+c)%2] for c in range(100)) for r in range(100)]))
    if len(rows)!=18 or rows[-1]['category']!='constraint_max' or len(seen)!=18:
        raise ValueError(f'{pid}: expected 18 distinct cases and final maximum, got {len(rows)}')
    return rows
