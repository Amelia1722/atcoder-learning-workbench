"""ABC155–157 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc155_b', 'abc156_b', 'abc157_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc155_b': [
        {'input':'5\n6 7 9 10 31\n','expected':'APPROVED\n'},
        {'input':'3\n28 27 24\n','expected':'DENIED\n'},
    ],
    'abc156_b': [
        {'input':'11 2\n','expected':'4\n'},
        {'input':'1010101 10\n','expected':'7\n'},
        {'input':'314159265 3\n','expected':'18\n'},
    ],
    'abc157_b': [
        {'input':'84 97 66\n79 89 11\n61 59 7\n7\n89\n7\n87\n79\n24\n84\n30\n','expected':'Yes\n'},
        {'input':'41 7 46\n26 89 2\n78 92 8\n5\n6\n45\n16\n57\n17\n','expected':'No\n'},
        {'input':'60 88 34\n92 41 43\n65 73 48\n10\n60\n43\n88\n11\n48\n73\n65\n41\n92\n34\n','expected':'Yes\n'},
    ],
}


def _parts_exact(line: str, count: int) -> list[str]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical positive integer row')
    return parts


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc155_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N row and A row')
        n = int(lines[0])
        if not 1 <= n <= 100:
            raise ValueError('N range')
        parts = lines[1].split(' ')
        if len(parts) != n or any(POS.fullmatch(x) is None for x in parts):
            raise ValueError('A row shape')
        a = list(map(int, parts))
        if any(x > 1000 for x in a):
            raise ValueError('A range')
        return n, a
    if pid == 'abc156_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        n, k = map(int, _parts_exact(lines[0], 2))
        if not (1 <= n <= 10**9 and 2 <= k <= 10):
            raise ValueError('range')
        return n, k
    if len(lines) < 5:
        raise ValueError('too few rows')
    card = []
    for i in range(3):
        row = list(map(int, _parts_exact(lines[i], 3)))
        if any(x > 100 for x in row):
            raise ValueError('card range')
        card.extend(row)
    if len(set(card)) != 9:
        raise ValueError('card values must be distinct')
    if POS.fullmatch(lines[3]) is None:
        raise ValueError('N row')
    n = int(lines[3])
    if not 1 <= n <= 10 or len(lines) != 4 + n:
        raise ValueError('N/row count')
    calls = []
    for line in lines[4:]:
        if POS.fullmatch(line) is None:
            raise ValueError('called number row')
        x = int(line)
        if x > 100:
            raise ValueError('called number range')
        calls.append(x)
    if len(set(calls)) != n:
        raise ValueError('called numbers must be distinct')
    return card, calls


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc155_b':
        _, a = value
        bad = any(x % 2 == 0 and x % 3 != 0 and x % 5 != 0 for x in a)
        return output == ('DENIED' if bad else 'APPROVED')
    if pid == 'abc156_b':
        n, k = value
        digits = 0
        while n:
            digits += 1
            n //= k
        return output == str(digits)
    card, calls = value
    called = set(calls)
    marked = [x in called for x in card]
    lines = ((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    bingo = any(all(marked[i] for i in line) for line in lines)
    return output == ('Yes' if bingo else 'No')


def _155(a: list[int]) -> str:
    return f'{len(a)}\n{" ".join(map(str,a))}\n'


def _156(n: int, k: int) -> str:
    return f'{n} {k}\n'


def _157(card: list[int], calls: list[int]) -> str:
    return (' '.join(map(str, card[:3]))+'\n'+
            ' '.join(map(str, card[3:6]))+'\n'+
            ' '.join(map(str, card[6:]))+'\n'+
            str(len(calls))+'\n'+'\n'.join(map(str,calls))+'\n')


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid == 'abc155_b':
        vals = [
            ('sample1',[6,7,9,10,31]),('sample2',[28,27,24]),('min',[1]),('single_bad',[2]),
            ('single_div3',[6]),('single_div5',[10]),('all_odd',[1,3,5,7,999]),
            ('mixed_good',[15,21,25,30,999]),('mixed_bad',[15,22,25,30]),('max_value_good',[1000]),
            ('near_max_bad',[998]),('near_max_good',[996]),('many_good',[6,10,12,20,30,1000]),
            ('bad_first',[14,6,10]),('bad_last',[6,10,14]),('n100_one_bad',[30]*99+[14]),
            ('n100_all_odd',[999]*100),
        ]
        for cat,a in vals: add(cat,_155(a))
        add('constraint_max',_155([1000]*100))
    elif pid == 'abc156_b':
        vals = [
            ('sample1',11,2),('sample2',1010101,10),('sample3',314159265,3),('min',1,2),
            ('one_base10',1,10),('two_binary',2,2),('below_power2',7,2),('power2',8,2),
            ('below_power10',99,10),('power10',100,10),('below_power3',80,3),('power3',81,3),
            ('nine_digits10',999999999,10),('max_base10',10**9,10),('max_base9',10**9,9),
            ('power3_large',59049,3),('large_base7',999999937,7),
        ]
        for cat,n,k in vals: add(cat,_156(n,k))
        add('constraint_max',_156(10**9,2))
    else:
        base=list(range(1,10))
        high=[92,93,94,95,96,97,98,99,100]
        vals = [
            ('sample1',[84,97,66,79,89,11,61,59,7],[89,7,87,79,24,84,30]),
            ('sample2',[41,7,46,26,89,2,78,92,8],[6,45,16,57,17]),
            ('sample3',[60,88,34,92,41,43,65,73,48],[60,43,88,11,48,73,65,41,92,34]),
            ('row1',base,[1,2,3]),('row2',base,[4,5,6]),('col1',base,[1,4,7]),('col3',base,[3,6,9]),
            ('diag_main',base,[1,5,9]),('diag_anti',base,[3,5,7]),('near_row',base,[1,2]),
            ('scattered_no',base,[1,5,8]),('unrelated',base,[100]),('row_with_extra',base,[1,2,3,10,11]),
            ('n10_bingo',base,[1,2,3,10,11,12,13,14,15,16]),('high_row',high,[92,93,94]),
            ('near_diag',base,[3,5]),('all_card',base,list(range(1,10))),
        ]
        for cat,card,calls in vals: add(cat,_157(card,calls))
        add('constraint_max',_157(high,[1]+high))
    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
