"""Reviewed ABC066--071 D, canonical ARC identifiers and semantic constructions."""
from __future__ import annotations
from collections import Counter,deque
from functools import lru_cache
from itertools import combinations,product
from string import ascii_letters
from typing import cast
import random,re
TASKS=('arc077_b','arc078_b','arc079_b','arc080_b','abc070_d','arc081_b')
CONTESTS={p:f'abc{n:03}' for p,n in zip(TASKS,range(66,72))}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'arc079_b':'semantic','arc080_b':'semantic'}
CHECKER_IDS={p:p for p in OUTPUT_MODES}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]
Edge=tuple[int,int]
WeightedEdge=tuple[int,int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def tree_valid(n:int,edges:tuple[Edge,...])->None:
    require(len(edges)==n-1 and all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges),'tree edges');parent=list(range(n))
    def find(j:int)->int:
        while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
        return j
    for a,b in edges:
        a=find(a-1);b=find(b-1);require(a!=b,'tree cycle');parent[a]=b

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc077_b':
        require(len(rows)==2,'subsequence shape');n=ints(rows[0],1)[0];require(1<=n<=100000,'subsequence size');a=ints(rows[1],n+1);require(set(a)==set(range(1,n+1)),'all labels appear');return (a,)
    if pid=='arc078_b':
        n=ints(rows[0],1)[0];require(2<=n<=100000 and len(rows)==n,'game tree shape');edges=tuple(cast(Edge,ints(row,2)) for row in rows[1:]);tree_valid(n,edges);return n,edges
    if pid=='arc079_b':
        require(len(rows)==1,'topple scalar');k=ints(rows[0],1)[0];require(0<=k<=50*10**16,'topple count');return (k,)
    if pid=='arc080_b':
        require(len(rows)==3,'grid shape');h,w=ints(rows[0],2);n=ints(rows[1],1)[0];require(1<=h<=100 and 1<=w<=100 and 1<=n<=h*w,'grid bounds');a=ints(rows[2],n);require(all(v>=1 for v in a) and sum(a)==h*w,'positive partition');return h,w,a
    if pid=='abc070_d':
        n=ints(rows[0],1)[0];require(3<=n<=100000 and len(rows)>=n+1,'route tree shape');edges=tuple(cast(WeightedEdge,ints(row,3)) for row in rows[1:n]);tree_valid(n,tuple((a,b) for a,b,c in edges));require(all(1<=c<=10**9 for a,b,c in edges),'tree weight');q,k=ints(rows[n],2);require(1<=q<=100000 and 1<=k<=n and len(rows)==n+q+1,'route query shape');queries=tuple(cast(Edge,ints(row,2)) for row in rows[n+1:]);require(all(1<=x<=n and 1<=y<=n and x!=y and x!=k and y!=k for x,y in queries),'route query endpoints');return n,edges,k,queries
    require(len(rows)==3,'domino shape');n=ints(rows[0],1)[0];top,bottom=rows[1:];require(1<=n<=52 and len(top)==len(bottom)==n and re.fullmatch('[a-zA-Z]+',top+bottom) is not None,'domino bounds');positions:dict[str,list[Edge]]={}
    for r,s in enumerate((top,bottom)):
        for c,ch in enumerate(s):positions.setdefault(ch,[]).append((r,c))
    require(len(positions)==n and all(len(a)==2 and abs(a[0][0]-a[1][0])+abs(a[0][1]-a[1][1])==1 for a in positions.values()),'valid labeled domino tiling');return top,bottom

def binomial_row(n:int)->list[int]:
    values=[1]*(n+1);inverse=[0,1]+[0]*max(0,n-1)
    for j in range(2,n+1):inverse[j]=MOD-(MOD//j)*inverse[MOD%j]%MOD
    for j in range(1,n+1):values[j]=values[j-1]*(n-j+1)%MOD*inverse[j]%MOD
    return values

def subsequence_counts(a:tuple[int,...])->list[int]:
    length=len(a)
    if length<=16:
        sets=[set() for _ in range(length+1)]
        for mask in range(1<<length):s=tuple(v for j,v in enumerate(a) if mask>>j&1);sets[len(s)].add(s)
        return [len(sets[k]) for k in range(1,length+1)]
    duplicate=next(v for v,c in Counter(a).items() if c==2);left=a.index(duplicate);right=length-1-a[::-1].index(duplicate);unique=binomial_row(length-2);outside=binomial_row(left+length-1-right)
    def at(values:list[int],j:int)->int:return values[j] if 0<=j<len(values) else 0
    # Classify subsequences by using zero, both, or one duplicate occurrence.
    # Exactly one has two embeddings except when no interior element is used.
    return [(at(unique,k)+at(unique,k-2)+2*at(unique,k-1)-at(outside,k-1))%MOD for k in range(1,length+1)]

def tree_game(n:int,edges:tuple[Edge,...])->str:
    graph:list[list[int]]=[[] for _ in range(n)]
    for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
    parents=[-1]*n;parents[0]=0;stack=[0]
    while stack:
        j=stack.pop()
        for k in graph[j]:
            if parents[k]<0:parents[k]=j;stack.append(k)
    path=[n-1]
    while path[-1]!=0:path.append(parents[path[-1]])
    path.reverse();left,right=path[(len(path)-1)//2:(len(path)-1)//2+2];seen={0};stack=[0]
    while stack:
        j=stack.pop()
        for k in graph[j]:
            if (j,k) in ((left,right),(right,left)) or k in seen:continue
            seen.add(k);stack.append(k)
    return 'Fennec' if len(seen)>n-len(seen) else 'Snuke'

def stabilization_count(a:tuple[int,...])->int:
    n=len(a);candidates=[]
    for residue in range(n+1):
        if any((v+residue)%(n+1)==n for v in a):continue
        quotient=sum((v+residue)//(n+1) for v in a)-residue;steps=(n+1)*quotient+residue
        if steps>=0:candidates.append(steps)
    require(bool(candidates),'stable residue candidate');return min(candidates)

def topple_valid(k:int,actual:str)->bool:
    try:
        rows=actual.removesuffix('\n').split('\n');require(len(rows)==2,'topple output shape');n=ints(rows[0],1)[0];require(2<=n<=50,'topple N');a=ints(rows[1],n);require(all(0<=v<=10**16+1000 for v in a),'topple element bounds');return stabilization_count(a)==k
    except (ValueError,TypeError,IndexError):return False

def grid_valid(h:int,w:int,a:tuple[int,...],actual:str)->bool:
    try:
        rows=actual.removesuffix('\n').split('\n');require(len(rows)==h,'grid output rows');board=tuple(ints(row,w) for row in rows);flat=tuple(v for row in board for v in row);require(all(1<=v<=len(a) for v in flat),'grid colors');require(Counter(flat)==Counter({j:v for j,v in enumerate(a,1)}),'grid color counts');seen:set[Edge]=set();components:set[int]=set()
        for r in range(h):
            for c in range(w):
                if (r,c) in seen:continue
                color=board[r][c];require(color not in components,'grid disconnected color');components.add(color);seen.add((r,c));stack=[(r,c)]
                while stack:
                    y,x=stack.pop()
                    for yy,xx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                        if 0<=yy<h and 0<=xx<w and (yy,xx) not in seen and board[yy][xx]==color:seen.add((yy,xx));stack.append((yy,xx))
        return True
    except (ValueError,TypeError,IndexError):return False

def via_routes(n:int,edges:tuple[WeightedEdge,...],k:int,queries:tuple[Edge,...])->list[int]:
    graph:list[list[tuple[int,int]]]=[[] for _ in range(n)]
    for a,b,c in edges:graph[a-1].append((b-1,c));graph[b-1].append((a-1,c))
    depth=[0]*n;dist=[0]*n;parent=[-1]*n;parent[0]=0;stack=[0]
    while stack:
        j=stack.pop()
        for v,c in graph[j]:
            if parent[v]<0:parent[v]=j;depth[v]=depth[j]+1;dist[v]=dist[j]+c;stack.append(v)
    ancestors=[parent]
    for _ in range(n.bit_length()-1):previous=ancestors[-1];ancestors.append([previous[previous[j]] for j in range(n)])
    def distance(a:int,b:int)->int:
        x,y=a,b
        if depth[x]<depth[y]:x,y=y,x
        delta=depth[x]-depth[y]
        for bit in range(delta.bit_length()):
            if delta>>bit&1:x=ancestors[bit][x]
        if x!=y:
            for level in reversed(ancestors):
                if level[x]!=level[y]:x=level[x];y=level[y]
            x=parent[x]
        return dist[a]+dist[b]-2*dist[x]
    return [distance(x-1,k-1)+distance(k-1,y-1) for x,y in queries]

def domino_colorings(top:str,bottom:str)->int:
    dp:dict[Edge,int]={}
    for j,(a,b) in enumerate(zip(top,bottom)):
        nextdp:dict[Edge,int]={}
        for x,y in product(range(3),repeat=2):
            if (x==y)!=(a==b):continue
            if j==0:nextdp[(x,y)]=1;continue
            total=0
            for (u,v),ways in dp.items():
                if ((u==x)==(top[j-1]==a)) and ((v==y)==(bottom[j-1]==b)):total+=ways
            nextdp[(x,y)]=total%MOD
        dp=nextdp
    return sum(dp.values())%MOD

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc077_b':return '\n'.join(map(str,subsequence_counts(cast(tuple[int,...],data[0]))))
    if pid=='arc078_b':return tree_game(*cast(tuple[int,tuple[Edge,...]],data))
    if pid=='arc079_b':
        k=cast(int,data[0]);q,r=divmod(k,50);return '50\n'+' '.join(str(j+q-r+(51 if j<r else 0)) for j in range(50))
    if pid=='arc080_b':
        h,w,a=cast(tuple[int,int,tuple[int,...]],data);colors=[j for j,count in enumerate(a,1) for _ in range(count)];board=[[0]*w for _ in range(h)]
        for index,color in enumerate(colors):c,offset=divmod(index,h);r=offset if c%2==0 else h-1-offset;board[r][c]=color
        return '\n'.join(' '.join(map(str,row)) for row in board)
    if pid=='abc070_d':return '\n'.join(map(str,via_routes(*cast(tuple[int,tuple[WeightedEdge,...],int,tuple[Edge,...]],data))))
    return str(domino_colorings(*cast(tuple[str,str],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='arc079_b':return topple_valid(cast(int,data[0]),actual)
        if pid=='arc080_b':return grid_valid(*cast(tuple[int,int,tuple[int,...]],data),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid in OUTPUT_MODES:return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'arc077_b':"p=1000000007;n=int(input());a=list(map(int,input().split()));seen={};outside=0\nfor j,v in enumerate(a):\n if v in seen:outside=seen[v]+n-j;break\n seen[v]=j\nf=[1]*(n+2)\nfor j in range(1,n+2):f[j]=f[j-1]*j%p\ninv=[1]*(n+2);inv[-1]=pow(f[-1],p-2,p)\nfor j in range(n+1,0,-1):inv[j-1]=inv[j]*j%p\ndef C(n,k):return f[n]*inv[k]%p*inv[n-k]%p if 0<=k<=n else 0\nprint(*( (C(n+1,k)-C(outside,k-1))%p for k in range(1,n+2)),sep='\\n')\n",
'arc078_b':"from collections import deque\nn=int(input());g=[[] for _ in range(n)]\nfor _ in range(n-1):a,b=map(int,input().split());g[a-1].append(b-1);g[b-1].append(a-1)\ndef bfs(s):\n d=[-1]*n;d[s]=0;q=deque([s])\n while q:\n  j=q.popleft()\n  for k in g[j]:\n   if d[k]<0:d[k]=d[j]+1;q.append(k)\n return d\nx=bfs(0);y=bfs(n-1);black=sum(a<=b for a,b in zip(x,y));print('Fennec' if black>n-black else 'Snuke')\n",
'arc079_b':"k=int(input());q,r=divmod(k,50);print(50);print(*(49+q-r+(51 if j<r else 0) for j in range(50)))\n",
'arc080_b':"h,w=map(int,input().split());n=int(input());a=list(map(int,input().split()));colors=[j for j,count in enumerate(a,1) for _ in range(count)];board=[]\nfor r in range(h):\n row=colors[r*w:(r+1)*w]\n if r%2:row.reverse()\n board.append(row)\nfor row in board:print(*row)\n",
'abc070_d':"import sys\nit=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);g=[[] for _ in range(n)]\nfor _ in range(n-1):a=next(it)-1;b=next(it)-1;c=next(it);g[a].append((b,c));g[b].append((a,c))\nq=next(it);k=next(it)-1;distance=[-1]*n;distance[k]=0;stack=[k]\nwhile stack:\n j=stack.pop()\n for v,c in g[j]:\n  if distance[v]<0:distance[v]=distance[j]+c;stack.append(v)\nprint(*(distance[next(it)-1]+distance[next(it)-1] for _ in range(q)),sep='\\n')\n",
'arc081_b':"n=int(input());a=input();b=input();j=0;previous=None;answer=1\nwhile j<n:\n current='V' if a[j]==b[j] else 'H'\n if previous is None:factor=3 if current=='V' else 6\n elif previous=='V':factor=2\n elif current=='V':factor=1\n else:factor=3\n answer=answer*factor%1000000007;previous=current;j+=1 if current=='V' else 2\nprint(answer)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def domino_input(pattern:str)->str:
    top=bottom='';index=0
    for orientation in pattern:
        if orientation=='V':top+=ascii_letters[index];bottom+=ascii_letters[index];index+=1
        else:top+=ascii_letters[index]*2;bottom+=ascii_letters[index+1]*2;index+=2
    return f'{len(top)}\n{top}\n{bottom}\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18200+TASKS.index(pid));raws:list[str]=[]
    if pid=='arc077_b':
        def seq(a:list[int])->str:return f'{len(a)-1}\n'+line(a)
        raws=[seq([1,1]),seq([1,1,2]),seq([1,2,1]),seq([2,1,1])]
        for n in range(3,15):a=list(range(1,n+1))+[rng.randint(1,n)];rng.shuffle(a);raws.append(seq(a))
        raws += [seq([1]+list(range(2,100001))+[1]),seq(list(range(1,100001))+[100000])]
    elif pid=='arc078_b':
        def game(n:int,e:list[Edge])->str:return f'{n}\n'+''.join(line(edge) for edge in e)
        raws=[game(2,[(1,2)]),game(3,[(1,2),(2,3)]),game(3,[(1,2),(1,3)]),game(4,[(1,4),(4,2),(2,3)])]
        raws += [game(n,[(rng.randint(1,j-1),j) for j in range(2,n+1)]) for n in range(4,16)]
        raws += [game(100000,[(j,j+1) for j in range(1,100000)]),game(100000,[(1,j) for j in range(2,100001)])]
    elif pid=='arc079_b':raws=[f'{k}\n' for k in (0,1,2,3,4,48,49,50,51,99,100,101,1234567894848,10**16,50*10**16-51,50*10**16-50,50*10**16-1,50*10**16)]
    elif pid=='arc080_b':
        def grid(h:int,w:int,a:list[int])->str:return f'{h} {w}\n{len(a)}\n'+line(a)
        raws=[grid(1,1,[1]),grid(1,2,[1,1]),grid(2,1,[2]),grid(2,2,[2,1,1])]
        for h in range(3,15):w=h+1;cuts=sorted(rng.sample(range(1,h*w),h));bounds=[0,*cuts,h*w];raws.append(grid(h,w,[b-a for a,b in zip(bounds,bounds[1:])]))
        raws += [grid(100,100,[10000]),grid(100,100,[1]*10000)]
    elif pid=='abc070_d':
        def tree(n:int,e:list[WeightedEdge],k:int,q:list[Edge])->str:return f'{n}\n'+''.join(line(edge) for edge in e)+f'{len(q)} {k}\n'+''.join(line(query) for query in q)
        raws=[tree(3,[(1,2,1),(2,3,1)],1,[(2,3)]),tree(3,[(1,2,10**9),(2,3,10**9)],2,[(1,3)]),tree(3,[(1,2,1),(2,3,1)],3,[(1,2)]),tree(4,[(1,2,1),(2,3,2),(2,4,3)],2,[(3,4),(4,3)])]
        for n in range(4,16):e=[(rng.randint(1,j-1),j,rng.randint(1,10**9)) for j in range(2,n+1)];k=rng.randint(1,n);others=[j for j in range(1,n+1) if j!=k];q=[cast(Edge,tuple(rng.sample(others,2))) for _ in range(n)];raws.append(tree(n,e,k,q))
        raws += [tree(100000,[(1,j,10**9) for j in range(2,100001)],1,[(99999,100000)]*100000),tree(100000,[(j,j+1,10**9) for j in range(1,100000)],1,[(99999,100000)]*100000)]
    else:
        patterns=['V','VV','H','VH']
        for n in range(4,16):patterns.append(''.join(rng.choice('VH') for _ in range(n)))
        patterns += ['V'*52,'H'*26];raws=[domino_input(s) for s in patterns]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'arc077_b':('重複する整数は1種類だけで、2回出現します。','全ての位置の選び方から、重複整数を片方だけ選んで同じ数列になる余分な選び方を引きます。','疑似コード: 重複位置l,rを探しoutside=l+(n-r); 各k=1..n+1で C(n+1,k)-C(outside,k-1) をmodで出力。'),
'arc078_b':('始点1とNから各頂点までの距離を比べます。','距離が同じ頂点は先手が取れます。取れる頂点数が多い側が勝ち、同数なら先手が先に動けなくなります。','疑似コード: BFS(1),BFS(N)でd1,dNを求める; black=count(d1<=dN); black>N-blackならFennec、他はSnuke。'),
'arc079_b':('操作を逆向きに行う構成を考えます。','N=50とし、50回の逆操作は各要素を1増やします。残りr回は選択要素を50増やし他を1減らします。','疑似コード: q,r=divmod(K,50); N=50; a[i]=49+q-r+(51 if i<r else 0); Nとaを出力。'),
'arc080_b':('全マスを1本の連続した経路で巡れます。','行ごとに進む向きを反転する蛇行経路を作り、同じ色を指定枚数ずつ続けて塗ります。','疑似コード: colorsを各色iがa[i]回続く列にする; 行rへ次のW要素を配置; 奇数行は反転; 全行を出力。'),
'abc070_d':('Kを経由する距離は、xからKとKからyの距離の和です。','木をKから探索して全頂点のKまでの距離を求めれば、各質問は足し算だけです。','疑似コード: dist[K]=0からDFS; 未訪問隣接vへdist[v]=dist[u]+weight; 各(x,y)でdist[x]+dist[y]を出力。'),
'arc081_b':('ドミノの向きを左から順に読み取ります。','縦なら1列、横なら2列まとめて進みます。直前と現在の向きで新しい塗り方の倍率が決まります。','疑似コード: 初回Vは3,Hは6; V→VとV→Hは2,H→Vは1,H→Hは3を掛けてmod; Vは1列,Hは2列進む。')}

TITLES={'arc077_b': '11', 'arc078_b': 'Fennec VS. Snuke', 'arc079_b': 'Decrease (Contestant ver.)', 'arc080_b': 'Grid Coloring', 'abc070_d': 'Transit Tree Path', 'arc081_b': 'Coloring Dominoes'}
PUBLISHED_SAMPLES={'arc077_b': [{'input': '3\n1 2 1 3\n', 'expected': '3\n5\n4\n1\n'}, {'input': '1\n1 1\n', 'expected': '1\n1\n'}, {'input': '32\n29 19 7 10 26 32 27 4 11 20 2 8 16 23 5 14 6 12 17 22 18 30 28 24 15 1 25 3 13 21 19 31 9\n', 'expected': '32\n525\n5453\n40919\n237336\n1107568\n4272048\n13884156\n38567100\n92561040\n193536720\n354817320\n573166440\n818809200\n37158313\n166803103\n166803103\n37158313\n818809200\n573166440\n354817320\n193536720\n92561040\n38567100\n13884156\n4272048\n1107568\n237336\n40920\n5456\n528\n33\n1\n'}], 'arc078_b': [{'input': '7\n3 6\n1 2\n3 1\n7 4\n5 7\n1 4\n', 'expected': 'Fennec\n'}, {'input': '4\n1 4\n4 2\n2 3\n', 'expected': 'Snuke\n'}], 'arc079_b': [{'input': '0\n', 'expected': '4\n3 3 3 3\n'}, {'input': '1\n', 'expected': '3\n1 0 3\n'}, {'input': '2\n', 'expected': '2\n2 2\n'}, {'input': '3\n', 'expected': '7\n27 0 0 0 0 0 0\n'}, {'input': '1234567894848\n', 'expected': '10\n1000 193 256 777 0 1 1192 1234567891011 48 425\n'}], 'arc080_b': [{'input': '2 2\n3\n2 1 1\n', 'expected': '1 1\n2 3\n'}, {'input': '3 5\n5\n1 2 3 4 5\n', 'expected': '1 4 4 4 3\n2 5 4 5 3\n2 5 5 5 3\n'}, {'input': '1 1\n1\n1\n', 'expected': '1\n'}], 'abc070_d': [{'input': '5\n1 2 1\n1 3 1\n2 4 1\n3 5 1\n3 1\n2 4\n2 3\n4 5\n', 'expected': '3\n2\n4\n'}, {'input': '7\n1 2 1\n1 3 3\n1 4 5\n1 5 7\n1 6 9\n1 7 11\n3 2\n1 3\n4 5\n6 7\n', 'expected': '5\n14\n22\n'}, {'input': '10\n1 2 1000000000\n2 3 1000000000\n3 4 1000000000\n4 5 1000000000\n5 6 1000000000\n6 7 1000000000\n7 8 1000000000\n8 9 1000000000\n9 10 1000000000\n1 1\n9 10\n', 'expected': '17000000000\n'}], 'arc081_b': [{'input': '3\naab\nccb\n', 'expected': '6\n'}, {'input': '1\nZ\nZ\n', 'expected': '3\n'}, {'input': '52\nRvvttdWIyyPPQFFZZssffEEkkaSSDKqcibbeYrhAljCCGGJppHHn\nRLLwwdWIxxNNQUUXXVVMMooBBaggDKqcimmeYrhAljOOTTJuuzzn\n', 'expected': '958681902\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
