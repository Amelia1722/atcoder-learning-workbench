"""Turn 128 reviewed B batch: ABC411 B through ABC428 B."""
from __future__ import annotations

from collections import Counter, deque
import heapq
import math
import re

TASKS = tuple(f"abc{i}_b" for i in range(411, 429))
LANES = {
    "A": TASKS[0:3], "B": TASKS[3:6], "C": TASKS[6:9],
    "D": TASKS[9:12], "E": TASKS[12:15], "F": TASKS[15:18],
}
TITLES = {
    "abc411_b": "Distance Table", "abc412_b": "Precondition", "abc413_b": "cat 2",
    "abc414_b": "String Too Long", "abc415_b": "Pick Two", "abc416_b": "1D Akari",
    "abc417_b": "Search and Delete", "abc418_b": "You're a teapot", "abc419_b": "Get Min",
    "abc420_b": "Most Minority", "abc421_b": "Fibonacci Reversed", "abc422_b": "Looped Rope",
    "abc423_b": "Locked Rooms", "abc424_b": "Perfect", "abc425_b": "Find Permutation 2",
    "abc426_b": "The Odd One Out", "abc427_b": "Sum of Digits Sequence", "abc428_b": "Most Frequent Substrings",
}
PUBLISHED_SAMPLES = {
    "abc411_b": [
        {"input":"5\n5 10 2 3\n","expected":"5 15 17 20\n10 12 15\n2 5\n3\n"},
        {"input":"2\n100\n","expected":"100\n"},
    ],
    "abc412_b": [
        {"input":"AtCoder\nTotal\n","expected":"Yes\n"},
        {"input":"aBCdE\nabcdcba\n","expected":"No\n"},
        {"input":"abcde\nXYZ\n","expected":"Yes\n"},
    ],
    "abc413_b": [
        {"input":"4\nat\natco\ncoder\nder\n","expected":"11\n"},
        {"input":"5\na\naa\naaa\naaaa\naaaaa\n","expected":"7\n"},
    ],
    "abc414_b": [
        {"input":"8\nm 1\ni 1\ns 2\ni 1\ns 2\ni 1\np 2\ni 1\n","expected":"mississippi\n"},
        {"input":"7\na 1000000000000000000\nt 1000000000000000000\nc 1000000000000000000\no 1000000000000000000\nd 1000000000000000000\ne 1000000000000000000\nr 1000000000000000000\n","expected":"Too Long\n"},
        {"input":"1\na 100\n","expected":"" + "a"*100 + "\n"},
        {"input":"6\ng 4\nj 1\nm 4\ne 4\nd 3\ni 4\n","expected":"ggggjmmmmeeeedddiiii\n"},
    ],
    "abc415_b": [
        {"input":".#.##..##.#.###....#\n","expected":"2,4\n5,8\n9,11\n13,14\n15,20\n"},
    ],
    "abc416_b": [
        {"input":"#..#.\n","expected":"#o.#o\n"},
        {"input":"#\n","expected":"#\n"},
        {"input":".....\n","expected":"..o..\n"},
        {"input":"...#..#.##.#.\n","expected":"o..#.o#o##o#o\n"},
    ],
    "abc417_b": [
        {"input":"8 5\n1 2 2 3 3 3 5 6\n2 2 7 3 2\n","expected":"1 3 3 5 6\n"},
        {"input":"1 2\n1\n1 1\n","expected":"\n"},
    ],
    "abc418_b": [
        {"input":"attitude\n","expected":"0.50000000000000000\n"},
        {"input":"ottottott\n","expected":"0.66666666666666667\n"},
        {"input":"coffeecup\n","expected":"0.00000000000000000\n"},
    ],
    "abc419_b": [
        {"input":"5\n1 6\n1 7\n2\n1 1\n2\n","expected":"6\n1\n"},
        {"input":"8\n1 5\n1 1\n1 1\n1 9\n2\n2\n1 2\n2\n","expected":"1\n1\n2\n"},
    ],
    "abc420_b": [
        {"input":"3 5\n11100\n10101\n01110\n","expected":"2 3\n"},
        {"input":"5 4\n0000\n0000\n0000\n0000\n0000\n","expected":"1 2 3 4 5\n"},
        {"input":"7 8\n11010011\n01000000\n01111100\n10111000\n10011110\n10100101\n10010110\n","expected":"1 2 3\n"},
    ],
    "abc421_b": [
        {"input":"1 1\n","expected":"415\n"},
        {"input":"3 7\n","expected":"895\n"},
        {"input":"90701 90204\n","expected":"9560800101\n"},
    ],
    "abc422_b": [
        {"input":"8 7\n.######\n##....#\n#.###.#\n#.#.#.#\n#.#.#.#\n#.#####\n#...#..\n#####..\n","expected":"Yes\n"},
        {"input":"1 2\n##\n","expected":"No\n"},
        {"input":"4 3\n...\n...\n...\n...\n","expected":"Yes\n"},
        {"input":"15 18\n##.###..##.##..##.\n##.#.##.##.##.####\n...##.#.......####\n###.###....###.##.\n#.##.......#.#....\n#..#.##.##.#.#....\n#.########.####.##\n#.##.##.#....##.##\n#......##.........\n##.##..#..##..####\n.#.#####..#####..#\n.#..#...##.#.....#\n.#..#.####.#.....#\n.##.#.#.#..##..###\n..###.###...####..\n","expected":"Yes\n"},
    ],
    "abc423_b": [
        {"input":"5\n0 1 0 0 1\n","expected":"3\n"},
        {"input":"3\n1 0 1\n","expected":"2\n"},
        {"input":"8\n0 0 1 1 0 1 0 0\n","expected":"3\n"},
    ],
    "abc424_b": [
        {"input":"3 2 5\n1 1\n3 2\n2 1\n3 1\n1 2\n","expected":"3 1\n"},
        {"input":"2 2 2\n1 1\n2 2\n","expected":"\n"},
    ],
    "abc425_b": [
        {"input":"4\n-1 -1 2 -1\n","expected":"Yes\n3 1 2 4\n"},
        {"input":"5\n-1 -1 1 -1 1\n","expected":"No\n"},
        {"input":"7\n3 -1 4 -1 5 -1 2\n","expected":"Yes\n3 7 4 1 5 6 2\n"},
    ],
    "abc426_b": [
        {"input":"odd\n","expected":"o\n"},
        {"input":"dad\n","expected":"a\n"},
        {"input":"wwwwwwwwwv\n","expected":"v\n"},
    ],
    "abc427_b": [
        {"input":"6\n","expected":"23\n"},
        {"input":"45\n","expected":"427\n"},
    ],
    "abc428_b": [
        {"input":"9 3\novowowovo\n","expected":"2\novo owo\n"},
        {"input":"9 1\novowowovo\n","expected":"5\no\n"},
        {"input":"35 3\nthequickbrownfoxjumpsoverthelazydog\n","expected":"2\nthe\n"},
    ],
}
SAMPLE_COUNTS = {k: len(v) for k, v in PUBLISHED_SAMPLES.items()}

LOWER = re.compile(r"[a-z]+")
LETTERS = re.compile(r"[A-Za-z]+")


def _lines(raw: str) -> list[str]:
    if not raw.endswith("\n") or "\r" in raw:
        raise ValueError("newline")
    return raw[:-1].split("\n")


def _ints(s: str) -> list[int]:
    try:
        return list(map(int, s.split()))
    except Exception as exc:
        raise ValueError("ints") from exc


def validate(pid: str, raw: str):
    if pid not in TASKS:
        raise ValueError("pid")
    l = _lines(raw)
    if pid == "abc411_b":
        if len(l) != 2: raise ValueError("shape")
        n = int(l[0]); d = _ints(l[1])
        if not 2 <= n <= 50 or len(d) != n-1 or any(not 1 <= x <= 100 for x in d): raise ValueError("D")
        return n, tuple(d)
    if pid == "abc412_b":
        if len(l) != 2 or any(LETTERS.fullmatch(x) is None or not 1 <= len(x) <= 100 for x in l): raise ValueError("ST")
        return l[0], l[1]
    if pid == "abc413_b":
        if not l: raise ValueError("shape")
        n = int(l[0]); ss = l[1:]
        if not 2 <= n <= 100 or len(ss) != n or len(set(ss)) != n or any(LOWER.fullmatch(s) is None or not 1 <= len(s) <= 10 for s in ss): raise ValueError("S")
        return n, tuple(ss)
    if pid == "abc414_b":
        if not l: raise ValueError("shape")
        n = int(l[0]); rows = l[1:]
        if not 1 <= n <= 100 or len(rows) != n: raise ValueError("N")
        pairs=[]
        for row in rows:
            a=row.split()
            if len(a)!=2 or len(a[0])!=1 or not('a'<=a[0]<='z'): raise ValueError("pair")
            x=int(a[1])
            if not 1<=x<=10**18: raise ValueError("l")
            pairs.append((a[0],x))
        if any(pairs[i][0]==pairs[i+1][0] for i in range(n-1)): raise ValueError("adjacent")
        return n, tuple(pairs)
    if pid == "abc415_b":
        if len(l)!=1 or not 2<=len(l[0])<=1000 or any(c not in '.#' for c in l[0]): raise ValueError("S")
        c=l[0].count('#')
        if c<2 or c%2: raise ValueError("packages")
        return (l[0],)
    if pid == "abc416_b":
        if len(l)!=1 or not 1<=len(l[0])<=100 or any(c not in '.#' for c in l[0]): raise ValueError("S")
        return (l[0],)
    if pid == "abc417_b":
        if len(l)!=3: raise ValueError("shape")
        h=_ints(l[0]);
        if len(h)!=2: raise ValueError("head")
        n,m=h; a=_ints(l[1]); b=_ints(l[2])
        if not(1<=n<=100 and 1<=m<=100) or len(a)!=n or len(b)!=m or any(not 1<=x<=10**9 for x in a+b) or any(a[i]>a[i+1] for i in range(n-1)): raise ValueError("AB")
        return n,m,tuple(a),tuple(b)
    if pid == "abc418_b":
        if len(l)!=1 or not 1<=len(l[0])<=100 or LOWER.fullmatch(l[0]) is None: raise ValueError("S")
        return (l[0],)
    if pid == "abc419_b":
        if not l: raise ValueError("shape")
        q=int(l[0]); rows=l[1:]
        if not 2<=q<=100 or len(rows)!=q: raise ValueError("Q")
        size=0; twos=0
        for row in rows:
            a=_ints(row)
            if len(a)==2 and a[0]==1 and 1<=a[1]<=100: size+=1
            elif a==[2] and size>0: size-=1; twos+=1
            else: raise ValueError("query")
        if twos==0: raise ValueError("type2")
        return q,tuple(rows)
    if pid == "abc420_b":
        if not l: raise ValueError("shape")
        h=_ints(l[0]);
        if len(h)!=2: raise ValueError("head")
        n,m=h; ss=l[1:]
        if not(1<=n<=99 and n%2==1 and 1<=m<=100) or len(ss)!=n or any(len(s)!=m or any(c not in '01' for c in s) for s in ss): raise ValueError("grid")
        return n,m,tuple(ss)
    if pid == "abc421_b":
        if len(l)!=1: raise ValueError("shape")
        a=_ints(l[0])
        if len(a)!=2 or any(not 1<=x<=10**5 for x in a): raise ValueError("XY")
        return tuple(a)
    if pid == "abc422_b":
        if not l: raise ValueError("shape")
        h=_ints(l[0]);
        if len(h)!=2: raise ValueError("head")
        H,W=h; ss=l[1:]
        if not(1<=H<=20 and 1<=W<=20) or len(ss)!=H or any(len(s)!=W or any(c not in '.#' for c in s) for s in ss): raise ValueError("grid")
        return H,W,tuple(ss)
    if pid == "abc423_b":
        if len(l)!=2: raise ValueError("shape")
        n=int(l[0]); a=_ints(l[1])
        if not 2<=n<=100 or len(a)!=n or any(x not in (0,1) for x in a): raise ValueError("L")
        return n,tuple(a)
    if pid == "abc424_b":
        if not l: raise ValueError("shape")
        h=_ints(l[0]);
        if len(h)!=3: raise ValueError("head")
        n,m,k=h; rows=l[1:]
        if not(1<=n<=10 and 1<=m<=10 and 1<=k<=n*m) or len(rows)!=k: raise ValueError("NMK")
        ev=[]
        for row in rows:
            a=_ints(row)
            if len(a)!=2 or not(1<=a[0]<=n and 1<=a[1]<=m): raise ValueError("event")
            ev.append(tuple(a))
        if len(set(ev))!=k: raise ValueError("duplicate")
        return n,m,k,tuple(ev)
    if pid == "abc425_b":
        if len(l)!=2: raise ValueError("shape")
        n=int(l[0]); a=_ints(l[1])
        if not 1<=n<=10 or len(a)!=n or any(x!=-1 and not 1<=x<=n for x in a): raise ValueError("A")
        return n,tuple(a)
    if pid == "abc426_b":
        if len(l)!=1 or not 3<=len(l[0])<=10 or LOWER.fullmatch(l[0]) is None: raise ValueError("S")
        c=Counter(l[0])
        if len(c)!=2 or sorted(c.values())[0]!=1: raise ValueError("pattern")
        return (l[0],)
    if pid == "abc427_b":
        if len(l)!=1: raise ValueError("shape")
        n=int(l[0])
        if not 1<=n<=100: raise ValueError("N")
        return (n,)
    if pid == "abc428_b":
        if len(l)!=2: raise ValueError("shape")
        h=_ints(l[0]);
        if len(h)!=2: raise ValueError("head")
        n,k=h; s=l[1]
        if not(1<=k<=n<=100) or len(s)!=n or LOWER.fullmatch(s) is None: raise ValueError("NKS")
        return n,k,s
    raise ValueError(pid)


def _semantic_416(raw:str, actual:str)->bool:
    try: s=validate('abc416_b',raw)[0]
    except Exception: return False
    if '\r' in actual: return False
    t=actual.rstrip('\n')
    if len(t)!=len(s) or any(c not in '.#o' for c in t): return False
    if any((s[i]=='#') != (t[i]=='#') for i in range(len(s))): return False
    runs=0; i=0
    while i<len(s):
        if s[i]=='#': i+=1; continue
        runs+=1; j=i
        while j<len(s) and s[j]=='.': j+=1
        if sum(t[k]=='o' for k in range(i,j))!=1: return False
        i=j
    return t.count('o')==runs


def _semantic_425(raw:str, actual:str)->bool:
    try: n,a=validate('abc425_b',raw)
    except Exception: return False
    if '\r' in actual or not actual.endswith('\n'): return False
    dup = len([x for x in a if x!=-1]) != len(set(x for x in a if x!=-1))
    rows=actual[:-1].split('\n')
    if rows==['No']:
        return dup
    if dup or len(rows)!=2 or rows[0]!='Yes': return False
    try: p=list(map(int,rows[1].split()))
    except Exception: return False
    if len(p)!=n or sorted(p)!=list(range(1,n+1)): return False
    return all(x==-1 or p[i]==x for i,x in enumerate(a))


def _oracle(pid:str, raw:str)->str:
    v=validate(pid,raw)
    if pid=='abc411_b':
        n,d=v; return '\n'.join(' '.join(str(sum(d[i:j])) for j in range(i+1,n)) for i in range(n-1))
    if pid=='abc412_b':
        s,t=v; return 'Yes' if all(not s[i].isupper() or s[i-1] in t for i in range(1,len(s))) else 'No'
    if pid=='abc413_b':
        _,ss=v; return str(len({ss[i]+ss[j] for i in range(len(ss)) for j in range(len(ss)) if i!=j}))
    if pid=='abc414_b':
        _,pairs=v; total=sum(x for _,x in pairs)
        return 'Too Long' if total>100 else ''.join(c*x for c,x in pairs)
    if pid=='abc415_b':
        pos=[i+1 for i,c in enumerate(v[0]) if c=='#']; return '\n'.join(f'{pos[i]},{pos[i+1]}' for i in range(0,len(pos),2))
    if pid=='abc416_b':
        s=v[0]; out=list(s); i=0
        while i<len(s):
            if s[i]=='#': i+=1; continue
            out[i]='o'; i+=1
            while i<len(s) and s[i]=='.': out[i]='.'; i+=1
        return ''.join(out)
    if pid=='abc417_b':
        _,_,a,b=v; c=Counter(a)
        for x in b:
            if c[x]: c[x]-=1
        out=[]
        for x in sorted(c): out += [x]*c[x]
        return ' '.join(map(str,out))
    if pid=='abc418_b':
        s=v[0]; best=0.0
        for i in range(len(s)):
            if s[i]!='t': continue
            for j in range(i+2,len(s)):
                if s[j]=='t': best=max(best,(s[i:j+1].count('t')-2)/(j-i-1))
        return repr(best)
    if pid=='abc419_b':
        _,qs=v; arr=[]; out=[]
        for row in qs:
            a=_ints(row)
            if a[0]==1: arr.append(a[1]); arr.sort()
            else: out.append(str(arr.pop(0)))
        return '\n'.join(out)
    if pid=='abc420_b':
        n,m,ss=v; score=[0]*n
        for j in range(m):
            z=sum(s[j]=='0' for s in ss); o=n-z
            if z==0 or o==0: winners='01'
            elif z<o: winners='0'
            else: winners='1'
            for i,s in enumerate(ss): score[i]+=s[j] in winners
        mx=max(score); return ' '.join(str(i+1) for i,x in enumerate(score) if x==mx)
    if pid=='abc421_b':
        x,y=v
        for _ in range(8): x,y=y,int(str(x+y)[::-1])
        return str(y)
    if pid=='abc422_b':
        H,W,ss=v
        for i in range(H):
            for j in range(W):
                if ss[i][j]=='#':
                    c=sum(0<=ni<H and 0<=nj<W and ss[ni][nj]=='#' for ni,nj in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)))
                    if c not in (2,4): return 'No'
        return 'Yes'
    if pid=='abc423_b':
        n,a=v; locks=[i for i,x in enumerate(a,1) if x]
        return str(0 if not locks else locks[-1]-locks[0])
    if pid=='abc424_b':
        n,m,_,ev=v; cnt=[0]*(n+1); out=[]
        for p,_ in ev:
            cnt[p]+=1
            if cnt[p]==m: out.append(str(p))
        return ' '.join(out)
    if pid=='abc425_b':
        n,a=v; fixed=[x for x in a if x!=-1]
        if len(fixed)!=len(set(fixed)): return 'No'
        missing=iter(x for x in range(1,n+1) if x not in fixed)
        p=[next(missing) if x==-1 else x for x in a]
        return 'Yes\n'+' '.join(map(str,p))
    if pid=='abc426_b':
        c=Counter(v[0]); return min(c,key=c.get)
    if pid=='abc427_b':
        n=v[0]; A=[1]
        for i in range(1,n+1): A.append(sum(sum(map(int,str(x))) for x in A[:i]))
        return str(A[n])
    if pid=='abc428_b':
        n,k,s=v; c=Counter(s[i:i+k] for i in range(n-k+1)); mx=max(c.values()); vals=sorted(x for x,vv in c.items() if vv==mx)
        return str(mx)+'\n'+' '.join(vals)
    raise ValueError(pid)


def _float_ok(actual:str, expected:str, eps=1e-9)->bool:
    try: a=float(actual.strip()); b=float(expected.strip())
    except Exception: return False
    return math.isfinite(a) and math.isfinite(b) and (abs(a-b)<=eps or abs(a-b)<=eps*abs(b))


def independent_check(pid:str, raw:str, actual:str)->bool:
    try:
        if pid=='abc416_b': return _semantic_416(raw, actual if actual.endswith('\n') else actual+'\n')
        if pid=='abc425_b': return _semantic_425(raw, actual if actual.endswith('\n') else actual+'\n')
        exp=_oracle(pid,raw)
    except Exception:
        return False
    if pid=='abc418_b': return _float_ok(actual,exp,1e-9)
    return actual.rstrip('\n')==exp.rstrip('\n')


def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc416_b': return _semantic_416(raw,expected) and _semantic_416(raw,stdout)
    if pid=='abc425_b': return _semantic_425(raw,expected) and _semantic_425(raw,stdout)
    if pid=='abc418_b': return _float_ok(stdout,expected,1e-9) and independent_check(pid,raw,expected)
    return stdout.rstrip('\n')==expected.rstrip('\n') and independent_check(pid,raw,expected.rstrip('\n'))


def _base26(i:int)->str:
    s=''
    while True:
        s=chr(97+i%26)+s; i//=26
        if not i: return s
        i-=1


def _case(raw:str,idx:int)->dict[str,str]: return {'input':raw,'category':f'task_specific_{idx:02d}'}


def generate(pid:str):
    out=[]
    if pid=='abc411_b':
        for i in range(1,18):
            n=2+i%9; d=[(i*j)%100+1 for j in range(1,n)]; out.append(_case(f"{n}\n"+' '.join(map(str,d))+'\n',i))
        out.append({'input':'50\n'+' '.join(['100']*49)+'\n','category':'constraint_max'})
    elif pid=='abc412_b':
        pairs=[('A','x'),('aB','a'),('aB','x'),('abc','XYZ'),('AB','A'),('zZ','z'),('zZ','Z'),('aBcD','ac'),('aBcD','aBc'),('HELLO','E'),('xYz','x'),('mNOP','mNO'),('aA','a'),('Aa','z'),('abcD','c'),('abcD','d'),('ZabcX','c')]
        out=[_case(f'{s}\n{t}\n',i+1) for i,(s,t) in enumerate(pairs)]
        out.append({'input':'a'*99+'Z\n'+'a'*100+'\n','category':'constraint_max'})
    elif pid=='abc413_b':
        for i in range(1,18):
            n=2+i%8; ss=[_base26(i*10+j) for j in range(n)]; out.append(_case(str(n)+'\n'+'\n'.join(ss)+'\n',i))
        ss=['q'+_base26(i) for i in range(100)]; out.append({'input':'100\n'+'\n'.join(ss)+'\n','category':'constraint_max'})
    elif pid=='abc414_b':
        for i in range(1,18):
            n=1+i%6; rows=[f"{chr(97+j%2)} {1+(i+j)%20}" for j in range(n)]; out.append(_case(str(n)+'\n'+'\n'.join(rows)+'\n',i))
        rows=[f"{'a' if i%2==0 else 'b'} 1000000000000000000" for i in range(100)]; out.append({'input':'100\n'+'\n'.join(rows)+'\n','category':'constraint_max'})
    elif pid=='abc415_b':
        for i in range(1,18):
            n=4+i; p=2+2*(i%max(1,n//2-1)); p=min(p,n if n%2==0 else n-1); p=max(2,p); s=['.']*n
            for j in range(p): s[(j*3+i)%n]='#'
            # collisions may reduce; fill from left until even p positions
            cur=[j for j,c in enumerate(s) if c=='#']
            target=min(n if n%2==0 else n-1,max(2,2*(len(cur)//2)))
            if len(cur)<target:
                for j in range(n):
                    if s[j]=='.': s[j]='#'; cur.append(j)
                    if len(cur)==target: break
            if len(cur)%2: s[cur[-1]]='.'
            out.append(_case(''.join(s)+'\n',i))
        out.append({'input':'#'*1000+'\n','category':'constraint_max'})
    elif pid=='abc416_b':
        vals=['.','#','..','.#.','#..#','.....','##..##','..#..','.#.#.','...##...','####','.#...#.','..##..##.','.#....#....','...#..#.##.#.','.#.#.#.#.#.','..........#']
        out=[_case(s+'\n',i+1) for i,s in enumerate(vals)]
        out.append({'input':('.'*49+'#')*2+'\n','category':'constraint_max'})
    elif pid=='abc417_b':
        for i in range(1,18):
            n=1+i%8; m=1+(i*2)%8; a=sorted((j*j+i)%20+1 for j in range(n)); b=[(j*3+i)%20+1 for j in range(m)]; out.append(_case(f'{n} {m}\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n',i))
        out.append({'input':'100 100\n'+' '.join(map(str,range(1,101)))+'\n'+' '.join(map(str,range(1,101)))+'\n','category':'constraint_max'})
    elif pid=='abc418_b':
        vals=['a','t','tt','tat','ttt','attitude','ottottott','coffeecup','txt','tatt','attta','ttaat','t'*20,'abcde','txyzt','ttttaaaaat','atbtctdt','t'*50+'a'*49+'t']
        out=[_case(s+'\n',i+1) for i,s in enumerate(vals[:17])]
        out.append({'input':'t'*100+'\n','category':'constraint_max'})
    elif pid=='abc419_b':
        for i in range(1,18):
            qs=[]; size=0
            for j in range(2+i%7):
                if j%3==2 and size: qs.append('2'); size-=1
                else: qs.append(f'1 {(i*7+j)%100+1}'); size+=1
            if not any(x=='2' for x in qs): qs.append('2')
            out.append(_case(str(len(qs))+'\n'+'\n'.join(qs)+'\n',i))
        qs=[f'1 {100-i%100}' for i in range(50)]+['2']*50
        out.append({'input':'100\n'+'\n'.join(qs)+'\n','category':'constraint_max'})
    elif pid=='abc420_b':
        for i in range(1,18):
            n=1+2*(i%5); m=1+i%8; ss=[''.join(str((r*3+c+i)%2) for c in range(m)) for r in range(n)]; out.append(_case(f'{n} {m}\n'+'\n'.join(ss)+'\n',i))
        ss=[''.join(str((r+c)%2) for c in range(100)) for r in range(99)]; out.append({'input':'99 100\n'+'\n'.join(ss)+'\n','category':'constraint_max'})
    elif pid=='abc421_b':
        vals=[(1,1),(3,7),(10,20),(100,200),(999,1),(1,999),(123,456),(1000,1000),(9999,1),(1,9999),(54321,12345),(100000,1),(1,100000),(99999,99999),(90701,90204),(31415,92653),(50000,50001)]
        out=[_case(f'{x} {y}\n',i+1) for i,(x,y) in enumerate(vals)]
        out.append({'input':'100000 100000\n','category':'constraint_max'})
    elif pid=='abc422_b':
        grids=[['.'],['#'],['##'],['.#.'],['###'],['.#.','###','.#.'],['##','##'],['#.#','.#.','#.#'],['...','...'],['.#','##'],['####','####'],['#..#','....','#..#'],['###','###','###'],['.#.','.##','.#.'],['....#','...##','..###'],['#.#.#','.#.#.'],['#####','#...#','#...#','#...#','#####']]
        for i,g in enumerate(grids,1): out.append(_case(f'{len(g)} {len(g[0])}\n'+'\n'.join(g)+'\n',i))
        g=['#'*20 for _ in range(20)]; out.append({'input':'20 20\n'+'\n'.join(g)+'\n','category':'constraint_max'})
    elif pid=='abc423_b':
        vals=[[0,0],[1,0],[0,1],[1,1],[0,1,0],[1,0,1],[0,0,1,0],[1,0,0,1],[0,1,1,0,1],[0]*6,[1]*6,[0,0,1,1,0,1,0,0],[1,0,0,0,0,1],[0,1,0,1,0,1,0],[1,0,1,0,1,0,1],[0]*8+[1],[1]+[0]*8]
        out=[_case(str(len(a))+'\n'+' '.join(map(str,a))+'\n',i+1) for i,a in enumerate(vals)]
        a=[0]*20+[1]+[0]*58+[1]+[0]*20; out.append({'input':'100\n'+' '.join(map(str,a))+'\n','category':'constraint_max'})
    elif pid=='abc424_b':
        pairs=[(p,q) for p in range(1,11) for q in range(1,11)]
        for i in range(1,18):
            ev=pairs[:i]; out.append(_case(f'10 10 {i}\n'+'\n'.join(f'{a} {b}' for a,b in ev)+'\n',i))
        out.append({'input':'10 10 100\n'+'\n'.join(f'{a} {b}' for a,b in pairs)+'\n','category':'constraint_max'})
    elif pid=='abc425_b':
        vals=[[-1], [1], [-1,-1], [1,1], [2,-1], [-1,2], [-1,-1,-1], [1,-1,3], [1,-1,1], [3,-1,1], [-1,2,-1,4], [4,3,2,1], [-1,-1,2,-1], [-1,-1,1,-1,1], [3,-1,4,-1,5,-1,2], [-1,2,3,4,5], [5,-1,-1,2,-1]]
        out=[_case(str(len(a))+'\n'+' '.join(map(str,a))+'\n',i+1) for i,a in enumerate(vals)]
        out.append({'input':'10\n-1 -1 -1 -1 -1 -1 -1 -1 -1 -1\n','category':'constraint_max'})
    elif pid=='abc426_b':
        vals=['aab','aba','baa','xxxy','yxxx','zzzza','azzzz','pppppq','qppppp','aaaaaaaab','baaaaaaaa','cccccccccd','dccccccccc','mmmmn','nmmmm','kkkkkkkl','lkkkkkkk']
        out=[_case(s+'\n',i+1) for i,s in enumerate(vals)]
        out.append({'input':'aaaaaaaaab\n','category':'constraint_max'})
    elif pid=='abc427_b':
        out=[_case(f'{i}\n',i) for i in range(1,18)]
        out.append({'input':'100\n','category':'constraint_max'})
    elif pid=='abc428_b':
        vals=[(1,1,'a'),(2,1,'aa'),(2,2,'ab'),(3,1,'aba'),(3,2,'aaa'),(4,2,'abab'),(5,3,'abcab'),(6,2,'aaaaaa'),(7,3,'abababa'),(8,4,'abcdabcd'),(9,1,'ovowowovo'),(9,3,'ovowowovo'),(10,5,'abcdeabcde'),(12,3,'abcabcabcabc'),(15,4,'aaaabaaaabaaaab'),(20,2,'abcdefghijklmnopqrst'),(30,3,'abcabcabcabcabcabcabcabcabcabc')]
        out=[_case(f'{n} {k}\n{s}\n',i+1) for i,(n,k,s) in enumerate(vals)]
        s='a'*50+'b'*50; out.append({'input':'100 50\n'+s+'\n','category':'constraint_max'})
    else: raise ValueError(pid)
    if len(out)!=18 or len({x['input'] for x in out})!=18 or out[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: generated case construction failed ({len(out)}, {len({x["input"] for x in out})})')
    for row in out: validate(pid,row['input'])
    return out


REFERENCE_CODE = {
"abc411_b": "N=int(input());D=list(map(int,input().split()))\nP=[0]\nfor x in D:P.append(P[-1]+x)\nfor i in range(N-1):print(*[P[j]-P[i] for j in range(i+1,N)])\n",
"abc412_b": "S=input().strip();T=set(input().strip());print('Yes' if all(i==0 or (not c.isupper()) or S[i-1] in T for i,c in enumerate(S)) else 'No')\n",
"abc413_b": "N=int(input());S=[input().strip() for _ in range(N)];print(len({S[i]+S[j] for i in range(N) for j in range(N) if i!=j}))\n",
"abc414_b": "N=int(input());a=[];n=0\nfor _ in range(N):\n c,l=input().split();l=int(l);n+=l;a.append((c,l))\nif n>100:print('Too Long')\nelse:print(''.join(c*l for c,l in a))\n",
"abc415_b": "S=input().strip();p=[i+1 for i,c in enumerate(S) if c=='#']\nfor i in range(0,len(p),2):print(f'{p[i]},{p[i+1]}')\n",
"abc416_b": "S=input().strip();T=list(S);i=0\nwhile i<len(S):\n if S[i]=='#':i+=1;continue\n T[i]='o';i+=1\n while i<len(S) and S[i]=='.':T[i]='.';i+=1\nprint(''.join(T))\n",
"abc417_b": "from collections import Counter\nN,M=map(int,input().split());A=list(map(int,input().split()));B=list(map(int,input().split()));c=Counter(A)\nfor x in B:\n if c[x]:c[x]-=1\nans=[]\nfor x in sorted(c):ans += [x]*c[x]\nprint(*ans)\n",
"abc418_b": "S=input().strip();p=[0]\nfor c in S:p.append(p[-1]+(c=='t'))\nbest=0.0\nfor i in range(len(S)):\n if S[i]!='t':continue\n for j in range(i+2,len(S)):\n  if S[j]=='t':best=max(best,(p[j+1]-p[i]-2)/(j-i-1))\nprint(best)\n",
"abc419_b": "import heapq\nQ=int(input());h=[]\nfor _ in range(Q):\n q=list(map(int,input().split()))\n if q[0]==1:heapq.heappush(h,q[1])\n else:print(heapq.heappop(h))\n",
"abc420_b": "N,M=map(int,input().split());S=[input().strip() for _ in range(N)];sc=[0]*N\nfor j in range(M):\n o=sum(s[j]=='1' for s in S);z=N-o;w='01' if not o or not z else ('1' if o<z else '0')\n for i,s in enumerate(S):sc[i]+=s[j] in w\nm=max(sc);print(*[i+1 for i,x in enumerate(sc) if x==m])\n",
"abc421_b": "X,Y=map(int,input().split())\nfor _ in range(8):X,Y=Y,int(str(X+Y)[::-1])\nprint(Y)\n",
"abc422_b": "H,W=map(int,input().split());S=[input().strip() for _ in range(H)];ok=True\nfor i in range(H):\n for j in range(W):\n  if S[i][j]=='#':\n   c=sum(0<=a<H and 0<=b<W and S[a][b]=='#' for a,b in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)))\n   ok &= c in (2,4)\nprint('Yes' if ok else 'No')\n",
"abc423_b": "N=int(input());L=list(map(int,input().split()));p=[i for i,x in enumerate(L) if x];print(0 if not p else p[-1]-p[0])\n",
"abc424_b": "N,M,K=map(int,input().split());cnt=[0]*(N+1);ans=[]\nfor _ in range(K):\n a,b=map(int,input().split());cnt[a]+=1\n if cnt[a]==M:ans.append(a)\nprint(*ans)\n",
"abc425_b": "N=int(input());A=list(map(int,input().split()));F=[x for x in A if x!=-1]\nif len(F)!=len(set(F)):print('No')\nelse:\n miss=iter(x for x in range(1,N+1) if x not in F);P=[next(miss) if x==-1 else x for x in A];print('Yes');print(*P)\n",
"abc426_b": "from collections import Counter\nS=input().strip();c=Counter(S);print(min(c,key=c.get))\n",
"abc427_b": "N=int(input());a=1;total=1\nfor i in range(1,N+1):\n a=total;total+=sum(map(int,str(a)))\nprint(a)\n",
"abc428_b": "from collections import Counter\nN,K=map(int,input().split());S=input().strip();c=Counter(S[i:i+K] for i in range(N-K+1));m=max(c.values());print(m);print(*sorted(s for s,v in c.items() if v==m))\n",
}
