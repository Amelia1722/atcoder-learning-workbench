"""Private ABC174--179 D reviewed contracts."""
from __future__ import annotations
from collections import deque
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(174,180));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc174_d':
  n=ints(r[0],1)[0];require(2<=n<=200000 and len(r)==2 and len(r[1])==n and set(r[1])<={'R','W'},'stones');return (r[1],)
 if pid=='abc175_d':
  n,k=ints(r[0],2);require(2<=n<=5000 and 1<=k<=10**9 and len(r)==3,'shape');p=ints(r[1],n);c=ints(r[2],n);require(set(p)==set(range(1,n+1)) and all(v!=j+1 for j,v in enumerate(p)) and all(-10**9<=v<=10**9 for v in c),'permutation/scores');return p,c,k
 if pid=='abc176_d':
  h,w=ints(r[0],2);require(1<=h<=1000 and 1<=w<=1000 and len(r)==h+3,'shape');start=ints(r[1],2);goal=ints(r[2],2);grid=tuple(r[3:]);require(all(len(s)==w and set(s)<={'.','#'} for s in grid) and all(1<=a<=h and 1<=b<=w for a,b in (start,goal)) and start!=goal,'maze');require(grid[start[0]-1][start[1]-1]==grid[goal[0]-1][goal[1]-1]=='.','open endpoints');return grid,start,goal
 if pid=='abc177_d':
  n,m=ints(r[0],2);require(2<=n<=200000 and 0<=m<=200000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in edges),'endpoints');return n,edges
 if pid=='abc178_d':
  require(len(r)==1,'shape');s=ints(r[0],1)[0];require(1<=s<=2000,'sum');return (s,)
 n,k=ints(r[0],2);require(2<=n<=200000 and 1<=k<=min(n,10) and len(r)==k+1,'shape');intervals=tuple(ints(s,2) for s in r[1:]);require(all(1<=a<=b<=n for a,b in intervals),'range');ordered=sorted(intervals);require(all(a[1]<b[0] for a,b in zip(ordered,ordered[1:])),'disjoint');return n,intervals
def stone_boundary(s:str)->int:
 whites=0;reds=s.count('R');answer=reds
 for c in s:
  if c=='R':reds-=1
  else:whites+=1
  answer=min(answer,max(whites,reds))
 return answer
def circular_segment(a:list[int],lo:int,hi:int)->int:
 n=len(a);prefix=[0]
 for v in a+a:prefix.append(prefix[-1]+v)
 queue:deque[int]=deque();answer=-10**40
 for end in range(1,2*n):
  start=end-lo
  if 0<=start<n:
   while queue and prefix[queue[-1]]>=prefix[start]:queue.pop()
   queue.append(start)
  while queue and queue[0]<end-hi:queue.popleft()
  if queue:answer=max(answer,prefix[end]-prefix[queue[0]])
 return answer
def moving_cycles(p:tuple[int,...],c:tuple[int,...],k:int)->int:
 seen=[False]*len(p);answer=-10**40
 for start in range(len(p)):
  if seen[start]:continue
  a=[];u=start
  while not seen[u]:seen[u]=True;a.append(c[u]);u=p[u]-1
  n=len(a);total=sum(a)
  if total<=0 or k<n:best=circular_segment(a,1,min(k,n))
  else:
   q,r=divmod(k,n);best=q*total
   if r:best=max(best,q*total+circular_segment(a,1,r))
   if r+1<=n:best=max(best,(q-1)*total+circular_segment(a,r+1,n))
  answer=max(answer,best)
 return answer
def maze_components(grid:tuple[str,...],start:tuple[int,int],goal:tuple[int,int])->int:
 h,w=len(grid),len(grid[0]);labels=[-1]*(h*w);members:list[list[int]]=[]
 for r,row in enumerate(grid):
  for c,ch in enumerate(row):
   first=r*w+c
   if ch=='#' or labels[first]>=0:continue
   component=len(members);group=[first];labels[first]=component
   for u in group:
    a,b=divmod(u,w)
    for x,y in ((a-1,b),(a+1,b),(a,b-1),(a,b+1)):
     if 0<=x<h and 0<=y<w and grid[x][y]=='.' and labels[x*w+y]<0:labels[x*w+y]=component;group.append(x*w+y)
   members.append(group)
 source=labels[(start[0]-1)*w+start[1]-1];target=labels[(goal[0]-1)*w+goal[1]-1]
 if source==target:return 0
 distances=[-1]*len(members);distances[source]=0;queue=deque([source])
 while queue:
  component=queue.popleft();distance=distances[component]+1
  for u in members[component]:
   r,c=divmod(u,w)
   for a in range(max(0,r-2),min(h,r+3)):
    for b in range(max(0,c-2),min(w,c+3)):
     v=labels[a*w+b]
     if v>=0 and distances[v]<0:
      if v==target:return distance
      distances[v]=distance;queue.append(v)
 return -1
def friend_cliques(n:int,edges:tuple[tuple[int,int],...])->int:
 adj:list[list[int]]=[[] for _ in range(n)]
 for u,v in edges:adj[u-1].append(v-1);adj[v-1].append(u-1)
 seen=[False]*n;answer=1
 for u in range(n):
  if seen[u]:continue
  seen[u]=True;stack=[u];size=0
  while stack:
   v=stack.pop();size+=1
   for w in adj[v]:
    if not seen[w]:seen[w]=True;stack.append(w)
  answer=max(answer,size)
 return answer
def compositions_length(s:int)->int:return sum(comb(s-2*k-1,k-1) for k in range(1,s//3+1))%1000000007
def leaping_generating(n:int,intervals:tuple[tuple[int,int],...])->int:
 # F(z)=(1-z)/(1-z-sum(z^L-z^(R+1))). Recover exact coefficients
 # from the sparse denominator polynomial, not transition range sums.
 coefficients:dict[int,int]={1:-1}
 for left,right in intervals:
  coefficients[left]=coefficients.get(left,0)-1
  coefficients[right+1]=coefficients.get(right+1,0)+1
 lags=sorted((lag,v) for lag,v in coefficients.items() if v);f=[1]+[0]*(n-1);mod=998244353
 for i in range(1,n):
  value=-1 if i==1 else 0
  for lag,coefficient in lags:
   if lag>i:break
   value-=coefficient*f[i-lag]
  f[i]=value%mod
 return f[-1]
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc174_d':v=stone_boundary(cast(str,d[0]))
 elif pid=='abc175_d':v=moving_cycles(*cast(tuple[tuple[int,...],tuple[int,...],int],d))
 elif pid=='abc176_d':v=maze_components(*cast(tuple[tuple[str,...],tuple[int,int],tuple[int,int]],d))
 elif pid=='abc177_d':v=friend_cliques(*cast(tuple[int,tuple[tuple[int,int],...]],d))
 elif pid=='abc178_d':v=compositions_length(cast(int,d[0]))
 else:v=leaping_generating(*cast(tuple[int,tuple[tuple[int,int],...]],d))
 return f'{v}\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc174_d':'''n=int(input());s=input();r=s.count('R');print(s[:r].count('W'))
''',
'abc175_d':'''n,k=map(int,input().split());p=[v-1 for v in map(int,input().split())];c=list(map(int,input().split()));seen=[False]*n;answer=-10**40
for start in range(n):
 if seen[start]:continue
 cycle=[];u=start
 while not seen[u]:seen[u]=True;cycle.append(u);u=p[u]
 weights=[c[u] for u in cycle];length=len(weights);total=sum(weights);limit=min(k,length);doubled=weights+weights
 bonuses=[total*((k-t)//length) for t in range(1,limit+1)] if total>0 else [0]*limit
 for offset in range(length):
  score=0
  for weight,bonus in zip(doubled[offset+1:offset+limit+1],bonuses):
   score+=weight;value=score+bonus
   if value>answer:answer=value
print(answer)
''',
'abc176_d':'''from collections import deque
h,w=map(int,input().split());a,b=map(int,input().split());c,d=map(int,input().split());g=[input() for _ in range(h)];dist=[10**9]*(h*w);source=(a-1)*w+b-1;target=(c-1)*w+d-1;dist[source]=0;q=deque([source]);settled=bytearray(h*w)
while q:
 u=q.popleft()
 if settled[u]:continue
 settled[u]=1;r,c=divmod(u,w);v=dist[u]
 for x,y in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
  if 0<=x<h and 0<=y<w and g[x][y]=='.' and dist[x*w+y]>v:dist[x*w+y]=v;q.appendleft(x*w+y)
 for x in range(max(0,r-2),min(h,r+3)):
  for y in range(max(0,c-2),min(w,c+3)):
   if g[x][y]=='.' and dist[x*w+y]>v+1:dist[x*w+y]=v+1;q.append(x*w+y)
print(dist[target] if dist[target]<10**9 else -1)
''',
'abc177_d':'''n,m=map(int,input().split());p=[-1]*n
def find(u):
 while p[u]>=0:
  if p[p[u]]>=0:p[u]=p[p[u]]
  u=p[u]
 return u
for _ in range(m):
 u,v=map(int,input().split());a=find(u-1);b=find(v-1)
 if a!=b:
  if p[a]>p[b]:a,b=b,a
  p[a]+=p[b];p[b]=a
print(-min(p))
''',
'abc178_d':'''s=int(input());mod=1000000007;dp=[0]*(s+1);dp[0]=1;prefix=0
for i in range(3,s+1):prefix=(prefix+dp[i-3])%mod;dp[i]=prefix
print(dp[s])
''',
'abc179_d':'''n,k=map(int,input().split());intervals=[tuple(map(int,input().split())) for _ in range(k)];mod=998244353;dp=[0]*n;prefix=[0]*(n+1);dp[0]=1;prefix[1]=1
for i in range(1,n):
 value=0
 for l,r in intervals:
  a=max(0,i-r);b=i-l
  if b>=0:value+=prefix[b+1]-prefix[a]
 dp[i]=value%mod;prefix[i+1]=(prefix[i]+dp[i])%mod
print(dp[-1])
'''}
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(18800+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc174_d':raws=[f'{len(s)}\n{s}\n' for s in ('RR','RW','WR','WW','WWRR','WRWWRWRR','RWR','WRW','RRWWW','WWWRR','RWRWRW','WRWRWR','W'*100,'R'*100,'RW'*100,'WR'*100,'W'*100000+'R'*100000,'R'*200000)]
 elif pid=='abc175_d':
  def game(p:list[int],c:list[int],k:int)->str:return f'{len(p)} {k}\n'+line(p)+line(c)
  raws=[game([2,1],[-10**9,-10**9],1),game([2,1],[0,0],1),game([2,1],[10,-7],3),game([2,3,1],[9,-8,1],4),game([2,3,1],[-1,-2,-3],10**9)]
  for n in range(3,14):raws.append(game(list(range(2,n+1))+[1],[rng.randint(-10**9,10**9) for _ in range(n)],rng.randint(1,10**9)))
  raws+=[game(list(range(2,5001))+[1],[10**9 if i%2 else -10**9 for i in range(5000)],10**9),game(list(range(2,5001))+[1],[10**9]*5000,10**9)]
 elif pid=='abc176_d':
  def maze(g:list[str],start:tuple[int,int],goal:tuple[int,int])->str:return f'{len(g)} {len(g[0])}\n'+line(start)+line(goal)+'\n'.join(g)+'\n'
  raws=[maze(['..'],(1,1),(1,2)),maze(['.','.'],(1,1),(2,1)),maze(['.#.'],(1,1),(1,3)),maze(['.##.'],(1,1),(1,4)),maze(['.#','#.'],(1,1),(2,2)),maze(['.##','###','##.'],(1,1),(3,3))]
  for n in range(2,12):
   g=[''.join(rng.choice('.#') for _ in range(n+1)) for _ in range(n)];g[0]='.'+g[0][1:];g[-1]=g[-1][:-1]+'.';raws.append(maze(g,(1,1),(n,n+1)))
  raws+=[maze([''.join('.' if (r+c)%2==0 else '#' for c in range(1000)) for r in range(1000)],(1,1),(1000,1000)),maze(['.'*1000]*1000,(1,1),(1000,1000))]
 elif pid=='abc177_d':
  def graph(n:int,e:list[tuple[int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(p) for p in e)
  raws=[graph(2,[]),graph(2,[(1,2)]),graph(2,[(1,2),(2,1)]),graph(3,[(1,2)]),graph(4,[(1,2),(3,4)])]
  for n in range(3,14):raws.append(graph(n,[(i,i+1) for i in range(1,n)]+[(2,1)]*n))
  raws+=[graph(200000,[(1,2)]*200000),graph(200000,[(i,i+1) for i in range(1,200000)]+[(200000,1)])]
 elif pid=='abc178_d':raws=[f'{s}\n' for s in (1,2,3,4,5,6,7,8,9,10,11,12,100,500,1000,1729,1999,2000)]
 else:
  def steps(n:int,intervals:list[tuple[int,int]])->str:return f'{n} {len(intervals)}\n'+''.join(line(p) for p in intervals)
  raws=[steps(2,[(1,1)]),steps(2,[(2,2)]),steps(2,[(1,2)]),steps(2,[(2,2),(1,1)]),steps(5,[(1,1),(3,4)]),steps(5,[(3,3),(5,5)]),steps(5,[(1,2)]),steps(60,[(5,8),(1,3),(10,15)])]
  for n in range(6,14):raws.append(steps(n,[(j,j) for j in range(1,min(n,10)+1)]))
  raws+=[steps(200000,[(1,200000)]),steps(200000,[(1,20000)]+[(j,j+19999) for j in range(20001,200000,20000)])]
 require(len(raws)==len(set(raws))==18,'distinct18')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc174_d':('赤を左、白を右に集めた列を目指します。','赤の総数Rに対して先頭R個にある白を数えます。そこにある白と右側の赤を一組ずつ交換すれば最小です。色変更を許してもこれより少なくできません。','疑似コード: R=文字列の赤の個数; 先頭R文字のWの個数を出力。'),
'abc175_d':('順列は閉じたサイクルに分解できます。','各サイクルの各開始点と、一周以内の移動回数を調べます。一周の得点が正なら、残り回数でできるだけ周回を追加します。少なくとも一回は移動します。','疑似コード: 全cycleを抽出; 各開始点でt=1..min(K,cycle長)の累積得点を更新; cycle和>0なら和*floor((K-t)/長)を加算; 全候補の最大を出力。'),
'abc176_d':('歩く移動はコスト0、ワープはコスト1です。','0-1 BFSを使い、隣接する道の更新をdequeの先頭へ、5×5内の道への更新を末尾へ追加します。','疑似コード: dist[start]=0; dequeからpop; 上下左右の道へ同距離で緩和しappendleft; 半径2の道へdist+1で緩和しappend; goal距離、未到達なら-1。'),
'abc177_d':('友達の推移律により、連結成分の全員は互いに友達です。','一つの成分の全員を異なるグループに置く必要があります。最大成分サイズ個のグループで全成分を収容できます。','疑似コード: 友達全辺をUnion-Findでunion（重複辺もよい）; 全成分sizeの最大を出力。'),
'abc178_d':('最後の項を3以上として、残りの総和を考えます。','dp[s]は総和sの列数です。最後の項vを3..sとしてdp[s-v]を足します。累積和なら効率よく更新できます。','疑似コード: dp[0]=1; s=3..Sでprefix+=dp[s-3] mod; dp[s]=prefix; dp[S]を出力。'),
'abc179_d':('現在のマスへ入る直前のマスは、各歩幅区間に対応する範囲です。','dpの累積和から、各区間[i-R,i-L]の遷移元の総数を定数時間で求めます。区間は重ならないので重複計数しません。','疑似コード: dp[1]=1; i=2..Nについて各L,Rの有効範囲のprefix差を加算mod998244353; prefixを更新; dp[N]を出力。')}

TITLES={'abc174_d': 'Alter Altar', 'abc175_d': 'Moving Piece', 'abc176_d': 'Wizard in Maze', 'abc177_d': 'Friends', 'abc178_d': 'Redistribution', 'abc179_d': 'Leaping Tak'}
PUBLISHED_SAMPLES={'abc174_d': [{'input': '4\nWWRR\n', 'expected': '2\n'}, {'input': '2\nRR\n', 'expected': '0\n'}, {'input': '8\nWRWWRWRR\n', 'expected': '3\n'}], 'abc175_d': [{'input': '5 2\n2 4 5 1 3\n3 4 -10 -8 8\n', 'expected': '8\n'}, {'input': '2 3\n2 1\n10 -7\n', 'expected': '13\n'}, {'input': '3 3\n3 1 2\n-1000 -2000 -3000\n', 'expected': '-1000\n'}, {'input': '10 58\n9 1 6 7 8 4 3 2 10 5\n695279662 988782657 -119067776 382975538 -151885171 -177220596 -169777795 37619092 389386780 980092719\n', 'expected': '29507023469\n'}], 'abc176_d': [{'input': '4 4\n1 1\n4 4\n..#.\n..#.\n.#..\n.#..\n', 'expected': '1\n'}, {'input': '4 4\n1 4\n4 1\n.##.\n####\n####\n.##.\n', 'expected': '-1\n'}, {'input': '4 4\n2 2\n3 3\n....\n....\n....\n....\n', 'expected': '0\n'}, {'input': '4 5\n1 2\n2 5\n#.###\n####.\n#..##\n#..##\n', 'expected': '2\n'}], 'abc177_d': [{'input': '5 3\n1 2\n3 4\n5 1\n', 'expected': '3\n'}, {'input': '4 10\n1 2\n2 1\n1 2\n2 1\n1 2\n1 3\n1 4\n2 3\n2 4\n3 4\n', 'expected': '4\n'}, {'input': '10 4\n3 1\n4 1\n5 9\n2 6\n', 'expected': '3\n'}], 'abc178_d': [{'input': '7\n', 'expected': '3\n'}, {'input': '2\n', 'expected': '0\n'}, {'input': '1729\n', 'expected': '294867501\n'}], 'abc179_d': [{'input': '5 2\n1 1\n3 4\n', 'expected': '4\n'}, {'input': '5 2\n3 3\n5 5\n', 'expected': '0\n'}, {'input': '5 1\n1 2\n', 'expected': '5\n'}, {'input': '60 3\n5 8\n1 3\n10 15\n', 'expected': '221823067\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
