"""Hints re-reviewed against public official statements of ABC095–097 B."""
HINTS_V79={
'abc095_b':('まず全種類を1個ずつ作ると、残った材料で何を追加すれば個数を最も増やせるか考えてください。','全種類1個分の材料を引いた後、必要量が最小のドーナツを残り材料で可能な限り作ります。','疑似コード:\nused = sum(m)\nremain = X - used\nanswer = N + remain // min(m)\nprint(answer)'),
'abc096_b':('1回の2倍操作をどの数に使うと、その後の合計増加量が最も大きくなるでしょうか。','最大の数を毎回2倍するのが最適です。K回なら最大値だけを2^K倍して他の2値と足します。','疑似コード:\nvalues = [A, B, C]\ni = index_of_max(values)\nvalues[i] *= 2 ** K\nprint(sum(values))'),
'abc097_b':('Xは1000以下です。べき乗数の候補を直接列挙しても十分間に合います。','底bを2以上から試し、b^2, b^3, ... がX以下の間だけ最大値を更新します。1は常に候補です。','疑似コード:\nans = 1\nfor b in range(2, 32):\n  p = b*b\n  while p <= X:\n    ans = max(ans, p)\n    p *= b\nprint(ans)')}
