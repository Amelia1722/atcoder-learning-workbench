"""ABC266–268 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc266_b', 'abc267_b', 'abc268_b')
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)
BIN10 = re.compile(r'[01]{10}', re.ASCII)
MOD = 998244353

PUBLISHED_SAMPLES = {
    'abc266_b': [
        {'input': '998244354\n', 'expected': '1\n'},
        {'input': '-9982443534\n', 'expected': '998244349\n'},
    ],
    'abc267_b': [
        {'input': '0101110101\n', 'expected': 'Yes\n'},
        {'input': '0100101001\n', 'expected': 'Yes\n'},
        {'input': '0000100110\n', 'expected': 'No\n'},
        {'input': '1101110101\n', 'expected': 'No\n'},
    ],
    'abc268_b': [
        {'input': 'atco\natcoder\n', 'expected': 'Yes\n'},
        {'input': 'code\natcoder\n', 'expected': 'No\n'},
        {'input': 'abc\nabc\n', 'expected': 'Yes\n'},
        {'input': 'aaaa\naa\n', 'expected': 'No\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _validate266(raw: str) -> int:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or INT.fullmatch(lines[0]) is None:
        raise ValueError('shape')
    n = int(lines[0])
    if not -10**18 <= n <= 10**18:
        raise ValueError('N')
    return n


def _validate267(raw: str) -> str:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or BIN10.fullmatch(lines[0]) is None:
        raise ValueError('S')
    return lines[0]


def _validate268(raw: str) -> tuple[str, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    s, t = lines
    if LOWER.fullmatch(s) is None or LOWER.fullmatch(t) is None:
        raise ValueError('alphabet')
    if not 1 <= len(s) <= 100 or not 1 <= len(t) <= 100:
        raise ValueError('length')
    return s, t


def validate(pid: str, raw: str):
    if pid == 'abc266_b':
        return _validate266(raw)
    if pid == 'abc267_b':
        return _validate267(raw)
    if pid == 'abc268_b':
        return _validate268(raw)
    raise ValueError('unknown task')


def _oracle266(n: int) -> int:
    q = n // MOD
    x = n - q * MOD
    if x < 0:
        x += MOD
    elif x >= MOD:
        x -= MOD
    return x


def _oracle267(s: str) -> str:
    if s[0] == '1':
        return 'No'
    pin_to_col = (3, 2, 4, 1, 3, 5, 0, 2, 4, 6)
    standing = {pin_to_col[i] for i, ch in enumerate(s) if ch == '1'}
    if len(standing) < 2:
        return 'No'
    lo, hi = min(standing), max(standing)
    return 'Yes' if len(standing) != hi - lo + 1 else 'No'


def _oracle268(s: str, t: str) -> str:
    if len(s) > len(t):
        return 'No'
    for i, ch in enumerate(s):
        if ch != t[i]:
            return 'No'
    return 'Yes'


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc266_b':
        if re.fullmatch(r'(?:0|[1-9][0-9]*)', output, re.ASCII) is None:
            return False
        return int(output) == _oracle266(value)
    if pid == 'abc267_b':
        return output in {'Yes', 'No'} and output == _oracle267(value)
    return output in {'Yes', 'No'} and output == _oracle268(*value)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc266_b':
        custom = [
            ('zero', '0\n'),
            ('one', '1\n'),
            ('minus_one', '-1\n'),
            ('mod_minus_one', f'{MOD-1}\n'),
            ('mod_exact', f'{MOD}\n'),
            ('minus_mod_exact', f'{-MOD}\n'),
            ('minus_mod_plus_one', f'{-MOD+1}\n'),
            ('two_mod_plus', f'{2*MOD+123}\n'),
            ('two_mod_minus', f'{-2*MOD-123}\n'),
            ('large_positive', '999999999999999999\n'),
            ('large_negative', '-999999999999999999\n'),
            ('positive_mid', '123456789012345678\n'),
            ('negative_mid', '-123456789012345678\n'),
            ('near_max_negative', '-999999999999999998\n'),
            ('constraint_min', f'{-10**18}\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', f'{10**18}\n')
    elif pid == 'abc267_b':
        custom = [
            ('all_down', '0000000000\n'),
            ('head_only', '1000000000\n'),
            ('single_left', '0000001000\n'),
            ('single_right', '0000000001\n'),
            ('two_adjacent_columns', '0001001000\n'),
            ('gap_left_right', '0000001001\n'),
            ('gap_inner', '0100010000\n'),
            ('filled_contiguous', '0111011111\n'),
            ('only_col2_and4', '0100000010\n'),
            ('three_with_gap', '0001011000\n'),
            ('head_blocks_split', '1010001000\n'),
            ('near_all_standing_head_down', '0111111111\n'),
            ('alternating', '0010101010\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', '1111111111\n')
    else:
        custom = [
            ('single_equal', 'a\na\n'),
            ('single_prefix', 'a\naz\n'),
            ('single_not_prefix', 'z\naz\n'),
            ('longer_same_start', 'abcd\nabc\n'),
            ('diff_last', 'abcx\nabcy\n'),
            ('prefix_one_short', 'abcdefghi\nabcdefghij\n'),
            ('length100_equal', 'a'*100+'\n'+'a'*100+'\n'),
            ('length99_prefix', 'b'*99+'\n'+'b'*100+'\n'),
            ('length100_mismatch_end', 'c'*99+'d\n'+'c'*99+'e\n'),
            ('different_first', 'x'*50+'\n'+'y'*50+'\n'),
            ('mixed_prefix', 'atcoder\natcoderbeginnercontest\n'),
            ('mixed_no', 'beginner\natcoderbeginnercontest\n'),
            ('short_repeat_yes', 'abab\nabababab\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', 'z'*100+'\n'+'z'*100+'\n')

    if len(out) != 18:
        raise AssertionError((pid, len(out), [x['category'] for x in out]))
    return out
