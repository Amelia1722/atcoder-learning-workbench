from __future__ import annotations
from bisect import bisect_left
from collections import Counter,deque
from math import gcd
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{i}_d' for i in range(431,437));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...];NEG=-10**30

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc431_d':
  n=ints(r[0],1)[0];require(1<=n<=500 and len(r)==n+1,'N');parts=tuple(ints(row,3) for row in r[1:]);require(all(1<=w<=500 and 1<=h<=10**9 and 1<=b<=10**9 for w,h,b in parts),'parts');return (parts,)
 if pid=='abc432_d':
  n,x,y=ints(r[0],3);require(1<=n<=14 and 1<=x<=10**8 and 1<=y<=10**8 and len(r)==n+1,'shape');storms=[]
  for row in r[1:]:
   fields=row.split(' ');require(len(fields)==3 and fields[0] in ('X','Y'),'kind');a,b=ints(' '.join(fields[1:]),2);require(-10**8<=a<=10**8 and -10**8<=b<=10**8,'range');storms.append((fields[0],a,b))
  return x,y,tuple(storms)
 if pid=='abc433_d':
  n,m=ints(r[0],2);require(1<=n<=200000 and 1<=m<=10**9 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=v<=10**9 for v in a),'Ai');return m,a
 if pid=='abc434_d':
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)==n+1,'shape');clouds=tuple(ints(row,4) for row in r[1:]);require(all(1<=u<=d<=2000 and 1<=l<=rr<=2000 for u,d,l,rr in clouds),'rectangle');return (clouds,)
 if pid=='abc435_d':
  n,m=ints(r[0],2);require(1<=n<=300000 and 0<=m<=300000 and len(r)>=m+3,'N/M');edges=tuple(ints(row,2) for row in r[1:m+1]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges) and len(set(edges))==m,'simple directed');q=ints(r[m+1],1)[0];require(1<=q<=300000 and len(r)==m+q+2,'Q');queries=tuple(ints(row,2) for row in r[m+2:]);require(all(k in (1,2) and 1<=v<=n for k,v in queries),'queries');return n,edges,queries
 h,w=ints(r[0],2);require(1<=h<=1000 and 1<=w<=1000 and h*w>=2 and len(r)==h+1,'shape');grid=tuple(r[1:]);require(all(re.fullmatch('[.#a-z]{'+str(w)+'}',row) is not None for row in grid) and grid[0][0]!='#' and grid[-1][-1]!='#','grid');return (grid,)

def concave_convolution(old:list[int],prefix:list[int])->list[int]:
 n=len(old);count=len(prefix)-1
 if count<=3:
  out=old.copy()
  for chosen in range(1,count+1):
   gain=prefix[chosen];out[chosen:]=[max(current,value+gain) for current,value in zip(out[chosen:],old)]
  return out
 out=[NEG]*n
 def solve(left:int,right:int,optleft:int,optright:int)->None:
  if left>right:return
  middle=(left+right)//2;lo=max(optleft,middle-count,0);hi=min(optright,middle);best=NEG;arg=lo
  for j in range(lo,hi+1):
   value=old[j]+prefix[middle-j]
   if value>best:best,arg=value,j
  out[middle]=best;solve(left,middle-1,optleft,arg);solve(middle+1,right,arg,optright)
 solve(0,n-1,0,n-1);return out

def robot_grouped_monge(parts:tuple[tuple[int,...],...])->int:
 capacity=sum(w for w,h,b in parts)//2;base=sum(b for w,h,b in parts);groups:dict[int,list[int]]={}
 for w,h,b in parts:
  if h>b:groups.setdefault(w,[]).append(h-b)
 dp=[0]*(capacity+1)
 for weight,gains in sorted(groups.items()):
  prefix=[0]
  for gain in sorted(gains,reverse=True):prefix.append(prefix[-1]+gain)
  new=dp.copy()
  for residue in range(min(weight,capacity+1)):
   result=concave_convolution(dp[residue::weight],prefix);new[residue::weight]=result
  dp=new
 return base+dp[capacity]
Rect=tuple[int,int,int,int]

def inverse_storm_rectangles(x:int,y:int,storms:tuple[tuple[str,int,int],...])->list[Rect]:
 sx=sum(abs(b) for kind,a,b in storms if kind=='Y');sy=sum(abs(b) for kind,a,b in storms if kind=='X');out:list[Rect]=[]
 def descend(i:int,l:int,r:int,bottom:int,top:int,dx:int,dy:int)->None:
  if l>=r or bottom>=top:return
  if i<0:
   ll=max(l,-dx);rr=min(r,x-dx);bb=max(bottom,-dy);tt=min(top,y-dy)
   if ll<rr and bb<tt:out.append((ll,rr,bb,tt))
   return
  kind,a,b=storms[i]
  if kind=='X':
   cut=a-dx;descend(i-1,l,min(r,cut),bottom,top,dx,dy+b);descend(i-1,max(l,cut),r,bottom,top,dx,dy-b)
  else:
   cut=a-dy;descend(i-1,l,r,bottom,min(top,cut),dx+b,dy);descend(i-1,l,r,max(bottom,cut),top,dx-b,dy)
 descend(len(storms)-1,-sx,x+sx,-sy,y+sy,0,0);return out

def slab_components(rects:list[Rect])->list[int]:
 n=len(rects);parent=list(range(n));events:dict[int,list[tuple[int,int]]]={}
 def root(v:int)->int:
  while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
  return v
 def merge(a:int,b:int)->None:
  aa,bb=root(a),root(b)
  if aa!=bb:parent[aa]=bb
 for i,(l,r,b,t) in enumerate(rects):events.setdefault(l,[]).append((1,i));events.setdefault(r,[]).append((-1,i))
 active:set[int]=set();previous:list[tuple[int,int,int]]=[];coordinates=sorted(events)
 for x in coordinates[:-1]:
  for kind,i in events[x]:
   if kind==1:active.add(i)
   else:active.remove(i)
  groups:list[tuple[int,int,int]]=[]
  for b,t,i in sorted((rects[i][2],rects[i][3],i) for i in active):
   if groups and b<=groups[-1][1]:
    oldb,oldt,representative=groups[-1];merge(representative,i);groups[-1]=(oldb,max(oldt,t),representative)
   else:groups.append((b,t,i))
  at=0
  for b,t,i in groups:
   while at<len(previous) and previous[at][1]<=b:at+=1
   j=at
   while j<len(previous) and previous[j][0]<t:
    if max(b,previous[j][0])<min(t,previous[j][1]):merge(i,previous[j][2])
    j+=1
  previous=groups
 totals:dict[int,int]={}
 for i,(l,r,b,t) in enumerate(rects):rr=root(i);totals[rr]=totals.get(rr,0)+(r-l)*(t-b)
 return sorted(totals.values())
def tempest_inverse(x:int,y:int,storms:tuple[tuple[str,int,int],...])->list[int]:return slab_components(inverse_storm_rectangles(x,y,storms))

def concatenation_congruences(m:int,a:tuple[int,...])->int:
 lengths=Counter(len(str(v)) for v in a);answer=0
 for length in lengths:
  coefficient=10**length;common=gcd(coefficient,m);reduced=m//common;inverse=pow(coefficient//common,-1,reduced) if reduced>1 else 0;counts=Counter(v%reduced for v in a)
  for right in a:
   if len(str(right))==length and right%common==0:answer+=counts[(-right//common*inverse)%reduced]
 return answer

def clouds_sweep_xor(clouds:tuple[tuple[int,...],...],side:int=2000)->list[int]:
 events=[[] for _ in range(side+1)];countdiff=[0]*(side+1);ownerdiff=[0]*(side+1);single=[0]*len(clouds);uncovered=0
 for i,(u,d,l,r) in enumerate(clouds,1):events[u-1].append((1,l-1,r,i));events[d].append((-1,l-1,r,i))
 for row in range(side):
  for delta,left,right,owner in events[row]:countdiff[left]+=delta;countdiff[right]-=delta;ownerdiff[left]^=owner;ownerdiff[right]^=owner
  count=owner=0
  for col in range(side):
   count+=countdiff[col];owner^=ownerdiff[col]
   if count==0:uncovered+=1
   elif count==1:single[owner-1]+=1
 return [uncovered+v for v in single]

def first_black_reverse_dijkstra(n:int,edges:tuple[tuple[int,...],...],queries:tuple[tuple[int,...],...])->list[str]:
 incoming=[[] for _ in range(n)]
 for a,b in edges:incoming[b-1].append(a-1)
 time=[len(queries)+1]*n;heap=[]
 for i,(kind,v) in enumerate(queries):
  if kind==1 and i<time[v-1]:time[v-1]=i;heapq.heappush(heap,(i,v-1))
 while heap:
  moment,v=heapq.heappop(heap)
  if time[v]!=moment:continue
  for u in incoming[v]:
   if moment<time[u]:time[u]=moment;heapq.heappush(heap,(moment,u))
 return ['Yes' if time[v-1]<=i else 'No' for i,(kind,v) in enumerate(queries) if kind==2]

def teleport_lifted_zero_one(grid:tuple[str,...])->int:
 h=len(grid);w=len(grid[0]);n=h*w;letters=[[] for _ in range(26)];distance=[10**9]*(n+26);distance[0]=0;queue=deque([0])
 for r,row in enumerate(grid):
  for c,ch in enumerate(row):
   if ch not in '.#':letters[ord(ch)-97].append(r*w+c)
 def relax(u:int,v:int,cost:int)->None:
  candidate=distance[u]+cost
  if candidate<distance[v]:distance[v]=candidate;queue.append(v) if cost else queue.appendleft(v)
 while queue:
  u=queue.popleft()
  if u>=n:
   for v in letters[u-n]:relax(u,v,1)
   continue
  r,c=divmod(u,w);ch=grid[r][c]
  if ch not in '.#':relax(u,n+ord(ch)-97,0)
  for nr,nc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
   if 0<=nr<h and 0<=nc<w and grid[nr][nc]!='#':relax(u,nr*w+nc,1)
 return -1 if distance[n-1]==10**9 else distance[n-1]

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc431_d':return str(robot_grouped_monge(cast(tuple[tuple[int,...],...],d[0])))+'\n'
 if pid=='abc432_d':sizes=tempest_inverse(*cast(tuple[int,int,tuple[tuple[str,int,int],...]],d));return str(len(sizes))+'\n'+line(sizes)
 if pid=='abc433_d':return str(concatenation_congruences(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc434_d':return ''.join(str(v)+'\n' for v in clouds_sweep_xor(cast(tuple[tuple[int,...],...],d[0])))
 if pid=='abc435_d':return ''.join(v+'\n' for v in first_black_reverse_dijkstra(*cast(tuple[int,tuple[tuple[int,...],...],tuple[tuple[int,...],...]],d)))
 return str(teleport_lifted_zero_one(cast(tuple[str,...],d[0])))+'\n'
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,KeyError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc431_d':'''def solve():
 n=int(input());parts=[tuple(map(int,input().split())) for _ in range(n)];capacity=sum(w for w,h,b in parts)//2;dp=[0]*(capacity+1);base=0
 for w,h,b in parts:
  base+=b;gain=h-b
  if gain<=0:continue
  for weight in range(capacity,w-1,-1):
   candidate=dp[weight-w]+gain
   if candidate>dp[weight]:dp[weight]=candidate
 print(base+dp[capacity])
solve()
''',
'abc432_d':'''n,x,y=map(int,input().split());rects=[(0,x,0,y)]
for _ in range(n):
 kind,a,b=input().split();a=int(a);b=int(b);out=[]
 for l,r,bot,top in rects:
  if kind=='X':
   if l<min(r,a):out.append((l,min(r,a),bot-b,top-b))
   if max(l,a)<r:out.append((max(l,a),r,bot+b,top+b))
  else:
   if bot<min(top,a):out.append((l-b,r-b,bot,min(top,a)))
   if max(bot,a)<top:out.append((l+b,r+b,max(bot,a),top))
 rects=out
n=len(rects);parent=list(range(n));sizes=[(r-l)*(t-b) for l,r,b,t in rects]
def root(v):
 while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
 return v
def merge(a,b):
 a=root(a);b=root(b)
 if a!=b:parent[a]=b;sizes[b]+=sizes[a]
left={};right={};bottom={};top={}
for i,(l,r,b,t) in enumerate(rects):left.setdefault(l,[]).append((b,t,i));right.setdefault(r,[]).append((b,t,i));bottom.setdefault(b,[]).append((l,r,i));top.setdefault(t,[]).append((l,r,i))
def contacts(a,b):
 for coordinate in a.keys()&b.keys():
  one=sorted(a[coordinate]);two=sorted(b[coordinate]);i=j=0
  while i<len(one) and j<len(two):
   l,r,u=one[i];ll,rr,v=two[j]
   if max(l,ll)<min(r,rr):merge(u,v)
   if r<=rr:i+=1
   else:j+=1
contacts(left,right);contacts(bottom,top);out=sorted(sizes[i] for i in range(n) if root(i)==i);print(len(out));print(*out)
''',
'abc433_d':'''from collections import Counter
n,m=map(int,input().split());a=list(map(int,input().split()));groups={}
for v in a:groups.setdefault(len(str(v)),Counter())[v%m]+=1
answer=0
for length,counts in groups.items():
 coefficient=pow(10,length,m)
 for v in a:answer+=counts[(-v*coefficient)%m]
print(answer)
''',
'abc434_d':'''import sys
from array import array
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);size=2001;count=[array('i',[0])*size for _ in range(size)];owner=[array('q',[0])*size for _ in range(size)]
for i in range(1,n+1):
 u=next(it)-1;d=next(it);l=next(it)-1;r=next(it)
 for x,y,sign in [(u,l,1),(d,r,1),(u,r,-1),(d,l,-1)]:count[x][y]+=sign;owner[x][y]+=sign*i
uncovered=0;unique=[0]*n
for x in range(2000):
 c=0;o=0
 for y in range(2000):
  c+=count[x][y];o+=owner[x][y]
  if x:count[x][y]=c+count[x-1][y];owner[x][y]=o+owner[x-1][y]
  else:count[x][y]=c;owner[x][y]=o
  value=count[x][y]
  if value==0:uncovered+=1
  elif value==1:unique[owner[x][y]-1]+=1
sys.stdout.write('\\n'.join(str(uncovered+v) for v in unique)+'\\n')
''',
'abc435_d':'''import sys
from collections import deque
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);incoming=[[] for _ in range(n)]
for _ in range(m):a=next(it)-1;b=next(it)-1;incoming[b].append(a)
q=next(it);reachable=bytearray(n);out=[]
for _ in range(q):
 kind=next(it);v=next(it)-1
 if kind==2:out.append('Yes' if reachable[v] else 'No')
 elif not reachable[v]:
  reachable[v]=1;queue=deque([v])
  while queue:
   u=queue.popleft()
   for p in incoming[u]:
    if not reachable[p]:reachable[p]=1;queue.append(p)
sys.stdout.write(''.join(value+'\\n' for value in out))
''',
'abc436_d':'''from collections import deque
h,w=map(int,input().split());grid=[input() for _ in range(h)];letters=[[] for _ in range(26)]
for r in range(h):
 for c,ch in enumerate(grid[r]):
  if ch not in '.#':letters[ord(ch)-97].append(r*w+c)
distance=[-1]*(h*w);distance[0]=0;queue=deque([0])
while queue:
 p=queue.popleft();r,c=divmod(p,w);ch=grid[r][c]
 if ch not in '.#':
  k=ord(ch)-97
  for q in letters[k]:
   if distance[q]<0:distance[q]=distance[p]+1;queue.append(q)
  letters[k]=[]
 for nr,nc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
  if 0<=nr<h and 0<=nc<w and grid[nr][nc]!='#':
   q=nr*w+nc
   if distance[q]<0:distance[q]=distance[p]+1;queue.append(q)
print(distance[-1])
'''}
def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc431_d':
  def robot(parts:list[tuple[int,int,int]])->str:return str(len(parts))+'\n'+''.join(line(p) for p in parts)
  raws=[robot([(1,1,1)]),robot([(1,10**9,1)]),robot([(1,10**9,1),(1,1,10**9)]),robot([(1,41,59),(2,65,35),(8,97,93)]),robot([(500,1,10**9)]*2),robot([(1,10**9,1)]*3),robot([(1,100,50),(2,80,90),(3,1,1)]),robot([(500,10**9,1)]*3)]
  while len(raws)<16:raws.append(robot([(rng.randint(1,500),rng.randint(1,10**9),rng.randint(1,10**9)) for _ in range(5+len(raws))]))
  raws[15]=robot([(500,10**9,1)]*500)
  raws += [robot([(rng.randint(1,500),rng.randint(2,10**9),1) for _ in range(500)]),robot([(500,10**9,10**9)]*500)]
 elif pid=='abc432_d':
  def tempest(x:int,y:int,storms:list[tuple[str,int,int]])->str:return f'{len(storms)} {x} {y}\n'+''.join(f'{c} {a} {b}\n' for c,a,b in storms)
  raws=[tempest(1,1,[('X',0,0)]),tempest(2,2,[('X',1,0)]),tempest(2,2,[('X',1,1)]),tempest(2,2,[('X',1,-1)]),tempest(2,2,[('Y',1,1)]),tempest(3,5,[('X',2,2),('Y',-1,1)]),tempest(2,2,[('X',1,1),('X',1,-1)]),tempest(3,3,[('X',1,1),('Y',1,-1),('X',2,1)])]
  while len(raws)<16:raws.append(tempest(rng.randint(1,12),rng.randint(1,12),[(rng.choice('XY'),rng.randint(-12,12),rng.randint(-12,12)) for _ in range(14)]))
  raws += [tempest(10**8,10**8,[(rng.choice('XY'),rng.randint(-10**8,10**8),rng.randint(-10**8,10**8)) for _ in range(14)]),tempest(10**8,10**8,[('X' if i%2==0 else 'Y',10**8 if i%3 else -10**8,10**8 if i%4 else -10**8) for i in range(14)])]
 elif pid=='abc433_d':
  def concatenate(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
  raws=[concatenate(1,[1]),concatenate(11,[2,42]),concatenate(7,[2,8,16,183]),concatenate(5,[10**9]*5),concatenate(2,[1,2,3,4]),concatenate(10,[1,10,100,1000]),concatenate(25,[5,25,125,1]),concatenate(100,[10,100,1000,10**9])]
  while len(raws)<16:raws.append(concatenate(rng.randint(1,10**9),[rng.randint(1,10**9) for _ in range(20+len(raws))]))
  raws += [concatenate(999999937,[rng.randint(1,10**9) for _ in range(200000)]),concatenate(10**9,[10**9]*200000)]
 elif pid=='abc434_d':
  def clouds(a:list[tuple[int,int,int,int]])->str:return str(len(a))+'\n'+''.join(line(r) for r in a)
  raws=[clouds([(1,1,1,1)]),clouds([(1,2000,1,2000)]),clouds([(1,1,1,1)]*2),clouds([(1,1,1,1),(2,2,2,2)]),clouds([(1,2,1,2),(2,3,2,3)]),clouds([(1,2000,1,1),(1,1,1,2000)]),clouds([(2000,2000,2000,2000)]),clouds([(1,2000,1,2000),(1,1,1,1)])]
  while len(raws)<16:
   a=[]
   for _ in range(5+len(raws)):
    u,d=sorted((rng.randint(1,2000),rng.randint(1,2000)));l,r=sorted((rng.randint(1,2000),rng.randint(1,2000)));a.append((u,d,l,r))
   raws.append(clouds(a))
  raws += [clouds([(i//2000+1,i//2000+1,i%2000+1,i%2000+1) for i in range(200000)]),clouds([(1,2000,1,2000)]*200000)]
 elif pid=='abc435_d':
  def reach(n:int,e:list[tuple[int,int]],q:list[tuple[int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(p) for p in e)+str(len(q))+'\n'+''.join(line(p) for p in q)
  raws=[reach(1,[],[(1,1)]),reach(1,[],[(2,1)]),reach(1,[],[(1,1),(2,1)]),reach(2,[(1,2)],[(2,1),(1,2),(2,1)]),reach(2,[(2,1)],[(1,2),(2,1)]),reach(3,[(1,2),(2,3),(3,1)],[(1,2),(2,3),(2,1)]),reach(3,[],[(1,1),(1,1),(2,2)]),reach(3,[(1,2)],[(1,3),(2,1),(2,3)])]
  while len(raws)<15:
   n=10+len(raws);e=rng.sample([(a,b) for a in range(1,n+1) for b in range(1,n+1) if a!=b],2*n);raws.append(reach(n,e,[(rng.randint(1,2),rng.randint(1,n)) for _ in range(3*n)]))
  cycle=[(i,i+1) for i in range(1,300000)]+[(300000,1)];raws += [reach(300000,cycle,[(1,i+1) for i in range(300000)]),reach(300000,[(i,i+1) for i in range(1,300000)],[(1,300000),(2,1)]*150000),reach(300000,cycle,[(2,300000)]*300000)]
 else:
  def maze(rows:list[str])->str:return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'
  values=[['..'],['a.'],['aa'],['.#.'],['a#a'],['..','..'],['.#','#.'],['..a.','####','ba#b']];raws=[maze(rows) for rows in values]
  while len(raws)<16:
   h=4+len(raws)%5;w=5+len(raws)%7;rows=[''.join(rng.choice('.#abcde') for _ in range(w)) for _ in range(h)];rows[0]='.'+rows[0][1:];rows[-1]=rows[-1][:-1]+'.';raws.append(maze(rows))
  raws += [maze([''.join(rng.choice('.#abcdefghijklmnopqrstuvwxyz') for _ in range(1000)) for _ in range(999)]+['a'*1000]),maze(['z'*1000]*1000)]
  # Ensure maximum random grid start is passable without changing its physical domain.
  if raws[-2].splitlines()[1][0]=='#':rows=raws[-2].splitlines();rows[1]='a'+rows[1][1:];raws[-2]='\n'.join(rows)+'\n'
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i>=15 else 'random'} for i,raw in enumerate(raws)]
HINTS:dict[str,tuple[str,str,str]]={
'abc431_d':('全部品を体に置いた状態から、いくつかを頭へ移すと考えます。','頭の重さは総重量の半分以下です。頭へ移す利得Hi-Biを価値とする0/1ナップサックになります。','疑似コード: cap=sum(W)//2、base=sum(B)、dp=0配列。各部品でgain=H-Bが正ならweightをcapからWまで降順にしてdp[weight]=max(dp[weight],dp[weight-W]+gain)。base+dp[cap]を出力。'),
'abc432_d':('黒い長方形を、嵐の境界で分割して平行移動します。','各長方形の辺を座標ごとにまとめると、同じ座標で反対側の辺が重なる長方形同士を連結できます。角だけの接触は連結しません。','疑似コード: rects=[初期長方形]。各嵐で境界Aの前後に分割し、指定の方向へ±B移動。最後に左右・上下の辺を座標別にsortし、長さ正の重なりだけDSU結合。各成分の面積を足し、昇順サイズと個数を出力。'),
'abc433_d':('連結後の数はAi*10^桁数(Aj)+Ajです。','右側の数を桁数とMで割った余りで数えます。左側の数ごとに、必要な右側の余りを調べます。','疑似コード: cnt[digits(Aj)][Aj%M]を作る。各桁数dと各Aiについてanswer+=cnt[d][(-Ai*10^d)%M]。i=jも含めて出力。'),
'abc434_d':('雲を一つ取り除いて新たに晴れるのは、その雲だけで覆われていたマスです。','二次元いもす法で被覆数と、覆う雲の番号の和を求めます。被覆数1のときは番号の和から唯一の雲が分かります。','疑似コード: 各閉長方形を半開境界へ変換し4隅のcount差分とowner番号差分を更新。二次元累積和後、count0をbaseへ、count1をunique[owner]へ加算。各雲にbase+unique[i]を出力。'),
'abc435_d':('黒い頂点へ到達できる頂点は、その逆向きの辺をたどって探せます。','一度到達可能になった頂点はずっと到達可能です。黒くするクエリから逆グラフを探索し、各頂点は一度だけ追加します。','疑似コード: reversedEdgesを作りreachable=false。1 vで未reachableならvから逆辺の未訪問頂点をBFSしてtrue。2 vはreachable[v]のYes/No。2クエリがなければ出力は空。'),
'abc436_d':('移動もワープも一回の行動なので、最短距離をBFSで求めます。','同じ文字のワープ先を毎回走査すると遅くなります。その文字へ最初に到達したときだけ、全ワープ先を追加します。','疑似コード: letterPositionsを作り始点BFS。隣接非壁を距離+1で追加。文字マスなら同文字位置の未訪問を距離+1で追加してその一覧を空にする。終点距離または-1を出力。')}

TITLES={'abc431_d': 'Robot Customize', 'abc432_d': 'Suddenly, A Tempest', 'abc433_d': '183183', 'abc434_d': 'Clouds', 'abc435_d': 'Reachability Query 2', 'abc436_d': 'Teleport Maze'}
PUBLISHED_SAMPLES={'abc431_d': [{'input': '3\n1 41 59\n2 65 35\n8 97 93\n', 'expected': '217\n'}, {'input': '1\n1 1000000000 1\n', 'expected': '1\n'}, {'input': '2\n1 1000000000 1\n1 1 1000000000\n', 'expected': '2000000000\n'}, {'input': '20\n483 984529882 299667119\n372 428935469 104847758\n467 709733529 102461200\n421 659244277 110859936\n231 786224280 773073478\n351 334234040 193222121\n119 404159408 772024933\n302 519596088 432627257\n433 910226244 337833733\n184 406236461 530198622\n335 465203041 353047747\n418 656273464 114923636\n482 972364803 329650748\n453 748321854 169441643\n105 138464898 587159653\n401 832952051 506021805\n403 810916971 468755944\n231 798801044 749313343\n292 631278033 556088607\n366 567211596 374825770\n', 'expected': '12091388792\n'}], 'abc432_d': [{'input': '2 3 5\nX 2 2\nY -1 1\n', 'expected': '2\n2 13\n'}, {'input': '14 68875272 94216928\nX 1630731 32914676\nX 17164413 -33684569\nX 26798060 5418308\nX 34094469 -45675954\nX 43889566 34125482\nX 56836569 -22217058\nX 64045210 27857939\nY -54561094 11587606\nY 93548188 32214521\nY -77361096 25750481\nY 27724899 1810420\nY 80945185 -7871305\nY 14782822 -2565089\nY 54687684 -22884393\n', 'expected': '8\n21105046168287 22050167303226 33624667752182 223328231190194 441936776830492 1141371400772596 1141702254882183 3464097998105256\n'}], 'abc433_d': [{'input': '2 11\n2 42\n', 'expected': '2\n'}, {'input': '4 7\n2 8 16 183\n', 'expected': '4\n'}, {'input': '5 5\n1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '25\n'}, {'input': '12 13\n80 68 862370 82217 8 56 5 168 672624 6 286057 11864\n', 'expected': '10\n'}], 'abc434_d': [{'input': '5\n2 4 1 4\n3 3 3 5\n1 3 4 6\n4 5 3 5\n5 5 4 6\n', 'expected': '3999983\n3999976\n3999982\n3999978\n3999977\n'}], 'abc435_d': [{'input': '5 6\n1 2\n2 3\n3 1\n4 5\n1 4\n2 5\n5\n1 3\n2 1\n2 4\n1 5\n2 4\n', 'expected': 'Yes\nNo\nYes\n'}], 'abc436_d': [{'input': '3 4\n..a.\n####\nba#b\n', 'expected': '5\n'}, {'input': '3 4\n..a.\n####\nb.#b\n', 'expected': '-1\n'}, {'input': '4 4\nxxxx\nxxxx\nxxxx\nxxxx\n', 'expected': '1\n'}, {'input': '7 11\nu..#y..#...\nk..#.z.#.k.\niju#...#x..\n###########\n..x#.t.#..n\nabc#y..#...\n..z#..t#.y.\n', 'expected': '12\n'}]}
SAMPLE_COUNTS={'abc431_d': 4, 'abc432_d': 2, 'abc433_d': 4, 'abc434_d': 1, 'abc435_d': 1, 'abc436_d': 4}
