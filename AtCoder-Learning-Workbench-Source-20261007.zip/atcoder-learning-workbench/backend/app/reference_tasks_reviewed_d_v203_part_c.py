"""Private official D455..460 domains and independently structured checks."""
from __future__ import annotations
from array import array
from collections import Counter
from itertools import groupby
from typing import cast
import random,re
TASKS=tuple(f'abc{x}_d' for x in range(455,461))
CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc459_d':'semantic'};CHECKER_IDS={'abc459_d':'abc459_d'}
Case=dict[str,str];Data=tuple[object,...];MOD=998244353
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

class PileForest:
 """Oriented link-cut forest: represented parent is the card directly below."""
 def __init__(self,n:int)->None:
  self.left=[0]*(n+1);self.right=[0]*(n+1);self.parent=[0]*(n+1);self.size=[1]*(n+1);self.size[0]=0
 def update(self,x:int)->None:self.size[x]=1+self.size[self.left[x]]+self.size[self.right[x]]
 def aux_root(self,x:int)->bool:
  p=self.parent[x];return p==0 or (self.left[p]!=x and self.right[p]!=x)
 def rotate(self,x:int)->None:
  p=self.parent[x];g=self.parent[p]
  if not self.aux_root(p):
   if self.left[g]==p:self.left[g]=x
   else:self.right[g]=x
  self.parent[x]=g
  if self.left[p]==x:
   b=self.right[x];self.left[p]=b;self.right[x]=p
  else:
   b=self.left[x];self.right[p]=b;self.left[x]=p
  if b:self.parent[b]=p
  self.parent[p]=x;self.update(p);self.update(x)
 def splay(self,x:int)->None:
  while not self.aux_root(x):
   p=self.parent[x];g=self.parent[p]
   if not self.aux_root(p):self.rotate(p if (self.left[p]==x)==(self.left[g]==p) else x)
   self.rotate(x)
 def access(self,x:int)->None:
  v=x;last=0
  while v:
   self.splay(v);self.right[v]=last;self.update(v);last=v;v=self.parent[v]
  self.splay(x)
 def root(self,x:int)->int:
  self.access(x)
  while self.left[x]:x=self.left[x]
  self.splay(x);return x
 def cut(self,x:int)->None:
  self.access(x);ancestors=self.left[x];self.left[x]=0
  if ancestors:self.parent[ancestors]=0
  self.update(x)
 def attach(self,x:int,p:int)->None:self.parent[x]=p

def pile_domain(n:int,queries:tuple[tuple[int,...],...])->tuple[PileForest,list[int]]:
 forest=PileForest(n);above=[0]*(n+1);below=[0]*(n+1)
 for c,p in queries:
  require(1<=c<=n and 1<=p<=n and above[p]==0,'card/top')
  require(forest.root(c)!=forest.root(p),'different piles')
  old=below[c]
  if old:above[old]=0
  below[c]=p;above[p]=c;forest.cut(c);forest.attach(c,p)
 return forest,above

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc455_d':
  n,q=ints(r[0],2);require(1<=n<=300000 and 1<=q<=300000 and len(r)==q+1,'N/Q/rows');queries=tuple(ints(row,2) for row in r[1:]);f,above=pile_domain(n,queries);return n,queries,f,above
 if pid=='abc456_d':
  require(len(r)==1 and re.fullmatch('[abc]{1,300000}',r[0]) is not None,'S');return (r[0],)
 if pid=='abc457_d':
  require(len(r)==2,'rows');n,k=ints(r[0],2);a=ints(r[1],n);require(1<=n<=200000 and 1<=k<=10**18 and all(1<=x<=10**18 for x in a),'N/K/A');return a,k
 if pid=='abc458_d':
  require(len(r)>=3,'rows');x=ints(r[0],1)[0];q=ints(r[1],1)[0];require(1<=x<=10**9 and 1<=q<=200000 and len(r)==q+2,'X/Q/rows');pairs=tuple(ints(row,2) for row in r[2:]);require(all(1<=v<=10**9 for pair in pairs for v in pair),'values');return x,pairs
 if pid=='abc459_d':
  t=ints(r[0],1)[0];require(1<=t<=300000 and len(r)==t+1 and sum(map(len,r[1:]))<=10**6 and all(re.fullmatch('[a-z]{1,1000000}',s) is not None for s in r[1:]),'T/S/total');return (tuple(r[1:]),)
 h,w=ints(r[0],2);require(h>=1 and w>=1 and h*w<=10**6 and len(r)==h+1 and all(re.fullmatch('[.#]{'+str(w)+'}',s) is not None for s in r[1:]),'grid');return h,w,tuple(r[1:])

def pile_path_counts(n:int,forest:PileForest,above:list[int])->list[int]:
 answer=[0]*n
 for top in range(1,n+1):
  if above[top]==0:
   root=forest.root(top);forest.access(top);answer[root-1]=forest.size[top]
 return answer

Matrix=tuple[tuple[int,...],...]
def matrix_multiply(a:Matrix,b:Matrix)->Matrix:
 return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(4))%MOD for j in range(4)) for i in range(4))
def subsequence_matrix_product(s:str)->int:
 # Independent balanced product of run-weighted affine transformations.
 stack:list[tuple[int,Matrix]]=[]
 for char,group in groupby(s):
  length=sum(1 for _ in group);c=ord(char)-97;rows=[[int(i==j) for j in range(4)] for i in range(4)]
  rows[c]=[1 if j==c else length for j in range(4)];matrix=tuple(tuple(row) for row in rows);level=0
  while stack and stack[-1][0]==level:
   _,prior=stack.pop();matrix=matrix_multiply(matrix,prior);level+=1
  stack.append((level,matrix))
 result:Matrix=tuple(tuple(int(i==j) for j in range(4)) for i in range(4))
 for _,matrix in stack:result=matrix_multiply(matrix,result)
 return sum(result[i][3] for i in range(3))%MOD

def raise_union_rank(a:tuple[int,...],k:int)->int:
 # Greedily removing the least head selects K terms from the union of
 # progressions A_i+i*j; the next (K+1)-th multiset term is the optimum.
 low=min(a);high=a[0]+k
 while low<high:
  mid=(low+high)//2;count=0
  for index,start in enumerate(a,1):
   if start<=mid:count+=(mid-start)//index+1
   if count>k:break
  if count>k:high=mid
  else:low=mid+1
 return low

def median_offline_counts(x:int,pairs:tuple[tuple[int,...],...])->list[int]:
 values=sorted({x}|{v for pair in pairs for v in pair});indices={v:i+1 for i,v in enumerate(values)};n=len(values);tree=[0]*(n+1)
 def add(v:int)->None:
  i=indices[v]
  while i<=n:tree[i]+=1;i+=i&-i
 def kth(k:int)->int:
  i=0;step=1<<(n.bit_length()-1)
  while step:
   j=i+step
   if j<=n and tree[j]<k:i=j;k-=tree[j]
   step>>=1
  return values[i]
 add(x);answer=[]
 for number,(a,b) in enumerate(pairs,1):add(a);add(b);answer.append(kth(number+1))
 return answer

def arrange_even_slots(s:str)->str|None:
 counts=Counter(s);n=len(s)
 if max(counts.values())>(n+1)//2:return None
 answer=['']*n;position=0
 for char,count in sorted(counts.items(),key=lambda item:(-item[1],item[0])):
  for _ in range(count):
   if position>=n:position=1
   answer[position]=char;position+=2
 return ''.join(answer)

def distance_transform(h:int,w:int,seeds:str,char:str)->array[int]:
 d=array('i',(0 if x==char else h+w for x in seeds))
 for r in range(h):
  for c in range(w):
   i=r*w+c;best=d[i]
   if c:best=min(best,d[i-1]+1)
   if r:
    best=min(best,d[i-w]+1)
    if c:best=min(best,d[i-w-1]+1)
    if c+1<w:best=min(best,d[i-w+1]+1)
   d[i]=best
 for r in range(h-1,-1,-1):
  for c in range(w-1,-1,-1):
   i=r*w+c;best=d[i]
   if c+1<w:best=min(best,d[i+1]+1)
   if r+1<h:
    best=min(best,d[i+w]+1)
    if c:best=min(best,d[i+w-1]+1)
    if c+1<w:best=min(best,d[i+w+1]+1)
   d[i]=best
 return d

def repaint_chessboard_transform(h:int,w:int,grid:tuple[str,...])->str:
 s=''.join(grid)
 if '#' not in s or '.' not in s:return ('.'*w+'\n')*h
 white=distance_transform(h,w,s,'.');black=distance_transform(h,w,s,'#')
 answer=['#' if ((white[i] if c=='#' else black[i])%2)==(c=='#') else '.' for i,c in enumerate(s)]
 return ''.join(''.join(answer[r*w:(r+1)*w])+'\n' for r in range(h))

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc455_d':return line(pile_path_counts(cast(int,d[0]),cast(PileForest,d[2]),cast(list[int],d[3])))
 if pid=='abc456_d':return str(subsequence_matrix_product(cast(str,d[0])))+'\n'
 if pid=='abc457_d':return str(raise_union_rank(*cast(tuple[tuple[int,...],int],d)))+'\n'
 if pid=='abc458_d':return ''.join(str(v)+'\n' for v in median_offline_counts(*cast(tuple[int,tuple[tuple[int,...],...]],d)))
 if pid=='abc459_d':return ''.join('No\n' if (answer:=arrange_even_slots(s)) is None else 'Yes\n'+answer+'\n' for s in cast(tuple[str,...],d[0]))
 return repaint_chessboard_transform(*cast(tuple[int,int,tuple[str,...]],d))

def adjacent_distinct_check(strings:tuple[str,...],actual:str)->bool:
 rows=actual.removesuffix('\n').split('\n');at=0
 for s in strings:
  if at>=len(rows):return False
  label=rows[at];at+=1;possible=max(Counter(s).values())<=(len(s)+1)//2
  if label=='No':
   if possible:return False
  elif label=='Yes':
   if not possible or at>=len(rows):return False
   answer=rows[at];at+=1
   if Counter(answer)!=Counter(s) or any(a==b for a,b in zip(answer,answer[1:])):return False
  else:return False
 return at==len(rows)
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  if pid=='abc459_d':return adjacent_distinct_check(cast(tuple[str,...],validate(pid,raw)[0]),actual)
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc455_d':
  def piles(n:int,qs:list[tuple[int,int]])->str:return line([n,len(qs)])+''.join(line(v) for v in qs)
  raws=[piles(2,[(1,2)]),piles(3,[(2,1),(2,3),(2,1)]),piles(4,[(2,1),(3,2),(2,4),(3,1)])]
  while len(raws)<16:
   n=rng.randint(3,16);state=[[i] for i in range(1,n+1)];qs=[]
   for _ in range(rng.randint(1,45)):
    choices=[(i,j,k) for i,src in enumerate(state) if src for j,dst in enumerate(state) if dst and i!=j for k in range(len(src)) if k or sum(bool(p) for p in state)>2]
    i,j,k=rng.choice(choices);c,p=state[i][k],state[j][-1];qs.append((c,p));state[j]+=state[i][k:];state[i]=state[i][:k]
   raw=piles(n,qs)
   if raw not in raws:raws.append(raw)
  raws.append(piles(300000,[(3,1 if i%2==0 else 2) for i in range(300000)]))
  raws.append(piles(300000,[(i,i-1) for i in range(2,300000)]+[(299999,300000),(299998,299999)]))
 elif pid=='abc456_d':
  raws=[s+'\n' for s in ['a','b','c','aa','ab','abc','abbc','aaaaaa','abababab','abcabc','aabbbcccc']]
  while len(raws)<16:
   raw=''.join(rng.choice('abc') for _ in range(rng.randint(5,70)))+'\n'
   if raw not in raws:raws.append(raw)
  raws+=['a'*300000+'\n','abc'*100000+'\n']
 elif pid=='abc457_d':
  def raise_case(a:list[int],k:int)->str:return line([len(a),k])+line(a)
  raws=[raise_case([1],1),raise_case([10**18],10**18),raise_case([1,1],1),raise_case([1,1],2),raise_case([1,2,3],3),raise_case([10,1,10,1],5)]
  while len(raws)<16:
   raw=raise_case([rng.randint(1,1000) for _ in range(rng.randint(2,30))],rng.randint(1,1000))
   if raw not in raws:raws.append(raw)
  raws+=[raise_case([1]*200000,10**18),raise_case([10**18]*200000,10**18)]
 elif pid=='abc458_d':
  def med(x:int,pairs:list[tuple[int,int]])->str:return str(x)+'\n'+str(len(pairs))+'\n'+''.join(line(v) for v in pairs)
  raws=[med(1,[(1,1)]),med(10**9,[(10**9,10**9)]),med(5,[(2,3),(1,2),(8,9)]),med(1,[(i,i+1) for i in range(2,22,2)])]
  while len(raws)<16:
   raw=med(rng.randint(1,100),[(rng.randint(1,100),rng.randint(1,100)) for _ in range(rng.randint(1,30))])
   if raw not in raws:raws.append(raw)
  raws+=[med(500000000,[(i+1,10**9-i) for i in range(200000)]),med(10**9,[(10**9,10**9)]*200000)]
 elif pid=='abc459_d':
  def strings(ss:list[str])->str:return str(len(ss))+'\n'+'\n'.join(ss)+'\n'
  raws=[strings(['a']),strings(['aa']),strings(['ab']),strings(['aabb']),strings(['aaab']),strings(['aaabb']),strings(['aiiw','doodoo']),strings(['abc','zzzz','abab','baba'])]
  while len(raws)<16:
   raw=strings([''.join(rng.choice('abcd') for _ in range(rng.randint(1,40))) for _ in range(rng.randint(1,10))])
   if raw not in raws:raws.append(raw)
  raws+=[strings(['a'*500000+'b'*500000]),strings(['aabb']*100000+['abc']*200000)]
 else:
  def grid(rows:list[str])->str:return line([len(rows),len(rows[0])])+''.join(s+'\n' for s in rows)
  raws=[grid(['.']),grid(['#']),grid(['#.']),grid(['##.']),grid(['...']),grid(['#..','...','...']),grid(['###','###']),grid(['#.#','.#.'])]
  while len(raws)<16:
   h,w=rng.randint(1,8),rng.randint(1,8);raw=grid([''.join(rng.choice('.#') for _ in range(w)) for _ in range(h)])
   if raw not in raws:raws.append(raw)
  raws+=[grid(['#'+'.'*999999]),grid(['.']+['#']*999999)]
 require(len(raws)==len(set(raws))==18,'18 distinct')
 return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 else 'deterministic_random' if i<16 else 'large_scale'} for i,raw in enumerate(raws)]

REFERENCE_CODE:dict[str,str]={
'abc455_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);q=next(it);above=[0]*(n+1);below=[0]*(n+1)
for _ in range(q):
 c=next(it);p=next(it);old=below[c]
 if old:above[old]=0
 below[c]=p;above[p]=c
answer=[0]*n
for bottom in range(1,n+1):
 if below[bottom]:continue
 v=bottom;count=0
 while v:count+=1;v=above[v]
 answer[bottom-1]=count
print(*answer)
''',
'abc456_d':'''import sys
s=sys.stdin.buffer.readline().strip();mod=998244353;ends=[0,0,0];total=0
for char in s:
 c=char-97;added=(1+total-ends[c])%mod;ends[c]=(ends[c]+added)%mod;total=(total+added)%mod
print(total)
''',
'abc457_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);k=next(it);a=list(it);low=min(a);high=a[0]+k+1
while high-low>1:
 mid=(low+high)//2;needed=0
 for i,start in enumerate(a,1):
  if start<mid:needed+=(mid-start+i-1)//i
  if needed>k:break
 if needed<=k:low=mid
 else:high=mid
print(low)
''',
'abc458_d':'''import sys,heapq
it=iter(map(int,sys.stdin.buffer.read().split()));x=next(it);q=next(it);lower=[-x];upper=[];answer=[]
for _ in range(q):
 for v in (next(it),next(it)):
  if v<=-lower[0]:heapq.heappush(lower,-v)
  else:heapq.heappush(upper,v)
  if len(lower)<len(upper):heapq.heappush(lower,-heapq.heappop(upper))
  if len(lower)>len(upper)+1:heapq.heappush(upper,-heapq.heappop(lower))
 answer.append(str(-lower[0]))
print('\\n'.join(answer))
''',
'abc459_d':'''import sys,heapq
from collections import Counter
r=sys.stdin.buffer.read().split();answer=[]
for raw in r[1:]:
 s=raw.decode();counts=Counter(s)
 if max(counts.values())>(len(s)+1)//2:answer.append('No');continue
 heap=[(-count,char) for char,count in counts.items()];heapq.heapify(heap);held=(0,'');out=[]
 while heap:
  count,char=heapq.heappop(heap);out.append(char)
  if held[0]<0:heapq.heappush(heap,held)
  held=(count+1,char)
 answer.extend(('Yes',''.join(out)))
print('\\n'.join(answer))
''',
'abc460_d':'''import sys
from collections import deque
from array import array
r=sys.stdin.buffer.read().split();h=int(r[0]);w=int(r[1]);s=b''.join(r[2:]);n=h*w
def distances(color):
 d=array('i',[-1])*n;q=deque()
 for i,c in enumerate(s):
  if c==color:d[i]=0;q.append(i)
 while q:
  i=q.popleft();row,col=divmod(i,w);new=d[i]+1
  for dr in (-1,0,1):
   rr=row+dr
   if not 0<=rr<h:continue
   for dc in (-1,0,1):
    cc=col+dc
    if (dr or dc) and 0<=cc<w:
     j=rr*w+cc
     if d[j]<0:d[j]=new;q.append(j)
 return d
if 35 not in s or 46 not in s:out=b'.'*n
else:
 white=distances(46);black=distances(35);out=bytes(35 if ((white[i] if c==35 else black[i])%2)==(c==35) else 46 for i,c in enumerate(s))
sys.stdout.buffer.write(b'\\n'.join(out[i*w:(i+1)*w] for i in range(h))+b'\\n')
'''}
HINTS:dict[str,tuple[str,str,str]]={
'abc455_d':('山ごとに毎回カードを移すと遅くなります。カードの直下と直上の関係だけを更新しましょう。','Cの下との接続を切り、Pの上にCを接続します。Cより上の順序はそのままです。最後に下のカードがないカードから上へ数えます。','疑似コード: above/belowを0で初期化。各(C,P)でold=below[C]、oldがあればabove[old]=0、below[C]=P、above[P]=C。最後にbelow[i]==0の各iからaboveをたどり枚数をanswer[i]へ。全answerを出力。'),
'abc456_d':('末尾の文字がa、b、cである有効な部分列の数をそれぞれ保持しましょう。','新しい文字cを付けられるのは空列と末尾がc以外の列です。元からある列を残し、新しく作れる数を末尾cの数に加えます。','疑似コード: end=[0,0,0],total=0。Sの各cでadded=1+total-end[c]、end[c]+=added、total+=added。各値を998244353で剰余にし、最後のtotalを出力。'),
'abc457_d':('最小値をある値以上にできるかを調べると、答えを二分探索できます。','目標mに足りないA_iには、ceil((m-A_i)/i)回の操作が必要です。全体の必要回数がK以下なら実現できます。','疑似コード: low=min(A),high=A_1+K+1。while high-low>1: m=(low+high)//2、need=sum(max(0,ceil((m-A_i)/i)))。need<=Kならlow=m、そうでなければhigh=m。lowを出力。'),
'abc458_d':('追加のたびに全体を並べ替えず、中央値以下とそれより大きい数を分けて持ちましょう。','小さい側を最大ヒープ、大きい側を最小ヒープにします。小さい側の個数を大きい側と同じか一つ多くすると、その最大値が中央値です。','疑似コード: lowerに-X、upper空。各A,Bをlowerの最大値と比較して対応するヒープへ挿入。要素を移してlen(lower)=len(upper)または+1に調整。2個の追加後に-lower[0]を出力。'),
'abc459_d':('最も多い文字が他の文字の隙間に入るかを考えましょう。個数がceil(|S|/2)を超えると不可能です。','残り個数が多い文字から選び、直前に使った文字を一時的にヒープの外に置きます。これで同じ文字を連続で選ばずに構成できます。','疑似コード: 頻度最大>ceil(n/2)ならNo。それ以外は頻度の最大ヒープを作り、held=空。while heap: 最大の文字cを取り出して追加、前heldの残りがあれば戻す、今回cの残りをheldへ。Yesと構成列を出力。'),
'abc460_d':('混ざった色の境界では二つの色が交互に反転します。この影響が同色の領域へ一マスずつ伝わります。','各マスから初期の異色までの8近傍距離を求めます。初期白は距離が偶数、初期黒は距離が奇数なら、十分大きい偶数回後に黒です。単色は全白になります。','疑似コード: 単色なら全白を出力。それ以外は全白マスを始点とするBFSと全黒マスを始点とするBFSで距離を計算。各iでd=初期の異色までの距離、初期白かつd偶数、または初期黒かつd奇数なら#、それ以外は.。行ごとに出力。')}

TITLES={'abc455_d': 'Card Pile Query', 'abc456_d': 'Not Adjacent 2', 'abc457_d': 'Raise Minimum', 'abc458_d': 'Chalkboard Median', 'abc459_d': 'Adjacent Distinct String', 'abc460_d': 'Repeatedly Repainting'}
PUBLISHED_SAMPLES={'abc455_d': [{'input': '5 4\n1 3\n4 5\n1 4\n4 2\n', 'expected': '0 3 1 0 1\n'}, {'input': '7 8\n3 1\n5 4\n2 5\n5 7\n2 3\n6 2\n3 4\n5 1\n', 'expected': '2 0 0 4 0 0 1\n'}], 'abc456_d': [{'input': 'abbc\n', 'expected': '11\n'}, {'input': 'cabcabcbcaccacbcbcaabacbacaabccacbccbcacbacbacabcacabcaccaaaaabababcbabacaccabbcacbcbcbcababcbcbabca\n', 'expected': '378217423\n'}], 'abc457_d': [{'input': '3 3\n1 2 3\n', 'expected': '3\n'}, {'input': '4 5\n10 1 10 1\n', 'expected': '7\n'}, {'input': '20 457\n8 9 10 9 8 8 4 6 8 1 5 10 2 8 2 6 8 1 6 6\n', 'expected': '132\n'}], 'abc458_d': [{'input': '5\n3\n2 3\n1 2\n8 9\n', 'expected': '3\n2\n3\n'}, {'input': '1\n4\n2 3\n4 5\n6 7\n8 9\n', 'expected': '2\n3\n4\n5\n'}, {'input': '278117031\n7\n167642909 517897721\n148434323 567739597\n319926999 481642530\n659199879 252516557\n49913403 798318034\n89701408 892537201\n199166668 742285869\n', 'expected': '278117031\n278117031\n319926999\n319926999\n319926999\n319926999\n319926999\n'}], 'abc459_d': [{'input': '3\naiiw\ndoodoo\naabbababcacababaaba\n', 'expected': 'Yes\niwai\nNo\nYes\nababacabababacababa\n'}], 'abc460_d': [{'input': '3 4\n#.#.\n.#..\n#...\n', 'expected': '#.#.\n.#..\n#..#\n'}, {'input': '3 3\n###\n###\n###\n', 'expected': '...\n...\n...\n'}, {'input': '5 7\n.#.....\n.......\n..#....\n.......\n....#..\n', 'expected': '.#.##.#\n....#..\n#.#.###\n#.....#\n###.#.#\n'}]}
SAMPLE_COUNTS={p:len(v) for p,v in PUBLISHED_SAMPLES.items()}
