"""Exact reviewed ABC084--089 D with canonical ABC/ARC identities."""
from __future__ import annotations
from array import array
from bisect import bisect_left,bisect_right
from functools import lru_cache
from heapq import heappop,heappush
from math import isqrt
from typing import cast
import random,re
TASKS=('abc084_d','abc085_d','arc089_b','arc090_b','abc088_d','abc089_d')
CONTESTS={p:f'abc{n:03}' for p,n in zip(TASKS,range(84,90))}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
Triple=tuple[int,int,int]
Point=tuple[int,int,str]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc084_d':
        q=ints(rows[0],1)[0];require(1<=q<=100000 and len(rows)==q+1,'prime query shape');queries=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=b<=100000 and a%2==b%2==1 for a,b in queries),'odd intervals');return (queries,)
    if pid=='abc085_d':
        n,h=ints(rows[0],2);require(1<=n<=100000 and 1<=h<=10**9 and len(rows)==n+1,'weapons shape');items=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=b<=10**9 for a,b in items),'weapon bounds');return h,items
    if pid=='arc089_b':
        n,k=ints(rows[0],2);require(1<=n<=100000 and 1<=k<=1000 and len(rows)==n+1,'checkerboard shape');points=[]
        for row in rows[1:]:
            fields=row.split(' ');require(len(fields)==3 and fields[2] in ('B','W'),'point color');x,y=ints(' '.join(fields[:2]),2);require(0<=x<=10**9 and 0<=y<=10**9,'coordinates');points.append((x,y,fields[2]))
        require(len({(x,y) for x,y,c in points})==n,'distinct coordinates');return k,tuple(points)
    if pid=='arc090_b':
        n,m=ints(rows[0],2);require(1<=n<=100000 and 0<=m<=200000 and len(rows)==m+1,'difference shape');edges=tuple(cast(Triple,ints(row,3)) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b and 0<=d<=10000 for a,b,d in edges),'difference bounds');require(len({(min(a,b),max(a,b)) for a,b,d in edges})==m,'unordered duplicate information');return n,edges
    if pid=='abc088_d':
        h,w=ints(rows[0],2);board=tuple(rows[1:]);require(2<=h<=50 and 2<=w<=50 and len(board)==h and all(len(row)==w and set(row)<=set('.#') for row in board),'grid shape');require(board[0][0]==board[-1][-1]=='.','white endpoints');return (board,)
    h,w,d=ints(rows[0],3);require(1<=h<=300 and 1<=w<=300 and 1<=d<=h*w and len(rows)>=h+2,'permutation grid shape');board=tuple(ints(row,w) for row in rows[1:h+1]);require({v for row in board for v in row}==set(range(1,h*w+1)),'permutation');q=ints(rows[h+1],1)[0];require(1<=q<=100000 and len(rows)==h+q+2,'skill queries');queries=tuple(cast(Pair,ints(row,2)) for row in rows[h+2:]);require(all(1<=a<=b<=h*w and (b-a)%d==0 for a,b in queries),'skill residue');return d,board,queries

@lru_cache(maxsize=100000)
def trial_prime(n:int)->bool:
    if n<2:return False
    return all(n%j for j in range(2,isqrt(n)+1))
@lru_cache(maxsize=1)
def like_primes()->tuple[int,...]:return tuple(n for n in range(3,100001,2) if trial_prime(n) and trial_prime((n+1)//2))

def weapon_turns(h:int,items:tuple[Pair,...])->int:
    swing=max(a for a,b in items);gains=sorted((b-swing for a,b in items if b>swing),reverse=True);prefix=[0]
    for value in gains:prefix.append(prefix[-1]+value)
    # Maximal damage possible in t attacks, with all throws rearranged after
    # any swings to retain the best sword until it is last needed.
    low=1;high=(h+swing-1)//swing
    while low<high:
        mid=(low+high)//2
        if mid*swing+prefix[min(mid,len(gains))]>=h:high=mid
        else:low=mid+1
    return low

def checkerboard_max(k:int,points:tuple[Point,...])->int:
    side=k+1;difference=array('i',[0])*(side*side)
    def rectangle(x1:int,x2:int,y1:int,y2:int)->None:
        if x1>=x2 or y1>=y2:return
        difference[x1*side+y1]+=1;difference[x2*side+y1]-=1;difference[x1*side+y2]-=1;difference[x2*side+y2]+=1
    for x,y,color in points:
        x%=2*k;y=(y+(k if color=='W' else 0))%(2*k)
        x0=(0,x+1) if x<k else (x-k+1,k);x1=(x+1,k) if x<k else (0,x-k+1)
        y0=(0,y+1) if y<k else (y-k+1,k);y1=(y+1,k) if y<k else (0,y-k+1)
        rectangle(*x0,*y0);rectangle(*x1,*y1)
    best=0;n=len(points)
    for x in range(k):
        running=0;base=x*side;previous=base-side
        for y in range(k):
            running+=difference[base+y];score=running+(difference[previous+y] if x else 0);difference[base+y]=score;best=max(best,score,n-score)
    return best

def differences_consistent(n:int,edges:tuple[Triple,...])->bool:
    parent=list(range(n));size=[1]*n;delta=[0]*n
    def find(j:int)->int:
        path=[];root=j
        while parent[root]!=root:path.append(root);root=parent[root]
        offset=0
        for vertex in reversed(path):offset+=delta[vertex];parent[vertex]=root;delta[vertex]=offset
        return root
    for a,b,d in edges:
        a-=1;b-=1;left=find(a);right=find(b);offset=d+delta[a]-delta[b]
        if left==right:
            if offset:return False
        elif size[left]>=size[right]:parent[right]=left;delta[right]=offset;size[left]+=size[right]
        else:parent[left]=right;delta[left]=-offset;size[right]+=size[left]
    bounds:dict[int,Pair]={}
    for j in range(n):
        root=find(j);value=delta[j];low,high=bounds.get(root,(value,value));bounds[root]=(min(low,value),max(high,value))
    return all(high-low<=10**9 for low,high in bounds.values())

def repaint_score(board:tuple[str,...])->int:
    h=len(board);w=len(board[0]);distance=[10**9]*(h*w);distance[0]=1;heap=[(1,0)]
    while heap:
        cost,node=heappop(heap)
        if cost!=distance[node]:continue
        if node==h*w-1:return sum(row.count('.') for row in board)-cost
        r,c=divmod(node,w)
        for rr,cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
            if 0<=rr<h and 0<=cc<w and board[rr][cc]=='.':
                nxt=rr*w+cc
                if cost+1<distance[nxt]:distance[nxt]=cost+1;heappush(heap,(cost+1,nxt))
    return -1

def skill_queries(d:int,board:tuple[tuple[int,...],...],queries:tuple[Pair,...])->list[int]:
    n=sum(map(len,board));positions=[(0,0)]*(n+1)
    for r,row in enumerate(board):
        for c,value in enumerate(row):positions[value]=(r,c)
    indices=[0]*(n+1);weights=[]
    for residue in range(1,d+1):
        previous=None
        for value in range(residue,n+1,d):
            indices[value]=len(weights);r,c=positions[value];weights.append(0 if previous is None else abs(r-previous[0])+abs(c-previous[1]));previous=(r,c)
    size=1<<n.bit_length();tree=[0]*(2*size);tree[size:size+n]=weights
    for j in range(size-1,0,-1):tree[j]=tree[2*j]+tree[2*j+1]
    def total(left:int,right:int)->int:
        left+=size;right+=size;answer=0
        while left<right:
            if left&1:answer+=tree[left];left+=1
            if right&1:right-=1;answer+=tree[right]
            left//=2;right//=2
        return answer
    return [total(indices[a]+1,indices[b]+1) for a,b in queries]

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc084_d':primes=like_primes();return '\n'.join(str(bisect_right(primes,b)-bisect_left(primes,a)) for a,b in cast(tuple[Pair,...],data[0]))
    if pid=='abc085_d':return str(weapon_turns(*cast(tuple[int,tuple[Pair,...]],data)))
    if pid=='arc089_b':return str(checkerboard_max(*cast(tuple[int,tuple[Point,...]],data)))
    if pid=='arc090_b':return 'Yes' if differences_consistent(*cast(tuple[int,tuple[Triple,...]],data)) else 'No'
    if pid=='abc088_d':return str(repaint_score(cast(tuple[str,...],data[0])))
    return '\n'.join(map(str,skill_queries(*cast(tuple[int,tuple[tuple[int,...],...],tuple[Pair,...]],data))))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc084_d':"q=int(input());prime=[True]*100001;prime[0]=prime[1]=False\nfor p in range(2,317):\n if prime[p]:\n  for j in range(p*p,100001,p):prime[j]=False\ncount=[0]*100001\nfor j in range(1,100001):count[j]=count[j-1]+int(j%2 and prime[j] and prime[(j+1)//2])\nfor _ in range(q):a,b=map(int,input().split());print(count[b]-count[a-1])\n",
'abc085_d':"n,h=map(int,input().split());items=[tuple(map(int,input().split())) for _ in range(n)];a=max(x for x,y in items);throws=sorted((y for x,y in items if y>a),reverse=True);turns=0\nfor damage in throws:\n h-=damage;turns+=1\n if h<=0:break\nif h>0:turns+=(h+a-1)//a\nprint(turns)\n",
'arc089_b':"from array import array\nn,k=map(int,input().split());period=2*k;side=period+1;p=array('i',[0])*(side*side)\nfor _ in range(n):\n x,y,c=input().split();x=int(x)%period;y=(int(y)+(k if c=='W' else 0))%period;p[(x+1)*side+y+1]+=1\nfor x in range(1,side):\n total=0;row=x*side;previous=row-side\n for y in range(1,side):total+=p[row+y];p[row+y]=total+p[previous+y]\ndef rect(x,y,xx,yy):return p[xx*side+yy]-p[x*side+yy]-p[xx*side+y]+p[x*side+y]\nrows=[rect(x,0,x+k,period) for x in range(k)];cols=[rect(0,y,period,y+k) for y in range(k)];answer=0\nfor x in range(k):\n for y in range(k):\n  score=n-rows[x]-cols[y]+2*rect(x,y,x+k,y+k);answer=max(answer,score,n-score)\nprint(answer)\n",
'arc090_b':"n,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):a,b,d=map(int,input().split());g[a-1].append((b-1,d));g[b-1].append((a-1,-d))\npositions=[None]*n;ok=True\nfor start in range(n):\n if positions[start] is not None:continue\n positions[start]=0;stack=[start];lo=hi=0\n while stack:\n  j=stack.pop()\n  for v,d in g[j]:\n   expected=positions[j]+d\n   if positions[v] is None:positions[v]=expected;lo=min(lo,expected);hi=max(hi,expected);stack.append(v)\n   elif positions[v]!=expected:ok=False\n if hi-lo>1000000000:ok=False\nprint('Yes' if ok else 'No')\n",
'abc088_d':"from collections import deque\nh,w=map(int,input().split());s=[input() for _ in range(h)];d=[[-1]*w for _ in range(h)];d[0][0]=1;q=deque([(0,0)])\nwhile q:\n r,c=q.popleft()\n for y,x in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):\n  if 0<=y<h and 0<=x<w and s[y][x]=='.' and d[y][x]<0:d[y][x]=d[r][c]+1;q.append((y,x))\nprint(-1 if d[-1][-1]<0 else sum(row.count('.') for row in s)-d[-1][-1])\n",
'abc089_d':"h,w,d=map(int,input().split());p=[(0,0)]*(h*w+1)\nfor r in range(h):\n for c,v in enumerate(map(int,input().split())):p[v]=(r,c)\ncost=[0]*(h*w+1)\nfor v in range(d+1,h*w+1):a,b=p[v];x,y=p[v-d];cost[v]=cost[v-d]+abs(a-x)+abs(b-y)\nq=int(input())\nfor _ in range(q):a,b=map(int,input().split());print(cost[b]-cost[a])\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18300+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc084_d':
        def queries(a:list[Pair])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[queries([(1,1)]),queries([(3,3)]),queries([(5,5)]),queries([(7,7)])]
        raws += [queries([(1,2*j+1),(2*j+1,2*j+1),(3,2*j+3)]) for j in range(4,17)]
        raws.append(queries([(1,99999)]*100000))
    elif pid=='abc085_d':
        def swords(h:int,a:list[Pair])->str:return f'{len(a)} {h}\n'+''.join(line(v) for v in a)
        raws=[swords(1,[(1,1)]),swords(10**9,[(1,1)]),swords(10**9,[(1,10**9)]),swords(10,[(3,5)])]
        for n in range(2,14):
            items=[]
            for _ in range(n):a=rng.randint(1,100);items.append((a,rng.randint(a,1000)))
            raws.append(swords(rng.randint(1,10000),items))
        raws += [swords(10**9,[(1,1)]*100000),swords(10**9,[(10**9,10**9)]*100000)]
    elif pid=='arc089_b':
        def points(k:int,p:list[Point])->str:return f'{len(p)} {k}\n'+''.join(f'{x} {y} {c}\n' for x,y,c in p)
        raws=[points(1,[(0,0,'B')]),points(1,[(0,0,'W')]),points(1,[(0,0,'B'),(2,0,'W')]),points(2,[(0,0,'B'),(1,1,'W'),(2,2,'B')])]
        for k in range(2,14):coords=rng.sample([(x,y) for x in range(2*k+1) for y in range(2*k+1)],k+4);raws.append(points(k,[(x,y,rng.choice('BW')) for x,y in coords]))
        raws += [points(1000,[(j*2000,10**9,'B') for j in range(100000)]),points(1000,[(10**9-j,10**9-j,'B' if j%2 else 'W') for j in range(100000)])]
    elif pid=='arc090_b':
        def info(n:int,e:list[Triple])->str:return f'{n} {len(e)}\n'+''.join(line(v) for v in e)
        raws=[info(1,[]),info(2,[]),info(2,[(1,2,0)]),info(3,[(1,2,1),(2,3,1),(1,3,3)])]
        for n in range(3,15):positions=sorted(rng.sample(range(100),n));raws.append(info(n,[(a,b,positions[b-1]-positions[a-1]) for a in range(1,n+1) for b in range(a+1,n+1) if b==a+1 or rng.randrange(3)==0]))
        raws.append(info(100000,[(j,j+1,10000) for j in range(1,100000)]))
        edges=[(j,j+1,1) for j in range(1,100000)]+[(j,j+2,2) for j in range(1,99999)]+[(1,4,3),(2,5,3),(3,6,3)];raws.append(info(100000,edges))
    elif pid=='abc088_d':
        def grid(s:list[str])->str:return f'{len(s)} {len(s[0])}\n'+'\n'.join(s)+'\n'
        raws=[grid(['..','..']),grid(['.#','#.']),grid(['..','#.']),grid(['.#.','...','.#.'])]
        for n in range(3,15):s=[''.join(rng.choice('...#') for _ in range(n+1)) for _ in range(n)];s[0]='.'+s[0][1:];s[-1]=s[-1][:-1]+'.';raws.append(grid(s))
        s=['#'*50 for _ in range(50)];s[0]='.'*50
        for r in range(1,50):s[r]='#'*49+'.'
        raws += [grid(s),grid(['.'*50]*50)]
    else:
        def skill(h:int,w:int,d:int,a:list[int],q:list[Pair])->str:return f'{h} {w} {d}\n'+''.join(line(a[r*w:(r+1)*w]) for r in range(h))+f'{len(q)}\n'+''.join(line(v) for v in q)
        raws=[skill(1,1,1,[1],[(1,1)]),skill(1,2,1,[2,1],[(1,2)]),skill(2,1,2,[1,2],[(1,1),(2,2)]),skill(2,2,2,[1,4,2,3],[(1,3),(2,4)])]
        # Build each random instance separately to retain independent residues.
        for n in range(3,15):
            h=n;w=n+1;d=rng.randint(1,h*w);a=list(range(1,h*w+1));rng.shuffle(a);q=[]
            for _ in range(n):l=rng.randint(1,h*w);r=l+d*rng.randint(0,(h*w-l)//d);q.append((l,r))
            raws.append(skill(h,w,d,a,q))
        a=list(range(1,90001));raws += [skill(300,300,90000,a,[(90000,90000)]*100000),skill(300,300,1,a,[(1,90000)]*100000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc084_d':('2017に似た数を上限まで前計算します。','素数表を作り、奇数xでxと(x+1)/2が素数なら1とします。累積和なら区間の個数を定数時間で求められます。','疑似コード: sieveでprimeを作る; prefix[x]=prefix[x-1]+isLike(x); 各(l,r)でprefix[r]-prefix[l-1]を出力。'),
'abc085_d':('繰り返し振る刀はa_iが最大のものだけを考えます。','その最大aより大きいbを降順に投げ、残った体力を振る攻撃で処理します。振る攻撃は必要なら投げる前に行えます。','疑似コード: A=max(a); b>Aを降順sort; Hが正の間投げて減算; 残りが正ならceil(H/A)回を加算して出力。'),
'arc089_b':('周期は縦横2Kです。白を希望する点はKだけずらすと黒希望に統一できます。','座標を2Kで剰余化して2次元累積和を作ります。K×Kの黒い区画の開始位置を全て試します。','疑似コード: W点はy+=Kして周期化; 2Dprefix構築; 各phase(x,y)で黒区画と対角区画の点数を矩形和で数える; 反転N-countも含め最大を出力。'),
'arc090_b':('各連結成分で1人の位置を0と仮定して構いません。','情報を正負の距離を持つ辺にし、未訪問の位置を決めながら既訪問との矛盾を調べます。','疑似コード: L→RにD、R→Lに-Dの辺; 各成分DFSでpotentialを設定; 既存値が期待値と違えばNo、全一致なら成分を平行移動してYes。'),
'abc088_d':('最短経路に含まれない白マスを全て黒にできます。','BFSで両端を含む最短経路のマス数を求め、元の白マス数から引きます。到達不能なら-1です。','疑似コード: BFSでdistance[0][0]=1; .の未訪問隣接へ+1; goal未訪問なら-1、他はwhiteCount-distance[goal]。'),
'abc089_d':('Dだけ増える整数を1つの列として扱います。','各値の座標を求め、同じD剰余の移動費用を累積すると各質問を差分で答えられます。','疑似コード: pos[value]=(row,col); v>Dでcost[v]=cost[v-D]+Manhattan(pos[v],pos[v-D]); 各(L,R)でcost[R]-cost[L]を出力。')}

TITLES={'abc084_d': '2017-like Number', 'abc085_d': 'Katana Thrower', 'arc089_b': 'Checker', 'arc090_b': 'People on a Line', 'abc088_d': 'Grid Repainting', 'abc089_d': 'Practical Skill Test'}
PUBLISHED_SAMPLES={'abc084_d': [{'input': '1\n3 7\n', 'expected': '2\n'}, {'input': '4\n13 13\n7 11\n7 11\n2017 2017\n', 'expected': '1\n0\n0\n1\n'}, {'input': '6\n1 53\n13 91\n37 55\n19 51\n73 91\n13 49\n', 'expected': '4\n4\n1\n1\n1\n2\n'}], 'abc085_d': [{'input': '1 10\n3 5\n', 'expected': '3\n'}, {'input': '2 10\n3 5\n2 6\n', 'expected': '2\n'}, {'input': '4 1000000000\n1 1\n1 10000000\n1 30000000\n1 99999999\n', 'expected': '860000004\n'}, {'input': '5 500\n35 44\n28 83\n46 62\n31 79\n40 43\n', 'expected': '9\n'}], 'arc089_b': [{'input': '4 3\n0 1 W\n1 2 W\n5 3 B\n5 4 B\n', 'expected': '4\n'}, {'input': '2 1000\n0 0 B\n0 1 W\n', 'expected': '2\n'}, {'input': '6 2\n1 2 B\n2 1 W\n2 2 B\n1 0 B\n0 6 W\n4 5 W\n', 'expected': '4\n'}], 'arc090_b': [{'input': '3 3\n1 2 1\n2 3 1\n1 3 2\n', 'expected': 'Yes\n'}, {'input': '3 3\n1 2 1\n2 3 1\n1 3 5\n', 'expected': 'No\n'}, {'input': '4 3\n2 1 1\n2 3 5\n3 4 2\n', 'expected': 'Yes\n'}, {'input': '10 3\n8 7 100\n7 9 100\n9 8 100\n', 'expected': 'No\n'}, {'input': '100 0\n', 'expected': 'Yes\n'}], 'abc088_d': [{'input': '3 3\n..#\n#..\n...\n', 'expected': '2\n'}, {'input': '10 37\n.....................................\n...#...####...####..###...###...###..\n..#.#..#...#.##....#...#.#...#.#...#.\n..#.#..#...#.#.....#...#.#...#.#...#.\n.#...#.#..##.#.....#...#.#.###.#.###.\n.#####.####..#.....#...#..##....##...\n.#...#.#...#.#.....#...#.#...#.#...#.\n.#...#.#...#.##....#...#.#...#.#...#.\n.#...#.####...####..###...###...###..\n.....................................\n', 'expected': '209\n'}], 'abc089_d': [{'input': '3 3 2\n1 4 3\n2 5 7\n8 9 6\n1\n4 8\n', 'expected': '5\n'}, {'input': '4 2 3\n3 7\n1 4\n5 2\n6 8\n2\n2 2\n2 2\n', 'expected': '0\n0\n'}, {'input': '5 5 4\n13 25 7 15 17\n16 22 20 2 9\n14 11 12 1 19\n10 6 23 8 18\n3 21 5 24 4\n3\n13 13\n2 10\n13 13\n', 'expected': '0\n5\n0\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
