"""Private ABC289..294 D, preserving existing ABC295 D outside this scope."""
from __future__ import annotations
from typing import cast
import math,random,re
TASKS=tuple(f'abc{n}_d' for n in range(289,295));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
MOD=998244353
Case=dict[str,str]
Data=tuple[object,...]
Matrix=tuple[int,int,int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc289_d':
        require(len(rows)==5,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);m=ints(rows[2],1)[0];b=ints(rows[3],m);x=ints(rows[4],1)[0];require(1<=n<=10 and 1<=m<=100000 and 1<=a[0] and a[-1]<=100000 and all(u<v for u,v in zip(a,a[1:])) and 1<=b[0] and b[-1]<x<=100000 and all(u<v for u,v in zip(b,b[1:])),'domain');return a,b,x
    if pid=='abc290_d':
        t=ints(rows[0],1)[0];require(1<=t<=100000 and len(rows)==t+1,'shape');queries=tuple(ints(row,3) for row in rows[1:]);require(all(1<=k<=n<=10**9 and 1<=d<=10**9 for n,d,k in queries),'range');return (queries,)
    if pid=='abc291_d':
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');cards=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<=10**9 and 1<=b<=10**9 for a,b in cards),'range');return (cards,)
    if pid=='abc292_d':
        n,m=ints(rows[0],2);require(1<=n<=200000 and 0<=m<=200000 and len(rows)==m+1,'shape');edges=tuple(ints(row,2) for row in rows[1:]);require(all(1<=u<=v<=n for u,v in edges),'ordered endpoints');return n,edges
    if pid=='abc293_d':
        n,m=ints(rows[0],2);require(1<=n<=200000 and 0<=m<=200000 and len(rows)==m+1,'shape');ties=[];used:set[int]=set()
        for row in rows[1:]:
            match=re.fullmatch(r'([1-9][0-9]*) ([RB]) ([1-9][0-9]*) ([RB])',row);require(match is not None,'tie');assert match is not None;a,c=int(match[1]),int(match[3]);require(1<=a<=n and 1<=c<=n,'rope');u=2*(a-1)+int(match[2]=='B');v=2*(c-1)+int(match[4]=='B');require(u!=v and u not in used and v not in used,'unique endpoints');used.update((u,v));ties.append((u,v))
        return n,tuple(ties)
    n,q=ints(rows[0],2);require(1<=n<=500000 and 2<=q<=500000 and len(rows)==q+1,'shape');queries=tuple(ints(row) for row in rows[1:]);called=0;served:set[int]=set();reports=0
    for row in queries:
        kind=row[0];require(kind in (1,2,3) and len(row)==(2 if kind==2 else 1),'query')
        if kind==1:called+=1;require(called<=n,'all already called')
        elif kind==2:x=row[1];require(1<=x<=called and x not in served,'called unserved');served.add(x)
        else:require(called>len(served),'pending nonempty');reports+=1
    require(reports>=1,'at least one3');return n,queries
def step_reverse(a:tuple[int,...],b:tuple[int,...],x:int)->bool:
    forbidden=set(b);seen={x};queue=[x]
    for value in queue:
        if value==0:return True
        for move in a:
            previous=value-move
            if previous<0:break
            if previous not in forbidden and previous not in seen:seen.add(previous);queue.append(previous)
    return False
def extended_euclid(a:int,b:int)->tuple[int,int,int]:
    old_r,r=a,b;old_x,x=1,0;old_y,y=0,1
    while r:q=old_r//r;old_r,r=r,old_r-q*r;old_x,x=x,old_x-q*x;old_y,y=y,old_y-q*y
    return old_r,old_x,old_y
def marking_position(n:int,d:int,k:int)->int:
    period=n//math.gcd(n,d);component,steps=divmod(k-1,period);residue=0;power=d%n
    while steps:
        if steps&1:residue=(residue+power)%n
        power=power*2%n;steps//=2
    return component+residue
def marking_rank(n:int,d:int,position:int)->int:
    g,_,_=extended_euclid(n,d);period=n//g;component=position%g
    if period==1:local_rank=0
    else:_,inverse,_=extended_euclid(d//g,period);local_rank=(position//g*inverse)%period
    return component*period+local_rank+1
def matrix_product(a:Matrix,b:Matrix)->Matrix:
    aa,ab,ac,ad=a;ba,bb,bc,bd=b;return ((aa*ba+ab*bc)%MOD,(aa*bb+ab*bd)%MOD,(ac*ba+ad*bc)%MOD,(ac*bb+ad*bd)%MOD)
def flips_matrix(cards:tuple[tuple[int,...],...])->int:
    def composition(lo:int,hi:int)->Matrix:
        if hi==lo:return 1,0,0,1
        if hi-lo==1:
            previous,next_card=cards[lo-1],cards[lo];return (int(next_card[0]!=previous[0]),int(next_card[0]!=previous[1]),int(next_card[1]!=previous[0]),int(next_card[1]!=previous[1]))
        middle=(lo+hi)//2;return matrix_product(composition(middle,hi),composition(lo,middle))
    return sum(composition(1,len(cards)))%MOD
def unicyclic_basis(n:int,edges:tuple[tuple[int,...],...])->bool:
    parent=list(range(n));size=[1]*n;cycles=[0]*n
    def root(j:int)->int:
        while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
        return j
    for u,v in edges:
        a,b=root(u-1),root(v-1)
        if a==b:cycles[a]+=1
        else:
            if size[a]<size[b]:a,b=b,a
            parent[b]=a;size[a]+=size[b];cycles[a]+=cycles[b]
    return all(cycles[j]==1 for j in range(n) if parent[j]==j)
def endpoint_components(n:int,ties:tuple[tuple[int,...],...])->tuple[int,int]:
    neighbors=[[j^1] for j in range(2*n)]
    for u,v in ties:neighbors[u].append(v);neighbors[v].append(u)
    seen=bytearray(2*n);closed=opened=0
    for start in range(2*n):
        if seen[start]:continue
        seen[start]=1;queue=[start];cycle=True
        for point in queue:
            if len(neighbors[point])<2:cycle=False
            for nxt in neighbors[point]:
                if not seen[nxt]:seen[nxt]=1;queue.append(nxt)
        if cycle:closed+=1
        else:opened+=1
    return closed,opened
def bank_successor(n:int,queries:tuple[tuple[int,...],...])->list[int]:
    parent=list(range(n+2));called=0;answers=[]
    def next_pending(j:int)->int:
        while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
        return j
    for row in queries:
        if row[0]==1:called+=1
        elif row[0]==2:parent[row[1]]=next_pending(row[1]+1)
        else:answers.append(next_pending(1))
    return answers
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc289_d':a,b,x=cast(tuple[tuple[int,...],tuple[int,...],int],data);return 'Yes' if step_reverse(a,b,x) else 'No'
    if pid=='abc290_d':return '\n'.join(str(marking_position(n,d,k)) for n,d,k in cast(tuple[tuple[int,...],...],data[0]))
    if pid=='abc291_d':return str(flips_matrix(cast(tuple[tuple[int,...],...],data[0])))
    if pid=='abc292_d':n,edges=cast(tuple[int,tuple[tuple[int,...],...]],data);return 'Yes' if unicyclic_basis(n,edges) else 'No'
    if pid=='abc293_d':n,ties=cast(tuple[int,tuple[tuple[int,...],...]],data);return ' '.join(map(str,endpoint_components(n,ties)))
    n,queries=cast(tuple[int,tuple[tuple[int,...],...]],data);return '\n'.join(map(str,bank_successor(n,queries)))
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:
        if output_mode not in (None,'exact'):return False
        if pid!='abc290_d':return actual.removesuffix('\n')==oracle(pid,raw)
        queries=cast(tuple[tuple[int,...],...],validate(pid,raw)[0]);rows=actual.removesuffix('\n').split('\n')
        if len(rows)!=len(queries) or any(re.fullmatch(r'0|[1-9][0-9]*',row) is None for row in rows):return False
        return all(0<=position<n and marking_rank(n,d,position)==k for (n,d,k),position in zip(queries,map(int,rows)))
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={'abc289_d': "import sys\nit=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a=[next(it) for _ in range(n)];m=next(it);b={next(it) for _ in range(m)};x=next(it);dp=bytearray(x+1);dp[0]=1\nfor j in range(x+1):\n if not dp[j] or j in b:continue\n for move in a:\n  if j+move<=x:dp[j+move]=1\nprint('Yes' if dp[x] else 'No')\n", 'abc290_d': "import sys,math\nit=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);out=[]\nfor _ in range(t):\n n,d,k=next(it),next(it),next(it);out.append(str((k-1)*d%n+(k-1)//(n//math.gcd(n,d))))\nprint('\\n'.join(out))\n", 'abc291_d': 'import sys\nit=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a,b=next(it),next(it);x=y=1;mod=998244353\nfor _ in range(n-1):\n c,d=next(it),next(it);xx=((x if a!=c else 0)+(y if b!=c else 0))%mod;yy=((x if a!=d else 0)+(y if b!=d else 0))%mod;a,b,x,y=c,d,xx,yy\nprint((x+y)%mod)\n', 'abc292_d': "import sys\nit=iter(map(int,sys.stdin.buffer.read().split()));n,m=next(it),next(it);adj=[[] for _ in range(n)]\nfor _ in range(m):\n u,v=next(it)-1,next(it)-1;adj[u].append(v);adj[v].append(u)\nseen=bytearray(n);ok=True\nfor start in range(n):\n if seen[start]:continue\n seen[start]=1;stack=[start];vertices=degree=0\n while stack:\n  u=stack.pop();vertices+=1;degree+=len(adj[u])\n  for v in adj[u]:\n   if not seen[v]:seen[v]=1;stack.append(v)\n if degree!=2*vertices:ok=False\nprint('Yes' if ok else 'No')\n", 'abc293_d': 'import sys\nit=iter(sys.stdin.buffer.read().split());n,m=int(next(it)),int(next(it));p=list(range(n));size=[1]*n;edges=[0]*n\ndef root(j):\n while p[j]!=j:p[j]=p[p[j]];j=p[j]\n return j\nfor _ in range(m):\n a=int(next(it))-1;next(it);b=int(next(it))-1;next(it);u,v=root(a),root(b)\n if u!=v:\n  if size[u]<size[v]:u,v=v,u\n  p[v]=u;size[u]+=size[v];edges[u]+=edges[v]\n edges[u]+=1\nclosed=opened=0\nfor j in range(n):\n if p[j]==j:\n  if edges[j]==size[j]:closed+=1\n  else:opened+=1\nprint(closed,opened)\n', 'abc294_d': "import sys,heapq\nit=iter(map(int,sys.stdin.buffer.read().split()));n,q=next(it),next(it);called=0;active=set();heap=[];out=[]\nfor _ in range(q):\n kind=next(it)\n if kind==1:called+=1;active.add(called);heapq.heappush(heap,called)\n elif kind==2:active.remove(next(it))\n else:\n  while heap[0] not in active:heapq.heappop(heap)\n  out.append(str(heap[0]))\nprint('\\n'.join(out))\n"}

TITLES:dict[str,str]={'abc289_d': 'Step Up Robot', 'abc290_d': 'Marking', 'abc291_d': 'Flip Cards', 'abc292_d': 'Unicyclic Components', 'abc293_d': 'Tying Rope', 'abc294_d': 'Bank'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'abc289_d': [{'input': '3\n3 4 5\n4\n4 5 6 8\n15\n', 'expected': 'Yes\n'}, {'input': '4\n2 3 4 5\n4\n3 4 5 6\n8\n', 'expected': 'No\n'}, {'input': '4\n2 5 7 8\n5\n2 9 10 11 19\n20\n', 'expected': 'Yes\n'}], 'abc290_d': [{'input': '9\n4 2 1\n4 2 2\n4 2 3\n4 2 4\n5 8 1\n5 8 2\n5 8 3\n5 8 4\n5 8 5\n', 'expected': '0\n2\n1\n3\n0\n3\n1\n4\n2\n'}], 'abc291_d': [{'input': '3\n1 2\n4 2\n3 4\n', 'expected': '4\n'}, {'input': '4\n1 5\n2 6\n3 7\n4 8\n', 'expected': '16\n'}, {'input': '8\n877914575 602436426\n861648772 623690081\n476190629 262703497\n971407775 628894325\n822804784 450968417\n161735902 822804784\n161735902 822804784\n822804784 161735902\n', 'expected': '48\n'}], 'abc292_d': [{'input': '3 3\n2 3\n1 1\n2 3\n', 'expected': 'Yes\n'}, {'input': '5 5\n1 2\n2 3\n3 4\n3 5\n1 5\n', 'expected': 'Yes\n'}, {'input': '13 16\n7 9\n7 11\n3 8\n1 13\n11 11\n6 11\n8 13\n2 11\n3 3\n8 12\n9 11\n1 11\n5 13\n3 12\n6 9\n1 10\n', 'expected': 'No\n'}], 'abc293_d': [{'input': '5 3\n3 R 5 B\n5 R 3 B\n4 R 2 B\n', 'expected': '1 2\n'}, {'input': '7 0\n', 'expected': '0 7\n'}, {'input': '7 6\n5 R 3 R\n7 R 4 R\n4 B 1 R\n2 R 3 B\n2 B 5 B\n1 B 7 B\n', 'expected': '2 1\n'}], 'abc294_d': [{'input': '4 10\n1\n1\n3\n2 1\n1\n2 3\n3\n1\n2 2\n3\n', 'expected': '1\n2\n4\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(int(pid[3:6]));raws:list[str]=[]
    if pid=='abc289_d':
        def pack(a:list[int],b:list[int],x:int)->str:return f'{len(a)}\n'+line(a)+f'{len(b)}\n'+line(b)+f'{x}\n'
        raws=[pack([1],[1],2),pack([2],[1],2),pack([100000],[1],2),pack([1,3],[2,4],6)]
        for j in range(12):
            x=30+j;n=min(10,j+1);a=sorted(rng.sample(range(1,30),n));b=sorted(rng.sample(range(1,x),1+j));raws.append(pack(a,b,x))
        raws.extend([pack(list(range(1,11)),list(range(1,100000,2)),100000),pack(list(range(99991,100001)),list(range(1,100000)),100000)])
    elif pid=='abc290_d':
        def pack(q:list[tuple[int,int,int]])->str:return f'{len(q)}\n'+''.join(line(row) for row in q)
        raws=[pack([(1,1,1)]),pack([(1,10**9,1)]),pack([(12,8,3),(12,8,4),(12,8,12)]),pack([(7,1000000000,7),(10,10,10)])]
        for j in range(12):
            q=[]
            for _ in range(j+1):
                n=rng.randint(1,10**9);q.append((n,rng.randint(1,10**9),rng.randint(1,n)))
            raws.append(pack(q))
        raws.extend([pack([(10**9,999999999,1+j*9999) for j in range(100000)]),pack([(10**9,10**9,10**9)]*100000)])
    elif pid=='abc291_d':
        def pack(cards:list[tuple[int,int]])->str:return f'{len(cards)}\n'+''.join(line(row) for row in cards)
        raws=[pack([(1,1)]),pack([(1,1),(1,1)]),pack([(1,2),(2,1)]),pack([(10**9,1)])]
        for j in range(12):raws.append(pack([(rng.randint(1,5),rng.randint(1,5)) for _ in range(j+3)]))
        raws.extend([pack([(1+j%2,10**9-j%3) for j in range(200000)]),pack([(10**9,10**9)]*200000)])
    elif pid=='abc292_d':
        def pack(n:int,edges:list[tuple[int,int]])->str:return f'{n} {len(edges)}\n'+''.join(line(row) for row in edges)
        raws=[pack(1,[]),pack(1,[(1,1)]),pack(1,[(1,1),(1,1)]),pack(2,[(1,1),(2,2)])]
        for j in range(12):
            n=j+3;raws.append(pack(n,[tuple(sorted((rng.randint(1,n),rng.randint(1,n)))) for _ in range(j+1)]))
        raws.extend([pack(200000,[(j,j+1) for j in range(1,200000)]+[(1,200000)]),pack(200000,[(j,j) for j in range(1,200001)])])
    elif pid=='abc293_d':
        def pack(n:int,ties:list[tuple[int,int]])->str:return f'{n} {len(ties)}\n'+''.join(f'{u//2+1} {"B" if u%2 else "R"} {v//2+1} {"B" if v%2 else "R"}\n' for u,v in ties)
        raws=[pack(1,[]),pack(1,[(0,1)]),pack(2,[(0,2)]),pack(2,[(0,2),(1,3)])]
        for j in range(12):
            n=j+3;ends=list(range(2*n));rng.shuffle(ends);count=j+1;raws.append(pack(n,list(zip(ends[:2*count:2],ends[1:2*count:2]))))
        raws.extend([pack(200000,[(2*j,2*j+1) for j in range(200000)]),pack(200000,[(2*j+1,2*((j+1)%200000)) for j in range(200000)])])
    else:
        def pack(n:int,queries:list[tuple[int,...]])->str:return f'{n} {len(queries)}\n'+''.join(line(row) for row in queries)
        raws=[pack(1,[(1,),(3,)]),pack(1,[(1,),(3,),(2,1)]),pack(2,[(1,),(1,),(2,1),(3,)]),pack(2,[(1,),(3,),(1,),(3,),(2,2),(3,)])]
        for j in range(12):
            n=j+3;queries=[(1,),(3,)];pending={1};called=1
            for _ in range(20+j):
                choices=([1] if called<n else [])+([2,3] if pending else [])
                kind=rng.choice(choices or [1])
                if kind==1:called+=1;pending.add(called);queries.append((1,))
                elif kind==2:x=rng.choice(sorted(pending));pending.remove(x);queries.append((2,x))
                else:queries.append((3,))
                if not pending and called==n:break
            raws.append(pack(n,queries))
        big=[]
        for j in range(1,166667):big.extend([(1,),(2,j)])
        big.append((1,));big.extend([(3,)]*(500000-len(big)))
        raws.extend([pack(500000,big),pack(500000,[(1,)]*499999+[(3,)])])
    require(len(raws)==len(set(raws))==18,'18 unique');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'random'} for j,raw in enumerate(raws)]

HINTS:dict[str,tuple[str,str,str]]={'abc289_d': ('到達可能な段を低い方から順に調べます。', 'モチのある段からは次の段へ進めません。到達可能な段から各移動量を足します。', '疑似コード: dp[0]=true。i=0..Xで、dp[i]がtrueかつiがモチでなければ、各aについてi+a<=Xのときdp[i+a]=trueにする。dp[X]を出力する。'), 'abc290_d': ('D段ずつ進むと、最初の位置に戻る周期を求められます。', '周期はN/gcd(N,D)です。周期を完走するたびに開始位置が1つ増えます。', '疑似コード: p=N/gcd(N,D)、z=K-1とする。答えは(z*D)%N+z//p。各テストケースでこの式を計算する。'), 'abc291_d': ('最後に見えている値を状態にして、カードを左から処理します。', '現在のカードの表と裏を選んだ場合の通り数を別々に持ち、直前の値が異なる選択だけから遷移します。', '疑似コード: 最初は表・裏の通り数を各1とする。次の表の数は直前の表/裏と値が異なる項の和、次の裏も同様。各和を998244353で割った余りにし、最後の2状態の和を出す。'), 'abc292_d': ('条件を連結成分ごとに調べます。', '各連結成分の頂点数と辺数が同じなら条件を満たします。自己ループも辺1本として数えます。', '疑似コード: 無向隣接リストを作り、未訪問頂点からDFSする。訪問頂点数Vと隣接リスト長の和Dを数える。すべての成分でD=2VならYes、そうでなければNo。'), 'abc293_d': ('結ばれたロープを同じ連結成分にまとめます。', '各成分のロープ数と結び目数を数えます。両端の利用回数は最大1なので、輪は結び目数がロープ数と等しい成分です。', '疑似コード: DSUで各結び目の2本のロープを併合し、成分のロープ数と結び目数を集計する。根ごとに両者が等しければ輪、それ以外は輪でないとして数え、2つの個数を出す。'), 'abc294_d': ('呼ばれたまま受付へ行っていない人の最小番号を管理します。', '呼ばれた番号を最小ヒープへ入れ、受付へ行った人を別の集合から除きます。ヒープには古い番号を残せます。', '疑似コード: 種類1で次の番号をヒープと未受付集合へ追加する。種類2で集合からxを除く。種類3ではヒープ先頭が集合にない間popし、残った先頭を出力する。')}
