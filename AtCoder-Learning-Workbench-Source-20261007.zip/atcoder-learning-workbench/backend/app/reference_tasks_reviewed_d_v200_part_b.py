from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import deque,Counter
from itertools import permutations
from math import gcd,isqrt
from typing import cast
import random,re
TASKS=tuple(f'abc{i}_d' for i in range(395,401));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES={'abc397_d':'semantic'};CHECKER_IDS={'abc397_d':'abc397_d'};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc395_d':
  n,q=ints(r[0],2);ops=tuple(ints(row) for row in r[1:]);require(1<=n<=10**6 and 1<=q<=300000 and len(ops)==q and any(row[0]==3 for row in ops),'shape');require(all(len(row)==2 and row[0]==3 and 1<=row[1]<=n or len(row)==3 and row[0] in (1,2) and 1<=row[1]<=n and 1<=row[2]<=n and (row[0]==1 or row[1]<row[2]) for row in ops),'ops');return n,ops
 if pid=='abc396_d':
  n,m=ints(r[0],2);require(2<=n<=10 and n-1<=m<=n*(n-1)//2 and len(r)==m+1,'shape');edges=tuple(ints(row,3) for row in r[1:]);require(all(1<=u<v<=n and 0<=w<1<<60 for u,v,w in edges) and len({(u,v) for u,v,w in edges})==m,'edges');seen={1}
  while True:
   nxt=seen|{v for u,v,w in edges if u in seen}|{u for u,v,w in edges if v in seen}
   if nxt==seen:break
   seen=nxt
  require(len(seen)==n,'connected');return n,edges
 if pid=='abc397_d':require(len(r)==1,'shape');n=ints(r[0],1)[0];require(1<=n<=10**18,'N');return (n,)
 if pid=='abc398_d':
  n,row,col=ints(r[0],3);require(1<=n<=200000 and -n<=row<=n and -n<=col<=n and (row,col)!=(0,0) and len(r)==2 and re.fullmatch('[NWSE]{'+str(n)+'}',r[1]) is not None,'domain');return row,col,r[1]
 if pid=='abc399_d':
  t=ints(r[0],1)[0];require(1<=t<=200000 and len(r)==2*t+1,'shape');cases=[];total=0
  for i in range(t):
   n=ints(r[1+2*i],1)[0];require(1<=n<=200000,'N');a=ints(r[2+2*i],2*n);require(Counter(a)=={v:2 for v in range(1,n+1)},'each twice');total+=n;cases.append(a)
  require(total<=200000,'totalN');return (tuple(cases),)
 h,w=ints(r[0],2);require(1<=h<=1000 and 1<=w<=1000 and len(r)==h+2,'shape');grid=tuple(r[1:h+1]);require(all(re.fullmatch('[.#]{'+str(w)+'}',row) for row in grid),'grid');a,b,c,d=ints(r[-1],4);require(1<=a<=h and 1<=c<=h and 1<=b<=w and 1<=d<=w and (a,b)!=(c,d) and grid[a-1][b-1]==grid[c-1][d-1]=='.','endpoints');return grid,(a-1)*w+b-1,(c-1)*w+d-1

def pigeons_swap_blocks(n:int,ops:tuple[tuple[int,...],...])->list[int]:
 swaps=[];queries=[];last:dict[int,tuple[int,int]]={}
 for row in ops:
  if row[0]==2:swaps.append((row[1],row[2]))
  elif row[0]==1:last[row[1]]=(len(swaps),row[2])
  else:start,nest=last.get(row[1],(0,row[1]));queries.append((start,len(swaps),nest))
 size=512;blocks=[]
 for start in range(0,len(swaps),size):
  forward={};inverse={}
  for a,b in swaps[start:start+size]:
   aa=inverse.get(a,a);bb=inverse.get(b,b);forward[aa]=b;forward[bb]=a;inverse[a]=bb;inverse[b]=aa
  blocks.append(forward)
 answer=[]
 for start,end,nest in queries:
  boundary=min(end,((start+size-1)//size)*size)
  for i in range(start,boundary):
   a,b=swaps[i]
   if nest==a:nest=b
   elif nest==b:nest=a
  start=boundary
  while start+size<=end:nest=blocks[start//size].get(nest,nest);start+=size
  for i in range(start,end):
   a,b=swaps[i]
   if nest==a:nest=b
   elif nest==b:nest=a
  answer.append(nest)
 return answer

def xor_permutation_paths(n:int,edges:tuple[tuple[int,...],...])->int:
 weights={(u-1,v-1):w for u,v,w in edges};weights.update({(v,u):w for (u,v),w in list(weights.items())});middle=tuple(range(1,n-1));best=1<<60
 for size in range(n-1):
  for sequence in permutations(middle,size):
   value=0;previous=0
   for vertex in (*sequence,n-1):
    if (previous,vertex) not in weights:break
    value^=weights[previous,vertex];previous=vertex
   else:best=min(best,value)
 return best

def prime(n:int)->bool:
 if n<2:return False
 for p in (2,3,5,7,11,13,17,19,23,29,31,37):
  if n%p==0:return n==p
 d=n-1;s=0
 while d%2==0:d//=2;s+=1
 for a in (2,325,9375,28178,450775,9780504,1795265022):
  if a%n==0:continue
  x=pow(a,d,n)
  if x in (1,n-1):continue
  for _ in range(s-1):
   x=x*x%n
   if x==n-1:break
  else:return False
 return True

def brent_factor(n:int)->int:
 for p in (2,3,5,7,11,13):
  if n%p==0:return p
 for constant in range(1,100):
  y=2;r=1;g=1;x=ys=0
  while g==1:
   x=y
   for _ in range(r):y=(y*y+constant)%n
   k=0
   while k<r and g==1:
    ys=y;product=1
    for _ in range(min(128,r-k)):y=(y*y+constant)%n;product=product*abs(x-y)%n
    g=gcd(product,n);k+=128
   r*=2
  if g==n:
   g=1
   while g==1:ys=(ys*ys+constant)%n;g=gcd(abs(x-ys),n)
  if g!=n:return g
 raise ValueError('factorization')

def cube_divisor_solution(n:int)->tuple[int,int]|None:
 factors=Counter();pending=[n]
 while pending:
  value=pending.pop()
  if value==1:continue
  if prime(value):factors[value]+=1
  else:divisor=brent_factor(value);pending.extend((divisor,value//divisor))
 divisors=[1]
 for p,e in factors.items():divisors=[d*p**k for d in divisors for k in range(e+1)]
 for gap in sorted(divisors):
  if gap**3>=n:break
  discriminant=12*(n//gap)-3*gap*gap
  if discriminant<0:continue
  root=isqrt(discriminant)
  if root*root==discriminant and root>3*gap and (root-3*gap)%6==0:
   y=(root-3*gap)//6;return y+gap,y
 return None

def cubes_valid(n:int,actual:str)->bool:
 value=actual.removesuffix('\n')
 if value=='-1':return cube_divisor_solution(n) is None
 if re.fullmatch('[+-]?[0-9]+ [+-]?[0-9]+',value) is None:return False
 x,y=map(int,value.split());return x>0 and y>0 and x**3-y**3==n

def smoke_offline_first(row:int,col:int,s:str)->str:
 moves={'N':(-1,0),'W':(0,-1),'S':(1,0),'E':(0,1)};prefix=[(0,0)];r=c=0
 for char in s:dr,dc=moves[char];r+=dr;c+=dc;prefix.append((r,c))
 ordered=sorted((point,i) for i,point in enumerate(prefix));keys=[];first=[]
 for point,i in ordered:
  if not keys or point!=keys[-1]:keys.append(point);first.append(i)
 answer=[]
 for t,(r,c) in enumerate(prefix[1:],1):
  target=(r-row,c-col);i=bisect_left(keys,target);answer.append('1' if i<len(keys) and keys[i]==target and first[i]<t else '0')
 return ''.join(answer)

def couple_adjacency_edges(a:tuple[int,...])->int:
 n=len(a)//2;locations=[[] for _ in range(n+1)]
 for i,v in enumerate(a):locations[v].append(i)
 already={v for v in range(1,n+1) if locations[v][1]-locations[v][0]==1};pairs=set()
 for i,(u,v) in enumerate(zip(a,a[1:])):
  if u==v or u in already or v in already:continue
  uu=locations[u][0] if locations[u][1]==i else locations[u][1];vv=locations[v][0] if locations[v][1]==i+1 else locations[v][1]
  if abs(uu-vv)==1:pairs.add((min(u,v),max(u,v)))
 return len(pairs)

def wall_component_layers(grid:tuple[str,...],start:int,goal:int)->int:
 h,w=len(grid),len(grid[0]);n=h*w;flat=''.join(grid);owner=list(range(n));seen=bytearray(n);members:dict[int,list[int]]={}
 for seed,char in enumerate(flat):
  if char!='.' or seen[seed]:continue
  queue=[seed];seen[seed]=1
  for point in queue:
   r,c=divmod(point,w);owner[point]=seed
   for rr,cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
    if 0<=rr<h and 0<=cc<w:
     nxt=rr*w+cc
     if flat[nxt]=='.' and not seen[nxt]:seen[nxt]=1;queue.append(nxt)
  members[seed]=queue
 source,target=owner[start],owner[goal]
 if source==target:return 0
 distances=[-1]*n;distances[source]=0;current=deque([source]);next_layer=deque();level=0
 while current or next_layer:
  if not current:current,next_layer=next_layer,deque();level+=1
  node=current.popleft()
  if distances[node]!=level:continue
  if node==target:return level
  for point in members.get(node,(node,)):
   r,c=divmod(point,w)
   for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
    rr,cc=r+dr,c+dc
    if not(0<=rr<h and 0<=cc<w):continue
    nearby=rr*w+cc;destination=owner[nearby]
    if flat[nearby]=='.' and (distances[destination]<0 or distances[destination]>level):distances[destination]=level;current.append(destination)
    for step in (1,2):
     rr,cc=r+step*dr,c+step*dc
     if 0<=rr<h and 0<=cc<w:
      destination=owner[rr*w+cc]
      if distances[destination]<0:distances[destination]=level+1;next_layer.append(destination)
 raise AssertionError('reachable')

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc395_d':return ''.join(str(v)+'\n' for v in pigeons_swap_blocks(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))
 if pid=='abc396_d':return str(xor_permutation_paths(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))+'\n'
 if pid=='abc397_d':pair=cube_divisor_solution(cast(int,d[0]));return '-1\n' if pair is None else line(pair)
 if pid=='abc398_d':return smoke_offline_first(cast(int,d[0]),cast(int,d[1]),cast(str,d[2]))+'\n'
 if pid=='abc399_d':return ''.join(str(couple_adjacency_edges(a))+'\n' for a in cast(tuple[tuple[int,...],...],d[0]))
 return str(wall_component_layers(cast(tuple[str,...],d[0]),cast(int,d[1]),cast(int,d[2])))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  if pid=='abc397_d':return cubes_valid(cast(int,validate(pid,raw)[0]),actual)
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE:dict[str,str]={
'abc395_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);q=next(it);pigeon=list(range(n+1));label=list(range(n+1));nest=list(range(n+1));out=[]
for _ in range(q):
 kind=next(it);a=next(it)
 if kind==1:b=next(it);pigeon[a]=nest[b]
 elif kind==2:
  b=next(it);x,y=nest[a],nest[b];nest[a],nest[b]=y,x;label[x],label[y]=b,a
 else:out.append(str(label[pigeon[a]]))
print('\\n'.join(out))
''',
'abc396_d':'''n,m=map(int,input().split());g=[[] for _ in range(n)]
for _ in range(m):u,v,w=map(int,input().split());g[u-1].append((v-1,w));g[v-1].append((u-1,w))
answer=1<<60
def dfs(u,used,value):
 global answer
 if u==n-1:answer=min(answer,value);return
 for v,w in g[u]:
  if not used>>v&1:dfs(v,used|1<<v,value^w)
dfs(0,1,0);print(answer)
''',
'abc397_d':'''import sys
n=int(input());gap=1
while gap**3<n:
 if n%gap==0:
  q=n//gap;lo=0;hi=10**9
  while hi-lo>1:
   mid=(hi+lo)//2;value=3*mid*mid+3*gap*mid+gap*gap
   if value>=q:hi=mid
   else:lo=mid
  if 3*hi*hi+3*gap*hi+gap*gap==q:print(hi+gap,hi);sys.exit()
 gap+=1
print(-1)
''',
'abc398_d':'''n,r,c=map(int,input().split());s=input();x=y=0;seen={(0,0)};out=[];move={'N':(-1,0),'W':(0,-1),'S':(1,0),'E':(0,1)}
for char in s:
 dx,dy=move[char];x+=dx;y+=dy;seen.add((x,y));out.append('1' if (x-r,y-c) in seen else '0')
print(''.join(out))
''',
'abc399_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);out=[]
for _ in range(t):
 n=next(it);a=[next(it) for _ in range(2*n)];pos=[[] for _ in range(n+1)]
 for i,v in enumerate(a):pos[v].append(i)
 result=set()
 for u in range(1,n+1):
  first,last=pos[u]
  if last==first+1:continue
  for i in (first-1,first+1):
   if not 0<=i<2*n:continue
   v=a[i]
   if v<=u or pos[v][1]==pos[v][0]+1:continue
   four=sorted(pos[u]+pos[v])
   if four[1]==four[0]+1 and four[3]==four[2]+1:result.add((u,v))
 out.append(str(len(result)))
print('\\n'.join(out))
''',
'abc400_d':'''from collections import deque
h,w=map(int,input().split());g=[input() for _ in range(h)];a,b,c,d=map(int,input().split());source=(a-1)*w+b-1;target=(c-1)*w+d-1;inf=10**9;dist=[inf]*(h*w);dist[source]=0;queue=deque([(source,0)])
while queue:
 p,value=queue.popleft()
 if value!=dist[p]:continue
 if p==target:print(value);break
 r,col=divmod(p,w)
 for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
  rr,cc=r+dr,col+dc
  if not(0<=rr<h and 0<=cc<w):continue
  q=rr*w+cc
  if g[rr][cc]=='.' and value<dist[q]:dist[q]=value;queue.appendleft((q,value))
  for step in (1,2):
   rr,cc=r+step*dr,col+step*dc
   if 0<=rr<h and 0<=cc<w:
    q=rr*w+cc
    if value+1<dist[q]:dist[q]=value+1;queue.append((q,value+1))
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(200000+TASKS.index(pid));raws=[]
 if pid=='abc395_d':
  configs=[(1,((3,1),)),(1,((1,1,1),(3,1))),(2,((2,1,2),(3,1),(3,2))),(3,((1,1,2),(2,2,3),(3,1),(3,2))),(3,((2,1,2),(2,1,2),(3,1)))]
  for n in (4,5,6,7,8,10,17,100,1000,10000):
   ops=[]
   for _ in range(min(n,1000)):
    kind=rng.randint(1,3);a=rng.randint(1,n)
    if kind==3:ops.append((3,a))
    elif kind==1:ops.append((1,a,rng.randint(1,n)))
    else:x,y=sorted(rng.sample(range(1,n+1),2));ops.append((2,x,y))
   ops.append((3,n));configs.append((n,tuple(ops)))
  configs.append((10**6,((2,1,10**6),(3,10**6))*150000))
  configs += [(10**6,((3,10**6),)*300000),(10**6,tuple(row for i in range(100000) for row in ((1,i+1,10**6),(2,1,10**6),(3,i+1))))];raws=[line((n,len(ops)))+''.join(line(row) for row in ops) for n,ops in configs]
 elif pid=='abc396_d':
  configs=[(2,((1,2,0),)),(2,((1,2,(1<<60)-1),)),(3,((1,2,1),(2,3,2))),(3,((1,2,1),(2,3,2),(1,3,7))),(4,((1,2,1),(2,3,3),(3,4,1),(1,4,7)))]
  for i in range(11):
   n=3+i%7;edges={(j,j+1):rng.randrange(1<<60) for j in range(1,n)}
   for _ in range(n):u,v=sorted(rng.sample(range(1,n+1),2));edges[u,v]=rng.randrange(1<<60)
   configs.append((n,tuple((u,v,w) for (u,v),w in edges.items())))
  configs += [(10,tuple((u,v,rng.randrange(1<<60)) for u in range(1,11) for v in range(u+1,11))),(10,tuple((u,v,(1<<60)-1) for u in range(1,11) for v in range(u+1,11)))];raws=[line((n,len(e)))+''.join(line(row) for row in e) for n,e in configs]
 elif pid=='abc397_d':
  values=[1,2,6,7,19,26,37,397,999,1000,9999999967,999999937*999999929,10**18-1,39977273855577088,123456**3-12345**3,577350269**3-577350268**3,10**18-7,10**18];raws=[line((v,)) for v in values]
 elif pid=='abc398_d':
  configs=[(-1,-1,'N'),(-1,0,'N'),(0,1,'E'),(1,0,'S'),(-1,0,'NSNS'),(0,1,'EWEW')]
  for n in (5,6,7,8,10,17,100,1000,10000,100000):
   row=col=0
   while (row,col)==(0,0):row=rng.randint(-n,n);col=rng.randint(-n,n)
   configs.append((row,col,''.join(rng.choice('NWSE') for _ in range(n))))
  configs += [(0,1,'EW'*100000),(-200000,200000,'N'*200000)];raws=[line((len(s),r,c))+s+'\n' for r,c,s in configs]
 elif pid=='abc399_d':
  cases=[((1,1),),((1,2,1,2),),((1,2,2,1),),((1,1,2,2),),((1,2,3,1,2,3),),((1,2,3,3,1,2),)]
  for n in (4,5,6,7,8,10,17,100,1000,10000):a=list(range(1,n+1))*2;rng.shuffle(a);cases.append((tuple(a),))
  cases += [((1,1),)*200000,(tuple(range(1,200001))*2,)];raws=[line((len(c),))+''.join(line((len(a)//2,))+line(a) for a in c) for c in cases]
 else:
  configs=[(('..',),0,1),(('.#.',),0,2),(('.#','#.'),0,3),(('.##.',),0,3),(('.###.',),0,4),(('.'*5,)*5,0,24)]
  for i in range(10):
   h=2+i%5;w=3+i%5;grid=[''.join('#' if rng.randrange(2)==0 else '.' for _ in range(w)) for _ in range(h)];grid[0]='.'+grid[0][1:];grid[-1]=grid[-1][:-1]+'.';configs.append((tuple(grid),0,h*w-1))
  configs += [(('.'*1000,)*1000,0,999999),(('.'+'#'*999,)+('#'*1000,)*998+('#'*999+'.',),0,999999)];raws=[line((len(g),len(g[0])))+'\n'.join(g)+'\n'+line((start//len(g[0])+1,start%len(g[0])+1,goal//len(g[0])+1,goal%len(g[0])+1)) for g,start,goal in configs]
 require(len(raws)==len(set(raws))==18,'18distinct');result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result
HINTS:dict[str,tuple[str,str,str]]={
'abc395_d':('巣の中身と巣の番号を分けて管理すると、巣全体の交換が軽くなります。','鳩が属する中身ID、巣番号から中身ID、中身IDから巣番号の3配列を持ちます。交換では対応だけを書き換えます。','疑似コード: pigeon[i]=nest[i]=label[i]=i; 移動(a,b)はpigeon[a]=nest[b]; 交換(a,b)はnest[a],nest[b]を交換し、その中身IDのlabelを更新; 質問(a)はlabel[pigeon[a]]を出力。'),
'abc396_d':('頂点数が小さいので、すべての単純パスを試せます。','訪問済み頂点集合を持つDFSで、同じ頂点を2回通る遷移を除きます。XORを累積して終点で最小化します。','疑似コード: dfs(vertex,used,xor): vertex=Nなら答えをxorで最小化; 各隣接辺(v,w)についてvが未訪問ならdfs(v,used|bit(v),xor XOR w); 始点1から開始。'),
'abc397_d':('差d=x-yを固定すると、Nはdで割り切れ、yについての単調な二次式になります。','N=d*(3y^2+3dy+d^2)なのでd^3<Nです。dを整数立方根まで列挙し、割り切れた場合だけ正のyを二分探索します。','疑似コード: d=1からd^3<Nの間反復; N%d=0ならq=N//d、3y^2+3dy+d^2>=qを満たす最小y>=1を二分探索; 等号なら(y+d,y)を出力して終了; 全dで失敗したら-1。'),
'abc398_d':('風の累積移動を引いた座標で、煙を固定して考えます。','累積移動が初めて到達した座標で新しい煙が生まれます。現在の累積位置から(R,C)を引いた座標が既出か調べます。','疑似コード: prefix=(0,0),seen={(0,0)}; 風ごとにprefixを更新しseenへ追加; prefix-(R,C)がseenにあれば1、他は0を答えへ追加; 文字列を出力。'),
'abc399_d':('対象の4人が座る4つの位置は、交換しても変わりません。','両カップルがもともと離れていることを確認し、その4位置を小さい順にしたとき最初の2位置と最後の2位置が隣接するか調べます。候補は元の隣接席から拾えます。','疑似コード: 各値の出現位置2個を保存; 非隣接の値aの最初の位置の左右にあるb>aを候補にする; bも非隣接なら4位置をsort; p1+1=p2かつp3+1=p4ならpair集合へ; 集合サイズを出力。'),
'abc400_d':('道への移動は費用0、前蹴りによる到達は費用1として扱えます。','四近傍の元の道には0で移動します。各方向の1マス先・2マス先へは前蹴り1回で進めるので、0-1 BFSで最小回数を求めます。','疑似コード: startの距離0、dequeへ; 現在地pから四近傍の道へ距離そのままで更新して先頭へ; 各方向1/2マス先へ距離+1で更新して末尾へ; goalの最短距離を出力。')}

TITLES={'abc395_d': 'Pigeon Swap', 'abc396_d': 'Minimum XOR Path', 'abc397_d': 'Cubes', 'abc398_d': 'Bonfire', 'abc399_d': 'Switch Seats', 'abc400_d': 'Takahashi the Wall Breaker'}
PUBLISHED_SAMPLES={'abc395_d': [{'input': '6 8\n1 2 4\n1 3 6\n3 2\n2 4 5\n3 2\n1 4 2\n3 4\n3 2\n', 'expected': '4\n5\n2\n5\n'}, {'input': '1 2\n1 1 1\n3 1\n', 'expected': '1\n'}, {'input': '30 15\n3 3\n2 8 30\n2 12 15\n2 2 17\n1 19 1\n2 7 30\n3 12\n3 8\n2 25 26\n1 13 10\n1 16 10\n2 16 29\n2 1 21\n2 6 11\n1 21 8\n', 'expected': '3\n15\n7\n'}], 'abc396_d': [{'input': '4 4\n1 2 3\n2 4 5\n1 3 4\n3 4 7\n', 'expected': '3\n'}, {'input': '4 3\n1 2 1\n2 3 2\n3 4 4\n', 'expected': '7\n'}, {'input': '7 10\n1 2 726259430069220777\n1 4 988687862609183408\n1 5 298079271598409137\n1 6 920499328385871537\n1 7 763940148194103497\n2 4 382710956291350101\n3 4 770341659133285654\n3 5 422036395078103425\n3 6 472678770470637382\n5 7 938201660808593198\n', 'expected': '186751192333709144\n'}], 'abc397_d': [{'input': '397\n', 'expected': '12 11\n'}, {'input': '1\n', 'expected': '-1\n'}, {'input': '39977273855577088\n', 'expected': '342756 66212\n'}], 'abc398_d': [{'input': '6 -2 1\nNNEEWS\n', 'expected': '001010\n'}, {'input': '10 1 2\nNEESESWEES\n', 'expected': '0001101011\n'}, {'input': '20 -1 -2\nWWNNWSWEWNSWWENSNWWN\n', 'expected': '00100111111000101111\n'}], 'abc399_d': [{'input': '3\n3\n1 2 3 3 1 2\n4\n1 1 2 2 3 3 4 4\n5\n1 2 3 4 5 1 2 3 4 5\n', 'expected': '1\n0\n4\n'}], 'abc400_d': [{'input': '10 10\n..........\n#########.\n#.......#.\n#..####.#.\n##....#.#.\n#####.#.#.\n.##.#.#.#.\n###.#.#.#.\n###.#.#.#.\n#.....#...\n1 1 7 1\n', 'expected': '1\n'}, {'input': '2 2\n.#\n#.\n1 1 2 2\n', 'expected': '1\n'}, {'input': '1 3\n.#.\n1 1 1 3\n', 'expected': '1\n'}, {'input': '20 20\n####################\n##...##....###...###\n#.....#.....#.....##\n#..#..#..#..#..#..##\n#..#..#....##..#####\n#.....#.....#..#####\n#.....#..#..#..#..##\n#..#..#.....#.....##\n#..#..#....###...###\n####################\n####################\n##..#..##...###...##\n##..#..#.....#.....#\n##..#..#..#..#..#..#\n##..#..#..#..#..#..#\n##.....#..#..#..#..#\n###....#..#..#..#..#\n#####..#.....#.....#\n#####..##...###...##\n####################\n3 3 18 18\n', 'expected': '3\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
