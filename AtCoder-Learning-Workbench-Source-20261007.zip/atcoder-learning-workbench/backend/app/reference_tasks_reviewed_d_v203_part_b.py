"""Private reviewed D449..454; official domains and independent computations."""
from __future__ import annotations
from typing import cast
from functools import lru_cache
from collections import deque
from array import array
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(449,455));CONTESTS={p:p.split('_')[0] for p in TASKS};Case=dict[str,str];Data=tuple[object,...]
OUTPUT_MODES={'abc453_d':'semantic'};CHECKER_IDS={'abc453_d':'abc453_d'}
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?: -?(?:0|[1-9][0-9]*))*',row) is not None and '-0' not in row.split(),'integers');v=tuple(map(int,row.split()));require(n is None or len(v)==n,'fields');return v
def line(v:tuple[int,...]|list[int])->str:return ' '.join(map(str,v))+'\n'

@lru_cache(None)
def power_automaton()->tuple[tuple[tuple[int,...],...],tuple[bool,...]]:
 children:list[dict[str,int]]=[{}];terminal:set[int]=set()
 for exponent in range(30):
  node=0
  for ch in str(1<<exponent):
   if ch not in children[node]:children[node][ch]=len(children);children.append({})
   node=children[node][ch]
  terminal.add(node)
 subsets=[frozenset((0,))];index={subsets[0]:0};trans=[];accept=[]
 for subset in subsets:
  row=[];accept.append(0 in subset)
  for digit in '0123456789':
   reached={children[node][digit] for node in subset if digit in children[node]}
   if reached&terminal:reached.add(0)
   key=frozenset(reached)
   if key not in index:index[key]=len(subsets);subsets.append(key)
   row.append(index[key])
  trans.append(tuple(row))
 return tuple(trans),tuple(accept)
@lru_cache(None)
def power_suffix(state:int,remaining:int)->int:
 trans,accept=power_automaton()
 return int(accept[state]) if not remaining else sum(power_suffix(nextstate,remaining-1) for nextstate in trans[state])
@lru_cache(None)
def power_domain_max()->int:
 trans,_=power_automaton()
 # The only 10-digit integer <=1e9 is1000000000. No power begins0,
 # and no available power has only1 followed by zeroes, so it is not accepted.
 state=0
 for digit in '1000000000':state=trans[state][int(digit)]
 assert not power_automaton()[1][state]
 return sum(power_suffix(trans[0][digit],length-1) for length in range(1,10) for digit in range(1,10))
def power_unrank(rank:int)->int:
 trans,_=power_automaton();length=1
 while True:
  count=sum(power_suffix(trans[0][digit],length-1) for digit in range(1,10))
  if rank<=count:break
  rank-=count;length+=1
 state=0;result=''
 for position in range(length):
  for digit in range(1 if position==0 else 0,10):
   nextstate=trans[state][digit];count=power_suffix(nextstate,length-position-1)
   if rank>count:rank-=count
   else:result+=str(digit);state=nextstate;break
 return int(result)

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc449_d':
  require(len(rows)==1,'shape');l,r,d,u=ints(rows[0],4);require(-10**6<=l<=r<=10**6 and -10**6<=d<=u<=10**6,'range');return l,r,d,u
 if pid=='abc450_d':
  n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=10**9 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=x<=10**9 for x in a),'values');return k,a
 if pid=='abc451_d':
  require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=power_domain_max(),'implicit rank domain');return (n,)
 if pid=='abc452_d':
  require(len(rows)==2 and 1<=len(rows[0])<=200000 and 1<=len(rows[1])<=50 and all(re.fullmatch('[a-z]+',row) is not None for row in rows),'strings');return rows[0],rows[1]
 if pid=='abc453_d':
  h,w=ints(rows[0],2);require(1<=h<=1000 and 1<=w<=1000 and len(rows)==h+1,'shape');grid=tuple(rows[1:]);require(all(len(row)==w and re.fullmatch('[#.oxSG]+',row) is not None for row in grid),'grid');joined=''.join(grid);require(joined.count('S')==joined.count('G')==1,'endpoints');return h,w,grid
 t=ints(rows[0],1)[0];require(1<=t<=300000 and len(rows)==2*t+1,'shape');require(sum(map(len,rows[1:]))<=2000000 and all(1<=len(row)<=2000000 and re.fullmatch(r'[()x]+',row) is not None for row in rows[1:]),'strings');return (tuple(zip(rows[1::2],rows[2::2])),)

def square_even_rings(l:int,r:int,d:int,u:int)->int:
 def area(radius:int)->int:return max(0,min(r,radius)-max(l,-radius)+1)*max(0,min(u,radius)-max(d,-radius)+1)
 answer=0
 for radius in range(0,max(abs(l),abs(r),abs(d),abs(u))+1,2):answer+=area(radius)-area(radius-1)
 return answer
def residue_span_feasibility(k:int,a:tuple[int,...])->int:
 values=sorted(set(x%k for x in a));n=len(values);doubled=values+[x+k for x in values]
 def feasible(span:int)->bool:
  right=0
  for left in range(n):
   while right<left+n and doubled[right]-doubled[left]<=span:right+=1
   if right-left==n:return True
  return False
 low=0;high=k-1
 while low<high:
  mid=(low+high)//2
  if feasible(mid):high=mid
  else:low=mid+1
 return low
def subsequence_latest_start(s:str,t:str)->int:
 positions:dict[str,list[int]]={}
 for j,ch in enumerate(t):positions.setdefault(ch,[]).append(j)
 latest=[-1]*len(t);answer=0
 for i,ch in enumerate(s):
  for j in reversed(positions.get(ch,[])):latest[j]=i if j==0 else latest[j-1]
  answer+=i-latest[-1]
 return answer
STEPS=((-1,0),(1,0),(0,-1),(0,1));DIRECTIONS='UDLR'
def reverse_movement(h:int,w:int,grid:tuple[str,...])->str|None:
 cells=''.join(grid);goal=cells.index('G');start=cells.index('S');successor=array('i',[-1])*(4*h*w);queue=deque()
 for direction in range(4):state=4*goal+direction;successor[state]=state;queue.append(state)
 while queue:
  state=queue.popleft();cell,direction=divmod(state,4);y,x=divmod(cell,w);dy,dx=STEPS[direction];py,px=y-dy,x-dx
  if not(0<=py<h and 0<=px<w):continue
  previous=py*w+px;kind=cells[previous]
  if kind=='#':continue
  for entry in range(4):
   if kind=='o' and entry!=direction or kind=='x' and entry==direction:continue
   old=4*previous+entry
   if successor[old]<0:successor[old]=state;queue.append(old)
 candidates=[4*start+d for d in range(4) if successor[4*start+d]>=0]
 if not candidates:return None
 state=candidates[0];out=[]
 while state//4!=goal:state=successor[state];out.append(DIRECTIONS[state%4])
 return ''.join(out)
def movement_valid(raw:str,actual:str)->bool:
 h,w,grid=cast(tuple[int,int,tuple[str,...]],validate('abc453_d',raw));rows=actual.removesuffix('\n').split('\n')
 if rows==['No']:return reverse_movement(h,w,grid) is None
 if len(rows)!=2 or rows[0]!='Yes' or not 1<=len(rows[1])<=5000000 or re.fullmatch('[UDLR]+',rows[1]) is None:return False
 cells=''.join(grid);cell=cells.index('S');previous=-1
 for ch in rows[1]:
  direction=DIRECTIONS.index(ch);kind=cells[cell]
  if kind=='o' and direction!=previous or kind=='x' and direction==previous:return False
  y,x=divmod(cell,w);dy,dx=STEPS[direction];y+=dy;x+=dx
  if not(0<=y<h and 0<=x<w) or cells[y*w+x]=='#':return False
  cell=y*w+x;previous=direction
 return cells[cell]=='G'
def rewrite_linked(text:str)->str:
 n=len(text);previous=list(range(-1,n-1));following=list(range(1,n+1));alive=bytearray(b'\1')*n;queue=deque(i for i,ch in enumerate(text) if ch=='(')
 while queue:
  i=queue.popleft()
  if not alive[i]:continue
  j=following[i]
  if j>=n or text[j]!='x':continue
  k=following[j]
  if k>=n or text[k]!='x':continue
  end=following[k]
  if end>=n or text[end]!=')':continue
  left=previous[i];right=following[end];alive[i]=alive[end]=0;previous[j]=left;following[k]=right
  if left>=0:following[left]=j
  if right<n:previous[right]=k
  pivot=j
  for _ in range(3):
   pivot=previous[pivot]
   if pivot<0:break
   if text[pivot]=='(':queue.append(pivot)
 return ''.join(ch for i,ch in enumerate(text) if alive[i])
def oracle(pid:str,raw:str)->str:
 data=validate(pid,raw)
 if pid=='abc449_d':return str(square_even_rings(*cast(tuple[int,int,int,int],data)))+'\n'
 if pid=='abc450_d':return str(residue_span_feasibility(*cast(tuple[int,tuple[int,...]],data)))+'\n'
 if pid=='abc451_d':return str(power_unrank(cast(int,data[0])))+'\n'
 if pid=='abc452_d':return str(subsequence_latest_start(*cast(tuple[str,str],data)))+'\n'
 if pid=='abc453_d':
  path=reverse_movement(*cast(tuple[int,int,tuple[str,...]],data));return 'No\n' if path is None else 'Yes\n'+path+'\n'
 return ''.join('Yes\n' if rewrite_linked(a)==rewrite_linked(b) else 'No\n' for a,b in cast(tuple[tuple[str,str],...],data[0]))
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:
  if pid=='abc453_d':return mode in (None,'semantic') and movement_valid(raw,actual)
  return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc449_d':'''l,r,d,u=map(int,input().split())
def evens(a,b):return b//2-(a-1)//2 if a<=b else0
answer=0
for x in range(l,r+1):
 t=abs(x)
 if t%2==0:answer+=max(0,min(u,t)-max(d,-t)+1)
 answer+=evens(d,min(u,-t-1))+evens(max(d,t+1),u)
print(answer)
'''.replace('else0','else 0'),
'abc450_d':'''n,k=map(int,input().split());a=sorted(x%k for x in map(int,input().split()));gap=a[0]+k-a[-1]
for i in range(1,n):gap=max(gap,a[i]-a[i-1])
print(k-gap)
''',
'abc451_d':'''n=int(input());powers=[1<<i for i in range(30)];words=[(p,10**len(str(p))) for p in powers];bylength=[[v for v in words if v[1]<=10**remaining] for remaining in range(10)];seen={0};stack=[(0,0)]
while stack:
 value,length=stack.pop()
 for power,base in bylength[9-length]:
  nxt=value*base+power
  if nxt not in seen:seen.add(nxt);stack.append((nxt,length+len(str(power))))
seen.remove(0);print(sorted(seen)[n-1])
''',
'abc452_d':'''from bisect import bisect_left
def solve():
 s=input();t=input();positions={}
 for i,ch in enumerate(s):positions.setdefault(ch,[]).append(i)
 answer=0;n=len(s)
 for start in range(n):
  nextpos=start
  for ch in t:
   indexes=positions.get(ch,[]);j=bisect_left(indexes,nextpos)
   if j==len(indexes):nextpos=n+1;break
   nextpos=indexes[j]+1
  answer+=nextpos-start-1
 print(answer)
solve()
''',
'abc453_d':'''import sys
from collections import deque
from array import array
def solve():
 r=sys.stdin.buffer;h,w=map(int,r.readline().split());cells=''.join(r.readline().decode().strip() for _ in range(h));size=h*w;start=cells.index('S');goal=cells.index('G');parent=array('i',[-1])*(4*size);queue=deque();push=queue.append;pop=queue.popleft
 for d in range(4):parent[4*start+d]=-2;push(4*start+d)
 end=-1
 while queue:
  state=pop();cell,entry=divmod(state,4)
  if cell==goal:end=state;break
  x=cell%w;kind=cells[cell]
  neighbors=(cell-w if cell>=w else -1,cell+w if cell<size-w else -1,cell-1 if x else -1,cell+1 if x+1<w else -1)
  for d,nextcell in enumerate(neighbors):
   if nextcell<0 or cells[nextcell]=='#' or kind=='o' and d!=entry or kind=='x' and d==entry:continue
   nxt=4*nextcell+d
   if parent[nxt]==-1:parent[nxt]=state;push(nxt)
 if end<0:print('No')
 else:
  out=[]
  while parent[end]>=0:out.append('UDLR'[end%4]);end=parent[end]
  print('Yes');print(''.join(reversed(out)))
solve()
''',
'abc454_d':'''import sys
def normal(text):
 stack=[]
 for ch in text:
  stack.append(ch)
  while len(stack)>=4 and stack[-4:]==['(','x','x',')']:stack[-4:]=['x','x']
 return ''.join(stack)
r=sys.stdin.buffer;t=int(r.readline());out=[]
for _ in range(t):a=r.readline().decode().strip();b=r.readline().decode().strip();out.append('Yes' if normal(a)==normal(b) else 'No')
print('\\n'.join(out))
'''}
def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc449_d':
  raws=[line(v) for v in [(0,0,0,0),(1,1,1,1),(-1,-1,-1,-1),(-2,2,-2,2),(-2,0,0,2),(0,0,-10**6,10**6),(10**6,10**6,-10**6,10**6),(-999999,999999,999999,999999)]]
  while len(raws)<16:
   l,r=sorted((rng.randint(-20,20),rng.randint(-20,20)));d,u=sorted((rng.randint(-20,20),rng.randint(-20,20)));raws.append(line((l,r,d,u)))
  raws +=[line((-10**6,10**6,-1,1)),line((-10**6,10**6,-10**6,10**6))]
 elif pid=='abc450_d':
  def pack(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
  raws=[pack(1,[1]),pack(10**9,[10**9]),pack(5,[1,2]),pack(5,[1,5]),pack(4,[1,2,3,4]),pack(100,[1,101,201]),pack(10**9,[1,10**9]),pack(2,[1,2,3,4])]
  while len(raws)<16:raws.append(pack(rng.randint(1,100),[rng.randint(1,1000) for _ in range(len(raws)+3)]))
  raws +=[pack(10**9,list(range(1,200001))),pack(10**9,[10**9]*200000)]
 elif pid=='abc451_d':
  maximum=power_domain_max();values=[1,2,4,5,10,69,100,1000,1099898,maximum-1]
  while len(values)<17:
   n=rng.randint(1,maximum)
   if n not in values:values.append(n)
  raws=[str(n)+'\n' for n in values+[maximum]]
 elif pid=='abc452_d':
  def pack(s:str,t:str)->str:return s+'\n'+t+'\n'
  raws=[pack('a','a'),pack('a','b'),pack('a','a'*50),pack('aaa','aa'),pack('abc','ac'),pack('abc','ca'),pack('ababa','aba'),pack('abc','z')]
  while len(raws)<16:raws.append(pack(''.join(rng.choice('abc') for _ in range(10+len(raws))),''.join(rng.choice('abc') for _ in range(rng.randint(1,8)))))
  raws +=[pack('a'*200000,'a'*50),pack('z'*200000,'z'*50)]
 elif pid=='abc453_d':
  def pack(grid:list[str])->str:return f'{len(grid)} {len(grid[0])}\n'+'\n'.join(grid)+'\n'
  raws=[pack(['SG']),pack(['S#G']),pack(['SoG']),pack(['SxG']),pack(['Sx','.G']),pack(['So','.G']),pack(['S.x','xxG']),pack(['S#','oG'])]
  while len(raws)<16:
   grid=[[rng.choice('.#ox') for _ in range(7)] for _ in range(6)];grid[0][0]='S';grid[-1][-1]='G';raws.append(pack([''.join(row) for row in grid]))
  raws +=[pack(['S'+'.'*998+'G']+['.'*1000]*999),pack(['S'+'.'*999]+['.'*1000]*998+['.'*999+'G'])]
 else:
  def pack(pairs:list[tuple[str,str]])->str:return str(len(pairs))+'\n'+''.join(a+'\n'+b+'\n' for a,b in pairs)
  raws=[pack([('x','x')]),pack([('(','x')]),pack([('(xx)','xx')]),pack([('((xx))','xx')]),pack([('(x(xx))','(xxx)')]),pack([('xx','(xx)')]),pack([(')xx(','xx')]),pack([('((xx))','(xx)')])]
  while len(raws)<16:raws.append(pack([(''.join(rng.choice('()x') for _ in range(10+len(raws))),''.join(rng.choice('()x') for _ in range(10+len(raws)))) for _ in range(3)]))
  raws[15]=pack([('('*999998+'xxx'+')'*999998,'x')])
  raws +=[pack([('x','x')]*300000),pack([('('*499999+'xx'+')'*499999,'x'*1000000)])]
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i>=15 else 'random'} for i,raw in enumerate(raws)]
HINTS:dict[str,tuple[str,str,str]]={
'abc449_d':('xを固定して、黒くなるyの範囲を考えます。','|y|<=|x|の範囲は|x|が偶数のときだけ黒です。その外側はyが偶数なら黒です。','疑似コード: 各x=L..Rでt=abs(x)。tが偶数なら[D,U]と[-t,t]の重なり個数を加える。下側y<-tと上側y>tの偶数個数も加え、合計を出力。'),
'abc450_d':('Kを足しても、Kで割った余りは変わりません。','余りを円周上の点と考え、最も長い空白区間を除くと残りを覆う幅が最小になります。十分大きい値まで持ち上げればその幅を実現できます。','疑似コード: r=sort(A modK)。gapは隣接差とr[0]+K-r[-1]の最大値。K-gapを出力。'),
'abc451_d':('答えは10^9以下なので、使える2の冪と結合後の桁数は限られます。','9桁以下の結合を列挙し、同じ整数を集合でまとめます。10^9自体は条件を満たしません。','疑似コード: powers=2^0..2^29。stackに空prefixを入れ、9桁を超えない各powerを後ろへ結合。未出なら集合とstackへ追加。空prefixを除きsortしN番目を出力。'),
'abc452_d':('各開始位置から、Tを部分列として含む最短の終了位置を探します。','文字ごとの出現位置を保存し、Tの文字を順に二分探索します。最短の終了位置より前で終わる部分文字列が条件を満たします。','疑似コード: Sの各文字の位置列を作る。各startでnext=start、Tの各文字の最初の位置>=nextを探しnext=位置+1。見つからなければnext=|S|+1。answer+=next-start-1。'),
'abc453_d':('現在地に加えて、直前に移動した方向を状態に持ちます。','oでは同方向のみ、xでは同方向以外へ進めます。状態グラフをBFSして親を保存すると合法経路を復元できます。','疑似コード: Sの4方向状態をqueueへ。各状態からマス条件を満たす隣接非壁状態を訪問しparent保存。Gへ到達しなければNo。他はparentを逆にたどって移動文字列を復元しYesと出力。'),
'abc454_d':('削除する向きの操作(xx)→xxだけで短い標準形を作ります。','この置換は必ず長さを減らし、二つの置換箇所が途中で重なることもありません。したがって標準形は一意です。スタックで末尾の(xx)を縮めます。','疑似コード: normal(S)は文字をstackへ追加し、末尾が(xx)ならxxへ置換する処理を繰り返す。normal(A)==normal(B)ならYes、他はNo。')}

TITLES={'abc449_d': 'Make Target 2', 'abc450_d': 'Minimize Range', 'abc451_d': 'Concat Power of 2', 'abc452_d': 'No-Subsequence Substring', 'abc453_d': 'Go Straight', 'abc454_d': '(xx)'}
PUBLISHED_SAMPLES={'abc449_d': [{'input': '-4 3 1 3\n', 'expected': '10\n'}, {'input': '-14 14 -14 14\n', 'expected': '449\n'}], 'abc450_d': [{'input': '3 10\n3 21 9\n', 'expected': '4\n'}, {'input': '5 6\n4 100 5 10 450\n', 'expected': '2\n'}], 'abc451_d': [{'input': '10\n', 'expected': '21\n'}, {'input': '69\n', 'expected': '328\n'}, {'input': '1099898\n', 'expected': '819264512\n'}], 'abc452_d': [{'input': 'abrakadabra\naba\n', 'expected': '51\n'}, {'input': 'aaaaa\na\n', 'expected': '0\n'}, {'input': 'rdddrdtdcdrrdcredctdordoeecrotet\ndcre\n', 'expected': '263\n'}], 'abc453_d': [{'input': '3 5\n.#...\n.Sooo\n..x.G\n', 'expected': 'Yes\nDRUUDDRR\n'}, {'input': '3 3\n#So\nxoG\n..#\n', 'expected': 'Yes\nDDLURR\n'}, {'input': '2 2\nSo\noG\n', 'expected': 'No\n'}], 'abc454_d': [{'input': '6\n(xx)x\nx(xx)\n(x)x\n(xx)\n)x()x(\n)x()x(\nx\n(x)\n(((((xx)))))x\nx((((((((((xx))))))))))\n((xx)xx)xx\n(x((xx))x)(xx)\n', 'expected': 'Yes\nNo\nYes\nNo\nYes\nYes\n'}]}
SAMPLE_COUNTS={'abc449_d': 2, 'abc450_d': 2, 'abc451_d': 3, 'abc452_d': 3, 'abc453_d': 3, 'abc454_d': 1}
