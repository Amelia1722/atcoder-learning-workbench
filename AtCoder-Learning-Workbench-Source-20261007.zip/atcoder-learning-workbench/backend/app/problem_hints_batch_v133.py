"""Statement-checked three-stage hints for ABC257–259 B."""
HINTS_V133 = {
 'abc257_b': (
  '操作で指定されるのは「左から何番目の駒か」です。駒同士は追い越さないので、配列中の順番は最後まで変わりません。',
  '指定された駒がNにいるなら停止です。そうでなければ、次の駒がちょうど1つ右にいる場合だけ動けません。それ以外なら位置を1増やします。',
  '疑似コード:\npos = A のコピー\nfor l in L:\n  i = l-1\n  if pos[i] == N: continue\n  if i+1 < K and pos[i]+1 == pos[i+1]: continue\n  pos[i] += 1\nprint(pos)',
 ),
 'abc258_b': (
  '開始マスと進む方向を決めると、通るN個のマスは一意に決まります。上下左右だけでなく斜めも含めて8方向あります。',
  '盤面の端を越えたら反対側へ戻るので、行・列をそれぞれNで割った余りにします。N≤10なので全N^2×8通りをそのまま試せます。',
  '疑似コード:\nans = 0\nfor 各開始(i,j):\n  for (di,dj) in 8方向:\n    value = 0\n    for t = 0 .. N-1:\n      r = (i + di*t) mod N\n      c = (j + dj*t) mod N\n      value = value*10 + A[r][c]\n    ans = max(ans, value)\nprint(ans)',
 ),
 'abc259_b': (
  '2次元の回転公式を使います。角度d度をラジアンに直して、cosとsinで新しい座標を表せます。',
  '反時計回り回転では x\' = a cosθ - b sinθ、y\' = a sinθ + b cosθ です。θ=d×π/180 とします。',
  '疑似コード:\ntheta = d * pi / 180\nx = a*cos(theta) - b*sin(theta)\ny = a*sin(theta) + b*cos(theta)\nprint(x, y)',
 ),
}
