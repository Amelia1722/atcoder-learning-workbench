"""Evidence-bound backfill for ABC026–028 B; public statements checked."""
HINTS_BACKFILL_V70 = {
    'abc026_b': (
        '半径の順番は入力順とは限りません。外側から赤・白・赤…と塗るので、まず半径を大きい順に見ます。',
        '半径を降順に並べ、面積の係数R^2を `+,-,+,-,...` と交互に足し引きし、最後にπを掛けます。',
        '''疑似コード:\nR=sort_descending(R)\ncoef=0\nfor i,r in enumerate(R):\n  if i is even: coef += r*r\n  else: coef -= r*r\nprint(coef*pi)''',
    ),
    'abc027_b': (
        '全島を同人数にできるには、まず総人数がNで割り切れる必要があります。橋を架けない境界をどこに置けるか考えてください。',
        '平均をavgとすると、左からi島までの人数合計がavg*iになる地点では、そこで連結成分を区切れます。区切れない境界には橋が必要です。',
        '''疑似コード:\ntotal=sum(A)\nif total%N!=0: print(-1); stop\navg=total//N\nprefix=0; bridges=0\nfor i in 1..N-1:\n  prefix += A[i]\n  if prefix != avg*i: bridges += 1\nprint(bridges)''',
    ),
    'abc028_b': (
        '必要なのはA〜Fそれぞれの出現回数です。文字列を左から1回数えれば足ります。',
        '6文字ぶんのカウンタを用意するか、各文字についてcountして、A,B,C,D,E,Fの順に出力します。',
        '''疑似コード:\ncount={A:0,B:0,C:0,D:0,E:0,F:0}\nfor ch in S:\n  count[ch]+=1\nprint(count[A],count[B],count[C],count[D],count[E],count[F])''',
    ),
}
