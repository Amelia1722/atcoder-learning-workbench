"""ABC215–217 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import itertools
import re

TASKS = ('abc215_b', 'abc216_b', 'abc217_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]{1,10}', re.ASCII)
CONTESTS = ('ABC', 'ARC', 'AGC', 'AHC')
PUBLISHED_SAMPLES = {
    'abc215_b': [
        {'input': '6\n', 'expected': '2\n'},
        {'input': '1\n', 'expected': '0\n'},
        {'input': '1000000000000000000\n', 'expected': '59\n'},
    ],
    'abc216_b': [
        {'input': '3\ntanaka taro\nsato hanako\ntanaka taro\n', 'expected': 'Yes\n'},
        {'input': '3\nsaito ichiro\nsaito jiro\nsaito saburo\n', 'expected': 'No\n'},
        {'input': '4\nsypdgidop bkseq\nbajsqz hh\nozjekw mcybmtt\nqfeysvw dbo\n', 'expected': 'No\n'},
    ],
    'abc217_b': [
        {'input': 'ARC\nAGC\nAHC\n', 'expected': 'ABC\n'},
        {'input': 'AGC\nABC\nARC\n', 'expected': 'AHC\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    return raw[:-1].split('\n')


def _validate215(raw: str) -> int:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or POS.fullmatch(lines[0]) is None:
        raise ValueError('N syntax')
    n = int(lines[0])
    if not 1 <= n <= 10**18:
        raise ValueError('N range')
    return n


def _validate216(raw: str) -> tuple[tuple[str, str], ...]:
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N syntax')
    n = int(lines[0])
    if not 2 <= n <= 1000 or len(lines) != n + 1:
        raise ValueError('shape/N')
    rows: list[tuple[str, str]] = []
    for line in lines[1:]:
        parts = line.split(' ')
        if len(parts) != 2 or any(LOWER.fullmatch(x) is None for x in parts):
            raise ValueError('name row')
        rows.append((parts[0], parts[1]))
    return tuple(rows)


def _validate217(raw: str) -> tuple[str, str, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 3 or any(x not in CONTESTS for x in lines) or len(set(lines)) != 3:
        raise ValueError('contest rows')
    return lines[0], lines[1], lines[2]


def validate(pid: str, raw: str):
    if pid == 'abc215_b':
        return _validate215(raw)
    if pid == 'abc216_b':
        return _validate216(raw)
    if pid == 'abc217_b':
        return _validate217(raw)
    raise ValueError('unknown task')


def _ans215(n: int) -> int:
    return n.bit_length() - 1


def _ans216(rows: tuple[tuple[str, str], ...]) -> str:
    return 'Yes' if len(set(rows)) < len(rows) else 'No'


def _ans217(rows: tuple[str, str, str]) -> str:
    return next(x for x in CONTESTS if x not in rows)


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or '\n' in output or output != output.strip():
        return False
    if pid == 'abc215_b':
        return NONNEG.fullmatch(output) is not None and int(output) == _ans215(value)
    if pid == 'abc216_b':
        return output in {'Yes', 'No'} and output == _ans216(value)
    if pid == 'abc217_b':
        return output in CONTESTS and output == _ans217(value)
    return False


def _letters(i: int) -> str:
    s = ''
    while True:
        s = chr(ord('a') + i % 26) + s
        i = i // 26 - 1
        if i < 0:
            return s


def _case216(rows: list[tuple[str, str]]) -> str:
    return str(len(rows)) + '\n' + ''.join(f'{s} {t}\n' for s, t in rows)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    if pid == 'abc215_b':
        # The official third sample is the maximum input, so reserve it for the final constraint_max case.
        for i, row in enumerate(PUBLISHED_SAMPLES[pid][:2], 1):
            add(f'sample{i}', row['input'])
        vals = [
            ('pow1', '2\n'), ('between1', '3\n'), ('pow2', '4\n'), ('between2', '7\n'),
            ('pow3', '8\n'), ('between3', '15\n'), ('pow4', '16\n'), ('below_pow5', '31\n'),
            ('pow5', '32\n'), ('above_pow5', '33\n'), ('below_pow10', '1023\n'), ('pow10', '1024\n'),
            ('pow20', '1048576\n'), ('pow40', '1099511627776\n'), ('pow59', '576460752303423488\n'),
        ]
        for category, raw in vals:
            add(category, raw)
        add('constraint_max', '1000000000000000000\n')
    elif pid == 'abc216_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        cases = [
            ('n2_same', [('a', 'b'), ('a', 'b')]),
            ('n2_same_family_only', [('a', 'b'), ('a', 'c')]),
            ('n2_same_given_only', [('a', 'b'), ('c', 'b')]),
            ('duplicate_adjacent', [('alice', 'x'), ('alice', 'x'), ('bob', 'y')]),
            ('duplicate_far', [('a', 'a'), ('b', 'b'), ('c', 'c'), ('a', 'a')]),
            ('triple_duplicate', [('x', 'y'), ('x', 'y'), ('x', 'y')]),
            ('all_unique_same_family', [('same', 'a'), ('same', 'b'), ('same', 'c'), ('same', 'd')]),
            ('all_unique_same_given', [('a', 'same'), ('b', 'same'), ('c', 'same'), ('d', 'same')]),
            ('length10_names', [('abcdefghij', 'jihgfedcba'), ('abcdefghij', 'abcdefghij')]),
            ('case_sensitive_domain_lower', [('abc', 'def'), ('abcd', 'ef')]),
            ('n10_duplicate_end', [('s', _letters(i)) for i in range(9)] + [('s', 'a')]),
            ('n20_unique', [('s', _letters(i)) for i in range(20)]),
            ('n100_duplicate_middle', [('s', _letters(i)) for i in range(99)] + [('s', _letters(50))]),
            ('n500_unique', [('s', _letters(i)) for i in range(500)]),
        ]
        for category, rows in cases:
            add(category, _case216(rows))
        max_rows = [('s', _letters(i)) for i in range(999)] + [('s', 'a')]
        add('constraint_max', _case216(max_rows))
    else:
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        reserved = 'AHC\nAGC\nARC\n'
        for perm in itertools.permutations(CONTESTS, 3):
            raw = '\n'.join(perm) + '\n'
            if raw == reserved or raw in seen:
                continue
            add('permutation', raw)
            if len(out) == 17:
                break
        add('constraint_max', reserved)
    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
