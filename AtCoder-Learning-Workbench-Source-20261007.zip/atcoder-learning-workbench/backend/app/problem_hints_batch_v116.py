"""Statement-checked three-stage hints for ABC206–208 B."""
HINTS_V116 = {
    'abc206_b': (
        'i日目までに貯まる金額は1+2+...+iです。N以上になる最初の日を探します。',
        '毎日dayを1増やしてそのday円を累積額へ足し、累積額がN以上になった時点で止めれば十分です。N<=10^9でも必要日数は約4.5万日です。',
        '''疑似コード:
day = 0
money = 0
while money < N:
  day += 1
  money += day
print(day)''',
    ),
    'abc207_b': (
        'x回操作した後、水色はA+B*x個、赤色はC*x個です。目標条件を式にしてください。',
        'A+B*x <= C*D*x を変形すると A <= (C*D-B)*x です。C*D-B<=0なら不可能、正ならAをその値で割った切り上げが最小回数です。',
        '''疑似コード:
gain = C * D - B
if gain <= 0:
  print(-1)
else:
  answer = ceil(A / gain)
  print(answer)''',
    ),
    'abc208_b': (
        '大きい額面の硬貨ほど、小さい階乗硬貨をまとめたものに対応します。まず10!円から使えるだけ使うことを考えます。',
        '10!,9!,...,1!の順に、残額からその硬貨を使える最大枚数だけ使います。(k+1)!=(k+1)*k!なので、この貪欲法で最小枚数になります。',
        '''疑似コード:
answer = 0
for coin in [10!, 9!, ..., 1!]:
  use = P // coin
  answer += use
  P %= coin
print(answer)''',
    ),
}
