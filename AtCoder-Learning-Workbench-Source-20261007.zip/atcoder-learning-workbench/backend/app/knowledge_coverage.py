from __future__ import annotations

import hashlib
import re
import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class AliasRule:
    pattern: re.Pattern[str]
    queries: tuple[str, ...]


@dataclass(frozen=True)
class AnchorRule:
    pattern: re.Pattern[str]
    anchors: tuple[str, ...]


def _r(pattern: str, *queries: str) -> AliasRule:
    return AliasRule(re.compile(pattern, re.I), queries)


def _a(pattern: str, *anchors: str) -> AnchorRule:
    return AnchorRule(re.compile(pattern, re.I), anchors)


# High-confidence tag -> canonical Knowledge anchors.  These are intentionally
# evaluated before free-text matching so short tags such as LIS, SCC, set, DP,
# or mod cannot accidentally match unrelated prose fragments.
ANCHOR_RULES: tuple[AnchorRule, ...] = (
    _a(r"^implementation$", "chap-21"),
    _a(r"^ad.?hoc$", "sec-28-11"),
    _a(r"^graph$", "chap-23"),
    _a(r"^tree$", "sec-8-7"),
    _a(r"^math$|^number theory$", "chap-26"),
    _a(r"^string$", "chap-25"),
    _a(r"^simulation$", "sec-28-9"),
    _a(r"^(?:BFS)$", "sec-7-2"),
    _a(r"^(?:DFS)$", "sec-7-5"),
    _a(r"^(?:BFS/DFS|DFS/BFS)$", "sec-23-1"),
    _a(r"multi-source BFS|各始点BFS", "sec-7-3"),
    _a(r"最短経路数", "sec-37-16"),
    _a(r"状態付きBFS|トグル状態", "sec-7-4"),
    _a(r"0-1 BFS|グリッド上の0/1", "sec-7-8"),
    _a(r"Dijkstra|状態をグラフ化して非負重み最短路", "sec-7-7"),
    _a(r"multi-source Dijkstra", "sec-37-1"),
    _a(r"Warshall-Floyd|Floyd-Warshall|冗長辺判定", "sec-7-9"),
    _a(r"SCC|cycle抽出", "sec-23-7"),
    _a(r"トポロジカル", "sec-7-10"),
    _a(r"Kruskal|MST|不要辺の除去", "sec-7-11"),
    _a(r"Union-Find|MST / Union|連結成分", "sec-7-6"),
    _a(r"weighted / potentialized DSU", "sec-22-11"),
    _a(r"Euler Tour", "sec-23-12"),
    _a(r"LCA|木距離", "sec-23-11"),
    _a(r"rerooting|全頂点を根|木の距離和", "sec-23-14"),
    _a(r"Low-Link|articulation", "sec-23-17"),
    _a(r"Bipartite Matching", "sec-23-22"),
    _a(r"Max Flow", "sec-23-20"),
    _a(r"Min Cost Flow|Cost Flow", "sec-23-21"),
    _a(r"min-cut|頂点容量変換|グリッド選択|勝敗割当", "sec-37-2"),
    _a(r"3次元dominance", "sec-37-3"),
    _a(r"Link-Cut Tree", "sec-23-28"),
    _a(r"Static Top Tree", "sec-23-29"),
    _a(r"Matroid Intersection|Matroid", "sec-23-26"),

    _a(r"^DP$|状態DP|到達可能DP|少数状態DP|数え上げDP|選択個数を状態|遷移の圧縮|制約ごとに解法", "sec-8-1"),
    _a(r"ナップサック|部分和DP", "sec-8-3"),
    _a(r"メモ化再帰", "sec-8-5"),
    _a(r"bit DP|状態に訪問集合|使用済み集合", "sec-8-6"),
    _a(r"^Tree DP$", "sec-23-13"),
    _a(r"木DP|子の状態を親|次数制約付き辺選択|木上の累積", "sec-8-7"),
    _a(r"Digit DP|桁DP|使用数字集合", "sec-24-11"),
    _a(r"Probability DP|確率DP|確率分布|確率遷移", "sec-24-16"),
    _a(r"2次元区間DP|再帰分割", "sec-24-3"),
    _a(r"LIS", "sec-10-3"),
    _a(r"括弧列", "sec-37-6"),
    _a(r"平均|中央値|割合", "sec-37-5"),
    _a(r"同値一括更新DP|値順sort", "sec-37-4"),
    _a(r"小さいTop-K", "sec-37-7"),

    _a(r"順序付き数え上げ", "sec-37-17"),
    _a(r"Fenwick|2次元順序数え上げ|転倒数|複数Fenwick|行列クエリ", "sec-10-1"),
    _a(r"Segment Tree / Lazy|Lazy Segment Tree|Lazy的|区間分類更新", "sec-22-3"),
    _a(r"Segment Tree|GCD range query", "sec-10-2"),
    _a(r"Persistent Segment Tree|Persistent", "sec-22-12"),
    _a(r"Cartesian Tree", "sec-22-16"),
    _a(r"Mo's algorithm|Mo系|offline range query|3要素数え上げ|区間頻度", "sec-22-6"),
    _a(r"^stack$|単調stack|各要素1 push|pop", "sec-10-4"),
    _a(r"heapq|priority queue|K番目管理|全体offset", "sec-1-6"),
    _a(r"deque|削除せずindex移動|遅延反転", "sec-1-5"),
    _a(r"set|重複判定", "sec-1-3"),
    _a(r"dict|Counter|出現回数|初出管理|頻度|頻度管理|頻度表", "sec-37-14"),
    _a(r"sort|区間ソート", "sec-1-7"),
    _a(r"bisect", "sec-1-8"),
    _a(r"順序付き集合|predecessor|successor|順序管理", "sec-5-3"),
    _a(r"座標圧縮", "sec-5-2"),
    _a(r"イベントソート|日別イベント|sweep", "sec-5-4"),
    _a(r"オフライン処理|offline processing|offline query|クエリ順", "sec-10-5"),
    _a(r"逆向き処理|削除を逆順", "sec-10-6"),
    _a(r"Meet-in-the-Middle|グリッドXOR", "sec-10-8"),

    _a(r"(?<!2次元)累積和|prefix sum|prefix状態の頻度|剰余prefix|ペア和", "sec-4-1"),
    _a(r"prefix/suffix|prefix最小値|suffixカウント|prefix連結", "sec-4-3"),
    _a(r"imos|差分配列", "sec-4-4"),
    _a(r"差分更新|各クエリで変わる1項|挿入で影響|ペア数の差分|変化する対象", "sec-4-5"),
    _a(r"固定長sliding window|固定長window", "sec-4-6"),
    _a(r"two pointers|尺取り|sliding window", "sec-4-7"),
    _a(r"答えで二分探索|答え二分探索|binary search|二分探索", "sec-5-1"),
    _a(r"2次元累積和|区間条件を前計算", "sec-4-2"),
    _a(r"2次元→1次元化", "sec-11-1"),

    _a(r"bit全探索|bitmask|bitで区切り|行/列のbit", "sec-3-2"),
    _a(r"permutations|全順列|順列順位|文字→数字の単射", "sec-1-9"),
    _a(r"product的|二択全探索", "sec-1-9"),
    _a(r"全探索|中心全探索|制約を利用した全探索|単調列の全探索", "sec-3-1"),
    _a(r"バックトラッキング|経路全探索|枝刈り", "sec-20-2"),
    _a(r"計算量|1回走査|必要イベントだけ数える", "sec-0-1"),
    _a(r"償却計算量", "sec-20-5"),
    _a(r"探索空間変更|経路列挙→訪問区間", "sec-20-7"),

    _a(r"Functional Graph|cycleへ到達|周期性|周期$|巡回|サイクル", "sec-37-11"),
    _a(r"doubling|巨大回数", "sec-9-2"),
    _a(r"順列と逆順列", "sec-12-3"),

    _a(r"gcd|lcm|約数列挙|素因数|素数ペア", "sec-6-2"),
    _a(r"エラトステネス|多数の素数", "sec-6-3"),
    _a(r"mod|剰余|逆元", "sec-6-4"),
    _a(r"XOR linear basis|XOR線形", "sec-26-19"),
    _a(r"XOR", "sec-6-5"),
    _a(r"10進数|8進数|26進数|進数", "sec-6-6"),
    _a(r"組合せmod|階乗前計算", "sec-18-13"),
    _a(r"組合せ|ペア数", "sec-6-7"),
    _a(r"CRT|中国剰余定理", "sec-26-9"),
    _a(r"乗法的位数", "sec-26-16"),
    _a(r"Matrix Exponentiation|matrix exponentiation", "sec-26-17"),
    _a(r"Matrix-Tree|Kirchhoff|Directed Matrix-Tree", "sec-26-28"),
    _a(r"Generating Functions|FPS|Kinoshita", "sec-26-30"),
    _a(r"determinant", "sec-26-27"),
    _a(r"鳩ノ巣", "sec-26-14"),
    _a(r"包除|補集合", "sec-20-9"),

    _a(r"Trie|prefix関係の期待値", "sec-25-5"),
    _a(r"禁止文字列automaton", "sec-25-6"),
    _a(r"Suffix Array", "sec-25-7"),
    _a(r"LCP", "sec-25-8"),
    _a(r"Z Algorithm", "sec-25-2"),
    _a(r"ランレングス", "sec-2-2"),
    _a(r"文字列の正規化|平行移動正規化|正規化|不変量", "sec-12-2"),
    _a(r"文字列$", "sec-25-1"),

    _a(r"グリッド$|グラフ化|状態をグラフ化", "sec-37-15"),
    _a(r"グリッドBFS", "sec-7-2"),
    _a(r"グリッド回転", "sec-2-3"),
    _a(r"座標変換", "sec-37-13"),
    _a(r"幾何", "chap-27"),

    _a(r"greedy|貪欲|コスト最小化|総和判定", "sec-12-1"),
    _a(r"場合分け|条件整合性|矛盾検出", "sec-28-10"),
    _a(r"simulation|行列シミュレーション", "sec-28-9"),
    _a(r"対称性除去", "sec-20-8"),
    _a(r"辞書順", "sec-21-8"),
    _a(r"クエリ$", "sec-37-8"),
    _a(r"割当$", "sec-37-9"),
    _a(r"色制約", "sec-37-10"),
    _a(r"独立性", "sec-37-12"),
)


# Remaining phrase aliases. These are used after canonical anchors but before
# unstructured text search.
ALIAS_RULES: tuple[AliasRule, ...] = (
    _r(r"DP軸選択", "DPの状態設計", "Meet-in-the-Middle"),
    _r(r"prefix関係の期待値", "Trie", "Probability DP"),
    _r(r"次数の前計算", "隣接リスト", "Counter"),
    _r(r"添字変換", "座標圧縮", "dict"),
    _r(r"剰余状態", "mod演算"),
    _r(r"行列クエリ", "Fenwick Tree"),
    _r(r"LCM", "gcd / lcm"),
)

GENERIC_RULES: tuple[AliasRule, ...] = (
    _r(r"^dp$|dynamic programming", "DPの状態設計"),
    _r(r"graph", "グラフ・木"),
    _r(r"tree", "Tree DP", "木DP"),
    _r(r"greedy", "貪欲法"),
    _r(r"math|number theory", "数学・数論・組合せ"),
    _r(r"string", "文字列アルゴリズム"),
    _r(r"data structure|^ds$", "高度データ構造"),
    _r(r"binary search", "二分探索"),
    _r(r"brute force|enumeration", "全探索"),
    _r(r"two pointer|sliding window", "尺取り法", "sliding window"),
    _r(r"prefix sum", "累積和"),
    _r(r"union.?find|dsu", "Union-Find"),
    _r(r"dijkstra", "Dijkstra"),
    _r(r"bfs", "BFS"),
    _r(r"dfs", "DFS"),
    _r(r"segment tree", "Segment Tree"),
    _r(r"fenwick|bit tree", "Fenwick Tree"),
    _r(r"flow|matching", "Max Flow", "Matching"),
    _r(r"geometry", "幾何"),
    _r(r"combin", "組合せ"),
    _r(r"bitmask|bit mask", "bit全探索", "bit DP"),
    _r(r"simulation|implementation", "シミュレーション", "Python実装"),
    _r(r"sort", "sort / sorted"),
    _r(r"heap|priority queue", "heapq"),
    _r(r"ad.?hoc", "Ad-Hoc"),
)

BAD_GENERIC_HEADINGS = {
    "Python実装", "典型ミス・注意", "ロジック化", "まず考える愚直解", "重要",
    "典型", "応用", "見抜くサイン", "最大値", "問題文のサイン",
}


def canonical_anchors(tag: str) -> list[str]:
    out: list[str] = []
    for rule in ANCHOR_RULES:
        if rule.pattern.search(tag.strip()):
            out.extend(rule.anchors)
    return list(dict.fromkeys(out))


def candidate_queries(tag: str) -> list[str]:
    tag = tag.strip()
    out: list[str] = []
    for rule in ALIAS_RULES + GENERIC_RULES:
        if rule.pattern.search(tag):
            out.extend(rule.queries)
    return list(dict.fromkeys(out))


def _latin_short(query: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9+_.-]{1,5}", query.strip()))


def _query_match_score(query: str, heading: str, level: int) -> tuple[int, int, int]:
    q = query.strip().casefold()
    h = heading.strip().casefold()
    if h == q:
        rel = 0
    elif _latin_short(query):
        rel = 1 if re.search(rf"(?<![A-Za-z0-9]){re.escape(q)}(?![A-Za-z0-9])", h, re.I) else 4
    elif q in h:
        rel = 1
    else:
        rel = 3
    level_score = 0 if level == 2 else (1 if level == 1 else 2)
    generic = 1 if heading.strip() in BAD_GENERIC_HEADINGS else 0
    return (rel, generic, level_score)


def _find_sections(con: sqlite3.Connection, query: str, limit: int = 4) -> list[sqlite3.Row]:
    # Fetch a wider candidate set, then rank in Python. SQLite LIKE makes short
    # ASCII tokens case-insensitive (e.g. LIS matched "list"), which caused bad
    # Related Knowledge links in older versions.
    pat = f"%{query}%"
    rows = con.execute(
        """
        SELECT anchor,heading,chapter,importance,level,body_markdown
        FROM knowledge_sections
        WHERE heading LIKE ? OR search_text LIKE ?
        LIMIT 80
        """,
        (pat, pat),
    ).fetchall()
    return sorted(rows, key=lambda r: (_query_match_score(query, r["heading"], int(r["level"])), -len(r["body_markdown"] or "")))[:limit]


def _fallback_anchor(tag: str) -> str:
    digest = hashlib.sha1(tag.encode("utf-8")).hexdigest()[:12]
    return f"auto-tag-{digest}"


def _ensure_fallback_section(con: sqlite3.Connection, tag: str) -> str:
    anchor = _fallback_anchor(tag)
    problem_rows = con.execute(
        """
        SELECT p.contest_id,p.problem_index,p.title
        FROM tags t JOIN problems p ON p.problem_id=t.problem_id
        WHERE t.tag=?
        ORDER BY p.contest_id DESC,p.problem_index
        LIMIT 8
        """,
        (tag,),
    ).fetchall()
    examples = "\n".join(
        f"- {r['contest_id'].upper()} {r['problem_index']}: {r['title']}" for r in problem_rows
    ) or "- 現在のローカルDBでは例題を取得できませんでした。"
    body = "**重要度:** 要監査\n\n"
    body += f"タグ `{tag}` に対応する既存Knowledgeを自動監査した結果、確実に対応すると断定できる節が見つかりませんでした。\n\n"
    body += "### 関連問題\n" + examples + "\n\n"
    body += "### 注意\nこれは未監査タグの索引であり、一般化された知識項目としての完成版ではありません。Knowledge Coverage Auditではfallbackとして失敗扱いにします。"
    search = f"タグ監査 {tag} {tag.lower()} " + " ".join(r["title"] for r in problem_rows)
    con.execute(
        """
        INSERT OR REPLACE INTO knowledge_sections(anchor,heading,level,chapter,importance,body_markdown,search_text)
        VALUES(?,?,?,?,?,?,?)
        """,
        (anchor, f"未監査タグ: {tag}", 2, "37. タグ対応で不足していた実戦知識", "要監査", body, search),
    )
    return anchor


def _valid_anchor(con: sqlite3.Connection, anchor: str) -> bool:
    return con.execute("SELECT 1 FROM knowledge_sections WHERE anchor=?", (anchor,)).fetchone() is not None


def _ensure_knowledge_link_schema(con: sqlite3.Connection) -> None:
    """Create the knowledge-link migration objects for older user databases.

    v0.4.9 may be applied as a patch on top of an older installation whose
    database.py/SQLite schema predates knowledge_tag_links.  Do not require
    users to delete their DB; migrate it in place before the first rebuild.
    """
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS knowledge_tag_links (
          tag TEXT NOT NULL,
          anchor TEXT NOT NULL REFERENCES knowledge_sections(anchor) ON DELETE CASCADE,
          source TEXT NOT NULL,
          rank INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(tag, anchor)
        )
        """
    )
    con.execute(
        "CREATE INDEX IF NOT EXISTS idx_knowledge_tag_links_tag ON knowledge_tag_links(tag)"
    )


def rebuild_knowledge_tag_links(con: sqlite3.Connection) -> dict[str, int]:
    _ensure_knowledge_link_schema(con)
    con.execute("DELETE FROM knowledge_tag_links")
    con.execute("DELETE FROM knowledge_sections WHERE anchor LIKE 'auto-tag-%'")
    tags = [r[0] for r in con.execute("SELECT DISTINCT tag FROM tags ORDER BY tag")]
    linked = 0
    fallback = 0
    for tag in tags:
        anchors = [a for a in canonical_anchors(tag) if _valid_anchor(con, a)]
        source = "canonical"
        if not anchors:
            source = "alias"
            for q in candidate_queries(tag):
                for row in _find_sections(con, q, 4):
                    if row["anchor"] not in anchors:
                        anchors.append(row["anchor"])
                if anchors:
                    break
        if not anchors:
            source = "exact"
            for row in _find_sections(con, tag, 6):
                if row["anchor"] not in anchors:
                    anchors.append(row["anchor"])
        if not anchors:
            source = "fallback"
            anchors = [_ensure_fallback_section(con, tag)]
            fallback += 1
        for rank, anchor in enumerate(anchors[:4]):
            con.execute(
                "INSERT OR REPLACE INTO knowledge_tag_links(tag,anchor,source,rank) VALUES(?,?,?,?)",
                (tag, anchor, source, rank),
            )
            linked += 1
    return {"tags": len(tags), "links": linked, "fallback": fallback}


def audit_knowledge_coverage(con: sqlite3.Connection) -> dict:
    tags = [r[0] for r in con.execute("SELECT DISTINCT tag FROM tags ORDER BY tag")]
    missing: list[str] = []
    fallback: list[str] = []
    weak: list[dict] = []
    for tag in tags:
        rows = con.execute(
            """
            SELECT l.source,l.rank,k.anchor,k.heading,k.level,k.body_markdown
            FROM knowledge_tag_links l
            JOIN knowledge_sections k ON k.anchor=l.anchor
            WHERE l.tag=? ORDER BY l.rank,k.rowid
            """,
            (tag,),
        ).fetchall()
        if not rows:
            missing.append(tag)
            continue
        first = rows[0]
        if first["source"] == "fallback":
            fallback.append(tag)
        if first["heading"] in BAD_GENERIC_HEADINGS or int(first["level"]) > 2:
            weak.append({"tag": tag, "heading": first["heading"], "anchor": first["anchor"], "source": first["source"]})
    return {
        "tags": len(tags),
        "covered": len(tags) - len(missing) - len(fallback),
        "missing": missing,
        "fallback": fallback,
        "weak": weak,
        "ok": not missing and not fallback and not weak,
    }


def linked_knowledge(con: sqlite3.Connection, tags: list[str], limit: int = 20) -> list[dict]:
    if not tags:
        return []
    hits: dict[str, dict] = {}
    for tag in tags[:12]:
        rows = con.execute(
            """
            SELECT k.anchor,k.heading,k.chapter,k.importance,l.rank
            FROM knowledge_tag_links l
            JOIN knowledge_sections k ON k.anchor=l.anchor
            WHERE l.tag=?
            ORDER BY l.rank,k.rowid
            LIMIT 8
            """,
            (tag,),
        ).fetchall()
        for row in rows:
            hits.setdefault(row["anchor"], {
                "anchor": row["anchor"], "heading": row["heading"],
                "chapter": row["chapter"], "importance": row["importance"],
            })
    return list(hits.values())[:limit]
