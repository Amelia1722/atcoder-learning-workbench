from __future__ import annotations
from bisect import bisect_right
from math import isqrt
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in (296,297,298,300,301,302));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...];MOD=998244353

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid in ('abc296_d','abc297_d'):
  require(len(r)==1,'rows');a,b=ints(r[0],2);bound=10**12 if pid=='abc296_d' else 10**18;require(1<=a<=bound and 1<=b<=bound,'bound');return a,b
 if pid=='abc298_d':
  q=ints(r[0],1)[0];require(1<=q<=600000 and len(r)==q+1,'Q');queries=tuple(ints(s) for s in r[1:]);length=1;printed=False
  for row in queries:
   require(row[0] in (1,2,3) and len(row)==(2 if row[0]==1 else 1),'query')
   if row[0]==1:require(1<=row[1]<=9,'digit');length+=1
   elif row[0]==2:require(length>=2,'nonempty');length-=1
   else:printed=True
  require(printed,'query3 exists');return (queries,)
 if pid=='abc300_d':require(len(r)==1,'rows');n=ints(r[0],1)[0];require(300<=n<=10**12,'N');return (n,)
 if pid=='abc301_d':require(len(r)==2 and re.fullmatch(r'[01?]{1,60}',r[0]) is not None,'S');n=ints(r[1],1)[0];require(1<=n<=10**18,'N');return r[0],n
 n,m,d=ints(r[0],3);require(1<=n<=200000 and 1<=m<=200000 and 0<=d<=10**18 and len(r)==3,'shape');a=ints(r[1],n);b=ints(r[2],m);require(all(1<=x<=10**18 for x in a+b),'values');return d,a,b

def quotient_plateau_product(n:int,m:int)->int:
 if n*n<m:return -1
 low=(m+n-1)//n;high=min(n,isqrt(m)+1);best=n*n;a=low
 while a<=high:
  quotient=(m-1)//a;best=min(best,a*(quotient+1));a=min(high,(m-1)//quotient if quotient else high)+1
 return best

def euclidean_quotient_total(a:int,b:int)->int:
 total=0
 while b:q,r=divmod(a,b);total+=q;a,b=b,r
 return total-1

def decimal_prefix_history(queries:tuple[tuple[int,...],...])->list[int]:
 prefix=[0,1];powers=[1,10];head=0;out=[]
 for row in queries:
  if row[0]==1:prefix.append((prefix[-1]*10+row[1])%MOD);powers.append(powers[-1]*10%MOD)
  elif row[0]==2:head+=1
  else:out.append((prefix[-1]-prefix[head]*powers[len(prefix)-1-head])%MOD)
 return out

def euler_primes(limit:int)->list[int]:
 composite=bytearray(limit+1);primes=[]
 for value in range(2,limit+1):
  if not composite[value]:primes.append(value)
  for p in primes:
   multiple=p*value
   if multiple>limit:break
   composite[multiple]=1
   if value%p==0:break
 return primes

def count_middle_small_primes(n:int)->int:
 primes=euler_primes(isqrt(n//12));answer=0
 # c is fixed, enumerate legal middle b and count smaller a from a^2<=N/(bc^2).
 for ci in range(2,len(primes)):
  c=primes[ci];bound=n//(c*c);stop=min(ci,bisect_right(primes,bound//4))
  for bi in range(1,stop):
   b=primes[bi];answer+=min(bi,bisect_right(primes,isqrt(bound//b)))
 return answer

def binary_tight_states(s:str,n:int)->int:
 bound=min(n,(1<<len(s))-1);digits=f'{bound:0{len(s)}b}';states={True:0}
 for char,limit in zip(s,digits):
  updated={}
  for tight,value in states.items():
   for bit in (0,1):
    if char!='?' and bit!=int(char):continue
    if tight and bit>int(limit):continue
    next_tight=tight and bit==int(limit);updated[next_tight]=max(updated.get(next_tight,-1),value*2+bit)
  states=updated
 return max(states.values(),default=-1)

def gifts_by_upper_bound(d:int,a:tuple[int,...],b:tuple[int,...])->int:
 sorted_b=sorted(b);best=-1
 for x in a:
  index=bisect_right(sorted_b,x+d)-1
  if index>=0 and sorted_b[index]>=x-d:best=max(best,x+sorted_b[index])
 return best

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc296_d':return str(quotient_plateau_product(cast(int,d[0]),cast(int,d[1])))+'\n'
 if pid=='abc297_d':return str(euclidean_quotient_total(cast(int,d[0]),cast(int,d[1])))+'\n'
 if pid=='abc298_d':return ''.join(str(v)+'\n' for v in decimal_prefix_history(cast(tuple[tuple[int,...],...],d[0])))
 if pid=='abc300_d':return str(count_middle_small_primes(cast(int,d[0])))+'\n'
 if pid=='abc301_d':return str(binary_tight_states(cast(str,d[0]),cast(int,d[1])))+'\n'
 return str(gifts_by_upper_bound(cast(int,d[0]),cast(tuple[int,...],d[1]),cast(tuple[int,...],d[2])))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.split()==oracle(pid,raw).split() and all(re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s) is not None for s in actual.split())
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc296_d':'''from math import isqrt
n,m=map(int,input().split());answer=None
for a in range(1,min(n,isqrt(m)+1)+1):
 b=(m+a-1)//a
 if b<=n:answer=a*b if answer is None else min(answer,a*b)
print(-1 if answer is None else answer)
''',
'abc297_d':'''a,b=map(int,input().split());answer=0
while a!=b:
 if a<b:a,b=b,a
 count=(a-1)//b;answer+=count;a-=count*b
print(answer)
''',
'abc298_d':'''from collections import deque
import sys
q=int(input());digits=deque([1]);value=1;mod=998244353;powers=[1]*(q+2)
for i in range(1,q+2):powers[i]=powers[i-1]*10%mod
out=[]
for _ in range(q):
 row=list(map(int,input().split()))
 if row[0]==1:digits.append(row[1]);value=(value*10+row[1])%mod
 elif row[0]==2:value=(value-digits.popleft()*powers[len(digits)])%mod
 else:out.append(str(value))
print('\\n'.join(out))
''',
'abc300_d':'''from math import isqrt
from bisect import bisect_right
n=int(input());limit=isqrt(n//12);mark=bytearray(b'\\x01')*(limit+1);mark[:2]=b'\\x00\\x00'
for p in range(2,isqrt(limit)+1):
 if mark[p]:mark[p*p:limit+1:p]=b'\\x00'*((limit-p*p)//p+1)
primes=[p for p in range(2,limit+1) if mark[p]];answer=0
for i,a in enumerate(primes):
 if i+2>=len(primes) or a*a*primes[i+1]*primes[i+2]**2>n:break
 for j in range(i+1,len(primes)-1):
  b=primes[j];bound=isqrt(n//(a*a*b))
  if bound<=b:break
  answer+=bisect_right(primes,bound)-j-1
print(answer)
''',
'abc301_d':'''s=input();n=int(input());answer=int(s.replace('?','0'),2)
if answer>n:print(-1)
else:
 for i,c in enumerate(s):
  bit=1<<(len(s)-1-i)
  if c=='?' and answer+bit<=n:answer+=bit
 print(answer)
''',
'abc302_d':'''n,m,d=map(int,input().split());a=sorted(map(int,input().split()));b=sorted(map(int,input().split()));i=n-1;j=m-1;answer=-1
while i>=0 and j>=0:
 if abs(a[i]-b[j])<=d:answer=a[i]+b[j];break
 if a[i]>b[j]:i-=1
 else:j-=1
print(answer)
'''}

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(195000+int(pid[3:6]));raws=[]
 if pid=='abc296_d':
  pairs=[(1,1),(1,2),(2,4),(3,8),(5,25),(5,26),(10**12,1),(1,10**12)]
  pairs.extend((rng.randrange(1,1000000),rng.randrange(1,10**12+1)) for _ in range(8));pairs.extend(((999983,999983**2),(10**12,10**12)));raws=[line(p) for p in pairs]
 elif pid=='abc297_d':
  pairs=[(1,1),(1,2),(2,1),(10**18,1),(1,10**18),(10**18,10**18-1),(2**59,2**58),(7540113804746346429//8,4660046610375530309//8)]
  pairs.extend((rng.randrange(1,10**18+1),rng.randrange(1,10**18+1)) for _ in range(8));pairs.extend(((10**18-1,10**18-3),(10**18,10**18)));raws=[line(p) for p in pairs]
 elif pid=='abc298_d':
  def queries(a:list[tuple[int,...]])->str:return str(len(a))+'\n'+''.join(line(row) for row in a)
  raws=[queries([(3,)]),queries([(1,9),(2,),(3,)]),queries([(1,2),(1,3),(3,),(2,),(3,)]),queries([(1,9)]*30+[(3,)]+[(2,)]*30+[(3,)])]
  for j in range(12):
   a=[];length=1
   for _ in range(10+j*10):
    mode=rng.randrange(1,4)
    if mode==2 and length==1:mode=1
    row=(1,rng.randrange(1,10)) if mode==1 else (mode,);a.append(row);length+=(mode==1)-(mode==2)
   a.append((3,));raws.append(queries(a))
  raws[-1]=queries([(1,9)]*599999+[(3,)])
  raws.append(queries([(1,9)]*299999+[(3,)]+[(2,)]*299999+[(3,)]));raws.append(queries([(1,1)]*8+[(3,)]*599992))
 elif pid=='abc300_d':
  ns=[300,301,2999,3000,1000,10**6,10**9,10**10]
  ns.extend(rng.randrange(300,10**12+1) for _ in range(8));ns.extend((10**12-1,10**12));raws=[str(n)+'\n' for n in ns]
 elif pid=='abc301_d':
  pairs=[('0',1),('1',1),('?',1),('10',1),('?0?',4),('?'*60,10**18),('1'*60,10**18),('0'*60,1)]
  pairs.extend((''.join(rng.choice('01?') for _ in range(j+3)),rng.randrange(1,10**18+1)) for j in range(8));pairs.extend((('?'*59+'1',10**18),('?'*59+'0',10**18)));raws=[s+'\n'+str(n)+'\n' for s,n in pairs]
 else:
  def gifts(d:int,a:list[int],b:list[int])->str:return line((len(a),len(b),d))+line(a)+line(b)
  raws=[gifts(0,[1],[1]),gifts(0,[1],[2]),gifts(10**18,[1],[10**18]),gifts(1,[3,8],[5,7])]
  for j in range(12):raws.append(gifts(rng.randrange(10**18+1),[rng.randrange(1,10**18+1) for _ in range(j+2)],[rng.randrange(1,10**18+1) for _ in range(j+3)]))
  raws.append(gifts(0,list(range(1,200001)),list(range(200001,400001))));raws.append(gifts(10**18,[10**18]*200000,[10**18]*200000))
 require(len(raws)==len(set(raws))==18,'18 distinct');cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02d}'})
 return cases
HINTS={
'abc296_d':('積a*b>=Mとなる組のうち、一方を小さい方として固定しましょう。','aを固定すると必要な最小bはceil(M/a)です。最適な組の小さい方はceil(sqrt(M))まで調べれば十分です。b<=Nとなる候補だけ比較します。','疑似コード: answer=なし。a=1..min(N,isqrt(M)+1)でb=(M+a-1)//a。b<=Nならanswer=min(answer,a*b)。候補がなければ-1。'),
'abc297_d':('大きい方から小さい方を、まとめて何回引けるか考えましょう。','大きいaからbを引き過ぎて0にしないよう、(a-1)//b回を一度に行えます。ユークリッド互除法と同じように数が小さくなります。','疑似コード: count=0。a!=bの間、a<bならswapしq=(a-1)//b,count+=q,a-=q*b。等しくなった時のcountを出力。'),
'abc298_d':('数字列の先頭削除と末尾追加に対応できるdequeを使います。','末尾追加はvalue*10+xです。先頭削除は、その数字に10の桁数乗を掛けた値を引きます。全計算を998244353で割った余りにします。','疑似コード: digits=[1],value=1,pow10をQ+1まで前計算。追加xはdeque末尾へ,value=(value*10+x)%MOD。削除はd=先頭pop後、value=(value-d*pow10[len(digits)])%MOD。query3でvalueを出力。'),
'abc300_d':('素数a,bを固定すると、素数cの上限を計算できます。','a²*b*c²<=Nよりc<=isqrt(N//(a²*b))です。c>bという条件を加え、素数列の二分探索で候補数をまとめて数えます。','疑似コード: sqrt(N/12)まで素数を篩う。a<bを順に調べlimit=isqrt(N//(a*a*b))。limit<=bなら内側break。それ以外はupper_bound(primes,limit)-bのindex-1を加える。最小の次のb,cでも積>Nなら外側break。'),
'abc301_d':('?を全て0に置いた最小の値が、N以下かを先に確認しましょう。','最小値がNを超えるなら解はありません。そうでなければ上位の?から、Nを超えない時だけ1にすると最大値になります。','疑似コード: answer=int(Sの?を0へ置換,2)。answer>Nなら-1。そうでなければ左から?の桁weightを調べanswer+weight<=Nなら加算。最後answerを出力。'),
'abc302_d':('両方の候補をソートし、大きいものから比較しましょう。','最大候補同士の差がD以下ならその和が最大です。差が大きい場合、大きい方の値は残りの相手とも組めないため捨てます。','疑似コード: A,Bをsortしi=N-1,j=M-1。両index>=0の間、abs(A[i]-B[j])<=Dなら和を出力し終了。A[i]>B[j]ならi--、他j--。尽きたら-1。')}

TITLES={'abc296_d': 'M<=ab', 'abc297_d': 'Count Subtractions', 'abc298_d': 'Writing a Numeral', 'abc300_d': 'AABCC', 'abc301_d': 'Bitmask', 'abc302_d': 'Impartial Gift'}
PUBLISHED_SAMPLES={'abc296_d': [{'input': '5 7\n', 'expected': '8\n'}, {'input': '2 5\n', 'expected': '-1\n'}, {'input': '100000 10000000000\n', 'expected': '10000000000\n'}], 'abc297_d': [{'input': '3 8\n', 'expected': '4\n'}, {'input': '1234567890 1234567890\n', 'expected': '0\n'}, {'input': '1597 987\n', 'expected': '15\n'}], 'abc298_d': [{'input': '3\n3\n1 2\n3\n', 'expected': '1\n12\n'}, {'input': '3\n1 5\n2\n3\n', 'expected': '5\n'}, {'input': '11\n1 9\n1 9\n1 8\n1 2\n1 4\n1 4\n1 3\n1 5\n1 3\n2\n3\n', 'expected': '0\n'}], 'abc300_d': [{'input': '1000\n', 'expected': '3\n'}, {'input': '1000000000000\n', 'expected': '2817785\n'}], 'abc301_d': [{'input': '?0?\n2\n', 'expected': '1\n'}, {'input': '101\n4\n', 'expected': '-1\n'}, {'input': '?0?\n1000000000000000000\n', 'expected': '5\n'}], 'abc302_d': [{'input': '2 3 2\n3 10\n2 5 15\n', 'expected': '8\n'}, {'input': '3 3 0\n1 3 3\n6 2 7\n', 'expected': '-1\n'}, {'input': '1 1 1000000000000000000\n1000000000000000000\n1000000000000000000\n', 'expected': '2000000000000000000\n'}, {'input': '8 6 1\n2 5 6 5 2 1 7 9\n7 2 5 5 2 4\n', 'expected': '14\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
