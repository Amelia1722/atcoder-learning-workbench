"""ABC006 B: locally reviewed recurrence and independent matrix-power oracle.

The problem description and three samples were checked on the public AtCoder page;
that review is not equivalent to authenticating an archived HTML response.
"""
from __future__ import annotations

import re

PID = 'abc006_2'
MOD = 10007
MAX_N = 1_000_000


def validate(pid: str, raw: str) -> int:
    if pid != PID or not isinstance(raw, str) or not re.fullmatch(r'[1-9][0-9]*\n', raw, re.ASCII):
        raise ValueError('invalid task or input format')
    n = int(raw[:-1])
    if not 1 <= n <= MAX_N:
        raise ValueError('n out of official stated range')
    return n


def matmul(a: tuple[tuple[int, ...], ...], b: tuple[tuple[int, ...], ...]) -> tuple[tuple[int, ...], ...]:
    """3x3 matrix multiplication modulo MOD; no calls to reference solver."""
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(3)) % MOD for j in range(3)) for i in range(3))


def independent_answer(pid: str, raw: str) -> str:
    n = validate(pid, raw)
    if n <= 3:
        return str((0, 0, 1)[n-1])
    base = ((1, 1, 1), (1, 0, 0), (0, 1, 0))
    result = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    exponent = n - 3
    while exponent:
        if exponent & 1:
            result = matmul(result, base)
        base = matmul(base, base)
        exponent >>= 1
    return str(result[0][0])


def independent_check(pid: str, raw: str, output: str) -> bool:
    return isinstance(output, str) and output == independent_answer(pid, raw)


def generate(pid: str) -> list[dict[str, str]]:
    if pid != PID:
        raise ValueError('unknown problem')
    ns = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 100, 1000, 10000, 100000, 1000000]
    return [{'category': 'minimum' if n == 1 else 'constraint_max' if n == MAX_N else
             'boundary' if n in (2, 3, 4, 100000) else 'normal', 'input': f'{n}\n'} for n in ns]
