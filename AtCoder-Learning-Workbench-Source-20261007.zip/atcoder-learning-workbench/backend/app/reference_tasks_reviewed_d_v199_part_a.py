"""Private ABC371..376 D domains, independent oracles and output contracts."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import deque
from decimal import Decimal,DecimalException,localcontext
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(371,377));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc373_d':'semantic','abc374_d':'numeric_tolerance_1e-6'};CHECKER_IDS={'abc373_d':'abc373_d'};Case=dict[str,str];Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integer fields');values=tuple(map(int,row.split()));require(count is None or len(values)==count,'field count');return values
def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def potential_union_find(n:int,edges:tuple[tuple[int,...],...])->list[int]:
 parent=list(range(n));size=[1]*n;delta=[0]*n
 def find(v:int)->tuple[int,int]:
  path=[];u=v;total=0
  while parent[u]!=u:path.append(u);total+=delta[u];u=parent[u]
  remaining=total
  for at in path:old=delta[at];parent[at]=u;delta[at]=remaining;remaining-=old
  return u,total
 for u,v,w in edges:
  u-=1;v-=1;ru,du=find(u);rv,dv=find(v)
  if ru==rv:require(dv-du==w,'potential consistency');continue
  offset=w+du-dv
  if size[ru]<size[rv]:parent[ru]=rv;delta[ru]=-offset;size[rv]+=size[ru]
  else:parent[rv]=ru;delta[rv]=offset;size[ru]+=size[rv]
 return [find(i)[1] for i in range(n)]

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank rows')
 if pid=='abc371_d':
  n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)>=5,'N/rows');x=ints(rows[1],n);p=ints(rows[2],n);q=ints(rows[3],1)[0];require(1<=q<=200000 and len(rows)==q+4,'Q/rows');queries=tuple(ints(row,2) for row in rows[4:]);require(all(-10**9<=v<=10**9 for v in x) and all(a<b for a,b in zip(x,x[1:])) and all(1<=v<=10**9 for v in p) and all(-10**9<=l<=r<=10**9 for l,r in queries),'values');return x,p,queries
 if pid=='abc372_d':
  n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==2,'N/rows');h=ints(rows[1],n);require(set(h)==set(range(1,n+1)),'height permutation');return (h,)
 if pid=='abc373_d':
  n,m=ints(rows[0],2);require(2<=n<=200000 and 1<=m<=min(200000,n*(n-1)//2) and len(rows)==m+1,'N/M/rows');edges=tuple(ints(row,3) for row in rows[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v and abs(w)<=10**9 for u,v,w in edges) and len({tuple(sorted((u,v))) for u,v,w in edges})==m,'edges');potential_union_find(n,edges);return n,edges
 if pid=='abc374_d':
  n,s,t=ints(rows[0],3);require(1<=n<=6 and 1<=t<=s<=1000 and len(rows)==n+1,'N/S/T/rows');segments=tuple(ints(row,4) for row in rows[1:]);require(all(all(-1000<=v<=1000 for v in seg) and seg[:2]!=seg[2:] for seg in segments),'segments');return s,t,segments
 if pid=='abc375_d':require(len(rows)==1 and re.fullmatch(r'[A-Z]{1,200000}',rows[0]) is not None,'string');return (rows[0],)
 n,m=ints(rows[0],2);require(2<=n<=200000 and 1<=m<=min(200000,n*(n-1)//2) and len(rows)==m+1,'N/M/rows');edges=tuple(ints(row,2) for row in rows[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in edges) and len({tuple(sorted((u,v))) for u,v in edges})==m,'edges');return n,edges

def villages_offline_sweep(x:tuple[int,...],p:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 events=sorted([(l-1,i,-1) for i,(l,r) in enumerate(queries)]+[(r,i,1) for i,(l,r) in enumerate(queries)]);answer=[0]*len(queries);at=0;total=0
 for coordinate,index,sign in events:
  while at<len(x) and x[at]<=coordinate:total+=p[at];at+=1
  answer[index]+=sign*total
 return answer

def buildings_previous_greater_ranges(h:tuple[int,...])->list[int]:
 stack:list[int]=[];difference=[0]*(len(h)+1)
 for j,height in enumerate(h):
  while stack and h[stack[-1]]<height:stack.pop()
  start=stack[-1] if stack else 0
  if start<j:difference[start]+=1;difference[j]-=1
  stack.append(j)
 total=0;answer=[]
 for value in difference[:-1]:total+=value;answer.append(total)
 return answer

def laser_subset_decimal(s:int,t:int,segments:tuple[tuple[int,...],...])->Decimal:
 with localcontext() as context:
  context.prec=80;n=len(segments);ends=[(seg[0],seg[1]) for seg in segments]+[(seg[2],seg[3]) for seg in segments]
  def distance(a:tuple[int,int],b:tuple[int,int])->Decimal:return Decimal((a[0]-b[0])**2+(a[1]-b[1])**2).sqrt()
  travel=[[distance(a,b)/s for b in ends] for a in ends];origin=[distance((0,0),point)/s for point in ends];print_time=sum((distance(ends[i],ends[i+n])/t for i in range(n)),Decimal(0));dp:dict[tuple[int,int],Decimal]={}
  for i in range(n):dp[1<<i,i]=origin[i+n];dp[1<<i,i+n]=origin[i]
  for mask in range(1,1<<n):
   for end in range(2*n):
    cost=dp.get((mask,end))
    if cost is None:continue
    for i in range(n):
     if mask>>i&1:continue
     for start,finish in ((i,i+n),(i+n,i)):
      key=(mask|1<<i,finish);candidate=cost+travel[end][start]
      if key not in dp or candidate<dp[key]:dp[key]=candidate
  return min(dp[(1<<n)-1,end] for end in range(2*n))+print_time

def palindrome_endpoints(s:str)->int:
 counts=[0]*26;positions=[0]*26;answer=0
 for k,char in enumerate(s):
  key=ord(char)-65;answer+=counts[key]*(k-1)-positions[key];counts[key]+=1;positions[key]+=k
 return answer

def cycle_reverse_bfs(n:int,edges:tuple[tuple[int,...],...])->int:
 reverse:list[list[int]]=[[] for _ in range(n)];out=[]
 for u,v in edges:reverse[v-1].append(u-1)
 for u,v in edges:
  if u==1:out.append(v-1)
 distance=[-1]*n;distance[0]=0;queue=deque([0])
 while queue:
  v=queue.popleft()
  for u in reverse[v]:
   if distance[u]<0:distance[u]=distance[v]+1;queue.append(u)
 return min((1+distance[v] for v in out if distance[v]>=0),default=-1)

def potentials_valid(n:int,edges:tuple[tuple[int,...],...],actual:str)->bool:
 tokens=actual.split()
 if len(tokens)!=n or any(re.fullmatch(r'[+-]?[0-9]+',token) is None for token in tokens):return False
 values=list(map(int,tokens));return all(abs(value)<=10**18 for value in values) and all(values[v-1]-values[u-1]==w for u,v,w in edges)

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc371_d':return ''.join(str(value)+'\n' for value in villages_offline_sweep(*cast(tuple[tuple[int,...],tuple[int,...],tuple[tuple[int,...],...]],d)))
 if pid=='abc372_d':return line(buildings_previous_greater_ranges(cast(tuple[int,...],d[0])))
 if pid=='abc373_d':return line(potential_union_find(*cast(tuple[int,tuple[tuple[int,...],...]],d)))
 if pid=='abc374_d':return str(laser_subset_decimal(*cast(tuple[int,int,tuple[tuple[int,...],...]],d)))+'\n'
 if pid=='abc375_d':return str(palindrome_endpoints(cast(str,d[0])))+'\n'
 return str(cycle_reverse_bfs(*cast(tuple[int,tuple[tuple[int,...],...]],d)))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc373_d':return potentials_valid(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1]),actual)
  if pid=='abc374_d':
   tokens=actual.split()
   if len(tokens)!=1 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',tokens[0]) is None:return False
   with localcontext() as context:
    context.prec=90;value=Decimal(tokens[0])
    if not value.is_finite() or value.adjusted()>100:return False
    expected=laser_subset_decimal(*cast(tuple[int,int,tuple[tuple[int,...],...]],d));error=abs(value-expected);tolerance=Decimal('0.000001');return error<=tolerance or error<=abs(expected)*tolerance
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError,DecimalException):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={
'abc371_d':'''from bisect import bisect_left,bisect_right
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);x=[next(it) for _ in range(n)];p=[next(it) for _ in range(n)];pref=[0]
for v in p:pref.append(pref[-1]+v)
q=next(it);out=[]
for _ in range(q):l=next(it);r=next(it);out.append(str(pref[bisect_right(x,r)]-pref[bisect_left(x,l)]))
print('\\n'.join(out))
''',
'abc372_d':'''n=int(input());h=list(map(int,input().split()));stack=[];answer=[0]*n
for i in range(n-1,-1,-1):
 answer[i]=len(stack)
 while stack and stack[-1]<h[i]:stack.pop()
 stack.append(h[i])
print(*answer)
''',
'abc373_d':'''from collections import deque
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);graph=[[] for _ in range(n)]
for _ in range(m):u=next(it)-1;v=next(it)-1;w=next(it);graph[u].append((v,w));graph[v].append((u,-w))
values=[None]*n
for root in range(n):
 if values[root] is not None:continue
 values[root]=0;q=deque([root])
 while q:
  u=q.popleft()
  for v,w in graph[u]:
   if values[v] is None:values[v]=values[u]+w;q.append(v)
print(*values)
''',
'abc374_d':'''from itertools import permutations,product
from math import hypot
n,s,t=map(int,input().split());segments=[tuple(map(int,input().split())) for _ in range(n)];drawing=sum(hypot(a-c,b-d)/t for a,b,c,d in segments);answer=float('inf')
for order in permutations(range(n)):
 for orientations in product((0,1),repeat=n):
  x=y=0;cost=drawing
  for i,reverse in zip(order,orientations):
   a,b,c,d=segments[i]
   if reverse:a,b,c,d=c,d,a,b
   cost+=hypot(x-a,y-b)/s;x,y=c,d
  answer=min(answer,cost)
print(f'{answer:.15f}')
''',
'abc375_d':'''from collections import Counter
s=input();left=[0]*26;right=[0]*26
for char in s:right[ord(char)-65]+=1
answer=0
for char in s:
 key=ord(char)-65;right[key]-=1;answer+=sum(a*b for a,b in zip(left,right));left[key]+=1
print(answer)
''',
'abc376_d':'''from collections import deque
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);graph=[[] for _ in range(n)]
for _ in range(m):u=next(it)-1;v=next(it)-1;graph[u].append(v)
distance=[-1]*n;distance[0]=0;queue=deque([0]);answer=-1
while queue:
 u=queue.popleft()
 for v in graph[u]:
  if v==0:answer=distance[u]+1;queue.clear();break
  if distance[v]<0:distance[v]=distance[u]+1;queue.append(v)
 if answer>=0:break
print(answer)
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(199000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc371_d':
  configs=[((0,),(1,),((0,0),)),((-10**9,),(10**9,),((-10**9,-10**9),)),((10**9,),(10**9,),((-10**9,10**9),)),((-1,0,1),(1,2,3),((0,0),(-1,1),(2,2)))]
  for n in range(2,14):
   x=tuple(sorted(rng.sample(range(-10**9,10**9+1),n)));p=tuple(rng.randrange(1,10**9+1) for _ in range(n));queries=tuple(tuple(sorted((rng.randrange(-10**9,10**9+1),rng.randrange(-10**9,10**9+1)))) for _ in range(n));configs.append((x,p,queries))
  configs += [(tuple(range(-10**9,-10**9+200000)),(10**9,)*200000,tuple((v,v) for v in range(-10**9,-10**9+200000))),(tuple(range(10**9-199999,10**9+1)),(10**9,)*200000,((-10**9,10**9),)*200000)]
  raws=[line((len(x),))+line(x)+line(p)+line((len(q),))+''.join(line(v) for v in q) for x,p,q in configs]
 elif pid=='abc372_d':
  arrays=[(1,),(1,2),(2,1),(2,1,3)]
  for n in range(3,15):a=list(range(1,n+1));rng.shuffle(a);arrays.append(tuple(a))
  arrays += [tuple(range(200000,0,-1)),tuple(range(1,200001))];raws=[line((len(a),))+line(a) for a in arrays]
 elif pid=='abc373_d':
  configs=[(2,((1,2,0),)),(2,((2,1,-10**9),)),(3,((1,2,2),(3,2,3),(1,3,-1))),(4,((2,1,5),(3,4,-3)))]
  for n in range(3,15):
   values=[rng.randrange(-500000000,500000001) for _ in range(n)];pairs=rng.sample([(u,v) for u in range(1,n+1) for v in range(u+1,n+1)],min(n,n*(n-1)//2));edges=[]
   for u,v in pairs:
    if rng.randrange(2):u,v=v,u
    edges.append((u,v,values[v-1]-values[u-1]))
   configs.append((n,tuple(edges)))
  configs += [(200000,tuple((i+1,i,-10**9) for i in range(1,200000))),(200000,tuple((1,i,10**9) for i in range(2,200001))+((2,3,0),))];raws=[line((n,len(edges)))+''.join(line(e) for e in edges) for n,edges in configs]
 elif pid=='abc374_d':
  configs=[(1,1,((0,0,1,0),)),(1000,1000,((0,0,1,0),)),(1,1,((-1000,-1000,1000,1000),)),(2,1,((0,0,1,0),(0,0,1,0)))]
  for i in range(12):
   n=2+i%5;s=rng.randrange(1,1001);t=rng.randrange(1,s+1);segments=[]
   for _ in range(n):
    a,b,c,d=(rng.randrange(-1000,1001) for _ in range(4))
    if (a,b)==(c,d):c=1000 if a!=1000 else -1000
    segments.append((a,b,c,d))
   configs.append((s,t,tuple(segments)))
  configs += [(1,1,((-1000,-1000,1000,1000),)*6),(1000,1000,((-1000,-1000,1000,1000),(1000,-1000,-1000,1000),(-1000,0,1000,0),(0,-1000,0,1000),(-1000,-1000,-1000,1000),(1000,-1000,1000,1000)))];raws=[line((len(a),s,t))+''.join(line(v) for v in a) for s,t,a in configs]
 elif pid=='abc375_d':
  values=['A','AA','AAA','ABA','ABC','ABCA']+[''.join(rng.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(n)) for n in range(4,14)]+['ABCDEFGHIJKLMNOPQRSTUVWXYZ'*7692+'ABCDEFGH','A'*200000];raws=[s+'\n' for s in values]
 else:
  configs=[(2,((1,2),)),(3,((1,2),(2,3),(3,1))),(3,((2,3),)),(4,((1,2),(2,3),(3,1),(1,4)))]
  for n in range(4,16):
   pairs=rng.sample([(u,v) for u in range(1,n+1) for v in range(u+1,n+1)],min(n,n*(n-1)//2));edges=tuple((u,v) if rng.randrange(2) else (v,u) for u,v in pairs);configs.append((n,edges))
  configs += [(200000,tuple((i,i+1) for i in range(1,200000))),(200000,tuple((i,i+1) for i in range(1,200000))+((200000,1),))];raws=[line((n,len(edges)))+''.join(line(e) for e in edges) for n,edges in configs]
 require(len(raws)==len(set(raws))==18,'18 distinct');result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result

HINTS:dict[str,tuple[str,str,str]]={
'abc371_d':('座標順の人口の累積和を作ると、連続する村の人数をまとめて求められます。','L以上の最初の村とRより大きい最初の村を二分探索します。端点の村も含めることに注意しましょう。','疑似コード: prefix[0]=0; prefix[i+1]=prefix[i]+P[i]; 各(L,R)で left=lower_bound(X,L),right=upper_bound(X,R); prefix[right]-prefix[left]を出力。'),
'abc372_d':('右側で、それより手前のビルに隠れない高さの記録だけを管理します。','右から走査し、スタックに残るビル数を答えにします。今のビルより低い記録を取り除いてから今の高さを追加します。','疑似コード: stack空; i=N-1..0の順に answer[i]=stack.size; stack.top<H[i]の間pop; H[i]をpush; answerを順に出力。'),
'abc373_d':('各辺は二つの頂点の値の差を指定しています。成分ごとに基準の値を0に置けます。','uからvへ重みw、逆向きには-wの辺を置き、未決定の頂点へ値を伝えます。解の存在保証があるため矛盾しません。','疑似コード: 全頂点を未決定; 未決定rootごとにvalue[root]=0,BFS開始; 辺(u,v,w)で未決定vへvalue[u]+wを入れる; 全valueを出力。各値は単純経路の重み和なので絶対値は(N-1)*1e9以下。'),
'abc374_d':('印字する順序と、各線分のどちらの端点から始めるかを全て試せます。','Nは6以下です。印字中の時間は順序に依存しないため先に足し、端点間の移動時間だけ各候補で比較します。','疑似コード: drawing=sum(length(segment)/T); 全permutationと全2^N方向で現在位置=(0,0),cost=drawing; 各線分の開始端点まで距離/Sを加え、位置を終了端点へ更新; 最小costを出力。'),
'abc375_d':('長さ3の回文は、左右の文字が等しければ成立します。中央の文字は何でもかまいません。','中央の位置を固定し、各文字について左側の個数×右側の個数を加えます。現在の文字を右から除いてから数えましょう。','疑似コード: leftを0,rightをSの文字頻度にする; 各文字cでright[c]--; answer+=sum_x left[x]*right[x]; left[c]++; 最後にanswerを出力。'),
'abc376_d':('頂点1から進むBFSで、初めて頂点1へ戻る辺を見つけた距離が答えです。','最短距離で頂点を訪れ、頂点1への辺は訪問済み判定の前に調べます。到達できない場所の閉路は関係しません。','疑似コード: distance[1]=0,他-1; queue=[1]; popしたuの辺u→vでv==1ならdistance[u]+1を出力して終了; 未訪問vへdistance[u]+1を設定; 探索終了なら-1。')}

TITLES={'abc371_d': '1D Country', 'abc372_d': 'Buildings', 'abc373_d': 'Hidden Weights', 'abc374_d': 'Laser Marking', 'abc375_d': 'ABA', 'abc376_d': 'Cycle'}
PUBLISHED_SAMPLES={'abc371_d': [{'input': '4\n1 3 5 7\n1 2 3 4\n4\n1 1\n2 6\n0 10\n2 2\n', 'expected': '1\n5\n10\n0\n'}, {'input': '7\n-10 -5 -3 -1 0 1 4\n2 5 6 5 2 1 7\n8\n-7 7\n-1 5\n-10 -4\n-8 10\n-5 0\n-10 5\n-8 7\n-8 -3\n', 'expected': '26\n15\n7\n26\n18\n28\n26\n11\n'}], 'abc372_d': [{'input': '5\n2 1 4 3 5\n', 'expected': '3 2 2 1 0\n'}, {'input': '4\n1 2 3 4\n', 'expected': '3 2 1 0\n'}, {'input': '10\n1 9 6 5 2 7 10 4 8 3\n', 'expected': '2 3 3 3 2 1 2 1 1 0\n'}], 'abc373_d': [{'input': '3 3\n1 2 2\n3 2 3\n1 3 -1\n', 'expected': '3 5 2\n'}, {'input': '4 2\n2 1 5\n3 4 -3\n', 'expected': '5 0 6 3\n'}, {'input': '5 7\n2 1 18169343\n3 1 307110901\n4 1 130955934\n2 3 -288941558\n2 5 96267410\n5 3 -385208968\n4 3 -176154967\n', 'expected': '200401298 182231955 -106709603 69445364 278499365\n'}], 'abc374_d': [{'input': '3 2 1\n1 3 2 1\n0 2 0 0\n3 0 2 0\n', 'expected': '6.44317475868633722080\n'}, {'input': '2 1 1\n0 0 10 10\n0 2 2 0\n', 'expected': '20.97056274847714058517\n'}, {'input': '6 3 2\n-1000 -1000 1000 1000\n1000 -1000 -1000 1000\n-1000 -1000 1000 1000\n1000 -1000 -1000 1000\n1000 1000 -1000 -1000\n-1000 1000 1000 -1000\n', 'expected': '9623.35256169626864153344\n'}, {'input': '6 10 8\n1000 1000 -1000 -1000\n1000 -1000 -1000 -1000\n-1000 1000 1000 1000\n-1000 1000 -1000 -1000\n1000 1000 1000 -1000\n1000 -1000 -1000 1000\n', 'expected': '2048.52813742385702910909\n'}], 'abc375_d': [{'input': 'ABCACC\n', 'expected': '5\n'}, {'input': 'OOOOOOOO\n', 'expected': '56\n'}, {'input': 'XYYXYYXYXXX\n', 'expected': '75\n'}], 'abc376_d': [{'input': '3 3\n1 2\n2 3\n3 1\n', 'expected': '3\n'}, {'input': '3 2\n1 2\n2 3\n', 'expected': '-1\n'}, {'input': '6 9\n6 1\n1 5\n2 6\n2 1\n3 6\n4 2\n6 4\n3 5\n5 4\n', 'expected': '4\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
