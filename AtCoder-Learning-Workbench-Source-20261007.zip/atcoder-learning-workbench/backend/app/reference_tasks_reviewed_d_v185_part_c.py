"""Private ABC126--131 D tasks; tree same-color implication is one-way."""
from __future__ import annotations
from array import array
from bisect import bisect_left
from collections import Counter
from typing import cast
import heapq,random,re
TASKS=('abc126_d','abc127_d','abc128_d','abc129_d','abc130_d','abc131_d')
CONTESTS={p:p[:6] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc126_d':'semantic'}
CHECKER_IDS={'abc126_d':'abc126_d'}
Case=dict[str,str]
Data=tuple[object,...]
Edge=tuple[int,int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def tree_parities(n:int,edges:tuple[Edge,...])->list[int]:
    parent=list(range(n));size=[1]*n;xor=[0]*n
    def find(i:int)->tuple[int,int]:
        node=i;parity=0
        while parent[node]!=node:parity^=xor[node];node=parent[node]
        return node,parity
    for u,v,w in edges:
        a,x=find(u-1);b,y=find(v-1);require(a!=b,'tree cycle')
        if size[a]<size[b]:a,b=b,a
        parent[b]=a;xor[b]=x^y^(w%2);size[a]+=size[b]
    return [find(i)[1] for i in range(n)]

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc126_d':
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==n,'tree shape');edges=tuple(cast(Edge,ints(row,3)) for row in rows[1:]);require(all(1<=u<v<=n and 1<=w<=10**9 for u,v,w in edges),'edge bounds');tree_parities(n,edges);return n,edges
    if pid=='abc127_d':
        n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(rows)==m+2,'shape');a=ints(rows[1],n);offers=tuple(ints(row,2) for row in rows[2:]);require(all(1<=v<=10**9 for v in a) and all(1<=b<=n and 1<=c<=10**9 for b,c in offers),'cards/offers');return a,offers
    if pid=='abc128_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=50 and 1<=k<=100 and all(-10**7<=v<=10**7 for v in a),'gems');return k,a
    if pid=='abc129_d':
        h,w=ints(rows[0],2);require(1<=h<=2000 and 1<=w<=2000 and len(rows)==h+1 and all(len(row)==w and set(row)<={'.','#'} for row in rows[1:]) and any('.' in row for row in rows[1:]),'grid');return (tuple(rows[1:]),)
    if pid=='abc130_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=100000 and 1<=k<=10**10 and all(1<=v<=100000 for v in a),'subarrays');return k,a
    n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for pair in a for v in pair),'jobs');return (a,)

def colors_valid(n:int,edges:tuple[Edge,...],actual:str)->bool:
    try:
        rows=actual.removesuffix('\n').split('\n');require(len(rows)==n and all(row in ('0','1') for row in rows),'color lines');parities=tree_parities(n,edges);seen:dict[str,int]={}
        for color,parity in zip(rows,parities):
            if color in seen and seen[color]!=parity:return False
            seen[color]=parity
        return True
    except (ValueError,TypeError,IndexError):return False

def histogram_cards(a:tuple[int,...],offers:tuple[tuple[int,int],...])->int:
    counts=Counter(a)
    for b,c in offers:counts[c]+=b
    heap=[(-value,count) for value,count in counts.items()];heapq.heapify(heap);remaining=len(a);answer=0
    while remaining:
        negative,count=heapq.heappop(heap);take=min(remaining,count);answer-=negative*take;remaining-=take
    return answer

def deque_interval_dp(k:int,a:tuple[int,...])->int:
    # A retained jewel costs one operation; a removed then returned jewel
    # costs two. Returns can all happen after the desired prefix/suffix has
    # been removed, so their final positions need not be stored.
    n=len(a);bad=-10**30;dp=[[[bad]*(k+1) for _ in range(n+1)] for _ in range(n+1)];dp[0][0][0]=0;answer=0
    for left in range(n+1):
        for right in range(n-left+1):
            for moves in range(min(k,2*(left+right))+1):
                value=dp[left][right][moves]
                if value==bad:continue
                answer=max(answer,value)
                if left+right==n or moves==k:continue
                dp[left+1][right][moves+1]=max(dp[left+1][right][moves+1],value+a[left]);dp[left][right+1][moves+1]=max(dp[left][right+1][moves+1],value+a[n-right-1])
                if moves+2<=k:dp[left+1][right][moves+2]=max(dp[left+1][right][moves+2],value);dp[left][right+1][moves+2]=max(dp[left][right+1][moves+2],value)
    return answer

def wall_search(grid:tuple[str,...])->int:
    # Nearest obstacle ranks, independent from reference run-length sweeps.
    h,w=len(grid),len(grid[0]);rows=[array('i',[-1]) for _ in range(h)];cols=[array('i',[-1]) for _ in range(w)]
    for r,row in enumerate(grid):
        for c,ch in enumerate(row):
            if ch=='#':rows[r].append(c);cols[c].append(r)
    for row in rows:row.append(w)
    for col in cols:col.append(h)
    answer=0
    for r,row in enumerate(grid):
        for c,ch in enumerate(row):
            if ch=='.':
                x=bisect_left(rows[r],c);y=bisect_left(cols[c],r);answer=max(answer,rows[r][x]-rows[r][x-1]+cols[c][y]-cols[c][y-1]-3)
    return answer

def prefix_threshold(k:int,a:tuple[int,...])->int:
    prefix=[0]
    for v in a:prefix.append(prefix[-1]+v)
    return sum(len(prefix)-bisect_left(prefix,value+k,j+1) for j,value in enumerate(prefix[:-1]))

def maximum_scheduled(a:tuple[tuple[int,int],...])->int:
    # Moore-Hodgson maximises the number of scheduled jobs: remove the
    # longest chosen job when a deadline is exceeded. All are feasible iff
    # the optimal retained cardinality equals the original job count.
    heap:list[int]=[];total=0
    for duration,deadline in sorted(a,key=lambda p:p[1]):
        heapq.heappush(heap,-duration);total+=duration
        if total>deadline:total+=heapq.heappop(heap)
    return len(heap)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc126_d':return '\n'.join(map(str,tree_parities(*cast(tuple[int,tuple[Edge,...]],data))))
    if pid=='abc127_d':return str(histogram_cards(*cast(tuple[tuple[int,...],tuple[tuple[int,int],...]],data)))
    if pid=='abc128_d':return str(deque_interval_dp(*cast(tuple[int,tuple[int,...]],data)))
    if pid=='abc129_d':return str(wall_search(cast(tuple[str,...],data[0])))
    if pid=='abc130_d':return str(prefix_threshold(*cast(tuple[int,tuple[int,...]],data)))
    jobs=cast(tuple[tuple[int,int],...],data[0]);return 'Yes' if maximum_scheduled(jobs)==len(jobs) else 'No'

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='abc126_d':return colors_valid(*cast(tuple[int,tuple[Edge,...]],data),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc126_d':"n=int(input());g=[[] for _ in range(n)]\nfor _ in range(n-1):u,v,w=map(int,input().split());g[u-1].append((v-1,w));g[v-1].append((u-1,w))\ncolor=[-1]*n;color[0]=0;stack=[0]\nwhile stack:\n u=stack.pop()\n for v,w in g[u]:\n  if color[v]<0:color[v]=(color[u]+w)%2;stack.append(v)\nprint(*color,sep='\\n')\n",
'abc127_d':"n,m=map(int,input().split());a=sorted(map(int,input().split()));offers=[tuple(map(int,input().split())) for _ in range(m)];offers.sort(key=lambda p:p[1],reverse=True);j=0\nfor b,c in offers:\n for _ in range(min(b,n-j)):\n  if a[j]>=c:break\n  a[j]=c;j+=1\n if j==n:break\nprint(sum(a))\n",
'abc128_d':"n,k=map(int,input().split());a=list(map(int,input().split()));answer=0\nfor left in range(min(n,k)+1):\n for right in range(min(n-left,k-left)+1):\n  picked=sorted(a[:left]+(a[n-right:] if right else []));remaining=k-left-right\n  for j in range(min(remaining,len(picked))):\n   if picked[j]<0:picked[j]=0\n  answer=max(answer,sum(picked))\nprint(answer)\n",
'abc129_d':"from array import array\nh,w=map(int,input().split());g=[input() for _ in range(h)];horizontal=array('H',[0])*(h*w)\nfor r in range(h):\n c=0\n while c<w:\n  if g[r][c]=='#':c+=1;continue\n  end=c\n  while end<w and g[r][end]=='.':end+=1\n  for j in range(c,end):horizontal[r*w+j]=end-c\n  c=end\nanswer=0\nfor c in range(w):\n r=0\n while r<h:\n  if g[r][c]=='#':r+=1;continue\n  end=r\n  while end<h and g[end][c]=='.':end+=1\n  for j in range(r,end):answer=max(answer,horizontal[j*w+c]+end-r-1)\n  r=end\nprint(answer)\n",
'abc130_d':"n,k=map(int,input().split());a=list(map(int,input().split()));right=total=answer=0\nfor left in range(n):\n while right<n and total<k:total+=a[right];right+=1\n if total>=k:answer+=n-right+1\n total-=a[left]\nprint(answer)\n",
'abc131_d':"n=int(input());jobs=[tuple(map(int,input().split())) for _ in range(n)];jobs.sort(key=lambda p:p[1]);total=0;possible=True\nfor duration,deadline in jobs:\n total+=duration\n if total>deadline:possible=False;break\nprint('Yes' if possible else 'No')\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18500+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc126_d':
        def tree(n:int,a:list[Edge])->str:return f'{n}\n'+''.join(line(e) for e in a)
        raws=[tree(1,[]),tree(2,[(1,2,1)]),tree(2,[(1,2,2)]),tree(3,[(1,2,2),(2,3,1)])]
        for n in range(4,16):raws.append(tree(n,[(rng.randint(1,j-1),j,rng.randint(1,10**9)) for j in range(2,n+1)]))
        raws+=[tree(100000,[(j,j+1,999999999) for j in range(1,100000)]),tree(100000,[(1,j,10**9) for j in range(2,100001)])]
    elif pid=='abc127_d':
        def cards(a:list[int],offers:list[tuple[int,int]])->str:return f'{len(a)} {len(offers)}\n'+line(a)+''.join(line(p) for p in offers)
        raws=[cards([1],[(1,1)]),cards([1],[(1,10**9)]),cards([10**9],[(1,1)]),cards([1,2],[(2,3),(1,4)])]
        for n in range(3,15):raws.append(cards([rng.randint(1,10**9) for _ in range(n)],[(rng.randint(1,n),rng.randint(1,10**9)) for _ in range(n)]))
        raws+=[cards(list(range(1,100001)),[(1,10**9-j) for j in range(100000)]),cards([10**9]*100000,[(100000,10**9)]*100000)]
    elif pid=='abc128_d':
        def gems(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[gems(1,[0]),gems(1,[-10**7]),gems(1,[10**7]),gems(100,[-10**7]),gems(2,[-1,2]),gems(3,[-6,-100,50,-2,-5,-3])]
        for n in range(2,12):raws.append(gems(rng.randint(1,100),[rng.randint(-10**7,10**7) for _ in range(n)]))
        raws+=[gems(50,[-10**7 if j%2 else 10**7 for j in range(50)]),gems(100,[10**7]*50)]
    elif pid=='abc129_d':
        def grid(a:list[str])->str:return f'{len(a)} {len(a[0])}\n'+'\n'.join(a)+'\n'
        raws=[grid(['.']),grid(['.#']),grid(['.','#']),grid(['#.#','...','#.#'])]
        for n in range(2,14):a=[''.join(rng.choice('.#') for _ in range(n+1)) for _ in range(n)];a[0]='.'+a[0][1:];raws.append(grid(a))
        raws+=[grid([''.join('.' if (r+c)%3 else '#' for c in range(2000)) for r in range(2000)]),grid(['.'*2000]*2000)]
    elif pid=='abc130_d':
        def seq(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[seq(1,[1]),seq(10**10,[100000]),seq(2,[1,1]),seq(3,[1,1])]
        for n in range(3,15):raws.append(seq(rng.randint(1,100000*n),[rng.randint(1,100000) for _ in range(n)]))
        raws+=[seq(1,[100000]*100000),seq(10**10,[100000]*100000)]
    else:
        def jobs(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
        raws=[jobs([(1,1)]),jobs([(2,1)]),jobs([(10**9,10**9)]),jobs([(1,1),(1,2)])]
        for n in range(2,14):raws.append(jobs([(rng.randint(1,100000),rng.randint(1,n*100000)) for _ in range(n)]))
        raws+=[jobs([(1,10**9)]*200000),jobs([(10**9,10**9)]*200000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc126_d':('根からの距離が同じ偶奇なら、その二点間の距離も偶数です。','根を0色として、偶数の辺では同じ色、奇数の辺では反対色にする構成が使えます。全距離が偶数の木では他の塗り分けも正解です。','疑似コード: color[root]=0; DFSで未訪問の隣接vへcolor[v]=(color[u]+w)%2を設定; 全頂点の色を一行ずつ出力。'),
'abc127_d':('大きい値で書き換えられるカードを優先します。','初期カードを昇順、書き換え候補を値Cの降順にします。候補の枚数だけ最小のカードを、値が改善する場合に交換します。','疑似コード: sort(A); offersをC降順sort; j=0; 各(B,C)についてB枚までA[j]<CならA[j]=C,j++; 全N枚更新なら終了; sum(A)を出力。'),
'abc128_d':('取り出す宝石は、元の列の左の何個かと右の何個かです。','左右から取り出す個数を全列挙します。残り操作数の範囲で、取り出した負の宝石を小さいものから戻します。','疑似コード: L+R<=min(N,K)の全L,R; picked=左L個+右R個をsort; budget=K-L-R; 最小側からbudget個まで負値を0にする; pickedの和の最大値（0以上）を出力。'),
'abc129_d':('各空きマスから、横と縦に続く空きマスの長さを求めます。','行ごとの空き区間の長さを保存し、列ごとの空き区間を調べて横長さ+縦長さ-1を比較します。','疑似コード: 各行の連続.区間に区間長をhorizontalとして設定; 各列の連続.区間について区間内各cellのhorizontal+縦区間長-1を比較; 最大値を出力。'),
'abc130_d':('全要素が正なので、区間を右へ伸ばすと和は増えます。','左端を順に動かし、和がK以上になる最小の右端を二つのポインタで求めます。その右端以降は全て有効です。','疑似コード: right=0,total=0; 各leftでtotal<Kの間rightを伸ばす; total>=KならN-right+1を加算; total-=A[left]; 答えを出力。'),
'abc131_d':('締切の早い仕事から終える順序を考えます。','締切順に処理したときに間に合うなら正解です。どこかで締切を超えるなら、その締切以前に必要な総時間が足りません。','疑似コード: jobsをB昇順sort; time=0; 各(A,B)でtime+=A; time>BならNoで終了; 全て満たせばYes。')}

TITLES={'abc126_d': 'Even Relation', 'abc127_d': 'Integer Cards', 'abc128_d': 'equeue', 'abc129_d': 'Lamp', 'abc130_d': 'Enough Array', 'abc131_d': 'Megalomania'}
PUBLISHED_SAMPLES={'abc126_d': [{'input': '3\n1 2 2\n2 3 1\n', 'expected': '0\n0\n1\n'}, {'input': '5\n2 5 2\n2 3 10\n1 3 8\n3 4 2\n', 'expected': '1\n0\n1\n0\n1\n'}], 'abc127_d': [{'input': '3 2\n5 1 4\n2 3\n1 5\n', 'expected': '14\n'}, {'input': '10 3\n1 8 5 7 100 4 52 33 13 5\n3 10\n4 30\n1 4\n', 'expected': '338\n'}, {'input': '3 2\n100 100 100\n3 99\n3 99\n', 'expected': '300\n'}, {'input': '11 3\n1 1 1 1 1 1 1 1 1 1 1\n3 1000000000\n4 1000000000\n3 1000000000\n', 'expected': '10000000001\n'}], 'abc128_d': [{'input': '6 4\n-10 8 2 1 2 6\n', 'expected': '14\n'}, {'input': '6 4\n-6 -100 50 -2 -5 -3\n', 'expected': '44\n'}, {'input': '6 3\n-6 -100 50 -2 -5 -3\n', 'expected': '0\n'}], 'abc129_d': [{'input': '4 6\n#..#..\n.....#\n....#.\n#.#...\n', 'expected': '8\n'}, {'input': '8 8\n..#...#.\n....#...\n##......\n..###..#\n...#..#.\n##....#.\n#...#...\n###.#..#\n', 'expected': '13\n'}], 'abc130_d': [{'input': '4 10\n6 1 2 7\n', 'expected': '2\n'}, {'input': '3 5\n3 3 3\n', 'expected': '3\n'}, {'input': '10 53462\n103 35322 232 342 21099 90000 18843 9010 35221 19352\n', 'expected': '36\n'}], 'abc131_d': [{'input': '5\n2 4\n1 9\n1 8\n4 9\n3 12\n', 'expected': 'Yes\n'}, {'input': '3\n334 1000\n334 1000\n334 1000\n', 'expected': 'No\n'}, {'input': '30\n384 8895\n1725 9791\n170 1024\n4 11105\n2 6\n578 1815\n702 3352\n143 5141\n1420 6980\n24 1602\n849 999\n76 7586\n85 5570\n444 4991\n719 11090\n470 10708\n1137 4547\n455 9003\n110 9901\n15 8578\n368 3692\n104 1286\n3 4\n366 12143\n7 6649\n610 2374\n152 7324\n4 7042\n292 11386\n334 5720\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
