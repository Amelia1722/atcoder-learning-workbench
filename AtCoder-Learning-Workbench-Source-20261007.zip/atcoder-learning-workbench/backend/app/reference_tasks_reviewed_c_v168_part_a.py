"""Reviewed C tasks with trie signatures, prefix DP and semantic insertion positions."""
from __future__ import annotations
from bisect import bisect_right
from itertools import accumulate,combinations
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(279,285))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc280_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==279:
        h,w=ints(rows[0],2);require(h>=1 and w>=1 and h*w<=400000 and len(rows)==2*h+1 and all(len(row)==w and set(row)<={'#','.'} for row in rows[1:]),'grids');return tuple(rows[1:h+1]),tuple(rows[h+1:])
    if number==280:
        require(len(rows)==2,'shape');s,t=rows;require(1<=len(s)<=500000 and len(t)==len(s)+1 and all(re.fullmatch('[a-z]+',v) is not None for v in rows),'strings');i=next((i for i,(a,b) in enumerate(zip(s,t)) if a!=b),len(s));require(t[:i]+t[i+1:]==s,'insertion');return s,t
    if number==281:
        require(len(rows)==2,'shape');n,t=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=100000 and 1<=t<=10**18 and all(1<=v<=10**9 for v in a),'playlist');phase=t%sum(a);require(phase not in set(accumulate(a,initial=0)),'switch instant');return t,a
    if number==282:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(1<=n<=200000 and len(s)==n and re.fullmatch('[a-z,\"]+',s) is not None and s.count('"')%2==0,'delimiters');return (s,)
    if number==283:
        require(len(rows)==1,'shape');s=rows[0];require(re.fullmatch('[1-9][0-9]*',s) is not None and (len(s)<=100000 or s=='1'+'0'*100000),'number');return (s,)
    n,m=ints(rows[0],2);require(1<=n<=100 and 0<=m<=n*(n-1)//2 and len(rows)==m+1,'graph');edges=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges) and len({tuple(sorted(e)) for e in edges})==m,'simple graph');return n,edges

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==279:
        s,t=cast(tuple[tuple[str,...],tuple[str,...]],data);children:list[dict[str,int]]=[{}];counts:list[int]=[0]
        for grid,sign in ((s,1),(t,-1)):
            for col in range(len(grid[0])):
                node=0
                for row in grid:
                    char=row[col]
                    if char not in children[node]:children[node][char]=len(children);children.append({});counts.append(0)
                    node=children[node][char]
                counts[node]+=sign
        return 'Yes' if not any(counts) else 'No'
    if number==280:
        s,t=cast(tuple[str,str],data);suffix=0
        while suffix<len(s) and s[-1-suffix]==t[-1-suffix]:suffix+=1
        return str(len(t)-suffix)
    if number==281:
        t,a=cast(tuple[int,tuple[int,...]],data);prefix=list(accumulate(a,initial=0));phase=t%prefix[-1];j=bisect_right(prefix,phase)-1;return f'{j+1} {phase-prefix[j]}'
    if number==282:
        s=cast(str,data[0]);return '"'.join(part.replace(',','.') if j%2==0 else part for j,part in enumerate(s.split('"')))
    if number==283:
        s=cast(str,data[0]);dp=[0]*(len(s)+1)
        for j,char in enumerate(s,1):dp[j]=min(dp[j-1]+1,dp[j-2]+1) if j>=2 and s[j-2:j]=='00' else dp[j-1]+1
        return str(dp[-1])
    n,edges=cast(tuple[int,tuple[tuple[int,int],...]],data);parent=list(range(n));size=[1]*n;answer=n
    def find(x:int)->int:
        while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
        return x
    for a,b in edges:
        x,y=find(a-1),find(b-1)
        if x==y:continue
        if size[x]<size[y]:x,y=y,x
        parent[y]=x;size[x]+=size[y];answer-=1
    return str(answer)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc280_c':
            s,t=cast(tuple[str,str],validate(pid,raw));token=actual.removesuffix('\n');require(re.fullmatch('[1-9][0-9]{0,5}',token) is not None,'position');j=int(token);return 1<=j<=len(t) and t[:j-1]+t[j:]==s
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc280_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc279_c':"h,w=map(int,input().split());s=[input() for _ in range(h)];t=[input() for _ in range(h)];print('Yes' if sorted(zip(*s))==sorted(zip(*t)) else 'No')\n",
'abc280_c':"s=input();t=input();i=0\nwhile i<len(s) and s[i]==t[i]:i+=1\nprint(i+1)\n",
'abc281_c':"n,t=map(int,input().split());a=list(map(int,input().split()));t%=sum(a)\nfor i,duration in enumerate(a,1):\n if t<duration:print(i,t);break\n t-=duration\n",
'abc282_c':"n=int(input());s=input();inside=False;out=[]\nfor char in s:\n if char=='\"':inside=not inside\n out.append('.' if char==',' and not inside else char)\nprint(''.join(out))\n",
'abc283_c':"s=input();i=answer=0\nwhile i<len(s):\n i+=2 if s[i:i+2]=='00' else 1;answer+=1\nprint(answer)\n",
'abc284_c':"n,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):\n a,b=map(int,input().split());g[a-1].append(b-1);g[b-1].append(a-1)\nseen=set();answer=0\nfor start in range(n):\n if start in seen:continue\n answer+=1;seen.add(start);pending=[start]\n while pending:\n  for nxt in g[pending.pop()]:\n   if nxt not in seen:seen.add(nxt);pending.append(nxt)\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16800+number)
    if number==279:
        def grid(s:list[str],t:list[str])->str:return f'{len(s)} {len(s[0])}\n'+'\n'.join(s+t)+'\n'
        raws=[grid(['.'],['.']),grid(['#'],['.']),grid(['.#'],['#.']),grid(['.#','##'],['##','.#'])]
        for h in range(2,14):
            w=h+2;s=[''.join(rng.choice('.#') for _ in range(w)) for _ in range(h)];order=list(range(w));rng.shuffle(order);t=[''.join(row[c] for c in order) for row in s]
            if h%2:t[0]=('#' if t[0][0]=='.' else '.')+t[0][1:]
            raws.append(grid(s,t))
        raws.extend([grid(['#.'*200000],['.#'*200000]),grid(['.'*1000]*400,['#'+'.'*999]+['.'*1000]*399)])
    elif number==280:
        raws=['a\naa\n','a\nba\n','a\nab\n','ab\nacb\n']
        for n in range(3,15):
            s=''.join(rng.choice('abc') for _ in range(n));j=rng.randrange(n+1);raws.append(s+'\n'+s[:j]+rng.choice('abc')+s[j:]+'\n')
        raws.extend(['a'*500000+'\n'+'a'*500001+'\n','a'*500000+'\n'+'a'*500000+'z\n'])
    elif number==281:
        def playlist(a:list[int],t:int)->str:return f'{len(a)} {t}\n'+line(a)
        raws=[playlist([2],1),playlist([3],2),playlist([2,3],4),playlist([1,2],5)]
        for n in range(3,15):
            a=[rng.randint(2,100) for _ in range(n)];j=rng.randrange(n);t=sum(a)*rng.randint(1,1000)+sum(a[:j])+1;raws.append(playlist(a,t))
        raws.extend([playlist([10**9]*100000,10**18-1),playlist([10**9]*99999+[10**9-1],10**18)])
    elif number==282:
        def delimit(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[delimit('a'),delimit(','),delimit('""'),delimit('","')]
        for n in range(3,15):
            s=''.join(rng.choice('ab,"') for _ in range(n));s+= '"' if s.count('"')%2 else '';raws.append(delimit(s))
        raws.extend([delimit('"'+','*199998+'"'),delimit(('a,"b,c",'*25000))])
    elif number==283:
        raws=[s+'\n' for s in ('1','10','100','1000','10000','101','10100','100100','999','90909','1000001','10000001','1200030004000','9'*30,'1'+'0'*99,'1'+'0'*100)]
        raws.extend(['9'*100000+'\n','1'+'0'*100000+'\n'])
    else:
        def graph(n:int,edges:list[tuple[int,int]])->str:return f'{n} {len(edges)}\n'+''.join(line(e) for e in edges)
        raws=[graph(1,[]),graph(2,[]),graph(2,[(1,2)]),graph(3,[(2,1)])]
        for n in range(4,16):raws.append(graph(n,[edge for edge in combinations(range(1,n+1),2) if rng.random()<.18]))
        raws.extend([graph(100,[]),graph(100,list(combinations(range(1,101),2)))])
    require(len(raws)==len(set(raws))==18,'unique cases')
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc279_c':('列を並べ替えても各列の上下の文字は変わりません。','各列を長さHの文字列にして、重複も含めて比較します。','疑似コード: SとTを転置する; 列文字列の列をそれぞれsort; 一致ならYes。'),
'abc280_c':('挿入箇所より前は両文字列が一致します。','先頭から最初に異なる位置を探します。全て一致するなら末尾が候補です。','疑似コード: i=0; i<len(S)かつS[i]==T[i]の間i++; i+1を出力。'),
'abc281_c':('プレイリスト全体の長さで周期を求めます。','Tを周期で割った余りにし、曲の長さを順に引きます。','疑似コード: T%=sum(A); 各曲iでT<A[i]ならi,Tを出力して終了; それ以外はT-=A[i]。'),
'abc282_c':('引用符に入っているかを記録します。','引用符のたびに状態を反転し、外側のカンマだけ変更します。','疑似コード: inside=false; 各文字で引用符ならinside反転; カンマかつinside=falseならピリオドを出力、他は元の文字を出力。'),
'abc283_c':('00ボタンだけが一度に2桁を入力できます。','左から見て00があれば2桁、それ以外なら1桁ずつ処理します。','疑似コード: i=answer=0; i<len(S)の間、S[i:i+2]==00ならi+=2、他はi++; answer++; answerを出力。'),
'abc284_c':('未訪問の頂点から探索すると、連結成分を1つ得られます。','DFSなどで到達した全頂点を訪問済みにして、探索開始回数を数えます。','疑似コード: answer=0; 各未訪問頂点でanswer++; DFSで同じ成分を訪問済みにする; answerを出力。')}

TITLES={'abc279_c': 'RANDOM', 'abc280_c': 'Extra Character', 'abc281_c': 'Circular Playlist', 'abc282_c': 'String Delimiter', 'abc283_c': 'Cash Register', 'abc284_c': 'Count Connected Components'}
PUBLISHED_SAMPLES={'abc279_c': [{'input': '3 4\n##.#\n##..\n#...\n.###\n..##\n...#\n', 'expected': 'Yes\n'}, {'input': '3 3\n#.#\n.#.\n#.#\n##.\n##.\n.#.\n', 'expected': 'No\n'}, {'input': '2 1\n#\n.\n#\n.\n', 'expected': 'Yes\n'}, {'input': '8 7\n#..#..#\n.##.##.\n#..#..#\n.##.##.\n#..#..#\n.##.##.\n#..#..#\n.##.##.\n....###\n####...\n....###\n####...\n....###\n####...\n....###\n####...\n', 'expected': 'Yes\n'}], 'abc280_c': [{'input': 'atcoder\natcorder\n', 'expected': '5\n'}, {'input': 'million\nmilllion\n', 'expected': '5\n'}, {'input': 'vvwvw\nvvvwvw\n', 'expected': '3\n'}], 'abc281_c': [{'input': '3 600\n180 240 120\n', 'expected': '1 60\n'}, {'input': '3 281\n94 94 94\n', 'expected': '3 93\n'}, {'input': '10 5678912340\n1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '6 678912340\n'}], 'abc282_c': [{'input': '8\n"a,b"c,d\n', 'expected': '"a,b"c.d\n'}, {'input': '5\n,,,,,\n', 'expected': '.....\n'}, {'input': '20\na,"t,"c,"o,"d,"e,"r,\n', 'expected': 'a."t,"c."o,"d."e,"r.\n'}], 'abc283_c': [{'input': '40004\n', 'expected': '4\n'}, {'input': '1355506027\n', 'expected': '10\n'}, {'input': '10888869450418352160768000001\n', 'expected': '27\n'}], 'abc284_c': [{'input': '5 3\n1 2\n1 3\n4 5\n', 'expected': '2\n'}, {'input': '5 0\n', 'expected': '5\n'}, {'input': '4 6\n1 2\n1 3\n1 4\n2 3\n2 4\n3 4\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
