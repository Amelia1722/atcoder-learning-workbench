"""ABC089–091 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc089_b','abc090_b','abc091_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER=re.compile(r'[a-z]{1,10}', re.ASCII)


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc089_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
        n=int(lines[0]); colors=lines[1].split(' ')
        if not (1<=n<=100 and len(colors)==n and all(c in {'P','W','G','Y'} for c in colors)):
            raise ValueError('range/colors')
        if not {'P','W','G'} <= set(colors): raise ValueError('required colors')
        return colors
    if pid=='abc090_b':
        if len(lines)!=1: raise ValueError('lines')
        parts=lines[0].split(' ')
        if len(parts)!=2 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('format')
        a,b=map(int,parts)
        if not (10000<=a<=b<=99999): raise ValueError('range')
        return a,b
    if not lines or POS.fullmatch(lines[0]) is None: raise ValueError('format')
    n=int(lines[0])
    if not 1<=n<=100: raise ValueError('N')
    if len(lines)<n+2: raise ValueError('lines')
    blue=lines[1:1+n]
    if any(LOWER.fullmatch(s) is None for s in blue): raise ValueError('blue')
    if POS.fullmatch(lines[1+n]) is None: raise ValueError('M')
    m=int(lines[1+n])
    if not 1<=m<=100 or len(lines)!=n+m+2: raise ValueError('M/lines')
    red=lines[2+n:]
    if any(LOWER.fullmatch(s) is None for s in red): raise ValueError('red')
    return blue,red


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc089_b':
        return output==('Four' if any(c=='Y' for c in value) else 'Three')
    if pid=='abc090_b':
        a,b=value; count=0
        for prefix in range(100,1000):
            s=str(prefix); p=int(s+s[-2::-1])
            if a<=p<=b: count+=1
        return output==str(count)
    blue,red=value
    scores={}
    for s in blue: scores[s]=scores.get(s,0)+1
    for s in red: scores[s]=scores.get(s,0)-1
    best=0
    for score in scores.values():
        if score>best: best=score
    return output==str(best)


def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc089_b':
        values=[
            ['P','W','G'],['P','W','G','Y'],['G','W','P'],['Y','G','W','P'],
            ['P','P','W','G'],['P','W','W','G'],['P','W','G','G'],['P','Y','W','G','Y'],
            ['G','P','Y','W','P','G'],['W','G','P','P','P','P'],
            ['P','W','G']*10,['P','W','G','Y']*10,
            ['P']*20+['W']*20+['G']*20,['Y']*20+['P']*20+['W']*20+['G']*20,
            ['P']*97+['W','G'],['Y']*97+['P','W','G'],
            ['P','W','G']+['P']*96,
        ]
        for colors in values:
            add('boundary' if len(colors) in (3,99,100) else 'normal',f'{len(colors)}\n'+' '.join(colors)+'\n')
        colors=['P','W','G','Y']*25
        add('constraint_max','100\n'+' '.join(colors)+'\n')
    elif pid=='abc090_b':
        vals=[
            (10000,10000),(10001,10001),(10000,10001),(10100,10200),(10999,11011),
            (11111,11111),(12320,12322),(19990,20010),(50000,50100),(54300,54400),
            (90000,90109),(99998,99999),(99999,99999),(10000,10999),(20000,29999),
            (90000,99999),(12345,98765),
        ]
        for a,b in vals:
            add('boundary' if a==10000 or b==99999 or a==b else 'normal',f'{a} {b}\n')
        add('constraint_max','10000 99999\n')
    else:
        vals=[
            (['a'],['b']),
            (['a'],['a']),
            (['a','a'],['a']),
            (['a'],['a','a']),
            (['apple','orange','apple'],['grape']),
            (['red','blue','red'],['red','green']),
            (['x','y','z'],['x','y','z']),
            (['abc','abc','def','ghi'],['abc','def']),
            (['abcdefghij'],['jihgfedcba']),
            (['same']*10,['same']*9),
            (['same']*9,['same']*10),
            (['a','b','c','d','e'],['f','g','h','i','j']),
            (['a']*50+['b']*25,['a']*25+['c']*50),
            ([f'x{chr(97+i%10)}' for i in range(1,91)], [f'x{chr(97+i%10)}' for i in range(1,81)]),
            (['abcdefghij']*99,['abcdefghij']*100),
            (['a']*100,['b']*100),
            (['z']*100,['z']*99),
        ]
        for blue,red in vals:
            raw=str(len(blue))+'\n'+'\n'.join(blue)+'\n'+str(len(red))+'\n'+'\n'.join(red)+'\n'
            add('boundary' if len(blue) in (1,99,100) or len(red) in (1,99,100) else 'normal',raw)
        blue=['abcdefghij']*100; red=['abcdefghij']*100
        add('constraint_max','100\n'+'\n'.join(blue)+'\n100\n'+'\n'.join(red)+'\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
