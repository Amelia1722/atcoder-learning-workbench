"""Reviewed variety selection, geometric dominance, temporal maxima and reversals."""
from __future__ import annotations
from bisect import bisect_left
from collections import defaultdict
from heapq import heappush
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(461,466))+('abc003_4',)
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if pid=='abc003_4':
        require(len(rows)==3,'shape');r,c=ints(rows[0],2);x,y=ints(rows[1],2);d,l=ints(rows[2],2);require(1<=x<=r<=30 and 1<=y<=c<=30 and d>=0 and l>=0 and 1<=d+l<=x*y,'room');return r,c,x,y,d,l
    if number==461:
        n,k,m=ints(rows[0],3);require(1<=m<=k<=n<=200000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=c<=n and 1<=v<=10**9 for c,v in a) and len({c for c,v in a})>=m,'gems');return k,m,a
    if number==462:
        n=ints(rows[0],1)[0];require(1<=n<=300000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=x<=n and 1<=y<=n for x,y in a) and len({x for x,y in a})==len({y for x,y in a})==n,'permutations');return (a,)
    if number==463:
        n=ints(rows[0],1)[0];require(1<=n<=300000 and len(rows)==n+3,'shape');a=tuple(ints(row,2) for row in rows[1:n+1]);q=ints(rows[n+1],1)[0];queries=ints(rows[n+2],q);require(1<=q<=300000 and all(1<=h<=10**9 and 1<=l<=10**9 for h,l in a) and all(a[j][1]<=a[j+1][1] for j in range(n-1)) and all(0<=t<a[-1][1] for t in queries),'time/height');return a,queries
    if number==464:
        n,m=ints(rows[0],2);require(1<=n<=300000 and 1<=m<=300000 and len(rows)==n+1,'shape');a=tuple(ints(row,3) for row in rows[1:]);require(all(1<=x<=n and 1<=y<=n and 1<=d<=m for x,d,y in a),'birds');return m,a
    require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(2<=n<=500000 and len(s)==n and set(s)<=set('ox'),'reversals');return (s,)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if pid=='abc003_4':
        r,c,x,y,d,l=cast(tuple[int,int,int,int,int,int],data);k=d+l;ways=[[0]*(y+1) for _ in range(x+1)]
        for h in range(1,x+1):
            for w in range(1,y+1):
                count=comb(h*w,k) if h*w>=k else 0
                for hh in range(1,h+1):
                    for ww in range(1,w+1):
                        if hh!=h or ww!=w:count-=ways[hh][ww]*(h-hh+1)*(w-ww+1)
                ways[h][w]=count
        return str(ways[x][y]*comb(k,d)*(r-x+1)*(c-y+1)%1000000007)
    if number==461:
        k,m,a=cast(tuple[int,int,tuple[tuple[int,int],...]],data);best:dict[int,tuple[int,int]]={}
        for j,(c,v) in enumerate(a):
            if c not in best or v>best[c][0]:best[c]=(v,j)
        chosen=sorted(best.values(),reverse=True)[:m];used={j for v,j in chosen};extras=sorted((v for j,(c,v) in enumerate(a) if j not in used),reverse=True);return str(sum(v for v,j in chosen)+sum(extras[:k-m]))
    if number==462:
        a=cast(tuple[tuple[int,int],...],data[0]);n=len(a);tree=[0]*(n+1);answer=0
        for x,y in sorted(a,key=lambda v:v[1]):
            total=0;j=x-1
            while j:total+=tree[j];j-=j&-j
            answer+=total==0;j=x
            while j<=n:tree[j]+=1;j+=j&-j
        return str(answer)
    if number==463:
        a,queries=cast(tuple[tuple[tuple[int,int],...],tuple[int,...]],data);people=sorted(a,key=lambda v:v[1],reverse=True);ordered=sorted(enumerate(queries),key=lambda v:v[1],reverse=True);heap:list[int]=[];j=0;out=[0]*len(queries)
        for index,t in ordered:
            while j<len(people) and people[j][1]>t:heappush(heap,-people[j][0]);j+=1
            out[index]=-heap[0]
        return '\n'.join(map(str,out))
    if number==464:
        m,a=cast(tuple[int,tuple[tuple[int,int,int],...]],data);intervals:dict[int,list[tuple[int,int]]]=defaultdict(list)
        for x,d,y in a:
            if d>1:intervals[x].append((1,d-1))
            intervals[y].append((d,m))
        delta=[0]*(m+2)
        for segments in intervals.values():
            segments.sort();left,right=segments[0]
            for l,r in segments[1:]:
                if l<=right+1:right=max(right,r)
                else:delta[left]+=1;delta[right+1]-=1;left,right=l,r
            delta[left]+=1;delta[right+1]-=1
        current=0;out=[]
        for day in range(1,m+1):current+=delta[day];out.append(str(current))
        return '\n'.join(out)
    s=cast(str,data[0]);parity=0;front=[];back=[]
    for j in range(len(s)-1,-1,-1):
        parity^=s[j]=='o'
        if parity:front.append(j+1)
        else:back.append(j+1)
    return ' '.join(map(str,front+back[::-1]))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc003_4':"mod=1000000007\nr,c=map(int,input().split());x,y=map(int,input().split());d,l=map(int,input().split());k=d+l;factor=[1]*(x*y+1)\nfor j in range(1,len(factor)):factor[j]=factor[j-1]*j%mod\ninverse=[1]*len(factor);inverse[-1]=pow(factor[-1],mod-2,mod)\nfor j in range(len(factor)-1,0,-1):inverse[j-1]=inverse[j]*j%mod\ndef choose(n,k):return factor[n]*inverse[k]%mod*inverse[n-k]%mod if 0<=k<=n else 0\nanswer=0\nfor mask in range(16):\n rows=set();cols=set()\n if mask&1:rows.add(0)\n if mask&2:rows.add(x-1)\n if mask&4:cols.add(0)\n if mask&8:cols.add(y-1)\n area=(x-len(rows))*(y-len(cols));value=choose(area,k)*choose(k,d)%mod;answer+=(-1 if mask.bit_count()%2 else 1)*value\nprint(answer*(r-x+1)*(c-y+1)%mod)\n",
'abc461_c':"import heapq\nn,k,m=map(int,input().split());a=sorted((tuple(map(int,input().split())) for _ in range(n)),key=lambda v:v[1],reverse=True);seen=set();duplicates=[];answer=0\nfor c,v in a[:k]:\n answer+=v\n if c in seen:heapq.heappush(duplicates,v)\n else:seen.add(c)\nfor c,v in a[k:]:\n if len(seen)>=m:break\n if c not in seen:answer+=v-heapq.heappop(duplicates);seen.add(c)\nprint(answer)\n",
'abc462_c':"n=int(input());a=sorted(tuple(map(int,input().split())) for _ in range(n));smallest=n+1;answer=0\nfor x,y in a:\n if y<smallest:answer+=1;smallest=y\nprint(answer)\n",
'abc463_c':"from bisect import bisect_right\nn=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];q=int(input());t=list(map(int,input().split()));l=[v[1] for v in a];suffix=[0]*n\nfor j in range(n-1,-1,-1):suffix[j]=max(a[j][0],suffix[j+1] if j+1<n else 0)\nprint('\\n'.join(str(suffix[bisect_right(l,x)]) for x in t))\n",
'abc464_c':"n,m=map(int,input().split());events=[[] for _ in range(m+1)];counts=[0]*(n+1);distinct=0\nfor _ in range(n):\n a,d,b=map(int,input().split());counts[a]+=1;events[d].append((a,b))\ndistinct=sum(v>0 for v in counts)\nfor day in range(1,m+1):\n for a,b in events[day]:\n  counts[a]-=1\n  if counts[a]==0:distinct-=1\n  if counts[b]==0:distinct+=1\n  counts[b]+=1\n print(distinct)\n",
'abc465_c':"from collections import deque\nn=int(input());s=input();a=deque();reverse=False\nfor j,c in enumerate(s,1):\n if reverse:a.appendleft(j)\n else:a.append(j)\n if c=='o':reverse=not reverse\nif reverse:a.reverse()\nprint(*a)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17800+number)
    if pid=='abc003_4':
        def room(r:int,c:int,x:int,y:int,d:int,l:int)->str:return f'{r} {c}\n{x} {y}\n{d} {l}\n'
        raws=[room(1,1,1,1,0,1),room(1,1,1,1,1,0),room(3,3,1,3,1,1),room(3,3,3,1,1,1)]
        for n in range(3,14):
            r=n;c=n+1;x=rng.randint(1,r);y=rng.randint(1,c);k=rng.randint(1,x*y);d=rng.randint(0,k);raws.append(room(r,c,x,y,d,k-d))
        raws.extend([room(30,30,30,30,225,225),room(30,30,30,30,0,900),room(30,30,30,30,900,0)])
    elif number==461:
        def gems(k:int,m:int,a:list[tuple[int,int]])->str:return f'{len(a)} {k} {m}\n'+''.join(line(v) for v in a)
        raws=[gems(1,1,[(1,1)]),gems(2,2,[(1,3),(1,2),(2,1)]),gems(2,1,[(1,3),(1,2),(2,1)]),gems(3,2,[(1,8),(1,7),(1,6),(2,5),(3,4)])]
        for n in range(3,15):
            a=[(rng.randint(1,n),rng.randint(1,100)) for _ in range(n)];k=rng.randint(1,n);m=rng.randint(1,min(k,len({c for c,v in a})));raws.append(gems(k,m,a))
        raws.extend([gems(100000,100000,[(1,10**9)]*100000+[(j,1) for j in range(2,100002)]),gems(200000,200000,[(j,10**9) for j in range(1,200001)])])
    elif number==462:
        def points(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[points([(1,1)]),points([(1,2),(2,1)]),points([(2,2),(1,1)]),points([(2,3),(3,2),(1,1)])]
        for n in range(3,15):
            xs=list(range(1,n+1));ys=xs.copy();rng.shuffle(xs);rng.shuffle(ys);raws.append(points(list(zip(xs,ys))))
        raws.extend([points([(j,300001-j) for j in range(1,300001)]),points([(j,j) for j in range(1,300001)])])
    elif number==463:
        def heights(a:list[tuple[int,int]],q:list[int])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)+f'{len(q)}\n'+line(q)
        raws=[heights([(1,1)],[0]),heights([(3,1),(2,1),(1,2)],[0,1]),heights([(1,2),(3,2)],[1,0,1]),heights([(5,1),(3,2),(4,3)],[0,1,2])]
        for n in range(3,15):
            ls=sorted(rng.randint(1,100) for _ in range(n));a=[(rng.randint(1,100),l) for l in ls];raws.append(heights(a,[rng.randrange(ls[-1]) for _ in range(n)]))
        raws.extend([heights([(300001-j,j) for j in range(1,300001)],list(range(300000))),heights([(10**9,10**9)]*300000,[10**9-1]*300000)])
    elif number==464:
        def birds(m:int,a:list[tuple[int,int,int]])->str:return f'{len(a)} {m}\n'+''.join(line(v) for v in a)
        raws=[birds(1,[(1,1,1)]),birds(2,[(1,1,2),(2,2,1)]),birds(3,[(1,2,2),(2,2,1)]),birds(2,[(1,2,1),(1,1,2)])]
        raws.extend(birds(n+1,[(rng.randint(1,n),rng.randint(1,n+1),rng.randint(1,n)) for _ in range(n)]) for n in range(3,15));raws.extend([birds(300000,[(j,j,1) for j in range(1,300001)]),birds(300000,[(300000,300000,300000)]*300000)])
    else:
        raws=[s+'\n' for s in ('xx','oo','ox','xo')];raws=[f'{len(s)-1}\n'+s for s in raws];raws.extend(f'{n}\n'+''.join(rng.choice('ox') for _ in range(n))+'\n' for n in range(3,15));raws.extend(['500000\n'+'ox'*250000+'\n','500000\n'+'o'*500000+'\n'])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc003_4':('物を置くマスを選んだ後、そのうちD個をデスクに割り当てます。四辺すべてに物が必要です。','上・下・左・右の辺が空になる条件を包除原理で除き、部屋内での長方形の位置数を掛けます。','疑似コード: 4辺の部分集合を列挙; 禁止する行・列は集合で重複を除く; 残りareaに対し(-1)^辺数*C(area,D+L)*C(D+L,D)を加算; (R-X+1)(C-Y+1)倍してmod。'),
'abc461_c':('まず価値の高いK個を選び、色数が足りるか確認します。','足りなければ同色の重複のうち最も安い宝石を、未選択の色で最も高い宝石へ交換します。','疑似コード: 価値降順の先頭Kを選ぶ; 重複価値をminheapへ; 残りを価値降順に見て新色なら最安重複と交換; M色達成で停止。'),
'abc462_c':('x座標が小さい点だけが長方形の内部に入り得ます。','x座標順に並べ、これまでのy座標の最小値と比較します。','疑似コード: 点をx昇順にsort; minY=∞; y<minYなら答え++してminY=y; 最後に答え出力。'),
'abc463_c':('時刻T+0.5で残る人は、退出時刻LがTより大きい人です。','退出時刻が昇順なので、残る人は末尾の連続区間です。','疑似コード: 身長のsuffixMaxを右から計算; 各Tでupper_bound(L,T)を求め、その位置のsuffixMaxを出力。'),
'abc464_c':('色ごとに何羽いるかを管理すると、色の種類数の増減が分かります。','変化日ごとのイベントを集め、その日の変化を全て反映してから答えます。','疑似コード: 初期Aの頻度を数える; 日Dの各A→BでAを減らし0なら種類--、Bが0なら種類++して増やす; 日ごとに出力。'),
'abc465_c':('kより後の要素はまだ変化していません。新しい要素を末尾に加えて先頭全体を反転すると考えます。','dequeと向きのフラグを使い、実際の反転を省きます。','疑似コード: i=1..Nで向きに応じdequeの末尾側へiを追加; S[i]=oなら向きを反転; 最終向きで列を出力。')}

TITLES={'abc461_c': 'Variety', 'abc462_c': 'Not Covered Points', 'abc463_c': 'Tallest at the Moment', 'abc464_c': 'Plumage Palette', 'abc465_c': 'Reverse Permutation', 'abc003_4': 'AtCoder社の冬'}
PUBLISHED_SAMPLES={'abc461_c': [{'input': '5 3 2\n1 30\n1 40\n1 50\n2 10\n3 20\n', 'expected': '110\n'}, {'input': '5 3 3\n1 30\n1 40\n1 50\n2 10\n3 20\n', 'expected': '80\n'}, {'input': '5 5 1\n4 1000000000\n5 1000000000\n4 1000000000\n5 1000000000\n4 1000000000\n', 'expected': '5000000000\n'}], 'abc462_c': [{'input': '3\n2 1\n1 3\n3 2\n', 'expected': '2\n'}, {'input': '5\n1 1\n4 2\n2 3\n5 5\n3 4\n', 'expected': '1\n'}, {'input': '7\n3 4\n6 1\n5 5\n2 7\n7 2\n1 3\n4 6\n', 'expected': '2\n'}], 'abc463_c': [{'input': '4\n31 4\n26 5\n3 5\n15 9\n4\n3 4 5 6\n', 'expected': '31\n26\n15\n15\n'}, {'input': '10\n587 138\n772 155\n755 404\n519 408\n529 432\n169 586\n114 632\n249 656\n329 972\n299 984\n14\n443 801 824 276 399 314 300 510 311 580 498 930 359 5\n', 'expected': '329\n329\n329\n755\n755\n755\n755\n329\n755\n329\n329\n329\n755\n772\n'}], 'abc464_c': [{'input': '6 7\n1 3 2\n2 6 5\n5 5 1\n3 3 5\n4 1 6\n6 3 6\n', 'expected': '5\n5\n3\n3\n4\n4\n4\n'}], 'abc465_c': [{'input': '5\nooxoo\n', 'expected': '5 2 1 3 4\n'}, {'input': '7\nooooooo\n', 'expected': '7 5 3 1 2 4 6\n'}, {'input': '15\nxooxoxoxoxoxxoo\n', 'expected': '15 11 10 7 6 3 1 2 4 5 8 9 12 13 14\n'}], 'abc003_4': [{'input': '3 2\n2 2\n2 2\n', 'expected': '12\n'}, {'input': '4 5\n3 1\n3 0\n', 'expected': '10\n'}, {'input': '23 18\n15 13\n100 95\n', 'expected': '364527243\n'}, {'input': '30 30\n24 22\n145 132\n', 'expected': '976668549\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
