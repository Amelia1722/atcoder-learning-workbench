from pydantic import BaseModel, Field


class UserSettings(BaseModel):
    user_id: str = Field(default="", max_length=64)


class NoteUpdate(BaseModel):
    note: str = Field(default="", max_length=20000)
