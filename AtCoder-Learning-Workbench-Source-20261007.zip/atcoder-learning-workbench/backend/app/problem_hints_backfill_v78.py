"""Evidence-bound hint backfill for ABC011 A / ABC012 A / ABC013 A."""
HINTS_BACKFILL_V78={
'abc011_1':('12月の次だけ1月に戻ることに注意してください。','Nが12なら1、それ以外ならN+1を出力します。','疑似コード:\nif N == 12: print(1)\nelse: print(N+1)'),
'abc012_1':('求めるのは計算結果ではなく、2つの値を入れ替えた順番です。','A,Bを受け取ったらB,Aの順で出力すればよいです。','疑似コード:\nA, B = read_two_integers()\nprint(B, A)'),
'abc013_1':('入力はA〜Eの5文字だけです。Aを1として順番を対応させます。','文字コード差を使うなら ord(X)-ord("A")+1 で求められます。辞書で対応させても構いません。','疑似コード:\nX = read_char()\nprint(ord(X) - ord("A") + 1)')}
