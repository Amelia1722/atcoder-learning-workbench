"""Finite ruler sequence, Gray subsets, linked swaps and Fenwick multiset."""
from __future__ import annotations
from collections import Counter,defaultdict
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (247,248,249,250,252,253))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CASE_COUNTS={p:16 if p=='abc247_c' else 18 for p in TASKS}
MOD=998244353
Case=dict[str,str]
Data=tuple[object,...]
Query=tuple[int,...]
ALPHABET='abcdefghijklmnopqrstuvwxyz'
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==247:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=16,'rank');return (n,)
    if number==248:
        require(len(rows)==1,'shape');n,m,k=ints(rows[0],3);require(1<=n<=50 and 1<=m<=50 and n<=k<=n*m,'dice');return n,m,k
    if number==249:
        n,k=ints(rows[0],2);words=tuple(rows[1:]);require(1<=k<=n<=15 and len(words)==len(set(words))==n and all(re.fullmatch('[a-z]{1,26}',s) is not None and len(s)==len(set(s)) for s in words),'words');return k,words
    if number==250:
        n,q=ints(rows[0],2);require(2<=n<=200000 and 1<=q<=200000 and len(rows)==q+1,'shape');queries=tuple(ints(row,1)[0] for row in rows[1:]);require(all(1<=x<=n for x in queries),'ball');return n,queries
    if number==252:
        n=ints(rows[0],1)[0];words=tuple(rows[1:]);require(2<=n<=100 and len(words)==n and all(len(s)==10 and set(s)==set('0123456789') for s in words),'reels');return (words,)
    q=ints(rows[0],1)[0];require(1<=q<=200000 and len(rows)==q+1,'shape');queries=tuple(ints(row) for row in rows[1:]);counts:Counter[int]=Counter();total=0
    for query in queries:
        require(bool(query),'query')
        if query[0]==1:
            require(len(query)==2 and 0<=query[1]<=10**9,'insert');counts[query[1]]+=1;total+=1
        elif query[0]==2:
            require(len(query)==3 and 0<=query[1]<=10**9 and 1<=query[2]<=q,'remove');removed=min(counts[query[1]],query[2]);counts[query[1]]-=removed;total-=removed
        else:require(query==(3,) and total>0,'nonempty range')
    return (queries,)
def _gray_letters(k:int,words:tuple[str,...])->int:
    counts=[0]*26;answer=0;previous=0
    for ordinal in range(1,1<<len(words)):
        current=ordinal^(ordinal>>1);changed=current^previous;index=changed.bit_length()-1;delta=1 if current&changed else -1
        for ch in words[index]:counts[ord(ch)-97]+=delta
        answer=max(answer,counts.count(k));previous=current
    return answer
def _linked_swaps(n:int,queries:tuple[int,...])->str:
    previous=[i-1 for i in range(n+2)];following=[i+1 for i in range(n+2)];following[n]=0;following[0]=1;previous[0]=n;previous[1]=0
    for value in queries:
        left=value if following[value] else previous[value];right=following[left];before=previous[left];after=following[right]
        following[before]=right;previous[right]=before;following[right]=left;previous[left]=right;following[left]=after;previous[after]=left
    answer=[];value=following[0]
    while value:answer.append(value);value=following[value]
    return ' '.join(map(str,answer))
def _slot_matching(words:tuple[str,...])->int:
    def feasible(digit:str,deadline:int)->bool:
        choices=[list(range(s.index(digit),deadline+1,10)) for s in words];owner:dict[int,int]={}
        def match(reel:int,seen:set[int])->bool:
            for moment in choices[reel]:
                if moment in seen:continue
                seen.add(moment)
                if moment not in owner or match(owner[moment],seen):owner[moment]=reel;return True
            return False
        return all(match(reel,set()) for reel in range(len(words)))
    answer=10*len(words)
    for digit in '0123456789':
        low=-1;high=10*len(words)-1
        while high-low>1:
            middle=(high+low)//2
            if feasible(digit,middle):high=middle
            else:low=middle
        answer=min(answer,high)
    return answer
def _fenwick_queries(queries:tuple[Query,...])->str:
    coordinates=sorted({query[1] for query in queries if query[0]!=3});index={v:j+1 for j,v in enumerate(coordinates)};tree=[0]*(len(coordinates)+1);counts=[0]*len(coordinates);total=0;answer=[]
    def add(position:int,delta:int)->None:
        while position<len(tree):tree[position]+=delta;position+=position&-position
    def kth(rank:int)->int:
        position=0;step=1<<(len(coordinates).bit_length()-1)
        while step:
            candidate=position+step
            if candidate<len(tree) and tree[candidate]<rank:position=candidate;rank-=tree[candidate]
            step//=2
        return coordinates[position]
    for query in queries:
        if query[0]==3:answer.append(str(kth(total)-kth(1)));continue
        position=index[query[1]];delta=1 if query[0]==1 else -min(counts[position-1],query[2]);counts[position-1]+=delta;total+=delta;add(position,delta)
    return '\n'.join(answer)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==247:return ' '.join(str((j&-j).bit_length()) for j in range(1,1<<cast(int,data[0])))
    if number==248:
        n,m,k=cast(tuple[int,int,int],data);# Upper-bounded compositions via inclusion-exclusion.
        budget=k-n;return str(sum((-1)**j*comb(n,j)*comb(budget-j*m+n,n) for j in range(min(n,budget//m)+1))%MOD)
    if number==249:return str(_gray_letters(*cast(tuple[int,tuple[str,...]],data)))
    if number==250:return _linked_swaps(*cast(tuple[int,tuple[int,...]],data))
    if number==252:return str(_slot_matching(cast(tuple[str,...],data[0])))
    return _fenwick_queries(cast(tuple[Query,...],data[0]))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError,ZeroDivisionError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc247_c':"n=int(input());answer=[1]\nfor j in range(2,n+1):answer=answer+[j]+answer\nprint(*answer)\n",
'abc248_c':"n,m,k=map(int,input().split());mod=998244353;dp=[0]*(k+1);dp[0]=1\nfor _ in range(n):\n following=[0]*(k+1)\n for total,count in enumerate(dp):\n  for value in range(1,min(m,k-total)+1):following[total+value]=(following[total+value]+count)%mod\n dp=following\nprint(sum(dp)%mod)\n",
'abc249_c':"from collections import Counter\nn,k=map(int,input().split());words=[input() for _ in range(n)];answer=0\nfor mask in range(1<<n):\n counts=Counter(''.join(words[j] for j in range(n) if mask>>j&1));answer=max(answer,sum(v==k for v in counts.values()))\nprint(answer)\n",
'abc250_c':"n,q=map(int,input().split());a=list(range(n));position=list(range(n))\nfor _ in range(q):\n x=int(input())-1;i=position[x];j=i+1 if i<n-1 else i-1;y=a[j];a[i],a[j]=a[j],a[i];position[x],position[y]=j,i\nprint(*(v+1 for v in a))\n",
'abc252_c':"from collections import Counter\nn=int(input());words=[input() for _ in range(n)];answer=10*n\nfor digit in '0123456789':\n counts=Counter(s.index(digit) for s in words);answer=min(answer,max(position+10*(count-1) for position,count in counts.items()))\nprint(answer)\n",
'abc253_c':"from collections import Counter\nimport heapq\nq=int(input());counts=Counter();low=[];high=[]\nfor _ in range(q):\n query=list(map(int,input().split()))\n if query[0]==1:\n  x=query[1];counts[x]+=1;heapq.heappush(low,x);heapq.heappush(high,-x)\n elif query[0]==2:\n  x,c=query[1:];counts[x]=max(0,counts[x]-c)\n else:\n  while not counts[low[0]]:heapq.heappop(low)\n  while not counts[-high[0]]:heapq.heappop(high)\n  print(-high[0]-low[0])\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');n=int(pid[3:6]);rng=random.Random(16600+n)
    if n==247:raws=[f'{v}\n' for v in range(1,17)]
    elif n==248:
        triples=[(1,1,1),(1,2,1),(1,2,2),(2,2,2),(2,2,3),(2,2,4),(3,3,3),(3,3,5),(3,3,9),(5,7,15),(7,5,20),(10,10,55),(20,20,200),(30,40,750),(40,30,600),(50,1,50),(50,50,50),(50,50,2500)];raws=[line(row) for row in triples]
    elif n==249:
        def words(k:int,s:list[str])->str:return f'{len(s)} {k}\n'+'\n'.join(s)+'\n'
        raws=[words(1,['a']),words(1,[ALPHABET]),words(1,['a','b']),words(2,['ab','bc'])]
        for size in range(3,15):
            s=set()
            while len(s)<size:s.add(''.join(sorted(rng.sample(ALPHABET,rng.randint(1,26)))))
            raws.append(words(rng.randint(1,size),sorted(s)))
        raws.extend([words(1,[ALPHABET[:j]+ALPHABET[j+1:] for j in range(15)]),words(15,[ALPHABET[:j]+ALPHABET[j+1:] for j in range(15)])])
    elif n==250:
        def swaps(n:int,q:list[int])->str:return f'{n} {len(q)}\n'+''.join(f'{x}\n' for x in q)
        raws=[swaps(2,[1]),swaps(2,[2]),swaps(2,[1,1]),swaps(3,[3,3,3])]
        for size in range(3,15):raws.append(swaps(size,[rng.randint(1,size) for _ in range(size*3)]))
        raws.extend([swaps(200000,[200000]*200000),swaps(200000,list(range(1,200001)))])
    elif n==252:
        def slots(s:list[str])->str:return f'{len(s)}\n'+'\n'.join(s)+'\n'
        raws=[slots(['0123456789']*2),slots(['0123456789','9876543210']),slots(['0123456789','1234567890']),slots(['0123456789']*3)]
        for size in range(4,16):raws.append(slots([''.join(rng.sample('0123456789',10)) for _ in range(size)]))
        raws.extend([slots(['0123456789']*99+['9876543210']),slots(['0123456789']*100)])
    else:
        def queries(q:list[Query])->str:return f'{len(q)}\n'+''.join(line(row) for row in q)
        raws=[queries([(1,0)]),queries([(1,10**9),(3,)]),queries([(2,1,1)]),queries([(1,0),(1,10**9),(3,),(2,0,6),(3,),(2,10**9,6)])]
        for size in range(3,15):
            q=[(1,0)];counts:Counter[int]=Counter({0:1})
            for _ in range(size*3):
                kind=rng.randint(1,3);x=rng.randint(0,10)
                if kind==3 and sum(counts.values()):q.append((3,))
                elif kind==2:c=rng.randint(1,size);q.append((2,x,c));counts[x]=max(0,counts[x]-c)
                else:q.append((1,x));counts[x]+=1
            raws.append(queries(q))
        raws.extend([queries([(1,j) for j in range(100000)]+[(2,j,200000) for j in range(99999)]+[(3,)]),queries([(1,0),(1,10**9)]+[(3,)]*199998)])
    require(len(raws)==len(set(raws))==CASE_COUNTS[pid],'distinct count')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==len(raws)-1 else 'finite_domain' if pid=='abc247_c' else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc247_c':('一つ小さい列を両側へ置く定義を、そのまま繰り返せます。','S=[1]から始め、i=2からNまでS=S+[i]+Sと更新します。Nは16以下なので列全体を作れます。','疑似コード: S=[1]; for i=2..N: S=S+[i]+S; print S separated by spaces。'),
'abc248_c':('選んだ個数と合計値を状態にして数えます。','dp[sum]を現在の個数で合計sumになる方法数とし、次の値1からMを足して遷移します。N回後の合計K以下を足します。','疑似コード: dp[0]=1; repeat N times: next=[0]*(K+1); for sum,value: if sum+value<=K: next[sum+value]+=dp[sum] modulo998244353; dp=next; print(sum(dp)%mod)。'),
'abc249_c':('文字列の選び方は2^N通りなので全て調べられます。','各部分集合について文字ごとの登場回数を数え、ちょうどKの文字数の最大を取ります。各文字列内に重複文字はありません。','疑似コード: answer=0; for mask=0..2^N-1: count letters in selected strings; answer=max(answer,number of letters with count K); print(answer)。'),
'abc250_c':('各ボールの現在位置を別の配列で持てば、探す時間を省けます。','値から位置を参照し、隣のボールと交換して、両方の位置情報も更新します。右端なら左隣を使います。','疑似コード: A=1..N; pos[value]=index; for x: i=pos[x]; j=i+1 unless rightmost then i-1; y=A[j]; swap A[i],A[j]; swap pos[x],pos[y]; print A。'),
'abc252_c':('揃える数字を0から9まで試します。','同じ位置に出るリールは10秒ずつずらして止める必要があります。位置pのリールがc個なら、最後はp+10*(c-1)秒です。','疑似コード: for digit=0..9: count positions of digit in each reel; finish=max(p+10*(count[p]-1)); answer=min(answer,finish); print(answer)。'),
'abc253_c':('多重集合の個数と、最小・最大候補を効率よく管理します。','出現回数を辞書で持ち、最小用と最大用のヒープへ追加します。削除では個数だけ更新し、照会時に個数0の候補を捨てます。','疑似コード: insert x: count[x]+=1; push x and -x to heaps; remove x,c: count[x]=max(0,count[x]-c); query: pop zero-count tops; print(-maxheap.top-minheap.top)。')}

TITLES={'abc247_c': '1 2 1 3 1 2 1', 'abc248_c': 'Dice Sum', 'abc249_c': 'Just K', 'abc250_c': 'Adjacent Swaps', 'abc252_c': 'Slot Strategy', 'abc253_c': 'Max - Min Query'}
PUBLISHED_SAMPLES={'abc247_c': [{'input': '2\n', 'expected': '1 2 1\n'}, {'input': '1\n', 'expected': '1\n'}, {'input': '4\n', 'expected': '1 2 1 3 1 2 1 4 1 2 1 3 1 2 1\n'}], 'abc248_c': [{'input': '2 3 4\n', 'expected': '6\n'}, {'input': '31 41 592\n', 'expected': '798416518\n'}], 'abc249_c': [{'input': '4 2\nabi\naef\nbc\nacg\n', 'expected': '3\n'}, {'input': '2 2\na\nb\n', 'expected': '0\n'}, {'input': '5 2\nabpqxyz\naz\npq\nbc\ncy\n', 'expected': '7\n'}], 'abc250_c': [{'input': '5 5\n1\n2\n3\n4\n5\n', 'expected': '1 2 3 5 4\n'}, {'input': '7 7\n7\n7\n7\n7\n7\n7\n7\n', 'expected': '1 2 3 4 5 7 6\n'}, {'input': '10 6\n1\n5\n2\n9\n6\n6\n', 'expected': '1 2 3 4 5 7 6 8 10 9\n'}], 'abc252_c': [{'input': '3\n1937458062\n8124690357\n2385760149\n', 'expected': '6\n'}, {'input': '5\n0123456789\n0123456789\n0123456789\n0123456789\n0123456789\n', 'expected': '40\n'}], 'abc253_c': [{'input': '8\n1 3\n1 2\n3\n1 2\n1 7\n3\n2 2 3\n3\n', 'expected': '1\n5\n4\n'}, {'input': '4\n1 10000\n1 1000\n2 100 3\n1 10\n', 'expected': '\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
