"""ABC164–166 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
from bisect import bisect_left
import re

TASKS = ('abc164_b', 'abc165_b', 'abc166_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc164_b': [
        {'input':'10 9 10 10\n','expected':'No\n'},
        {'input':'46 4 40 5\n','expected':'Yes\n'},
    ],
    'abc165_b': [
        {'input':'103\n','expected':'3\n'},
        {'input':'1000000000000000000\n','expected':'3760\n'},
        {'input':'1333333333\n','expected':'1706\n'},
    ],
    'abc166_b': [
        {'input':'3 2\n2\n1 3\n1\n3\n','expected':'1\n'},
        {'input':'3 3\n1\n3\n1\n3\n1\n3\n','expected':'2\n'},
    ],
}


def _canon_parts(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc164_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        a,b,c,d = _canon_parts(lines[0], 4)
        if not all(1 <= x <= 100 for x in (a,b,c,d)):
            raise ValueError('range')
        return a,b,c,d
    if pid == 'abc165_b':
        if len(lines) != 1 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected canonical X')
        x = int(lines[0])
        if not 101 <= x <= 10**18:
            raise ValueError('X range')
        return x
    if len(lines) < 3:
        raise ValueError('too few rows')
    n,k = _canon_parts(lines[0], 2)
    if not (1 <= n <= 100 and 1 <= k <= 100):
        raise ValueError('N/K range')
    if len(lines) != 1 + 2*k:
        raise ValueError('row count')
    groups=[]
    p=1
    for _ in range(k):
        drow = lines[p]; arow = lines[p+1]; p += 2
        if POS.fullmatch(drow) is None:
            raise ValueError('noncanonical d_i')
        d = int(drow)
        if not 1 <= d <= n:
            raise ValueError('d_i range')
        arr = _canon_parts(arow, d)
        if arr != sorted(arr) or len(set(arr)) != d or any(not 1 <= x <= n for x in arr):
            raise ValueError('owner list invalid')
        groups.append(arr)
    return n,k,groups


_BALANCES=[100]
while _BALANCES[-1] < 10**18:
    cur=_BALANCES[-1]
    _BALANCES.append(cur + cur//100)


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc164_b':
        if output not in ('Yes','No'):
            return False
        a,b,c,d = value
        takahashi_attacks = (c + b - 1)//b
        aoki_attacks = (a + d - 1)//d
        return output == ('Yes' if takahashi_attacks <= aoki_attacks else 'No')
    if pid == 'abc165_b':
        if not output.isascii() or not output.isdigit() or (len(output)>1 and output[0]=='0'):
            return False
        x=value
        expected=bisect_left(_BALANCES, x)
        return output == str(expected)
    if not output.isascii() or not output.isdigit() or (len(output)>1 and output[0]=='0'):
        return False
    n,_,groups=value
    covered=[False]*(n+1)
    for group in groups:
        for person in group:
            covered[person]=True
    return output == str(sum(not covered[i] for i in range(1,n+1)))


def _164(a:int,b:int,c:int,d:int)->str:
    return f'{a} {b} {c} {d}\n'

def _165(x:int)->str:
    return f'{x}\n'

def _166(n:int, groups:list[list[int]])->str:
    rows=[f'{n} {len(groups)}']
    for group in groups:
        rows.append(str(len(group)))
        rows.append(' '.join(map(str,group)))
    return '\n'.join(rows)+'\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category:str, raw:str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid == 'abc164_b':
        vals=[
            ('sample1',10,9,10,10),('sample2',46,4,40,5),
            ('min_first_wins',1,1,1,1),('first_one_shot',100,100,100,1),
            ('second_survives_one',100,99,100,100),('equal_turns_first_wins',20,5,16,4),
            ('first_needs_one_more',20,4,21,5),('small_attack',100,1,100,1),
            ('aoki_fragile',1,1,100,100),('takahashi_fragile',100,100,1,1),
            ('ceil_boundary_yes',11,5,21,4),('ceil_boundary_no',10,4,21,5),
            ('large_hp_low_power_yes',100,2,99,2),('large_hp_low_power_no',99,2,100,2),
            ('asymmetric_yes',37,7,80,4),('asymmetric_no',37,4,80,7),
            ('near_max',99,100,100,99),
        ]
        for row in vals: add(row[0],_164(*row[1:]))
        add('constraint_max',_164(100,100,100,100))
    elif pid == 'abc165_b':
        vals=[
            ('sample1',103),('sample3',1333333333),('min',101),('two_years',102),
            ('four_years',104),('small_110',110),('small_199',199),('round_200',200),
            ('thousand',1000),('ten_thousand',10000),('million',10**6),('billion',10**9),
            ('trillion',10**12),('quadrillion',10**15),('near_max',10**18-1),
            ('balance_year_100',_BALANCES[100]),('just_above_year_100',_BALANCES[100]+1),('mid_large',500000000000000000),
        ]
        for cat,x in vals: add(cat,_165(x))
        add('constraint_max',_165(10**18))
    else:
        vals=[
            ('sample1',3,[[1,3],[3]]),
            ('sample2',3,[[3],[3],[3]]),
            ('min_covered',1,[[1]]),
            ('all_covered_once',5,[[1,2,3,4,5]]),
            ('middle_uncovered',5,[[1,2,4,5]]),
            ('disjoint_groups',6,[[1,2],[3,4],[5]]),
            ('overlap_union_all',6,[[1,2,3],[3,4,5],[1,5,6]]),
            ('same_person_many',5,[[2],[2],[2],[2]]),
            ('first_only_uncovered',5,[[2,3,4,5]]),
            ('last_only_uncovered',5,[[1,2,3,4]]),
            ('alternating',10,[[1,3,5,7,9],[2,4,6,8]]),
            ('nested',8,[[1,2],[1,2,3,4],[1,2,3,4,5,6]]),
            ('many_singletons',10,[[i] for i in range(1,10)]),
            ('all_have_all_twice',10,[list(range(1,11)),list(range(1,11))]),
            ('n100_one_owner',100,[[100]]),
            ('n100_half',100,[list(range(1,51))]),
            ('k100_same_owner',100,[[1] for _ in range(100)]),
        ]
        for cat,n,groups in vals: add(cat,_166(n,groups))
        add('constraint_max',_166(100,[list(range(1,101)) for _ in range(100)]))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
