"""Positional counts, Floyd cycles, word backtracking, Pareto states and exact angles."""
from __future__ import annotations
from bisect import bisect_right
from functools import cache
from itertools import combinations
from math import gcd
from typing import cast
import random,re

TASKS=('abc029_d','abc030_d','abc031_d','abc032_d','abc033_d','abc041_d')
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc031_d':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
Pairs=tuple[tuple[str,str],...]
Point=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def word_solution(k:int,pairs:Pairs)->tuple[str,...]|None:
    ordered=sorted(pairs,key=lambda pair:len(pair[1]));mapping=['']*(k+1)
    def search(row:int,digit:int,offset:int)->bool:
        if row==len(ordered):return True
        v,w=ordered[row]
        if digit==len(v):return offset==len(w) and search(row+1,0,0)
        key=int(v[digit]);known=mapping[key]
        if known:return w.startswith(known,offset) and search(row,digit+1,offset+len(known))
        remaining=len(v)-digit-1
        for length in range(1,4):
            if offset+length>len(w) or not remaining<=len(w)-offset-length<=3*remaining:continue
            mapping[key]=w[offset:offset+length]
            if search(row,digit+1,offset+length):return True
        mapping[key]='';return False
    return tuple(mapping[1:]) if search(0,0,0) else None

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');k=int(pid[3:6])
    if k==29:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<10**9,'bound');return (n,)
    if k==30:
        require(len(rows)==3,'shape');n,start=ints(rows[0],2);steps=rows[1];a=ints(rows[2],n);require(2<=n<=100000 and 1<=start<=n and all(1<=v<=n and v!=j for j,v in enumerate(a,1)),'functional graph');require(re.fullmatch('[1-9][0-9]{0,100000}',steps) is not None and (len(steps)<=100000 or steps=='1'+'0'*100000),'decimal steps');return start,steps,a
    if k==31:
        k,n=ints(rows[0],2);require(1<=k<=9 and 1<=n<=50 and len(rows)==n+1,'size');pairs=[]
        for row in rows[1:]:
            fields=row.split(' ');require(len(fields)==2,'pair');v,w=fields;require(re.fullmatch(f'[1-{k}]{{1,9}}',v) is not None and re.fullmatch('[a-z]{1,27}',w) is not None,'word pair');pairs.append((v,w))
        require(set(''.join(v for v,w in pairs))==set(str(j) for j in range(1,k+1)),'all digits appear');data=tuple(pairs);require(word_solution(k,data) is not None,'mapping exists');return k,data
    if k==32:
        n,w=ints(rows[0],2);require(1<=n<=200 and 1<=w<=10**9 and len(rows)==n+1,'size');items=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 and 1<=weight<=10**9 for v,weight in items),'items');require(n<=30 or all(weight<=1000 for v,weight in items) or all(v<=1000 for v,weight in items),'at least one complexity bound');return w,items
    if k==33:
        n=ints(rows[0],1)[0];points=tuple(ints(row,2) for row in rows[1:]);require(3<=n<=2000 and len(points)==n and len(set(points))==n and all(-10000<=v<=10000 for point in points for v in point),'points')
        for x,y in points:
            directions=set()
            for a,b in points:
                if (a,b)==(x,y):continue
                dx,dy=a-x,b-y;g=gcd(abs(dx),abs(dy));dx//=g;dy//=g
                if dx<0 or (dx==0 and dy<0):dx=-dx;dy=-dy
                require((dx,dy) not in directions,'no three collinear');directions.add((dx,dy))
        return (points,)
    n,m=ints(rows[0],2);require(2<=n<=16 and 1<=m<=n*(n-1)//2 and len(rows)==m+1,'size');edges=tuple(ints(row,2) for row in rows[1:]);require(len(set(edges))==m and all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges),'precedence edges');degrees=[0]*n;g=[[] for _ in range(n)]
    for a,b in edges:g[a-1].append(b-1);degrees[b-1]+=1
    queue=[j for j in range(n) if degrees[j]==0]
    for node in queue:
        for v in g[node]:
            degrees[v]-=1
            if degrees[v]==0:queue.append(v)
    require(len(queue)==n,'compatible order exists');return n,edges

def pareto(items:tuple[tuple[int,int],...],capacity:int)->list[tuple[int,int]]:
    states=[(0,0)]
    for value,weight in items:
        shifted=[(w+weight,v+value) for w,v in states if w+weight<=capacity];i=j=0;new=[];best=-1
        while i<len(states) or j<len(shifted):
            if j==len(shifted) or (i<len(states) and states[i][0]<shifted[j][0]):w,v=states[i];i+=1
            elif i==len(states) or shifted[j][0]<states[i][0]:w,v=shifted[j];j+=1
            else:w=states[i][0];v=max(states[i][1],shifted[j][1]);i+=1;j+=1
            if v>best:new.append((w,v));best=v
        states=new
    return states

def _triangles(points:tuple[Point,...])->tuple[int,int,int]:
    if len(points)<=50:
        counts=[0,0,0]
        for a,b,c in combinations(points,3):
            distances=sorted((sum((x-y)**2 for x,y in zip(a,b)),sum((x-y)**2 for x,y in zip(a,c)),sum((x-y)**2 for x,y in zip(b,c))))
            delta=distances[0]+distances[1]-distances[2];counts[0 if delta>0 else 1 if delta==0 else 2]+=1
        return cast(tuple[int,int,int],tuple(counts))
    def order(v:Point)->tuple[int,int]:
        x,y=v
        # -cot(angle) increases on each half-circle. Distinct rational slopes
        # differ by >=1/(20000**2), so scale 10**12 separates keys by >=2500.
        return int(y<0 or (y==0 and x<0)),(-x*10**12//y if y else -10**30)
    right=obtuse=0
    for x,y in points:
        vectors=sorted(((a-x,b-y) for a,b in points if (a,b)!=(x,y)),key=order);n=len(vectors);vectors*=2;quarter=semi=1
        for j in range(n):
            ax,ay=vectors[j];quarter=max(quarter,j+1);semi=max(semi,quarter)
            while quarter<j+n:
                bx,by=vectors[quarter]
                if ax*by-ay*bx<=0 or ax*bx+ay*by<=0:break
                quarter+=1
            semi=max(semi,quarter)
            while semi<j+n and ax*vectors[semi][1]-ay*vectors[semi][0]>0:semi+=1
            is_right=quarter<semi and ax*vectors[quarter][0]+ay*vectors[quarter][1]==0;right+=is_right;obtuse+=semi-quarter-is_right
    total=len(points)*(len(points)-1)*(len(points)-2)//6
    return total-right-obtuse,right,obtuse

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);k=int(pid[3:6])
    if k==29:
        n=cast(int,data[0]);answer=0;place=1
        while place<=n:
            high=n//(place*10);digit=n//place%10;low=n%place;answer+=high*place+(place if digit>1 else low+1 if digit==1 else 0);place*=10
        return str(answer)
    if k==30:
        start,steps,a=cast(tuple[int,str,tuple[int,...]],data);start-=1;slow=a[start]-1;fast=a[a[start]-1]-1
        while slow!=fast:slow=a[slow]-1;fast=a[a[fast]-1]-1
        mu=0;slow=start
        while slow!=fast:slow=a[slow]-1;fast=a[fast]-1;mu+=1
        length=1;fast=a[slow]-1
        while slow!=fast:fast=a[fast]-1;length+=1
        if len(steps)<len(str(mu)) or (len(steps)==len(str(mu)) and steps<str(mu)):distance=int(steps)
        else:
            remainder=0
            for c in steps:remainder=(remainder*10+ord(c)-48)%length
            distance=mu+(remainder-mu)%length
        node=start
        for _ in range(distance):node=a[node]-1
        return str(node+1)
    if k==31:
        size,pairs=cast(tuple[int,Pairs],data);solution=word_solution(size,pairs);require(solution is not None,'solution');return '\n'.join(cast(tuple[str,...],solution))
    if k==32:
        capacity,items=cast(tuple[int,tuple[tuple[int,int],...]],data)
        if len(items)<=30:
            cut=len(items)//2;left=pareto(items[:cut],capacity);right=pareto(items[cut:],capacity);j=len(right)-1;best=0
            for w,v in left:
                while j>=0 and w+right[j][0]>capacity:j-=1
                if j>=0:best=max(best,v+right[j][1])
            return str(best)
        return str(pareto(items,capacity)[-1][1])
    if k==33:return ' '.join(map(str,_triangles(cast(tuple[Point,...],data[0]))))
    n,edges=cast(tuple[int,tuple[tuple[int,int],...]],data);outgoing=[0]*n
    for a,b in edges:outgoing[a-1]|=1<<(b-1)
    @cache
    def sinks(mask:int)->int:
        if not mask:return 1
        return sum(sinks(mask&~(1<<j)) for j in range(n) if mask>>j&1 and not outgoing[j]&mask)
    return str(sinks((1<<n)-1))

def semantic_valid(k:int,pairs:Pairs,actual:str)->bool:
    words=actual.removesuffix('\n').split('\n')
    return len(words)==k and all(re.fullmatch('[a-z]{1,3}',s) is not None for s in words) and all(''.join(words[int(d)-1] for d in v)==w for v,w in pairs)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc031_d':k,pairs=cast(tuple[int,Pairs],validate(pid,raw));return semantic_valid(k,pairs,actual)
        if pid=='abc033_d':require(all(v>=0 for v in ints(actual.removesuffix('\n'),3)),'triangle counts')
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc031_d':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc029_d':"n=input();dp={(True,0):(1,0)}\nfor c in n:\n nextdp={}\n for (tight,_),(ways,total) in dp.items():\n  for digit in range(int(c)+1 if tight else 10):\n   key=(tight and digit==int(c),0);oldways,oldtotal=nextdp.get(key,(0,0));nextdp[key]=(oldways+ways,oldtotal+total+ways*(digit==1))\n dp=nextdp\nprint(sum(total for ways,total in dp.values()))\n",
'abc030_d':"n,start=map(int,input().split());k=input();a=list(map(int,input().split()));seen={};path=[];node=start\nwhile node not in seen:seen[node]=len(path);path.append(node);node=a[node-1]\nmu=seen[node];length=len(path)-mu\nif len(k)<len(str(mu)) or (len(k)==len(str(mu)) and k<str(mu)):print(path[int(k)])\nelse:\n residue=0\n for c in k:residue=(residue*10+ord(c)-48)%length\n print(path[mu+(residue-mu)%length])\n",
'abc031_d':"from itertools import product\nk,n=map(int,input().split());pairs=[input().split() for _ in range(n)]\nfor lengths in product((1,2,3),repeat=k):\n mapping=[None]*k;ok=True\n for v,w in pairs:\n  if sum(lengths[int(d)-1] for d in v)!=len(w):ok=False;break\n  offset=0\n  for d in v:\n   j=int(d)-1;s=w[offset:offset+lengths[j]];offset+=lengths[j]\n   if mapping[j] is not None and mapping[j]!=s:ok=False;break\n   mapping[j]=s\n  if not ok:break\n if ok:print('\\n'.join(mapping));break\n",
'abc032_d':"from bisect import bisect_right\nn,W=map(int,input().split());items=[tuple(map(int,input().split())) for _ in range(n)]\nif n<=30:\n def subsets(seq):\n  states=[(0,0)]\n  for v,w in seq:states += [(a+w,b+v) for a,b in states if a+w<=W]\n  return states\n left=subsets(items[:n//2]);right=sorted(subsets(items[n//2:]));weights=[a for a,b in right];best=[];current=0\n for a,b in right:current=max(current,b);best.append(current)\n print(max(v+best[bisect_right(weights,W-w)-1] for w,v in left))\nelif max(w for v,w in items)<=1000:\n cap=min(W,sum(w for v,w in items));dp=[-1]*(cap+1);dp[0]=0;total=0\n for v,w in items:\n  total=min(cap,total+w)\n  for j in range(total,w-1,-1):\n   if dp[j-w]>=0:dp[j]=max(dp[j],dp[j-w]+v)\n print(max(dp))\nelse:\n total=sum(v for v,w in items);dp=[10**30]*(total+1);dp[0]=0;done=0\n for v,w in items:\n  done+=v\n  for j in range(done,v-1,-1):dp[j]=min(dp[j],dp[j-v]+w)\n print(max(j for j,w in enumerate(dp) if w<=W))\n",
'abc033_d':"from math import atan2,pi\nfrom bisect import bisect_left,bisect_right\nn=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];right=obtuse=0;eps=1e-10\nfor x,y in points:\n angles=sorted(atan2(b-y,a-x) for a,b in points if (a,b)!=(x,y));m=len(angles);angles += [a+2*pi for a in angles]\n for j in range(m):\n  theta=angles[j]+pi/2;lo=bisect_left(angles,theta-eps,j+1,j+m);hi=bisect_right(angles,theta+eps,j+1,j+m);end=bisect_left(angles,angles[j]+pi-eps,j+1,j+m);right+=hi-lo;obtuse+=end-hi\nprint(n*(n-1)*(n-2)//6-right-obtuse,right,obtuse)\n",
'abc041_d':"n,m=map(int,input().split());before=[0]*n\nfor _ in range(m):a,b=map(int,input().split());before[b-1]|=1<<(a-1)\ndp=[0]*(1<<n);dp[0]=1\nfor mask in range(1<<n):\n for j in range(n):\n  if not mask>>j&1 and before[j]&mask==before[j]:dp[mask|1<<j]+=dp[mask]\nprint(dp[-1])\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');k=int(pid[3:6]);rng=random.Random(18000+k);raws:list[str]=[]
    if k==29:raws=[f'{n}\n' for n in (1,2,9,10,11,12,19,20,99,100,101,110,111,999,1000,99999999,100000000,999999999)]
    elif k==30:
        def graph(start:int,steps:str,a:list[int])->str:return f'{len(a)} {start}\n{steps}\n'+line(a)
        raws=[graph(1,'1',[2,1]),graph(1,'2',[2,1]),graph(2,'3',[2,1]),graph(1,'1',[2,3,2])]
        for n in range(3,16):raws.append(graph(1,str(n*n+1),list(range(2,n+1))+[max(1,n//2)]))
        raws.append(graph(100000,'1'+'0'*100000,list(range(2,100001))+[1]))
    elif k==31:
        def words(mapping:list[str],digits:list[str])->str:return f'{len(mapping)} {len(digits)}\n'+''.join(v+' '+''.join(mapping[int(d)-1] for d in v)+'\n' for v in digits)
        raws=[words(['a'],['1']),words(['abc'],['1']),words(['a'],['111']), '2 1\n12 abcab\n']
        for n in range(2,15):
            size=1+n%9;mapping=[chr(97+j)*(1+j%3) for j in range(size)];digits=[str(j) for j in range(1,size+1)]+[''.join(str(rng.randint(1,size)) for _ in range(9)) for _ in range(n)];raws.append(words(mapping,digits))
        mapping=[chr(97+j)*3 for j in range(9)];raws.append(words(mapping,['123456789']+[''.join(str(rng.randint(1,9)) for _ in range(9)) for _ in range(49)]))
    elif k==32:
        def knapsack(capacity:int,items:list[tuple[int,int]])->str:return f'{len(items)} {capacity}\n'+''.join(line(item) for item in items)
        raws=[knapsack(1,[(1,1)]),knapsack(1,[(10**9,10**9)]),knapsack(1,[(1,1),(2,1)]),knapsack(2,[(1,1),(2,1)])]
        raws += [knapsack(10000,[(rng.randint(1,10**9),rng.randint(1,1000)) for _ in range(n)]) for n in range(3,13)]
        raws += [knapsack(10**9,[(rng.randint(1,10**9),rng.randint(1,10**9)) for _ in range(30)]),knapsack(10**9,[(10**9,10**9)]*30),knapsack(10**9,[(10**9,1000)]*200),knapsack(10**9,[(1000,10**9)]*200)]
    elif k==33:
        def points(p:list[Point])->str:return f'{len(p)}\n'+''.join(line(point) for point in p)
        raws=[points([(0,0),(1,0),(0,1)]),points([(0,0),(2,0),(1,2)]),points([(0,0),(4,0),(1,1)]),points([(-10000,-10000),(10000,-10000),(-10000,10000)])]
        raws += [points([(j,j*j) for j in range(n)]) for n in range(4,17)]
        raws.append(points([(j-1000,(j*j)%2003-1000) for j in range(2000)]))
    else:
        def race(n:int,edges:list[Point])->str:return f'{n} {len(edges)}\n'+''.join(line(edge) for edge in edges)
        raws=[race(2,[(1,2)]),race(2,[(2,1)]),race(3,[(1,2)]),race(3,[(1,2),(2,3)])]
        for j in range(12):
            n=4+j//2;raws.append(race(n,[(a,b) for a in range(1,n+1) for b in range(a+1,n+1) if b==a+1 or rng.randrange(3)==0]))
        raws += [race(16,[(1,2)]),race(16,[(a,b) for a in range(1,17) for b in range(a+1,17)])]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc029_d':('各桁で1が出る回数を数える方法があります。','桁DPで上限未満かどうかと、書いた数の個数・1の累積個数を管理します。','疑似コード: dp[tight]=(ways,ones); Nの各桁を読んで許されるdigitへ遷移し、onesにways*(digit==1)を加算; 最終onesの合計を出力。'),
'abc030_d':('同じ単語に戻ると、その後は周期的です。','初回訪問位置を保存し、周期の開始と長さを求めます。巨大kは文字列のまま剰余を計算します。','疑似コード: 未訪問の間pathへ追加; mu=再訪単語の初回添字、period=len(path)-mu; k<muならpath[k]、他はpath[mu+(k mod period-mu) mod period]。'),
'abc031_d':('数字ごとの文字列長は1、2、3のいずれかです。','3^K通りの長さを試し、各wをその長さで切って同じ数字の割当が一致するか調べます。','疑似コード: lengthsを全列挙; 各(v,w)をdigits順に切り、同じdigitの切片が既知割当と一致するか検査; 全組一致ならK個の割当を出力。'),
'abc032_d':('制約は3種類の解法のいずれかが使えるように決められています。','N<=30なら半分全列挙、重さ<=1000なら重さDP、それ以外は価値DPを使います。','疑似コード: 小Nは左右subsetを列挙し残容量へ二分探索; 小weightはdp[weight]=最大value; 小valueはdp[value]=最小weight; 容量W内の最大valueを出力。'),
'abc033_d':('直角・鈍角になる角は三角形ごとに高々1個です。','各点を頂点として方向角を並べ、90度ちょうどと90〜180度の方向を数えます。','疑似コード: 各pivotのatan2方向をsortして2π分複製; 各方向からπ/2とπの境界を二分探索しright/obtuse加算; 全組合せ-right-obtuseをacuteとする。'),
'abc041_d':('既にゴールしたうさぎの集合を状態にします。','前に来るべきうさぎが全て集合内なら、次にそのうさぎを追加できます。','疑似コード: dp[0]=1; 各maskと未選択jでbefore[j]がmaskの部分集合ならdp[mask|1<<j]+=dp[mask]; dp[(1<<N)-1]を出力。')}

TITLES={'abc029_d': '1', 'abc030_d': 'へんてこ辞書', 'abc031_d': '語呂合わせ', 'abc032_d': 'ナップサック問題', 'abc033_d': '三角形の分類', 'abc041_d': '徒競走'}
PUBLISHED_SAMPLES={'abc029_d': [{'input': '12\n', 'expected': '5\n'}, {'input': '345\n', 'expected': '175\n'}, {'input': '999999999\n', 'expected': '900000000\n'}], 'abc030_d': [{'input': '6 4\n5\n2 3 1 2 6 5\n', 'expected': '3\n'}, {'input': '4 1\n100000000000000000000\n2 3 4 1\n', 'expected': '1\n'}, {'input': '8 1\n1\n2 3 4 5 3 2 4 5\n', 'expected': '2\n'}], 'abc031_d': [{'input': '6 4\n356 migoro\n461 yoroi\n2 ni\n12 ini\n', 'expected': 'i\nni\nmi\nyo\ngo\nro\n'}, {'input': '3 4\n21 aaa\n12 aaa\n123 aaaaaa\n13 aaaa\n', 'expected': 'a\naa\naaa\n'}, {'input': '2 3\n12211 abcaaaaabcabc\n2121 aaabcaaabc\n222221 aaaaaaaaaaabc\n', 'expected': 'abc\naa\n'}, {'input': '2 1\n12 abcab\n', 'expected': 'ab\ncab\n'}], 'abc032_d': [{'input': '3 10\n15 9\n10 6\n6 4\n', 'expected': '16\n'}, {'input': '30 499887702\n128990795 137274936\n575374246 989051853\n471048785 85168425\n640066776 856699603\n819841327 611065509\n704171581 22345022\n536108301 678298936\n119980848 616908153\n117241527 28801762\n325850062 478675378\n623319578 706900574\n998395208 738510039\n475707585 135746508\n863910036 599020879\n340559411 738084616\n122579234 545330137\n696368935 86797589\n665665204 592749599\n958833732 401229830\n371084424 523386474\n463433600 5310725\n210508742 907821957\n685281136 565237085\n619500108 730556272\n88215377 310581512\n558193168 136966252\n475268130 132739489\n303022740 12425915\n122379996 137199296\n304092766 23505143\n', 'expected': '3673016420\n'}, {'input': '10 2921\n981421680 325\n515936168 845\n17309336 371\n788067075 112\n104855562 96\n494541604 960\n32007355 161\n772339969 581\n55112800 248\n98577050 22\n', 'expected': '3657162058\n'}, {'input': '10 936447862\n854 810169801\n691 957981784\n294 687140254\n333 932608409\n832 42367415\n642 727293784\n139 870916042\n101 685539955\n853 243593312\n369 977358410\n', 'expected': '1686\n'}], 'abc033_d': [{'input': '5\n1 3\n2 2\n3 2\n4 1\n4 3\n', 'expected': '1 2 7\n'}, {'input': '9\n2 0\n1 1\n3 1\n1 2\n5 2\n0 3\n4 3\n2 4\n4 4\n', 'expected': '27 14 43\n'}], 'abc041_d': [{'input': '3 2\n2 1\n2 3\n', 'expected': '2\n'}, {'input': '5 5\n1 2\n2 3\n3 5\n1 4\n4 5\n', 'expected': '3\n'}, {'input': '16 1\n1 2\n', 'expected': '10461394944000\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
