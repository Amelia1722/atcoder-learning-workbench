"""Problem-specific three-stage hints from manually reviewed public ABC050–052 B tasks."""
HINTS_V64 = {
    'abc050_b': (
        '各ドリンクで全N問の合計を最初から計算し直す必要があるか考えてください。変わる問題は1問だけです。',
        '通常時の合計を一度だけ求め、各ドリンクでは変更前のT[P-1]を引いてXを足します。',
        '疑似コード:\nbase=sum(T)\n各(P,X)について:\n  print(base - T[P-1] + X)',
    ),
    'abc051_b': (
        'X,Y,Zを3重ループする前に、2つを決めた後の残り1つが自動的に決まることに注目してください。',
        'XとYを0..Kで全探索し、Z=S-X-Yが0..Kに入る場合だけ数えます。',
        '疑似コード:\nans=0\nfor X in 0..K:\n  for Y in 0..K:\n    Z=S-X-Y\n    if 0<=Z<=K: ans+=1\nprint(ans)',
    ),
    'abc052_b': (
        '必要なのは最後のxではなく、途中も含めた最大値です。開始前のx=0も候補に入ります。',
        '左からIなら+1、Dなら-1して、そのたびに最大値を更新します。',
        '疑似コード:\nx=0; ans=0\nfor c in S:\n  x += 1 if c==I else -1\n  ans=max(ans,x)\nprint(ans)',
    ),
}
