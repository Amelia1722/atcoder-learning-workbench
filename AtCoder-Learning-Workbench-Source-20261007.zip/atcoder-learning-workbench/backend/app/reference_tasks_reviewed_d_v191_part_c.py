"""Private ABC234..239 D domains and materially independent oracles."""
from __future__ import annotations
from collections import deque
from functools import lru_cache
from itertools import permutations
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(234,240))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc234_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=k<=n<=500000 and len(set(a))==n and all(1<=v<=n for v in a),'permutation');return k,a
    if pid=='abc235_d':
        require(len(rows)==1,'shape');a,n=ints(rows[0],2);require(2<=a<10**6 and 2<=n<10**6,'range');return a,n
    if pid=='abc236_d':
        n=ints(rows[0],1)[0];require(1<=n<=8 and len(rows)==2*n,'shape');values=tuple(ints(row,2*n-j-1) for j,row in enumerate(rows[1:]));require(all(0<=v<2**30 for row in values for v in row),'range');return (values,)
    if pid=='abc237_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=500000 and len(rows[1])==n and set(rows[1])<=set('LR'),'range/string');return (rows[1],)
    if pid=='abc238_d':
        t=ints(rows[0],1)[0];require(1<=t<=100000 and len(rows)==t+1,'shape');queries=tuple(ints(row,2) for row in rows[1:]);require(all(0<=a<2**60 and 0<=s<2**60 for a,s in queries),'range');return (queries,)
    require(len(rows)==1,'shape');a,b,c,d=ints(rows[0],4);require(1<=a<=b<=100 and 1<=c<=d<=100,'range');return a,b,c,d

def prefix_fenwick(k:int,a:tuple[int,...])->list[int]:
    n=len(a);tree=[0]*(n+1);result=[]
    for length,value in enumerate(a,1):
        j=value
        while j<=n:tree[j]+=1;j+=j&-j
        if length>=k:
            rank=length-k+1;j=0;step=1<<(n.bit_length()-1)
            while step:
                nxt=j+step
                if nxt<=n and tree[nxt]<rank:rank-=tree[nxt];j=nxt
                step//=2
            result.append(j+1)
    return result
def rotation_reverse(a:int,n:int)->int:
    distance={n:0};queue=deque([n]);limit=10**len(str(n))
    while queue:
        value=queue.popleft();d=distance[value]
        if value==1:return d
        candidates=[]
        if value%a==0:candidates.append(value//a)
        power=10**(len(str(value))-1)
        if power>=10 and value%(power)//(power//10)>0:candidates.append(value%power*10+value//power)
        for previous in candidates:
            if 0<previous<limit and previous not in distance:distance[previous]=d+1;queue.append(previous)
    return -1
def dance_halves(values:tuple[tuple[int,...],...])->int:
    size=len(values)+1;half=size//2;matrix=[[0]*size for _ in range(size)]
    for i,row in enumerate(values):
        for j,value in enumerate(row,i+1):matrix[i][j]=matrix[j][i]=value
    full=(1<<half)-1
    @lru_cache(None)
    def internal(mask:int,offset:int)->tuple[int,...]:
        if not mask:return (0,)
        first=(mask&-mask).bit_length()-1;rest=mask^(1<<first);answers=[];choices=rest
        while choices:
            bit=choices&-choices;other=bit.bit_length()-1;answers.extend(matrix[first+offset][other+offset]^v for v in internal(rest^bit,offset));choices^=bit
        return tuple(answers)
    by_size:dict[int,list[int]]={}
    for mask in range(full+1):
        if (half-mask.bit_count())%2==0:by_size.setdefault(mask.bit_count(),[]).append(mask)
    answer=0
    for count,masks in by_size.items():
        for left in masks:
            ls=[j for j in range(half) if left>>j&1];left_values=internal(full^left,0)
            for right in masks:
                rs=[j+half for j in range(half) if right>>j&1];inside={u^v for u in left_values for v in internal(full^right,half)}
                for matching in permutations(rs):
                    crossing=0
                    for u,v in zip(ls,matching):crossing^=matrix[u][v]
                    answer=max(answer,max(crossing^v for v in inside))
    return answer
def linked_insertion(s:str)->list[int]:
    n=len(s);left=[-1]*(n+1);right=[-1]*(n+1);head=0
    for previous,char in enumerate(s):
        value=previous+1
        if char=='L':
            neighbor=left[previous];left[value]=neighbor;right[value]=previous;left[previous]=value
            if neighbor<0:head=value
            else:right[neighbor]=value
        else:
            neighbor=right[previous];right[value]=neighbor;left[value]=previous;right[previous]=value
            if neighbor>=0:left[neighbor]=value
    result=[]
    while head>=0:result.append(head);head=right[head]
    return result
def and_sum_carries(a:int,s:int)->bool:
    # Each bit permits (0,0),(0,1),(1,0) when AND=0, or only (1,1).
    carry=0
    for j in range(61):
        total=((s>>j)&1)-carry
        if (a>>j)&1:
            if total%2:return False
            carry=(2+carry)//2
        else:
            digit=total%2
            carry=(digit+carry)//2
    return carry==0
def prime_game_sieve(a:int,b:int,c:int,d:int)->str:
    prime=[True]*201;prime[0]=prime[1]=False
    for p in range(2,15):
        if prime[p]:
            for value in range(p*p,201,p):prime[value]=False
    reply_counts=[sum(prime[value+reply] for reply in range(c,d+1)) for value in range(a,b+1)]
    return 'Takahashi' if 0 in reply_counts else 'Aoki'
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc234_d':k,a=cast(tuple[int,tuple[int,...]],data);return '\n'.join(map(str,prefix_fenwick(k,a)))
    if pid=='abc235_d':a,n=cast(tuple[int,int],data);return str(rotation_reverse(a,n))
    if pid=='abc236_d':return str(dance_halves(cast(tuple[tuple[int,...],...],data[0])))
    if pid=='abc237_d':return ' '.join(map(str,linked_insertion(cast(str,data[0]))))
    if pid=='abc238_d':return '\n'.join('Yes' if and_sum_carries(a,s) else 'No' for a,s in cast(tuple[tuple[int,...],...],data[0]))
    a,b,c,d=cast(tuple[int,int,int,int],data);return prime_game_sieve(a,b,c,d)
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:
        if output_mode not in (None,'exact'):return False
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc234_d':'''import sys,heapq
n,k=map(int,input().split());p=list(map(int,input().split()));heap=p[:k];heapq.heapify(heap);answers=[str(heap[0])]
for value in p[k:]:
 if value>heap[0]:heapq.heapreplace(heap,value)
 answers.append(str(heap[0]))
print('\\n'.join(answers))
''',
'abc235_d':'''from collections import deque
a,n=map(int,input().split());limit=10**len(str(n));distance=[-1]*limit;distance[1]=0;queue=deque([1])
while queue:
 value=queue.popleft()
 if value==n:break
 candidates=[value*a]
 if value>=10 and value%10:candidates.append(value%10*(10**(len(str(value))-1))+value//10)
 for nxt in candidates:
  if nxt<limit and distance[nxt]<0:distance[nxt]=distance[value]+1;queue.append(nxt)
print(distance[n])
''',
'abc236_d':'''n=int(input());size=2*n;matrix=[[0]*size for _ in range(size)]
for i in range(size-1):
 for j,value in enumerate(map(int,input().split()),i+1):matrix[i][j]=value
answer=0
def search(mask,value):
 global answer
 if not mask:answer=max(answer,value);return
 bit=mask&-mask;i=bit.bit_length()-1;rest=mask^bit;choices=rest
 while choices:
  pair=choices&-choices;j=pair.bit_length()-1;search(rest^pair,value^matrix[i][j]);choices^=pair
search((1<<size)-1,0);print(answer)
''',
'abc237_d':'''from collections import deque
n=int(input());s=input();answer=deque([n])
for i in range(n-1,-1,-1):
 if s[i]=='L':answer.append(i)
 else:answer.appendleft(i)
print(*answer)
''',
'abc238_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);answer=[]
for _ in range(t):
 a,s=next(it),next(it);v=s-2*a;answer.append('Yes' if v>=0 and v&a==0 else 'No')
print('\\n'.join(answer))
''',
'abc239_d':'''import math
a,b,c,d=map(int,input().split())
def prime(n):return n>=2 and all(n%p for p in range(2,math.isqrt(n)+1))
print('Takahashi' if any(all(not prime(x+y) for y in range(c,d+1)) for x in range(a,b+1)) else 'Aoki')
'''}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(19100+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc234_d':
        def prefix(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[prefix(1,[1]),prefix(1,[2,1]),prefix(2,[2,1]),prefix(2,[1,3,2])]
        for n in range(4,16):a=list(range(1,n+1));rng.shuffle(a);raws.append(prefix(rng.randint(1,n),a))
        raws += [prefix(1,list(range(500000,0,-1))),prefix(500000,list(range(1,500001)))]
    elif pid=='abc235_d':
        raws=['2 2\n','2 3\n','3 72\n','10 100\n','10 101\n','2 61\n']
        raws += [f'{rng.randint(2,999999)} {rng.randint(2,999999)}\n' for _ in range(10)]
        raws += ['2 999999\n','999999 999999\n']
    elif pid=='abc236_d':
        def dance(n:int,a:list[list[int]])->str:return f'{n}\n'+''.join(line(row) for row in a)
        raws=[dance(1,[[0]]),dance(1,[[2**30-1]]),dance(2,[[1,2,3],[4,5],[6]]),dance(2,[[0]*3,[0]*2,[0]])]
        for j in range(12):n=1+j//2;raws.append(dance(n,[[rng.randrange(2**30) for _ in range(2*n-i-1)] for i in range(2*n-1)]))
        raws += [dance(8,[[rng.randrange(2**30) for _ in range(15-i)] for i in range(15)]),dance(8,[[2**30-1]*(15-i) for i in range(15)])]
    elif pid=='abc237_d':
        def insertion(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[insertion('L'),insertion('R'),insertion('LR'),insertion('RL')]+[insertion(''.join(rng.choice('LR') for _ in range(n))) for n in range(3,15)]+[insertion('LR'*250000),insertion('R'*500000)]
    elif pid=='abc238_d':
        def queries(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(pair) for pair in a)
        raws=[queries([(0,0)]),queries([(2**60-1,2**60-1)]),queries([(0,2**60-1)]),queries([(1,2),(1,3),(1,4),(2**59-1,2**60-2)])]
        for n in range(2,14):raws.append(queries([(rng.randrange(2**60),rng.randrange(2**60)) for _ in range(n)]))
        raws += [queries([(j,j*2) for j in range(100000)]),queries([(2**60-1,2**60-1)]*100000)]
    else:
        raws=['1 1 1 1\n','1 1 2 2\n','99 100 99 100\n','1 100 1 100\n']
        for _ in range(13):a=rng.randint(1,100);b=rng.randint(a,100);c=rng.randint(1,100);d=rng.randint(c,100);raws.append(f'{a} {b} {c} {d}\n')
        raws.append('100 100 100 100\n')
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc234_d':('各prefixの大きい方K個だけを残せば、最小値が答えです。','大きい方K個を最小heapに入れます。新しい値がheapの最小値より大きければ置き換えます。','疑似コード: heap=最初K要素をheap化; 最小値を出力; 残りvalueでvalue>heap[0]ならheapreplace; 各回heap[0]を出力。'),
'abc235_d':('整数を状態、操作を辺とする最短経路を考えます。','桁数は減らないため、Nより桁数が多い整数は探索不要です。1から幅優先探索し、掛け算と末尾を先頭へ移す操作を試します。','疑似コード: limit=10^桁数(N); dist[1]=0; BFSでvalue*aと、value>=10かつ末尾非0なら末尾移動を生成; limit未満の未訪問状態へdist+1; dist[N]を出力。'),
'abc236_d':('ペアの作り方を全探索し、全ペアの値のXORを最大化します。','まだ使っていない最小番号を一人固定し、その相手だけを選びます。同じペア集合を順序違いで重複列挙しません。','疑似コード: search(unused,xor); unused空ならanswer=max(answer,xor); 最小iを除く; 残る各jでsearch(unusedからi,jを除いた集合,xor XOR A[i,j]); 初期全員で探索。'),
'abc237_d':('最後の整数Nから挿入操作を逆向きに復元できます。','S[i]がLならiの左にi+1が入ったので、逆向きにはiを右端へ追加します。Rなら左端へ追加します。','疑似コード: deque=[N]; i=N-1..0でS[i]==Lならappend(i)、Rならappendleft(i); dequeを順に出力。'),
'abc238_d':('x+y=(x XOR y)+2*(x AND y)を使えます。','必要なXORはs-2aです。この値が非負で、ANDの1ビットとXORの1ビットが重ならなければ構成できます。','疑似コード: 各(a,s)でv=s-2*a; v>=0かつ(v AND a)==0ならYes、そうでなければNoを出力。'),
'abc239_d':('高橋君の選んだ値ごとに、青木君が素数を作れる返答があるか調べます。','どの返答でも和が合成数になる高橋君の選択が一つあれば、高橋君が勝てます。和は最大200なので素数判定は小さく済みます。','疑似コード: prime(n)は2..isqrt(n)で割り切れないか検査; x=A..Bのどれかで全y=C..Dについてnot prime(x+y)ならTakahashi、他Aoki。')}

TITLES={'abc234_d': 'Prefix K-th Max', 'abc235_d': 'Multiply and Rotate', 'abc236_d': 'Dance', 'abc237_d': 'LR insertion', 'abc238_d': 'AND and SUM', 'abc239_d': 'Prime Sum Game'}
PUBLISHED_SAMPLES={'abc234_d': [{'input': '3 2\n1 2 3\n', 'expected': '1\n2\n'}, {'input': '11 5\n3 7 2 5 11 6 1 9 8 10 4\n', 'expected': '2\n3\n3\n5\n6\n7\n7\n'}], 'abc235_d': [{'input': '3 72\n', 'expected': '4\n'}, {'input': '2 5\n', 'expected': '-1\n'}, {'input': '2 611\n', 'expected': '12\n'}, {'input': '2 767090\n', 'expected': '111\n'}], 'abc236_d': [{'input': '2\n4 0 1\n5 3\n2\n', 'expected': '6\n'}, {'input': '1\n5\n', 'expected': '5\n'}, {'input': '5\n900606388 317329110 665451442 1045743214 260775845 726039763 57365372 741277060 944347467\n369646735 642395945 599952146 86221147 523579390 591944369 911198494 695097136\n138172503 571268336 111747377 595746631 934427285 840101927 757856472\n655483844 580613112 445614713 607825444 252585196 725229185\n827291247 105489451 58628521 1032791417 152042357\n919691140 703307785 100772330 370415195\n666350287 691977663 987658020\n1039679956 218233643\n70938785\n', 'expected': '1073289207\n'}], 'abc237_d': [{'input': '5\nLRRLR\n', 'expected': '1 2 4 5 3 0\n'}, {'input': '7\nLLLLLLL\n', 'expected': '7 6 5 4 3 2 1 0\n'}], 'abc238_d': [{'input': '2\n1 8\n4 2\n', 'expected': 'Yes\nNo\n'}, {'input': '4\n201408139683277485 381410962404666524\n360288799186493714 788806911317182736\n18999951915747344 451273909320288229\n962424162689761932 1097438793187620758\n', 'expected': 'No\nYes\nYes\nNo\n'}], 'abc239_d': [{'input': '2 3 3 4\n', 'expected': 'Aoki\n'}, {'input': '1 100 50 60\n', 'expected': 'Takahashi\n'}, {'input': '3 14 1 5\n', 'expected': 'Aoki\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
