"""ABC083–085 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random, re

TASKS=('abc083_b','abc084_b','abc085_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
POSTAL_CHARS=re.compile(r'[0-9-]+', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc083_b':
        if len(lines)!=1: raise ValueError('lines')
        parts=lines[0].split(' ')
        if len(parts)!=3 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('NAB')
        n,a,b=map(int,parts)
        if not (1<=n<=10**4 and 1<=a<=b<=36): raise ValueError('range')
        return n,a,b
    if pid=='abc084_b':
        if len(lines)!=2: raise ValueError('lines')
        parts=lines[0].split(' ')
        if len(parts)!=2 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('AB')
        a,b=map(int,parts); s=lines[1]
        if not (1<=a<=5 and 1<=b<=5 and len(s)==a+b+1 and POSTAL_CHARS.fullmatch(s) is not None):
            raise ValueError('format/range')
        return a,b,s
    if not lines or len(lines)<2 or POS.fullmatch(lines[0]) is None: raise ValueError('N')
    n=int(lines[0])
    if not 1<=n<=100 or len(lines)!=n+1: raise ValueError('range/lines')
    if any(POS.fullmatch(x) is None for x in lines[1:]): raise ValueError('d')
    d=list(map(int,lines[1:]))
    if any(not 1<=x<=100 for x in d): raise ValueError('range')
    return d

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc083_b':
        n,a,b=value; total=0
        for x in range(1,n+1):
            y=x; ds=0
            while y:
                ds += y%10; y//=10
            if a<=ds<=b: total += x
        return output==str(total)
    if pid=='abc084_b':
        a,b,s=value
        ok=(s[a]=='-' and all('0'<=ch<='9' for ch in s[:a]) and all('0'<=ch<='9' for ch in s[a+1:]))
        return output==('Yes' if ok else 'No')
    seen=[False]*101
    for x in value: seen[x]=True
    return output==str(sum(seen))

def generate(pid:str, seed:int=75)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    random.Random(f'abc-v75:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc083_b':
        vals=[
          (1,1,1),(9,1,9),(10,1,1),(20,2,5),(99,18,18),(100,1,1),(100,4,16),
          (999,1,27),(1000,1,1),(1234,10,10),(4321,1,36),(5000,20,30),(9999,36,36),
          (3141,5,15),(7777,7,28),(10000,1,1),(10000,2,36)]
        for n,a,b in vals: add('boundary' if n in (1,10000) or a==b else 'normal',f'{n} {a} {b}\n')
        add('constraint_max','10000 1 36\n')
    elif pid=='abc084_b':
        vals=[
          (1,1,'0-0'),(1,1,'---'),(1,2,'7-44'),(1,2,'7444'),(2,1,'12-3'),(2,1,'1-23'),
          (3,4,'269-6650'),(3,4,'2696650-'),(3,4,'269--650'),(4,2,'0000-00'),(4,2,'000000-'),
          (5,1,'12345-6'),(1,5,'1-23456'),(2,5,'99-00000'),(5,2,'12345-67'),
          (5,5,'00000-00000'),(5,5,'99999-99999')]
        for a,b,s in vals: add('boundary' if a==5 or b==5 else 'normal',f'{a} {b}\n{s}\n')
        add('constraint_max','5 5\n12345-67890\n')
    else:
        vals=[
          [1],[100],[1,1],[1,2],[10,8,8,6],[15,15,15],[50,30,50,100,50,80,30],
          [1,2,3,4,5],[5,4,3,2,1],[10,20,10,20],[100,99,98,97],[42]*10,
          list(range(1,21)),[1,100]*20,[3,3,2,2,1,1],list(range(50,68)),[100]*99]
        for d in vals: add('boundary' if len(d) in (1,99) else 'normal',f'{len(d)}\n'+'\n'.join(map(str,d))+'\n')
        add('constraint_max','100\n'+'\n'.join(map(str,range(1,101)))+'\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
