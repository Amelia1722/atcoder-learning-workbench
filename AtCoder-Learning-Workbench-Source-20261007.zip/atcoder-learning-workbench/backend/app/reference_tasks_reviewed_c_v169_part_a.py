"""Reviewed C tasks with offline merge trees, max flow and Hamiltonian subset DP."""
from __future__ import annotations
from bisect import bisect_right
from collections import Counter,defaultdict,deque
from heapq import merge
from itertools import groupby
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(297,303))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc297_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
Grid=tuple[str,...]
Queries=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def components(grid:Grid)->list[set[tuple[int,int]]]:
    h=len(grid);w=len(grid[0]);remaining={(r,c) for r,row in enumerate(grid) for c,ch in enumerate(row) if ch=='#'};answer=[]
    while remaining:
        start=remaining.pop();component={start};pending=[start]
        while pending:
            r,c=pending.pop()
            for dr in (-1,0,1):
                for dc in (-1,0,1):
                    cell=r+dr,c+dc
                    if cell in remaining:remaining.remove(cell);component.add(cell);pending.append(cell)
        answer.append(component)
    return answer
def cross_size(component:set[tuple[int,int]])->int:
    lowr=min(r for r,c in component);highr=max(r for r,c in component);lowc=min(c for r,c in component);highc=max(c for r,c in component);size=(highr-lowr)//2;r=(lowr+highr)//2;c=(lowc+highc)//2;expected={(r,c)}|{(r+dr*d,c+dc*d) for d in range(1,size+1) for dr in (-1,1) for dc in (-1,1)};require(size>=1 and highr-lowr==highc-lowc==2*size and component==expected,'cross geometry');return size
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number in (297,300):
        h,w=ints(rows[0],2);require((1<=h<=100 and 2<=w<=100 if number==297 else 3<=h<=100 and 3<=w<=100) and len(rows)==h+1 and all(len(row)==w and set(row)<=({'T','.'} if number==297 else {'#','.'}) for row in rows[1:]),'grid');grid=tuple(rows[1:])
        if number==300:
            for component in components(grid):cross_size(component)
        return (grid,)
    if number==298:
        require(len(rows)>=3,'shape');n=ints(rows[0],1)[0];q=ints(rows[1],1)[0];require(1<=n<=200000 and 1<=q<=200000 and len(rows)==q+2,'bounds');queries=tuple(ints(row) for row in rows[2:]);boxcounts:Counter[int]=Counter();cardboxes:dict[int,set[int]]=defaultdict(set);outputcount=0
        for query in queries:
            require(query[0] in (1,2,3) and len(query)==(3 if query[0]==1 else 2),'query')
            if query[0]==1:
                _,card,box=query;require(1<=card<=200000 and 1<=box<=n,'insert');boxcounts[box]+=1;cardboxes[card].add(box)
            elif query[0]==2:
                box=query[1];require(1<=box<=n and boxcounts[box]>0,'nonempty box');outputcount+=boxcounts[box]
            else:
                card=query[1];require(1<=card<=200000 and bool(cardboxes[card]),'present card');outputcount+=len(cardboxes[card])
        require(outputcount<=200000,'output budget');return n,queries
    if number==299:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(1<=n<=200000 and len(s)==n and set(s)<={'o','-'},'dango');return (s,)
    if number==301:
        require(len(rows)==2 and 1<=len(rows[0])<=200000 and len(rows[0])==len(rows[1]) and all(re.fullmatch('[a-z@]+',s) is not None for s in rows),'cards');return tuple(rows)
    n,m=ints(rows[0],2);require(2<=n<=8 and 1<=m<=5 and len(rows)==n+1 and len(set(rows[1:]))==n and all(len(s)==m and re.fullmatch('[a-z]+',s) is not None for s in rows[1:]),'strings');return (tuple(rows[1:]),)
def _offline_reports(events:list[tuple[int,int]],requests:list[tuple[int,int]],outputs:list[str])->None:
    if not requests:return
    size=1
    while size<len(events):size*=2
    tree:list[list[int]]=[[] for _ in range(2*size)]
    for j,(_,value) in enumerate(events):tree[size+j]=[value]
    for j in range(size-1,0,-1):tree[j]=list(merge(tree[2*j],tree[2*j+1]))
    times=[t for t,v in events]
    for timestamp,index in requests:
        left=size;right=size+bisect_right(times,timestamp);blocks=[]
        while left<right:
            if left&1:blocks.append(tree[left]);left+=1
            if right&1:right-=1;blocks.append(tree[right])
            left//=2;right//=2
        outputs[index]=' '.join(map(str,merge(*blocks)))
def _cards_flow(s:str,t:str)->bool:
    letters='abcdefghijklmnopqrstuvwxyz@';left=Counter(s);right=Counter(t);capacity=[[0]*56 for _ in range(56)];source=54;sink=55
    for i,ch in enumerate(letters):
        capacity[source][i]=left[ch];capacity[27+i][sink]=right[ch]
        for j,other in enumerate(letters):
            if ch==other or ch=='@' and other in 'atcoder' or other=='@' and ch in 'atcoder':capacity[i][27+j]=len(s)
    flow=0
    while True:
        parent=[-1]*56;parent[source]=source;queue=deque([source])
        while queue and parent[sink]==-1:
            u=queue.popleft()
            for v,value in enumerate(capacity[u]):
                if value and parent[v]==-1:parent[v]=u;queue.append(v)
        if parent[sink]==-1:break
        increment=len(s);v=sink
        while v!=source:increment=min(increment,capacity[parent[v]][v]);v=parent[v]
        v=sink
        while v!=source:u=parent[v];capacity[u][v]-=increment;capacity[v][u]+=increment;v=u
        flow+=increment
    return flow==len(s)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==297:
        grid=cast(Grid,data[0]);out=[]
        for row in grid:
            parts=[]
            for ch,chars in groupby(row):
                length=sum(1 for _ in chars);parts.append('T'*(length%2)+'PC'*(length//2) if ch=='T' else '.'*length)
            out.append(''.join(parts))
        return '\n'.join(out)
    if number==298:
        _,queries=cast(tuple[int,Queries],data);boxes:dict[int,list[tuple[int,int]]]=defaultdict(list);cards:dict[int,list[tuple[int,int]]]=defaultdict(list);boxrequests:dict[int,list[tuple[int,int]]]=defaultdict(list);cardrequests:dict[int,list[tuple[int,int]]]=defaultdict(list);seen:set[tuple[int,int]]=set();outputs=[]
        for timestamp,query in enumerate(queries):
            if query[0]==1:
                _,card,box=query;boxes[box].append((timestamp,card))
                if (card,box) not in seen:seen.add((card,box));cards[card].append((timestamp,box))
            else:
                (boxrequests if query[0]==2 else cardrequests)[query[1]].append((timestamp,len(outputs)));outputs.append('')
        for key,requests in boxrequests.items():_offline_reports(boxes[key],requests,outputs)
        for key,requests in cardrequests.items():_offline_reports(cards[key],requests,outputs)
        return '\n'.join(outputs)
    if number==299:
        s=cast(str,data[0]);length=max(map(len,s.split('-')));return str(length if '-' in s and length>0 else -1)
    if number==300:
        grid=cast(Grid,data[0]);answer=[0]*min(len(grid),len(grid[0]))
        for component in components(grid):answer[(len(component)-1)//4-1]+=1
        return ' '.join(map(str,answer))
    if number==301:return 'Yes' if _cards_flow(*cast(tuple[str,str],data)) else 'No'
    strings=cast(tuple[str,...],data[0]);n=len(strings);neighbors=[sum(1<<j for j,t in enumerate(strings) if sum(a!=b for a,b in zip(s,t))==1) for s in strings];dp=[0]*(1<<n)
    for j in range(n):dp[1<<j]=1<<j
    for mask in range(1,1<<n):
        for j in range(n):
            if not dp[mask]>>j&1:continue
            options=neighbors[j]&~mask
            while options:bit=options&-options;options-=bit;dp[mask|bit]|=bit
    return 'Yes' if dp[-1] else 'No'
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc297_c':
            grid=cast(Grid,validate(pid,raw)[0]);out=actual.removesuffix('\n').split('\n');require(len(out)==len(grid),'rows')
            for source,target in zip(grid,out):
                require(len(source)==len(target),'width');j=pairs=0
                while j<len(source):
                    if target[j]=='P':require(j+1<len(source) and source[j:j+2]=='TT' and target[j:j+2]=='PC','operation');pairs+=1;j+=2
                    else:require(target[j]==source[j],'preserve');j+=1
                require(pairs==sum(len(run)//2 for run in source.split('.')),'optimal')
            return True
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc297_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc297_c':"h,w=map(int,input().split())\nfor _ in range(h):\n s=list(input());j=0\n while j+1<w:\n  if s[j]==s[j+1]=='T':s[j]='P';s[j+1]='C';j+=2\n  else:j+=1\n print(''.join(s))\n",
'abc298_c':"from collections import defaultdict\nn=int(input());q=int(input());boxes=defaultdict(list);cards=defaultdict(set)\nfor _ in range(q):\n query=list(map(int,input().split()))\n if query[0]==1:_,i,j=query;boxes[j].append(i);cards[i].add(j)\n elif query[0]==2:print(*sorted(boxes[query[1]]))\n else:print(*sorted(cards[query[1]]))\n",
'abc299_c':"n=int(input());s=input();answer=-1;run=0\nfor i,ch in enumerate(s):\n if ch=='o':run+=1\n else:\n  if run:answer=max(answer,run)\n  run=0\nif run and '-' in s:answer=max(answer,run)\nprint(answer)\n",
'abc300_c':"h,w=map(int,input().split());s=[input() for _ in range(h)];answer=[0]*min(h,w)\nfor r in range(h):\n for c in range(w):\n  if s[r][c]!='#':continue\n  size=0\n  while r-size-1>=0 and r+size+1<h and c-size-1>=0 and c+size+1<w and all(s[r+dr*(size+1)][c+dc*(size+1)]=='#' for dr in (-1,1) for dc in (-1,1)):size+=1\n  if size:answer[size-1]+=1\nprint(*answer)\n",
'abc301_c':"from collections import Counter\ns=Counter(input());t=Counter(input());ok=True\nfor ch in 'abcdefghijklmnopqrstuvwxyz':\n if ch not in 'atcoder':ok&=s[ch]==t[ch]\n elif s[ch]>t[ch]:t['@']-=s[ch]-t[ch]\n else:s['@']-=t[ch]-s[ch]\nprint('Yes' if ok and s['@']>=0 and t['@']>=0 else 'No')\n",
'abc302_c':"from itertools import permutations\nn,m=map(int,input().split());s=[input() for _ in range(n)];edges=[[sum(a!=b for a,b in zip(x,y))==1 for y in s] for x in s];print('Yes' if any(all(edges[p[i]][p[i+1]] for i in range(n-1)) for p in permutations(range(n))) else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16900+number)
    if number==297:
        def grid(rows:list[str])->str:return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'
        raws=[grid(['..']),grid(['TT']),grid(['TTT']),grid(['T.T'])];raws.extend(grid([''.join(rng.choice('T.') for _ in range(n)) for _ in range(2+n%5)]) for n in range(4,16));raws.extend([grid(['T'*100]*99+['.'*100]),grid(['T'*100]*100)])
    elif number==298:
        def queries(n:int,qs:list[tuple[int,...]])->str:return f'{n}\n{len(qs)}\n'+''.join(line(q) for q in qs)
        raws=[queries(1,[(1,1,1)]),queries(1,[(1,1,1),(2,1)]),queries(1,[(1,1,1),(1,1,1),(3,1)]),queries(2,[(1,1,1),(1,1,2),(3,1),(2,1)])]
        for n in range(3,15):
            qs:list[tuple[int,...]]=[];records=[]
            for _ in range(n*3):
                if not records or rng.random()<.6:card=rng.randint(1,10);box=rng.randint(1,n);records.append((card,box));qs.append((1,card,box))
                else:card,box=rng.choice(records);qs.append((2,box) if rng.randrange(2) else (3,card))
            raws.append(queries(n,qs))
        raws.extend([queries(200000,[(1,200000,box) for box in range(1,200000)]+[(3,200000)]),queries(200000,[(1,card,200000) for card in range(1,200000)]+[(2,200000)])])
    elif number==299:
        def dango(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[dango(s) for s in ('-','o','-o','o-')];raws.extend(dango(''.join(rng.choice('o-') for _ in range(n))) for n in range(3,15));raws.extend([dango('o'*200000),dango('o'*199999+'-')])
    elif number==300:
        def crossgrid(h:int,w:int,crosses:list[tuple[int,int,int]])->str:
            rows=[['.']*w for _ in range(h)]
            for r,c,size in crosses:
                rows[r][c]='#'
                for d in range(1,size+1):
                    for dr in (-1,1):
                        for dc in (-1,1):rows[r+dr*d][c+dc*d]='#'
            return f'{h} {w}\n'+'\n'.join(''.join(row) for row in rows)+'\n'
        raws=[crossgrid(3,3,[]),crossgrid(3,3,[(1,1,1)]),crossgrid(3,4,[(1,1,1)]),crossgrid(5,5,[(2,2,2)])]
        raws.extend(crossgrid(2*size+3,2*size+5,[(size+1,size+1,size)]) for size in range(1,13));raws.extend([crossgrid(100,100,[(r,c,1) for r in range(1,99,4) for c in range(1,99,4)]),crossgrid(100,100,[(49,49,49)])])
    elif number==301:
        raws=[s+'\n'+t+'\n' for s,t in (('a','a'),('@','a'),('@','b'),('@@','@@'))]
        for n in range(3,15):raws.append(''.join(rng.choice('atcoder@xyz') for _ in range(n))+'\n'+''.join(rng.choice('atcoder@xyz') for _ in range(n))+'\n')
        raws.extend(['@'*200000+'\n'+'a'*200000+'\n','@'*200000+'\n'+'z'*200000+'\n'])
    else:
        def strings(s:list[str])->str:return f'{len(s)} {len(s[0])}\n'+'\n'.join(s)+'\n'
        raws=[strings(['a','b']),strings(['aa','bb']),strings(['aa','ab','bb']),strings(['aa','ab','ba'])]
        for j in range(12):
            n=4+j%5;m=2+j//5;s=set()
            while len(s)<n:s.add(''.join(rng.choice('abc') for _ in range(m)))
            raws.append(strings(sorted(s)))
        raws.extend([strings([c+'aaaa' for c in 'abcdefgh']),strings([c*5 for c in 'abcdefgh'])])
    require(len(raws)==len(set(raws))==18,'unique cases')
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc297_c':('Tの連続区間ごとに隣り合う2文字をペアにできます。','左からTTをPCへ置き換えると、長さLの区間にfloor(L/2)台を置けます。','疑似コード: 各行を左から走査; TTならPCに置換して2文字進む; 他は1文字進む; 各行を出力。'),
'abc298_c':('箱からカードと、カードから箱の両方向を記録します。','箱側は重複を保持する列、カード側は重複を除く集合を使います。','疑似コード: 追加でboxes[j].append(i), cards[i].add(j); type2でsort(boxes[i]); type3でsort(cards[i]); 各結果を1行で出力。'),
'abc299_c':('ハイフンに隣接するoの連続区間を探します。','ハイフンが1つでもあれば、oの最長連続長が答えです。oがない場合も解なしです。','疑似コード: run=0, answer=-1; 各文字がoならrun++; ハイフンならrunが正の場合answer=max(answer,run)としてrun=0; 最終runもハイフンがある場合だけ採用。'),
'abc300_c':('各中心候補から4方向の斜めの腕を伸ばします。','4方向すべて#である最大距離がバツ印のサイズです。中心以外は4方向を同時に伸ばせません。','疑似コード: 各#の中心でsize=0; 距離size+1の斜め4マスが範囲内かつ#ならsize++; size>0ならcount[size]++; count[1..min(H,W)]を出力。'),
'abc301_c':('並べ替えられるので位置より文字の個数が重要です。','atcoder以外の文字数は一致が必要です。atcoderの不足分を反対側の@で補います。','疑似コード: S,Tの文字数を数える; 各文字で差を求める; atcoder以外で差があればNo; atcoderの差だけ不足側の@を減らす; 両側@が非負ならYes。'),
'abc302_c':('最大8文字列なので全ての並べ替えを試せます。','各文字列ペアについて、ちょうど1文字だけ異なるかを先に求めます。','疑似コード: edge[i][j]=(相違文字数==1); 各順列pで全隣接edge[p[k]][p[k+1]]を確認; 全てtrueの順列があればYes、なければNo。')}

TITLES={'abc297_c': 'PC on the Table', 'abc298_c': 'Cards Query Problem', 'abc299_c': 'Dango', 'abc300_c': 'Cross', 'abc301_c': 'AtCoder Cards', 'abc302_c': 'Almost Equal'}
PUBLISHED_SAMPLES={'abc297_c': [{'input': '2 3\nTTT\nT.T\n', 'expected': 'PCT\nT.T\n'}, {'input': '3 5\nTTT..\n.TTT.\nTTTTT\n', 'expected': 'PCT..\n.PCT.\nPCTPC\n'}], 'abc298_c': [{'input': '5\n8\n1 1 1\n1 2 4\n1 1 4\n2 4\n1 1 4\n2 4\n3 1\n3 2\n', 'expected': '1 2\n1 1 2\n1 4\n4\n'}, {'input': '1\n5\n1 1 1\n1 2 1\n1 200000 1\n2 1\n3 200000\n', 'expected': '1 2 200000\n1\n'}], 'abc299_c': [{'input': '10\no-oooo---o\n', 'expected': '4\n'}, {'input': '1\n-\n', 'expected': '-1\n'}, {'input': '30\n-o-o-oooo-oo-o-ooooooo--oooo-o\n', 'expected': '7\n'}], 'abc300_c': [{'input': '5 9\n#.#.#...#\n.#...#.#.\n#.#...#..\n.....#.#.\n....#...#\n', 'expected': '1 1 0 0 0\n'}, {'input': '3 3\n...\n...\n...\n', 'expected': '0 0 0\n'}, {'input': '3 16\n#.#.....#.#..#.#\n.#.......#....#.\n#.#.....#.#..#.#\n', 'expected': '3 0 0\n'}, {'input': '15 20\n#.#..#.............#\n.#....#....#.#....#.\n#.#....#....#....#..\n........#..#.#..#...\n#.....#..#.....#....\n.#...#....#...#..#.#\n..#.#......#.#....#.\n...#........#....#.#\n..#.#......#.#......\n.#...#....#...#.....\n#.....#..#.....#....\n........#.......#...\n#.#....#....#.#..#..\n.#....#......#....#.\n#.#..#......#.#....#\n', 'expected': '5 0 1 0 0 0 1 0 0 0 0 0 0 0 0\n'}], 'abc301_c': [{'input': 'ch@ku@ai\nchoku@@i\n', 'expected': 'Yes\n'}, {'input': 'ch@kud@i\nakidu@ho\n', 'expected': 'Yes\n'}, {'input': 'aoki\n@ok@\n', 'expected': 'No\n'}, {'input': 'aa\nbb\n', 'expected': 'No\n'}], 'abc302_c': [{'input': '4 4\nbbed\nabcd\nabed\nfbed\n', 'expected': 'Yes\n'}, {'input': '2 5\nabcde\nabced\n', 'expected': 'No\n'}, {'input': '8 4\nfast\nface\ncast\nrace\nfact\nrice\nnice\ncase\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
