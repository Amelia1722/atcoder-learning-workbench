"""ABC050–052 B task-specific local oracles based on manually reviewed public statements.

Official HTML bytes have not been archived or authenticated. Ready means only the
saved generated inputs and transcribed examples were independently crosschecked.
"""
from __future__ import annotations
import math
import random
import re

TASKS = ('abc050_b', 'abc051_b', 'abc052_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
ID = re.compile(r'[ID]+', re.ASCII)


def _numbers(line: str, count: int) -> tuple[int, ...]:
    parts = line.split(' ')
    if len(parts) != count or any(INT.fullmatch(s) is None for s in parts):
        raise ValueError('invalid integer line')
    return tuple(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown problem or noncanonical input')
    lines = raw[:-1].split('\n')
    if pid == 'abc050_b':
        if not lines:
            raise ValueError('missing input')
        (n,) = _numbers(lines[0], 1)
        if not (1 <= n <= 100) or len(lines) < 3:
            raise ValueError('N outside constraints or truncated input')
        t = _numbers(lines[1], n)
        if any(not 1 <= x <= 10**5 for x in t):
            raise ValueError('T outside constraints')
        (m,) = _numbers(lines[2], 1)
        if not (1 <= m <= 100) or len(lines) != 3 + m:
            raise ValueError('M outside constraints or wrong query count')
        queries = []
        for line in lines[3:]:
            p, x = _numbers(line, 2)
            if not (1 <= p <= n and 1 <= x <= 10**5):
                raise ValueError('drink query outside constraints')
            queries.append((p, x))
        return n, t, queries
    if pid == 'abc051_b':
        if len(lines) != 1:
            raise ValueError('one line required')
        k, s = _numbers(lines[0], 2)
        if not (2 <= k <= 2500 and 0 <= s <= 3*k):
            raise ValueError('K or S outside constraints')
        return k, s
    if len(lines) != 2:
        raise ValueError('two lines required')
    (n,) = _numbers(lines[0], 1)
    s = lines[1]
    if not (1 <= n <= 100 and len(s) == n and ID.fullmatch(s) is not None):
        raise ValueError('N or operation string outside constraints')
    return n, s


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc050_b':
        _, times, queries = value
        answers = []
        for p, x in queries:
            changed = list(times)
            changed[p-1] = x
            answers.append(str(sum(changed)))
        return output == '\n'.join(answers)
    if pid == 'abc051_b':
        k, s = value
        # Inclusion-exclusion on upper bounds: independent from the O(K^2) reference.
        total = 0
        for j in range(4):
            remaining = s - j*(k+1)
            if remaining >= 0:
                total += (-1)**j * math.comb(3, j) * math.comb(remaining+2, 2)
        return output == str(total)
    _, ops = value
    # Compute each prefix from counts rather than mutating x in the reference order.
    best = max([0] + [ops[:i].count('I') - ops[:i].count('D') for i in range(1, len(ops)+1)])
    return output == str(best)


def generate(pid: str, seed: int = 64) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown problem')
    rng = random.Random(f'abc-v64:{pid}:{seed}')
    rows: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category': category, 'input': raw})
    if pid == 'abc050_b':
        def fmt(times, queries):
            return f'{len(times)}\n' + ' '.join(map(str, times)) + f'\n{len(queries)}\n' + ''.join(f'{p} {x}\n' for p,x in queries)
        fixtures = [
            ([1],[(1,1)]),([100000],[(1,1)]),([1],[(1,100000)]),
            ([2,1,4],[(1,1),(2,3)]),([5,5],[(1,5),(2,5)]),
            ([1,2,3],[(3,1)]),([99999,1],[(1,100000),(2,100000)]),
            ([7,2,3,8,5],[(4,2),(1,7),(4,13)]),([1,1,1],[(1,2),(1,3)]),
            ([10,20,30,40],[(4,1),(1,100000)]),([3,4],[(2,3)]),
            ([100000,100000],[(1,100000)]),([1,100000],[(2,1)]),([42],[(1,43)])]
        for times,queries in fixtures:
            add('boundary' if len(times)==1 else 'normal',fmt(times,queries))
        while len(rows) < 17:
            n=rng.randint(1,30); times=[rng.randint(1,100000) for _ in range(n)]
            queries=[(rng.randint(1,n),rng.randint(1,100000)) for _ in range(rng.randint(1,20))]
            add('random',fmt(times,queries))
        times=[100000 if i%2 else 1 for i in range(100)]
        queries=[(i%100+1, 100000-(i%7)) for i in range(100)]
        add('constraint_max',fmt(times,queries))
    elif pid == 'abc051_b':
        fixtures=[(2,0),(2,1),(2,2),(2,6),(5,15),(5,0),(5,14),(10,10),
                  (10,20),(10,30),(100,150),(2500,0),(2500,1),(2500,7500)]
        for k,s in fixtures:add('boundary' if s in (0,3*k) else 'normal',f'{k} {s}\n')
        while len(rows)<17:
            k=rng.randint(2,80);s=rng.randint(0,3*k);add('random',f'{k} {s}\n')
        add('constraint_max','2500 3750\n')
    else:
        fixtures=['I','D','II','DD','ID','DI','IIDID','DDIDDII','I'*100,'D'*100,
                  'ID'*50,'DI'*50,'IIIIDDDD','DIIII','DDDIDIII','IIDDDII']
        for s in fixtures:add('boundary' if len(s) in (1,100) else 'normal',f'{len(s)}\n{s}\n')
        while len(rows)<17:
            n=rng.randint(1,100);s=''.join(rng.choice('ID') for _ in range(n));add('random',f'{n}\n{s}\n')
        add('constraint_max','100\n'+'I'*50+'D'*50+'\n')
    if len(rows)!=18 or rows[-1]['category']!='constraint_max' or len(seen)!=18:
        raise ValueError(f'{pid}: expected 18 distinct cases and final maximum, got {len(rows)}')
    return rows
