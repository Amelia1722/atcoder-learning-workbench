"""Hexagonal tile metric, palindrome-event inclusion exclusion and width feasibility."""
from __future__ import annotations
from collections import Counter
from functools import lru_cache
from itertools import accumulate
from math import factorial
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(359,365))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc362_c':'semantic'}
Pair=tuple[int,int]
Data=tuple[object,...]
Case=dict[str,str]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==359:
        require(len(rows)==2,'shape');s,t=ints(rows[0],2),ints(rows[1],2);require(all(0<=v<=2*10**16 for pair in (s,t) for v in pair),'coordinates');return s,t
    if number==360:
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];require(1<=n<=100000,'length');a,w=ints(rows[1],n),ints(rows[2],n);require(all(1<=v<=n for v in a) and all(1<=v<=10000 for v in w),'packages');return a,w
    if number==361:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);require(1<=k<n<=200000,'length');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'values');return k,a
    if number==362:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'length');pairs=tuple(ints(row,2) for row in rows[1:]);require(all(-10**9<=l<=r<=10**9 for l,r in pairs),'intervals');return (pairs,)
    if number==363:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);s=rows[1];require(2<=k<=n<=10 and len(s)==n and re.fullmatch('[a-z]+',s) is not None,'letters');return k,s
    require(len(rows)==3,'shape');n,x,y=ints(rows[0],3);require(1<=n<=200000 and 1<=x<=2*10**14 and 1<=y<=2*10**14,'bounds');a,b=ints(rows[1],n),ints(rows[2],n);require(all(1<=v<=10**9 for seq in (a,b) for v in seq),'tastes');return x,y,a,b

def _tile_metric(s:Pair,t:Pair)->int:
    def position(p:Pair)->Pair:
        x,y=p;x-=(x+y)&1;return (x+y)//2,(x-y)//2
    u,v=position(s);a,b=position(t);du,dv=a-u,b-v;return max(abs(du),abs(dv),abs(du-dv))

def _minimum_width(k:int,a:tuple[int,...])->int:
    ordered=sorted(a);need=len(a)-k;low=-1;high=ordered[-1]-ordered[0]
    def feasible(width:int)->bool:
        left=0
        for right,value in enumerate(ordered):
            while value-ordered[left]>width:left+=1
            if right-left+1>=need:return True
        return False
    while high-low>1:
        middle=(low+high)//2
        if feasible(middle):high=middle
        else:low=middle
    return high

@lru_cache(maxsize=10000)
def _equalities_count(blocks:tuple[int,...],counts:tuple[int,...])->int:
    if not blocks:
        ways=factorial(sum(counts))
        for count in counts:ways//=factorial(count)
        return ways
    size=blocks[0];answer=0
    for j,count in enumerate(counts):
        if count<size:continue
        remaining=list(counts);remaining[j]-=size;answer+=_equalities_count(blocks[1:],tuple(sorted(remaining)))
    return answer

def _avoid_palindromes(k:int,s:str)->int:
    n=len(s);events=n-k+1;counts=tuple(sorted(Counter(s).values()));answer=0
    for mask in range(1<<events):
        parent=list(range(n))
        def root(v:int)->int:
            while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
            return v
        for start in range(events):
            if not mask>>start&1:continue
            for offset in range(k//2):
                a,b=root(start+offset),root(start+k-1-offset);parent[b]=a
        sizes=Counter(root(v) for v in range(n));blocks=tuple(sorted((size for size in sizes.values() if size>1),reverse=True));ways=_equalities_count(blocks,counts);answer+=(-1 if mask.bit_count()%2 else 1)*ways
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==359:return str(_tile_metric(*cast(tuple[Pair,Pair],data)))
    if number==360:
        a,w=cast(tuple[tuple[int,...],tuple[int,...]],data);occupied=set();moved=0
        for weight,box in sorted(zip(w,a),reverse=True):
            if box in occupied:moved+=weight
            else:occupied.add(box)
        return str(moved)
    if number==361:return str(_minimum_width(*cast(tuple[int,tuple[int,...]],data)))
    if number==362:
        pairs=cast(tuple[Pair,...],data[0]);values=[min(max(0,l),r) for l,r in pairs];total=sum(values)
        for j in range(len(pairs)-1,-1,-1):
            l,r=pairs[j]
            if total>0:change=min(total,values[j]-l);values[j]-=change;total-=change
            elif total<0:change=min(-total,r-values[j]);values[j]+=change;total+=change
        return 'No' if total else 'Yes\n'+' '.join(map(str,values))
    if number==363:return str(_avoid_palindromes(*cast(tuple[int,str],data)))
    x,y,a,b=cast(tuple[int,int,tuple[int,...],tuple[int,...]],data);pa=list(accumulate(sorted(a),initial=0));pb=list(accumulate(sorted(b),initial=0));n=len(a);low=0;high=n+1
    while high-low>1:
        count=(low+high)//2
        if pa[-1]-pa[n-count]>x or pb[-1]-pb[n-count]>y:high=count
        else:low=count
    return str(min(n,high))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc362_c':
            pairs=cast(tuple[Pair,...],validate(pid,raw)[0]);token=actual.removesuffix('\n');possible=sum(l for l,r in pairs)<=0<=sum(r for l,r in pairs)
            if token=='No':return not possible
            rows=token.split('\n');require(len(rows)==2 and rows[0]=='Yes','witness');values=ints(rows[1],len(pairs));return sum(values)==0 and all(l<=v<=r for v,(l,r) in zip(values,pairs))
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc362_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc359_c':"sx,sy=map(int,input().split());tx,ty=map(int,input().split());sx-=(sx+sy)%2;tx-=(tx+ty)%2;dx=abs(tx-sx);dy=abs(ty-sy);print(dy+max(0,(dx-dy)//2))\n",
'abc360_c':"n=int(input());a=list(map(int,input().split()));w=list(map(int,input().split()));best=[0]*n\nfor box,weight in zip(a,w):best[box-1]=max(best[box-1],weight)\nprint(sum(w)-sum(best))\n",
'abc361_c':"n,k=map(int,input().split());a=sorted(map(int,input().split()));length=n-k;print(min(a[i+length-1]-a[i] for i in range(k+1)))\n",
'abc362_c':"n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];low=sum(l for l,r in a);high=sum(r for l,r in a)\nif not low<=0<=high:print('No')\nelse:\n need=-low;out=[]\n for l,r in a:change=min(need,r-l);out.append(l+change);need-=change\n print('Yes');print(*out)\n",
'abc363_c':"from math import factorial\nn,k=map(int,input().split());s=input()\nif len(set(s))==n:print(factorial(n))\nelse:\n p=sorted(s);answer=0\n while True:\n  answer+=all(p[i:i+k]!=p[i:i+k][::-1] for i in range(n-k+1));i=n-2\n  while i>=0 and p[i]>=p[i+1]:i-=1\n  if i<0:break\n  j=n-1\n  while p[j]<=p[i]:j-=1\n  p[i],p[j]=p[j],p[i];p[i+1:]=reversed(p[i+1:])\n print(answer)\n",
'abc364_c':"n,x,y=map(int,input().split());a=sorted(map(int,input().split()),reverse=True);b=sorted(map(int,input().split()),reverse=True)\ndef count(values,limit):\n total=0\n for i,v in enumerate(values,1):\n  total+=v\n  if total>limit:return i\n return n\nprint(min(count(a,x),count(b,y)))\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17200+number)
    if number==359:
        def travel(s:Pair,t:Pair)->str:return line(s)+line(t)
        raws=[travel((0,0),(0,0)),travel((0,0),(1,0)),travel((1,0),(2,0)),travel((0,0),(0,1))]
        raws.extend(travel((rng.randrange(100),rng.randrange(100)),(rng.randrange(100),rng.randrange(100))) for _ in range(12));raws.extend([travel((0,2*10**16),(2*10**16,0)),travel((2*10**16,2*10**16),(2*10**16,2*10**16))])
    elif number==360:
        def packages(a:list[int],w:list[int])->str:return f'{len(a)}\n'+line(a)+line(w)
        raws=[packages(a,w) for a,w in (([1],[1]),([1,1],[1,2]),([1,2],[1,2]),([2,2,2],[3,1,2]))];raws.extend(packages([rng.randint(1,n) for _ in range(n)],[rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([packages(list(range(1,100001)),[10000]*100000),packages([100000]*100000,[10000]*100000)])
    elif number==361:
        def remove(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[remove(k,a) for k,a in ((1,[1,1]),(1,[1,2]),(1,[1,2,100]),(2,[1,2,100]))];raws.extend(remove(rng.randint(1,n-1),[rng.randint(1,100) for _ in range(n)]) for n in range(4,16));raws.extend([remove(1,list(range(1,200001))),remove(199999,[10**9]*200000)])
    elif number==362:
        def intervals(a:list[Pair])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[intervals(a) for a in ([(0,0)],[(1,1)],[(-1,-1)],[(-1,1),(-1,1)])]
        for n in range(3,15):raws.append(intervals([tuple(sorted((rng.randint(-100,100),rng.randint(-100,100)))) for _ in range(n)]))
        raws.extend([intervals([(-10**9,-10**9)]*100000+[(10**9,10**9)]*100000),intervals([(-10**9,10**9)]*200000)])
    elif number==363:
        pairs=[(2,'aa'),(2,'ab'),(2,'aab'),(3,'aba'),(2,'aabb'),(3,'aabb'),(4,'aabb'),(2,'abcde'),(3,'abcde'),(4,'aabccd'),(5,'aabccd'),(6,'aabccd'),(2,'aabbccdd'),(3,'aabbccdd'),(4,'abcwxyzyxw'),(5,'abcwxyzyxw'),(2,'abcdefghij'),(10,'z'*10)];raws=[f'{len(s)} {k}\n{s}\n' for k,s in pairs]
    else:
        def foods(x:int,y:int,a:list[int],b:list[int])->str:return f'{len(a)} {x} {y}\n'+line(a)+line(b)
        raws=[foods(x,y,a,b) for x,y,a,b in ((1,1,[1],[1]),(1,1,[2],[1]),(2,2,[1,1],[1,1]),(2,2,[2,1],[1,2]))];raws.extend(foods(rng.randint(1,100),rng.randint(1,100),[rng.randint(1,30) for _ in range(n)],[rng.randint(1,30) for _ in range(n)]) for n in range(3,15));raws.extend([foods(10**9,2*10**14,[10**9]*200000,[1]*200000),foods(2*10**14,2*10**14,[10**9]*200000,[10**9]*200000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<4 or i==16 else 'deterministic_random'} for i,raw in enumerate(raws)]

HINTS={
'abc359_c':('同じ横長タイル内の移動は無料です。','各位置をタイル左側のマスへ正規化します。縦移動では1マス分の横ずれも吸収できます。','疑似コード: x-=(x+y)%2で両端正規化; dx=abs(tx-sx),dy=abs(ty-sy); dy+max(0,(dx-dy)//2)を出力。'),
'abc360_c':('各箱に最も重い荷物を一つ残せば、移す重さが最小です。','全重量から、各箱の最大重量の合計を引きます。','疑似コード: 各boxのbest=max(best,W); sum(W)-sum(best)を出力。'),
'abc361_c':('残すN-K要素の最大最小だけが重要です。','値をソートし、連続したN-K要素の範囲幅を全て試します。','疑似コード: sort(A); length=N-K; min(A[i+length-1]-A[i], i=0..K)を出力。'),
'abc362_c':('全て下限を選んだ総和と、全て上限を選んだ総和の間に0が必要です。','下限から始め、総和を0にする不足分を上限までの余裕に割り振ります。','疑似コード: sum(L)<=0<=sum(R)でなければNo; need=-sum(L); 各区間でd=min(need,R-L),X=L+d,need-=d; YesとXを出力。'),
'abc363_c':('Nが10以下なので異なる並べ替えを列挙できます。','昇順から次の辞書順の並べ替えへ進み、各長さKの部分文字列が回文か確認します。','疑似コード: P=sort(S); 各異なるPで全windowを調べ回文無しならanswer++; next_permutation(P)が無くなるまで反復; answerを出力。'),
'abc364_c':('甘さかしょっぱさのどちらかを最も早く超えれば終了します。','それぞれ値の大きい順に並べ、合計が閾値を超える最初の個数を求めます。','疑似コード: A,Bを各降順sort; 各列でprefixが閾値を超える最初のcount（無ければN）を求め、2つのminを出力。')}

TITLES={'abc359_c': 'Tile Distance 2', 'abc360_c': 'Move It', 'abc361_c': 'Make Them Narrow', 'abc362_c': 'Sum = 0', 'abc363_c': 'Avoid K Palindrome 2', 'abc364_c': 'Minimum Glutton'}
PUBLISHED_SAMPLES={'abc359_c': [{'input': '5 0\n2 5\n', 'expected': '5\n'}, {'input': '3 1\n4 1\n', 'expected': '0\n'}, {'input': '2552608206527595 5411232866732612\n771856005518028 7206210729152763\n', 'expected': '1794977862420151\n'}], 'abc360_c': [{'input': '5\n2 2 3 3 5\n33 40 2 12 16\n', 'expected': '35\n'}, {'input': '12\n3 6 7 4 12 4 8 11 11 1 8 11\n3925 9785 9752 3587 4013 1117 3937 7045 6437 6208 3391 6309\n', 'expected': '17254\n'}], 'abc361_c': [{'input': '5 2\n3 1 5 4 9\n', 'expected': '2\n'}, {'input': '6 5\n1 1 1 1 1 1\n', 'expected': '0\n'}, {'input': '8 3\n31 43 26 6 18 36 22 13\n', 'expected': '18\n'}], 'abc362_c': [{'input': '3\n3 5\n-4 1\n-2 3\n', 'expected': 'Yes\n4 -3 -1\n'}, {'input': '3\n1 2\n1 2\n1 2\n', 'expected': 'No\n'}, {'input': '6\n-87 12\n-60 -54\n2 38\n-76 6\n87 96\n-17 38\n', 'expected': 'Yes\n-66 -57 31 -6 89 9\n'}], 'abc363_c': [{'input': '3 2\naab\n', 'expected': '1\n'}, {'input': '5 3\nzzyyx\n', 'expected': '16\n'}, {'input': '10 5\nabcwxyzyxw\n', 'expected': '440640\n'}], 'abc364_c': [{'input': '4 7 18\n2 3 5 1\n8 8 1 4\n', 'expected': '2\n'}, {'input': '5 200000000000000 200000000000000\n1 1 1 1 1\n2 2 2 2 2\n', 'expected': '5\n'}, {'input': '8 30 30\n1 2 3 4 5 6 7 8\n8 7 6 5 4 3 2 1\n', 'expected': '6\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
