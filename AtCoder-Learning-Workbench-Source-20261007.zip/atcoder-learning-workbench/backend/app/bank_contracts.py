"""Data-only validation shared by private recovery and the hint reader."""
import re
MAX_HINT_CHARACTERS = 20_000
PROBLEM_ID = re.compile(r'(?:abc|arc)\d{3,4}_(?:[a-g]|[1-7])$')


def validate_hint_map(hints: object) -> dict:
    if not isinstance(hints, dict):
        raise ValueError('hints must be a problem-keyed object')
    max_characters = max_bytes = 0
    for pid, values in hints.items():
        if not isinstance(pid, str) or not PROBLEM_ID.fullmatch(pid):
            raise ValueError('Invalid hint problem ID')
        if not isinstance(values, list) or len(values) != 3:
            raise ValueError('Each problem must have exactly three progressive hints')
        for value in values:
            if not isinstance(value, str) or not value.strip() or len(value) > MAX_HINT_CHARACTERS:
                raise ValueError('Hints must be nonempty strings of at most 20000 characters')
            max_characters = max(max_characters, len(value))
            max_bytes = max(max_bytes, len(value.encode('utf-8')))
    return {'sets':len(hints),'max_hint_characters':max_characters,'max_hint_utf8_bytes':max_bytes}
