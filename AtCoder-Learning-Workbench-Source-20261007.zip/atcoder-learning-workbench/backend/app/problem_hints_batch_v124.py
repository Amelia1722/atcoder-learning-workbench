"""Statement-checked three-stage hints for ABC230–232 B."""
HINTS_V124 = {
    'abc230_b': (
        '文字列Tは `oxx` を繰り返した周期3の文字列です。Sの先頭がTの周期のどの位置に対応するかは3通りしかありません。',
        'Sの各文字が、ある開始位置から見た `o,x,x,o,x,x,...` と最後まで一致するかを調べれば十分です。Sの長さは最大10なので、十分長い `oxxoxx...` を作って部分文字列判定しても構いません。',
        '疑似コード:\npattern = "oxx" を十分回数繰り返す\nif S is substring of pattern:\n  print("Yes")\nelse:\n  print("No")',
    ),
    'abc231_b': (
        '必要なのは各候補者の得票数です。同じ名前が何回現れたかを数えれば、選挙の順序そのものは重要ではありません。',
        '辞書やCounterで `名前 -> 得票数` を集計し、値が最大の名前を取り出します。問題文で最多得票者は一意と保証されています。',
        '疑似コード:\ncount = empty map\nfor each vote name s:\n  count[s] += 1\nanswer = key whose count is maximum\nprint(answer)',
    ),
    'abc232_b': (
        '全ての文字に同じKを足すので、各位置での「Sの文字からTの文字までのずれ」が26を法として全て同じである必要があります。',
        '最初の1文字から必要なシフト量Kを決めます。そのKをSの全ての文字に適用したときTと一致するか、または各位置の差 `(T_i-S_i) mod 26` が同じか確認します。',
        '疑似コード:\nk = (code(T[0]) - code(S[0])) mod 26\nfor i = 0 .. len(S)-1:\n  if (code(T[i]) - code(S[i])) mod 26 != k:\n    print("No")\n    stop\nprint("Yes")',
    ),
}
