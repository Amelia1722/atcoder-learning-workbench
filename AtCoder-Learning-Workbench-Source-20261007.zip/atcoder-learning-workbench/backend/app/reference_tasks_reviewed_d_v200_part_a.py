"""Private ABC389..394 D strict domains and independent oracles."""
from __future__ import annotations
from collections import Counter,deque
from decimal import Decimal,DecimalException,localcontext
from fractions import Fraction
from functools import lru_cache
from math import isqrt
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(389,395));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc392_d':'numeric_tolerance_1e-8'};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integer fields');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'field count');return a
def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc389_d':require(len(r)==1,'rows');radius=ints(r[0],1)[0];require(1<=radius<=10**6,'radius');return (radius,)
 if pid=='abc390_d':
  n=ints(r[0],1)[0];require(2<=n<=12 and len(r)==2,'N/rows');a=ints(r[1],n);require(all(1<=v<=10**17 for v in a),'Ai');return (a,)
 if pid=='abc391_d':
  n,w=ints(r[0],2);require(1<=w<=n<=200000 and len(r)>=n+3,'N/W/rows');blocks=tuple(ints(row,2) for row in r[1:n+1]);q=ints(r[n+1],1)[0];require(1<=q<=200000 and len(r)==n+q+2,'Q/rows');queries=tuple(ints(row,2) for row in r[n+2:]);require(len(set(blocks))==n and all(1<=x<=w and 1<=y<=10**9 for x,y in blocks) and all(1<=t<=10**9 and 1<=a<=n for t,a in queries),'coordinates/queries');return w,blocks,queries
 if pid=='abc392_d':
  n=ints(r[0],1)[0];require(2<=n<=100 and len(r)==n+1,'N/rows');dice=[];total=0
  for row in r[1:]:
   fields=ints(row);k=fields[0];require(k>=1 and len(fields)==k+1 and all(1<=v<=10**5 for v in fields[1:]),'die');dice.append(fields[1:]);total+=k
  require(total<=100000,'sum Ki');return (tuple(dice),)
 if pid=='abc393_d':
  n=ints(r[0],1)[0];require(2<=n<=500000 and len(r)==2 and re.fullmatch('[01]{'+str(n)+'}',r[1]) is not None and '1' in r[1],'string');return (r[1],)
 require(len(r)==1 and re.fullmatch(r'[()\[\]<>]{1,200000}',r[0]) is not None,'brackets');return (r[0],)

def squares_integer_roots(radius:int)->int:
 limit=4*radius*radius;answer=0
 for x in range(radius):
  y=(isqrt(limit-(2*x+1)**2)-1)//2;answer+=(2*y+1)*(1 if x==0 else 2)
 return answer

@lru_cache(maxsize=128)
def partitions_anchored_subsets(a:tuple[int,...])->int:
 n=len(a);sums=[0]*(1<<n)
 for mask in range(1,1<<n):bit=mask&-mask;sums[mask]=sums[mask^bit]+a[bit.bit_length()-1]
 outcomes:set[int]=set()
 def visit(mask:int,value:int)->None:
  if mask==0:outcomes.add(value);return
  anchor=mask&-mask;others=mask^anchor;subset=others
  while True:
   group=subset|anchor;visit(mask^group,value^sums[group])
   if subset==0:break
   subset=(subset-1)&others
 visit((1<<n)-1,0);answer=len(outcomes);outcomes.clear();return answer

def blocks_global_height_ranks(w:int,blocks:tuple[tuple[int,...],...],queries:tuple[tuple[int,...],...])->list[str]:
 levels=[0]*w;ranks=[0]*len(blocks);maxima:list[int]=[]
 for y,x,index in sorted((y,x-1,index) for index,(x,y) in enumerate(blocks)):
  rank=levels[x];levels[x]+=1;ranks[index]=rank
  if rank==len(maxima):maxima.append(y)
  else:maxima[rank]=max(maxima[rank],y)
 full=min(levels);return ['Yes' if ranks[a-1]>=full or t<maxima[ranks[a-1]] else 'No' for t,a in queries]

def dice_inverted_exact(dice:tuple[tuple[int,...],...])->Fraction:
 postings:dict[int,list[tuple[int,int]]]={};n=len(dice);scores=[[0]*n for _ in range(n)]
 for i,die in enumerate(dice):
  for value,count in Counter(die).items():postings.setdefault(value,[]).append((i,count))
 for entries in postings.values():
  for at,(i,ci) in enumerate(entries):
   for j,cj in entries[at+1:]:scores[i][j]+=ci*cj
 numerator=0;denominator=1
 for i in range(n):
  for j in range(i+1,n):
   value=scores[i][j];divisor=len(dice[i])*len(dice[j])
   if value*denominator>numerator*divisor:numerator,denominator=value,divisor
 return Fraction(numerator,denominator)

def ones_weighted_zero_gaps(s:str)->int:
 positions=[i for i,char in enumerate(s) if char=='1'];k=len(positions)
 return sum((right-left-1)*min(i+1,k-i-1) for i,(left,right) in enumerate(zip(positions,positions[1:])))

def brackets_linked_deletions(s:str)->bool:
 n=len(s);previous=list(range(-1,n-1));following=list(range(1,n))+[-1];alive=bytearray([1])*n;pairs={'()','[]','<>'};queue=deque((i,i+1) for i in range(n-1) if s[i:i+2] in pairs);remaining=n
 while queue:
  left,right=queue.popleft()
  if not alive[left] or not alive[right] or following[left]!=right:continue
  before=previous[left];after=following[right];alive[left]=alive[right]=0;remaining-=2
  if before>=0:following[before]=after
  if after>=0:previous[after]=before
  if before>=0 and after>=0 and s[before]+s[after] in pairs:queue.append((before,after))
 return remaining==0

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc389_d':return str(squares_integer_roots(cast(int,d[0])))+'\n'
 if pid=='abc390_d':return str(partitions_anchored_subsets(cast(tuple[int,...],d[0])))+'\n'
 if pid=='abc391_d':return '\n'.join(blocks_global_height_ranks(*cast(tuple[int,tuple[tuple[int,...],...],tuple[tuple[int,...],...]],d)))+'\n'
 if pid=='abc392_d':
  value=dice_inverted_exact(cast(tuple[tuple[int,...],...],d[0]))
  with localcontext() as context:context.prec=90;return str(Decimal(value.numerator)/value.denominator)+'\n'
 if pid=='abc393_d':return str(ones_weighted_zero_gaps(cast(str,d[0])))+'\n'
 return ('Yes' if brackets_linked_deletions(cast(str,d[0])) else 'No')+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc392_d':
   fields=actual.split()
   if len(fields)!=1 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',fields[0]) is None:return False
   with localcontext() as context:
    context.prec=90;value=Decimal(fields[0])
    if not value.is_finite() or value.adjusted()>100:return False
    rational=dice_inverted_exact(cast(tuple[tuple[int,...],...],d[0]));tol=Fraction(1,100000000)
    if value.adjusted()<-100:
     # Truth denominator <=2.5e9; its nonzero distance to tol is >=4e-18.
     if rational<tol:return True
     if rational>tol:return False
     return value>=0
    error=abs(Fraction(value)-rational);return error<=tol or error<=abs(rational)*tol
  if pid in ('abc389_d','abc390_d','abc393_d') and re.fullmatch(r'(?:0|[1-9][0-9]*)\n?',actual) is None:return False
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError,DecimalException):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={
'abc389_d':'''r=int(input());limit=4*r*r;y=r-1;positive=0
for x in range(1,r):
 while y>0 and (2*x+1)**2+(2*y+1)**2>limit:y-=1
 positive+=y
print(4*positive+4*(r-1)+1)
''',
'abc390_d':'''n=int(input());a=list(map(int,input().split()));groups=[];outcomes=set()
def dfs(i,value):
 if i==n:outcomes.add(value);return
 stone=a[i]
 for j in range(len(groups)):
  old=groups[j];new=old+stone;groups[j]=new;dfs(i+1,value^old^new);groups[j]=old
 groups.append(stone);dfs(i+1,value^stone);groups.pop()
dfs(0,0);print(len(outcomes))
''',
'abc391_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);w=next(it);columns=[[] for _ in range(w)]
for i in range(n):x=next(it)-1;y=next(it);columns[x].append((y,i))
for col in columns:col.sort()
count=min(map(len,columns));death=[10**18]*n
for rank in range(count):
 time=max(col[rank][0] for col in columns)
 for col in columns:death[col[rank][1]]=time
q=next(it);out=[]
for _ in range(q):t=next(it);a=next(it)-1;out.append('Yes' if t<death[a] else 'No')
print('\\n'.join(out))
''',
'abc392_d':'''from collections import Counter
n=int(input());dice=[];lengths=[]
for _ in range(n):row=list(map(int,input().split()));lengths.append(row[0]);dice.append(Counter(row[1:]))
answer=0.0
for i in range(n):
 for j in range(i+1,n):
  a,b=dice[i],dice[j]
  if len(a)>len(b):a,b=b,a
  numerator=sum(count*b.get(value,0) for value,count in a.items());answer=max(answer,numerator/(lengths[i]*lengths[j]))
print(f'{answer:.15f}')
''',
'abc393_d':'''n=int(input());s=input();positions=[i for i,c in enumerate(s) if c=='1'];adjusted=[value-i for i,value in enumerate(positions)];median=adjusted[len(adjusted)//2]
print(sum(abs(value-median) for value in adjusted))
''',
'abc394_d':'''s=input();stack=[];match={')':'(',']':'[','>':'<'};valid=True
for c in s:
 if c in '([<':stack.append(c)
 elif not stack or stack.pop()!=match[c]:valid=False;break
print('Yes' if valid and not stack else 'No')
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(200000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc389_d':raws=[line((v,)) for v in (1,2,3,4,5,10,26,100,999,1000,10000,100000,123456,499999,500000,999998,999999,1000000)]
 elif pid=='abc390_d':
  arrays=[(1,1),(1,2),(1,1,1),(2,5,7),(10**17,10**17),tuple(1<<i for i in range(12))]
  arrays += [tuple(rng.randrange(1,10**17+1) for _ in range(n)) for n in range(2,12)]
  arrays += [tuple(10**17-rng.randrange(1,10**12) for _ in range(12)),(10**17,)*12];raws=[line((len(a),))+line(a) for a in arrays]
 elif pid=='abc391_d':
  configs=[(1,((1,1),),((1,1),)),(1,((1,2),),((1,1),(2,1))),(2,((1,1),(1,2)),((10**9,1),(10**9,2))),(2,((1,1),(2,2)),((1,1),(2,1),(2,2)))]
  for n in range(3,15):
   w=rng.randrange(1,n+1);points=tuple(rng.sample([(x,y) for x in range(1,w+1) for y in range(1,30)],n));queries=tuple((rng.randrange(1,31),rng.randrange(1,n+1)) for _ in range(n));configs.append((w,points,queries))
  configs += [(1,tuple((1,10**9-199999+i) for i in range(200000)),tuple((10**9-199999+i,i+1) for i in range(200000))),(200000,tuple((i+1,10**9) for i in range(200000)),tuple((10**9 if i%2 else 10**9-1,i+1) for i in range(200000)))];raws=[line((len(p),w))+''.join(line(v) for v in p)+line((len(q),))+''.join(line(v) for v in q) for w,p,q in configs]
 elif pid=='abc392_d':
  configs=[((1,),(1,)),((1,),(2,)),((100000,),(100000,)),((1,1,2),(1,2,2)),((1,2,3),(1,2,2,1),(1,2,3,4,5,6)),((1,)*49999,(2,)*50001)]
  for n in range(2,12):configs.append(tuple(tuple(rng.randrange(1,100001) for _ in range(i+1)) for i in range(n)))
  configs += [tuple(tuple(range(1,1001)) for _ in range(100)),tuple((100000,)*1000 for _ in range(100))];raws=[line((len(dice),))+''.join(line((len(die),)+die) for die in dice) for dice in configs]
 elif pid=='abc393_d':
  values=['10','01','11','101','10101','100001']
  for n in range(3,12):s='1'+''.join(rng.choice('01') for _ in range(n-1));values.append(s)
  values.append('1'*500000)
  values += ['10'*250000,'1'*125000+'0'*250000+'1'*125000];raws=[line((len(s),))+s+'\n' for s in values]
 else:
  values=['(',')','[',']','<','>','()','[]','<>','([<>])','([)]','())']
  values += [''.join(rng.choice('()[]<>') for _ in range(n)) for n in (9,17,100,1000)]
  values += ['([])<>'*33333+'()','('*100000+')'*100000];raws=[s+'\n' for s in values]
 require(len(raws)==len(set(raws))==18,'18 distinct');result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result

HINTS:dict[str,tuple[str,str,str]]={
'abc389_d':('原点から一番遠い角が円内にあれば、正方形全体が円内です。','座標を2倍すると条件は (2x+1)^2+(2y+1)^2<=4R^2 です。正の第一象限を走査し、yの上限を単調に減らします。','疑似コード: y=R-1,count=0; x=1..R-1で条件違反の間y--; count+=y; 対称な4象限、軸上4*(R-1)、原点1を合わせて4*count+4*(R-1)+1を出力。'),
'abc390_d':('袋を移し替えた結果は、元の袋をいくつかのグループへ分けた状態と考えられます。','石を順に既存グループへ加えるか、新しいグループを作るかを試します。各分割のグループ合計のXORを集合へ記録します。','疑似コード: dfs(i,xor): 全石を処理したらsetへxor; 各既存groupで old=sum,new=old+A[i]; xor^old^newで再帰して戻す; A[i]の新groupを追加してxor^A[i]で再帰; set.sizeを出力。'),
'abc391_d':('各列の下から同じ順位にあるブロックは、同じタイミングで消えます。','全列に存在する順位だけを処理します。その順位の初期高さの最大値が消滅時刻です。質問の時刻と等しい場合は既に消えています。','疑似コード: 列ごとに(Y,id)をsort; count=各列サイズの最小; 各rank<countでdeathTime=max_column Y[rank]; そのrankの全idへ時刻を設定; 他はINF; 各(T,id)でT<death[id]ならYes、他No。'),
'abc392_d':('同じ出目の面の個数をサイコロごとに数えます。','サイコロi,jの一致確率は、各値の面数の積を足してからK[i]*K[j]で割ったものです。全組を比較します。','疑似コード: 各dieをfrequencyへ; 全i<jで小さいfrequency側の(value,count)を走査し numerator+=count*other.get(value,0); probability=numerator/(K[i]*K[j]); 最大probabilityを出力。'),
'abc393_d':('1の出現位置をp[0],p[1],...とすると、連続する1の目標位置はbase+iです。','p[i]-iを作り、それらの中央値をbaseに選ぶと絶対値差の和が最小になります。1同士の順序は変える必要がありません。','疑似コード: adjusted=[p[i]-i]; median=adjusted[len//2]; answer=sum(abs(value-median)); answerを出力。'),
'abc394_d':('開き括弧と閉じ括弧は、内側から順番に対応しなければなりません。','開き括弧をスタックへ積み、閉じ括弧なら直前の開き括弧が同じ種類か確かめます。最後に余りがないことも必要です。','疑似コード: stack空; 開き括弧ならpush; 閉じ括弧ならstack空またはpopが対応する開き括弧でない場合No; 最後にstack空ならYes、他No。')}

TITLES={'abc389_d': 'Squares in Circle', 'abc390_d': 'Stone XOR', 'abc391_d': 'Gravity', 'abc392_d': 'Doubles', 'abc393_d': 'Swap to Gather', 'abc394_d': 'Colorful Bracket Sequence'}
PUBLISHED_SAMPLES={'abc389_d': [{'input': '2\n', 'expected': '5\n'}, {'input': '4\n', 'expected': '37\n'}, {'input': '26\n', 'expected': '2025\n'}], 'abc390_d': [{'input': '3\n2 5 7\n', 'expected': '3\n'}, {'input': '2\n100000000000000000 100000000000000000\n', 'expected': '2\n'}, {'input': '6\n71 74 45 34 31 60\n', 'expected': '84\n'}], 'abc391_d': [{'input': '5 3\n1 1\n1 2\n2 2\n3 2\n2 3\n6\n1 1\n1 2\n2 3\n2 5\n3 4\n3 5\n', 'expected': 'Yes\nYes\nNo\nYes\nNo\nYes\n'}, {'input': '3 2\n1 1\n2 1\n1 2\n4\n1 1\n1 2\n1 3\n2 3\n', 'expected': 'No\nNo\nYes\nYes\n'}], 'abc392_d': [{'input': '3\n3 1 2 3\n4 1 2 2 1\n6 1 2 3 4 5 6\n', 'expected': '0.333333333333333\n'}, {'input': '3\n5 1 1 1 1 1\n4 2 2 2 2\n3 1 1 2\n', 'expected': '0.666666666666667\n'}], 'abc393_d': [{'input': '7\n0101001\n', 'expected': '3\n'}, {'input': '3\n100\n', 'expected': '0\n'}, {'input': '10\n0101001001\n', 'expected': '7\n'}], 'abc394_d': [{'input': '([])<>()\n', 'expected': 'Yes\n'}, {'input': '([<)]>\n', 'expected': 'No\n'}, {'input': '())\n', 'expected': 'No\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
