"""Reviewed C tasks with full-stock matching DP and recipe count feasibility."""
from __future__ import annotations
from itertools import accumulate
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(334,340))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[str,str],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==334:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],k);require(1<=k<=n<=200000 and all(1<=v<=n for v in a) and all(x<y for x,y in zip(a,a[1:])),'missing socks');return n,a
    if number==335:
        n,q=ints(rows[0],2);require(2<=n<=10**6 and 1<=q<=200000 and len(rows)==q+1,'shape');queries=[]
        for row in rows[1:]:
            parts=row.split(' ');require(len(parts)==2 and parts[0] in ('1','2'),'query');kind,value=parts
            if kind=='1':require(value in 'RLUD' and len(value)==1,'direction')
            else:p=ints(value,1)[0];require(1<=p<=n,'part')
            queries.append((kind,value))
        return n,tuple(queries)
    if number==336:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**12,'rank');return (n,)
    if number==337:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=300000,'length');a=ints(rows[1],n);require(all(v==-1 or 1<=v<=n for v in a) and a.count(-1)==1 and len(set(a))==n,'predecessors');nextperson={v:j for j,v in enumerate(a,1)};person=nextperson[-1];seen=set()
        while person not in seen:seen.add(person);person=nextperson.get(person,0)
        require(person==0 and len(seen)==n+1,'single chain');return (a,)
    if number==338:
        require(len(rows)==4,'shape');n=ints(rows[0],1)[0];require(1<=n<=10,'length');q,a,b=(ints(row,n) for row in rows[1:]);require(all(1<=v<=10**6 for v in q) and all(0<=v<=10**6 for seq in (a,b) for v in seq) and any(a) and any(b),'recipes');return q,a,b
    require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000,'length');a=ints(rows[1],n);require(all(-10**9<=v<=10**9 for v in a),'passengers');return (a,)
def recipes_feasible(total:int,q:tuple[int,...],a:tuple[int,...],b:tuple[int,...])->bool:
    low=0;high=total
    for stock,x,y in zip(q,a,b):
        if x==y:
            if y*total>stock:return False
        elif x>y:high=min(high,(stock-y*total)//(x-y))
        else:low=max(low,-((stock-y*total)//(y-x)))
    return low<=high
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==334:
        n,a=cast(tuple[int,tuple[int,...]],data);lost=set(a);stock=[color for color in range(1,n+1) for _ in range(1 if color in lost else 2)];infinity=10**18;dp=[[infinity,infinity] for _ in range(len(stock)+1)];dp[0][0]=0
        for j in range(1,len(stock)+1):
            dp[j][1]=dp[j-1][0]
            if j>=2:
                for skipped in (0,1):dp[j][skipped]=min(dp[j][skipped],dp[j-2][skipped]+stock[j-1]-stock[j-2])
        return str(dp[-1][len(stock)%2])
    if number==335:
        _,queries=cast(tuple[int,Queries],data);head=[(1,0)];requests=[];x=1;y=0
        for kind,value in queries:
            if kind=='1':x+=(value=='R')-(value=='L');y+=(value=='U')-(value=='D');head.append((x,y))
            else:requests.append((len(head)-1,int(value)))
        return '\n'.join(f'{head[t-p+1][0]} {head[t-p+1][1]}' if p<=t+1 else f'{p-t} 0' for t,p in requests)
    if number==336:
        rank=cast(int,data[0]);
        if rank==1:return '0'
        rank-=2;length=1
        while rank>=4*5**(length-1):rank-=4*5**(length-1);length+=1
        value='';digits='2468';block=5**(length-1);first,rank=divmod(rank,block);value+=digits[first]
        for remaining in range(length-2,-1,-1):digit,rank=divmod(rank,5**remaining);value+='02468'[digit]
        return value
    if number==337:
        a=cast(tuple[int,...],data[0]);depth=[-1]*len(a)
        for j in range(len(a)):
            if depth[j]>=0:continue
            path=[];person=j
            while person!=-1 and depth[person]<0:path.append(person);person=a[person]-1 if a[person]!=-1 else -1
            distance=0 if person==-1 else depth[person]+1
            for person in reversed(path):depth[person]=distance;distance+=1
        return ' '.join(str(j+1) for j in sorted(range(len(a)),key=depth.__getitem__))
    if number==338:
        q,a,b=cast(tuple[tuple[int,...],tuple[int,...],tuple[int,...]],data);low=0;high=min(stock//v for stock,v in zip(q,a) if v)+min(stock//v for stock,v in zip(q,b) if v)+1
        while high-low>1:
            middle=(low+high)//2
            if recipes_feasible(middle,q,a,b):low=middle
            else:high=middle
        return str(low)
    a=cast(tuple[int,...],data[0]);current=0
    for delta in a:current=max(0,current+delta)
    return str(current)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc334_c':"n,k=map(int,input().split());a=list(map(int,input().split()))\nif k%2==0:print(sum(a[j+1]-a[j] for j in range(0,k,2)))\nelse:\n left=[0]*(k+1);right=[0]*(k+1)\n for j in range(2,k+1,2):left[j]=left[j-2]+a[j-1]-a[j-2]\n for j in range(k-2,-1,-2):right[j]=right[j+2]+a[j+1]-a[j]\n print(min(left[j]+right[j+1] for j in range(0,k,2)))\n",
'abc335_c':"n,q=map(int,input().split());dragon=[(j,0) for j in range(1,n+1)];head=0\nfor _ in range(q):\n kind,value=input().split()\n if kind=='1':\n  x,y=dragon[head];x+=(value=='R')-(value=='L');y+=(value=='U')-(value=='D');head=(head-1)%n;dragon[head]=(x,y)\n else:print(*dragon[(head+int(value)-1)%n])\n",
'abc336_c':"n=int(input())-1;out=''\nwhile n:out=str(2*(n%5))+out;n//=5\nprint(out or '0')\n",
'abc337_c':"n=int(input());a=list(map(int,input().split()));following={}\nfor j,v in enumerate(a,1):following[v]=j\nperson=following[-1];out=[]\nwhile person:out.append(person);person=following.get(person,0)\nprint(*out)\n",
'abc338_c':"n=int(input());q=list(map(int,input().split()));a=list(map(int,input().split()));b=list(map(int,input().split()));answer=0;limit=min(stock//v for stock,v in zip(q,a) if v)\nfor x in range(limit+1):\n y=min((stock-v*x)//w for stock,v,w in zip(q,a,b) if w);answer=max(answer,x+y)\nprint(answer)\n",
'abc339_c':"from itertools import accumulate\nn=int(input());a=list(map(int,input().split()));prefix=list(accumulate(a,initial=0));print(prefix[-1]-min(prefix))\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17100+number)
    if number==334:
        def socks(n:int,a:list[int])->str:return f'{n} {len(a)}\n'+line(a)
        raws=[socks(1,[1]),socks(2,[1,2]),socks(3,[1,3]),socks(4,[1,2,4])];raws.extend(socks(n,sorted(rng.sample(range(1,n+1),rng.randint(1,n)))) for n in range(5,17));raws.extend([socks(200000,list(range(1,200000))),socks(200000,list(range(1,200001)))])
    elif number==335:
        def queries(n:int,qs:list[tuple[str,str]])->str:return f'{n} {len(qs)}\n'+''.join(f'{a} {b}\n' for a,b in qs)
        raws=[queries(2,[('1','R')]),queries(2,[('2','1')]),queries(2,[('2','2')]),queries(3,[('1','L'),('2','2'),('2','3')])]
        for n in range(3,15):raws.append(queries(n,[('1',rng.choice('RLUD')) if rng.randrange(2) else ('2',str(rng.randint(1,n))) for _ in range(n+2)]))
        raws.extend([queries(10**6,[('1','U')]*199999+[('2','200000')]),queries(10**6,[('2',str(j+1)) for j in range(200000)])])
    elif number==336:raws=[f'{n}\n' for n in (1,2,5,6,7,25,26,125,126,625,626,3125,3126,10**6,10**9,10**10,10**12-1,10**12)]
    elif number==337:
        def chain(order:list[int])->str:
            a=[0]*len(order);previous=-1
            for v in order:a[v-1]=previous;previous=v
            return f'{len(a)}\n'+line(a)
        raws=[chain([1]),chain([1,2]),chain([2,1]),chain([2,3,1])]
        for n in range(4,16):order=list(range(1,n+1));rng.shuffle(order);raws.append(chain(order))
        raws.extend([chain(list(range(1,300001))),chain(list(range(300000,0,-1)))])
    elif number==338:
        def recipe(q:list[int],a:list[int],b:list[int])->str:return f'{len(q)}\n'+line(q)+line(a)+line(b)
        raws=[recipe([1],[1],[1]),recipe([1],[2],[2]),recipe([3,4],[1,0],[0,1]),recipe([10],[2],[3])]
        for n in range(1,13):size=min(n,10);q=[rng.randint(1,100) for _ in range(size)];a=[rng.randint(0,20) for _ in range(size)];b=[rng.randint(0,20) for _ in range(size)];a[0]=max(1,a[0]);b[-1]=max(1,b[-1]);raws.append(recipe(q,a,b))
        raws.extend([recipe([10**6]*10,[1]+[0]*9,[0,1]+[0]*8),recipe([10**6]*10,[10**6]*10,[10**6]*10)])
    else:
        def bus(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[bus(a) for a in ([0],[-1],[1],[1,-2,1])];raws.extend(bus([rng.randint(-100,100) for _ in range(n)]) for n in range(3,15));raws.extend([bus([-10**9]*100000+[10**9]*100000),bus([10**9]*200000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc334_c':('同じ色で2枚残る靴下は奇妙さ0で組にできます。','1枚だけ残る色を昇順に隣接ペアへ。奇数なら1枚を余らせる位置をprefix/suffixで試します。','疑似コード: Kが偶数なら隣接差を合計; 奇数なら左偶数枚のpair費用prefixと右偶数枚の費用suffixを作り、偶数位置の余りを全て試して最小を出力。'),
'abc335_c':('各移動で頭の直前位置へ新しい座標を置き、他のパーツを順に追従させます。', '固定長の循環配列と頭の添字で、移動も位置照会も定数時間にできます。', '疑似コード: dragon=[(1,0),...,(N,0)], head=0; 移動で新しい頭座標を求めhead=(head-1)%Nへ書く; p番目はdragon[(head+p-1)%N]を出力。'),
'abc336_c':('0,2,4,6,8を0,1,2,3,4へ対応させます。','N-1を5進数にし、各桁を2倍すると欲しい整数になります。','疑似コード: x=N-1; xを5進法の桁列へ; 各桁dを2*dに置換して連結; x=0なら0を出力。'),
'abc337_c':('各人の次に並ぶ人を逆引きします。','A[i]=-1の人から始め、現在の人を前に持つ人を順に追います。','疑似コード: 各iでfollowing[A[i]]=i; v=following[-1]; vを出力列へ追加しv=following[v]を、次がなくなるまで繰り返す。'),
'abc338_c':('料理Aの人数を決めると、残りで作れるBの最大人数が分かります。','Aの人数を0から材料が足りる上限まで列挙し、Bの人数を全材料の制限の最小として求めます。','疑似コード: limit=min(Q[i]/A[i], A[i]>0); x=0..limitでy=min((Q[i]-A[i]*x)/B[i], B[i]>0); x+yの最大を出力。'),
'abc339_c':('初期人数は、途中で乗客数が負にならない最低限だけ必要です。','初期0人とした累積和の最小値を調べ、その分だけ全時点の人数を増やします。','疑似コード: prefix=0とAの累積和; 初期人数=-min(prefix); 現在人数=prefix[-1]-min(prefix)を出力。')}

TITLES={'abc334_c': 'Socks 2', 'abc335_c': 'Loong Tracking', 'abc336_c': 'Even Digits', 'abc337_c': 'Lining Up 2', 'abc338_c': 'Leftover Recipes', 'abc339_c': 'Perfect Bus'}
PUBLISHED_SAMPLES={'abc334_c': [{'input': '4 2\n1 3\n', 'expected': '2\n'}, {'input': '5 1\n2\n', 'expected': '0\n'}, {'input': '8 5\n1 2 4 7 8\n', 'expected': '2\n'}], 'abc335_c': [{'input': '5 9\n2 3\n1 U\n2 3\n1 R\n1 D\n2 3\n1 L\n2 1\n2 5\n', 'expected': '3 0\n2 0\n1 1\n1 0\n1 0\n'}], 'abc336_c': [{'input': '8\n', 'expected': '24\n'}, {'input': '133\n', 'expected': '2024\n'}, {'input': '31415926535\n', 'expected': '2006628868244228\n'}], 'abc337_c': [{'input': '6\n4 1 -1 5 3 2\n', 'expected': '3 5 4 1 2 6\n'}, {'input': '10\n-1 1 2 3 4 5 6 7 8 9\n', 'expected': '1 2 3 4 5 6 7 8 9 10\n'}, {'input': '30\n3 25 20 6 18 12 26 1 29 -1 21 17 23 9 8 30 10 15 22 27 4 13 5 11 16 24 28 2 19 7\n', 'expected': '10 17 12 6 4 21 11 24 26 7 30 16 25 2 28 27 20 3 1 8 15 18 5 23 13 22 19 29 9 14\n'}], 'abc338_c': [{'input': '2\n800 300\n100 100\n200 10\n', 'expected': '5\n'}, {'input': '2\n800 300\n100 0\n0 10\n', 'expected': '38\n'}, {'input': '2\n800 300\n801 300\n800 301\n', 'expected': '0\n'}, {'input': '10\n1000000 1000000 1000000 1000000 1000000 1000000 1000000 1000000 1000000 1000000\n0 1 2 3 4 5 6 7 8 9\n9 8 7 6 5 4 3 2 1 0\n', 'expected': '222222\n'}], 'abc339_c': [{'input': '4\n3 -5 7 -4\n', 'expected': '3\n'}, {'input': '5\n0 0 0 0 0\n', 'expected': '0\n'}, {'input': '4\n-1 1000000000 1000000000 1000000000\n', 'expected': '3000000000\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
