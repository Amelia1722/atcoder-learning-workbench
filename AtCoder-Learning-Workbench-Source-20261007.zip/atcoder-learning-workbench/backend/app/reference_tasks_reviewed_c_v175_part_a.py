"""Reviewed C tasks with pattern segment trees, offline rotations and interval BFS."""
from __future__ import annotations
from collections import Counter,defaultdict,deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (372,408,409,410,411,412))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[int,...],...]
Updates=tuple[tuple[int,str],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==372:
        n,q=ints(rows[0],2);require(3<=n<=200000 and 1<=q<=200000 and len(rows)==q+2 and len(rows[1])==n and re.fullmatch('[A-Z]+',rows[1]) is not None,'shape');queries=[]
        for row in rows[2:]:parts=row.split(' ');require(len(parts)==2 and re.fullmatch('[A-Z]',parts[1]) is not None,'letter');p=ints(parts[0],1)[0];require(1<=p<=n,'position');queries.append((p,parts[1]))
        return rows[1],tuple(queries)
    if number==408:
        n,m=ints(rows[0],2);require(1<=n<=10**6 and 1<=m<=200000 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=l<=r<=n for l,r in a),'ranges');return n,a
    if number==409:
        require(len(rows)==2,'shape');n,l=ints(rows[0],2);a=ints(rows[1],n-1);require(3<=n<=300000 and 3<=l<=300000 and all(0<=v<l for v in a),'distances');return l,a
    if number==410:
        n,q=ints(rows[0],2);require(1<=n<=10**6 and 1<=q<=300000 and len(rows)==q+1,'shape');queries=[]
        for row in rows[1:]:
            a=ints(row);kind=a[0];require(kind in (1,2,3) and len(a)==(3 if kind==1 else 2),'query')
            if kind in (1,2):require(1<=a[1]<=n and (kind==2 or 1<=a[2]<=10**6),'update')
            else:require(1<=a[1]<=10**9,'rotation')
            queries.append(a)
        return n,tuple(queries)
    if number==411:
        require(len(rows)==2,'shape');n,q=ints(rows[0],2);a=ints(rows[1],q);require(1<=n<=500000 and 1<=q<=500000 and all(1<=v<=n for v in a),'toggles');return (a,)
    t=ints(rows[0],1)[0];require(1<=t<=100000 and len(rows)==1+2*t,'cases');cases=[];total=0
    for j in range(t):n=ints(rows[1+2*j],1)[0];a=ints(rows[2+2*j],n);require(2<=n<=200000 and all(1<=v<=10**9 for v in a),'dominoes');total+=n;cases.append(a)
    require(total<=200000,'total');return (tuple(cases),)
Node=tuple[int,str,str,int]
def merge(left:Node,right:Node)->Node:
    count,pre,suf,length=left;other,prefix,suffix,size=right;cross=(suf+prefix).count('ABC');return count+other+cross,(pre+prefix)[:2] if length<2 else pre,(suf+suffix)[-2:] if size<2 else suffix,length+size
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==372:
        s,qs=cast(tuple[str,Updates],data);size=1
        while size<len(s):size*=2
        tree: list[Node]=[(0,'','',0)]*(2*size)
        for j,ch in enumerate(s):tree[size+j]=(0,ch,ch,1)
        for j in range(size-1,0,-1):tree[j]=merge(tree[2*j],tree[2*j+1])
        out=[]
        for p,ch in qs:
            j=size+p-1;tree[j]=(0,ch,ch,1);j//=2
            while j:tree[j]=merge(tree[2*j],tree[2*j+1]);j//=2
            out.append(str(tree[1][0]))
        return '\n'.join(out)
    if number==408:
        n,a=cast(tuple[int,tuple[tuple[int,int],...]],data);events:dict[int,int]=defaultdict(int);events[1]+=0;events[n+1]+=0
        for l,r in a:events[l]+=1;events[r+1]-=1
        current=0;answer=len(a)
        for position in sorted(events):
            current+=events[position]
            if position<=n:answer=min(answer,current)
        return str(answer)
    if number==409:
        l,a=cast(tuple[int,tuple[int,...]],data)
        if l%3:return '0'
        positions=Counter({0:1});p=0
        for v in a:p=(p+v)%l;positions[p]+=1
        step=l//3;answer=sum(count*positions[(p+step)%l]*positions[(p+2*step)%l] for p,count in positions.items());return str(answer//3)
    if number==410:
        n,qs=cast(tuple[int,Queries],data);events:dict[int,list[tuple[int,int,int]]]=defaultdict(list);rotation=0;answers={}
        for t,a in enumerate(qs):
            if a[0]==3:rotation=(rotation+a[1])%n
            else:p=(a[1]-1+rotation)%n;events[p].append((t,a[0],a[2] if a[0]==1 else 0))
        for p,seq in events.items():
            value=p+1
            for t,kind,v in seq:
                if kind==1:value=v
                else:answers[t]=str(value)
        return '\n'.join(answers[t] for t in sorted(answers))
    if number==411:
        a=cast(tuple[int,...],data[0]);boundaries=set();out=[]
        for p in a:
            for edge in (p-1,p):
                if edge in boundaries:boundaries.remove(edge)
                else:boundaries.add(edge)
            out.append(str(len(boundaries)//2))
        return '\n'.join(out)
    cases=cast(tuple[tuple[int,...],...],data[0]);out=[]
    for a in cases:
        middle=sorted(a[1:-1]);pending=deque([(a[0],1)]);p=0;answer=-1
        while pending:
            value,count=pending.popleft()
            if a[-1]<=2*value:answer=count+1;break
            while p<len(middle) and middle[p]<=2*value:pending.append((middle[p],count+1));p+=1
        out.append(str(answer))
    return '\n'.join(out)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc372_c':"n,q=map(int,input().split());s=list(input());count=''.join(s).count('ABC')\nfor _ in range(q):\n p,ch=input().split();p=int(p)-1;starts=range(max(0,p-2),min(p+1,n-2))\n for j in starts:count-=s[j:j+3]==list('ABC')\n s[p]=ch\n for j in starts:count+=s[j:j+3]==list('ABC')\n print(count)\n",
'abc408_c':"n,m=map(int,input().split());diff=[0]*(n+1)\nfor _ in range(m):l,r=map(int,input().split());diff[l-1]+=1;diff[r]-=1\ncurrent=0;answer=m\nfor v in diff[:n]:current+=v;answer=min(answer,current)\nprint(answer)\n",
'abc409_c':"n,l=map(int,input().split());a=list(map(int,input().split()));counts=[0]*l;counts[0]=1;p=0\nfor v in a:p=(p+v)%l;counts[p]+=1\nprint(0 if l%3 else sum(counts[p]*counts[p+l//3]*counts[p+2*l//3] for p in range(l//3)))\n",
'abc410_c':"n,q=map(int,input().split());a=list(range(1,n+1));head=0\nfor _ in range(q):\n parts=list(map(int,input().split()))\n if parts[0]==1:a[(head+parts[1]-1)%n]=parts[2]\n elif parts[0]==2:print(a[(head+parts[1]-1)%n])\n else:head=(head+parts[1])%n\n",
'abc411_c':"n,q=map(int,input().split());a=list(map(int,input().split()));black=[False]*(n+2);answer=0\nfor p in a:\n neighbors=black[p-1]+black[p+1];answer+=(neighbors-1) if black[p] else (1-neighbors);black[p]=not black[p];print(answer)\n",
'abc412_c':"from bisect import bisect_right\nt=int(input())\nfor _ in range(t):\n n=int(input());a=list(map(int,input().split()));middle=sorted(a[1:-1]);value=a[0];count=2\n while 2*value<a[-1]:\n  p=bisect_right(middle,2*value)-1\n  if p<0 or middle[p]<=value:count=-1;break\n  value=middle[p];count+=1\n print(count)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17500+number)
    if number==372:
        def patterns(s:str,qs:list[tuple[int,str]])->str:return f'{len(s)} {len(qs)}\n{s}\n'+''.join(f'{p} {ch}\n' for p,ch in qs)
        raws=[patterns(s,qs) for s,qs in (('AAA',[(1,'A')]),('ABC',[(2,'B')]),('ABC',[(1,'Z')]),('ABA',[(3,'C'),(1,'Z')]))];raws.extend(patterns(''.join(rng.choice('ABCZ') for _ in range(n)),[(rng.randint(1,n),rng.choice('ABCZ')) for _ in range(n+2)]) for n in range(4,16));raws.extend([patterns('ABC'*66666+'AB',[(3*j+3,'Z' if j%2 else 'C') for j in range(66666)]*3+[(1,'A'),(2,'B')]),patterns('Z'*200000,[(200000,'Z')]*200000)])
    elif number==408:
        def walls(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{l} {r}\n' for l,r in a)
        raws=[walls(n,a) for n,a in ((1,[(1,1)]),(2,[(1,1)]),(2,[(1,2),(1,2)]),(3,[(1,2),(2,3)]))];raws.extend(walls(n,[tuple(sorted((rng.randint(1,n),rng.randint(1,n)))) for _ in range(n)]) for n in range(3,15));raws.extend([walls(10**6,[(j+1,10**6-j) for j in range(200000)]),walls(10**6,[(1,10**6)]*200000)])
    elif number==409:
        def circle(l:int,a:list[int])->str:return f'{len(a)+1} {l}\n'+line(a)
        raws=[circle(l,a) for l,a in ((3,[0,0]),(3,[1,1]),(4,[1,1]),(6,[2,2,0]))];raws.extend(circle(n,[rng.randrange(n) for _ in range(n-1)]) for n in range(5,17));raws.extend([circle(300000,[100000]*299999),circle(300000,[299999]*299999)])
    elif number==410:
        def rotation(n:int,qs:list[str])->str:return f'{n} {len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[rotation(n,qs) for n,qs in ((1,['1 1 1']),(1,['2 1']),(1,['3 1']),(3,['1 2 9','3 1','2 1','2 3']))]
        for n in range(2,14):qs=[f'1 {rng.randint(1,n)} {rng.randint(1,100)}' if k==1 else f'2 {rng.randint(1,n)}' if k==2 else f'3 {rng.randint(1,100)}' for k in [rng.randint(1,3) for _ in range(n+5)]];raws.append(rotation(n,qs))
        raws.extend([rotation(10**6,['3 999999999','1 1 1000000','2 1']*100000),rotation(10**6,['2 1000000']*300000)])
    elif number==411:
        def toggles(n:int,a:list[int])->str:return f'{n} {len(a)}\n'+line(a)
        raws=[toggles(n,a) for n,a in ((1,[1]),(1,[1,1]),(2,[1,2]),(3,[1,3,2,2]))];raws.extend(toggles(n,[rng.randint(1,n) for _ in range(n+5)]) for n in range(3,15));raws.extend([toggles(500000,list(range(1,500001,2))*2),toggles(500000,[500000]*500000)])
    else:
        def domino(cases:list[list[int]])->str:return f'{len(cases)}\n'+''.join(f'{len(a)}\n'+line(a) for a in cases)
        raws=[domino(cases) for cases in ([[1,1]],[[1,3]],[[1,2,4]],[[1,2,4],[3,1],[1,3,9]])];raws.extend(domino([[rng.randint(1,100) for _ in range(n)]]) for n in range(3,15));raws.extend([domino([[1]+[min(10**9,2**min(j,30)) for j in range(1,199999)]+[10**9]]),domino([[10**9,10**9]]*100000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc372_c':('1文字を変えて影響するABCは、その位置を含む3つの開始位置だけです。','変更前の該当箇所を総数から引き、変更後に再判定して足します。','疑似コード: count=ABC総数; p変更ごとにj=p-2..pの盤内開始位置のABCを引く; S[p]=C; 同じjのABCを足しcount出力。'),
'abc408_c':('城壁1つを無防備にするには、その城壁を守る砲台をすべて壊します。','区間加算の差分配列で各城壁を守る数を求め、最小を出します。','疑似コード: diff[L]++,diff[R+1]--; 城壁順に累積和currentを作りmin(current)を出力。'),
'abc409_c':('正三角形の頂点は円周を3等分します。','Lが3で割れなければ0です。各位置の点数を数え、x,x+L/3,x+2L/3の積を足します。','疑似コード: 累積距離mod Lの頻度countを作る; L%3なら0; 他はx=0..L/3-1でcount[x]*count[x+L/3]*count[x+2L/3]を合計。'),
'abc410_c':('回転のたびに配列を動かす必要はありません。','先頭が元配列のどこかをoffsetで保持し、照会や変更の位置を変換します。','疑似コード: head=0; pの実添字は(head+p-1)%N; type1はその要素変更、type2は出力、type3はhead=(head+k)%N。'),
'abc411_c':('反転位置の左右の色だけが区間数に影響します。','白から黒なら1から黒い隣接数を引いて加算し、黒から白なら逆にします。','疑似コード: neighbors=black[p-1]+black[p+1]; 白ならanswer+=1-neighbors、黒ならanswer+=neighbors-1; black[p]反転; answer出力。'),
'abc412_c':('現在の2倍以下で倒せる中間ドミノのうち最大を選ぶと先へ最も進めます。','中間をsortし、2倍以下の最大を二分探索します。大きさが増えなければ到達できません。','疑似コード: value=S[1],count=2; 2*value<S[N]の間、中間の2*value以下最大vを探す; v<=valueなら-1; 他はvalue=v,count++; 終了でcount出力。')}

TITLES={'abc372_c': 'Count ABC Again', 'abc408_c': 'Not All Covered', 'abc409_c': 'Equilateral Triangle', 'abc410_c': 'Rotatable Array', 'abc411_c': 'Black Intervals', 'abc412_c': 'Giant Domino'}
PUBLISHED_SAMPLES={'abc372_c': [{'input': '7 4\nABCDABC\n4 B\n3 A\n5 C\n4 G\n', 'expected': '2\n1\n1\n0\n'}, {'input': '3 3\nABC\n1 A\n2 B\n3 C\n', 'expected': '1\n1\n1\n'}, {'input': '15 10\nBBCCBCACCBACACA\n9 C\n11 B\n5 B\n11 B\n4 A\n8 C\n8 B\n5 B\n7 B\n14 B\n', 'expected': '0\n0\n0\n0\n1\n1\n2\n2\n1\n1\n'}], 'abc408_c': [{'input': '10 4\n1 6\n4 5\n5 10\n7 10\n', 'expected': '1\n'}, {'input': '5 2\n1 2\n3 4\n', 'expected': '0\n'}, {'input': '5 10\n2 5\n1 5\n1 2\n2 4\n2 2\n5 5\n2 4\n1 2\n2 2\n2 3\n', 'expected': '3\n'}], 'abc409_c': [{'input': '5 6\n4 3 1 2\n', 'expected': '2\n'}, {'input': '4 4\n1 1 1\n', 'expected': '0\n'}, {'input': '10 12\n4 4 5 7 1 7 0 8 5\n', 'expected': '13\n'}], 'abc410_c': [{'input': '5 5\n2 3\n1 2 1000000\n3 4\n2 2\n2 3\n', 'expected': '3\n1\n1000000\n'}, {'input': '1000000 2\n1 1000000 999999\n3 1000000000\n', 'expected': '\n'}], 'abc411_c': [{'input': '5 7\n2 3 3 5 1 5 2\n', 'expected': '1\n1\n1\n2\n2\n1\n1\n'}, {'input': '1 2\n1 1\n', 'expected': '1\n0\n'}, {'input': '3 3\n1 3 2\n', 'expected': '1\n2\n1\n'}], 'abc412_c': [{'input': '3\n4\n1 3 2 5\n2\n1 100\n10\n298077099 766294630 440423914 59187620 725560241 585990757 965580536 623321126 550925214 917827435\n', 'expected': '4\n-1\n3\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
