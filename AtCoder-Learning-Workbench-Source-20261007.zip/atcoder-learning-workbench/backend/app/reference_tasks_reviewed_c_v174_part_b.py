"""Count envelopes, occurrence intervals, forest rank and odd square parts."""
from __future__ import annotations
from itertools import groupby,accumulate
from math import isqrt
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(396,402))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==396:
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(1<=n<=200000 and 1<=m<=200000,'size');b,w=ints(rows[1],n),ints(rows[2],m);require(all(-10**9<=v<=10**9 for seq in (b,w) for v in seq),'values');return b,w
    if number in (397,398):
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require((2 if number==397 else 1)<=n<=300000 and all(1<=v<=(n if number==397 else 10**9) for v in a),'values');return (a,)
    if number==399:
        n,m=ints(rows[0],2);require(1<=n<=200000 and 0<=m<=min(n*(n-1)//2,200000) and len(rows)==m+1,'shape');edges=tuple(ints(row,2) for row in rows[1:]);require(len(set(edges))==m and all(1<=a<b<=n for a,b in edges),'simple graph');return n,edges
    require(len(rows)==1,'shape')
    if number==400:n=ints(rows[0],1)[0];require(1<=n<=10**18,'bound');return (n,)
    n,k=ints(rows[0],2);require(1<=n<=10**6 and 1<=k<=10**6,'recurrence');return n,k

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==396:
        b,w=cast(tuple[tuple[int,...],tuple[int,...]],data);black=list(accumulate(sorted(b,reverse=True),initial=0));envelope=black[:]
        for j in range(len(b)-1,-1,-1):envelope[j]=max(envelope[j],envelope[j+1])
        white=list(accumulate(sorted(w,reverse=True),initial=0));return str(max(envelope[j]+white[j] for j in range(min(len(b),len(w))+1)))
    if number==397:
        a=cast(tuple[int,...],data[0]);first:dict[int,int]={};last:dict[int,int]={}
        for j,v in enumerate(a):first.setdefault(v,j);last[v]=j
        delta=[0]*(len(a)+1)
        for v,left in first.items():delta[left+1]+=1;delta[last[v]+1]-=1
        active=best=0
        for cut in range(1,len(a)):active+=delta[cut];best=max(best,active)
        return str(len(first)+best)
    if number==398:
        a=cast(tuple[int,...],data[0]);answer=-1
        for value,group in groupby(sorted((v,j) for j,v in enumerate(a,1)),key=lambda item:item[0]):
            positions=list(group)
            if len(positions)==1:answer=positions[0][1]
        return str(answer)
    if number==399:
        n,edges=cast(tuple[int,tuple[tuple[int,int],...]],data);adj=[[] for _ in range(n)]
        for a,b in edges:adj[a-1].append(b-1);adj[b-1].append(a-1)
        seen=[False]*n;components=0
        for root in range(n):
            if seen[root]:continue
            components+=1;seen[root]=True;stack=[root]
            while stack:
                for target in adj[stack.pop()]:
                    if not seen[target]:seen[target]=True;stack.append(target)
        return str(len(edges)-n+components)
    if number==400:
        n=cast(int,data[0]);power=2;answer=0
        while power<=n:answer+=(isqrt(n//power)+1)//2;power*=2
        return str(answer)
    n,k=cast(tuple[int,int],data);mod=10**9
    if n<k:return '1'
    values=[1]*k+[k%mod]
    for i in range(k+1,n+1):values.append((2*values[-1]-values[i-k-1])%mod)
    return str(values[n])

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc396_c':"n,m=map(int,input().split());b=sorted(map(int,input().split()),reverse=True);w=sorted(map(int,input().split()),reverse=True);white=[0]\nfor v in w:\n if v>0:white.append(white[-1]+v)\nanswer=0;black=0\nfor k,v in enumerate(b,1):black+=v;answer=max(answer,black+white[min(k,len(white)-1)])\nprint(answer)\n",
'abc397_c':"n=int(input());a=list(map(int,input().split()));left=[];seen=set()\nfor v in a:seen.add(v);left.append(len(seen))\nseen=set();answer=0\nfor j in range(n-1,0,-1):seen.add(a[j]);answer=max(answer,left[j-1]+len(seen))\nprint(answer)\n",
'abc398_c':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));count=Counter(a);best=-1;answer=-1\nfor j,v in enumerate(a,1):\n if count[v]==1 and v>best:best=v;answer=j\nprint(answer)\n",
'abc399_c':"n,m=map(int,input().split());parent=list(range(n));size=[1]*n;answer=0\ndef find(v):\n while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]\n return v\nfor _ in range(m):\n a,b=map(int,input().split());a=find(a-1);b=find(b-1)\n if a==b:answer+=1\n else:\n  if size[a]<size[b]:a,b=b,a\n  parent[b]=a;size[a]+=size[b]\nprint(answer)\n",
'abc400_c':"from math import isqrt\nn=int(input());print(isqrt(n//2)+isqrt(n//4))\n",
'abc401_c':"from collections import deque\nn,k=map(int,input().split());mod=10**9\nif n<k:print(1)\nelse:\n window=deque([1]*k);total=k;value=1\n for _ in range(k,n+1):value=total%mod;total=(total+value-window.popleft())%mod;window.append(value)\n print(value)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17400+number)
    if number==396:
        def balls(b:list[int],w:list[int])->str:return f'{len(b)} {len(w)}\n'+line(b)+line(w)
        raws=[balls(b,w) for b,w in (([-1],[-1]),([0],[0]),([-1],[2]),([2,-1],[3,1]))];raws.extend(balls([rng.randint(-20,20) for _ in range(n)],[rng.randint(-20,20) for _ in range(n+1)]) for n in range(3,15));raws.extend([balls([-10**9]*200000,[10**9]*200000),balls([10**9]*200000,[10**9]*200000)])
    elif number in (397,398):
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in (([1,1],[1,2],[1,2,1],[1,2,2,1]) if number==397 else ([1],[1,1],[1,2],[3,3,2,1]))];raws.extend(arr([rng.randint(1,n) for _ in range(n)]) for n in range(4,16));raws.extend([arr(list(range(1,300001))),arr([300000 if number==397 else 10**9]*300000)])
    elif number==399:
        def graph(n:int,edges:list[tuple[int,int]])->str:return f'{n} {len(edges)}\n'+''.join(f'{a} {b}\n' for a,b in edges)
        raws=[graph(n,e) for n,e in ((1,[]),(2,[]),(2,[(1,2)]),(3,[(1,2),(1,3),(2,3)]))]
        for n in range(4,16):edges=[(a,b) for a in range(1,n+1) for b in range(a+1,n+1)];raws.append(graph(n,rng.sample(edges,rng.randint(0,len(edges)))))
        raws.extend([graph(200000,[(j,j+1) for j in range(1,200000)]),graph(200000,[(1,j) for j in range(2,200001)]+[(2,3)])])
    elif number==400:raws=[f'{n}\n' for n in (1,2,3,4,7,8,17,18,19,20,399,400,401,10**9,10**12,10**15,10**18-1,10**18)]
    else:raws=[f'{n} {k}\n' for n,k in ((1,1),(1,2),(2,1),(2,2),(3,2),(4,2),(5,3),(7,4),(10,20),(30,1),(100,2),(100,99),(99,100),(1000,17),(10000,5000),(1000000,1),(1000000,500000),(1000000,1000000))]
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc396_c':('黒玉をk個選ぶなら、白玉は高々k個です。','価値の大きい黒玉から選び、白玉は正の価値の大きい順に高々k個足します。kをすべて試します。','疑似コード: B,W降順sort; 正のWのprefix和Pを作る; k=1..Nで上位k黒玉の和+P[min(k,正白玉数)]を計算; 0も含め最大値。'),
'abc397_c':('区切りの左右それぞれの種類数を知れば評価できます。','左側の種類数を前から保存し、右側を後ろから集合で数えます。','疑似コード: left[i]=A[0:i+1]の種類数; 右端からseenへ追加し、区切りiでleft[i-1]+len(seen)の最大を出力。'),
'abc398_c':('数の出現回数を先に数えます。','出現回数が1の候補だけから最大の値と元の位置を選びます。','疑似コード: count=Counter(A); 各iでcount[A[i]]=1なら最大値候補を更新; 候補の番号または-1を出力。'),
'abc399_c':('同じ連結成分の中へ辺を足すと閉路ができます。','Union-Findで端点がすでにつながっている辺を数えると、削除が必要な最小本数になります。','疑似コード: 各辺(u,v)でfind(u)=find(v)ならanswer++; 違えばunion; 最後にanswerを出力。'),
'abc400_c':('2の指数の偶奇で重複しない二種類に分けられます。','良い整数は2倍の平方数、または4倍の平方数として一意に分類できます。両者は重なりません。','疑似コード: answer=isqrt(N//2)+isqrt(N//4); 整数平方根で浮動小数点誤差を避けて出力。'),
'abc401_c':('直前K項の合計を毎回計算し直す必要はありません。','合計を窓として保持し、新しい項を足して最古の項を引きます。','疑似コード: N<Kなら1; queueにK個の1、sum=K; i=K..Nでvalue=sum%10^9; sum=(sum+value-queue.popleft())%10^9; queue.append(value); 最後のvalueを出力。')}

TITLES={'abc396_c': 'Buy Balls', 'abc397_c': 'Variety Split Easy', 'abc398_c': 'Uniqueness', 'abc399_c': 'Make it Forest', 'abc400_c': '2^a b^2', 'abc401_c': 'K-bonacci'}
PUBLISHED_SAMPLES={'abc396_c': [{'input': '4 3\n8 5 -1 3\n3 -2 -4\n', 'expected': '19\n'}, {'input': '4 3\n5 -10 -2 -5\n8 1 4\n', 'expected': '15\n'}, {'input': '3 5\n-36 -33 -31\n12 12 28 24 27\n', 'expected': '0\n'}], 'abc397_c': [{'input': '5\n3 1 4 1 5\n', 'expected': '5\n'}, {'input': '10\n2 5 6 5 2 1 7 9 7 2\n', 'expected': '8\n'}], 'abc398_c': [{'input': '9\n2 9 9 7 9 2 4 5 8\n', 'expected': '9\n'}, {'input': '4\n1000000000 1000000000 998244353 998244353\n', 'expected': '-1\n'}], 'abc399_c': [{'input': '4 4\n1 2\n1 3\n2 4\n3 4\n', 'expected': '1\n'}, {'input': '5 0\n', 'expected': '0\n'}, {'input': '10 10\n7 9\n4 6\n6 10\n2 5\n5 6\n5 9\n6 8\n4 8\n1 5\n1 4\n', 'expected': '2\n'}], 'abc400_c': [{'input': '20\n', 'expected': '5\n'}, {'input': '400\n', 'expected': '24\n'}, {'input': '1234567890\n', 'expected': '42413\n'}], 'abc401_c': [{'input': '4 2\n', 'expected': '5\n'}, {'input': '10 20\n', 'expected': '1\n'}, {'input': '1000000 500000\n', 'expected': '420890625\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
