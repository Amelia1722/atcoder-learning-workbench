"""ABC179–181 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
from math import isqrt
import re

TASKS = ('abc179_b', 'abc180_b', 'abc181_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc179_b': [
        {'input':'5\n1 2\n6 6\n4 4\n3 3\n3 2\n','expected':'Yes\n'},
        {'input':'5\n1 1\n2 2\n3 4\n5 5\n6 6\n','expected':'No\n'},
        {'input':'6\n1 1\n2 2\n3 3\n4 4\n5 5\n6 6\n','expected':'Yes\n'},
    ],
    'abc180_b': [
        {'input':'2\n2 -1\n','expected':'3\n2.236067977499790\n2\n'},
        {'input':'10\n3 -1 -4 1 -5 9 2 -6 5 -3\n','expected':'39\n14.387494569938159\n9\n'},
    ],
    'abc181_b': [
        {'input':'2\n1 3\n3 5\n','expected':'18\n'},
        {'input':'3\n11 13\n17 47\n359 44683\n','expected':'998244353\n'},
        {'input':'1\n1 1000000\n','expected':'500000500000\n'},
    ],
}


def _int(token: str, pattern: re.Pattern[str] = SIGNED) -> int:
    if pattern.fullmatch(token) is None:
        raise ValueError('noncanonical integer')
    return int(token)


def _row(line: str, count: int, pattern: re.Pattern[str] = SIGNED) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc179_b':
        if not lines or POS.fullmatch(lines[0]) is None:
            raise ValueError('N row')
        n = int(lines[0])
        if not 3 <= n <= 100 or len(lines) != n + 1:
            raise ValueError('N/row count')
        rolls = []
        for line in lines[1:]:
            a, b = _row(line, 2, POS)
            if not (1 <= a <= 6 and 1 <= b <= 6):
                raise ValueError('die range')
            rolls.append((a,b))
        return rolls

    if pid == 'abc180_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and coordinate row')
        n = int(lines[0])
        if not 1 <= n <= 100_000:
            raise ValueError('N range')
        xs = _row(lines[1], n, SIGNED)
        if any(not -100_000 <= x <= 100_000 for x in xs):
            raise ValueError('coordinate range')
        return xs

    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N row')
    n = int(lines[0])
    if not 1 <= n <= 100_000 or len(lines) != n + 1:
        raise ValueError('N/row count')
    intervals = []
    for line in lines[1:]:
        a,b = _row(line,2,POS)
        if not (1 <= a <= b <= 1_000_000):
            raise ValueError('interval range/order')
        intervals.append((a,b))
    return intervals


def _answer_179(rolls: list[tuple[int,int]]) -> str:
    streak = 0
    for a,b in rolls:
        streak = streak + 1 if a == b else 0
        if streak >= 3:
            return 'Yes'
    return 'No'


def _distances(xs: list[int]) -> tuple[int, int, int]:
    manhattan = sum(abs(x) for x in xs)
    squared = sum(x*x for x in xs)
    chebyshev = max(abs(x) for x in xs)
    return manhattan, squared, chebyshev


def _answer_181(intervals: list[tuple[int,int]]) -> int:
    total = 0
    for a,b in intervals:
        total += (a+b) * (b-a+1) // 2
    return total


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc179_b':
        return output in ('Yes','No') and output == _answer_179(value)

    if pid == 'abc180_b':
        parts = output.split('\n')
        if len(parts) != 3 or NONNEG.fullmatch(parts[0]) is None or NONNEG.fullmatch(parts[2]) is None:
            return False
        manhattan, squared, chebyshev = _distances(value)
        if int(parts[0]) != manhattan or int(parts[2]) != chebyshev:
            return False
        try:
            actual = Decimal(parts[1])
        except InvalidOperation:
            return False
        if not actual.is_finite() or actual < 0:
            return False
        with localcontext() as ctx:
            ctx.prec = 90
            truth = Decimal(squared).sqrt()
            diff = abs(actual - truth)
            tolerance = Decimal('1e-9')
            return diff <= tolerance or diff <= abs(truth) * tolerance

    if NONNEG.fullmatch(output) is None:
        return False
    return int(output) == _answer_181(value)


def _179(rows: list[tuple[int,int]]) -> str:
    return f'{len(rows)}\n' + ''.join(f'{a} {b}\n' for a,b in rows)


def _180(xs: list[int]) -> str:
    return f'{len(xs)}\n' + ' '.join(map(str,xs)) + '\n'


def _181(intervals: list[tuple[int,int]]) -> str:
    return f'{len(intervals)}\n' + ''.join(f'{a} {b}\n' for a,b in intervals)


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category: str, raw: str):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})

    if pid == 'abc179_b':
        cases = [
            ('sample1',[(1,2),(6,6),(4,4),(3,3),(3,2)]),
            ('sample2',[(1,1),(2,2),(3,4),(5,5),(6,6)]),
            ('sample3',[(1,1),(2,2),(3,3),(4,4),(5,5),(6,6)]),
            ('minimum_yes',[(1,1),(2,2),(6,6)]),
            ('minimum_no',[(1,1),(2,2),(3,4)]),
            ('all_nondouble',[(1,2),(2,3),(3,4),(4,5),(5,6)]),
            ('start_three',[(6,6),(5,5),(4,4),(1,2)]),
            ('end_three',[(1,2),(2,3),(4,4),(5,5),(6,6)]),
            ('two_break_two',[(1,1),(2,2),(3,4),(4,4),(5,5)]),
            ('alternating',[(1,1),(1,2),(2,2),(2,3),(3,3),(3,4),(4,4)]),
            ('four_straight',[(1,2),(2,2),(3,3),(4,4),(5,5),(6,1)]),
            ('same_face_three',[(6,6),(6,6),(6,6),(1,2),(2,1)]),
            ('different_faces_three',[(1,1),(6,6),(2,2),(3,4)]),
            ('n20_no',[(i%6+1,(i+1)%6+1) for i in range(20)]),
            ('n50_middle_yes',[(1,2)]*20+[(2,2),(3,3),(4,4)]+[(5,6)]*27),
            ('n99_two_at_end',[(1,2)]*97+[(5,5),(6,6)]),
            ('n100_no',[(1,2),(2,1)]*50),
        ]
        for cat, rows in cases: add(cat,_179(rows))
        add('constraint_max',_179([(1,2)]*97+[(1,1),(2,2),(3,3)]))

    elif pid == 'abc180_b':
        cases = [
            ('sample1',[2,-1]),
            ('sample2',[3,-1,-4,1,-5,9,2,-6,5,-3]),
            ('single_zero',[0]),('single_one',[1]),('single_negative',[-100000]),
            ('two_extremes',[-100000,100000]),('pythagorean',[3,4]),('integer_3d',[1,2,2]),
            ('all_zero',[0]*7),('mixed_small',[-3,-2,-1,0,1,2,3]),
            ('same_17',[17]*17),('alternating_100',[100000,-100000]*50),
            ('n999_pattern',[i%201-100 for i in range(999)]),
            ('n1000_sparse',[0]*999+[100000]),
            ('n10000_ones',[1]*10000),
            ('n50000_pm1',[1,-1]*25000),
            ('n99999_twos',[2]*99999),
        ]
        for cat,xs in cases: add(cat,_180(xs))
        add('constraint_max',_180([100000 if i%2==0 else -100000 for i in range(100000)]))

    else:
        cases = [
            ('sample1',[(1,3),(3,5)]),
            ('sample2',[(11,13),(17,47),(359,44683)]),
            ('sample3',[(1,1000000)]),
            ('single_one',[(1,1)]),('single_max',[(1000000,1000000)]),
            ('two_values',[(1,2)]),('near_max',[(999999,1000000)]),
            ('same_twice',[(5,5),(5,5)]),('overlap',[(1,10),(5,15)]),
            ('disjoint',[(1,3),(10,12),(100,101)]),
            ('n10_singletons',[(i,i) for i in range(1,11)]),
            ('n100_same',[(1,1000)]*100),
            ('n1000_singletons',[(i,i) for i in range(1,1001)]),
            ('n10000_small',[(1,10)]*10000),
            ('n50000_mixed',[(1,1) if i%2==0 else (1000000,1000000) for i in range(50000)]),
            ('n99999_fullish',[(1,999999)]*99999),
            ('n100000_singletons',[(1,1)]*100000),
        ]
        for cat,intervals in cases: add(cat,_181(intervals))
        add('constraint_max',_181([(1,1000000)]*100000))

    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
