"""Three-stage problem-specific hints for ABC121–124 A/B."""
HINTS_V19 = {
 'abc121_a': (
  '塗られる場所そのものではなく、最後まで塗られない行と列に注目しましょう。',
  '残った行数と列数をそれぞれ計算し、長方形の面積を求めます。',
  '疑似コード:\nH,W = read_two_ints()\nh,w = read_two_ints()\nprint((H-h)*(W-w))'),
 'abc121_b': (
  '各行について、与えられた数値を一定のルールで評価し、条件を満たす行数を数えます。',
  '各行の対応要素の積を足し、Cを加えた結果が0より大きいか判定します。',
  '疑似コード:\nN,M,C = read_three_ints()\nB = read_array(M)\nanswer = 0\nrepeat N times:\n  A = read_array(M)\n  if sum(A[j]*B[j] for j in 0..M-1)+C>0: answer+=1\nprint(answer)'),
 'abc122_a': (
  '入力の文字に対応する相手は、最初から決められた組だけです。',
  'AとT、CとGが対応する辞書を作り、入力文字をキーに取り出します。',
  '疑似コード:\nb = read_char()\npair = {A:T, T:A, C:G, G:C}\nprint(pair[b])'),
 'abc122_b': (
  '条件を満たす文字が続く区間の長さを考え、条件を満たさない文字で区切りましょう。',
  'A/C/G/Tが連続した長さを一文字ずつ更新する線形走査で、最大長を記録します。',
  '疑似コード:\nS = read_string()\ncurrent=0; best=0\nfor ch in S:\n  if ch in "ACGT": current+=1; best=max(best,current)\n  else: current=0\nprint(best)'),
 'abc123_a': (
  '離れた二つの地点ほど通信が難しくなることを考えましょう。',
  '座標は昇順に与えられるので、最も離れた両端の距離とkだけ比較します。',
  '疑似コード:\ncoords = read_five_positions()\nk = read_int()\nif coords[4]-coords[0]>k: print(":(")\nelse: print("Yay!")'),
 'abc123_b': (
  '最後の一品だけは、次の注文時刻まで待つ必要がないことに注目してください。',
  '全品を10分単位で切り上げた合計から、最後にする一品の切り上げ余分を最大限引きます。',
  '疑似コード:\nA = read_five_ints()\nrounded = sum(ceil_to_10(x) for x in A)\nanswer = min(rounded - (ceil_to_10(x)-x) for x in A)\nprint(answer)'),
 'abc124_a': (
  '押した後には、そのボタンから次にもらえる枚数が変わります。',
  '2回それぞれで、現在大きい方のボタンを押す貪欲法が使えます。',
  '疑似コード:\na,b = read_two_ints()\ncoins=0\nrepeat 2 times:\n  if a>=b: coins+=a; a-=1\n  else: coins+=b; b-=1\nprint(coins)'),
 'abc124_b': (
  'ある位置から左側だけを見たとき、どの高さまで見えていたかを考えましょう。',
  '左から走査して、それまでの最大高さ以上なら数え、最大高さを更新します。等号も含みます。',
  '疑似コード:\nN = read_int(); H = read_array(N)\nbest=0; answer=0\nfor h in H:\n  if h>=best: answer+=1\n  best=max(best,h)\nprint(answer)'),
}
