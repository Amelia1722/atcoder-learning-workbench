"""ABC137–139 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
from fractions import Fraction
import re

TASKS = ('abc137_b', 'abc138_b', 'abc139_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)

# Literal samples transcribed from the public official task pages.  Keeping a
# second fixed representation prevents a locally re-hashed modified cache from
# being silently accepted by the builder.
PUBLISHED_SAMPLES = {
    'abc137_b': [
        {'input': '3 7\n', 'expected': '5 6 7 8 9\n'},
        {'input': '4 0\n', 'expected': '-3 -2 -1 0 1 2 3\n'},
        {'input': '1 100\n', 'expected': '100\n'},
    ],
    'abc138_b': [
        {'input': '2\n10 30\n', 'expected': '7.5\n'},
        {'input': '3\n200 200 200\n', 'expected': '66.66666666666667\n'},
        {'input': '1\n1000\n', 'expected': '1000\n'},
    ],
    'abc139_b': [
        {'input': '4 10\n', 'expected': '3\n'},
        {'input': '8 9\n', 'expected': '2\n'},
        {'input': '8 8\n', 'expected': '1\n'},
    ],
}


def _split(line: str, count: int, pattern: re.Pattern[str]) -> list[str]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(token) is None for token in parts):
        raise ValueError('noncanonical integer row')
    return parts


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc137_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        k_raw, x_raw = _split(lines[0], 2, NONNEG)
        k, x = int(k_raw), int(x_raw)
        if not 1 <= k <= 100 or not 0 <= x <= 100:
            raise ValueError('K/X range')
        return k, x

    if pid == 'abc138_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and A row')
        n = int(lines[0])
        if not 1 <= n <= 100:
            raise ValueError('N range')
        a = list(map(int, _split(lines[1], n, POS)))
        if any(not 1 <= value <= 1000 for value in a):
            raise ValueError('A range')
        return a

    if len(lines) != 1:
        raise ValueError('expected one row')
    a_raw, b_raw = _split(lines[0], 2, POS)
    a, b = int(a_raw), int(b_raw)
    if not 2 <= a <= 20 or not 1 <= b <= 20:
        raise ValueError('A/B range')
    return a, b


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc137_b':
        parts = output.split(' ')
        if any(SIGNED.fullmatch(token) is None for token in parts):
            return False
        k, x = value
        expected = list(range(x - k + 1, x + k))
        return list(map(int, parts)) == expected

    if pid == 'abc138_b':
        try:
            actual = Decimal(output)
        except InvalidOperation:
            return False
        if not actual.is_finite() or actual <= 0:
            return False
        a = value
        reciprocal_sum = sum((Fraction(1, x) for x in a), Fraction(0, 1))
        truth_fraction = 1 / reciprocal_sum
        with localcontext() as ctx:
            ctx.prec = 80
            truth = Decimal(truth_fraction.numerator) / Decimal(truth_fraction.denominator)
            diff = abs(actual - truth)
            tolerance = Decimal('0.00001')
            return diff <= tolerance or diff <= abs(truth) * tolerance

    if NONNEG.fullmatch(output) is None:
        return False
    a, b = value
    sockets = 1
    strips = 0
    while sockets < b:
        sockets += a - 1
        strips += 1
    return output == str(strips)


def _one_row(a: int, b: int) -> str:
    return f'{a} {b}\n'


def _seq(values: list[int]) -> str:
    return f'{len(values)}\n' + ' '.join(map(str, values)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc137_b':
        fixed = [
            ('sample1',3,7), ('sample2',4,0), ('sample3',1,100),
            ('minimum',1,0), ('single_middle',1,50), ('k2_zero',2,0),
            ('k2_max_x',2,100), ('k3_zero',3,0), ('k3_max_x',3,100),
            ('k10_small_x',10,1), ('k10_middle',10,50), ('k10_max_x',10,100),
            ('k50_zero',50,0), ('k50_middle',50,50), ('k99_max_x',99,100),
            ('k100_zero',100,0), ('k100_middle',100,50),
        ]
        for category, k, x in fixed:
            add(category, _one_row(k, x))
        add('constraint_max', _one_row(100, 100))

    elif pid == 'abc138_b':
        fixed = [
            ('sample1',[10,30]), ('sample2',[200,200,200]), ('sample3',[1000]),
            ('minimum',[1]), ('two_ones',[1,1]), ('one_and_max',[1,1000]),
            ('two_max',[1000,1000]), ('mixed_small',[2,3,6]), ('harmonic',[2,4,8,16]),
            ('coprimeish',[7,11,13]), ('ascending10',list(range(1,11))),
            ('descending10',list(range(10,0,-1))), ('same17',[17]*17),
            ('same999',[999]*37), ('alternating',[1,1000]*25),
            ('near_n_max',[1000]*99), ('varied100',[i*10 for i in range(1,101)]),
        ]
        for category, values in fixed:
            add(category, _seq(values))
        add('constraint_max', _seq([1000] * 100))

    else:
        fixed = [
            ('sample1',4,10), ('sample2',8,9), ('sample3',8,8),
            ('already_enough',2,1), ('minimum_two',2,2), ('a2_b3',2,3),
            ('a2_b20',2,20), ('a3_b2',3,2), ('a3_b3',3,3),
            ('a3_b4',3,4), ('a3_b20',3,20), ('a20_b2',20,2),
            ('a20_b19',20,19), ('a20_b1',20,1), ('exact_after_two',5,9),
            ('just_over_one',5,6), ('near_max',19,20),
        ]
        for category, a, b in fixed:
            add(category, _one_row(a, b))
        add('constraint_max', _one_row(20, 20))

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
