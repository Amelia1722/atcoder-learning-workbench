"""Private ABC180..185 D domains and independent algorithms."""
from __future__ import annotations
from array import array
from collections import Counter
from decimal import Decimal,localcontext,DecimalException
from functools import lru_cache
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(180,186))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc184_d':'numeric_tolerance_1e-6'}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n')
    if pid=='abc185_d':
        n,m=ints(rows[0],2);require(1<=n<=10**9 and 0<=m<=200000,'range')
        if m==0:require(rows==[rows[0]] or rows==[rows[0],''],'empty positions shape');a:tuple[int,...]=()
        else:require(len(rows)==2,'shape');a=ints(rows[1],m)
        require(all(1<=v<=n for v in a) and len(set(a))==m,'distinct positions');return n,a
    require(all(rows),'blank')
    if pid=='abc180_d':
        require(len(rows)==1,'shape');x,y,a,b=ints(rows[0],4);require(1<=x<y<=10**18 and 2<=a<=10**9 and 1<=b<=10**9,'range');return x,y,a,b
    if pid=='abc181_d':require(len(rows)==1 and re.fullmatch('[1-9]{1,200000}',rows[0]) is not None,'digits');return (rows[0],)
    if pid=='abc182_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=200000 and all(-10**8<=v<=10**8 for v in a),'range');return (a,)
    if pid=='abc183_d':
        n,w=ints(rows[0],2);require(1<=n<=200000 and 1<=w<=10**9 and len(rows)==n+1,'shape/range');intervals=tuple(ints(r,3) for r in rows[1:]);require(all(0<=s<t<=200000 and 1<=p<=10**9 for s,t,p in intervals),'interval');return w,intervals
    require(len(rows)==1,'shape');a,b,c=ints(rows[0],3);require(all(0<=v<=99 for v in (a,b,c)) and a+b+c>=1,'range');return a,b,c

def growth_enumeration(x:int,y:int,a:int,b:int)->int:
    # Exchange +B then *A for *A then +B, whose final strength is no larger.
    answer=0;multiplications=0
    while x<y:answer=max(answer,multiplications+(y-1-x)//b);x*=a;multiplications+=1
    return answer

def eight_digit_dp(s:str)->bool:
    # Build suffixes of length min(3,N) from available digit multiplicities.
    # States store the used histogram (base4), residue and length, not multiples.
    counts=Counter(s);states={(0,0)};weights={d:4**(d-1) for d in range(1,10)}
    for _ in range(min(3,len(s))):
        next_states:set[tuple[int,int]]=set()
        for code,remainder in states:
            for digit,weight in weights.items():
                if (code//weight)%4<counts[str(digit)]:next_states.add((code+weight,(10*remainder+digit)%8))
        states=next_states
    return any(remainder==0 for _,remainder in states)

def wandering_reverse(a:tuple[int,...])->int:
    prefix:list[int]=[];bases:list[int]=[];velocity=0;position=0
    for value in a:bases.append(position);velocity+=value;prefix.append(velocity);position+=velocity
    best=0;suffix_base=-(10**30)
    for start in range(len(a)-1,-1,-1):suffix_base=max(suffix_base,bases[start]);best=max(best,suffix_base+prefix[start])
    return best

def water_active(w:int,intervals:tuple[tuple[int,...],...])->bool:
    active:list[tuple[int,int]]=[];usage=0
    for start,end,power in sorted(intervals):
        while active and active[0][0]<=start:_,old=heapq.heappop(active);usage-=old
        usage+=power
        if usage>w:return False
        heapq.heappush(active,(end,power))
    return True

@lru_cache(maxsize=64)
def coins_forward(a:int,b:int,c:int)->float:
    if sum(v>0 for v in (a,b,c))==1:return float(100-a-b-c)
    mass=array('d',[0.0])*(101**3);mass[a*10201+b*101+c]=1.0;initial=a+b+c;expectation=0.0
    arange=range(a,100) if a else (0,);brange=range(b,100) if b else (0,);crange=range(c,100) if c else (0,)
    for aa in arange:
        for bb in brange:
            base=aa*10201+bb*101
            for cc in crange:
                index=base+cc;probability=mass[index]
                if not probability:continue
                total=aa+bb+cc;unit=probability/total;steps=total+1-initial
                for count,delta in ((aa,10201),(bb,101),(cc,1)):
                    if count==99:expectation+=unit*count*steps
                    elif count:mass[index+delta]+=unit*count
    return expectation

def coins_decimal(a:int,b:int,c:int)->Decimal:return Decimal(str(coins_forward(*sorted((a,b,c)))))
def numeric_valid(target:Decimal,actual:str)->bool:
    token=actual.strip()
    if re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
    try:
        value=Decimal(token)
        with localcontext() as ctx:
            ctx.prec=max(80,len(value.as_tuple().digits)+20);difference=abs(value-target);tolerance=Decimal('0.000001');return value.is_finite() and (difference<=tolerance or difference<=abs(target)*tolerance)
    except (ValueError,DecimalException):return False

def stamp_width_search(n:int,a:tuple[int,...])->int:
    if len(a)==n:return 0
    boundaries=[0]+sorted(a)+[n+1];gaps=[right-left-1 for left,right in zip(boundaries,boundaries[1:]) if right>left+1]
    low=1;high=n
    while low<high:
        middle=(low+high+1)//2
        if all(size>=middle for size in gaps):low=middle
        else:high=middle-1
    return sum(size//low+int(size%low!=0) for size in gaps)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc180_d':return str(growth_enumeration(*cast(tuple[int,int,int,int],data)))
    if pid=='abc181_d':return 'Yes' if eight_digit_dp(cast(str,data[0])) else 'No'
    if pid=='abc182_d':return str(wandering_reverse(cast(tuple[int,...],data[0])))
    if pid=='abc183_d':return 'Yes' if water_active(*cast(tuple[int,tuple[tuple[int,...],...]],data)) else 'No'
    if pid=='abc184_d':return str(coins_decimal(*cast(tuple[int,int,int],data)))
    return str(stamp_width_search(*cast(tuple[int,tuple[int,...]],data)))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='abc184_d':return numeric_valid(coins_decimal(*cast(tuple[int,int,int],data)),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc180_d':"x,y,a,b=map(int,input().split());answer=0\nwhile x*a<y and x*a<x+b:x*=a;answer+=1\nprint(answer+(y-1-x)//b)\n",
'abc181_d':"from collections import Counter\nfrom itertools import permutations\ns=input()\nif len(s)<=2:print('Yes' if any(int(''.join(v))%8==0 for v in permutations(s)) else 'No')\nelse:\n count=Counter(s);possible=False\n for number in range(104,1000,8):\n  needed=Counter(str(number))\n  if all(count[d]>=v for d,v in needed.items()):possible=True;break\n print('Yes' if possible else 'No')\n",
'abc182_d':"n=int(input());a=list(map(int,input().split()));velocity=position=peak=answer=0\nfor value in a:velocity+=value;peak=max(peak,velocity);answer=max(answer,position+peak);position+=velocity\nprint(answer)\n",
'abc183_d':"n,w=map(int,input().split());difference=[0]*200002\nfor _ in range(n):s,t,p=map(int,input().split());difference[s]+=p;difference[t]-=p\nusage=0;possible=True\nfor change in difference:\n usage+=change\n if usage>w:possible=False;break\nprint('Yes' if possible else 'No')\n",
'abc184_d':"from functools import lru_cache\n@lru_cache(None)\ndef expected(a,b,c):\n if max(a,b,c)==100:return 0.\n total=a+b+c;value=1.\n if a:value+=a/total*expected(a+1,b,c)\n if b:value+=b/total*expected(a,b+1,c)\n if c:value+=c/total*expected(a,b,c+1)\n return value\na,b,c=map(int,input().split());print(format(expected(a,b,c),'.15f'))\n",
'abc185_d':"n,m=map(int,input().split());a=list(map(int,input().split())) if m else [];a.sort();points=[0]+a+[n+1];gaps=[v-u-1 for u,v in zip(points,points[1:]) if v>u+1]\nif not gaps:print(0)\nelse:\n width=min(gaps);print(sum((v+width-1)//width for v in gaps))\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18800+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc180_d':
        values=[(1,2,2,1),(1,10**18,2,1),(1,10**18,2,10**9),(10**18-2,10**18,10**9,10**9),(1,3,2,1),(1,4,2,2)]
        values += [(rng.randint(1,100),rng.randint(101,10**18),rng.randint(2,10**9),rng.randint(1,10**9)) for _ in range(10)]
        values += [(1,10**18,10**9,10**9),(10**18-1,10**18,10**9,10**9)];raws=[line(t) for t in values]
    elif pid=='abc181_d':raws=[s+'\n' for s in ['1','8','61','11','888','111','112','123','9999','444','12345','999999','1111111','77777','87654','314159265358979']]+['123456789'*22222+'12\n','9'*200000+'\n']
    elif pid=='abc182_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([0]),seq([-10**8]),seq([10**8]),seq([2,-1,-2]),seq([-1,10,-10])]+[seq([rng.randint(-10**8,10**8) for _ in range(n)]) for n in range(2,13)]+[seq([10**8,-10**8]*100000),seq([10**8]*200000)]
    elif pid=='abc183_d':
        def water(w:int,a:list[tuple[int,int,int]])->str:return f'{len(a)} {w}\n'+''.join(line(e) for e in a)
        raws=[water(1,[(0,1,1)]),water(1,[(0,1,2)]),water(1,[(0,1,1),(1,2,1)]),water(1,[(0,2,1),(1,2,1)])]
        for n in range(2,14):
            intervals=[]
            for _ in range(n):s=rng.randrange(200000);intervals.append((s,rng.randint(s+1,200000),rng.randint(1,10**9)))
            raws.append(water(rng.randint(1,10**9),intervals))
        raws += [water(10**9,[(j,j+1,10**9) for j in range(200000)]),water(10**9,[(0,200000,10**9)]*200000)]
    elif pid=='abc184_d':
        values=[(0,0,1),(0,1,0),(1,0,0),(0,0,99),(99,99,98),(99,98,97),(1,1,1),(1,1,0),(2,3,4)]
        values += [(rng.randint(80,99),rng.randint(80,99),rng.randint(80,99)) for _ in range(7)];values += [(1,2,3),(99,99,99)];raws=[line(t) for t in values]
    else:
        def stamp(n:int,a:list[int])->str:return f'{n} {len(a)}\n'+(line(a) if a else '\n')
        raws=[stamp(1,[]),stamp(1,[1]),stamp(10**9,[]),stamp(3,[2]),stamp(4,[4]),stamp(5,[1,3,5])]
        for n in range(6,16):raws.append(stamp(n,rng.sample(range(1,n+1),rng.randrange(n+1))))
        raws += [stamp(10**9,list(range(1,400001,2))),stamp(10**9,list(range(10**9-199999,10**9+1)))]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc180_d':('次の強さが小さい特訓を選ぶと、今後できる回数を減らしません。','X*AがX+Bより小さい間は掛け算を選び、それ以降は全て足し算です。どちらも強さがYに届く操作はできません。','疑似コード: answer=0; X*A<YかつX*A<X+Bの間X*=A,answer++; answer+=(Y-1-X)//B; answerを出力。'),
'abc181_d':('三桁以上の整数が8の倍数かどうかは、末尾三桁だけで決まります。','二桁以下は全並べ替えを調べます。三桁以上は三桁の8の倍数を列挙し、必要な数字を元の文字列から確保できるか判定します。','疑似コード: len<=2なら全permutationのint%8を判定; 他はdigitcountsを作り104,112,...,992の各数字countが手元count以下か確認; 一つあればYes、他はNo。'),
'abc182_d':('一つの段階での移動量はAの累積和です。その途中で一番右へ行く移動量も保存します。','現在位置と、ここまでの累積和の最大値を足して答えを更新し、その段階の累積和を現在位置に加えます。','疑似コード: velocity=position=peak=answer=0; 各aでvelocity+=a; peak=max(peak,velocity); answer=max(answer,position+peak); position+=velocity; answerを出力。'),
'abc183_d':('時刻Sで使用量が増え、時刻Tちょうどで使用量が減ります。','時刻ごとの増減を差分配列に加え、累積使用量がWを超える時刻があるか確認します。','疑似コード: difference[S]+=P,difference[T]-=P; 全時刻を昇順にusage+=difference[t]; usage>WならNo; 全て満たせばYes。'),
'abc184_d':('枚数を状態にすると、どの硬貨が選ばれる確率かを枚数の比で表せます。','期待値E(a,b,c)は、一回の操作と、その後の三つの期待値の確率付き和です。いずれか100枚の状態は0です。','疑似コード: memo付きE(a,b,c); max=100なら0; total=a+b+c; E=1+(a*E(a+1,b,c)+b*E(a,b+1,c)+c*E(a,b,c+1))/total; 0枚の種類の項は省略; E(A,B,C)を出力。'),
'abc185_d':('白い連続区間の中で一番短い区間より幅が長いハンコは使えません。','青い位置を並べて白区間を求めます。最小の正区間長を幅kにして、各区間で必要なceil(length/k)を合計します。','疑似コード: sort(A); 0,A...,N+1の隣接差-1から正gapだけ集める; gapがなければ0; 他はk=min(gap); sum((gap+k-1)//k)を出力。')}

TITLES={'abc180_d': 'Takahashi Unevolved', 'abc181_d': 'Hachi', 'abc182_d': 'Wandering', 'abc183_d': 'Water Heater', 'abc184_d': 'increment of coins', 'abc185_d': 'Stamp'}
PUBLISHED_SAMPLES={'abc180_d': [{'input': '4 20 2 10\n', 'expected': '2\n'}, {'input': '1 1000000000000000000 10 1000000000\n', 'expected': '1000000007\n'}], 'abc181_d': [{'input': '1234\n', 'expected': 'Yes\n'}, {'input': '1333\n', 'expected': 'No\n'}, {'input': '8\n', 'expected': 'Yes\n'}], 'abc182_d': [{'input': '3\n2 -1 -2\n', 'expected': '5\n'}, {'input': '5\n-2 1 3 -1 -1\n', 'expected': '2\n'}, {'input': '5\n-1000 -1000 -1000 -1000 -1000\n', 'expected': '0\n'}], 'abc183_d': [{'input': '4 10\n1 3 5\n2 4 4\n3 10 6\n2 4 1\n', 'expected': 'No\n'}, {'input': '4 10\n1 3 5\n2 4 4\n3 10 6\n2 3 1\n', 'expected': 'Yes\n'}, {'input': '6 1000000000\n0 200000 999999999\n2 20 1\n20 200 1\n200 2000 1\n2000 20000 1\n20000 200000 1\n', 'expected': 'Yes\n'}], 'abc184_d': [{'input': '99 99 99\n', 'expected': '1.000000000\n'}, {'input': '98 99 99\n', 'expected': '1.331081081\n'}, {'input': '0 0 1\n', 'expected': '99.000000000\n'}, {'input': '31 41 59\n', 'expected': '91.835008202\n'}], 'abc185_d': [{'input': '5 2\n1 3\n', 'expected': '3\n'}, {'input': '13 3\n13 3 9\n', 'expected': '6\n'}, {'input': '5 5\n5 2 1 4 3\n', 'expected': '0\n'}, {'input': '1 0\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
