"""ABC257–259 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
import re

TASKS = ('abc257_b', 'abc258_b', 'abc259_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc257_b': [
        {'input': '5 3 5\n1 3 4\n3 3 1 1 2\n', 'expected': '2 4 5\n'},
        {'input': '2 2 2\n1 2\n1 2\n', 'expected': '1 2\n'},
        {'input': '10 6 9\n1 3 5 7 8 9\n1 2 3 4 5 6 5 6 2\n', 'expected': '2 5 6 7 9 10\n'},
    ],
    'abc258_b': [
        {'input': '4\n1161\n1119\n7111\n1811\n', 'expected': '9786\n'},
        {'input': '10\n1111111111\n1111111111\n1111111111\n1111111111\n1111111111\n1111111111\n1111111111\n1111111111\n1111111111\n1111111111\n', 'expected': '1111111111\n'},
    ],
    'abc259_b': [
        {'input': '2 2 180\n', 'expected': '-2 -2\n'},
        {'input': '5 0 120\n', 'expected': '-2.49999999999999911182 4.33012701892219364908\n'},
        {'input': '0 0 11\n', 'expected': '0.00000000000000000000 0.00000000000000000000\n'},
        {'input': '15 5 360\n', 'expected': '15.00000000000000177636 4.99999999999999555911\n'},
        {'input': '-505 191 278\n', 'expected': '118.85878514480690171240 526.66743699786547949770\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints(line: str, count: int, pattern: re.Pattern[str] = POS) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate257(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 3:
        raise ValueError('shape')
    n, k, q = _ints(lines[0], 3)
    if not 1 <= k <= n <= 200 or not 1 <= q <= 1000:
        raise ValueError('constraints')
    a = _ints(lines[1], k)
    if any(not 1 <= x <= n for x in a) or any(a[i] >= a[i + 1] for i in range(k - 1)):
        raise ValueError('A')
    ops = _ints(lines[2], q)
    if any(not 1 <= x <= k for x in ops):
        raise ValueError('L')
    return n, tuple(a), tuple(ops)


def _validate258(raw: str):
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 10 or len(lines) != n + 1:
        raise ValueError('N/shape')
    rows = lines[1:]
    if any(len(row) != n or any(c < '1' or c > '9' for c in row) for row in rows):
        raise ValueError('grid')
    return tuple(rows)


def _validate259(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    parts = lines[0].split(' ')
    if len(parts) != 3 or SIGNED.fullmatch(parts[0]) is None or SIGNED.fullmatch(parts[1]) is None or POS.fullmatch(parts[2]) is None:
        raise ValueError('tokens')
    a, b, d = map(int, parts)
    if not -1000 <= a <= 1000 or not -1000 <= b <= 1000 or not 1 <= d <= 360:
        raise ValueError('constraints')
    return a, b, d


def validate(pid: str, raw: str):
    if pid == 'abc257_b': return _validate257(raw)
    if pid == 'abc258_b': return _validate258(raw)
    if pid == 'abc259_b': return _validate259(raw)
    raise ValueError('unknown task')


def _oracle257(n: int, a: tuple[int, ...], ops: tuple[int, ...]) -> tuple[int, ...]:
    pos = list(a)
    occupied = {x: i for i, x in enumerate(pos)}
    for one_based in ops:
        idx = one_based - 1
        x = pos[idx]
        y = x + 1
        if y > n or y in occupied:
            continue
        del occupied[x]
        occupied[y] = idx
        pos[idx] = y
    return tuple(pos)


def _oracle258(rows: tuple[str, ...]) -> str:
    n = len(rows)
    best = -1
    directions = ((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1))
    for sr in range(n):
        for sc in range(n):
            for dr, dc in directions:
                value = 0
                r, c = sr, sc
                for _ in range(n):
                    value = value * 10 + (ord(rows[r][c]) - 48)
                    r = (r + dr) % n
                    c = (c + dc) % n
                best = max(best, value)
    return str(best)


_PI = Decimal('3.141592653589793238462643383279502884197169399375105820974944592307816406286')


def _decimal_sin_cos(degrees: int) -> tuple[Decimal, Decimal]:
    with localcontext() as ctx:
        ctx.prec = 80
        x = Decimal(degrees) * _PI / Decimal(180)
        two_pi = _PI * 2
        x %= two_pi
        if x > _PI:
            x -= two_pi
        x2 = x * x
        sin_v, cos_v = x, Decimal(1)
        term_s, term_c = x, Decimal(1)
        for k in range(1, 45):
            term_s *= -x2 / Decimal((2*k)*(2*k+1))
            term_c *= -x2 / Decimal((2*k-1)*(2*k))
            sin_v += term_s
            cos_v += term_c
        return +sin_v, +cos_v


def _truth259(a: int, b: int, d: int) -> tuple[Decimal, Decimal]:
    s, c = _decimal_sin_cos(d)
    aa, bb = Decimal(a), Decimal(b)
    return aa*c - bb*s, aa*s + bb*c


def _within(actual: Decimal, truth: Decimal, tol: Decimal = Decimal('1e-6')) -> bool:
    diff = abs(actual - truth)
    return diff <= tol or diff <= abs(truth) * tol


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc257_b':
        n, a, ops = value
        parts = output.split(' ')
        if len(parts) != len(a) or any(POS.fullmatch(x) is None for x in parts):
            return False
        return tuple(map(int, parts)) == _oracle257(n, a, ops)
    if pid == 'abc258_b':
        rows = value
        return len(output) == len(rows) and output.isdigit() and output == _oracle258(rows)
    parts = output.split(' ')
    if len(parts) != 2:
        return False
    try:
        x, y = (Decimal(p) for p in parts)
    except InvalidOperation:
        return False
    if not x.is_finite() or not y.is_finite():
        return False
    tx, ty = _truth259(*value)
    return _within(x, tx) and _within(y, ty)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(category, raw):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); out.append({'category': category, 'input': raw})
    for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}', row['input'])
    if pid == 'abc257_b':
        cases = [
            ('single_stuck','1 1 1\n1\n1\n'), ('single_move','2 1 1\n1\n1\n'),
            ('single_repeated','5 1 6\n1\n1 1 1 1 1 1\n'), ('adjacent_blocked','4 2 4\n1 2\n1 2 1 2\n'),
            ('two_gap','6 2 5\n1 5\n1 1 2 2 1\n'), ('all_occupied','6 6 6\n1 2 3 4 5 6\n1 2 3 4 5 6\n'),
            ('last_piece','8 3 5\n1 3 6\n3 3 3 2 1\n'), ('cascade','8 4 8\n1 3 5 7\n4 3 2 1 4 3 2 1\n'),
            ('repeated_first','10 3 10\n1 5 9\n1 1 1 1 1 1 1 1 1 1\n'),
            ('middle_pressure','12 5 12\n1 2 5 8 11\n3 3 2 4 5 1 3 2 4 5 1 3\n'),
            ('n20','20 5 20\n1 4 8 12 16\n'+' '.join(str(i%5+1) for i in range(20))+'\n'),
            ('n50','50 10 40\n'+' '.join(str(1+i*4) for i in range(10))+'\n'+' '.join(str((i*7)%10+1) for i in range(40))+'\n'),
            ('n100','100 25 100\n'+' '.join(str(1+i*3) for i in range(25))+'\n'+' '.join(str((i*11)%25+1) for i in range(100))+'\n'),
            ('n199','199 50 200\n'+' '.join(str(1+i*3) for i in range(50))+'\n'+' '.join(str((i*17)%50+1) for i in range(200))+'\n'),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max','200 200 1000\n'+' '.join(map(str,range(1,201)))+'\n'+' '.join(str(i%200+1) for i in range(1000))+'\n')
    elif pid == 'abc258_b':
        def pack(rows): return f'{len(rows)}\n'+'\n'.join(rows)+'\n'
        cases = [
            ('n1_low',pack(['1'])), ('n1_high',pack(['9'])), ('n2_diag',pack(['12','34'])), ('n2_wrap',pack(['91','19'])),
            ('n3_rows',pack(['123','456','789'])), ('n3_corner9',pack(['911','111','119'])),
            ('n4_desc',pack(['9876','5432','1987','6543'])), ('n4_uniform9',pack(['9999']*4)),
            ('n5_spiralish',pack(['12345','67891','23456','78912','34567'])),
            ('n5_one9',pack(['11111','11111','11911','11111','11111'])),
            ('n6_pattern',pack(['123456','234561','345612','456123','561234','612345'])),
            ('n7_pattern',pack(['1234567','7654321','2345671','6712345','3456712','5671234','4567123'])),
            ('n8_checker',pack(['91919191' if i%2==0 else '19191919' for i in range(8)])),
            ('n9_diag9',pack([''.join('9' if i==j else str((i+j)%8+1) for j in range(9)) for i in range(9)])),
            ('n10_mixed',pack(['1234567891','2345678912','3456789123','4567891234','5678912345','6789123456','7891234567','8912345678','9123456789','1234567891'])),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max',pack(['9'*10 for _ in range(10)]))
    else:
        cases = [
            ('origin360','0 0 360\n'), ('x90','1 0 90\n'), ('y90','0 1 90\n'), ('negx270','-7 0 270\n'),
            ('negy45','0 -8 45\n'), ('quarter','3 4 90\n'), ('half','-3 7 180\n'), ('threequarter','12 -5 270\n'),
            ('small_angle','1000 1 1\n'), ('large_negative','-1000 -1000 359\n'), ('mixed_137','321 -654 137\n'), ('mixed_223','-987 456 223\n'),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max','1000 1000 360\n')
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
