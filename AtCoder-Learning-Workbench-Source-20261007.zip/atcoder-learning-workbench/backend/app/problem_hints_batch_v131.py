"""Statement-checked three-stage hints for ABC251–253 B."""
HINTS_V131 = {
 'abc251_b': (
  '選ぶおもりは高々3個です。1個、2個、3個の場合をすべて調べ、W以下になった和だけを集合に入れれば重複を除けます。',
  'N≤300なので3重ループでも約2700万組です。異なる添字だけを選ぶよう i<j<k として、1個・2個・3個の和をsetへ追加します。',
  '疑似コード:\ngood = empty set\nfor i:\n  add A[i] if <= W\n  for j > i:\n    add A[i]+A[j] if <= W\n    for k > j:\n      add A[i]+A[j]+A[k] if <= W\nprint(len(good))',
 ),
 'abc252_b': (
  '食べる可能性があるのは「おいしさが最大」の食品だけです。その中に嫌いな食品が1つでもあるかを確認します。',
  '最大値M=max(A)を求め、Bに含まれる各食品番号についてA[B_i-1]==Mか調べれば十分です。',
  '疑似コード:\nM = max(A)\nfor b in B:\n  if A[b-1] == M:\n    print("Yes")\n    exit\nprint("No")',
 ),
 'abc253_b': (
  '駒は上下左右にだけ動くので、2点間の最短移動回数は行番号の差の絶対値＋列番号の差の絶対値です。',
  '盤面を走査して`o`の座標を2つ保存し、マンハッタン距離を計算します。障害物はないため経路探索は不要です。',
  '疑似コード:\npos = []\nfor r,c in all cells:\n  if S[r][c] == "o": pos.append((r,c))\n(r1,c1),(r2,c2) = pos\nprint(abs(r1-r2) + abs(c1-c2))',
 ),
}
