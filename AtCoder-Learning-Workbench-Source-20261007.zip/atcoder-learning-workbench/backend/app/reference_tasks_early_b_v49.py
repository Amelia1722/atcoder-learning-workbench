"""ABC009/010 B: problem-specific validators and independent answer oracles.
Public statements manually reviewed; no authenticated HTML snapshots.
"""
from __future__ import annotations
import random
import re
TASKS = ('abc009_2','abc010_2')
DECIMAL = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

def validate(pid: str, raw: str) -> list[int]:
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('invalid task or input')
    lines=raw[:-1].split('\n')
    if not lines or DECIMAL.fullmatch(lines[0]) is None:
        raise ValueError('invalid count')
    n=int(lines[0])
    if pid=='abc009_2':
        if not 2<=n<=100 or len(lines)!=n+1 or any(DECIMAL.fullmatch(x) is None for x in lines[1:]):
            raise ValueError('invalid ABC009 B lines')
        nums=[int(x) for x in lines[1:]]
        if any(not 1<=a<=1000 for a in nums) or len(set(nums))<2:
            raise ValueError('prices must be valid and not all equal')
        return nums
    if not 1<=n<=10 or len(lines)!=2:
        raise ValueError('invalid ABC010 B row count')
    tokens=lines[1].split(' ')
    if len(tokens)!=n or any(DECIMAL.fullmatch(x) is None for x in tokens):
        raise ValueError('invalid ABC010 B values')
    values=[int(x) for x in tokens]
    if any(not 1<=a<=9 for a in values):
        raise ValueError('petals out of range')
    return values

def independent_answer(pid: str, raw: str) -> str:
    values=validate(pid,raw)
    if pid=='abc009_2':
        biggest=runner=None
        for value in values:
            if biggest is None or value>biggest:
                runner,biggest=biggest,value
            elif value!=biggest and (runner is None or value>runner):
                runner=value
        assert runner is not None
        return str(runner)
    removed=0
    for petals in values:
        for count in range(petals,0,-1):
            if count%2==1 and count%3!=2:
                removed+=petals-count
                break
        else:
            raise AssertionError('no valid petal count')
    return str(removed)

def independent_check(pid:str,raw:str,out:str)->bool:
    return isinstance(out,str) and out==independent_answer(pid,raw)

def generate(pid:str, seed:int=49)->list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unknown task')
    rng=random.Random(f'abc-v49:{pid}:{seed}')
    cases=[]; seen=set()
    def add(category, values):
        if pid=='abc009_2':raw=str(len(values))+'\n'+'\n'.join(map(str,values))+'\n'
        else:raw=str(len(values))+'\n'+' '.join(map(str,values))+'\n'
        validate(pid,raw)
        if raw not in seen:seen.add(raw);cases.append({'category':category,'input':raw})
    if pid=='abc009_2':
        presets=[[1,2],[2,1],[999,1000],[1000,999],[100,200,300,300],
                 [1000]*99+[1],[1]*99+[1000],[1,1000]*50,[1000,1000,999],
                 [1,2,2],[3,3,1,2],[1000,999,998],[4,1,3,2],list(range(1,101))]
        for vals in presets:add('boundary' if len(vals) in (2,100) else 'normal',vals)
        while len(cases)<17:
            n=rng.randint(2,100)
            values=[rng.randint(1,1000) for _ in range(n)]
            if len(set(values))>=2:add('normal',values)
        maximum=list(range(1,101))
        maximum[-1]=1000
    else:
        presets=[[1],[2],[3],[4],[5],[6],[7],[8],[9],list(range(1,10)),
                 [9]*10,[1]*10,[2]*10,[5]*10,[8]*10,[3,5,8],[9,8,7,6,5,4,3,2,1,9]]
        for vals in presets:add('boundary' if len(vals) in (1,10) else 'normal',vals)
        while len(cases)<17:
            vals=[rng.randint(1,9) for _ in range(rng.randint(1,10))]
            add('normal',vals)
        maximum=[9]*9+[8]
    if pid=='abc009_2':raw=str(len(maximum))+'\n'+'\n'.join(map(str,maximum))+'\n'
    else:raw='10\n'+' '.join(map(str,maximum))+'\n'
    validate(pid,raw)
    cases=[c for c in cases if c['input']!=raw][:17]
    cases.append({'category':'constraint_max','input':raw})
    if len(cases)!=18 or len({c['input'] for c in cases})!=18:
        raise ValueError('nonunique generated inputs')
    return cases
