"""ABC206–208 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re
from math import factorial, isqrt

TASKS = ('abc206_b', 'abc207_b', 'abc208_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'0|[1-9][0-9]*', re.ASCII)
SIGNED = re.compile(r'-1|0|[1-9][0-9]*', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc206_b': [
        {'input': '12\n', 'expected': '5\n'},
        {'input': '100128\n', 'expected': '447\n'},
    ],
    'abc207_b': [
        {'input': '5 2 3 2\n', 'expected': '2\n'},
        {'input': '6 9 2 3\n', 'expected': '-1\n'},
    ],
    'abc208_b': [
        {'input': '9\n', 'expected': '3\n'},
        {'input': '119\n', 'expected': '10\n'},
        {'input': '10000000\n', 'expected': '24\n'},
    ],
}


def _one(raw: str, lo: int, hi: int) -> int:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if '\n' in body or POS.fullmatch(body) is None:
        raise ValueError('shape/integer')
    x = int(body)
    if not lo <= x <= hi:
        raise ValueError('range')
    return x


def _split4(raw: str) -> tuple[int, int, int, int]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if '\n' in body:
        raise ValueError('shape')
    parts = body.split(' ')
    if len(parts) != 4 or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    a, b, c, d = map(int, parts)
    if any(not 1 <= x <= 100000 for x in (a, b, c, d)):
        raise ValueError('range')
    return a, b, c, d


def validate(pid: str, raw: str):
    if pid == 'abc206_b':
        return _one(raw, 1, 10**9)
    if pid == 'abc207_b':
        return _split4(raw)
    if pid == 'abc208_b':
        return _one(raw, 1, 10**7)
    raise ValueError('unknown task')


def _ans206(n: int) -> int:
    # Independent from the reference simulation: solve x(x+1)/2 >= n with integer sqrt, then adjust.
    x = (isqrt(1 + 8 * n) - 1) // 2
    while x * (x + 1) // 2 < n:
        x += 1
    while x > 1 and (x - 1) * x // 2 >= n:
        x -= 1
    return x


def _ans207(v: tuple[int, int, int, int]) -> int:
    a, b, c, d = v
    gain = c * d - b
    if gain <= 0:
        return -1
    return (a + gain - 1) // gain


def _ans208(p: int) -> int:
    # Factoradic coefficient sum; formulated independently from the reference's descending remainder loop.
    ans = p // factorial(10)
    for k in range(1, 10):
        ans += (p // factorial(k)) % (k + 1)
    return ans


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or '\n' in output or output != output.strip():
        return False
    if pid == 'abc207_b':
        return SIGNED.fullmatch(output) is not None and int(output) == _ans207(value)
    if NONNEG.fullmatch(output) is None:
        return False
    expected = _ans206(value) if pid == 'abc206_b' else _ans208(value)
    return int(output) == expected


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out = []
    seen = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    if pid == 'abc206_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        values = [
            ('min', '1\n'), ('tri2', '3\n'), ('after_tri2', '4\n'), ('tri3', '6\n'),
            ('after_tri3', '7\n'), ('tri10', '55\n'), ('after_tri10', '56\n'),
            ('before_tri100', '5049\n'), ('tri100', '5050\n'), ('after_tri100', '5051\n'),
            ('tri1000', '500500\n'), ('after_tri1000', '500501\n'), ('million', '1000000\n'),
            ('near_max', '999999999\n'), ('large_boundary', '999950000\n'),
        ]
        for category, raw in values:
            add(category, raw)
        add('constraint_max', '1000000000\n')
    elif pid == 'abc207_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        values = [
            ('min_gain1', '1 1 1 2\n'), ('impossible_equal', '1 1 1 1\n'),
            ('impossible_bigger', '10 100 1 1\n'), ('one_step_exact', '5 1 3 2\n'),
            ('one_step_slack', '5 1 4 2\n'), ('gain1_large_a', '100000 99999 50000 2\n'),
            ('large_gain', '100000 1 100000 100000\n'), ('d1_possible', '10 1 3 1\n'),
            ('d1_impossible', '10 3 3 1\n'), ('c1_dmax', '99999 1 1 100000\n'),
            ('bmax_possible', '100000 100000 100000 2\n'),
            ('bmax_impossible', '100000 100000 1 100000\n'),
            ('ceil_boundary', '11 2 3 2\n'), ('ceil_exact', '12 2 3 2\n'),
            ('balanced_large', '99991 99990 99991 1\n'),
        ]
        for category, raw in values:
            add(category, raw)
        add('constraint_max', '100000 100000 100000 100000\n')
    else:
        # Sample 3 is itself the maximum input; keep that input as constraint_max in the generated set.
        for i, row in enumerate(PUBLISHED_SAMPLES[pid][:2], 1):
            add(f'sample{i}', row['input'])
        values = [
            ('min', '1\n'), ('two', '2\n'), ('factorial3', '6\n'), ('factorial4', '24\n'),
            ('factorial5', '120\n'), ('below4fact', '23\n'), ('above4fact', '25\n'),
            ('mixed_small', '17\n'), ('factorial6_minus1', '719\n'), ('factorial6', '720\n'),
            ('factorial7_plus', '5041\n'), ('factorial10', '3628800\n'),
            ('twice_factorial10', '7257600\n'), ('near_max', '9999999\n'), ('large_mixed', '8765432\n'),
        ]
        for category, raw in values:
            add(category, raw)
        add('constraint_max', '10000000\n')
    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
