"""ABC041–043 B: hand-reviewed public statements, unauthenticated HTML originals."""
from __future__ import annotations
import random
import re

TASKS = ('abc041_b', 'abc042_b', 'abc043_b')
INTEGER = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown problem or noncanonical input')
    lines = raw[:-1].split('\n')
    if pid == 'abc041_b':
        if len(lines) != 1:
            raise ValueError('expected exactly one line')
        tokens = lines[0].split(' ')
        if len(tokens) != 3 or any(INTEGER.fullmatch(x) is None for x in tokens):
            raise ValueError('expected three canonical positive integers')
        vals = tuple(map(int, tokens))
        if not all(1 <= v <= 10**9 for v in vals):
            raise ValueError('dimension outside constraints')
        return vals
    if pid == 'abc042_b':
        if not lines:
            raise ValueError('empty')
        tokens = lines[0].split(' ')
        if len(tokens) != 2 or any(INTEGER.fullmatch(x) is None for x in tokens):
            raise ValueError('expected N L')
        n, length = map(int, tokens)
        if not (1 <= n <= 100 and 1 <= length <= 100) or len(lines) != n + 1:
            raise ValueError('N L or line count outside constraints')
        if any(len(s) != length or LOWER.fullmatch(s) is None for s in lines[1:]):
            raise ValueError('strings must contain L lowercase ASCII letters')
        return tuple(lines[1:])
    if len(lines) != 1 or not 1 <= len(lines[0]) <= 10 or any(c not in '01B' for c in lines[0]):
        raise ValueError('invalid keystrokes')
    # Official constraint: the final edited string must be nonempty.
    stack = []
    for c in lines[0]:
        if c == 'B':
            if stack:
                stack.pop()
        else:
            stack.append(c)
    if not stack:
        raise ValueError('official constraint forbids empty final answer')
    return lines[0]


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        data = validate(pid, raw)
    except (ValueError, TypeError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc041_b':
        # Separate modular reduction at each multiplication, not a monolithic product.
        acc = 1
        for dim in data:
            acc = (acc * (dim % 1000000007)) % 1000000007
        return output == str(acc)
    if pid == 'abc042_b':
        # Selection algorithm: repeatedly remove the minimum, not sorted/join.
        pool = list(data)
        answer = ''
        while pool:
            smallest = min(pool)
            answer += smallest
            pool.remove(smallest)
        return output == answer
    # Reverse scan: each pending B erases the nearest preceding surviving digit.
    pending = 0
    rev = []
    for c in reversed(data):
        if c == 'B':
            pending += 1
        elif pending:
            pending -= 1
        else:
            rev.append(c)
    return output == ''.join(reversed(rev))


def generate(pid: str, seed: int = 61) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown problem')
    rng = random.Random(f'abc-v61:{pid}:{seed}')
    rows: list[dict[str, str]] = []
    seen = set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            rows.append({'category': category, 'input': raw})
    if pid == 'abc041_b':
        fixtures = [(1,1,1),(1,1,2),(2,3,4),(10**9,1,1),(1,10**9,1),
                    (1,1,10**9),(1000000000,1000000000,1),(1000000000,1,1000000000),
                    (999999937,1,1),(1000000000,999999999,999999998),
                    (7,7,7),(998244353,998244353,998244353),(2,1000000000,3)]
        for a,b,c in fixtures:
            add('boundary' if 1 in (a,b,c) else 'normal', f'{a} {b} {c}\n')
        while len(rows) < 17:
            a,b,c = (rng.randint(1, 10**9) for _ in range(3))
            add('random', f'{a} {b} {c}\n')
        add('constraint_max',f'{10**9} {10**9} {10**9}\n')
    elif pid == 'abc042_b':
        fixtures = [(['a'],1),(['z'],1),(['b','a'],1),(['aa','ab','aa'],2),
                    (['zzz','aaa','bbb'],3),(['abab','abaa','abac'],4),
                    (['a','a','a','b'],1),(['zy','xz','ab'],2),
                    (['z'*10,'a'*10,'m'*10],10),(['abc','abc','abd'],3),
                    (['aa','ba','ab','bb'],2)]
        for words,length in fixtures:
            add('boundary' if len(words)==1 else 'normal',f'{len(words)} {length}\n'+'\n'.join(words)+'\n')
        while len(rows) < 17:
            n = rng.randint(1, 8)
            length = rng.randint(1, 8)
            words = [''.join(rng.choice('abcxyz') for _ in range(length)) for _ in range(n)]
            add('random',f'{n} {length}\n'+'\n'.join(words)+'\n')
        add('constraint_max', '100 100\n'+'\n'.join('z'*100 if i%2 else 'a'*100 for i in range(100))+'\n')
    else:
        fixtures = ['0','1','B0','BB1','01B0','0BB1','001B','101B1','0B1','1B0',
                    '00BB1','BBBBBB1','100B01','0B0B1','1010101','0BB0BB1']
        for seq in fixtures:
            add('boundary' if len(seq)<=2 else 'normal',seq+'\n')
        while len(rows) < 17:
            seq=''.join(rng.choice('01B') for _ in range(rng.randint(1,10)))
            try: add('random',seq+'\n')
            except ValueError: continue
        add('constraint_max','BBBBBBBBB1\n')
    if len(rows) != 18 or rows[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases, got {len(rows)}')
    return rows
