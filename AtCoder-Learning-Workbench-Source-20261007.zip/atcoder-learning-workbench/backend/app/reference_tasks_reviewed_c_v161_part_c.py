"""Reviewed C tasks ABC148--151,153,156 with independent bounded oracles."""
from __future__ import annotations
from functools import lru_cache
from math import factorial
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in (148,149,150,151,153,156))
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'field count');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==148:
        require(len(rows)==1,'shape');a,b=ints(rows[0],2);require(1<=a<=100000 and 1<=b<=100000 and a!=b,'distinct party sizes');return a,b
    if number==149:
        require(len(rows)==1,'shape');x=ints(rows[0],1)[0];require(2<=x<=100000,'lower bound');return (x,)
    if number==150:
        n=ints(rows[0],1)[0];require(2<=n<=8 and len(rows)==3,'shape');p=ints(rows[1],n);q=ints(rows[2],n);require(set(p)==set(q)==set(range(1,n+1)),'permutations');return p,q
    if number==151:
        n,m=ints(rows[0],2);require(1<=n<=100000 and 0<=m<=100000 and len(rows)==m+1,'shape');events:list[tuple[int,str]]=[]
        for row in rows[1:]:
            require(re.fullmatch(r'[1-9][0-9]* (?:AC|WA)',row) is not None,'submission');p,s=row.split(' ');require(1<=int(p)<=n,'problem index');events.append((int(p),s))
        return n,tuple(events)
    if number==153:
        n,k=ints(rows[0],2);require(1<=n<=200000 and 0<=k<=200000 and len(rows)==2,'shape');h=ints(rows[1],n);require(all(1<=v<=10**9 for v in h),'health');return k,h
    n=ints(rows[0],1)[0];require(1<=n<=100 and len(rows)==2,'shape');xs=ints(rows[1],n);require(all(1<=x<=100 for x in xs),'positions');return (xs,)

def factor_powers(value:int)->dict[int,int]:
    powers:dict[int,int]={};p=2
    while p*p<=value:
        while value%p==0:powers[p]=powers.get(p,0)+1;value//=p
        p+=1
    if value>1:powers[value]=powers.get(value,0)+1
    return powers

@lru_cache(maxsize=1)
def prime_sieve()->bytes:
    size=200001;flags=bytearray(b'\x01')*size;flags[0:2]=b'\x00\x00'
    for p in range(2,448):
        if flags[p]:flags[p*p:size:p]=b'\x00'*len(range(p*p,size,p))
    return bytes(flags)

def permutation_rank(p:tuple[int,...])->int:
    return sum(sum(other<value for other in p[j+1:])*factorial(len(p)-j-1) for j,value in enumerate(p))

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==148:
        a,b=cast(tuple[int,int],data);fa=factor_powers(a);fb=factor_powers(b);answer=1
        for p in fa.keys()|fb.keys():answer*=p**max(fa.get(p,0),fb.get(p,0))
        return str(answer)
    if number==149:
        x=cast(int,data[0]);flags=prime_sieve();return str(next(j for j in range(x,len(flags)) if flags[j]))
    if number==150:
        p,q=cast(tuple[tuple[int,...],tuple[int,...]],data);return str(abs(permutation_rank(p)-permutation_rank(q)))
    if number==151:
        _,events=cast(tuple[int,tuple[tuple[int,str],...]],data);first_ac:dict[int,int]={}
        for j,(p,s) in enumerate(events):
            if s=='AC':first_ac.setdefault(p,j)
        penalties=sum(s=='WA' and j<first_ac.get(p,-1) for j,(p,s) in enumerate(events));return f'{len(first_ac)} {penalties}'
    if number==153:
        k,h=cast(tuple[int,tuple[int,...]],data);keep=max(0,len(h)-k)
        if keep==0:return '0'
        lo=0;hi=max(h)
        while hi-lo>1:
            mid=(lo+hi)//2
            if sum(v<=mid for v in h)>=keep:hi=mid
            else:lo=mid
        below=[v for v in h if v<hi];return str(sum(below)+(keep-len(below))*hi)
    xs=cast(tuple[int,...],data[0]);return str(min(sum((x-position)**2 for x in xs) for position in range(1,101)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc148_c':"from math import gcd\na,b=map(int,input().split());print(a//gcd(a,b)*b)\n",
'abc149_c':"from math import isqrt\nx=int(input())\nwhile any(x%d==0 for d in range(2,isqrt(x)+1)):x+=1\nprint(x)\n",
'abc150_c':"from itertools import permutations\nn=int(input());p=tuple(map(int,input().split()));q=tuple(map(int,input().split()));items=list(permutations(range(1,n+1)));print(abs(items.index(p)-items.index(q)))\n",
'abc151_c':"n,m=map(int,input().split());solved=[False]*n;wrong=[0]*n;penalty=0\nfor _ in range(m):\n p,s=input().split();p=int(p)-1\n if solved[p]:continue\n if s=='WA':wrong[p]+=1\n else:solved[p]=True;penalty+=wrong[p]\nprint(sum(solved),penalty)\n",
'abc153_c':"n,k=map(int,input().split());h=sorted(map(int,input().split()),reverse=True);print(sum(h[k:]))\n",
'abc156_c':"n=int(input());x=list(map(int,input().split()));center=sum(x)//n;print(min(sum((v-center)**2 for v in x),sum((v-center-1)**2 for v in x)))\n"}

def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16100+number);raws:list[str]=[]
    if number==148:raws=[line(pair) for pair in ((1,2),(2,1),(2,3),(4,8),(6,9),(12,18),(97,101),(100000,1),(1,100000),(99991,99989),(65536,32768),(59049,19683),(99999,33333),(123,456),(2520,5040),(99999,2),(2,100000),(100000,99999))]
    elif number==149:raws=[f'{x}\n' for x in (2,3,4,5,6,8,9,10,11,12,20,21,97,98,99991,99992,99999,100000)]
    elif number==150:
        def ranks(p:list[int],q:list[int])->str:return f'{len(p)}\n'+line(p)+line(q)
        raws=[ranks([1,2],[1,2]),ranks([1,2],[2,1]),ranks([2,1],[1,2]),ranks([2,1],[2,1])]
        while len(raws)<17:
            n=3+len(raws)%5;p=list(range(1,n+1));q=p.copy();rng.shuffle(p);rng.shuffle(q);raw=ranks(p,q)
            if raw not in raws:raws.append(raw)
        raws.append(ranks(list(range(1,9)),list(range(8,0,-1))))
    elif number==151:
        def contest(n:int,events:list[tuple[int,str]])->str:return f'{n} {len(events)}\n'+''.join(f'{p} {s}\n' for p,s in events)
        raws=[contest(1,[]),contest(1,[(1,'WA')]),contest(1,[(1,'AC')]),contest(1,[(1,'AC'),(1,'WA')]),contest(2,[(1,'WA'),(2,'AC'),(1,'WA')]),contest(1,[(1,'WA'),(1,'AC'),(1,'AC'),(1,'WA')])]+[contest(j+1,[(rng.randrange(1,j+2),rng.choice(('AC','WA'))) for _ in range(j*3)]) for j in range(1,11)]+[contest(100000,[(j+1,'WA') for j in range(100000)]),contest(100000,[(100000,'WA')]*99999+[(100000,'AC')])]
    elif number==153:
        def fight(k:int,h:list[int])->str:return f'{len(h)} {k}\n'+line(h)
        raws=[fight(0,[1]),fight(1,[1]),fight(200000,[1]),fight(0,[10**9]),fight(1,[10**9,1]),fight(2,[1,2])]+[fight(j%5,[rng.randrange(1,1001) for _ in range(j+3)]) for j in range(1,10)]+[fight(0,[10**9]*200000),fight(1,[1]*199999+[10**9]),fight(200000,[10**9]*200000)]
    else:
        def rally(xs:list[int])->str:return f'{len(xs)}\n'+line(xs)
        raws=[rally([1]),rally([100]),rally([1,100]),rally([1,4])]+[rally([rng.randrange(1,101) for _ in range(n)]) for n in range(3,15)]+[rally([1]*50+[100]*50),rally([100]*100)]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc148_c':('どちらの人数でも配り切れる個数は、両方の倍数です。','最小公倍数はA×Bを最大公約数で割ると求まります。','疑似コード: print((A/gcd(A,B))*B)。'),
'abc149_c':('Xから順に素数かを調べます。','合成数なら平方根以下に約数があるので、その範囲の整数で割り切れるか確認します。','疑似コード: candidate=X; while exists d in 2..floor(sqrt(candidate)) with candidate%d==0: candidate+=1; print(candidate)。'),
'abc150_c':('Nは8以下なので、すべての順列を列挙できます。','1からNの順列を辞書順に並べ、PとQの位置を求めます。','疑似コード: permutations=all_permutations(1..N) in lexicographic order; print(abs(index(P)-index(Q)))。'),
'abc151_c':('正解済みの問題への提出は、その後のペナルティへ影響しません。','問題ごとのWA回数と正解済みフラグを持ち、初めてACした時だけWA回数を加算します。','疑似コード: for (p,result): if solved[p]: continue; if WA: wrong[p]+=1; else: solved[p]=true; penalty+=wrong[p]; print(count(solved),penalty)。'),
'abc153_c':('体力の大きいモンスターへ必殺技を使うと、通常攻撃を多く省けます。','体力を降順に並べ、先頭K体を除いた体力の総和を求めます。','疑似コード: H=sort(H,descending); print(sum(H[K:]))。K>=Nなら空の和で0。'),
'abc156_c':('二乗距離の総和は、平均付近で最小になります。','平均の切り捨てと、その一つ上の整数座標を比べます。','疑似コード: center=floor(sum(X)/N); print(min(sum((x-center)^2),sum((x-(center+1))^2)))。')}

TITLES={'abc148_c': 'Snack', 'abc149_c': 'Next Prime', 'abc150_c': 'Count Order', 'abc151_c': 'Welcome to AtCoder', 'abc153_c': 'Fennec vs Monster', 'abc156_c': 'Rally'}
PUBLISHED_SAMPLES={'abc148_c': [{'input': '2 3\n', 'expected': '6\n'}, {'input': '123 456\n', 'expected': '18696\n'}, {'input': '100000 99999\n', 'expected': '9999900000\n'}], 'abc149_c': [{'input': '20\n', 'expected': '23\n'}, {'input': '2\n', 'expected': '2\n'}, {'input': '99992\n', 'expected': '100003\n'}], 'abc150_c': [{'input': '3\n1 3 2\n3 1 2\n', 'expected': '3\n'}, {'input': '8\n7 3 5 4 2 1 6 8\n3 8 2 5 4 6 7 1\n', 'expected': '17517\n'}, {'input': '3\n1 2 3\n1 2 3\n', 'expected': '0\n'}], 'abc151_c': [{'input': '2 5\n1 WA\n1 AC\n2 WA\n2 AC\n2 WA\n', 'expected': '2 2\n'}, {'input': '100000 3\n7777 AC\n7777 AC\n7777 AC\n', 'expected': '1 0\n'}, {'input': '6 0\n', 'expected': '0 0\n'}], 'abc153_c': [{'input': '3 1\n4 1 5\n', 'expected': '5\n'}, {'input': '8 9\n7 9 3 2 3 8 4 6\n', 'expected': '0\n'}, {'input': '3 0\n1000000000 1000000000 1000000000\n', 'expected': '3000000000\n'}], 'abc156_c': [{'input': '2\n1 4\n', 'expected': '5\n'}, {'input': '7\n14 14 2 13 56 2 37\n', 'expected': '2354\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
