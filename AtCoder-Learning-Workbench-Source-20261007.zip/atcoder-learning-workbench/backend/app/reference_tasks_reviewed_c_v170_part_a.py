"""Reviewed C tasks: flavor extrema, path DP and exact reveal probabilities."""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
from math import factorial
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (315,317,318,319,320,333))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc319_c':'numeric_tolerance_1e-8'}
Case=dict[str,str]
Data=tuple[object,...]
LINES=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==315:
        n=ints(rows[0],1)[0];require(2<=n<=300000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=f<=n and 2<=s<=10**9 and s%2==0 for f,s in a),'flavor scores');return (a,)
    if number==317:
        n,m=ints(rows[0],2);require(2<=n<=10 and 1<=m<=n*(n-1)//2 and len(rows)==m+1,'shape');edges=tuple(ints(row,3) for row in rows[1:]);require(all(1<=a<b<=n and 1<=c<=10**8 for a,b,c in edges) and len({(a,b) for a,b,c in edges})==m,'roads');return n,edges
    if number==318:
        require(len(rows)==2,'shape');n,d,p=ints(rows[0],3);require(1<=n<=200000 and 1<=d<=200000 and 1<=p<=10**9,'ticket');fares=ints(rows[1],n);require(all(1<=v<=10**9 for v in fares),'fares');return d,p,fares
    if number==319:
        require(len(rows)==3,'shape');a=tuple(v for row in rows for v in ints(row,3));require(all(1<=v<=9 for v in a) and all(len({a[j] for j in line})>1 for line in LINES),'board');return (a,)
    if number==320:
        m=ints(rows[0],1)[0];require(1<=m<=100 and len(rows)==4 and all(len(s)==m and re.fullmatch('[0-9]+',s) is not None for s in rows[1:]),'reels');return (tuple(rows[1:]),)
    require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=333,'rank');return (n,)
def reveal_probability(a:tuple[int,...])->Fraction:
    traps=[]
    for line in LINES:
        for x,y in combinations(line,2):
            if a[x]==a[y]:z=next(j for j in line if j not in (x,y));traps.append((x,y,z))
    dp=[0]*512;dp[0]=1
    for mask in range(511):
        if not dp[mask]:continue
        for j in range(9):
            if mask>>j&1:continue
            if any((j==x and mask>>y&1 or j==y and mask>>x&1) and not mask>>z&1 for x,y,z in traps):continue
            dp[mask|1<<j]+=dp[mask]
    return Fraction(dp[-1],factorial(9))
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==315:
        a=cast(tuple[tuple[int,int],...],data[0]);top:dict[int,tuple[int,int]]=defaultdict(lambda:(0,0))
        for flavor,score in a:
            first,second=top[flavor]
            if score>=first:top[flavor]=score,first
            elif score>second:top[flavor]=first,score
        answer=max(first+second//2 for first,second in top.values() if second) if any(second for first,second in top.values()) else 0;best=sorted(first for first,second in top.values());return str(max(answer,sum(best[-2:]) if len(best)>=2 else 0))
    if number==317:
        n,edges=cast(tuple[int,tuple[tuple[int,int,int],...]],data);graph=[[] for _ in range(n)]
        for a,b,c in edges:graph[a-1].append((b-1,c));graph[b-1].append((a-1,c))
        dp=[[-1]*n for _ in range(1<<n)]
        for j in range(n):dp[1<<j][j]=0
        answer=0
        for mask in range(1,1<<n):
            for j,distance in enumerate(dp[mask]):
                if distance<0:continue
                answer=max(answer,distance)
                for nxt,cost in graph[j]:
                    if not mask>>nxt&1:dp[mask|1<<nxt][nxt]=max(dp[mask|1<<nxt][nxt],distance+cost)
        return str(answer)
    if number==318:
        d,p,fares=cast(tuple[int,int,tuple[int,...]],data);ordered=sorted(fares);dp=[0]*(len(ordered)+1)
        for j,fare in enumerate(ordered,1):dp[j]=min(dp[j-1]+fare,dp[max(0,j-d)]+p)
        return str(dp[-1])
    if number==319:return format(float(reveal_probability(cast(tuple[int,...],data[0]))),'.17g')
    if number==320:
        reels=cast(tuple[str,...],data[0]);m=len(reels[0]);answer=3*m
        for digit in set.intersection(*(set(s) for s in reels)):
            reachable={0}
            for t in range(3*m):
                previous=tuple(reachable)
                for mask in previous:
                    for j in range(3):
                        if not mask>>j&1 and reels[j][t%m]==digit:reachable.add(mask|1<<j)
                if 7 in reachable:answer=min(answer,t);break
        return str(answer if answer<3*m else -1)
    n=cast(int,data[0]);rank=0
    for largest in range(1,13):
        for middle in range(1,largest+1):
            for smallest in range(1,middle+1):
                rank+=1
                if rank==n:return str(sum((10**width-1)//9 for width in (largest,middle,smallest)))
    raise ValueError('rank')
def numeric_value(actual:str)->Fraction:
    token=actual.removesuffix('\n');require(len(token)<=1000 and re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is not None,'finite decimal');exponent=re.split('[eE]',token);require(len(exponent)==1 or abs(int(exponent[1]))<=1000,'exponent');return Fraction(token)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc319_c':return abs(numeric_value(actual)-reveal_probability(cast(tuple[int,...],validate(pid,raw)[0])))<=Fraction(1,10**8)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError,ZeroDivisionError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc319_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc315_c':"n=int(input());a=sorted((tuple(map(int,input().split())) for _ in range(n)),key=lambda p:p[1],reverse=True);f,s=a[0];print(max(s+(t//2 if g==f else t) for g,t in a[1:]))\n",
'abc317_c':"n,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):\n a,b,c=map(int,input().split());g[a-1].append((b-1,c));g[b-1].append((a-1,c))\ndef dfs(v,seen):\n return max([0]+[cost+dfs(u,seen|1<<u) for u,cost in g[v] if not seen>>u&1])\nprint(max(dfs(j,1<<j) for j in range(n)))\n",
'abc318_c':"from itertools import accumulate\nn,d,p=map(int,input().split());a=sorted(map(int,input().split()));prefix=list(accumulate(a,initial=0));print(min(k*p+prefix[max(0,n-k*d)] for k in range((n+d-1)//d+1)))\n",
'abc319_c':"from itertools import permutations,combinations\na=[v for _ in range(3) for v in map(int,input().split())];lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6));traps=[]\nfor line in lines:\n for x,y in combinations(line,2):\n  if a[x]==a[y]:traps.append((x,y,next(z for z in line if z not in (x,y))))\ngood=0\nfor order in permutations(range(9)):\n rank=[0]*9\n for j,v in enumerate(order):rank[v]=j\n good+=not any(max(rank[x],rank[y])<rank[z] for x,y,z in traps)\nprint(good/362880)\n",
'abc320_c':"from itertools import permutations\nm=int(input());s=[input() for _ in range(3)];answer=3*m\nfor digit in '0123456789':\n for order in permutations(range(3)):\n  t=-1\n  for j in order:\n   t+=1\n   while t<3*m and s[j][t%m]!=digit:t+=1\n   if t>=3*m:break\n  else:answer=min(answer,t)\nprint(answer if answer<3*m else -1)\n",
'abc333_c':"from itertools import combinations_with_replacement\nn=int(input());r=[int('1'*length) for length in range(1,13)];values=sorted(set(sum(c) for c in combinations_with_replacement(r,3)));print(values[n-1])\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17000+number)
    if number==315:
        def flavors(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[flavors(a) for a in ([(1,2),(1,2)],[(1,2),(2,2)],[(1,10),(1,8),(2,2)],[(1,10),(1,2),(2,8)])];raws.extend(flavors([(rng.randint(1,n),2*rng.randint(1,100)) for _ in range(n)]) for n in range(3,15));raws.extend([flavors([(j+1,10**9-2*j) for j in range(300000)]),flavors([(300000,10**9)]*300000)])
    elif number==317:
        def graph(n:int,e:list[tuple[int,int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(v) for v in e)
        raws=[graph(2,[(1,2,1)]),graph(3,[(1,2,1)]),graph(3,[(1,2,10),(2,3,2)]),graph(3,[(1,2,1),(1,3,4),(2,3,2)])]
        for j in range(12):
            n=4+j%6;e=[(a,b,rng.randint(1,100)) for a,b in combinations(range(1,n+1),2) if rng.random()<.35];raws.append(graph(n,e or [(1,2,1)]))
        raws.extend([graph(10,[(a,b,a*b) for a,b in combinations(range(1,11),2)]),graph(10,[(a,b,10**8) for a,b in combinations(range(1,11),2)])])
    elif number==318:
        def fares(a:list[int],d:int,p:int)->str:return f'{len(a)} {d} {p}\n'+line(a)
        raws=[fares([1],1,1),fares([2],2,1),fares([1],200000,10**9),fares([5,5,5],2,10)];raws.extend(fares([rng.randint(1,100) for _ in range(n)],rng.randint(1,n+2),rng.randint(1,100)) for n in range(3,15));raws.extend([fares([10**9]*200000,1,10**9),fares([10**9]*200000,200000,10**9)])
    elif number==319:
        a=[1,1,2,2,2,1,1,2,1];raws=[''.join(line(a[j:j+3]) for j in (0,3,6)),''.join(line(list(range(j+1,j+4))) for j in (0,3,6))]
        while len(raws)<17:
            a=[rng.randint(1,9) for _ in range(9)]
            if any(len({a[j] for j in v})==1 for v in LINES):continue
            raw=''.join(line(a[j:j+3]) for j in (0,3,6))
            if raw not in raws:raws.append(raw)
        raws.append('9 9 8\n8 8 9\n9 8 9\n')
    elif number==320:
        def reels(s:list[str])->str:return f'{len(s[0])}\n'+'\n'.join(s)+'\n'
        raws=[reels(['0']*3),reels(['0','1','2']),reels(['01']*3),reels(['00','01','10'])];raws.extend(reels([''.join(rng.choice('0123') for _ in range(n)) for _ in range(3)]) for n in range(3,15));raws.extend([reels(['0'+'1'*99]*3),reels(['9'*100]*3)])
    else:raws=[f'{n}\n' for n in (1,2,3,4,5,6,10,19,20,35,56,84,120,165,220,286,332,333)]
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc315_c':('美味しさ最大のカップを1つ選んだ場合を考えます。','最大のカップを含む最適解が存在します。2個目を全て試し、同じ味なら半分にします。','疑似コード: 美味しさ降順にsort; 最初を(f,s)とする; 他の(g,t)についてs+(t/2 if f==g else t)の最大を出力。'),
'abc317_c':('街が最大10個なので、全ての単純経路を試せます。','開始街を全て試し、訪問済み街を記録してDFSで道を伸ばします。','疑似コード: DFS(v,seen)は未訪問隣接uへのcost+DFS(u,seen∪{u})と0の最大; 全開始vのDFSの最大を出力。'),
'abc318_c':('購入枚数を決めたら料金の高い日からパスを使います。','料金をソートして累積和を作り、購入セット数を0からceil(N/D)まで試します。','疑似コード: Fを昇順sortしprefix作成; 各kでk*P+prefix[max(0,N-k*D)]を計算; 最小を出力。'),
'abc319_c':('9マスを知る順番は9!通りで列挙できます。','各列の同じ数字の2マスが、違う数字のマスより先に両方見える順番は除外します。','疑似コード: 各9マス順列でrankを求める; 同値ペアx,yと残りzでmax(rank[x],rank[y])<rank[z]なら失敗; 成功順番数/9!を出力。'),
'abc320_c':('同じ数字と、3リールを止める順序を全て試します。','各順序で、前の停止時刻より後に数字が出る最初の時刻を選べば十分です。','疑似コード: 数字0..9と3リール順列を列挙; t=-1; 各リールでt++から一致するまで待つ; 全停止可能なら最後のtを答え候補にする。'),
'abc333_c':('必要なレピュニットは最初の12個で足ります。','3個の重複を許す組合せの和を集め、重複を除いてソートします。','疑似コード: R=[1,11,...12桁]; i<=j<=kの全組でR[i]+R[j]+R[k]を集合に追加; sortしてN-1番目を出力。')}

TITLES={'abc315_c': 'Flavors', 'abc317_c': 'Remembering the Days', 'abc318_c': 'Blue Spring', 'abc319_c': 'False Hope', 'abc320_c': 'Slot Strategy 2 (Easy)', 'abc333_c': 'Repunit Trio'}
PUBLISHED_SAMPLES={'abc315_c': [{'input': '4\n1 4\n2 10\n2 8\n3 6\n', 'expected': '16\n'}, {'input': '4\n4 10\n3 2\n2 4\n4 12\n', 'expected': '17\n'}], 'abc317_c': [{'input': '4 4\n1 2 1\n2 3 10\n1 3 100\n1 4 1000\n', 'expected': '1110\n'}, {'input': '10 1\n5 9 1\n', 'expected': '1\n'}, {'input': '10 13\n1 2 1\n1 10 1\n2 3 1\n3 4 4\n4 7 2\n4 8 1\n5 8 1\n5 9 3\n6 8 1\n6 9 5\n7 8 1\n7 9 4\n9 10 3\n', 'expected': '20\n'}], 'abc318_c': [{'input': '5 2 10\n7 1 6 3 6\n', 'expected': '20\n'}, {'input': '3 1 10\n1 2 3\n', 'expected': '6\n'}, {'input': '8 3 1000000000\n1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '3000000000\n'}], 'abc319_c': [{'input': '3 1 9\n2 5 6\n2 7 1\n', 'expected': '0.666666666666666666666666666667\n'}, {'input': '7 7 6\n8 6 8\n7 7 6\n', 'expected': '0.004982363315696649029982363316\n'}, {'input': '3 6 7\n1 9 7\n5 7 5\n', 'expected': '0.4\n'}], 'abc320_c': [{'input': '10\n1937458062\n8124690357\n2385760149\n', 'expected': '6\n'}, {'input': '20\n01234567890123456789\n01234567890123456789\n01234567890123456789\n', 'expected': '20\n'}, {'input': '5\n11111\n22222\n33333\n', 'expected': '-1\n'}], 'abc333_c': [{'input': '5\n', 'expected': '113\n'}, {'input': '19\n', 'expected': '2333\n'}, {'input': '333\n', 'expected': '112222222233\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
