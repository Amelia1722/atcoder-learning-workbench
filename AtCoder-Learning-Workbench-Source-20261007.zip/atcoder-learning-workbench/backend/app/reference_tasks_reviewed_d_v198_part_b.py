from __future__ import annotations
from collections import deque
from bisect import bisect_left,bisect_right
from typing import cast
import re,random
TASKS=tuple(f'abc{i}_d' for i in range(359,365));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
MOD=998244353

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:tuple[int,...]|list[int])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc359_d':
  n,k=ints(rows[0],2);require(2<=k<=min(n,10) and n<=1000 and len(rows)==2 and re.fullmatch('[AB?]{'+str(n)+'}',rows[1]) is not None,'domain');return k,rows[1]
 if pid=='abc360_d':
  n,t=ints(rows[0],2);require(2<=n<=200000 and 1<=t<=10**9 and len(rows)==3 and re.fullmatch('[01]{'+str(n)+'}',rows[1]) is not None,'domain');x=ints(rows[2],n);require(len(set(x))==n and all(-10**9<=v<=10**9 for v in x),'Xi');return t,rows[1],x
 if pid=='abc361_d':
  n=ints(rows[0],1)[0];require(2<=n<=14 and len(rows)==3 and all(re.fullmatch('[BW]{'+str(n)+'}',s) is not None for s in rows[1:]),'domain');return rows[1],rows[2]
 if pid=='abc362_d':
  n,m=ints(rows[0],2);require(2<=n<=200000 and n-1<=m<=200000 and len(rows)==m+2,'shape');a=ints(rows[1],n);edges=tuple(ints(r,3) for r in rows[2:]);require(all(0<=v<=10**9 for v in a) and all(1<=u<v<=n and 0<=b<=10**9 for u,v,b in edges) and len({(u,v) for u,v,b in edges})==m,'weights/edges');parent=list(range(n))
  def root(v:int)->int:
   while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
   return v
  for u,v,b in edges:parent[root(u-1)]=root(v-1)
  require(len({root(i) for i in range(n)})==1,'connected');return a,edges
 if pid=='abc363_d':require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**18,'N');return (n,)
 n,q=ints(rows[0],2);require(1<=n<=100000 and 1<=q<=100000 and len(rows)==q+2,'shape');a=ints(rows[1],n);queries=tuple(ints(r,2) for r in rows[2:]);require(all(-10**8<=v<=10**8 for v in a) and all(-10**8<=b<=10**8 and 1<=k<=n for b,k in queries),'range');return a,queries

def avoid_palindrome_automaton(k:int,s:str)->int:
 children:list[list[int]]=[[-1,-1]];failure=[0];bad=[False]
 for prefix in range(1<<((k+1)//2)):
  bits=f'{prefix:0{(k+1)//2}b}';word=bits+bits[:k//2][::-1];node=0
  for char in word:
   bit=int(char)
   if children[node][bit]<0:children[node][bit]=len(children);children.append([-1,-1]);failure.append(0);bad.append(False)
   node=children[node][bit]
  bad[node]=True
 queue=deque()
 for bit in range(2):
  child=children[0][bit]
  if child<0:children[0][bit]=0
  else:queue.append(child)
 while queue:
  node=queue.popleft();bad[node]|=bad[failure[node]]
  for bit in range(2):
   child=children[node][bit]
   if child<0:children[node][bit]=children[failure[node]][bit]
   else:failure[child]=children[failure[node]][bit];queue.append(child)
 dp=[0]*len(children);dp[0]=1
 for char in s:
  nxt=[0]*len(children);allowed=(0,1) if char=='?' else (int(char=='B'),)
  for node,count in enumerate(dp):
   if not count:continue
   for bit in allowed:
    target=children[node][bit]
    if not bad[target]:nxt[target]=(nxt[target]+count)%MOD
  dp=nxt
 return sum(dp)%MOD

def ant_trajectory_inversions(t:int,s:str,x:tuple[int,...])->int:
 trajectories=sorted((v,10*v+(10*t+1)*(1 if direction=='1' else -1)) for v,direction in zip(x,s));ends={value:i+1 for i,value in enumerate(sorted(end for _,end in trajectories))};tree=[0]*(len(x)+1);answer=0
 for previous,(_,end) in enumerate(trajectories):
  index=ends[end];at=index;less=0
  while at:less+=tree[at];at-=at&-at
  answer+=previous-less
  while index<len(tree):tree[index]+=1;index+=index&-index
 return answer

def stones_bidirectional(s:str,t:str)->int:
 if s.count('B')!=t.count('B'):return -1
 n=len(s);start=(sum((char=='B')<<i for i,char in enumerate(s)),n);goal=(sum((char=='B')<<i for i,char in enumerate(t)),n)
 if start==goal:return 0
 forward={start:0};backward={goal:0};front={start};back={goal}
 while front and back:
  if len(front)>len(back):front,back=back,front;forward,backward=backward,forward
  nxt=set()
  for mask,empty in front:
   depth=forward[mask,empty]
   for at in range(n+1):
    if abs(at-empty)<=1:continue
    bits=(mask>>at)&3;changed=(mask&~(3<<at))|(bits<<empty);state=(changed,at)
    if state in forward:continue
    if state in backward:return depth+1+backward[state]
    forward[state]=depth+1;nxt.add(state)
  front=nxt
 return -1

class RadixQueue:
 def __init__(self)->None:self.last=0;self.buckets:list[list[tuple[int,int]]]=[[] for _ in range(64)];self.size=0
 def push(self,key:int,value:int)->None:
  assert key>=self.last;self.buckets[(key^self.last).bit_length()].append((key,value));self.size+=1
 def pop(self)->tuple[int,int]:
  if not self.buckets[0]:
   index=next(i for i,bucket in enumerate(self.buckets) if bucket);self.last=min(key for key,_ in self.buckets[index]);old=self.buckets[index];self.buckets[index]=[]
   for key,value in old:self.buckets[(key^self.last).bit_length()].append((key,value))
  self.size-=1;return self.buckets[0].pop()

def weighted_symmetric_radix(a:tuple[int,...],edges:tuple[tuple[int,...],...])->list[int]:
 n=len(a);graph:list[list[tuple[int,int]]]=[[] for _ in a]
 for u,v,b in edges:u-=1;v-=1;cost=2*b+a[u]+a[v];graph[u].append((v,cost));graph[v].append((u,cost))
 inf=10**30;distance=[inf]*n;distance[0]=0;queue=RadixQueue();queue.push(0,0)
 while queue.size:
  dist,u=queue.pop()
  if dist!=distance[u]:continue
  for v,cost in graph[u]:
   nd=dist+cost
   if nd<distance[v]:distance[v]=nd;queue.push(nd,v)
 return [(distance[i]+a[0]+a[i])//2 for i in range(1,n)]

def palindrome_count(value:int)->int:
 digits=str(value);length=len(digits);answer=1
 for size in range(1,length):answer+=9*10**((size-1)//2)
 half=(length+1)//2;prefix=int(digits[:half]);minimum=10**(half-1);answer+=max(0,prefix-minimum);text=str(prefix);mirrored=int(text+text[:length//2][::-1]);answer+=int(prefix>=minimum and mirrored<=value)
 return answer

def palindrome_rank_search(n:int)->str:
 if n==1:return '0'
 low=0;high=10**36
 while high-low>1:
  mid=(high+low)//2
  if palindrome_count(mid)>=n:high=mid
  else:low=mid
 return str(high)

def nearest_partition(a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 values=sorted(a);n=len(a);answer=[];inf=10**30
 for b,k in queries:
  middle=bisect_left(values,b);leftsize=middle;rightsize=n-middle;lo=max(0,k-rightsize);hi=min(k,leftsize)
  while lo<=hi:
   i=(lo+hi)//2;j=k-i;ll=b-values[middle-i] if i else -1;lr=b-values[middle-i-1] if i<leftsize else inf;rl=values[middle+j-1]-b if j else -1;rr=values[middle+j]-b if j<rightsize else inf
   if ll>rr:hi=i-1
   elif rl>lr:lo=i+1
   else:answer.append(max(ll,rl));break
  else:raise AssertionError('partition')
 return answer

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc359_d':return str(avoid_palindrome_automaton(cast(int,d[0]),cast(str,d[1])))+'\n'
 if pid=='abc360_d':return str(ant_trajectory_inversions(cast(int,d[0]),cast(str,d[1]),cast(tuple[int,...],d[2])))+'\n'
 if pid=='abc361_d':return str(stones_bidirectional(cast(str,d[0]),cast(str,d[1])))+'\n'
 if pid=='abc362_d':return line(weighted_symmetric_radix(cast(tuple[int,...],d[0]),cast(tuple[tuple[int,...],...],d[1])))
 if pid=='abc363_d':return palindrome_rank_search(cast(int,d[0]))+'\n'
 return ''.join(str(v)+'\n' for v in nearest_partition(cast(tuple[int,...],d[0]),cast(tuple[tuple[int,...],...],d[1])))
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE:dict[str,str]={
'abc359_d':'''n,k=map(int,input().split());s=input();mask=(1<<(k-1))-1;bad={i for i in range(1<<k) if f'{i:0{k}b}'==f'{i:0{k}b}'[::-1]};dp={0:1};mod=998244353
for i,c in enumerate(s):
 nxt={}
 for state,count in dp.items():
  for bit in ((0,1) if c=='?' else (int(c=='B'),)):
   v=(state<<1)|bit
   if i>=k-1 and v in bad:continue
   key=v&mask;nxt[key]=(nxt.get(key,0)+count)%mod
 dp=nxt
print(sum(dp.values())%mod)
''',
'abc360_d':'''from bisect import bisect_left,bisect_right
n,t=map(int,input().split());s=input();x=list(map(int,input().split()));left=sorted(v for v,c in zip(x,s) if c=='0');ans=0
for v,c in zip(x,s):
 if c=='1':ans+=bisect_right(left,v+2*t)-bisect_left(left,v)
print(ans)
''',
'abc361_d':'''from collections import deque
n=int(input());s=input()+'..';t=input()+'..'
if s.count('B')!=t.count('B'):print(-1)
else:
 distance={s:0};q=deque([s]);answer=-1
 while q:
  state=q.popleft();d=distance[state]
  if state==t:answer=d;break
  empty=state.index('.')
  for i in range(n+1):
   if '.' in state[i:i+2]:continue
   a=list(state);a[empty:empty+2]=state[i:i+2];a[i:i+2]='..';nxt=''.join(a)
   if nxt not in distance:distance[nxt]=d+1;q.append(nxt)
 print(answer)
''',
'abc362_d':'''import heapq,sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);a=[next(it) for _ in range(n)];g=[[] for _ in range(n)]
for _ in range(m):u=next(it)-1;v=next(it)-1;b=next(it);g[u].append((v,b));g[v].append((u,b))
inf=10**30;dist=[inf]*n;dist[0]=a[0];heap=[(a[0],0)]
while heap:
 d,u=heapq.heappop(heap)
 if d!=dist[u]:continue
 for v,b in g[u]:
  nd=d+b+a[v]
  if nd<dist[v]:dist[v]=nd;heapq.heappush(heap,(nd,v))
print(*dist[1:])
''',
'abc363_d':'''n=int(input())
if n==1:print(0)
else:
 rank=n-2;length=1
 while rank>=9*10**((length-1)//2):rank-=9*10**((length-1)//2);length+=1
 half=(length+1)//2;prefix=str(10**(half-1)+rank)
 print(prefix+prefix[:length//2][::-1])
''',
'abc364_d':'''from bisect import bisect_left,bisect_right
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);q=next(it);a=sorted(next(it) for _ in range(n));out=[]
for _ in range(q):
 b=next(it);k=next(it);lo=-1;hi=200000000
 while hi-lo>1:
  mid=(lo+hi)//2
  if bisect_right(a,b+mid)-bisect_left(a,b-mid)>=k:hi=mid
  else:lo=mid
 out.append(str(hi))
print('\\n'.join(out))
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(198000+TASKS.index(pid));raws=[]
 if pid=='abc359_d':
  configs=[(2,'AA'),(2,'AB'),(2,'??'),(3,'???'),(3,'ABA'),(3,'ABB'),(4,'ABBA'),(4,'????'),(5,'ABABA'),(2,'?'*1000),(9,'?'*1000),(10,'A'*1000)]
  for n in (11,12,17,30,100):configs.append((min(10,n-1),''.join(rng.choice('AB?') for _ in range(n))))
  configs.append((10,'?'*1000));raws=[line((len(s),k))+s+'\n' for k,s in configs]
 elif pid=='abc360_d':
  configs=[(1,'00',(-10**9,-10**9+1)),(1,'10',(0,2)),(1,'10',(0,3)),(1,'01',(0,1)),(1,'10',(1,-1)),(10**9,'10',(-10**9,10**9)),(10**9,'01',(-10**9,10**9))]
  for n in (3,4,5,6,10,17,100,1000,5000):configs.append((rng.randint(1,10**9),''.join(rng.choice('01') for _ in range(n)),tuple(rng.sample(range(-10**9,10**9+1),n))))
  configs += [(10**9,'0'*200000,tuple(range(-10**9,-10**9+200000))),(10**9,'1'*100000+'0'*100000,tuple(range(-10**9,-10**9+100000))+tuple(range(10**9-99999,10**9+1)))]
  raws=[line((len(x),t))+s+'\n'+line(x) for t,s,x in configs]
 elif pid=='abc361_d':
  pairs=[('BB','BB'),('BB','WW'),('BW','WB'),('BBW','WBB'),('BWB','BBW'),('BWBW','WWBB'),('BBWW','WWBB'),('BW'*3,'W'*3+'B'*3),('B'*7+'W'*7,'W'*7+'B'*7),('B'*14,'W'*14)]
  for n in (5,6,7,8,9,10,11):
   s=''.join(rng.choice('BW') for _ in range(n));characters=list(s);rng.shuffle(characters);pairs.append((s,''.join(characters)))
  pairs.append(('BW'*7,'WB'*7));raws=[line((len(s),))+s+'\n'+t+'\n' for s,t in pairs]
 elif pid=='abc362_d':
  configs=[((0,0),((1,2,0),)),((10**9,10**9),((1,2,10**9),)),((0,0,0),((1,2,0),(2,3,0),(1,3,1))),((1,100,1),((1,2,0),(2,3,0),(1,3,2)))]
  for n in range(4,16):
   edges={(i,i+1):rng.randint(0,10**9) for i in range(1,n)}
   for _ in range(n):u,v=sorted(rng.sample(range(1,n+1),2));edges[u,v]=rng.randint(0,10**9)
   configs.append((tuple(rng.randint(0,10**9) for _ in range(n)),tuple((u,v,b) for (u,v),b in edges.items())))
  configs += [((0,)*200000,tuple((1,i,0) for i in range(2,200001))),((10**9,)*200000,tuple((i,i+1,10**9) for i in range(1,200000))+((1,200000,10**9),))]
  raws=[line((len(a),len(edges)))+line(a)+''.join(line(e) for e in edges) for a,edges in configs]
 elif pid=='abc363_d':
  numbers=[1,2,10,11,19,20,100,109,110,199,200,1000,1099,1100,10**9,10**15,10**18-1,10**18];raws=[line((n,)) for n in numbers]
 else:
  configs=[((0,),((0,1),)),((0,0),((0,1),(0,2))),((-10**8,10**8),((0,1),(0,2))),((-10**8,),((10**8,1),)),((0,1,1,2),((1,1),(1,2),(1,3),(1,4))),((1,2,3),((-10**8,3),(10**8,3)))]
  for n in (4,5,6,7,8,10,17,100,1000,10000):configs.append((tuple(rng.randint(-10**8,10**8) for _ in range(n)),tuple((rng.randint(-10**8,10**8),rng.randint(1,n)) for _ in range(n))))
  configs += [((0,)*100000,tuple(((-1)**i*10**8,i+1) for i in range(100000))),(tuple(range(-10**8,-10**8+50000))+tuple(range(10**8-49999,10**8+1)),tuple(((-1)**i*10**8,i+1) for i in range(100000)))]
  raws=[line((len(a),len(q)))+line(a)+''.join(line(query) for query in q) for a,q in configs]
 require(len(raws)==len(set(raws))==18,'18distinct');result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result
HINTS:dict[str,tuple[str,str,str]]={
'abc359_d':('新しい文字でできる回文は、末尾の長さKの部分文字列だけです。','直近K-1文字をビットで状態にして、?の2通りを試します。長さKになった時点で回文の遷移を捨てます。','疑似コード: dp[0]=1; 各文字について許されるbitを列挙; v=(state<<1)|bit; K文字そろいvが回文なら除外; next[v&((1<<(K-1))-1)]+=dp[state]; 998244353で剰余を取り最後の状態数を合計。'),
'abc360_d':('すれ違うのは、右向きの蟻の右側に左向きの蟻がいる組です。','相対速度は2なので、初期距離が2T以下ならすれ違います。座標が整数なので時刻T+0.1までという条件でも同じです。','疑似コード: 左向き蟻の座標をsort; 各右向き座標xについて、二分探索で x<y<=x+2T の左向き蟻を数える; 全右向き蟻の結果を合計。'),
'abc361_d':('盤面そのものを状態として、操作1回の遷移を作ります。','状態数は小さいのでBFSで最小回数を調べられます。空きマスと重なる2個の石は選べません。','疑似コード: SとTの末尾に..を追加; queueへS、distance[S]=0; 状態の空き位置を求め、石2個がある各隣接箇所を空き位置へ順序を保って移す; 未訪問ならdistance+1で追加; Tへの距離、未到達なら-1。'),
'abc362_d':('頂点に入るたびに、その頂点の重みも払うと考えます。','辺u→vの費用をB+A[v]にしてDijkstra法を使います。始点の重みA[1]も初期距離に含めます。','疑似コード: dist[1]=A[1],他はINF; minheapへ(dist[1],1); 最小距離を取り出し、各辺(u,v,B)で next=dist[u]+B+A[v]; 改善なら距離更新しheap追加; dist[2..N]を出力。'),
'abc363_d':('回文数は前半の桁を決めるだけで一意に決まります。','0を先頭の1個として除き、桁数ごとの個数9×10^floor((L-1)/2)を引いて目的の桁数を決めます。','疑似コード: N=1なら0; rank=N-2; L=1から、その桁数の個数をrankから引ける間L++; 前半=10^(ceil(L/2)-1)+rank; 偶数桁なら前半全体、奇数桁なら末尾を除いた前半を反転して連結。'),
'abc364_d':('答えの距離d以下に、何個のAの点があるかを調べます。','Aの座標をソートすると、区間[b-d,b+d]に入る点数を二分探索2回で数えられます。重複座標もそれぞれ数えます。','疑似コード: Aをsort; 各(b,k)でlo=-1,hi=200000000; mid=(lo+hi)//2; upper_bound(b+mid)-lower_bound(b-mid)>=kならhi=mid、他はlo=mid; 境界が隣接したらhiを出力。')}

TITLES={'abc359_d': 'Avoid K Palindrome', 'abc360_d': 'Ghost Ants', 'abc361_d': 'Go Stone Puzzle', 'abc362_d': 'Shortest Path 3', 'abc363_d': 'Palindromic Number', 'abc364_d': 'K-th Nearest'}
PUBLISHED_SAMPLES={'abc359_d': [{'input': '7 4\nAB?A?BA\n', 'expected': '1\n'}, {'input': '40 7\n????????????????????????????????????????\n', 'expected': '116295436\n'}, {'input': '15 5\nABABA??????????\n', 'expected': '0\n'}, {'input': '40 8\n?A?B??B?B?AA?A?B??B?A???B?BB?B???BA??BAA\n', 'expected': '259240\n'}], 'abc360_d': [{'input': '6 3\n101010\n-5 -1 0 1 2 4\n', 'expected': '5\n'}, {'input': '13 656320850\n0100110011101\n-900549713 -713494784 -713078652 -687818593 -517374932 -498415009 -472742091 -390030458 -379340552 -237481538 -44636942 352721061 695864366\n', 'expected': '14\n'}], 'abc361_d': [{'input': '6\nBWBWBW\nWWWBBB\n', 'expected': '4\n'}, {'input': '6\nBBBBBB\nWWWWWW\n', 'expected': '-1\n'}, {'input': '14\nBBBWBWWWBBWWBW\nWBWWBBWWWBWBBB\n', 'expected': '7\n'}], 'abc362_d': [{'input': '3 3\n1 2 3\n1 2 1\n1 3 6\n2 3 2\n', 'expected': '4 9\n'}, {'input': '2 1\n0 1\n1 2 3\n', 'expected': '4\n'}, {'input': '5 8\n928448202 994752369 906965437 942744902 907560126\n2 5 975090662\n1 2 908843627\n1 5 969061140\n3 4 964249326\n2 3 957690728\n2 4 942986477\n4 5 948404113\n1 3 988716403\n', 'expected': '2832044198 2824130042 4696218483 2805069468\n'}], 'abc363_d': [{'input': '46\n', 'expected': '363\n'}, {'input': '1\n', 'expected': '0\n'}, {'input': '1000000000000000000\n', 'expected': '90000000000000000000000000000000009\n'}], 'abc364_d': [{'input': '4 3\n-3 -1 5 6\n-2 3\n2 1\n10 4\n', 'expected': '7\n3\n13\n'}, {'input': '2 2\n0 0\n0 1\n0 2\n', 'expected': '0\n0\n'}, {'input': '10 5\n-84 -60 -41 -100 8 -8 -52 -62 -61 -76\n-52 5\n14 4\n-2 6\n46 2\n26 7\n', 'expected': '11\n66\n59\n54\n88\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
