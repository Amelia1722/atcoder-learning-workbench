"""Turn 132: reviewed ABC008--025 C, independent algorithms and strict inputs."""
from __future__ import annotations
from collections import Counter, deque
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from functools import lru_cache
from heapq import heappop, heappush
from itertools import combinations, permutations, product
from math import factorial
import random
import re
from typing import cast

TASKS=tuple(f'abc{i:03}_3' if i<=19 else f'abc{i:03}_c' for i in range(8,26))
LANES={chr(65+i):TASKS[i*3:i*3+3] for i in range(6)}
OUTPUT_MODES={'abc008_3':'numeric_tolerance_1e-6'}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
Edges=tuple[Pair,...]
Weighted=tuple[tuple[int,int,int],...]

def require(condition: bool, label: str) -> None:
    if not condition:raise ValueError(label)

def ints(line: str,count: int | None=None) -> tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',line) is not None,'integers')
    values=tuple(map(int,line.split(' ')))
    require(count is None or len(values)==count,'field count')
    return values

def connected(n: int,edges: Edges) -> bool:
    graph=[[] for _ in range(n)]
    for u,v in edges:graph[u-1].append(v-1);graph[v-1].append(u-1)
    seen={0};pending=[0]
    while pending:
        for v in graph[pending.pop()]:
            if v not in seen:seen.add(v);pending.append(v)
    return len(seen)==n

def migration(days: Edges,queries: Edges) -> tuple[int,...]:
    results=[]
    for start,goal in queries:
        low=high=start
        for day,(left,right) in enumerate(days,1):
            if left<=high and low<=right:low=min(low,left);high=max(high,right)
            if low<=goal<=high:results.append(day);break
        else:results.append(-1)
    return tuple(results)

def validate(pid: str,raw: str) -> Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'pid/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank line')
    number=int(pid[3:6])
    if number==8:
        n,=ints(rows[0],1);a=tuple(ints(r,1)[0] for r in rows[1:])
        require(1<=n<=100 and len(a)==n and all(1<=v<=10**9 for v in a),'coins');return n,a
    if number==9:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);s=rows[1]
        require(1<=n<=100 and 0<=k<=n and len(s)==n and re.fullmatch('[a-z]+',s) is not None,'string');return n,k,s
    if number==10:
        require(len(rows)>=2,'shape');a,b,c,d,t,v=ints(rows[0],6);n,=ints(rows[1],1);points=tuple(ints(r,2) for r in rows[2:])
        require(all(0<=x<=1000 for x in (a,b,c,d)) and 1<=t<=50 and 1<=v<=100 and 1<=n<=1000 and len(points)==n,'movement')
        require(all(0<=x<=1000 for p in points for x in p) and (a-c)**2+(b-d)**2<=(t*v)**2,'coordinates/straight reachability')
        return a,b,c,d,t,v,points
    if number==11:
        require(len(rows)==4,'shape');n,=ints(rows[0],1);ng=tuple(ints(r,1)[0] for r in rows[1:]);require(1<=n<=300 and all(1<=x<=300 for x in ng),'NG');return n,ng
    if number==12:
        require(len(rows)==1,'shape');n,=ints(rows[0],1);require(1944<=n<=2024 and any(x*y==2025-n for x in range(1,10) for y in range(1,10)),'solvable sum');return (n,)
    if number==13:
        require(len(rows)==2,'shape');n,h=ints(rows[0],2);a,b,c,d,e=ints(rows[1],5)
        require(1<=n<=500000 and 1<=h<=10**9 and 1<=c<a<=10**6 and 1<=d<b<=10**6 and 1<=e<=10**6,'diet');return n,h,a,b,c,d,e
    if number==14:
        n,=ints(rows[0],1);intervals=tuple(ints(r,2) for r in rows[1:]);require(1<=n<=100000 and len(intervals)==n and all(0<=a<=b<=1000000 for a,b in intervals),'intervals');return n,intervals
    if number==15:
        n,k=ints(rows[0],2);matrix=tuple(ints(r,k) for r in rows[1:]);require(1<=n<=5 and 1<=k<=5 and len(matrix)==n and all(0<=x<=127 for row in matrix for x in row),'xor');return n,k,matrix
    if number==16:
        n,m=ints(rows[0],2);edges=tuple(ints(r,2) for r in rows[1:]);require(1<=n<=10 and 0<=m<=n*(n-1)//2 and len(edges)==m and len(set(edges))==m and all(1<=u<v<=n for u,v in edges),'friends');return n,edges
    if number==17:
        n,m=ints(rows[0],2);intervals=tuple(ints(r,3) for r in rows[1:]);require(1<=n<=100000 and 1<=m<=100000 and len(intervals)==n and all(1<=l<=r<=m and 1<=s<=5000 for l,r,s in intervals),'ruins');return n,m,intervals
    if number==18:
        r,c,k=ints(rows[0],3);grid=tuple(rows[1:]);require(3<=r<=500 and 3<=c<=500 and 2<=k<=500 and len(grid)==r and all(len(s)==c and set(s)<=set('ox') for s in grid),'diamond');return r,c,k,grid
    if number==19:
        require(len(rows)==2,'shape');n,=ints(rows[0],1);a=ints(rows[1],n);require(1<=n<=100000 and len(set(a))==n and all(1<=x<=10**9 for x in a),'distinct box inputs');return n,a
    if number==20:
        r,c,t=ints(rows[0],3);grid=tuple(rows[1:]);require(2<=r<=10 and 2<=c<=10 and 2<=t<=10**9 and len(grid)==r and all(len(s)==c and set(s)<=set('.#SG') for s in grid),'wall grid')
        require(sum(s.count('S') for s in grid)==sum(s.count('G') for s in grid)==1,'one endpoint each')
        start=next((y,x) for y in range(r) for x in range(c) if grid[y][x]=='S');goal=next((y,x) for y in range(r) for x in range(c) if grid[y][x]=='G')
        require(abs(start[0]-goal[0])+abs(start[1]-goal[1])<=t,'x=1 feasibility')
        seen={start};queue=[start]
        while queue:
            y,x=queue.pop()
            for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
                p=y+dy,x+dx
                if 0<=p[0]<r and 0<=p[1]<c and p not in seen and grid[p[0]][p[1]]!='#':seen.add(p);queue.append(p)
        require(goal not in seen,'at least one wall required');return r,c,t,grid
    if number==21:
        require(len(rows)>=3,'shape');n,=ints(rows[0],1);a,b=ints(rows[1],2);m,=ints(rows[2],1);edges=tuple(ints(s,2) for s in rows[3:])
        require(2<=n<=100 and 1<=a<=n and 1<=b<=n and a!=b and 1<=m<=200 and len(edges)==m and all(1<=u<=n and 1<=v<=n and u!=v for u,v in edges),'shortest paths')
        # The published statement does not guarantee distinct roads; retain multiplicity.
        require(connected(n,cast(Edges,edges)),'connected towns');return n,a,b,edges
    if number==22:
        n,m=ints(rows[0],2);edges=tuple(ints(s,3) for s in rows[1:]);require(3<=n<=300 and 3<=m<=n*(n-1)//2 and len(edges)==m and len({(u,v) for u,v,w in edges})==m and all(1<=u<v<=n and 1<=w<=10**5 for u,v,w in edges),'weighted simple graph');return n,edges
    if number==23:
        require(len(rows)>=2,'shape');r,c,k=ints(rows[0],3);n,=ints(rows[1],1);points=tuple(ints(s,2) for s in rows[2:]);require(1<=r<=100000 and 1<=c<=100000 and 1<=k<=n<=100000 and len(points)==len(set(points))==n and all(1<=y<=r and 1<=x<=c for y,x in points),'candies');return r,c,k,points
    if number==24:
        n,d,k=ints(rows[0],3);require(1<=n<=10**9 and 1<=d<=10000 and 1<=k<=100 and len(rows)==1+d+k,'migration size')
        days=tuple(ints(s,2) for s in rows[1:1+d]);queries=tuple(ints(s,2) for s in rows[1+d:]);require(all(1<=l<=r<=n for l,r in days) and all(1<=s<=n and 1<=t<=n and s!=t for s,t in queries),'migration ranges')
        require(all(day>0 for day in migration(cast(Edges,days),cast(Edges,queries))),'guaranteed arrival');return n,days,queries
    require(len(rows)==5,'game shape');matrix=tuple(ints(s,3 if i<2 else 2) for i,s in enumerate(rows));require(all(0<=x<=100 for row in matrix for x in row),'game points');return (matrix,)

def _lex_oracle(s: str,k: int) -> str:
    if len(s)<=8:
        return min(''.join(p) for p in set(permutations(s)) if sum(a!=b for a,b in zip(p,s))<=k)
    # Lexical branch-and-bound with explicit maximum bipartite matching of equal
    # letters; reference instead uses histogram deficit arithmetic.
    remaining=list(s);answer='';used=0
    for i in range(len(s)):
        for candidate in sorted(set(remaining)):
            trial=remaining.copy();trial.remove(candidate);suffix=s[i+1:]
            match:dict[int,int]={}
            def augment(pos: int,seen: set[int]) -> bool:
                for j,ch in enumerate(trial):
                    if ch==suffix[pos] and j not in seen:
                        seen.add(j)
                        if j not in match or augment(match[j],seen):match[j]=pos;return True
                return False
            matches=sum(augment(pos,set()) for pos in range(len(suffix)))
            changed=used+(candidate!=s[i])
            if changed+len(suffix)-matches<=k:
                answer+=candidate;remaining=trial;used=changed;break
        else:raise AssertionError('lex search infeasible')
    return answer

def _diamond_oracle(r: int,c: int,k: int,grid: tuple[str,...]) -> int:
    dist=[[r+c]*c for _ in range(r)];queue:deque[Pair]=deque()
    for y in range(r):
        for x in range(c):
            if grid[y][x]=='x':dist[y][x]=0;queue.append((y,x))
    while queue:
        y,x=queue.popleft()
        for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
            yy,xx=y+dy,x+dx
            if 0<=yy<r and 0<=xx<c and dist[yy][xx]>dist[y][x]+1:dist[yy][xx]=dist[y][x]+1;queue.append((yy,xx))
    return sum(dist[y][x]>=k for y in range(k-1,r-k+1) for x in range(k-1,c-k+1))

def _wall_oracle(r: int,c: int,t: int,grid: tuple[str,...]) -> int:
    start=next(y*c+x for y in range(r) for x in range(c) if grid[y][x]=='S');goal=next(y*c+x for y in range(r) for x in range(c) if grid[y][x]=='G')
    limit=r*c;best=[[10**9]*limit for _ in range(limit)];best[start][0]=0;heap=[(0,start,0)]
    while heap:
        white,v,walls=heappop(heap)
        if white!=best[v][walls]:continue
        y,x=divmod(v,c)
        for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
            yy,xx=y+dy,x+dx
            if not(0<=yy<r and 0<=xx<c):continue
            black=grid[yy][xx]=='#';bb=walls+black;ww=white+(not black);u=yy*c+xx
            if bb<limit and ww<best[u][bb]:best[u][bb]=ww;heappush(heap,(ww,u,bb))
    return max((t-white)//walls for walls,white in enumerate(best[goal]) if walls and t>=white+walls)

def _game_oracle(matrix: tuple[tuple[int,...],...]) -> tuple[int,int]:
    edges=[(i*3+j,(i+1)*3+j,matrix[i][j]) for i in range(2) for j in range(3)]+[(i*3+j,i*3+j+1,matrix[i+2][j]) for i in range(3) for j in range(2)]
    # Bottom-up occupied-mask DP, independently of recursive ternary-board minimax.
    values:dict[tuple[int,int],int]={}
    for first in combinations(range(9),5):
        a=sum(1<<i for i in first);b=511^a
        values[a,b]=sum(w for u,v,w in edges if bool(a&(1<<u))==bool(a&(1<<v)))
    for count in range(8,-1,-1):
        for cells in combinations(range(9),count):
            occupied=sum(1<<i for i in cells)
            for first in combinations(cells,(count+1)//2):
                a=sum(1<<i for i in first);b=occupied^a
                children=[values[a|(1<<i),b] if count%2==0 else values[a,b|(1<<i)] for i in range(9) if not occupied&(1<<i)]
                values[a,b]=max(children) if count%2==0 else min(children)
    score=values[0,0];return score,sum(w for u,v,w in edges)-score

@lru_cache(maxsize=512)
def oracle(pid: str,raw: str) -> str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==8:
        n,a=cast(tuple[int,tuple[int,...]],data)
        if n<=7:
            total=0
            for order in permutations(range(n)):
                faces=[True]*n
                for i,coin in enumerate(order):
                    for later in order[i+1:]:
                        if a[later]%a[coin]==0:faces[later]=not faces[later]
                total+=sum(faces)
            return str(float(Fraction(total,factorial(n))))
        # For each coin, integrate parity over its uniform relative rank among
        # all divisors, using exact rational arithmetic rather than the shortcut.
        result=Fraction(0)
        for i,v in enumerate(a):
            count=sum(i!=j and v%w==0 for j,w in enumerate(a))
            result+=sum((Fraction(1,count+1) for rank in range(count+1) if rank%2==0),Fraction(0))
        return str(float(result))
    if number==9:
        n,k,s=cast(tuple[int,int,str],data);return _lex_oracle(s,k)
    if number==10:
        a,b,c,d,t,v,points=cast(tuple[int,int,int,int,int,int,Edges],data);length=t*v
        for x,y in points:
            p=(x-a)**2+(y-b)**2;q=(x-c)**2+(y-d)**2;rest=length*length-p-q
            # sqrt(p)+sqrt(q)<=L, exactly in integers (no epsilon).
            if rest>=0 and rest*rest>=4*p*q:return 'YES'
        return 'NO'
    if number==11:
        n,ng=cast(tuple[int,tuple[int,...]],data)
        if n in ng:return 'NO'
        queue=deque([(n,0)]);seen={n}
        while queue:
            v,depth=queue.popleft()
            if v==0:return 'YES'
            if depth==100:continue
            for step in (1,2,3):
                u=v-step
                if u>=0 and u not in ng and u not in seen:seen.add(u);queue.append((u,depth+1))
        return 'NO'
    if number==12:
        n,=cast(tuple[int],data);target=2025-n
        return '\n'.join(f'{i} x {target//i}' for i in range(1,10) if target%i==0 and 1<=target//i<=9)
    if number==13:
        n,h,a,b,c,d,e=cast(tuple[int,int,int,int,int,int,int],data)
        if n<=7:
            best=n*a
            for days in product((0,1,2),repeat=n):
                health=h;cost=0
                for meal in days:
                    health+=b if meal==0 else d if meal==1 else -e;cost+=a if meal==0 else c if meal==1 else 0
                    if health<=0:break
                else:best=min(best,cost)
            return str(best)
        # Enumerate cheap meals; binary-search required expensive meals with the
        # strict positive-health condition. Reference enumerates expensive meals
        # and directly divides for cheap meals.
        best=n*a
        for cheap in range(n+1):
            lo,hi=0,n-cheap
            if h+hi*b+cheap*d<=e*(n-hi-cheap):continue
            while lo<hi:
                mid=(lo+hi)//2
                if h+mid*b+cheap*d>e*(n-mid-cheap):hi=mid
                else:lo=mid+1
            best=min(best,lo*a+cheap*c)
        return str(best)
    if number==14:
        n,intervals=cast(tuple[int,Edges],data);ends=sorted(b for a,b in intervals);starts=sorted(a for a,b in intervals);j=0;best=0
        for i,start in enumerate(starts):
            while j<n and ends[j]<start:j+=1
            best=max(best,i+1-j)
        return str(best)
    if number==15:
        n,k,matrix=cast(tuple[int,int,tuple[tuple[int,...],...]],data)
        for answer in product(*matrix):
            value=0
            for x in answer:value^=x
            if value==0:return 'Found'
        return 'Nothing'
    if number==16:
        n,edges=cast(tuple[int,Edges],data);dist=[[0 if i==j else 100 for j in range(n)] for i in range(n)]
        for u,v in edges:dist[u-1][v-1]=dist[v-1][u-1]=1
        for k in range(n):
            for i in range(n):
                for j in range(n):dist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j])
        return '\n'.join(str(row.count(2)) for row in dist)
    if number==17:
        n,m,intervals=cast(tuple[int,int,Weighted],data)
        if n<=8 and m<=8:
            best=0
            for flags in product((0,1),repeat=n):
                acquired=set();score=0
                for flag,(l,r,s) in zip(flags,intervals):
                    if flag:acquired.update(range(l,r+1));score+=s
                if len(acquired)<m:best=max(best,score)
            return str(best)
        events:dict[int,int]={1:0,m+1:0};total=0
        for l,r,s in intervals:events[l]=events.get(l,0)+s;events[r+1]=events.get(r+1,0)-s;total+=s
        loss=0;minimum=total
        for pos,change in sorted(events.items()):
            loss+=change
            if pos<=m:minimum=min(minimum,loss)
        return str(total-minimum)
    if number==18:
        r,c,k,grid=cast(tuple[int,int,int,tuple[str,...]],data);return str(_diamond_oracle(r,c,k,grid))
    if number==19:
        n,a=cast(tuple[int,tuple[int,...]],data);parent={v:v for v in a};maximum=max(a)
        def find(x: int) -> int:
            while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
            return x
        for v in a:
            u=v*2
            while u<=maximum:
                if u in parent:parent[find(u)]=find(v)
                u*=2
        return str(len({find(v) for v in a}))
    if number==20:
        r,c,t,grid=cast(tuple[int,int,int,tuple[str,...]],data);return str(_wall_oracle(r,c,t,grid))
    if number==21:
        n,a,b,edges=cast(tuple[int,int,int,Edges],data);neighbors=[[] for _ in range(n)]
        for u,v in edges:neighbors[u-1].append(v-1);neighbors[v-1].append(u-1)
        # Count all length-d walks, stopping at the first d that reaches b;
        # earliest walks are necessarily shortest paths.
        ways=[0]*n;ways[a-1]=1
        for length in range(1,n):
            nxt=[0]*n
            for u in range(n):
                for v in neighbors[u]:nxt[v]+=ways[u]
            ways=nxt
            if ways[b-1]:return str(ways[b-1]%1000000007)
        raise AssertionError('connected graph')
    if number==22:
        n,edges=cast(tuple[int,Weighted],data);neighbors=[[] for _ in range(n)]
        for u,v,w in edges:neighbors[u-1].append((v-1,w));neighbors[v-1].append((u-1,w))
        best=10**18
        # Remove each incident edge in turn, then find a weighted path back to
        # house 1. Reference removes house 1 and pairs its neighboring houses.
        for start,weight in neighbors[0]:
            distances=[10**18]*n;distances[start]=0;heap=[(0,start)]
            while heap:
                distance,u=heappop(heap)
                if distance!=distances[u]:continue
                if u==0:best=min(best,distance+weight);break
                for v,w in neighbors[u]:
                    if (u==start and v==0) or (u==0 and v==start):continue
                    if distance+w<distances[v]:distances[v]=distance+w;heappush(heap,(distance+w,v))
        return str(best if best<10**18 else -1)
    if number==23:
        r,c,k,points=cast(tuple[int,int,int,Edges],data);rowcounts=Counter(y for y,x in points);colcounts=Counter(x for y,x in points)
        # Group actual column indices by candy count; remove occupied columns
        # row by row, then count their true (one-candy-corrected) union size.
        columns:dict[int,set[int]]={}
        for x,count in colcounts.items():columns.setdefault(count,set()).add(x)
        frequencies={count:len(cols) for count,cols in columns.items()};frequencies[0]=c-len(colcounts)
        occupied:dict[int,list[int]]={}
        for y,x in points:occupied.setdefault(y,[]).append(x)
        total=0
        for y in range(1,r+1):
            count=rowcounts.get(y,0);total+=frequencies.get(k-count,0)
            for x in occupied.get(y,[]):
                total-=count+colcounts[x]==k
                total+=count+colcounts[x]-1==k
        return str(total)
    if number==24:
        n,days,queries=cast(tuple[int,Edges,Edges],data);return '\n'.join(map(str,migration(days,queries)))
    matrix,=cast(tuple[tuple[tuple[int,...],...]],data);return '\n'.join(map(str,_game_oracle(matrix)))

def independent_check(pid: str,raw: str,actual: str) -> bool:
    validate(pid,raw)
    if pid=='abc008_3':
        if re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\n?',actual) is None:return False
        try:
            value,expected=Decimal(actual.strip()),Decimal(oracle(pid,raw));epsilon=Decimal('0.000001')
            return value.is_finite() and (abs(value-expected)<=epsilon or abs(value-expected)<=epsilon*abs(expected))
        except InvalidOperation:return False
    return actual.removesuffix('\n')==oracle(pid,raw)

def official_expected_matches_reference(pid: str,raw: str,expected: str,stdout: str) -> bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)

REFERENCE_CODE:dict[str,str]={}
def reference(number: int,body: str) -> None:
    pid=f'abc{number:03}_3' if number<=19 else f'abc{number:03}_c'
    REFERENCE_CODE[pid]='import sys, math\nfrom collections import Counter, deque\nfrom heapq import heappop, heappush\nfrom functools import lru_cache\n'+body.strip()+'\n'

reference(8,'''
n=int(input());a=[int(input()) for _ in range(n)];ans=0.0
for i,v in enumerate(a):
 d=sum(i!=j and v%w==0 for j,w in enumerate(a));ans+=((d+2)//2)/(d+1)
print(format(ans,'.15f'))
''')
reference(9,'''
n,k=map(int,input().split());s=input();remaining=Counter(s);result='';changed=0
for i in range(n):
 tail=Counter(s[i+1:])
 for ch in sorted(remaining):
  if remaining[ch]==0:continue
  remaining[ch]-=1;cost=changed+(ch!=s[i])+sum(max(0,count-remaining[x]) for x,count in tail.items())
  if cost<=k:result+=ch;changed+=(ch!=s[i]);break
  remaining[ch]+=1
print(result)
''')
reference(10,'''
a,b,c,d,t,v=map(int,input().split());n=int(input());ok=False
for _ in range(n):
 x,y=map(int,input().split())
 if math.hypot(x-a,y-b)+math.hypot(x-c,y-d)<=t*v:ok=True
print('YES' if ok else 'NO')
''')
reference(11,'''
n=int(input());ng={int(input()) for _ in range(3)};dp=[1000]*(n+1);dp[0]=0
for x in range(1,n+1):
 if x not in ng:dp[x]=1+min(dp[max(0,x-3):x])
print('YES' if dp[n]<=100 else 'NO')
''')
reference(12,'''
n=int(input())
for a in range(1,10):
 for b in range(1,10):
  if a*b==2025-n:print(a,'x',b)
''')
reference(13,'''
n,h=map(int,input().split());a,b,c,d,e=map(int,input().split());ans=n*a
for expensive in range(n+1):
 cheap=max(0,(n*e-h-expensive*(b+e))//(d+e)+1)
 if expensive+cheap<=n:ans=min(ans,expensive*a+cheap*c)
print(ans)
''')
reference(14,'''
n=int(input());diff=[0]*1000002
for _ in range(n):
 a,b=map(int,input().split());diff[a]+=1;diff[b+1]-=1
current=ans=0
for change in diff:current+=change;ans=max(ans,current)
print(ans)
''')
reference(15,'''
n,k=map(int,input().split());possible={0}
for _ in range(n):
 row=list(map(int,input().split()));possible={x^y for x in possible for y in row}
print('Found' if 0 in possible else 'Nothing')
''')
reference(16,'''
n,m=map(int,input().split());friends=[set() for _ in range(n)]
for _ in range(m):
 u,v=map(int,input().split());friends[u-1].add(v-1);friends[v-1].add(u-1)
for i in range(n):
 candidates=set().union(*(friends[j] for j in friends[i]));print(len(candidates-friends[i]-{i}))
''')
reference(17,'''
n,m=map(int,input().split());diff=[0]*(m+2);total=0
for _ in range(n):
 l,r,s=map(int,input().split());diff[l]+=s;diff[r+1]-=s;total+=s
loss=0;minimum=total
for x in range(1,m+1):loss+=diff[x];minimum=min(minimum,loss)
print(total-minimum)
''')
reference(18,'''
r,c,k=map(int,input().split());grid=[input() for _ in range(r)];up=[[0]*c for _ in range(r)];down=[[0]*c for _ in range(r)]
for y in range(r):
 for x in range(c):
  if grid[y][x]=='o':up[y][x]=1+(up[y-1][x] if y else 0)
for y in range(r-1,-1,-1):
 for x in range(c):
  if grid[y][x]=='o':down[y][x]=1+(down[y+1][x] if y+1<r else 0)
ans=0
for y in range(k-1,r-k+1):
 for x in range(k-1,c-k+1):
  if all(min(up[y][xx],down[y][xx])>=k-abs(xx-x) for xx in range(x-k+1,x+k)):ans+=1
print(ans)
''')
reference(19,'''
n=int(input());normalized=set()
for a in map(int,input().split()):
 while a%2==0:a//=2
 normalized.add(a)
print(len(normalized))
''')
reference(20,'''
r,c,t=map(int,input().split());grid=[input() for _ in range(r)];start=next((y,x) for y in range(r) for x in range(c) if grid[y][x]=='S');goal=next((y,x) for y in range(r) for x in range(c) if grid[y][x]=='G')
def feasible(cost):
 dist=[[10**18]*c for _ in range(r)];dist[start[0]][start[1]]=0;heap=[(0,*start)]
 while heap:
  d,y,x=heappop(heap)
  if d!=dist[y][x]:continue
  if (y,x)==goal:return d<=t
  for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
   yy,xx=y+dy,x+dx
   if 0<=yy<r and 0<=xx<c:
    nd=d+(cost if grid[yy][xx]=='#' else 1)
    if nd<dist[yy][xx]:dist[yy][xx]=nd;heappush(heap,(nd,yy,xx))
 return False
lo,hi=1,t+1
while hi-lo>1:
 mid=(lo+hi)//2
 if feasible(mid):lo=mid
 else:hi=mid
print(lo)
''')
reference(21,'''
n=int(input());a,b=map(int,input().split());m=int(input());graph=[[] for _ in range(n)]
for _ in range(m):
 u,v=map(int,input().split());graph[u-1].append(v-1);graph[v-1].append(u-1)
dist=[-1]*n;ways=[0]*n;dist[a-1]=0;ways[a-1]=1;q=deque([a-1])
while q:
 u=q.popleft()
 for v in graph[u]:
  if dist[v]<0:dist[v]=dist[u]+1;q.append(v)
  if dist[v]==dist[u]+1:ways[v]=(ways[v]+ways[u])%1000000007
print(ways[b-1])
''')
reference(22,'''
n,m=map(int,input().split());graph=[[] for _ in range(n)];around=[]
for _ in range(m):
 u,v,w=map(int,input().split());u-=1;v-=1
 if u==0:around.append((v,w))
 else:graph[u].append((v,w));graph[v].append((u,w))
ans=10**18
for i,(start,cost) in enumerate(around):
 dist=[10**18]*n;dist[start]=0;heap=[(0,start)]
 while heap:
  d,u=heappop(heap)
  if d!=dist[u]:continue
  for v,w in graph[u]:
   if d+w<dist[v]:dist[v]=d+w;heappush(heap,(d+w,v))
 for end,other in around[i+1:]:ans=min(ans,cost+dist[end]+other)
print(ans if ans<10**18 else -1)
''')
reference(23,'''
r,c,k=map(int,input().split());n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];rows=[0]*r;cols=[0]*c
for y,x in points:rows[y-1]+=1;cols[x-1]+=1
rc=Counter(rows);cc=Counter(cols);ans=sum(count*cc.get(k-v,0) for v,count in rc.items())
for y,x in points:
 count=rows[y-1]+cols[x-1]
 if count==k:ans-=1
 if count==k+1:ans+=1
print(ans)
''')
reference(24,'''
n,d,k=map(int,input().split());days=[tuple(map(int,input().split())) for _ in range(d)]
for _ in range(k):
 start,goal=map(int,input().split());position=start
 for day,(l,r) in enumerate(days,1):
  if l<=position<=r:
   if l<=goal<=r:print(day);break
   position=r if position<goal else l
''')
reference(25,'''
matrix=[list(map(int,input().split())) for _ in range(5)];edges=[(i*3+j,(i+1)*3+j,matrix[i][j]) for i in range(2) for j in range(3)]+[(i*3+j,i*3+j+1,matrix[i+2][j]) for i in range(3) for j in range(2)]
@lru_cache(None)
def solve(board):
 count=sum(x!=0 for x in board)
 if count==9:return sum(w for u,v,w in edges if board[u]==board[v])
 results=[]
 for i,x in enumerate(board):
  if x==0:
   child=list(board);child[i]=1 if count%2==0 else 2;results.append(solve(tuple(child)))
 return max(results) if count%2==0 else min(results)
first=solve((0,)*9);print(first);print(sum(w for u,v,w in edges)-first)
''')

def _matrix(rows: list[list[int]]) -> str:
    return '\n'.join(' '.join(map(str,row)) for row in rows)+'\n'

def _graph(n: int,edges: list[Pair] | list[tuple[int,int,int]]) -> str:
    return f'{n} {len(edges)}\n'+_matrix([list(edge) for edge in edges]) if edges else f'{n} 0\n'

def generate(pid: str) -> list[Case]:
    require(pid in TASKS,'pid');number=int(pid[3:6]);rng=random.Random(155+number);raws:list[str]=[]
    if number==8:
        def coins(a: list[int]) -> str:return f'{len(a)}\n'+'\n'.join(map(str,a))+'\n'
        raws=[coins([1]),coins([10**9]),coins([1,1]),coins([2,3]),coins([1,2,4,8])]
        for j in range(12):raws.append(coins([rng.randint(1,30) for _ in range(3+j%5)]))
        raws.append(coins([10**9]*100))
    elif number==9:
        def word(s: str,k: int) -> str:return f'{len(s)} {k}\n{s}\n'
        raws=[word('a',0),word('z',1),word('ba',0),word('ba',1),word('ba',2),word('bbaa',2)]
        for j in range(11):
            n=3+j%5;raws.append(word(''.join(rng.choice('abcd') for _ in range(n)),j%(n+1)))
        raws.append(word(('zyxwvutsrqponmlkjihgfedcba'*4)[:100],50))
    elif number==10:
        def visit(head: list[int],points: list[Pair]) -> str:return ' '.join(map(str,head))+f'\n{len(points)}\n'+_matrix([list(p) for p in points])
        raws=[visit([0,0,1,0,1,1],[(0,0)]),visit([0,0,1,0,1,1],[(0,1)]),visit([0,0,6,8,1,10],[(3,4)]),visit([0,0,0,0,1,2],[(1,0)]),visit([0,0,0,0,1,2],[(1,1)])]
        for j in range(12):raws.append(visit([0,0,10+j,0,2,20],[(rng.randint(0,30),rng.randint(0,30)) for _ in range(j+1)]))
        raws.append(visit([0,0,1000,1000,50,100],[(1000,i) for i in range(1000)]))
    elif number==11:
        heads=[(1,[1,2,3]),(1,[2,3,4]),(3,[1,2,3]),(4,[1,2,3]),(299,[298,297,296]),(300,[299,298,297])]
        raws=[f'{n}\n'+'\n'.join(map(str,ng))+'\n' for n,ng in heads]
        for j in range(11):raws.append(f'{rng.randint(1,300)}\n'+'\n'.join(str(rng.randint(1,300)) for _ in range(3))+'\n')
        raws.append('300\n1\n1\n1\n')
    elif number==12:
        missing=sorted({a*b for a in range(1,10) for b in range(1,10)})
        raws=[f'{2025-x}\n' for x in missing[:17]]+['1944\n']
    elif number==13:
        raws=['1 1\n2 2 1 1 1\n','1 2\n2 2 1 1 1\n','1 1\n1000000 1000000 1 1 1000000\n','2 1\n5 5 2 2 1\n']
        for j in range(12):
            n=2+j%6;h=1+j;c=rng.randint(1,10);d=rng.randint(1,10);raws.append(f'{n} {h}\n{c+rng.randint(1,10)} {d+rng.randint(1,10)} {c} {d} {rng.randint(1,10)}\n')
        raws.append('1000 1000000000\n1000000 1000000 999999 999999 1000000\n')
        raws.append('500000 1\n1000000 1000000 999999 999999 1000000\n')
    elif number==14:
        def intervals(edges: list[Pair]) -> str:return f'{len(edges)}\n'+_matrix([list(p) for p in edges])
        raws=[intervals([(0,0)]),intervals([(1000000,1000000)]),intervals([(0,1),(1,2)]),intervals([(0,0),(1,1)])]
        for j in range(13):
            edges=[]
            for i in range(j+2):
                a=rng.randint(0,1000000);b=rng.randint(a,1000000);edges.append((a,b))
            raws.append(intervals(edges))
        raws.append(intervals([(0,1000000)]*100000))
    elif number==15:
        raws=['1 1\n0\n','1 1\n127\n','2 2\n1 2\n1 2\n','2 1\n0\n127\n']
        for j in range(13):
            n=1+j%5;k=1+(j//5)%5;raws.append(f'{n} {k}\n'+_matrix([[rng.randint(0,127) for _ in range(k)] for _ in range(n)]))
        raws.append('5 5\n'+_matrix([[127]*5 for _ in range(5)]))
    elif number==16:
        raws=[_graph(1,[]),_graph(2,[]),_graph(2,[(1,2)]),_graph(3,[(1,2),(2,3)])]
        for j in range(13):
            n=4+j%7;edges=[p for p in combinations(range(1,n+1),2) if rng.randrange(2)];raws.append(_graph(n,edges))
        raws.append(_graph(10,list(combinations(range(1,11),2))))
    elif number==17:
        def ruins(m: int,edges: list[tuple[int,int,int]]) -> str:return f'{len(edges)} {m}\n'+_matrix([list(edge) for edge in edges])
        raws=[ruins(1,[(1,1,1)]),ruins(2,[(1,1,5000)]),ruins(2,[(1,1,1),(2,2,1)]),ruins(3,[(1,3,1),(1,1,2)])]
        for j in range(13):
            m=2+j;edges=[]
            for i in range(2+j):
                l=rng.randint(1,m);edges.append((l,rng.randint(l,m),rng.randint(1,5000)))
            raws.append(ruins(m,edges))
        raws.append(ruins(100000,[(i,i,5000) for i in range(1,100001)]))
    elif number==18:
        def diamond(grid: list[str],k: int) -> str:return f'{len(grid)} {len(grid[0])} {k}\n'+'\n'.join(grid)+'\n'
        raws=[diamond(['ooo']*3,2),diamond(['xxx']*3,2),diamond(['ooo','oxo','ooo'],2),diamond(['ooo']*3,500)]
        for j in range(12):
            r=4+j;c=5+j;raws.append(diamond([''.join(rng.choices('ox',weights=[9,1],k=c)) for _ in range(r)],2+j%4))
        raws.append(diamond(['o'*500]*500,500));raws.append(diamond(['o'*500]*500,250))
    elif number==19:
        def box(a: list[int]) -> str:return f'{len(a)}\n'+' '.join(map(str,a))+'\n'
        raws=[box([1]),box([10**9]),box([1,4]),box([2,3,5,7])]
        for j in range(13):raws.append(box(rng.sample(range(1,1000000),j+2)))
        raws.append(box(list(range(1,100001))))
    elif number==20:
        def wall(r: int,c: int,t: int,pattern: int) -> str:
            grid=[['#']*c for _ in range(r)]
            if pattern:
                for y in range(r):
                    for x in range(c):
                        if x not in (c//2,):grid[y][x]='.'
            grid[0][0]='S';grid[-1][-1]='G'
            return f'{r} {c} {t}\n'+'\n'.join(''.join(row) for row in grid)+'\n'
        raws=[wall(2,2,2,0),wall(2,2,3,0),wall(2,3,10,1),wall(3,3,4,0)]
        for j in range(13):
            r=3+j%8;c=3+(j*3)%8;raws.append(wall(r,c,max(r+c,10+j*7),j%2))
        raws.append(wall(10,10,10**9,1))
    elif number==21:
        def paths(n: int,a: int,b: int,edges: list[Pair]) -> str:return f'{n}\n{a} {b}\n{len(edges)}\n'+_matrix([list(e) for e in edges])
        raws=[paths(2,1,2,[(1,2)]),paths(3,1,3,[(1,2),(2,3)]),paths(4,1,4,[(1,2),(1,3),(2,4),(3,4)]),paths(2,1,2,[(1,2),(1,2)])]
        for j in range(13):
            n=5+j;edges=[(i,i+1) for i in range(1,n)]
            edges.extend(p for p in combinations(range(1,n+1),2) if p not in edges and rng.randrange(5)==0)
            raws.append(paths(n,1,n,edges))
        # 2**49 shortest paths: force modular arithmetic at maximum N/M.
        layers=[[1]]+[[2*i,2*i+1] for i in range(1,50)]+[[100]]
        edges=[(a,b) for left,right in zip(layers,layers[1:]) for a in left for b in right]
        raws.append(paths(100,1,100,edges))
    elif number==22:
        raws=[_graph(3,[(1,2,1),(1,3,1),(2,3,1)]),_graph(4,[(1,2,1),(1,3,1),(1,4,1)]),_graph(4,[(1,2,1),(2,3,1),(2,4,1)]),_graph(4,[(1,2,100000),(1,4,1),(2,4,1)])]
        for j in range(13):
            n=4+j;edges=[(i,i+1,rng.randint(1,100000)) for i in range(1,n)]
            edges.extend((u,v,rng.randint(1,100000)) for u,v in combinations(range(1,n+1),2) if v>u+1 and rng.randrange(3)==0)
            raws.append(_graph(n,edges))
        raws.append(_graph(300,[(u,v,100000) for u,v in combinations(range(1,301),2)]))
    elif number==23:
        def candy(r: int,c: int,k: int,points: list[Pair]) -> str:return f'{r} {c} {k}\n{len(points)}\n'+_matrix([list(p) for p in points])
        raws=[candy(1,1,1,[(1,1)]),candy(1,3,2,[(1,1),(1,3)]),candy(3,3,1,[(1,1)]),candy(2,2,3,[(1,1),(1,2),(2,1)])]
        for j in range(13):
            r=3+j;c=4+j;points=rng.sample(list(product(range(1,r+1),range(1,c+1))),2+j);raws.append(candy(r,c,1+j%(len(points)),points))
        raws.append(candy(100000,100000,100000,[(i,i) for i in range(1,100001)]))
    elif number==24:
        def migrate(n: int,days: list[Pair],queries: list[Pair]) -> str:return f'{n} {len(days)} {len(queries)}\n'+_matrix([list(p) for p in days+queries])
        raws=[migrate(2,[(1,2)],[(1,2)]),migrate(2,[(1,1),(1,2)],[(2,1)]),migrate(10,[(1,3),(3,5),(5,10)],[(1,10),(10,1)])]
        # Reverse query in the previous example cannot arrive: add a full final day.
        raws[-1]=migrate(10,[(1,3),(3,5),(5,10),(1,10)],[(1,10),(10,1)])
        for j in range(14):
            n=3+j;days=[]
            for i in range(j+1):
                l=rng.randint(1,n);days.append((l,rng.randint(l,n)))
            days.append((1,n));raws.append(migrate(n,days,[(1,n),(n,1)]))
        raws.append(migrate(10**9,[(1,1)]*9999+[(1,10**9)],[(i,10**9-i) for i in range(1,101)]))
    else:
        raws=[_matrix([[0]*3,[0]*3,[0]*2,[0]*2,[0]*2]),_matrix([[1]*3,[1]*3,[1]*2,[1]*2,[1]*2])]
        for j in range(15):raws.append(_matrix([[rng.randint(0,100) for _ in range(3 if i<2 else 2)] for i in range(5)]))
        raws.append(_matrix([[100]*3,[100]*3,[100]*2,[100]*2,[100]*2]))
    require(len(raws)==len(set(raws))==18,f'{pid}: count or duplicate')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'boundary_{i:02}'} for i,raw in enumerate(raws)]

TITLES: dict[str,str] = {'abc008_3': 'コイン', 'abc009_3': '辞書式順序ふたたび', 'abc010_3': '浮気調査', 'abc011_3': '123引き算', 'abc012_3': '九九足し算', 'abc013_3': '節制', 'abc014_3': 'AtColor', 'abc015_3': '高橋くんのバグ探し', 'abc016_3': '友達の友達', 'abc017_3': 'ハイスコア', 'abc018_3': '菱型カウント', 'abc019_3': '高橋くんと魔法の箱', 'abc020_c': '壁抜け', 'abc021_c': '正直者の高橋くん', 'abc022_c': 'Blue Bird', 'abc023_c': '収集王', 'abc024_c': '民族大移動', 'abc025_c': '双子と○×ゲーム'}
PUBLISHED_SAMPLES: dict[str,list[Case]] = {'abc008_3': [{'input': '3\n2\n4\n8\n', 'expected': '2.166666666667\n'}, {'input': '4\n5\n5\n5\n5\n', 'expected': '2.000000000000\n'}, {'input': '5\n2\n3\n2\n6\n12\n', 'expected': '3.100000000000\n'}], 'abc009_3': [{'input': '3 2\nabc\n', 'expected': 'abc\n'}, {'input': '7 2\natcoder\n', 'expected': 'actoder\n'}, {'input': '7 7\natcoder\n', 'expected': 'acdeort\n'}, {'input': '10 3\nhelloworld\n', 'expected': 'dehloworll\n'}], 'abc010_3': [{'input': '1 1 8 2 2 4\n1\n4 5\n', 'expected': 'NO\n'}, {'input': '1 1 8 2 2 6\n1\n4 5\n', 'expected': 'YES\n'}, {'input': '1 1 8 2 2 5\n1\n4 5\n', 'expected': 'YES\n'}, {'input': '7 7 1 1 3 4\n3\n8 1\n1 7\n9 9\n', 'expected': 'YES\n'}], 'abc011_3': [{'input': '2\n1\n7\n15\n', 'expected': 'YES\n'}, {'input': '5\n1\n4\n2\n', 'expected': 'YES\n'}, {'input': '300\n57\n121\n244\n', 'expected': 'NO\n'}], 'abc012_3': [{'input': '2013\n', 'expected': '2 x 6\n3 x 4\n4 x 3\n6 x 2\n'}, {'input': '2024\n', 'expected': '1 x 1\n'}], 'abc013_3': [{'input': '4 5\n100 4 60 1 4\n', 'expected': '160\n'}, {'input': '10 1\n5000 2 2000 1 300\n', 'expected': '20000\n'}, {'input': '9 23\n170 8 120 5 12\n', 'expected': '650\n'}, {'input': '653 314159\n6728 123456 5141 41928 222222\n', 'expected': '2818162\n'}], 'abc014_3': [{'input': '4\n0 2\n2 3\n2 4\n5 6\n', 'expected': '3\n'}, {'input': '4\n1000000 1000000\n1000000 1000000\n0 1000000\n1 1000000\n', 'expected': '4\n'}], 'abc015_3': [{'input': '3 4\n1 3 5 17\n2 4 2 3\n1 3 2 9\n', 'expected': 'Found\n'}, {'input': '5 3\n89 62 15\n44 36 17\n4 24 24\n25 98 99\n66 33 57\n', 'expected': 'Nothing\n'}], 'abc016_3': [{'input': '3 2\n1 2\n2 3\n', 'expected': '1\n0\n1\n'}, {'input': '3 3\n1 2\n1 3\n2 3\n', 'expected': '0\n0\n0\n'}, {'input': '8 12\n1 6\n1 7\n1 8\n2 5\n2 6\n3 5\n3 6\n4 5\n4 8\n5 6\n5 7\n7 8\n', 'expected': '4\n4\n4\n5\n2\n3\n4\n2\n'}], 'abc017_3': [{'input': '4 6\n1 3 30\n2 3 40\n3 6 25\n6 6 10\n', 'expected': '80\n'}, {'input': '2 7\n1 3 90\n5 7 90\n', 'expected': '180\n'}, {'input': '1 4\n1 4 70\n', 'expected': '0\n'}], 'abc018_3': [{'input': '4 5 2\nxoooo\noooox\nooooo\noxxoo\n', 'expected': '3\n'}, {'input': '4 5 2\nooooo\noxoox\noooox\noxxoo\n', 'expected': '0\n'}, {'input': '8 6 3\noooooo\noooooo\noooooo\noooooo\noxoooo\noooooo\noooooo\noooooo\n', 'expected': '4\n'}], 'abc019_3': [{'input': '3\n1 2 3\n', 'expected': '2\n'}, {'input': '4\n2 4 8 16\n', 'expected': '1\n'}, {'input': '4\n2 3 5 7\n', 'expected': '4\n'}], 'abc020_c': [{'input': '2 3 10\nS##\n.#G\n', 'expected': '8\n'}, {'input': '3 4 7\nS##G\n.##.\n..#.\n', 'expected': '3\n'}, {'input': '4 4 1000000000\nS###\n####\n####\n###G\n', 'expected': '199999999\n'}], 'abc021_c': [{'input': '7\n1 7\n8\n1 2\n1 3\n4 2\n4 3\n4 5\n4 6\n7 5\n7 6\n', 'expected': '4\n'}, {'input': '7\n1 7\n9\n1 2\n1 3\n4 2\n4 3\n4 5\n4 6\n7 5\n7 6\n4 7\n', 'expected': '2\n'}], 'abc022_c': [{'input': '5 7\n1 2 2\n1 4 1\n2 3 7\n1 5 12\n3 5 2\n2 5 3\n3 4 5\n', 'expected': '13\n'}, {'input': '5 4\n1 2 1\n1 3 1\n1 4 1\n1 5 1\n', 'expected': '-1\n'}, {'input': '10 12\n1 4 3\n1 9 1\n2 5 4\n2 6 1\n3 7 5\n3 10 9\n4 7 2\n5 6 6\n5 8 5\n6 8 3\n7 9 5\n8 10 8\n', 'expected': '11\n'}], 'abc023_c': [{'input': '3 5 3\n5\n1 2\n2 1\n2 5\n3 2\n3 5\n', 'expected': '5\n'}, {'input': '7 3 1\n4\n3 2\n3 3\n4 2\n4 3\n', 'expected': '0\n'}, {'input': '5 5 2\n5\n1 1\n2 2\n3 3\n4 4\n5 5\n', 'expected': '20\n'}], 'abc024_c': [{'input': '10 10 3\n1 5\n3 6\n7 10\n5 8\n4 4\n1 4\n2 9\n1 3\n1 1\n4 5\n1 6\n2 7\n10 1\n', 'expected': '2\n4\n8\n'}, {'input': '10 10 4\n1 2\n2 4\n3 6\n4 8\n5 10\n9 10\n7 8\n5 6\n3 5\n1 3\n10 1\n3 8\n2 4\n1 3\n', 'expected': '10\n4\n2\n2\n'}, {'input': '314159265 10 1\n1 10000\n500 12031\n1414 113232\n111111 777777\n666661 23423423\n12345678 123456789\n111111111 314159265\n112334 235235235\n1 223445\n314 1592\n1 314159265\n', 'expected': '7\n'}], 'abc025_c': [{'input': '0 15 0\n0 0 25\n20 10\n0 0\n25 0\n', 'expected': '15\n80\n'}, {'input': '18 22 15\n11 16 17\n4 25\n22 15\n10 4\n', 'expected': '72\n107\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
