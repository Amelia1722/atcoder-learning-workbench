"""Private ABC186..191 D contracts, including exact scaled decimal geometry."""
from __future__ import annotations
from bisect import bisect_left
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(186,192))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
SCALE=10000

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def scaled_decimal(token:str)->int:
    require(re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]{1,4})?',token) is not None,'at most4 decimal places');sign=-1 if token.startswith('-') else 1;parts=token.removeprefix('-').split('.');return sign*(int(parts[0])*SCALE+int(parts[1].ljust(4,'0') if len(parts)==2 else '0'))

def decimal_text(value:int)->str:return ('-' if value<0 else '')+str(abs(value)//SCALE)+'.'+str(abs(value)%SCALE).zfill(4)

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc186_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(2<=n<=200000,'N');a=ints(rows[1],n);require(all(abs(v)<=10**8 for v in a),'Ai');return (a,)
    if pid=='abc187_d':
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'N/shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=x<=10**9 and 1<=y<=10**9 for x,y in a),'A/B');return (a,)
    if pid=='abc188_d':
        n,c=ints(rows[0],2);require(1<=n<=200000 and 1<=c<=10**9 and len(rows)==n+1,'N/C/shape');a=tuple(ints(row,3) for row in rows[1:]);require(all(1<=left<=right<=10**9 and 1<=cost<=10**9 for left,right,cost in a),'a/b/c');return c,a
    if pid=='abc189_d':
        n=ints(rows[0],1)[0];require(1<=n<=60 and len(rows)==n+1 and all(row in ('AND','OR') for row in rows[1:]),'N/ops');return (tuple(rows[1:]),)
    if pid=='abc190_d':
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**12,'N');return (n,)
    require(len(rows)==1 and len(rows[0].split(' '))==3,'shape');x,y,r=map(scaled_decimal,rows[0].split(' '));require(abs(x)<=10**9 and abs(y)<=10**9 and 1<=r<=10**9,'X/Y/R');return x,y,r

def difference_fenwick(a:tuple[int,...])->int:
    values=sorted(set(a));counts=[0]*(len(values)+1);sums=[0]*len(counts);total=answer=0
    for index,value in enumerate(a):
        j=bisect_left(values,value)+1;left_count=left_sum=0;cursor=j-1
        while cursor:left_count+=counts[cursor];left_sum+=sums[cursor];cursor-=cursor&-cursor
        answer+=value*left_count-left_sum+total-left_sum-value*(index-left_count);total+=value
        while j<len(counts):counts[j]+=1;sums[j]+=value;j+=j&-j
    return answer

def election_gain_heap(a:tuple[tuple[int,...],...])->int:
    remaining=sum(x for x,y in a);heap=[-(2*x+y) for x,y in a];heapq.heapify(heap);moves=0
    while remaining>=0:remaining+=heapq.heappop(heap);moves+=1
    return moves

def service_active_heap(c:int,a:tuple[tuple[int,...],...])->int:
    services=sorted(a);cursor=0;active:list[tuple[int,int]]=[];previous=services[0][0];cost=answer=0
    while cursor<len(services) or active:
        next_start=services[cursor][0] if cursor<len(services) else 10**20;next_end=active[0][0] if active else 10**20;day=min(next_start,next_end);answer+=min(c,cost)*(day-previous)
        while active and active[0][0]==day:cost-=heapq.heappop(active)[1]
        while cursor<len(services) and services[cursor][0]==day:
            left,right,value=services[cursor];heapq.heappush(active,(right+1,value));cost+=value;cursor+=1
        previous=day
    return answer

def logic_suffix_cofactors(ops:tuple[str,...])->int:
    false,true=0,1
    for op in reversed(ops):
        if op=='AND':false,true=2*false,false+true
        else:false,true=false+true,2*true
    return false+true

def staircase_odd_divisors(n:int)->int:
    while n%2==0:n//=2
    p=3;divisors=1
    while p*p<=n:
        exponent=0
        while n%p==0:n//=p;exponent+=1
        divisors*=exponent+1;p+=2
    if n>1:divisors*=2
    return 2*divisors

def circle_row_binary(x:int,y:int,r:int)->int:
    ymin=-((r-y)//SCALE);ymax=(y+r)//SCALE;xmin=-((r-x)//SCALE);xmax=(x+r)//SCALE;nearest=(x+SCALE//2)//SCALE;answer=0
    for row in range(ymin,ymax+1):
        remainder=r*r-(row*SCALE-y)**2
        if (nearest*SCALE-x)**2>remainder:continue
        low=xmin-1;high=nearest
        while low+1<high:
            middle=(low+high)//2
            if (middle*SCALE-x)**2<=remainder:high=middle
            else:low=middle
        first=high;low=nearest;high=xmax+1
        while low+1<high:
            middle=(low+high)//2
            if (middle*SCALE-x)**2<=remainder:low=middle
            else:high=middle
        answer+=low-first+1
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc186_d':return str(difference_fenwick(cast(tuple[int,...],data[0])))
    if pid=='abc187_d':return str(election_gain_heap(cast(tuple[tuple[int,...],...],data[0])))
    if pid=='abc188_d':return str(service_active_heap(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
    if pid=='abc189_d':return str(logic_suffix_cofactors(cast(tuple[str,...],data[0])))
    if pid=='abc190_d':return str(staircase_odd_divisors(cast(int,data[0])))
    return str(circle_row_binary(*cast(tuple[int,int,int],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc186_d':"n=int(input());a=sorted(map(int,input().split()));prefix=answer=0\nfor j,value in enumerate(a):answer+=j*value-prefix;prefix+=value\nprint(answer)\n",
'abc187_d':"n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];needed=sum(x for x,y in a);gains=sorted((2*x+y for x,y in a),reverse=True);moves=0\nfor gain in gains:\n needed-=gain;moves+=1\n if needed<0:break\nprint(moves)\n",
'abc188_d':"n,c=map(int,input().split());events=[]\nfor _ in range(n):a,b,cost=map(int,input().split());events.extend(((a,cost),(b+1,-cost)))\nevents.sort();previous=events[0][0];cost=answer=0\nfor day,delta in events:answer+=min(c,cost)*(day-previous);cost+=delta;previous=day\nprint(answer)\n",
'abc189_d':"n=int(input());false=true=1\nfor _ in range(n):\n op=input()\n if op=='AND':false,true=2*false+true,true\n else:false,true=false,false+2*true\nprint(true)\n",
'abc190_d':"from math import isqrt\nn=int(input());twice=2*n;answer=0\nfor divisor in range(1,isqrt(twice)+1):\n if twice%divisor:continue\n for length in (divisor,twice//divisor) if divisor*divisor!=twice else (divisor,):\n  if (twice//length-length+1)%2==0:answer+=1\nprint(answer)\n",
'abc191_d':"from math import isqrt\ndef scaled(token):\n sign=-1 if token.startswith('-') else 1;parts=token.lstrip('-').split('.');return sign*(int(parts[0])*10000+int(parts[1].ljust(4,'0') if len(parts)==2 else '0'))\nx,y,r=map(scaled,input().split());answer=0\nfor column in range(-((r-x)//10000),(x+r)//10000+1):\n half=isqrt(r*r-(column*10000-x)**2);low=-((half-y)//10000);high=(y+half)//10000;answer+=max(0,high-low+1)\nprint(answer)\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18900+TASKS.index(pid))
    if pid=='abc186_d':
        arrays=[[0,0],[-10**8,10**8],[-10**8,-10**8],[10**8,10**8]];arrays.extend([rng.randint(-10**8,10**8) for _ in range(n)] for n in range(3,15));arrays.extend([[(j*7919)%(2*10**8+1)-10**8 for j in range(200000)],[-10**8]*100000+[10**8]*100000]);raws=[f'{len(a)}\n'+line(a) for a in arrays]
    elif pid=='abc187_d':
        def towns(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
        raws=[towns([(1,1)]),towns([(10**9,10**9)]),towns([(2,1)]*5),towns([(1,1),(2,1)])];raws.extend(towns([(rng.randint(1,10**9),rng.randint(1,10**9)) for _ in range(n)]) for n in range(2,14));raws.extend([towns([(j+1,200000-j) for j in range(200000)]),towns([(10**9,10**9)]*200000)])
    elif pid=='abc188_d':
        def service(c:int,a:list[tuple[int,int,int]])->str:return line((len(a),c))+''.join(line(p) for p in a)
        raws=[service(1,[(1,1,1)]),service(10**9,[(1,10**9,10**9)]),service(1,[(10**9,10**9,10**9)]),service(6,[(1,2,4),(2,2,4)])];raws.extend(service(rng.randint(1,10**9),[(a,a+rng.randint(0,100),rng.randint(1,10**9)) for a in [rng.randint(1,10**8) for _ in range(n)]]) for n in range(2,14));raws.extend([service(10**9,[(j+1,j+2,j%1000+1) for j in range(200000)]),service(10**9,[(1,10**9,10**9)]*200000)])
    elif pid=='abc189_d':
        sequences=[('AND',),('OR',),('AND','OR'),('OR','AND')];sequences.extend(tuple(rng.choice(('AND','OR')) for _ in range(n)) for n in range(3,15));sequences.extend([('AND',)*60,('OR',)*60]);raws=[f'{len(a)}\n'+'\n'.join(a)+'\n' for a in sequences]
    elif pid=='abc190_d':raws=[f'{n}\n' for n in [1,2,3,4,6,12,15,30,36,60,2**39,3**25,5**17,999999999989,999983**2,963761198400,10**12-1,10**12]]
    else:
        circles=[(0,0,1),(1,1,1),(5000,5000,1),(0,0,10000),(1000000000,-1000000000,10000),(2000,8000,11000),(-5000,-5000,7071),(-5000,-5000,7072),(9999,-9999,1),(-10000,-10000,10000),(1000,-9000,10000),(-9999,9999,10001)]
        circles.extend((rng.randint(-10**9,10**9),rng.randint(-10**9,10**9),rng.randint(1,30000)) for _ in range(4));circles.extend([(999999999,-999999999,999999999),(-1000000000,1000000000,1000000000)]);raws=[' '.join(map(decimal_text,a))+'\n' for a in circles]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc186_d':('値を昇順にすると、後ろの値から前の値を引けば絶対値が外れます。','現在の値A_iと前の全要素との差の合計はi*A_i-前の累積和です。','疑似コード: Aをsort; prefix=answer=0; 各index iでanswer+=i*A[i]-prefix; prefix+=A[i]; answerを出力。'),
'abc187_d':('町で演説すると、相手からA票減り、自分へA+B票増えるので、差は2A+B変化します。','差の改善が大きい町から選び、相手の初期票数を超える改善になる最小個数を求めます。','疑似コード: required=sum(A); gain=2A+Bを降順sort; gainを順にrequiredから引き、required<0になる最初の個数を出力。'),
'abc188_d':('サービス料金が変わる日は、開始日aと終了日の翌日b+1だけです。','その間の毎日の料金は同じなので、料金と上限Cの小さい方に日数を掛けて足します。','疑似コード: eventsへ(a,+c),(b+1,-c); day昇順sort; 各eventでanswer+=min(cap,currentCost)*(day-previous); currentCost+=delta; previous=day; answerを出力。'),
'abc189_d':('左から演算を一つずつ適用し、結果がFalseとTrueになる代入の個数を管理します。','ANDではTrueと次の変数TrueだけがTrue、ORではFalseと次の変数FalseだけがFalseになります。','疑似コード: false=true=1; ANDならnewFalse=2*false+true,newTrue=true; ORならnewFalse=false,newTrue=false+2*true; 最後trueを出力。'),
'abc190_d':('長さL、最初の整数aの和はL*(2a+L-1)/2です。負のaも許されます。','Lは2Nの約数で、2N/L-L+1が偶数なら整数aが一意に決まります。','疑似コード: 2Nの全約数Lをsqrtまで列挙; (2N/L-L+1)%2=0ならanswer++; 約数の重複を避けて合計を出力。'),
'abc191_d':('小数を浮動小数点にせず、座標と半径を10000倍した整数で扱います。','整数のxを固定し、R^2-(10000*x-X)^2の整数平方根からyの上下限を求めます。円周上も含め、負の座標の切上げに注意します。','疑似コード: X,Y,Rをscaled整数へparse; x=ceil((X-R)/10000)..floor((X+R)/10000); d=isqrt(R^2-(10000*x-X)^2); low=ceil((Y-d)/10000),high=floor((Y+d)/10000); high-low+1を加算して出力。')}

TITLES={'abc186_d': 'Sum of difference', 'abc187_d': 'Choose Me', 'abc188_d': 'Snuke Prime', 'abc189_d': 'Logical Expression', 'abc190_d': 'Staircase Sequences', 'abc191_d': 'Circle Lattice Points'}
PUBLISHED_SAMPLES={'abc186_d': [{'input': '3\n5 1 2\n', 'expected': '8\n'}, {'input': '5\n31 41 59 26 53\n', 'expected': '176\n'}], 'abc187_d': [{'input': '4\n2 1\n2 2\n5 1\n1 3\n', 'expected': '1\n'}, {'input': '5\n2 1\n2 1\n2 1\n2 1\n2 1\n', 'expected': '3\n'}, {'input': '1\n273 691\n', 'expected': '1\n'}], 'abc188_d': [{'input': '2 6\n1 2 4\n2 2 4\n', 'expected': '10\n'}, {'input': '5 1000000000\n583563238 820642330 44577\n136809000 653199778 90962\n54601291 785892285 50554\n5797762 453599267 65697\n468677897 916692569 87409\n', 'expected': '163089627821228\n'}, {'input': '5 100000\n583563238 820642330 44577\n136809000 653199778 90962\n54601291 785892285 50554\n5797762 453599267 65697\n468677897 916692569 87409\n', 'expected': '88206004785464\n'}], 'abc189_d': [{'input': '2\nAND\nOR\n', 'expected': '5\n'}, {'input': '5\nOR\nOR\nOR\nOR\nOR\n', 'expected': '63\n'}], 'abc190_d': [{'input': '12\n', 'expected': '4\n'}, {'input': '1\n', 'expected': '2\n'}, {'input': '963761198400\n', 'expected': '1920\n'}], 'abc191_d': [{'input': '0.2 0.8 1.1\n', 'expected': '3\n'}, {'input': '100 100 1\n', 'expected': '5\n'}, {'input': '42782.4720 31949.0192 99999.99\n', 'expected': '31415920098\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
