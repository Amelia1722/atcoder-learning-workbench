"""Official-statement-checked ABC129–132 A–C tasks; original test oracles."""
from __future__ import annotations
from collections import Counter
from decimal import Decimal, InvalidOperation
from math import gcd
from random import Random
import re

SAMPLES = {
 'abc129_a': ('1 3 4\n','4','1<=P,Q,R<=100'),
 'abc129_b': ('3\n1 2 3\n','0','2<=N<=100;1<=Wi<=100'),
 'abc129_c': ('6 1\n3\n','4','1<=N<=100000;0<=M<=N-1;1<=a1<...<aM<=N-1'),
 'abc130_a': ('3 5\n','0','0<=X,A<=9'),
 'abc130_b': ('3 6\n3 4 5\n','2','1<=N<=100;1<=Li<=100;1<=X<=10000'),
 'abc130_c': ('2 3 1 2\n','3.000000 0','1<=W,H<=10**9;0<=x<=W;0<=y<=H;absolute/relative error <=1e-9'),
 'abc131_a': ('3776\n','Bad','S: exactly four ASCII digits'),
 'abc131_b': ('5 2\n','18','2<=N<=200;-100<=L<=100'),
 'abc131_c': ('4 9 2 3\n','2','1<=A<=B<=10**18;1<=C,D<=10**9'),
 'abc132_a': ('ASSA\n','Yes','S: exactly four uppercase ASCII letters'),
 'abc132_b': ('5\n1 3 5 4 2\n','2','3<=N<=20;P is permutation of 1..N'),
 'abc132_c': ('6\n9 1 4 4 6 7\n','2','2<=N<=100000;N even;1<=di<=100000'),
}
BATCH16 = {pid: {'sample_input': sample, 'sample_output': output,
                 'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                 'constraints': constraints} for pid,(sample,output,constraints) in SAMPLES.items()}
_UINT = re.compile(r'(?:0|[1-9][0-9]*)\Z')
_INT = re.compile(r'(?:0|-?[1-9][0-9]*)\Z')


def _numbers(line: str, length: int, signed: bool=False) -> list[int]:
    fields=line.split()
    pattern = _INT if signed else _UINT
    if len(fields)!=length or any(not pattern.fullmatch(token) for token in fields):
        raise ValueError('integer token/count invalid')
    return [int(v) for v in fields]


def validate(pid: str, data: str):
    if pid not in BATCH16: raise ValueError('unknown task')
    lines=data.strip().splitlines()
    if pid in ('abc131_a','abc132_a'):
        pattern = r'[0-9]{4}' if pid=='abc131_a' else r'[A-Z]{4}'
        if len(lines)!=1 or not re.fullmatch(pattern,lines[0]): raise ValueError('four characters invalid')
        return lines[0]
    if pid=='abc129_c':
        if not lines: raise ValueError('N M missing')
        n,m = _numbers(lines[0],2)
        if not 1<=n<=100000 or not 0<=m<=n-1 or len(lines)!=m+1: raise ValueError('N M or broken count invalid')
        broken=[_numbers(line,1)[0] for line in lines[1:]]
        if any(not 1<=x<=n-1 for x in broken) or broken != sorted(set(broken)):
            raise ValueError('broken steps not strictly increasing')
        return n, broken
    if pid in ('abc129_b','abc130_b','abc132_b','abc132_c'):
        if len(lines)!=2: raise ValueError('two-line array input required')
        if pid=='abc130_b':
            n,x=_numbers(lines[0],2); lo,hi=1,100
            arr=_numbers(lines[1],n) if lo<=n<=hi else []
            if not lo<=n<=hi or not 1<=x<=10000 or any(not 1<=v<=100 for v in arr):
                raise ValueError('bounce bounds invalid')
            return n,x,arr
        n,=_numbers(lines[0],1)
        lo,hi = (2,100) if pid=='abc129_b' else (3,20) if pid=='abc132_b' else (2,100000)
        if not lo<=n<=hi or (pid=='abc132_c' and n%2): raise ValueError('N out of range')
        arr=_numbers(lines[1],n)
        if pid=='abc132_b':
            if set(arr)!=set(range(1,n+1)): raise ValueError('not a permutation')
        elif any(not 1<=x<=(100 if pid=='abc129_b' else 100000) for x in arr):
            raise ValueError('array element out of range')
        return n,arr
    if len(lines)!=1:raise ValueError('one numeric line required')
    if pid=='abc131_b':
        n,l=_numbers(lines[0],2,True)
        if not 2<=n<=200 or not -100<=l<=100: raise ValueError('N or L invalid')
        return n,l
    if pid=='abc129_a':
        args=_numbers(lines[0],3)
        if any(not 1<=x<=100 for x in args): raise ValueError('flight invalid')
        return tuple(args)
    if pid=='abc130_a':
        args=_numbers(lines[0],2)
        if any(not 0<=x<=9 for x in args):raise ValueError('X or A invalid')
        return tuple(args)
    if pid=='abc130_c':
        w,h,x,y=_numbers(lines[0],4)
        if not 1<=w<=10**9 or not 1<=h<=10**9 or not 0<=x<=w or not 0<=y<=h:
            raise ValueError('rectangle invalid')
        return w,h,x,y
    a,b,c,d=_numbers(lines[0],4)
    if not 1<=a<=b<=10**18 or not 1<=c<=10**9 or not 1<=d<=10**9:
        raise ValueError('A B C D invalid')
    return a,b,c,d


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str,str]]:
    if pid not in BATCH16 or not 1<=count<=80: raise ValueError('invalid request')
    rnd=Random(seed);cases=[];seen=set()
    def add(kind: str, value: str):
        validate(pid,value)
        if value not in seen:seen.add(value);cases.append({'category':kind,'input':value})
    def ints(kind: str,*args:int):add(kind,' '.join(map(str,args))+'\n')
    def array(kind: str,values:list[int],header: str|None=None):
        add(kind,(header or str(len(values)))+'\n'+' '.join(map(str,values))+'\n')
    def stairs(kind:str,n:int,broken:list[int]):
        add(kind,f'{n} {len(broken)}\n'+''.join(f'{i}\n' for i in broken))
    add('sample',BATCH16[pid]['sample_input'])
    maximum=''
    if pid=='abc129_a':
        for row in [(1,1,1),(100,100,100),(1,100,100),(100,1,100),(100,100,1),(99,100,100),(1,2,3),(3,2,1),(100,99,98),(1,1,100),(10,20,30),(30,10,20)]:ints('boundary',*row)
        while len(cases)<count:ints('random',*(rnd.randint(1,100) for _ in range(3)))
        maximum='100 100 100\n'
    elif pid=='abc129_b':
        for values in [[1,1],[100,100],[1,100],[100,1],[1,2,3],[1]*100,[100]*100,[1]*99+[100],[100]*99+[1],list(range(1,101)),list(range(100,0,-1)),[1,3,1,1],[27,23,76,2,3,5,62,52]]:array('boundary',values)
        while len(cases)<count:array('random',[rnd.randint(1,100) for _ in range(rnd.randint(2,100))])
        maximum='100\n'+' '.join(['100']*100)+'\n'
    elif pid=='abc129_c':
        for n,b in [(1,[]),(2,[]),(2,[1]),(3,[1]),(3,[2]),(3,[1,2]),(6,[3]),(10,[4,5]),(15,[1,14]),(25,list(range(1,25,2))),(25,list(range(1,25))),(25,[])]:stairs('boundary',n,b)
        while len(cases)<count:
            n=rnd.randint(1,90);b=sorted(rnd.sample(range(1,n),rnd.randrange(n)))
            stairs('random',n,b)
        maximum='100000 99999\n'+''.join(f'{i}\n' for i in range(1,100000))
    elif pid=='abc130_a':
        for row in [(0,0),(0,9),(9,0),(9,9),(1,2),(2,1),(1,1),(8,9),(9,8),(3,5),(7,5),(6,6)]:ints('boundary',*row)
        while len(cases)<count:ints('random',rnd.randrange(10),rnd.randrange(10))
        maximum='9 9\n'
    elif pid=='abc130_b':
        def bounce(kind,n,x,values):array(kind,values,f'{n} {x}')
        for n,x,arr in [(1,1,[1]),(1,1,[100]),(1,10000,[1]),(1,10000,[100]),(3,6,[3,4,5]),(4,9,[3]*4),(100,1,[100]*100),(100,10000,[100]*100),(100,9999,[100]*100),(100,10000,[1]*100),(100,50,[1]*100),(10,9,[1]*10)]:bounce('boundary',n,x,arr)
        while len(cases)<count:
            n=rnd.randint(1,100);bounce('random',n,rnd.randint(1,10000),[rnd.randint(1,100) for _ in range(n)])
        maximum='100 10000\n'+' '.join(['100']*100)+'\n'
    elif pid=='abc130_c':
        for row in [(1,1,0,0),(1,1,1,1),(1,1,0,1),(2,2,1,1),(2,3,1,2),(3,3,1,1),(3,3,0,0),(2,3,2,3),(10**9,10**9,0,0),(10**9,10**9,5*10**8,5*10**8),(10**9,1,5*10**8,0),(1,10**9,0,5*10**8)]:ints('boundary',*row)
        while len(cases)<count:
            w=rnd.randint(1,10**9);h=rnd.randint(1,10**9);ints('random',w,h,rnd.randint(0,w),rnd.randint(0,h))
        maximum='1000000000 1000000000 500000000 500000000\n'
    elif pid=='abc131_a':
        for s in ['0000','9999','0123','8080','3776','0024','1333','1000','0100','0010','0001','1223','1001','9090','1234']:
            add('boundary',s+'\n')
        while len(cases)<count:add('random',''.join(str(rnd.randrange(10)) for _ in range(4))+'\n')
        maximum='9999\n'
    elif pid=='abc131_b':
        for n,l in [(2,-100),(2,100),(200,-100),(200,100),(200,-99),(200,0),(200,1),(2,0),(3,-1),(5,2),(30,-50),(101,-100),(200,-50)]:ints('boundary',n,l)
        while len(cases)<count:ints('random',rnd.randint(2,200),rnd.randint(-100,100))
        maximum='200 100\n'
    elif pid=='abc131_c':
        for row in [(1,1,1,1),(1,10,1,10),(1,10,2,3),(4,9,2,3),(10,40,6,8),(1,10**18,1,1),(1,10**18,10**9,10**9-1),(10**18,10**18,10**9,10**9),(10**18-1,10**18,2,3),(1,10**18,999999937,999999929),(1,10**18,1,10**9),(10**18-100,10**18,7,11)]:ints('boundary',*row)
        while len(cases)<count:
            a=rnd.randint(1,10**18);b=min(10**18,a+rnd.randint(0,10000));ints('random',a,b,rnd.randint(1,10**9),rnd.randint(1,10**9))
        maximum='1 1000000000000000000 1000000000 999999999\n'
    elif pid=='abc132_a':
        for s in ['AAAA','ABCD','ASSA','STOP','FFEE','FREE','AABB','ABAB','ABBA','AABC','AAAB','ABBB','ZZYY','ZYZY','ZZZZ']:
            add('boundary',s+'\n')
        while len(cases)<count:add('random',''.join(rnd.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ',k=4))+'\n')
        maximum='ZZYY\n'
    elif pid=='abc132_b':
        for a in [[1,2,3],[1,3,2],[3,2,1],[1,3,5,4,2],[9,6,3,2,5,8,7,4,1],list(range(1,21)),list(range(20,0,-1)),[2,1,3],[2,3,1],[1,20]+list(range(2,20)),[20,1]+list(range(2,20))]:array('boundary',a)
        while len(cases)<count:
            n=rnd.randint(3,20);array('random',rnd.sample(range(1,n+1),n))
        maximum='20\n'+' '.join(map(str,range(1,21)))+'\n'
    elif pid=='abc132_c':
        for arr in [[1,1],[1,2],[100000,100000],[1,100000],[1,1,2,2],[9,1,4,4,6,7],[9,1,14,5,5,4,4,14],[1]*100000,[100000]*100000,[1]*50000+[100000]*50000,[1,2]*50000,list(range(1,101))]:array('boundary',arr)
        while len(cases)<count:
            n=2*rnd.randint(1,50);array('random',[rnd.randint(1,100000) for _ in range(n)])
        maximum='100000\n'+' '.join(['1']*50000+['100000']*50000)+'\n'
    if include_large:
        cases=[c for c in cases if c['input']!=maximum]
        seen.discard(maximum)
        add('constraint_max',maximum)
    return cases[:count]+([c for c in cases[count:] if c['category']=='constraint_max'] if include_large else [])


def independent_check(pid: str, data: str, expected: str)->bool:
    args=validate(pid,data)
    answer=expected.strip()
    if pid=='abc129_a':
        values=list(args);return answer==str(sum(values)-max(values))
    if pid=='abc129_b':
        _,weights=args
        return answer==str(min(abs(sum(weights[:i])-sum(weights[i:])) for i in range(1,len(weights))))
    if pid=='abc129_c':
        n,broken=args
        # Independent top-down Fibonacci segment multiplication with forced-zero steps.
        prev,cur=0,1
        excluded=set(broken)
        for step in range(1,n+1):
            nxt=(prev+cur)%(10**9+7) if step not in excluded else 0
            prev,cur=cur,nxt
        return answer==str(cur)
    if pid=='abc130_a':
        x,a=args;return answer==('10' if x>=a else '0')
    if pid=='abc130_b':
        _,x,steps=args
        p=0; count=1
        for length in steps:
            p+=length
            if p<=x:count+=1
        return answer==str(count)
    if pid=='abc130_c':
        w,h,x,y=args
        parts=answer.split()
        if len(parts)!=2 or parts[1] not in ('0','1'):return False
        try:area=Decimal(parts[0])
        except InvalidOperation:return False
        target=Decimal(w*h)/2
        tolerance=max(Decimal('0.000000001'),target*Decimal('0.000000001'))
        return area.is_finite() and abs(area-target)<=tolerance and parts[1]==str(int(2*x==w and 2*y==h))
    if pid=='abc131_a':
        return answer==('Bad' if any(args[i]==args[i+1] for i in range(3)) else 'Good')
    if pid=='abc131_b':
        n,l=args
        apples=list(range(l,l+n));omit=min(apples,key=lambda v:abs(v))
        return answer==str(sum(v for v in apples if v!=omit))
    if pid=='abc131_c':
        a,b,c,d=args
        # Count residues by an independent floor-count function and inclusion-exclusion.
        def upto(v):
            both=c//gcd(c,d)*d
            return v-(v//c+v//d-v//both)
        if b-a<=10000:
            return answer==str(sum(x%c!=0 and x%d!=0 for x in range(a,b+1)))
        return answer==str(upto(b)-upto(a-1))
    if pid=='abc132_a':
        counts=Counter(args)
        return answer==('Yes' if len(counts)==2 and set(counts.values())=={2} else 'No')
    if pid=='abc132_b':
        _,p=args
        return answer==str(sum(sorted(p[i-1:i+2])[1]==p[i] for i in range(1,len(p)-1)))
    _,a=args
    if len(a)<=100:
        return answer==str(sum(sum(v<k for v in a)==len(a)//2 for k in range(1,100002)))
    # Counting sort independent of reference's O(N log N) sorting.
    counts=[0]*100002
    for v in a:counts[v]+=1
    less=0;result=0
    for k in range(1,100002):
        less+=counts[k-1]
        if less==len(a)//2:result+=1
    return answer==str(result)
