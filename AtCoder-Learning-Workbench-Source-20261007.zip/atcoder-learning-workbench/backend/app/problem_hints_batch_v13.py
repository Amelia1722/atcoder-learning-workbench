"""Three-level, task-specific hints for the additional 19 ABC bank tasks."""
HINTS_V13 = {
 'abc081_a': (
  '三つのマスのうち、対象になっているマスの数だけを考えてください。',
  '3文字の文字列に含まれる「1」の数を数えれば答えです。',
  '疑似コード:\nS = read_string()\nprint(count_character(S, "1"))'),
 'abc081_b': (
  '全員が同時に次の操作へ進めるのは、どのような状態が続いている間でしょうか。',
  'すべての要素が偶数の間、各要素を2で割って回数を増やします。',
  '疑似コード:\ncount = 0\nwhile every(x % 2 == 0 for x in A):\n  A = [x // 2 for x in A]\n  count += 1\nprint(count)'),
 'abc081_c': (
  '書き換えずに残す種類を選ぶとしたら、どの種類が有利でしょうか。',
  '出現回数を数え、頻度が大きいK種類を残します。残りの種類の頻度を足します。',
  '疑似コード:\nfreq = frequency(A)\ncounts = sort_ascending(freq.values())\nremove = max(0, len(counts) - K)\nprint(sum(counts[:remove]))'),
 'abc083_a': (
  '左右それぞれの重さの合計だけが結果を決めます。',
  'A+B と C+D を大小比較し、3通りの表示を分岐します。',
  '疑似コード:\nleft = A + B\nright = C + D\nif left > right: print("Left")\nelif left < right: print("Right")\nelse: print("Balanced")'),
 'abc083_b': (
  '条件を満たす整数を、1から順に確かめてみてください。',
  '1..Nの各整数の10進法での桁和を求め、A以上B以下なら元の整数を合計します。',
  '疑似コード:\nans = 0\nfor x in 1..N:\n  digit_sum = sum(int(digit) for digit in str(x))\n  if A <= digit_sum <= B: ans += x\nprint(ans)'),
 'abc083_c': (
  '次の数をなるべく小さく増やした方が、長い列を作れるか考えてください。',
  '次の項は直前の2倍以上なので、2倍を続けると最長になります。',
  '疑似コード:\nlength = 0\nwhile X <= Y:\n  length += 1\n  X *= 2\nprint(length)'),
 'abc085_a': (
  '変わるのは日付の全部ではなく、先頭の一部分だけです。',
  '固定の先頭4文字を2018へ差し替え、残りの文字列はそのまま結合します。',
  '疑似コード:\nS = read_string()\nprint("2018" + S[4:])'),
 'abc085_b': (
  '同じ大きさの餅を重複して選ぶ必要があるか考えてください。',
  '異なる直径の個数が最大段数です。setで重複を取り除きます。',
  '疑似コード:\ndiameters = read_N_numbers()\nprint(len(set(diameters)))'),
 'abc086_a': (
  '積全体を計算しなくても、積の偶奇を決める要因がないか考えてください。',
  'どちらも奇数のときだけ積は奇数です。剰余で偶奇を確認します。',
  '疑似コード:\na, b = read_two_integers()\nprint("Odd" if a*b % 2 else "Even")'),
 'abc086_b': (
  '与えられた二つの整数を「足し算」する問題ではありません。',
  'aとbを文字列として連結した後、整数平方根の2乗が元の数に一致するか判定します。',
  '疑似コード:\na, b = read_two_strings()\nx = int(a + b)\nr = integer_sqrt(x)\nprint("Yes" if r*r == x else "No")'),
 'abc086_c': (
  '前の予定から次の予定までに、何歩動けるかと何歩必要かを比較してください。',
  'マンハッタン距離が時間差以下、かつ余った歩数が偶数であることを全区間で判定します。',
  '疑似コード:\nprev_t, prev_x, prev_y = 0,0,0\nfor t,x,y in visits:\n  dt = t-prev_t\n  dist = abs(x-prev_x)+abs(y-prev_y)\n  if dist > dt or (dt-dist)%2: print("No"); stop\n  prev_t,prev_x,prev_y=t,x,y\nprint("Yes")'),
 'abc087_a': (
  '一度買ったあとの残額について、同じ価格の品を可能な限り買う状況です。',
  'XからAを引き、残額をBで割った余りが答えです。',
  '疑似コード:\nX = read_integer()\nA = read_integer()\nB = read_integer()\nprint((X-A)%B)'),
 'abc087_b': (
  '同じ種類の硬貨は区別しないため、種類ごとの使用枚数を決めれば一通りが定まります。',
  '500円・100円の使用枚数を全探索し、残額を50円玉でちょうど作れるか調べます。',
  '疑似コード:\nans = 0\nfor i in 0..A:\n  for j in 0..B:\n    remain = X-500*i-100*j\n    if remain >= 0 and remain % 50 == 0 and remain//50 <= C: ans += 1\nprint(ans)'),
 'abc100_a': (
  '丸く並んだ切れ目を考え、一人が隣接せず取れる最大数を考えてください。',
  '16切れの円では1人が隣接せず取れるのは最大8切れです。AとBがそれぞれ8以下か判定します。',
  '疑似コード:\nA,B = read_two_integers()\nif A<=8 and B<=8: print("Yay!")\nelse: print(":(")'),
 'abc100_b': (
  '一定の数で割り切れる条件を満たす数を小さい順に並べてみてください。途中の例外に注意します。',
  '100のD乗を掛ける数を考えます。100番目だけは100の倍数を一つ飛ばして101とします。',
  '疑似コード:\nD,N = read_two_integers()\nif N==100: N=101\nprint(N*(100**D))'),
 'abc100_c': (
  '全体の操作回数を増やすために、各数のどの特徴が必要か考えてください。',
  '各要素が2で割れる回数（素因数2の指数）を足し合わせます。',
  '疑似コード:\nans=0\nfor x in A:\n  while x%2==0:\n    ans+=1\n    x//=2\nprint(ans)'),
 'abc102_a': (
  '条件の一方が2なので、与えられた値の偶奇で結果がどう変わるか考えます。',
  '2とNの最小公倍数です。Nが偶数ならN、奇数なら2Nです。',
  '疑似コード:\nN=read_integer()\nprint(N if N%2==0 else 2*N)'),
 'abc102_b': (
  '数列のすべての組を比べる代わりに、最も離れた二つの値に注目してください。',
  '配列の最大値と最小値の差を取ります。',
  '疑似コード:\nA=read_array()\nprint(max(A)-min(A))'),
 'abc102_c': (
  '式の中で変えられる数がひとつだけの場合、各項の基準を揃えられないか考えます。',
  'A_i-iの列へ変形すると、共通のbとの絶対差の和を最小化する問題です。中央値をbにします。',
  '疑似コード:\nB=sort([A[i]-i for i in 1..N])\nmedian=B[N//2]\nprint(sum(abs(x-median) for x in B))'),
 'abc001_1': (
  '二つの時刻の値を比べて、増減を表す数値を考えてください。',
  '現在の積雪深から1時間前の積雪深を引きます。負の値もそのまま出力します。',
  '疑似コード:\nnow = read_integer()\nprevious = read_integer()\nprint(now - previous)'),
}
