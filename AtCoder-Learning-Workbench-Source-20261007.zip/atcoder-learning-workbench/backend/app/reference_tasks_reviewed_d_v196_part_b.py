"""Private ABC323..328 D domains, references and independent oracles."""
from __future__ import annotations
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import permutations
from math import isqrt
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{i}_d' for i in range(323,329));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc326_d':'semantic'};CHECKER_IDS={'abc326_d':'abc326_d'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc323_d':
  n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==n+1,'shape');pairs=tuple(ints(r,2) for r in rows[1:]);require(all(1<=s<=10**9 and 1<=c<=10**9 for s,c in pairs) and len({s for s,c in pairs})==n,'slimes');return (pairs,)
 if pid=='abc324_d':n=ints(rows[0],1)[0];require(1<=n<=13 and len(rows)==2 and len(rows[1])==n and re.fullmatch(r'[0-9]+',rows[1]) is not None,'digits');return (rows[1],)
 if pid=='abc325_d':
  n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');products=tuple(ints(r,2) for r in rows[1:]);require(all(1<=t<=10**18 and 1<=d<=10**18 for t,d in products),'products');return (products,)
 if pid=='abc326_d':n=ints(rows[0],1)[0];require(3<=n<=5 and len(rows)==3 and all(len(s)==n and re.fullmatch(r'[ABC]+',s) is not None for s in rows[1:]),'RC');return rows[1],rows[2]
 if pid=='abc327_d':
  n,m=ints(rows[0],2);require(1<=n<=200000 and 1<=m<=200000 and len(rows)==3,'shape');a=ints(rows[1],m);b=ints(rows[2],m);require(all(1<=v<=n for v in a+b),'nodes');return n,tuple(zip(a,b))
 require(len(rows)==1 and re.fullmatch(r'[ABC]{1,200000}',rows[0]) is not None,'S');return (rows[0],)
def slime_odd_mass(pairs:tuple[tuple[int,...],...])->int:
 groups:dict[int,int]=defaultdict(int)
 for size,count in pairs:
  power=size&-size;groups[size//power]+=count*power
 return sum(mass.bit_count() for mass in groups.values())
def digit_square_radix(s:str)->int:
 target=tuple(s.count(str(i)) for i in range(10));maximum=int(''.join(sorted(s,reverse=True)));limit=isqrt(maximum);digits=len(str(limit));candidates=[0];place=1
 def allowed(value:int,length:int)->bool:
  counts=[0]*10
  for _ in range(length):counts[value%10]+=1;value//=10
  return all(a<=b for a,b in zip(counts,target))
 for length in range(1,digits+1):
  modulus=place*10;candidates=[root+d*place for root in candidates for d in range(10) if root+d*place<=limit and allowed((root+d*place)**2%modulus,length)];place=modulus
 return sum(allowed(root*root,len(s)) for root in candidates)
def printing_reverse(products:tuple[tuple[int,...],...])->int:
 intervals=sorted(((t+d,t) for t,d in products),reverse=True);j=0;time=intervals[0][0];heap:list[int]=[];answer=0
 while j<len(intervals) or heap:
  if not heap:time=min(time,intervals[j][0])
  while j<len(intervals) and intervals[j][0]>=time:heapq.heappush(heap,-intervals[j][1]);j+=1
  while heap and -heap[0]>time:heapq.heappop(heap)
  if heap:heapq.heappop(heap);answer+=1;time-=1
 return answer
@lru_cache(maxsize=None)
def abc_color_assignments(r:str,c:str)->tuple[str,...]|None:
 n=len(r);all_permutations=tuple(permutations(range(n)))
 for a in all_permutations:
  inverse_a=[0]*n
  for row,column in enumerate(a):inverse_a[column]=row
  for b in all_permutations:
   if any(x==y for x,y in zip(a,b)):continue
   inverse_b=[0]*n
   for row,column in enumerate(b):inverse_b[column]=row
   if any((letter=='A' and a[i]>b[i]) or (letter=='B' and b[i]>a[i]) for i,letter in enumerate(r)):continue
   if any((letter=='A' and inverse_a[j]>inverse_b[j]) or (letter=='B' and inverse_b[j]>inverse_a[j]) for j,letter in enumerate(c)):continue
   options=[]
   for i,letter in enumerate(r):
    columns=[]
    for j in range(n):
     if j in (a[i],b[i]):continue
     if (letter=='A' and j<a[i]) or (letter=='B' and j<b[i]) or (letter=='C' and j>min(a[i],b[i])):continue
     if (c[j]=='A' and i<inverse_a[j]) or (c[j]=='B' and i<inverse_b[j]) or (c[j]=='C' and i>min(inverse_a[j],inverse_b[j])):continue
     columns.append(j)
    options.append(columns)
   assignment=[-1]*n;order=sorted(range(n),key=lambda i:len(options[i]))
   def match(position:int,used:int)->bool:
    if position==n:return True
    row=order[position]
    for column in options[row]:
     if not used>>column&1:
      assignment[row]=column
      if match(position+1,used|1<<column):return True
    return False
   if match(0,0):
    grid=[['.']*n for _ in range(n)]
    for i in range(n):grid[i][a[i]]='A';grid[i][b[i]]='B';grid[i][assignment[i]]='C'
    return tuple(''.join(row) for row in grid)
 return None
def abc_grid_valid(r:str,c:str,actual:str)->bool:
 rows=actual.removesuffix('\n').split('\n');n=len(r)
 if rows==['No']:return abc_color_assignments(r,c) is None
 if len(rows)!=n+1 or rows[0]!='Yes' or any(len(s)!=n or re.fullmatch(r'[ABC.]+',s) is None for s in rows[1:]):return False
 grid=rows[1:]
 for i in range(n):
  row=grid[i].replace('.','');column=''.join(grid[j][i] for j in range(n)).replace('.','')
  if sorted(row)!=list('ABC') or sorted(column)!=list('ABC') or row[0]!=r[i] or column[0]!=c[i]:return False
 return True
def bipartite_double_cover(n:int,edges:tuple[tuple[int,...],...])->bool:
 parent=list(range(2*n));sizes=[1]*(2*n)
 def root(v:int)->int:
  while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
  return v
 def merge(a:int,b:int)->None:
  aa,bb=root(a),root(b)
  if aa==bb:return
  if sizes[aa]<sizes[bb]:aa,bb=bb,aa
  parent[bb]=aa;sizes[aa]+=sizes[bb]
 for u,v in edges:merge(u-1,v-1+n);merge(u-1+n,v-1)
 return all(root(v)!=root(v+n) for v in range(n))
def abc_leftmost_links(s:str)->str:
 n=len(s);previous=list(range(-1,n-1));following=list(range(1,n))+[-1];alive=bytearray([1])*n;heap=[]
 def match(i:int)->bool:
  if i<0 or not alive[i] or s[i]!='A':return False
  j=following[i]
  if j<0 or s[j]!='B':return False
  k=following[j];return k>=0 and s[k]=='C'
 for i in range(n):
  if match(i):heap.append(i)
 heapq.heapify(heap)
 while heap:
  i=heapq.heappop(heap)
  if not match(i):continue
  j=following[i];k=following[j];left=previous[i];right=following[k];alive[i]=alive[j]=alive[k]=0
  if left>=0:following[left]=right
  if right>=0:previous[right]=left
  for candidate in (left,previous[left] if left>=0 else -1):
   if match(candidate):heapq.heappush(heap,candidate)
 return ''.join(c for i,c in enumerate(s) if alive[i])
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc323_d':return str(slime_odd_mass(cast(tuple[tuple[int,...],...],d[0])))+'\n'
 if pid=='abc324_d':return str(digit_square_radix(cast(str,d[0])))+'\n'
 if pid=='abc325_d':return str(printing_reverse(cast(tuple[tuple[int,...],...],d[0])))+'\n'
 if pid=='abc326_d':grid=abc_color_assignments(cast(str,d[0]),cast(str,d[1]));return 'Yes\n'+'\n'.join(grid)+'\n' if grid is not None else 'No\n'
 if pid=='abc327_d':return ('Yes' if bipartite_double_cover(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])) else 'No')+'\n'
 return abc_leftmost_links(cast(str,d[0]))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc326_d':return abc_grid_valid(cast(str,d[0]),cast(str,d[1]),actual)
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc323_d':'''import heapq
n=int(input());counts={}
for _ in range(n):s,c=map(int,input().split());counts[s]=c
heap=list(counts);heapq.heapify(heap);answer=0
while heap:
 size=heapq.heappop(heap);count=counts.pop(size);answer+=count%2
 if count//2:
  if 2*size not in counts:counts[2*size]=0;heapq.heappush(heap,2*size)
  counts[2*size]+=count//2
print(answer)
''',
'abc324_d':'''from math import isqrt
n=int(input());s=input();target=''.join(sorted(s));answer=0
for root in range(isqrt(10**n-1)+1):
 if ''.join(sorted(str(root*root).zfill(n)))==target:answer+=1
print(answer)
''',
'abc325_d':'''import sys,heapq
read=sys.stdin.buffer.readline;n=int(read());products=sorted(tuple(map(int,read().split())) for _ in range(n));heap=[];j=0;time=0;answer=0
while j<n or heap:
 if not heap:time=max(time,products[j][0])
 while j<n and products[j][0]<=time:t,d=products[j];heapq.heappush(heap,t+d);j+=1
 while heap and heap[0]<time:heapq.heappop(heap)
 if heap:heapq.heappop(heap);answer+=1;time+=1
print(answer)
''',
'abc326_d':'''from itertools import permutations
n=int(input());r=input();c=input();patterns=[]
for row in range(n):
 options=[]
 for columns in permutations(range(n),3):
  cells=['.']*n
  for char,column in zip('ABC',columns):cells[column]=char
  if next(ch for ch in cells if ch!='.')==r[row]:options.append(''.join(cells))
 patterns.append(options)
answer=[];masks=[0]*n
def search(row):
 if row==n:return all(mask==7 for mask in masks)
 for cells in patterns[row]:
  valid=True
  for column,char in enumerate(cells):
   if char=='.':continue
   bit=1<<('ABC'.index(char))
   if masks[column]&bit or (masks[column]==0 and char!=c[column]):valid=False;break
  if not valid:continue
  for column,char in enumerate(cells):
   if char!='.':masks[column]|=1<<('ABC'.index(char))
  answer.append(cells)
  if search(row+1):return True
  answer.pop()
  for column,char in enumerate(cells):
   if char!='.':masks[column]^=1<<('ABC'.index(char))
 return False
if search(0):print('Yes');print('\\n'.join(answer))
else:print('No')
''',
'abc327_d':'''from collections import deque
n,m=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));adj=[[] for _ in range(n)]
for u,v in zip(a,b):adj[u-1].append(v-1);adj[v-1].append(u-1)
colors=[-1]*n;ok=True
for start in range(n):
 if colors[start]!=-1:continue
 colors[start]=0;queue=deque([start])
 while queue:
  v=queue.popleft()
  for u in adj[v]:
   if colors[u]==-1:colors[u]=1-colors[v];queue.append(u)
   elif colors[u]==colors[v]:ok=False
print('Yes' if ok else 'No')
''',
'abc328_d':'''s=input();stack=[]
for char in s:
 stack.append(char)
 if len(stack)>=3 and stack[-3:]==['A','B','C']:del stack[-3:]
print(''.join(stack))
'''}
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'pid');rng=random.Random(196000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc323_d':
  def slimes(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
  raws=[slimes([(1,1)]),slimes([(1,2)]),slimes([(1,1),(2,1),(3,1)]),slimes([(3,3),(5,1),(6,1)])]
  for n in range(2,14):sizes=rng.sample(range(1,10000),n);raws.append(slimes([(s,rng.randint(1,10**9)) for s in sizes]))
  raws+=[slimes([(1<<j,10**9) for j in range(30)]),slimes([(10**9-i,10**9) for i in range(100000)])]
 elif pid=='abc324_d':raws=[f'{len(s)}\n{s}\n' for s in ['0','1','2','9','010','4320','00','81','100','101','1234','000001','999999','112233','0000000000000','9999999999999','8694027811503','9876543210000']]
 elif pid=='abc325_d':
  def products(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(p) for p in a)
  raws=[products([(1,1)]),products([(1,1)]*3),products([(1,1),(3,1)]),products([(1,1),(10**18,10**18)])]
  for n in range(2,14):raws.append(products([(rng.randint(1,30),rng.randint(1,30)) for _ in range(n)]))
  raws+=[products([(10**18,1)]*200000),products([(10**18-i,10**18) for i in range(200000)])]
 elif pid=='abc326_d':
  pairs=[('AAA','AAA'),('ABC','ABC'),('ABC','ACB'),('AAA','BBB'),('ABCBC','ACAAB'),('ABCA','ABCA'),('ABCA','ACBA'),('AAAA','AAAA'),('BBBB','BBBB'),('CCCC','CCCC'),('ABCAB','ABCAB'),('ACBAC','ACBAC'),('CABCA','CABCA'),('BBCAA','CACAB'),('AAAAA','BBBBB'),('CCCCC','AAAAA'),('ABCBC','ACBAC'),('CCCCC','CCCCC')]
  raws=[f'{len(r)}\n{r}\n{c}\n' for r,c in pairs]
 elif pid=='abc327_d':
  def graph(n:int,edges:list[tuple[int,int]])->str:return f'{n} {len(edges)}\n'+line([u for u,v in edges])+line([v for u,v in edges])
  raws=[graph(1,[(1,1)]),graph(2,[(1,2)]),graph(2,[(1,2)]*3),graph(3,[(1,2),(2,3),(3,1)])]
  for n in range(3,15):raws.append(graph(n,[(rng.randint(1,n),rng.randint(1,n)) for _ in range(n)]))
  raws+=[graph(200000,[(i,i+1) for i in range(1,200000)]+[(1,200000)]),graph(200000,[(i,i) for i in range(1,200001)])]
 else:raws=[s+'\n' for s in ['A','B','C','ABC','ABCABC','AABCBC','ABABC','BAABCBCCABCAC','ABCCABC','AAA','BBB','CCC','CABACBC','CBAABCABCAB','AAABCABCABCAABCABCBBBAABCBCCCAAABCBCBCC','A'*66666+'BC'*66666,'ABC'*66666+'AB','C'*200000]]
 require(len(raws)==len(set(raws))==18,'18distinct')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'adversarial_{i:02}'} for i,raw in enumerate(raws)]
HINTS={
'abc323_d':('同じサイズの匹数をまとめ、小さいサイズから合成します。','個数がcならc//2匹を倍のサイズへ送り、c%2匹だけ残ります。優先度付きキューで未処理の最小サイズを取り出します。','疑似コード: counts[S]=C、heapに全S; 最小Sをpopしcを削除; answer+=c%2; c//2>0ならcounts[2S]へ加算し、新規ならheap追加; answer出力。'),
'abc324_d':('N桁以下の平方数の平方根は、およそ10^(N/2)以下です。','平方数を列挙し、先頭を0で埋めてN桁にします。数字をソートしたものがSと同じなら、その整数を一度数えます。','疑似コード: target=sort(S); root=0..整数平方根(10^N-1)でdigits=平方数をN桁0埋め; sort(digits)==targetならanswer++; answer出力。'),
'abc325_d':('時間を早い方から進め、今印字できる商品を管理します。','印字可能な商品の中で退出時刻が最も早いものを選びます。候補がなければ次の入場時刻まで飛ばせます。退出瞬間も印字できます。','疑似コード: T順sort; heap空ならtimeを次Tへ; T<=timeの商品をheapへ退出T+Dで追加; 退出<timeは除く; heap非空なら最小退出を印字answer++、time++; answer出力。'),
'abc326_d':('各行にA,B,Cを一つずつ置く位置を列挙します。','行の最初の文字がRに合う候補だけを残し、列で文字が重複しないことと、最初の文字がCに合うことを確認しながら探索します。','疑似コード: 各行でABCの異なる3列を列挙し左端R一致なら候補; 行ごとDFSで列mask重複と未使用列の先頭Cを検査; 全行後全mask=ABCならYesと盤面、全失敗No。'),
'abc327_d':('各条件は二つの頂点の色が異なることを意味します。','無向グラフを作り、隣接頂点へ反対の色を付けます。すでに同じ色なら条件を満たせません。','疑似コード: 全未彩色頂点を始点にBFS; 隣u未彩色ならcolor[u]=1-color[v]、同色なら失敗; 全条件矛盾なしYes、他No。'),
'abc328_d':('文字を左から積み、末尾がABCになったら消します。','削除によって新しくできるABCも、次の文字を積む過程で見つかります。残す文字だけをスタックに持ちます。','疑似コード: stack=[]; 各文字をappend; 末尾3文字がABCならpop3回; 最後stackを連結して出力。')}

TITLES={'abc323_d': 'Merge Slimes', 'abc324_d': 'Square Permutation', 'abc325_d': 'Printing Machine', 'abc326_d': 'ABC Puzzle', 'abc327_d': 'Good Tuple Problem', 'abc328_d': 'Take ABC'}
PUBLISHED_SAMPLES={'abc323_d': [{'input': '3\n3 3\n5 1\n6 1\n', 'expected': '3\n'}, {'input': '3\n1 1\n2 1\n3 1\n', 'expected': '3\n'}, {'input': '1\n1000000000 1000000000\n', 'expected': '13\n'}], 'abc324_d': [{'input': '4\n4320\n', 'expected': '2\n'}, {'input': '3\n010\n', 'expected': '2\n'}, {'input': '13\n8694027811503\n', 'expected': '840\n'}], 'abc325_d': [{'input': '5\n1 1\n1 1\n2 1\n1 2\n1 4\n', 'expected': '4\n'}, {'input': '2\n1 1\n1000000000000000000 1000000000000000000\n', 'expected': '2\n'}, {'input': '10\n4 1\n1 2\n1 4\n3 2\n5 1\n5 1\n4 1\n2 1\n4 1\n2 4\n', 'expected': '6\n'}], 'abc326_d': [{'input': '5\nABCBC\nACAAB\n', 'expected': 'Yes\nAC..B\n.BA.C\nC.BA.\nBA.C.\n..CBA\n'}, {'input': '3\nAAA\nBBB\n', 'expected': 'No\n'}], 'abc327_d': [{'input': '3 2\n1 2\n2 3\n', 'expected': 'Yes\n'}, {'input': '3 3\n1 2 3\n2 3 1\n', 'expected': 'No\n'}, {'input': '10 1\n1\n1\n', 'expected': 'No\n'}, {'input': '7 8\n1 6 2 7 5 4 2 2\n3 2 7 2 1 2 3 3\n', 'expected': 'Yes\n'}], 'abc328_d': [{'input': 'BAABCBCCABCAC\n', 'expected': 'BCAC\n'}, {'input': 'ABCABC\n', 'expected': '\n'}, {'input': 'AAABCABCABCAABCABCBBBAABCBCCCAAABCBCBCC\n', 'expected': 'AAABBBCCC\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
