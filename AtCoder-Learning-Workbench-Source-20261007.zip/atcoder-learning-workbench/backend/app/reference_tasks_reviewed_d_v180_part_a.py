"""Reviewed legacy D with strict modular-domain and equation-residual judges."""
from __future__ import annotations
from decimal import Decimal,localcontext,DecimalException
from functools import lru_cache
from heapq import nlargest
from itertools import permutations
from math import sin,pi
from typing import cast
import random,re
TASKS=tuple(f'abc{n:03}_d' for n in range(23,29))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc026_d':'semantic','abc028_d':'numeric_tolerance_1e-9'}
CHECKER_IDS={'abc026_d':'abc026_d'}
Case=dict[str,str]
Data=tuple[object,...]
MOD=1000000007
PI=Decimal('3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679')

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

@lru_cache(maxsize=1024)
def choose_mod(n:int,k:int)->int:
    k=min(k,n-k);num=den=1
    for j in range(1,k+1):num=num*(n-k+j)%MOD;den=den*j%MOD
    return num*pow(den,MOD-2,MOD)%MOD

def grid_values(r:int,c:int)->tuple[int,int,int]:
    a=choose_mod(r+c,r);return a,a*(r+c+1)*pow(c+1,MOD-2,MOD)%MOD,a*(r+c+1)*pow(r+1,MOD-2,MOD)%MOD

def recover(a:int,b:int,c:int)->tuple[int,int]:
    determinant=(a*(b+c)-b*c)%MOD;require(determinant!=0,'grid inverse');inverse=pow(determinant,MOD-2,MOD);return c*(b-a)*inverse%MOD,b*(c-a)*inverse%MOD

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==23:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=h<=10**9 and 1<=s<=10**9 for h,s in a),'balloons');return (a,)
    if number==24:
        require(len(rows)==3,'shape');a,b,c=(ints(row,1)[0] for row in rows);require(all(0<=v<MOD for v in (a,b,c)),'grid residues');r,col=recover(a,b,c);require(0<=r<99999999 and 0<=col<99999999,'grid position');require(grid_values(r,col)==(a,b,c),'original binomial grid guarantee');return a,b,c
    if number==25:
        require(len(rows)==5,'shape');a=tuple(v for row in rows for v in ints(row,5));known=[v for v in a if v];require(all(0<=v<=25 for v in a) and len(known)>=5 and len(set(known))==len(known),'fixed board');return (a,)
    if number==26:
        require(len(rows)==1,'shape');a=ints(rows[0],3);require(all(1<=v<=100 for v in a),'curve');return a
    if number==27:
        require(len(rows)==1 and 1<=len(rows[0])<=100000 and set(rows[0])<=set('M+-') and rows[0].count('M')%2==0,'commands');return (rows[0],)
    require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=k<=n<=10**6,'median');return n,k

TRIPLES=tuple([(5*r+c,5*r+c+1,5*r+c+2) for r in range(5) for c in range(3)]+[(5*r+c,5*r+c+5,5*r+c+10) for r in range(3) for c in range(5)])

def board_count(a:tuple[int,...])->int:
    if any(a[x] and a[y] and a[z] and (a[x]<a[y]<a[z] or a[x]>a[y]>a[z]) for x,y,z in TRIPLES):return 0
    empty=[j for j,v in enumerate(a) if not v];missing=[v for v in range(1,26) if v not in a]
    if len(empty)<=8:
        board=list(a);answer=0
        for values in permutations(missing):
            for j,v in zip(empty,values):board[j]=v
            answer+=not any(board[x]<board[y]<board[z] or board[x]>board[y]>board[z] for x,y,z in TRIPLES)
        return answer%MOD
    # Descending labels with explicit triple middle/rank predicates. The
    # standalone reference grows an ascending occupancy mask with bit partners.
    fixed={v:j for j,v in enumerate(a) if v};unknown=[j for j,v in enumerate(a) if not v];triples=[[(x,y,z) for x,y,z in TRIPLES if y==j] for j in range(25)];full=(1<<25)-1
    @lru_cache(None)
    def count(larger:int)->int:
        label=25-larger.bit_count()
        if label==0:return 1
        candidates=(fixed[label],) if label in fixed else unknown;answer=0
        for j in candidates:
            bit=1<<j
            if larger&bit:continue
            if any(bool(larger>>x&1)!=bool(larger>>z&1) for x,y,z in triples[j]):continue
            answer+=count(larger|bit)
        return answer%MOD
    return count(0)

def decimal_sin(value:Decimal)->Decimal:
    with localcontext() as context:
        context.prec=90;value=value%(2*PI)
        if value>PI:value-=2*PI
        term=value;total=value;square=value*value;j=1
        while abs(term)>Decimal('1e-85'):term=-term*square/Decimal((2*j)*(2*j+1));total+=term;j+=1
        return +total

def finite_decimal(actual:str)->Decimal|None:
    token=actual.removesuffix('\n')
    if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return None
    try:
        value=Decimal(token)
        return value if value.is_finite() else None
    except DecimalException:return None

def equation_valid(raw:str,actual:str)->bool:
    try:
        a,b,c=cast(tuple[int,int,int],validate('abc026_d',raw));t=finite_decimal(actual)
        if t is None or t<0:return False
        with localcontext() as context:
            context.prec=4096
            if t>(Decimal(100+b)+Decimal('1e-6'))/Decimal(a):return False
            phase=Decimal(c)*t;doubled=phase*2
            value=Decimal((0,1,0,-1)[int(doubled)%4]) if doubled==doubled.to_integral_value() else decimal_sin(phase*PI)
            residual=Decimal(a)*t+Decimal(b)*value-100;return abs(residual)<=Decimal('1e-6')
    except (ValueError,TypeError,IndexError,DecimalException,OverflowError):return False

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==23:
        a=cast(tuple[tuple[int,int],...],data[0]);n=len(a)
        def possible(bound:int)->bool:
            slots=[0]*n
            for h,s in a:
                if h>bound:return False
                slots[min(n-1,(bound-h)//s)]+=1
            # Each deadline prefix imposes a Hall bound on available slots.
            used=0
            for j,count in enumerate(slots):
                used+=count
                if used>j+1:return False
            return True
        left=max(h for h,s in a)-1;right=max(h+s*(n-1) for h,s in a)
        while right-left>1:
            middle=(left+right)//2
            if possible(middle):right=middle
            else:left=middle
        return str(right)
    if number==24:
        a,b,c=cast(tuple[int,int,int],data);u=b*pow(a,MOD-2,MOD)%MOD;v=c*pow(a,MOD-2,MOD)%MOD;iv=pow(v,MOD-2,MOD);iu=pow(u,MOD-2,MOD);s=pow((iu+iv-1)%MOD,MOD-2,MOD);return f'{(s*iv-1)%MOD} {(s*iu-1)%MOD}'
    if number==25:return str(board_count(cast(tuple[int,...],data[0])))
    if number==26:
        a,b,c=cast(tuple[int,int,int],data)
        with localcontext() as context:
            context.prec=80;lo=Decimal(0);hi=Decimal(200)
            for _ in range(170):
                mid=(lo+hi)/2
                if a*mid+b*decimal_sin(c*mid*PI)<100:lo=mid
                else:hi=mid
            return str((lo+hi)/2)
    if number==27:
        s=cast(str,data[0]);prefix=0;weights=[]
        for ch in s:
            if ch=='M':weights.append(prefix)
            else:prefix+=1 if ch=='+' else -1
        return str(2*sum(nlargest(len(weights)//2,weights))-sum(weights))
    n,k=cast(tuple[int,int],data)
    # Difference of two median CDF numerators, independently of event categories.
    count=(3*k*k*n-2*k*k*k)-(3*(k-1)**2*n-2*(k-1)**3)
    with localcontext() as context:context.prec=100;return str(Decimal(count)/Decimal(n**3))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc026_d':return equation_valid(raw,actual)
    try:
        expected=oracle(pid,raw)
        if pid=='abc028_d':
            value=finite_decimal(actual)
            if value is None:return False
            with localcontext() as context:context.prec=4096;target=Decimal(expected);return abs(value-target)<=max(Decimal('1e-9'),Decimal('1e-9')*abs(target))
        return actual.removesuffix('\n')==expected
    except (ValueError,IndexError,TypeError,DecimalException,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid in OUTPUT_MODES:return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc023_d':"n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];lo=0;hi=max(h+s*(n-1) for h,s in a)\ndef feasible(value):\n if any(h>value for h,s in a):return False\n return all(deadline>=j for j,deadline in enumerate(sorted((value-h)//s for h,s in a)))\nwhile lo<hi:\n mid=(lo+hi)//2\n if feasible(mid):hi=mid\n else:lo=mid+1\nprint(lo)\n",
'abc024_d':"p=1000000007;a=int(input());b=int(input());c=int(input());inverse=pow((a*(b+c)-b*c)%p,p-2,p);print(c*(b-a)*inverse%p,b*(c-a)*inverse%p)\n",
'abc025_d':"from functools import lru_cache\np=1000000007;a=[int(v) for _ in range(5) for v in input().split()];fixed={v:j for j,v in enumerate(a) if v};empty=[j for j,v in enumerate(a) if not v];pairs=[[] for _ in range(25)]\nfor j in range(25):\n if 0<j%5<4:pairs[j].append((1<<(j-1))|(1<<(j+1)))\n if 5<=j<20:pairs[j].append((1<<(j-5))|(1<<(j+5)))\n@lru_cache(None)\ndef solve(mask):\n value=mask.bit_count()+1\n if value==26:return 1\n answer=0\n for j in ((fixed[value],) if value in fixed else empty):\n  bit=1<<j\n  if mask&bit:continue\n  if any((mask&pair)!=0 and (mask&pair)!=pair for pair in pairs[j]):continue\n  answer+=solve(mask|bit)\n return answer%p\nprint(solve(0))\n",
'abc026_d':"from math import sin,pi\na,b,c=map(int,input().split());lo=0.0;hi=200.0\nfor _ in range(100):\n mid=(lo+hi)/2\n if a*mid+b*sin(c*mid*pi)<100:lo=mid\n else:hi=mid\nprint((lo+hi)/2)\n",
'abc027_d':"s=input();suffix=0;weights=[]\nfor ch in reversed(s):\n if ch=='M':weights.append(suffix)\n elif ch=='+':suffix+=1\n else:suffix-=1\nweights.sort();half=len(weights)//2;print(sum(weights[half:])-sum(weights[:half]))\n",
'abc028_d':"n,k=map(int,input().split());ways=6*(k-1)*(n-k)+3*(n-1)+1;print(ways/n**3)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(18000+number)
    if number==23:
        def balloons(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[balloons(a) for a in ([(1,1)],[(1,10**9)],[(1,1),(1,1)],[(100,1),(1,100)])];raws.extend(balloons([(rng.randint(1,1000),rng.randint(1,1000)) for _ in range(n)]) for n in range(3,15));raws.extend([balloons([(1,10**9)]*100000),balloons([(10**9,10**9)]*100000)])
    elif number==24:
        positions=[(0,0),(0,1),(1,0),(1,1)]+[(n,n+1) for n in range(2,13)]+[(0,99999998),(99999998,99999998),(99999998,0)];raws=[''.join(f'{v}\n' for v in grid_values(r,c)) for r,c in positions]
    elif number==25:
        full=(1,25,2,24,3,23,4,22,5,21,6,20,7,19,8,18,9,17,10,16,11,15,12,14,13)
        def board(a:list[int]|tuple[int,...])->str:return ''.join(line(a[j:j+5]) for j in range(0,25,5))
        raws=[board([1,2,3,4,5]+[0]*20),board(list(range(1,26))),board([v if j!=0 else 0 for j,v in enumerate(full)]),board([v if j not in (0,1) else 0 for j,v in enumerate(full)])]
        for count in range(3,15):
            omitted=set(rng.sample(range(25),min(count,8)));raws.append(board([0 if j in omitted else v for j,v in enumerate(full)]))
        raws.extend([board([v if j in (0,1,2,3,4) else 0 for j,v in enumerate(full)]),board(full[::-1])])
    elif number==26:
        triples=[(1,1,1),(1,100,100),(100,1,1),(1,100,1)]+[(rng.randint(1,100),rng.randint(1,100),rng.randint(1,100)) for _ in range(12)]+[(1,99,100),(100,100,100)];raws=[line(v) for v in triples]
    elif number==27:
        raws=[s+'\n' for s in ('+','-','MM','M+M')]
        for n in range(3,15):
            s=''.join(rng.choice('M+-') for _ in range(n));s+='M' if s.count('M')%2 else '';raws.append(s+'\n')
        raws.extend(['M+'*50000+'\n','M'*100000+'\n'])
    else:raws=[line(v) for v in ((1,1),(2,1),(2,2),(3,2))];raws.extend(line((n,rng.randint(1,n))) for n in range(4,16));raws.extend([line((10**6,500000)),line((10**6,10**6))])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc023_d':('得点の上限Xを決めると、各風船をいつまでに割るべきか分かります。','締切時刻を昇順に並べ、j番目の風船を時刻jで割れるか調べます。','疑似コード: feasible(X)はH>Xならfalse; deadline=(X-H)//Sをsort; 全jでdeadline[j]>=jを確認; feasibleとなる最小Xをbinary search。'),
'abc024_d':('隣のマスとの二項係数の比から、座標の関係を作れます。','A(r+c+1)=B(c+1)、A(r+c+1)=C(r+1)をmod上の連立一次方程式として解きます。','疑似コード: den=A(B+C)-BC; inv=pow(den,mod-2,mod); r=C(B-A)*inv mod、c=B(C-A)*inv modを出力。'),
'abc025_d':('小さい整数から置いたマス集合を状態にします。','中央のマスへ置くとき、左右や上下の片方だけが既に置かれているなら、単調な3連続が発生します。','疑似コード: DP(mask)で次の数=popcount(mask)+1; 固定マスまたは未固定マス候補へ; 両隣の占有が同じなら追加maskへ遷移; 全配置の個数をmodで合計。'),
'abc026_d':('f(0)<100、f(200)>=100なので、その区間に少なくとも1つの解があります。','連続性を使い、f(left)<100<=f(right)を維持して区間を半分にします。単調でなくてもこの不変条件は保てます。','疑似コード: lo=0,hi=200; mid=(lo+hi)/2; f(mid)<100ならlo=mid、他はhi=mid; 十分反復してmidを出力。'),
'abc027_d':('各移動は、それ以降の+と-の差に応じた幸福度を生みます。','原点へ戻るため、正向きと負向きの移動は同数です。影響が大きい半分を正向きにします。','疑似コード: 右から+/-差suffixを数えMごとに保存; sort(weights); 上半分の和から下半分の和を引いて出力。'),
'abc028_d':('中央値がKになる場合を、3値が異なる場合とKが複数ある場合に分けます。','K未満とK超の値を1個ずつ選ぶ場合は6通りの順序です。Kが2個以上の場合も足します。','疑似コード: ways=6(K-1)(N-K)+3(N-1)+1; ways/N^3を十分な精度で出力。')}

TITLES={'abc023_d': '射撃王', 'abc024_d': '動的計画法', 'abc025_d': '25個の整数', 'abc026_d': '高橋君ボール1号', 'abc027_d': 'ロボット', 'abc028_d': '乱数生成'}
PUBLISHED_SAMPLES={'abc023_d': [{'input': '4\n5 6\n12 4\n14 7\n21 2\n', 'expected': '23\n'}, {'input': '6\n100 1\n100 1\n100 1\n100 1\n100 1\n1 30\n', 'expected': '105\n'}], 'abc024_d': [{'input': '15\n35\n21\n', 'expected': '4 2\n'}, {'input': '126\n252\n210\n', 'expected': '5 4\n'}, {'input': '144949225\n545897619\n393065978\n', 'expected': '314159 365358\n'}], 'abc025_d': [{'input': '0 0 15 2 7\n0 0 16 1 22\n20 25 4 19 0\n3 23 9 18 10\n17 0 5 21 8\n', 'expected': '2\n'}, {'input': '10 14 13 15 11\n16 0 17 0 18\n0 19 0 20 9\n21 12 22 0 23\n0 24 0 25 0\n', 'expected': '40320\n'}, {'input': '1 2 3 4 5\n6 7 8 9 10\n11 12 13 14 15\n16 17 18 19 20\n0 0 0 0 0\n', 'expected': '0\n'}, {'input': '1 25 2 24 3\n23 4 22 5 21\n6 20 7 19 8\n18 9 17 10 16\n11 15 12 14 13\n', 'expected': '1\n'}], 'abc026_d': [{'input': '1 1 1\n', 'expected': '100\n'}, {'input': '53 82 49\n', 'expected': '1.63372043395339\n'}], 'abc027_d': [{'input': 'M+MM-M\n', 'expected': '2\n'}, {'input': 'MMM+M\n', 'expected': '1\n'}, {'input': 'MMM+--MMM\n', 'expected': '3\n'}, {'input': '+\n', 'expected': '0\n'}], 'abc028_d': [{'input': '3 2\n', 'expected': '0.48148148148148148148\n'}, {'input': '3 1\n', 'expected': '0.25925925925925925926\n'}, {'input': '765 573\n', 'expected': '0.00147697396984624371\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
