"""Reviewed ABC080--097 C: canonical inputs and separate reference/oracle methods."""
from __future__ import annotations
from collections import Counter, deque
from functools import lru_cache
from heapq import nlargest
from itertools import combinations, product
from typing import cast
import random
import re

TASKS = ('abc080_c', 'arc086_a', 'arc087_a', 'arc088_a', 'abc084_c', 'abc085_c', 'arc089_a', 'arc090_a', 'arc091_a', 'arc092_a', 'arc093_a', 'arc094_a', 'arc095_a', 'arc096_a', 'abc096_c', 'arc097_a', 'arc098_a', 'abc099_c')
NUMBERS = dict(zip(TASKS, (*range(80,88),*range(90,100)), strict=True))
CONTESTS = {p:f'abc{n:03}' for p,n in NUMBERS.items()}
LANES = {chr(65+i):TASKS[3*i:3*i+3] for i in range(6)}
OUTPUT_MODES = {'abc085_c':'semantic'}
Case = dict[str,str]
Data = tuple[object,...]
Pair = tuple[int,int]

def require(condition: bool, label: str) -> None:
    if not condition: raise ValueError(label)

def ints(row: str, count: int | None = None) -> tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    values=tuple(map(int,row.split(' ')))
    require(count is None or len(values)==count,'field count')
    return values

def validate(pid: str, raw: str) -> Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank line');i=NUMBERS[pid]
    if i in (83,85,90,93,95):
        require(len(rows)==1,'shape');a=ints(rows[0],5 if i==95 else 3 if i==93 else 2)
        if i==83: require(1<=a[0]<=a[1]<=10**18,'gifts')
        elif i==85:require(1<=a[0]<=2000 and 1000<=a[1]<=20000000 and a[1]%1000==0,'banknotes')
        elif i==90:require(all(1<=v<=10**9 for v in a),'grid size')
        elif i==93:require(all(0<=v<=50 for v in a),'integers')
        else:require(all(1<=v<=5000 for v in a[:3]) and all(1<=v<=100000 for v in a[3:]),'pizzas')
        return a
    if i==88:
        require(len(rows)==3,'shape');grid=tuple(ints(r,3) for r in rows)
        require(all(0<=v<=100 for r in grid for v in r),'grid values');return (grid,)
    if i==96:
        h,w=ints(rows[0],2);require(1<=h<=50 and 1<=w<=50 and len(rows)==h+1,'shape')
        require(all(len(r)==w and set(r)<={'#','.'} for r in rows[1:]),'cells');return h,w,tuple(rows[1:])
    if i==97:
        require(len(rows)==2 and re.fullmatch('[a-z]{1,5000}',rows[0]) is not None,'substring')
        k=ints(rows[1],1)[0];require(1<=k<=5,'rank')
        require(len({rows[0][a:a+b] for a in range(len(rows[0])) for b in range(1,k+1) if a+b<=len(rows[0])})>=k,'rank exists')
        return rows[0],k
    if i==98:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0]
        require(2<=n<=300000 and len(rows[1])==n and set(rows[1])<={'E','W'},'directions');return n,rows[1]
    if i==99:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=100000,'withdrawal');return (n,)
    if i==81:
        n,k=ints(rows[0],2);require(1<=k<=n<=200000 and len(rows)==2,'shape');a=ints(rows[1],n)
        require(all(1<=v<=n for v in a),'values');return n,k,a
    n=ints(rows[0],1)[0]
    if i in (82,92,94):
        require((2<=n<=200000 and n%2==0) if i==94 else (2<=n<=100000 if i==92 else 1<=n<=100000),'size')
        require(len(rows)==2,'shape');a=ints(rows[1],n)
        require(all(-5000<=v<=5000 for v in a) if i==92 else all(1<=v<=10**9 for v in a),'values');return n,a
    if i==80:
        require(1<=n<=100 and len(rows)==1+2*n,'shape')
        f=tuple(ints(r,10) for r in rows[1:n+1]);p=tuple(ints(r,11) for r in rows[n+1:])
        require(all(set(r)<={0,1} and sum(r)>0 for r in f),'open periods')
        require(all(-10**7<=v<=10**7 for r in p for v in r),'profits');return n,f,p
    if i==84:
        require(1<=n<=500 and len(rows)==n,'shape');legs=tuple(ints(r,3) for r in rows[1:])
        require(all(1<=c<=100 and 1<=s<=100000 and 1<=f<=100 and s%f==0 for c,s,f in legs),'trains');return n,legs
    if i==86:
        require(1<=n<=100000 and len(rows)==n+1,'shape');visits=tuple(ints(r,3) for r in rows[1:])
        require(all(1<=t<=100000 and 0<=x<=100000 and 0<=y<=100000 for t,x,y in visits),'visits')
        require(all(visits[j][0]<visits[j+1][0] for j in range(n-1)),'time order');return n,visits
    if i==87:
        require(1<=n<=100 and len(rows)==3,'shape');grid=tuple(ints(r,n) for r in rows[1:])
        require(all(1<=v<=100 for r in grid for v in r),'candies');return n,grid
    if i==89:
        require(1<=n<=100000 and len(rows)==n+1,'shape');names=tuple(rows[1:])
        require(len(set(names))==n and all(re.fullmatch('[A-Z]{1,10}',s) is not None for s in names),'names');return n,names
    require(i==91 and 1<=n<=100 and len(rows)==2*n+1,'shape')
    points=tuple(ints(r,2) for r in rows[1:])
    require(all(0<=x<2*n and 0<=y<2*n for x,y in points),'coordinates')
    require(len({x for x,y in points})==2*n and len({y for x,y in points})==2*n,'coordinate uniqueness')
    return n,points[:n],points[n:]

def banknote_bounds(n: int, yen: int) -> tuple[int,int,int]:
    d=yen//1000-n
    low=max(0,-((-(d-4*n))//5));high=min(n,d//9)
    # 9x+4y=d; x == d (mod 4), y>=0 and x+y<=n.
    first=low+(d-low)%4
    return d,first,high

def banknotes_valid(n: int, yen: int, answer: tuple[int,...]) -> bool:
    if answer==(-1,-1,-1):
        _,first,high=banknote_bounds(n,yen);return first>high
    return len(answer)==3 and min(answer)>=0 and sum(answer)==n and sum(v*c for v,c in zip(answer,(10000,5000,1000)))==yen

def _shop_gray(f: tuple[tuple[int,...],...], p: tuple[tuple[int,...],...]) -> int:
    overlaps=[0]*len(f);total=sum(r[0] for r in p);best=-10**30;previous=0
    for step in range(1,1024):
        mask=step^(step>>1);changed=mask^previous;bit=changed.bit_length()-1;direction=1 if mask&changed else -1
        for j,row in enumerate(f):
            if row[bit]:
                old=overlaps[j];overlaps[j]+=direction;total+=p[j][overlaps[j]]-p[j][old]
        best=max(best,total);previous=mask
    return best

def _matching(red: tuple[Pair,...], blue: tuple[Pair,...]) -> int:
    neighbors=[[j for j,(x,y) in enumerate(blue) if a<x and b<y] for a,b in red];owner=[-1]*len(blue)
    def augment(u: int, seen: set[int]) -> bool:
        for v in neighbors[u]:
            if v in seen:continue
            seen.add(v)
            if owner[v]<0 or augment(owner[v],seen):owner[v]=u;return True
        return False
    return sum(augment(u,set()) for u in range(len(red)))

def _medians(a: tuple[int,...]) -> list[int]:
    values=sorted(set(a));positions={v:j+1 for j,v in enumerate(values)};tree=[0]*(len(values)+1)
    def add(v: int, delta: int) -> None:
        j=positions[v]
        while j<len(tree):tree[j]+=delta;j+=j&-j
    def kth(k: int) -> int:
        j=0;bit=1<<(len(values).bit_length()-1)
        while bit:
            nxt=j+bit
            if nxt<len(tree) and tree[nxt]<k:k-=tree[nxt];j=nxt
            bit>>=1
        return values[j]
    for v in a:add(v,1)
    answers=[]
    for v in a:add(v,-1);answers.append(kth(len(a)//2));add(v,1)
    return answers

def oracle(pid: str, raw: str) -> str:
    data=validate(pid,raw);i=NUMBERS[pid]
    if i==80:return str(_shop_gray(cast(tuple[tuple[int,...],...],data[1]),cast(tuple[tuple[int,...],...],data[2])))
    if i==81:
        n,k,a=cast(tuple[int,int,tuple[int,...]],data);return str(n-sum(nlargest(k,Counter(a).values())))
    if i==82:
        _,a=cast(tuple[int,tuple[int,...]],data)
        if len(a)<=16:
            return str(min(len(a)-sum(mask) for mask in product((0,1),repeat=len(a)) if all(v==c for v,c in Counter(v for v,b in zip(a,mask) if b).items())))
        groups=Counter(a);kept=sum(v for v,count in groups.items() if count>=v);return str(len(a)-kept)
    if i==83:
        x,y=cast(tuple[int,int],data);return str((y//x).bit_length())
    if i==84:
        n,legs=cast(tuple[int,tuple[tuple[int,int,int],...]],data)
        cache:dict[Pair,int]={}
        def arrival(station: int, time: int) -> int:
            pending=[]
            while station<n-1 and (station,time) not in cache:
                pending.append((station,time));c,s,f=legs[station];lo=0;hi=200001
                while lo<hi:
                    middle=(lo+hi)//2
                    if s+middle*f>=time:hi=middle
                    else:lo=middle+1
                station+=1;time=s+lo*f+c
            result=cache.get((station,time),time)
            for state in pending:cache[state]=result
            return result
        return '\n'.join(str(arrival(j,0)) for j in range(n))
    if i==85:
        n,yen=cast(tuple[int,int],data);d,x,high=banknote_bounds(n,yen)
        if x>high:return '-1 -1 -1'
        y=(d-9*x)//4;return f'{x} {y} {n-x-y}'
    if i==86:
        _,visits=cast(tuple[int,tuple[tuple[int,int,int],...]],data);previous=(0,0,0)
        for t,x,y in visits:
            pt,px,py=previous;dt=t-pt;dx=x-px;dy=y-py
            if dt<=6:
                reachable={(0,0)}
                for _ in range(dt):reachable={(a+c,b+d) for a,b in reachable for c,d in ((1,0),(-1,0),(0,1),(0,-1))}
                if (dx,dy) not in reachable:return 'No'
            elif abs(dx)+abs(dy)>dt or (dt-dx-dy)%2:return 'No'
            previous=(t,x,y)
        return 'Yes'
    if i==87:
        n,g=cast(tuple[int,tuple[tuple[int,...],...]],data);dp=[[0]*n for _ in range(2)]
        for r in range(2):
            for c in range(n):dp[r][c]=g[r][c]+max(dp[r-1][c] if r else 0,dp[r][c-1] if c else 0)
        return str(dp[1][-1])
    if i==88:
        g=cast(tuple[tuple[int,...],...],data[0])
        return 'Yes' if all(g[r][c]+g[0][0]==g[r][0]+g[0][c] for r in range(3) for c in range(3)) else 'No'
    if i==89:
        _,names=cast(tuple[int,tuple[str,...]],data);counts=Counter(s[0] for s in names);ways={0:1}
        for bit,letter in enumerate('MARCH'):
            ways.update({mask|(1<<bit):v*counts[letter] for mask,v in list(ways.items())})
        return str(sum(v for mask,v in ways.items() if mask.bit_count()==3))
    if i==90:
        n,m=cast(tuple[int,int],data)
        def odd_positions(size: int) -> int:
            if size<=10:return sum((1+(p>0)+(p+1<size))%2 for p in range(size))
            return size-2
        return str(odd_positions(n)*odd_positions(m))
    if i==91:return str(_matching(cast(tuple[Pair,...],data[1]),cast(tuple[Pair,...],data[2])))
    if i==92:
        _,a=cast(tuple[int,tuple[int,...]],data);route=(0,*a,0);prefix=[0]
        for x,y in zip(route,route[1:]):prefix.append(prefix[-1]+abs(x-y))
        suffix=[0]*len(route)
        for j in range(len(route)-2,-1,-1):suffix[j]=suffix[j+1]+abs(route[j+1]-route[j])
        return '\n'.join(str(prefix[j-1]+suffix[j+1]+abs(route[j-1]-route[j+1])) for j in range(1,len(route)-1))
    if i==93:
        a=cast(tuple[int,int,int],data);target=max(a)
        while (3*target-sum(a))%2:target+=1
        return str((3*target-sum(a))//2)
    if i==94:return '\n'.join(map(str,_medians(cast(tuple[int,...],data[1]))))
    if i==95:
        a,b,c,x,y=cast(tuple[int,int,int,int,int],data)
        return str(min(2*c*z+a*max(0,x-z)+b*max(0,y-z) for z in range(max(x,y)+1)))
    if i==96:
        h,w,g=cast(tuple[int,int,tuple[str,...]],data);remaining={(r,c) for r in range(h) for c in range(w) if g[r][c]=='#'}
        while remaining:
            start=remaining.pop();queue=[start];size=0
            while queue:
                r,c=queue.pop();size+=1
                for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
                    nxt=(r+dr,c+dc)
                    if nxt in remaining:remaining.remove(nxt);queue.append(nxt)
            if size==1:return 'No'
        return 'Yes'
    if i==98:
        from bisect import bisect_left,bisect_right
        n,s=cast(tuple[int,str],data);west=[j for j,c in enumerate(s) if c=='W'];east=[j for j,c in enumerate(s) if c=='E']
        return str(min(bisect_left(west,j)+len(east)-bisect_right(east,j) for j in range(n)))
    if i==99:
        n=cast(int,data[0])
        def digits(value: int, base: int) -> int:
            total=0
            while value:total+=value%base;value//=base
            return total
        return str(min(digits(a,6)+digits(n-a,9) for a in range(n+1)))
    s,k=cast(tuple[str,int],data);trie:list[dict[str,int]]=[{}]
    for start in range(len(s)):
        node=0
        for c in s[start:start+k]:
            if c not in trie[node]:trie[node][c]=len(trie);trie.append({})
            node=trie[node][c]
    found=[]
    def visit(node: int, prefix: str) -> None:
        for c in sorted(trie[node]):
            if len(found)>=k:return
            found.append(prefix+c);visit(trie[node][c],prefix+c)
    visit(0,'');return found[k-1]

def independent_check(pid: str, raw: str, actual: str) -> bool:
    try:
        data=validate(pid,raw)
        actual=actual.removesuffix('\n')
        if pid=='abc085_c':
            n,yen=cast(tuple[int,int],data);return banknotes_valid(n,yen,ints(actual,3))
        return actual==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid: str, raw: str, expected: str, stdout: str) -> bool:
    if pid=='abc085_c':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE = {'abc080_c': 'import sys\nv=list(map(int,sys.stdin.buffer.read().split()));n=v[0];f=v[1:1+10*n];p=v[1+10*n:]\nmasks=[sum(f[10*j+b]<<b for b in range(10)) for j in range(n)]\nprint(max(sum(p[11*j+(masks[j]&mask).bit_count()] for j in range(n)) for mask in range(1,1024)))\n', 'arc086_a': 'from collections import Counter\nn,k=map(int,input().split());a=list(map(int,input().split()));counts=sorted(Counter(a).values());print(sum(counts[:max(0,len(counts)-k)]))\n', 'arc087_a': 'from collections import Counter\nn=int(input());a=list(map(int,input().split()));print(sum(c-v if c>=v else c for v,c in Counter(a).items()))\n', 'arc088_a': 'x,y=map(int,input().split());answer=0\nwhile x<=y:answer+=1;x*=2\nprint(answer)\n', 'abc084_c': 'n=int(input());legs=[tuple(map(int,input().split())) for _ in range(n-1)]\nfor start in range(n):\n t=0\n for c,s,f in legs[start:]:t=max(s,((t+f-1)//f)*f)+c\n print(t)\n', 'abc085_c': 'n,yen=map(int,input().split());answer=(-1,-1,-1)\nfor x in range(n+1):\n rest=yen-10000*x-1000*(n-x)\n if rest>=0 and rest%4000==0 and rest//4000<=n-x:\n  y=rest//4000;answer=(x,y,n-x-y);break\nprint(*answer)\n', 'arc089_a': "n=int(input());t=x=y=0;ok=True\nfor _ in range(n):\n nt,nx,ny=map(int,input().split());d=abs(nx-x)+abs(ny-y);dt=nt-t\n if d>dt or (dt-d)%2:ok=False\n t,x,y=nt,nx,ny\nprint('Yes' if ok else 'No')\n", 'arc090_a': 'n=int(input());a=list(map(int,input().split()));b=list(map(int,input().split()));top=0;bottom=sum(b);best=0\nfor j in range(n):top+=a[j];best=max(best,top+bottom);bottom-=b[j]\nprint(best)\n', 'arc091_a': 'n,m=map(int,input().split())\nif n==1 and m==1:print(1)\nelif n==1:print(max(0,m-2))\nelif m==1:print(max(0,n-2))\nelse:print((n-2)*(m-2))\n', 'arc092_a': 'n=int(input());red=[tuple(map(int,input().split())) for _ in range(n)];blue=sorted(tuple(map(int,input().split())) for _ in range(n));used=set();answer=0\nfor x,y in blue:\n candidates=[j for j,(a,b) in enumerate(red) if j not in used and a<x and b<y]\n if candidates:used.add(max(candidates,key=lambda j:red[j][1]));answer+=1\nprint(answer)\n', 'arc093_a': 'n=int(input());a=[0]+list(map(int,input().split()))+[0];total=sum(abs(x-y) for x,y in zip(a,a[1:]))\nfor j in range(1,n+1):print(total-abs(a[j]-a[j-1])-abs(a[j+1]-a[j])+abs(a[j+1]-a[j-1]))\n', 'arc094_a': 'a=sorted(map(int,input().split()));answer=0\nwhile len({v%2 for v in a})>1:\n if sum(v%2 for v in a)==1:\n  for j in range(3):\n   if a[j]%2==0:a[j]+=1\n else:\n  for j in range(3):\n   if a[j]%2==1:a[j]+=1\n answer+=1\nanswer+=sum((max(a)-v)//2 for v in a);print(answer)\n', 'arc095_a': 'n=int(input());a=list(map(int,input().split()));s=sorted(a);left=s[n//2-1];right=s[n//2]\nfor v in a:print(right if v<=left else left)\n', 'arc096_a': 'a,b,c,x,y=map(int,input().split());print(min(a*x+b*y,2*c*min(x,y)+a*max(x-y,0)+b*max(y-x,0),2*c*max(x,y)))\n', 'abc096_c': "h,w=map(int,input().split());s=[input() for _ in range(h)];ok=True\nfor r in range(h):\n for c in range(w):\n  if s[r][c]=='#' and not any(0<=r+dr<h and 0<=c+dc<w and s[r+dr][c+dc]=='#' for dr,dc in ((1,0),(-1,0),(0,1),(0,-1))):ok=False\nprint('Yes' if ok else 'No')\n", 'arc097_a': 's=input();k=int(input());candidates=sorted({s[j:j+length] for j in range(len(s)) for length in range(1,k+1) if j+length<=len(s)});print(candidates[k-1])\n', 'arc098_a': 'n=int(input());s=input();west=0;east=s.count("E");answer=n\nfor c in s:\n if c=="E":east-=1\n answer=min(answer,west+east)\n if c=="W":west+=1\nprint(answer)\n', 'abc099_c': 'n=int(input());coins=[1]\nfor base in (6,9):\n p=base\n while p<=n:coins.append(p);p*=base\ndp=[0]+[n+1]*n\nfor value in range(1,n+1):dp[value]=1+min(dp[value-c] for c in coins if c<=value)\nprint(dp[n])\n'}

def line(values: tuple[int,...] | list[int]) -> str:return ' '.join(map(str,values))+'\n'
def array(values: list[int]) -> str:return f'{len(values)}\n'+line(values)
def column(values: list[int]) -> str:return ''.join(f'{v}\n' for v in values)

def generate(pid: str) -> list[Case]:
    require(pid in TASKS,'task');i=NUMBERS[pid];rng=random.Random(15900+i);raws:list[str]=[]
    if i==80:
        def shop(n: int, variant: int) -> str:
            f=[[int((j+b+variant)%3!=0) for b in range(10)] for j in range(n)]
            if variant==0:f=[[1]+[0]*9 for _ in range(n)]
            p=[[(-10**7 if variant%3==0 else 10**7 if variant==99 else (k-5)*(j+1)*(1 if variant%2 else -1)) for k in range(11)] for j in range(n)]
            return f'{n}\n'+''.join(line(r) for r in f+p)
        raws=[shop(1,0),shop(1,1),shop(1,2),shop(2,0)]+[shop(n,n) for n in range(3,16)]+[shop(100,99)]
    elif i==81:
        def diverse(a: list[int], k: int) -> str:return f'{len(a)} {k}\n'+line(a)
        raws=[diverse([1],1),diverse([1,2],1),diverse([1,2],2),diverse([1,1],1)]+[diverse([rng.randrange(1,n+1) for _ in range(n)],1+n%3) for n in range(3,16)]+[diverse(list(range(1,200001)),1)]
    elif i==82:raws=[array([1]),array([2]),array([2,2]),array([2,2,2])]+[array([rng.randrange(1,n+2) for _ in range(n)]) for n in range(3,16)]+[array([10**9]*100000)]
    elif i==83:raws=['1 1\n','1 2\n','1 3\n','2 3\n']+[f'{j} {j*2**j-1}\n' for j in range(3,16)]+['1 1000000000000000000\n']
    elif i==84:
        def trains(n: int, variant: int) -> str:return f'{n}\n'+''.join(f'{100 if variant==99 else 1+j%100} {(100000 if variant==99 else 1+j)* (100 if variant==99 else 1) } {100 if variant==99 else 1}\n' for j in range(n-1))
        raws=['1\n','2\n1 1 1\n','2\n100 100000 100\n','3\n1 2 2\n1 3 3\n']+[trains(n,n) for n in range(4,17)]+['500\n'+('100 100000 100\n'*499)]
    elif i==85:raws=['1 1000\n','1 2000\n','1 5000\n','1 10000\n','9 45000\n','2 1000\n']+[f'{n} {n*7000}\n' for n in range(2,13)]+['2000 20000000\n']
    elif i==86:
        def travel(visits: list[tuple[int,int,int]]) -> str:return f'{len(visits)}\n'+''.join(line(v) for v in visits)
        raws=[travel([(1,0,0)]),travel([(1,1,0)]),travel([(2,0,0)]),travel([(1,100000,100000)])]+[travel([(j,j%2,0) for j in range(1,n+1)]) for n in range(2,15)]+[travel([(j,j,0) for j in range(1,100001)])]
    elif i==87:
        def candies(a: list[int], b: list[int]) -> str:return f'{len(a)}\n'+line(a)+line(b)
        raws=[candies([1],[1]),candies([100],[100]),candies([1,100],[100,1]),candies([100,1],[1,100])]+[candies([rng.randrange(1,101) for _ in range(n)],[rng.randrange(1,101) for _ in range(n)]) for n in range(3,16)]+[candies([100]*100,[100]*100)]
    elif i==88:
        raws=['0 0 0\n0 0 0\n0 0 0\n','0 1 2\n1 2 3\n2 3 4\n','0 0 0\n0 1 0\n0 0 0\n','100 100 100\n100 100 100\n100 100 100\n']
        raws += [''.join(line([j+r,j+r+1,j+r+2]) for r in range(3)) for j in range(1,14)]
        raws.append('0 100 0\n100 0 100\n0 100 0\n')
    elif i==89:
        def suffix(j: int) -> str:
            result=''
            while j>=0:result=chr(65+j%26)+result;j=j//26-1
            return result
        def march(n: int, variant: int) -> str:
            names=[('MARCHZ'[(j+variant)%6] if variant!=99 else 'MARCH'[j%5])+suffix(j//6 if variant!=99 else j//5) for j in range(n)]
            return f'{n}\n'+'\n'.join(names)+'\n'
        raws=[march(1,0),march(2,0),march(3,0),march(3,5)]+[march(n,n) for n in range(4,17)]+[march(100000,99)]
    elif i==90:raws=[line([n,m]) for n,m in ((1,1),(1,2),(2,1),(2,2),(1,3),(3,1),(3,3),(3,4),(4,3),(10,10),(1,1000000000),(1000000000,1),(2,1000000000),(1000000000,2),(999999999,999999999),(123,456),(100,100000),(1000000000,1000000000))]
    elif i==91:
        def matching(n: int, variant: int) -> str:
            xs=list(range(2*n));ys=list(range(2*n))
            if variant%3==1:xs.reverse();ys.reverse()
            elif variant%3==2:rng.shuffle(xs);rng.shuffle(ys)
            return f'{n}\n'+''.join(f'{x} {y}\n' for x,y in zip(xs,ys))
        raws=[matching(1,0),matching(1,1),matching(2,2),matching(2,0)]+[matching(n,n) for n in range(3,16)]+[matching(100,0)]
    elif i==92:raws=[array([0,0]),array([-5000,5000]),array([1,1]),array([5000,-5000])]+[array([rng.randrange(-20,21) for _ in range(n)]) for n in range(3,16)]+[array([5000 if j%2 else -5000 for j in range(100000)])]
    elif i==93:raws=[line(a) for a in ((0,0,0),(0,0,1),(0,1,1),(0,1,2),(0,0,50),(0,50,50),(1,2,3),(2,2,3),(3,3,3),(4,7,9),(10,20,30),(49,50,50),(48,49,50),(1,1,49),(0,2,4),(5,10,15),(50,0,1),(50,50,50))]
    elif i==94:raws=[array([1,1]),array([1,2]),array([2,1]),array([1,1,2,2])]+[array([rng.randrange(1,11) for _ in range(2*n)]) for n in range(3,16)]+[array([1]*100000+[10**9]*100000)]
    elif i==95:raws=[line(a) for a in ((1,1,1,1,1),(1,1,5000,1,1),(5000,5000,1,1,1),(1,5000,1,1,2),(5000,1,1,2,1),(2,2,1,3,3),(3,4,3,7,2),(3,4,4,2,7),(100,200,50,10,100),(200,100,50,100,10),(4999,5000,2500,99,100),(5,6,2,100000,1),(5,6,2,1,100000),(5000,5000,5000,100000,1),(1,1,1,100000,100000),(1,5000,4999,1,100000),(5000,1,4999,100000,1),(5000,5000,5000,100000,100000))]
    elif i==96:
        raws=['1 1\n.\n','1 1\n#\n','1 2\n##\n','2 1\n#\n#\n']
        raws += [f'{n} {n}\n'+''.join(('.'*n if n%2 else '#'*n)+'\n' for _ in range(n)) for n in range(2,15)]
        raws.append('50 50\n'+('#'*50+'\n')*50)
    elif i==97:
        raws=['a\n1\n','aa\n2\n','abc\n5\n','zyx\n5\n']+[('abcde'*(j+1))+'\n'+f'{1+j%5}\n' for j in range(1,14)]+['z'*5000+'\n5\n']
    elif i==98:
        raws=['2\nEE\n','2\nEW\n','2\nWE\n','2\nWW\n']+[f'{n}\n'+''.join(rng.choice('EW') for _ in range(n))+'\n' for n in range(3,16)]+['300000\n'+'E'*150000+'W'*150000+'\n']
    else:raws=[f'{n}\n' for n in (1,2,5,6,7,8,9,10,35,36,37,80,81,82,215,216,99999,100000)]
    require(len(raws)==len(set(raws))==18,'18 distinct cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

TITLES={'abc080_c': 'Shopping Street', 'arc086_a': 'Not so Diverse', 'arc087_a': 'Good Sequence', 'arc088_a': 'Multiple Gift', 'abc084_c': 'Special Trains', 'abc085_c': 'Otoshidama', 'arc089_a': 'Traveling', 'arc090_a': 'Candies', 'arc091_a': 'Flip,Flip, and Flip......', 'arc092_a': '2D Plane 2N Points', 'arc093_a': 'Traveling Plan', 'arc094_a': 'Same Integers', 'arc095_a': 'Many Medians', 'arc096_a': 'Half and Half', 'abc096_c': 'Grid Repainting 2', 'arc097_a': 'K-th Substring', 'arc098_a': 'Attention', 'abc099_c': 'Strange Bank'}
PUBLISHED_SAMPLES={'abc080_c': [{'input': '1\n1 1 0 1 0 0 0 1 0 1\n3 4 5 6 7 8 9 -2 -3 4 -2\n', 'expected': '8\n'}, {'input': '2\n1 1 1 1 1 0 0 0 0 0\n0 0 0 0 0 1 1 1 1 1\n0 -2 -2 -2 -2 -2 -1 -1 -1 -1 -1\n0 -2 -2 -2 -2 -2 -1 -1 -1 -1 -1\n', 'expected': '-2\n'}, {'input': '3\n1 1 1 1 1 1 0 0 1 1\n0 1 0 1 1 1 1 0 1 0\n1 0 1 1 0 1 0 1 0 1\n-8 6 -2 -8 -8 4 8 7 -6 2 2\n-9 2 0 1 7 -5 0 -2 -6 5 5\n6 -6 7 -9 6 -5 8 0 -9 -7 -7\n', 'expected': '23\n'}], 'arc086_a': [{'input': '5 2\n1 1 2 2 5\n', 'expected': '1\n'}, {'input': '4 4\n1 1 2 2\n', 'expected': '0\n'}, {'input': '10 3\n5 1 3 2 4 1 1 2 3 4\n', 'expected': '3\n'}], 'arc087_a': [{'input': '4\n3 3 3 3\n', 'expected': '1\n'}, {'input': '5\n2 4 1 4 2\n', 'expected': '2\n'}, {'input': '6\n1 2 2 3 3 3\n', 'expected': '0\n'}, {'input': '1\n1000000000\n', 'expected': '1\n'}, {'input': '8\n2 7 1 8 2 8 1 8\n', 'expected': '5\n'}], 'arc088_a': [{'input': '3 20\n', 'expected': '3\n'}, {'input': '25 100\n', 'expected': '3\n'}, {'input': '314159265 358979323846264338\n', 'expected': '31\n'}], 'abc084_c': [{'input': '3\n6 5 1\n1 10 1\n', 'expected': '12\n11\n0\n'}, {'input': '4\n12 24 6\n52 16 4\n99 2 2\n', 'expected': '187\n167\n101\n0\n'}, {'input': '4\n12 13 1\n44 17 17\n66 4096 64\n', 'expected': '4162\n4162\n4162\n0\n'}], 'abc085_c': [{'input': '9 45000\n', 'expected': '4 0 5\n'}, {'input': '20 196000\n', 'expected': '-1 -1 -1\n'}, {'input': '1000 1234000\n', 'expected': '14 27 959\n'}, {'input': '2000 20000000\n', 'expected': '2000 0 0\n'}], 'arc089_a': [{'input': '2\n3 1 2\n6 1 1\n', 'expected': 'Yes\n'}, {'input': '1\n2 100 100\n', 'expected': 'No\n'}, {'input': '2\n5 1 1\n100 1 1\n', 'expected': 'No\n'}], 'arc090_a': [{'input': '5\n3 2 2 4 1\n1 2 2 2 1\n', 'expected': '14\n'}, {'input': '4\n1 1 1 1\n1 1 1 1\n', 'expected': '5\n'}, {'input': '7\n3 3 4 5 4 5 3\n5 3 4 4 2 3 2\n', 'expected': '29\n'}, {'input': '1\n2\n3\n', 'expected': '5\n'}], 'arc091_a': [{'input': '2 2\n', 'expected': '0\n'}, {'input': '1 7\n', 'expected': '5\n'}, {'input': '314 1592\n', 'expected': '496080\n'}], 'arc092_a': [{'input': '3\n2 0\n3 1\n1 3\n4 2\n0 4\n5 5\n', 'expected': '2\n'}, {'input': '3\n0 0\n1 1\n5 2\n2 3\n3 4\n4 5\n', 'expected': '2\n'}, {'input': '2\n2 2\n3 3\n0 0\n1 1\n', 'expected': '0\n'}, {'input': '5\n0 0\n7 3\n2 2\n4 8\n1 6\n8 5\n6 9\n5 4\n9 1\n3 7\n', 'expected': '5\n'}, {'input': '5\n0 0\n1 1\n5 5\n6 6\n7 7\n2 2\n3 3\n4 4\n8 8\n9 9\n', 'expected': '4\n'}], 'arc093_a': [{'input': '3\n3 5 -1\n', 'expected': '12\n8\n10\n'}, {'input': '5\n1 1 1 2 0\n', 'expected': '4\n4\n4\n2\n4\n'}, {'input': '6\n-679 -2409 -3258 3095 -3291 -4462\n', 'expected': '21630\n21630\n19932\n8924\n21630\n19288\n'}], 'arc094_a': [{'input': '2 5 4\n', 'expected': '2\n'}, {'input': '2 6 3\n', 'expected': '5\n'}, {'input': '31 41 5\n', 'expected': '23\n'}], 'arc095_a': [{'input': '4\n2 4 4 3\n', 'expected': '4\n3\n3\n4\n'}, {'input': '2\n1 2\n', 'expected': '2\n1\n'}, {'input': '6\n5 5 4 4 3 3\n', 'expected': '4\n4\n4\n4\n4\n4\n'}], 'arc096_a': [{'input': '1500 2000 1600 3 2\n', 'expected': '7900\n'}, {'input': '1500 2000 1900 3 2\n', 'expected': '8500\n'}, {'input': '1500 2000 500 90000 100000\n', 'expected': '100000000\n'}], 'abc096_c': [{'input': '3 3\n.#.\n###\n.#.\n', 'expected': 'Yes\n'}, {'input': '5 5\n#.#.#\n.#.#.\n#.#.#\n.#.#.\n#.#.#\n', 'expected': 'No\n'}, {'input': '11 11\n...#####...\n.##.....##.\n#..##.##..#\n#..##.##..#\n#.........#\n#...###...#\n.#########.\n.#.#.#.#.#.\n##.#.#.#.##\n..##.#.##..\n.##..#..##.\n', 'expected': 'Yes\n'}], 'arc097_a': [{'input': 'aba\n4\n', 'expected': 'b\n'}, {'input': 'atcoderandatcodeer\n5\n', 'expected': 'andat\n'}, {'input': 'z\n1\n', 'expected': 'z\n'}], 'arc098_a': [{'input': '5\nWEEWW\n', 'expected': '1\n'}, {'input': '12\nWEWEWEEEWWWE\n', 'expected': '4\n'}, {'input': '8\nWWWWWEEE\n', 'expected': '3\n'}], 'abc099_c': [{'input': '127\n', 'expected': '4\n'}, {'input': '3\n', 'expected': '3\n'}, {'input': '44852\n', 'expected': '16\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
