"""Private ABC132..137 D domains and independent oracles."""
from __future__ import annotations
from functools import lru_cache
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(132,138))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc134_d':'semantic'}
CHECKER_IDS={'abc134_d':'abc134_d'}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def rain_affine(a:tuple[int,...])->tuple[int,...]:
    # Compose x_next=2*A-x as affine maps. Odd length closes with slope -1.
    intercept=0;slope=1
    for value in a:intercept=2*value-intercept;slope=-slope
    require(slope==-1 and intercept%2==0,'odd closure');current=intercept//2;rain=[]
    for value in a:rain.append(current);current=2*value-current
    require(current==rain[0] and all(v>=0 and v%2==0 for v in rain),'nonnegative even rain guarantee');return tuple(rain)

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc132_d':
        require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=k<=n<=2000,'N/K');return n,k
    if pid=='abc133_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(3<=n<=99999 and n%2==1,'odd N');a=ints(rows[1],n);require(all(0<=v<=10**9 for v in a),'Ai');rain_affine(a);return (a,)
    if pid=='abc134_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000,'N');a=ints(rows[1],n);require(all(v in (0,1) for v in a),'Ai');return (a,)
    if pid=='abc135_d':require(len(rows)==1 and re.fullmatch('[0-9?]{1,100000}',rows[0]) is not None,'S');return (rows[0],)
    if pid=='abc136_d':require(len(rows)==1 and re.fullmatch('R[RL]{0,99998}L',rows[0]) is not None,'S');return (rows[0],)
    n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(rows)==n+1,'N/M/shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=delay<=100000 and 1<=reward<=10000 for delay,reward in a),'jobs');return m,a

@lru_cache(maxsize=64)
def pascal_row(n:int)->tuple[int,...]:
    row=[1]
    for _ in range(n):row=[1]+[(row[j-1]+row[j])%MOD for j in range(1,len(row))]+[1]
    return tuple(row)

def colored_groups(n:int,k:int)->str:
    blue=pascal_row(k-1);red=pascal_row(n-k+1)
    return '\n'.join(str(blue[i-1]*red[i]%MOD if i<len(red) else 0) for i in range(1,k+1))

@lru_cache(maxsize=1)
def squarefree_table()->bytes:
    n=200000;table=bytearray(b'\x01')*(n+1)
    for root in range(2,448):
        square=root*root
        if square>n:break
        table[square:n+1:square]=b'\x00'*((n-square)//square+1)
    return bytes(table)

def box_mobius(a:tuple[int,...])->list[int]:
    # Mobius inversion on divisibility over GF2; -1 and +1 are equal.
    n=len(a);b=bytearray(n);squarefree=squarefree_table()
    for ratio in range(1,n+1):
        if squarefree[ratio]:
            for index in range(1,n//ratio+1):b[index-1]^=a[index*ratio-1]
    return [j+1 for j,value in enumerate(b) if value]

def boxes_valid(raw:str,actual:str)->bool:
    try:
        a=cast(tuple[int,...],validate('abc134_d',raw)[0]);fields=actual.split()
        if not fields or any(re.fullmatch(r'(?:0|[1-9][0-9]*)',token) is None for token in fields):return False
        numbers=list(map(int,fields));count=numbers[0];indices=numbers[1:];n=len(a)
        if not 0<=count<=n or len(indices)!=count or len(set(indices))!=count or any(not 1<=v<=n for v in indices):return False
        b=bytearray(n+1)
        for index in indices:b[index]=1
        return all(sum(b[multiple] for multiple in range(index,n+1,index))%2==a[index-1] for index in range(1,n+1))
    except (ValueError,TypeError,IndexError):return False

def digit_weight_convolution(s:str)->int:
    counts=[0]*13;counts[0]=1;weight=1
    for ch in reversed(s):
        if ch=='?':
            total=sum(counts);counts=[(total-counts[(r-10*weight)%13]-counts[(r-11*weight)%13]-counts[(r-12*weight)%13])%MOD for r in range(13)]
        else:
            shift=int(ch)*weight;counts=[counts[(r-shift)%13] for r in range(13)]
        weight=weight*10%13
    return counts[5]

def children_jump(s:str)->list[int]:
    # 2^17 is even and exceeds all transient path lengths. Every terminal cycle has length2.
    jump=[j+(1 if ch=='R' else -1) for j,ch in enumerate(s)]
    for _ in range(17):jump=[jump[j] for j in jump]
    counts=[0]*len(s)
    for j in jump:counts[j]+=1
    return counts

def schedule_latest(m:int,a:tuple[tuple[int,...],...])->int:
    parent=list(range(m+1));answer=0
    def find(day:int)->int:
        while day!=parent[day]:parent[day]=parent[parent[day]];day=parent[day]
        return day
    for delay,reward in sorted(a,key=lambda p:p[1],reverse=True):
        deadline=m-delay+1
        if deadline<=0:continue
        day=find(deadline)
        if day:answer+=reward;parent[day]=find(day-1)
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc132_d':return colored_groups(*cast(tuple[int,int],data))
    if pid=='abc133_d':return ' '.join(map(str,rain_affine(cast(tuple[int,...],data[0]))))
    if pid=='abc134_d':
        b=box_mobius(cast(tuple[int,...],data[0]));return str(len(b))+('\n'+' '.join(map(str,b)) if b else '')
    if pid=='abc135_d':return str(digit_weight_convolution(cast(str,data[0])))
    if pid=='abc136_d':return ' '.join(map(str,children_jump(cast(str,data[0]))))
    return str(schedule_latest(*cast(tuple[int,tuple[tuple[int,...],...]],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc134_d':return boxes_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc134_d':return boxes_valid(raw,expected) and boxes_valid(raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc132_d':"n,k=map(int,input().split());mod=1000000007;f=[1]*(n+2)\nfor i in range(1,n+2):f[i]=f[i-1]*i%mod\ninv=[1]*(n+2);inv[-1]=pow(f[-1],mod-2,mod)\nfor i in range(n+1,0,-1):inv[i-1]=inv[i]*i%mod\ndef C(n,r):return f[n]*inv[r]%mod*inv[n-r]%mod if 0<=r<=n else 0\nfor i in range(1,k+1):print(C(k-1,i-1)*C(n-k+1,i)%mod)\n",
'abc133_d':"n=int(input());a=list(map(int,input().split()));rain=[sum(a[::2])-sum(a[1::2])]\nfor value in a[:-1]:rain.append(2*value-rain[-1])\nprint(*rain)\n",
'abc134_d':"n=int(input());a=list(map(int,input().split()));b=[0]*(n+1)\nfor i in range(n,0,-1):b[i]=(a[i-1]+sum(b[j] for j in range(2*i,n+1,i)))%2\nselected=[i for i in range(1,n+1) if b[i]];print(len(selected))\nif selected:print(*selected)\n",
'abc135_d':"s=input();mod=1000000007;dp=[0]*13;dp[0]=1\nfor ch in s:\n nxt=[0]*13;digits=range(10) if ch=='?' else [int(ch)]\n for r,count in enumerate(dp):\n  for d in digits:nxt[(r*10+d)%13]+=count\n dp=[v%mod for v in nxt]\nprint(dp[5])\n",
'abc136_d':"s=input();n=len(s);answer=[0]*n;i=0\nwhile i<n:\n j=i\n while j<n and s[j]=='R':j+=1\n k=j\n while k<n and s[k]=='L':k+=1\n r=j-i;l=k-j;answer[j-1]=(r+1)//2+l//2;answer[j]=r//2+(l+1)//2;i=k\nprint(*answer)\n",
'abc137_d':"import heapq\nn,m=map(int,input().split());jobs=sorted(tuple(map(int,input().split())) for _ in range(n));cursor=0;heap=[];answer=0\nfor day in range(1,m+1):\n while cursor<n and jobs[cursor][0]<=day:heapq.heappush(heap,-jobs[cursor][1]);cursor+=1\n if heap:answer-=heapq.heappop(heap)\nprint(answer)\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18600+TASKS.index(pid))
    if pid=='abc132_d':raws=[line((1,1)),line((2,1)),line((2,2)),line((3,2))]+[line((n,rng.randint(1,n))) for n in range(4,16)]+[line((2000,1000)),line((2000,2000))]
    elif pid=='abc133_d':
        def dams(rain:list[int])->str:return f'{len(rain)}\n'+line([(rain[j]+rain[(j+1)%len(rain)])//2 for j in range(len(rain))])
        raws=[dams([0,0,0]),dams([0,2*10**9,0]),dams([2,4,6]),dams([0,0,2])];raws.extend(dams([2*rng.randint(0,5*10**8) for _ in range(n)]) for n in range(5,29,2));raws.extend([dams([2*(j*99991%(5*10**8+1)) for j in range(99999)]),dams([10**9]*99999)])
    elif pid=='abc134_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([0]),seq([1]),seq([0,1]),seq([1,0,0])];raws.extend(seq([rng.randrange(2) for _ in range(n)]) for n in range(4,16));raws.extend([seq([j%2 for j in range(200000)]),seq([1]*200000)])
    elif pid=='abc135_d':raws=[s+'\n' for s in ('0','5','?','??2??5')]+[''.join(rng.choice('0123456789?') for _ in range(n))+'\n' for n in range(2,14)]+['?'*99999+'5\n','?'*100000+'\n']
    elif pid=='abc136_d':raws=[s+'\n' for s in ('RL','RRL','RLL','RLRL')]+['R'+''.join(rng.choice('RL') for _ in range(n-2))+'L\n' for n in range(5,17)]+['RL'*50000+'\n','R'*50000+'L'*50000+'\n']
    else:
        def jobs(m:int,a:list[tuple[int,int]])->str:return line((len(a),m))+''.join(line(p) for p in a)
        raws=[jobs(1,[(1,1)]),jobs(1,[(2,1)]),jobs(1,[(1,10000)]),jobs(2,[(1,1),(2,2)])];raws.extend(jobs(n,[(rng.randint(1,n+1),rng.randint(1,10000)) for _ in range(n)]) for n in range(3,15));raws.extend([jobs(100000,[(j+1,j%10000+1) for j in range(100000)]),jobs(100000,[(100000,10000)]*100000)])
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc132_d':('操作回数iは、完成した列の青玉の連続区間がi個あることに対応します。','青K個をi個の非空区間に分ける方法と、赤玉の隙間N-K+1箇所から置く場所を選ぶ方法を掛けます。','疑似コード: factorialとinverse factorialをmodで前計算; i=1..Kに対してC(K-1,i-1)*C(N-K+1,i) modを出力; 範囲外のcombinationは0。'),
'abc133_d':('山の雨量Xとダムの量Aには、X_i+X_(i+1)=2A_iの関係があります。','Nが奇数なので、式を交互に足し引きすると最初の山の雨量が決まり、残りも順番に求まります。','疑似コード: X0=A0-A1+A2-...+A(N-1); j=0..N-2でX(j+1)=2A(j)-Xj; 全Xを出力。'),
'abc134_d':('番号iの条件に影響する箱はiの倍数です。大きい番号から決めると、未決定は箱iだけになります。','iより大きい倍数のボール数の偶奇を計算し、a_iと合うように箱iの有無を決めます。','疑似コード: i=N..1でb[i]=(a[i]+sum(b[2i],b[3i],...)) mod2; b[i]=1の番号を集め、個数と番号を任意順序で出力。'),
'abc135_d':('左から数字を付け加えると、13での余りは(古い余り×10+数字) mod13になります。','余り13種類の通り数をDPします。?では数字0〜9の全遷移を足し、毎段階で剰余を取ります。','疑似コード: dp[0]=1; 各文字でnextを0初期化; 全rと許可digitにnext[(10r+digit)%13]+=dp[r]; mod後dp=next; dp[5]を出力。'),
'abc136_d':('十分な偶数回移動後、子供はRLという隣り合う境界の2マスに集まります。','連続するRがr人、続くLがl人なら、境界への距離の偶奇でどちらのマスにいるかが決まります。','疑似コード: 各R連続区間と直後L連続区間を数える; 左境界=(r+1)//2+l//2,右境界=r//2+(l+1)//2; 他は0として全マスを出力。'),
'abc137_d':('仕事A_iは、報酬が間に合う開始日の締切M-A_i+1を持つ仕事として扱えます。','残り日数を1から増やす順に考え、その日までに候補となった仕事の中で報酬が最大のものを選びます。','疑似コード: 仕事をA昇順sort; remaining=1..MでA<=remainingをmaxheapに追加; heapが空でなければ最大Bを取り出して加算; 合計を出力。')}

TITLES={'abc132_d': 'Blue and Red Balls', 'abc133_d': 'Rain Flows into Dams', 'abc134_d': 'Preparing Boxes', 'abc135_d': 'Digits Parade', 'abc136_d': 'Gathering Children', 'abc137_d': 'Summer Vacation'}
PUBLISHED_SAMPLES={'abc132_d': [{'input': '5 3\n', 'expected': '3\n6\n1\n'}, {'input': '2000 3\n', 'expected': '1998\n3990006\n327341989\n'}], 'abc133_d': [{'input': '3\n2 2 4\n', 'expected': '4 0 4\n'}, {'input': '5\n3 8 7 5 5\n', 'expected': '2 4 12 2 8\n'}, {'input': '3\n1000000000 1000000000 0\n', 'expected': '0 2000000000 0\n'}], 'abc134_d': [{'input': '3\n1 0 0\n', 'expected': '1\n1\n'}, {'input': '5\n0 0 0 0 0\n', 'expected': '0\n'}], 'abc135_d': [{'input': '??2??5\n', 'expected': '768\n'}, {'input': '?44\n', 'expected': '1\n'}, {'input': '7?4\n', 'expected': '0\n'}, {'input': '?6?42???8??2??06243????9??3???7258??5??7???????774????4?1??17???9?5?70???76???\n', 'expected': '153716888\n'}], 'abc136_d': [{'input': 'RRLRL\n', 'expected': '0 1 2 1 1\n'}, {'input': 'RRLLLLRLRRLL\n', 'expected': '0 3 3 0 0 0 1 1 0 2 2 0\n'}, {'input': 'RRRLLRLLRRRLLLLL\n', 'expected': '0 0 3 2 0 2 1 0 0 0 4 4 0 0 0 0\n'}], 'abc137_d': [{'input': '3 4\n4 3\n4 1\n2 2\n', 'expected': '5\n'}, {'input': '5 3\n1 2\n1 3\n1 4\n2 1\n2 3\n', 'expected': '10\n'}, {'input': '1 1\n2 1\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
