"""Reviewed C tasks with histogram rectangles and occupancy lifetime sweeps."""
from __future__ import annotations
from collections import defaultdict
from itertools import groupby
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(390,396))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pairs=tuple[tuple[int,int],...]
Queries=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==390:
        h,w=ints(rows[0],2);a=tuple(rows[1:]);require(1<=h<=1000 and 1<=w<=1000 and len(a)==h and all(len(s)==w and set(s)<=set('#.?') for s in a) and any('#' in s for s in a),'grid');return (a,)
    if number==391:
        n,q=ints(rows[0],2);require(2<=n<=10**6 and 1<=q<=300000 and len(rows)==q+1,'shape');positions:dict[int,int]={};queries=[]
        for row in rows[1:]:
            a=ints(row);require(a[0] in (1,2) and len(a)==(3 if a[0]==1 else 1),'query')
            if a[0]==1:p,h=a[1:];require(1<=p<=n and 1<=h<=n and positions.get(p,p)!=h,'movement');positions[p]=h
            queries.append(a)
        return n,tuple(queries)
    if number==392:
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];p,q=ints(rows[1],n),ints(rows[2],n);require(2<=n<=300000 and set(p)==set(q)==set(range(1,n+1)),'permutations');return p,q
    if number==393:
        n,m=ints(rows[0],2);require(1<=n<=200000 and 0<=m<=500000 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=n for pair in a for v in pair),'endpoints');return (a,)
    if number==394:
        require(len(rows)==1 and 1<=len(rows[0])<=300000 and re.fullmatch('[A-Z]+',rows[0]) is not None,'string');return (rows[0],)
    require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=200000 and all(1<=v<=10**6 for v in a),'values');return (a,)
def rectangle_possible(a:tuple[str,...])->bool:
    h=len(a);w=len(a[0]);prefix=[[0]*(w+1) for _ in range(h+1)];heights=[0]*w
    for r,row in enumerate(a):
        count=0
        for c,ch in enumerate(row):count+=ch=='#';prefix[r+1][c+1]=prefix[r][c+1]+count
    total=prefix[-1][-1]
    for r,row in enumerate(a):
        for c,ch in enumerate(row):heights[c]=0 if ch=='.' else heights[c]+1
        stack:list[tuple[int,int]]=[]
        for c in range(w+1):
            height=heights[c] if c<w else 0;start=c
            while stack and stack[-1][1]>height:
                left,tall=stack.pop();top=r+1-tall;black=prefix[r+1][c]-prefix[top][c]-prefix[r+1][left]+prefix[top][left]
                if black==total:return True
                start=left
            if height and (not stack or stack[-1][1]<height):stack.append((start,height))
    return False
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==390:return 'Yes' if rectangle_possible(cast(tuple[str,...],data[0])) else 'No'
    if number==391:
        _,qs=cast(tuple[int,Queries],data);positions:dict[int,int]={};events:dict[int,list[tuple[int,int]]]=defaultdict(list);requests=[]
        for t,a in enumerate(qs):
            if a[0]==2:requests.append(t)
            else:p,h=a[1:];old=positions.get(p,p);positions[p]=h;events[old].append((t,-1));events[h].append((t,1))
        boundaries=[]
        for seq in events.values():
            count=1
            for t,delta in seq:old=count;count+=delta;change=(count>=2)-(old>=2);boundaries.append((t,change))
        boundaries.sort();p=0;crowded=0;out=[]
        for t in requests:
            while p<len(boundaries) and boundaries[p][0]<t:crowded+=boundaries[p][1];p+=1
            out.append(str(crowded))
        return '\n'.join(out)
    if number==392:
        p,q=cast(tuple[tuple[int,...],tuple[int,...]],data);owners=[person for label,person in sorted((label,j) for j,label in enumerate(q))];return ' '.join(str(q[p[owner]-1]) for owner in owners)
    if number==393:
        a=cast(Pairs,data[0]);normalized=sorted((min(u,v),max(u,v)) for u,v in a);answer=0
        for (u,v),seq in groupby(normalized):count=sum(1 for _ in seq);answer+=count if u==v else count-1
        return str(answer)
    if number==394:return re.sub(r'W+A',lambda match:'A'+'C'*(len(match[0])-1),cast(str,data[0]))
    a=cast(tuple[int,...],data[0]);pairs=sorted((v,j) for j,v in enumerate(a));answer=len(a)+1
    for (v,i),(w,j) in zip(pairs,pairs[1:]):
        if v==w:answer=min(answer,j-i+1)
    return str(answer if answer<=len(a) else -1)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc390_c':"h,w=map(int,input().split());a=[input() for _ in range(h)];black=[(r,c) for r in range(h) for c in range(w) if a[r][c]=='#'];top=min(r for r,c in black);bottom=max(r for r,c in black);left=min(c for r,c in black);right=max(c for r,c in black);print('No' if any(a[r][c]=='.' for r in range(top,bottom+1) for c in range(left,right+1)) else 'Yes')\n",
'abc391_c':"n,q=map(int,input().split());position=list(range(n));count=[1]*n;answer=0\nfor _ in range(q):\n a=list(map(int,input().split()))\n if a[0]==2:print(answer)\n else:\n  p,h=a[1]-1,a[2]-1;old=position[p];answer-=count[old]==2;count[old]-=1;answer+=count[h]==1;count[h]+=1;position[p]=h\n",
'abc392_c':"n=int(input());p=list(map(int,input().split()));q=list(map(int,input().split()));out=[0]*n\nfor i in range(n):out[q[i]-1]=q[p[i]-1]\nprint(*out)\n",
'abc393_c':"n,m=map(int,input().split());seen=set();answer=0\nfor _ in range(m):\n u,v=sorted(map(int,input().split()))\n if u==v or (u,v) in seen:answer+=1\n else:seen.add((u,v))\nprint(answer)\n",
'abc394_c':"s=list(input())\nfor j in range(len(s)-2,-1,-1):\n if s[j]=='W' and s[j+1]=='A':s[j]='A';s[j+1]='C'\nprint(''.join(s))\n",
'abc395_c':"n=int(input());a=list(map(int,input().split()));last={};answer=n+1\nfor j,v in enumerate(a):\n if v in last:answer=min(answer,j-last[v]+1)\n last[v]=j\nprint(answer if answer<=n else -1)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17400+number)
    if number==390:
        def grid(a:list[str])->str:return f'{len(a)} {len(a[0])}\n'+'\n'.join(a)+'\n'
        raws=[grid(a) for a in (['#'],['#?'],['#.#'],['#?','?#'])]
        for n in range(3,15):a=[''.join(rng.choice('#.?') for _ in range(n)) for _ in range(n)];a[0]='#'+a[0][1:];raws.append(grid(a))
        raws.extend([grid(['#'+'?'*998+'#']+['?'*1000]*499+['?'*500+'.'+'?'*499]+['?'*1000]*498+['#'+'?'*998+'#']),grid(['#'*1000]*1000)])
    elif number==391:
        def birds(n:int,qs:list[str])->str:return f'{n} {len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[birds(n,qs) for n,qs in ((2,['1 1 2']),(2,['2']),(2,['1 1 2','2']),(2,['1 1 2','1 1 1','2']))]
        for n in range(3,15):
            pos=list(range(1,n+1));qs=[]
            for _ in range(n+5):
                if rng.randrange(3)==0:qs.append('2')
                else:p=rng.randrange(n);h=rng.choice([x for x in range(1,n+1) if x!=pos[p]]);pos[p]=h;qs.append(f'1 {p+1} {h}')
            raws.append(birds(n,qs))
        raws.extend([birds(10**6,[f'1 {j+1} 1000000' for j in range(299999)]+['2']),birds(10**6,['2']*300000)])
    elif number==392:
        def people(p:list[int],q:list[int])->str:return f'{len(p)}\n'+line(p)+line(q)
        raws=[people(p,q) for p,q in (([1,2],[1,2]),([2,1],[1,2]),([1,2],[2,1]),([2,3,1],[3,1,2]))]
        for n in range(3,15):p=list(range(1,n+1));q=p[:];rng.shuffle(p);rng.shuffle(q);raws.append(people(p,q))
        raws.extend([people(list(range(2,300001))+[1],list(range(300000,0,-1))),people(list(range(1,300001)),list(range(1,300001)))])
    elif number==393:
        def graph(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{u} {v}\n' for u,v in a)
        raws=[graph(n,a) for n,a in ((1,[]),(1,[(1,1)]),(2,[(1,2),(2,1)]),(3,[(1,1),(1,2),(2,1),(2,3)]))];raws.extend(graph(n,[(rng.randint(1,n),rng.randint(1,n)) for _ in range(n+5)]) for n in range(3,15));raws.extend([graph(200000,[(j%199999+1,j%199999+2) for j in range(500000)]),graph(200000,[(200000,200000)]*500000)])
    elif number==394:raws=[s+'\n' for s in ('A','W','WA','WWA')];raws.extend(''.join(rng.choice('WABC') for _ in range(n))+'\n' for n in range(3,15));raws.extend(['W'*299999+'A\n','Z'*300000+'\n'])
    else:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[1,1],[1,2],[1,2,1])];raws.extend(arr([rng.randint(1,10) for _ in range(n)]) for n in range(3,15));raws.extend([arr(list(range(1,200000))+[1]),arr([10**6]*200000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc390_c':('既に黒いマスは、最終的な長方形にすべて含まれます。','黒マスの最小の包含長方形内に白マスがなければ、その領域の?を黒くできます。','疑似コード: #の行列の最小最大を求める; その長方形内に.があればNo; なければYes。'),
'abc391_c':('鳩の位置と巣ごとの匹数を保持します。','複数の鳩がいる巣の数は、移動元が2匹のとき減り、移動先が1匹のとき増えます。','疑似コード: position[i]=i,count=1; P移動で元count=2ならanswer--; 元count--; 先count=1ならanswer++; 先count++; position[P]=H; query2でanswer。'),
'abc392_c':('人iが見つめる人のゼッケンはQ[P[i]]です。','その値を、人iのゼッケンQ[i]に対応する出力位置へ置きます。','疑似コード: 各iでanswer[Q[i]]=Q[P[i]]; answerをゼッケン番号順に出力。'),
'abc393_c':('自己ループはすべて除去し、同じ2頂点の辺は1本だけ残します。','無向辺の両端を小さい順に揃えて集合へ入れると重複が分かります。','疑似コード: u,vをsort; u=vまたは既存(u,v)ならanswer++; 他はseenへ追加; answerを出力。'),
'abc394_c':('Wが何個も続いた後のAは、Wを左へ伝わりながら消します。','右からWAをACにすると、後ろから左へ連鎖を処理できます。','疑似コード: 文字配列を右端手前から左へ走査; S[i]=WかつS[i+1]=AならA,Cへ置換; 最終文字列を出力。'),
'abc395_c':('同じ値の隣り合う出現位置だけを調べれば十分です。','最後の出現位置を記録し、現在との距離に1を足した長さを最小化します。','疑似コード: 各i,vでlast[v]があればanswer=min(answer,i-last[v]+1); last[v]=i; 候補なしなら-1。')}

TITLES={'abc390_c': 'Paint to make a rectangle', 'abc391_c': 'Pigeonhole Query', 'abc392_c': 'Bib', 'abc393_c': 'Make it Simple', 'abc394_c': 'Debug', 'abc395_c': 'Shortest Duplicate Subarray'}
PUBLISHED_SAMPLES={'abc390_c': [{'input': '3 5\n.#?#.\n.?#?.\n?...?\n', 'expected': 'Yes\n'}, {'input': '3 3\n?##\n#.#\n##?\n', 'expected': 'No\n'}, {'input': '1 1\n#\n', 'expected': 'Yes\n'}], 'abc391_c': [{'input': '4 7\n2\n1 1 2\n2\n1 3 2\n2\n1 3 4\n2\n', 'expected': '0\n1\n1\n2\n'}, {'input': '5 10\n2\n1 4 3\n1 4 5\n2\n1 3 1\n2\n1 2 3\n1 2 5\n1 1 3\n2\n', 'expected': '0\n1\n2\n1\n'}], 'abc392_c': [{'input': '4\n4 3 2 1\n2 3 1 4\n', 'expected': '3 4 1 2\n'}, {'input': '10\n2 6 4 3 7 8 9 10 1 5\n1 4 8 2 10 5 7 3 9 6\n', 'expected': '4 8 6 5 3 10 9 2 1 7\n'}], 'abc393_c': [{'input': '3 5\n1 2\n2 3\n3 2\n3 1\n1 1\n', 'expected': '2\n'}, {'input': '1 0\n', 'expected': '0\n'}, {'input': '6 10\n6 2\n4 1\n5 1\n6 6\n5 3\n5 1\n1 4\n6 4\n4 2\n5 6\n', 'expected': '3\n'}], 'abc394_c': [{'input': 'WACWA\n', 'expected': 'ACCAC\n'}, {'input': 'WWA\n', 'expected': 'ACC\n'}, {'input': 'WWWWW\n', 'expected': 'WWWWW\n'}], 'abc395_c': [{'input': '5\n3 9 5 3 1\n', 'expected': '4\n'}, {'input': '4\n2 5 3 1\n', 'expected': '-1\n'}, {'input': '10\n1 1 2 3 5 8 13 21 34 55\n', 'expected': '2\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
