"""ABC224–226 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc224_b', 'abc225_b', 'abc226_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc224_b': [
        {'input': '3 3\n2 1 4\n3 1 3\n6 4 1\n', 'expected': 'Yes\n'},
        {'input': '2 4\n4 3 2 1\n5 6 7 8\n', 'expected': 'No\n'},
    ],
    'abc225_b': [
        {'input': '5\n1 4\n2 4\n3 4\n4 5\n', 'expected': 'Yes\n'},
        {'input': '4\n2 4\n1 4\n2 3\n', 'expected': 'No\n'},
        {'input': '10\n9 10\n3 10\n4 10\n8 10\n1 10\n2 10\n7 10\n6 10\n5 10\n', 'expected': 'Yes\n'},
    ],
    'abc226_b': [
        {'input': '4\n2 1 2\n2 1 1\n2 2 1\n2 1 2\n', 'expected': '3\n'},
        {'input': '5\n1 1\n1 1\n1 2\n2 1 1\n3 1 1 1\n', 'expected': '4\n'},
        {'input': '1\n1 1\n', 'expected': '1\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _tokens(line: str) -> list[str]:
    if not line or line.startswith(' ') or line.endswith(' ') or '  ' in line:
        raise ValueError('spacing')
    return line.split(' ')


def _validate224(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _tokens(lines[0])
    if len(head) != 2 or any(POS.fullmatch(x) is None for x in head):
        raise ValueError('H/W syntax')
    h, w = map(int, head)
    if not 2 <= h <= 50 or not 2 <= w <= 50 or len(lines) != h + 1:
        raise ValueError('H/W range/shape')
    grid = []
    for line in lines[1:]:
        vals = _tokens(line)
        if len(vals) != w or any(POS.fullmatch(x) is None for x in vals):
            raise ValueError('row syntax/shape')
        row = tuple(map(int, vals))
        if any(x > 10**9 for x in row):
            raise ValueError('cell range')
        grid.append(row)
    return h, w, tuple(grid)


def _validate225(raw: str):
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N syntax')
    n = int(lines[0])
    if not 3 <= n <= 100000 or len(lines) != n:
        raise ValueError('N range/shape')
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    seen = set()
    edges = []
    for line in lines[1:]:
        vals = _tokens(line)
        if len(vals) != 2 or any(POS.fullmatch(x) is None for x in vals):
            raise ValueError('edge syntax')
        a, b = map(int, vals)
        if not (1 <= a < b <= n) or (a, b) in seen:
            raise ValueError('edge range/duplicate')
        seen.add((a, b))
        edges.append((a, b))
        ra, rb = find(a - 1), find(b - 1)
        if ra == rb:
            raise ValueError('not tree cycle')
        parent[ra] = rb
    r = find(0)
    if any(find(i) != r for i in range(n)):
        raise ValueError('not tree disconnected')
    return n, tuple(edges)


def _validate226(raw: str):
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N syntax')
    n = int(lines[0])
    if not 1 <= n <= 200000 or len(lines) != n + 1:
        raise ValueError('N range/shape')
    seqs = []
    total = 0
    for line in lines[1:]:
        vals = _tokens(line)
        if not vals or POS.fullmatch(vals[0]) is None:
            raise ValueError('L syntax')
        length = int(vals[0])
        if not 1 <= length <= 200000 or len(vals) != length + 1:
            raise ValueError('L range/shape')
        if any(NONNEG.fullmatch(x) is None for x in vals[1:]):
            raise ValueError('element syntax')
        seq = tuple(map(int, vals[1:]))
        if any(x > 10**9 for x in seq):
            raise ValueError('element range')
        total += length
        if total > 200000:
            raise ValueError('total length')
        seqs.append(seq)
    return n, tuple(seqs)


def validate(pid: str, raw: str):
    if pid == 'abc224_b':
        return _validate224(raw)
    if pid == 'abc225_b':
        return _validate225(raw)
    if pid == 'abc226_b':
        return _validate226(raw)
    raise ValueError('unknown task')


def _monge_adjacent(grid) -> bool:
    h = len(grid)
    w = len(grid[0])
    for i in range(h - 1):
        for j in range(w - 1):
            if grid[i][j] + grid[i + 1][j + 1] > grid[i + 1][j] + grid[i][j + 1]:
                return False
    return True


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc224_b':
        if output not in {'Yes', 'No'}:
            return False
        _, _, grid = value
        return (output == 'Yes') == _monge_adjacent(grid)
    if pid == 'abc225_b':
        if output not in {'Yes', 'No'}:
            return False
        n, edges = value
        deg = [0] * n
        for a, b in edges:
            deg[a - 1] += 1
            deg[b - 1] += 1
        return (output == 'Yes') == (max(deg) == n - 1)
    if pid == 'abc226_b':
        if NONNEG.fullmatch(output) is None:
            return False
        _, seqs = value
        ordered = sorted(seqs)
        kinds = 1 + sum(ordered[i] != ordered[i - 1] for i in range(1, len(ordered)))
        return int(output) == kinds
    return False


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc224_b':
        cases = [
            ('min_equal', '2 2\n1 1\n1 1\n'),
            ('min_additive', '2 2\n1 2\n2 3\n'),
            ('min_violation', '2 2\n2 1\n1 2\n'),
            ('two_by_three_yes', '2 3\n5 6 7\n8 9 10\n'),
            ('two_by_three_no', '2 3\n5 6 7\n8 10 10\n'),
            ('three_by_two_yes', '3 2\n10 11\n20 21\n30 31\n'),
            ('three_by_two_no', '3 2\n10 9\n20 25\n30 31\n'),
            ('all_max', '3 4\n1000000000 1000000000 1000000000 1000000000\n1000000000 1000000000 1000000000 1000000000\n1000000000 1000000000 1000000000 1000000000\n'),
            ('boundary_mix_yes', '2 3\n999999998 999999999 1000000000\n1 2 3\n'),
            ('boundary_mix_no', '2 3\n1 1000000000 1\n1 1 1\n'),
            ('four_additive', '4 4\n2 3 4 5\n4 5 6 7\n7 8 9 10\n11 12 13 14\n'),
            ('single_local_break', '4 4\n2 3 4 5\n4 5 6 7\n7 8 20 10\n11 12 13 14\n'),
            ('valid_curved', '3 3\n100 90 70\n80 65 40\n50 30 1\n'),
            ('invalid_far', '3 4\n10 9 8 7\n20 18 16 14\n30 27 24 22\n'),
            ('five_equal_rows', '5 2\n1 2\n1 2\n1 2\n1 2\n1 2\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        rows = [' '.join(str(1000000 + i * 1000 + j) for j in range(50)) for i in range(50)]
        add('constraint_max', '50 50\n' + '\n'.join(rows) + '\n')
    elif pid == 'abc225_b':
        cases = [
            ('n3_center1', '3\n1 2\n1 3\n'),
            ('n3_center2', '3\n1 2\n2 3\n'),
            ('n4_center1', '4\n1 2\n1 3\n1 4\n'),
            ('n4_center4', '4\n1 4\n2 4\n3 4\n'),
            ('n4_path', '4\n1 2\n2 3\n3 4\n'),
            ('n5_center3', '5\n1 3\n2 3\n3 4\n3 5\n'),
            ('n5_path', '5\n1 2\n2 3\n3 4\n4 5\n'),
            ('n6_broom', '6\n1 2\n1 3\n1 4\n4 5\n4 6\n'),
            ('n6_center2', '6\n1 2\n2 3\n2 4\n2 5\n2 6\n'),
            ('n7_binaryish', '7\n1 2\n1 3\n2 4\n2 5\n3 6\n3 7\n'),
            ('n8_center7', '8\n1 7\n2 7\n3 7\n4 7\n5 7\n6 7\n7 8\n'),
            ('n8_path', '8\n1 2\n2 3\n3 4\n4 5\n5 6\n6 7\n7 8\n'),
            ('n10_center5', '10\n1 5\n2 5\n3 5\n4 5\n5 6\n5 7\n5 8\n5 9\n5 10\n'),
            ('n10_almost_star', '10\n1 5\n2 5\n3 5\n4 5\n5 6\n5 7\n5 8\n5 9\n9 10\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        n = 100000
        add('constraint_max', str(n) + '\n' + '\n'.join(f'{i} {n}' for i in range(1, n)) + '\n')
    else:
        cases = [
            ('single_zero', '1\n1 0\n'),
            ('single_max', '1\n1 1000000000\n'),
            ('two_same', '2\n2 1 2\n2 1 2\n'),
            ('two_diff_value', '2\n2 1 2\n2 1 3\n'),
            ('same_prefix_diff_length', '3\n1 1\n2 1 0\n3 1 0 0\n'),
            ('all_duplicates', '6\n3 5 5 5\n3 5 5 5\n3 5 5 5\n3 5 5 5\n3 5 5 5\n3 5 5 5\n'),
            ('all_unique_singletons', '6\n1 0\n1 1\n1 2\n1 3\n1 4\n1 5\n'),
            ('mixed_duplicates', '8\n1 1\n2 1 2\n1 1\n2 1 2\n2 2 1\n3 1 2 3\n3 1 2 3\n1 2\n'),
            ('zero_sequences_values', '4\n4 0 0 0 0\n4 0 0 0 0\n3 0 0 0\n5 0 0 0 0 0\n'),
            ('max_values', '4\n1 1000000000\n2 1000000000 1000000000\n1 999999999\n2 1000000000 999999999\n'),
            ('order_matters', '4\n3 1 2 3\n3 3 2 1\n3 1 3 2\n3 1 2 3\n'),
            ('length_matters', '5\n1 7\n2 7 7\n3 7 7 7\n4 7 7 7 7\n5 7 7 7 7 7\n'),
            ('n10_half_dupes', '10\n2 0 1\n2 0 1\n2 1 0\n2 1 0\n2 2 2\n2 2 2\n1 3\n1 3\n3 4 5 6\n3 4 5 6\n'),
            ('long_sequences_small_n', '2\n10 0 1 2 3 4 5 6 7 8 9\n10 0 1 2 3 4 5 6 7 8 10\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        n = 200000
        add('constraint_max', str(n) + '\n' + '\n'.join(f'1 {i}' for i in range(n)) + '\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
