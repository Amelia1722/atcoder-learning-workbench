"""ABC251–253 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import itertools
import re
from collections import deque

TASKS = ('abc251_b', 'abc252_b', 'abc253_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc251_b': [
        {'input': '2 10\n1 3\n', 'expected': '3\n'},
        {'input': '2 1\n2 3\n', 'expected': '0\n'},
        {'input': '4 12\n3 3 3 3\n', 'expected': '3\n'},
        {'input': '7 251\n202 20 5 1 4 2 100\n', 'expected': '48\n'},
    ],
    'abc252_b': [
        {'input': '5 3\n6 8 10 7 10\n2 3 4\n', 'expected': 'Yes\n'},
        {'input': '5 2\n100 100 100 1 1\n5 4\n', 'expected': 'No\n'},
        {'input': '2 1\n100 1\n2\n', 'expected': 'No\n'},
    ],
    'abc253_b': [
        {'input': '2 3\n--o\no--\n', 'expected': '3\n'},
        {'input': '5 4\n-o--\n----\n----\n----\n-o--\n', 'expected': '4\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate251(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    n, w = _ints(lines[0], 2)
    a = _ints(lines[1], n)
    if not (1 <= n <= 300 and 1 <= w <= 10**6 and all(1 <= x <= 10**6 for x in a)):
        raise ValueError('constraints')
    return n, w, a


def _validate252(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 3:
        raise ValueError('shape')
    n, k = _ints(lines[0], 2)
    a = _ints(lines[1], n)
    b = _ints(lines[2], k)
    if not (1 <= k <= n <= 100 and all(1 <= x <= 100 for x in a) and all(1 <= x <= n for x in b)):
        raise ValueError('constraints')
    if len(set(b)) != k:
        raise ValueError('B distinct')
    return n, k, a, b


def _validate253(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    h, w = _ints(lines[0], 2)
    if not (2 <= h <= 100 and 2 <= w <= 100 and len(lines) == h + 1):
        raise ValueError('constraints')
    grid = lines[1:]
    if any(len(row) != w or any(ch not in 'o-' for ch in row) for row in grid):
        raise ValueError('grid')
    if sum(row.count('o') for row in grid) != 2:
        raise ValueError('tokens')
    return h, w, grid


def validate(pid: str, raw: str):
    if pid == 'abc251_b': return _validate251(raw)
    if pid == 'abc252_b': return _validate252(raw)
    if pid == 'abc253_b': return _validate253(raw)
    raise ValueError('unknown task')


def _expected251(n: int, w: int, a: list[int]) -> int:
    good: set[int] = set()
    for r in (1, 2, 3):
        for comb in itertools.combinations(range(n), r):
            s = sum(a[i] for i in comb)
            if s <= w:
                good.add(s)
    return len(good)


def _expected252(n: int, k: int, a: list[int], b: list[int]) -> str:
    mx = max(a)
    max_indices = {i + 1 for i, x in enumerate(a) if x == mx}
    return 'Yes' if max_indices.intersection(b) else 'No'


def _expected253(h: int, w: int, grid: list[str]) -> int:
    starts = [(r, c) for r in range(h) for c in range(w) if grid[r][c] == 'o']
    start, goal = starts
    q = deque([(start[0], start[1], 0)])
    seen = {start}
    while q:
        r, c, d = q.popleft()
        if (r, c) == goal:
            return d
        for dr, dc in ((1,0),(-1,0),(0,1),(0,-1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < h and 0 <= nc < w and (nr, nc) not in seen:
                seen.add((nr, nc)); q.append((nr, nc, d + 1))
    raise AssertionError('reachable')


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc251_b':
        return output.isdigit() and int(output) == _expected251(*value)
    if pid == 'abc252_b':
        return output == _expected252(*value)
    return output.isdigit() and int(output) == _expected253(*value)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out=[]; seen=set()
    def add(category, raw):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); out.append({'category': category, 'input': raw})
    for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}', row['input'])
    if pid == 'abc251_b':
        cases=[
            ('single_hit','1 1\n1\n'),('single_miss','1 1\n2\n'),('single_max','1 1000000\n1000000\n'),
            ('duplicates','5 10\n2 2 2 2 2\n'),('pair_only','2 5\n2 3\n'),('triple_exact','3 6\n1 2 3\n'),
            ('w_filters','5 3\n1 2 3 4 5\n'),('duplicate_sums','6 20\n1 1 2 2 3 3\n'),
            ('large_values','5 1000000\n999998 999999 1000000 1 2\n'),('medium','8 50\n2 5 7 11 13 17 19 23\n'),
            ('all_above_w','4 10\n11 12 13 14\n'),('many_ones','20 3\n'+' '.join(['1']*20)+'\n'),
            ('mixed_limit','10 100\n1 4 9 16 25 36 49 64 81 100\n'),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max','300 1000000\n'+' '.join(str((i%1000)+1) for i in range(300))+'\n')
    elif pid == 'abc252_b':
        cases=[
            ('one_yes','1 1\n1\n1\n'),('tie_one_disliked','3 1\n5 5 1\n2\n'),('tie_none_disliked','3 1\n5 5 1\n3\n'),
            ('all_max_yes','4 2\n9 9 9 9\n1 4\n'),('unique_max_yes','4 1\n1 2 100 3\n3\n'),('unique_max_no','4 2\n1 2 100 3\n1 4\n'),
            ('k_equals_n','5 5\n1 2 3 4 5\n1 2 3 4 5\n'),('max_at_start','5 2\n100 1 2 3 4\n4 5\n'),
            ('max_at_end','5 2\n1 2 3 4 100\n1 5\n'),('multiple_max_sparse','6 2\n10 1 10 1 10 1\n2 6\n'),
            ('multiple_max_hit','6 2\n10 1 10 1 10 1\n2 5\n'),('all_equal_hit','6 1\n7 7 7 7 7 7\n6\n'),
            ('values_low','5 2\n1 1 1 1 1\n2 4\n'),('values_high','5 2\n100 99 98 97 96\n2 3\n'),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max','100 100\n'+' '.join(['100']*100)+'\n'+' '.join(map(str,range(1,101)))+'\n')
    else:
        def grid(h,w,p1,p2):
            a=[['-']*w for _ in range(h)]; a[p1[0]][p1[1]]=a[p2[0]][p2[1]]='o'
            return f'{h} {w}\n'+'\n'.join(''.join(r) for r in a)+'\n'
        cases=[
            ('horizontal_adjacent',grid(2,2,(0,0),(0,1))),('vertical_adjacent',grid(2,2,(0,0),(1,0))),
            ('diagonal',grid(2,2,(0,0),(1,1))),('same_row_far',grid(3,10,(1,0),(1,9))),('same_col_far',grid(10,3,(0,1),(9,1))),
            ('corners',grid(10,10,(0,0),(9,9))),('reverse_corners',grid(10,10,(0,9),(9,0))),
            ('interior',grid(7,8,(2,3),(5,6))),('near_edge',grid(4,5,(0,2),(3,4))),('wide',grid(2,100,(0,0),(1,99))),
            ('tall',grid(100,2,(0,1),(99,0))),('large_near',grid(100,100,(50,50),(51,50))),
            ('large_mid',grid(100,100,(20,30),(70,80))),('row_boundary',grid(6,6,(0,5),(5,5))),('col_boundary',grid(6,6,(5,0),(5,5))),
        ]
        for c,r in cases: add(c,r)
        add('constraint_max',grid(100,100,(0,0),(99,99)))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
