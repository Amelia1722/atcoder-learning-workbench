"""Statement-checked three-stage hints for ABC173–175 B."""
HINTS_V105 = {
    'abc173_b': (
        '必要なのは提出順ではなく、4種類それぞれが何回現れたかです。各文字列を読みながら種類別の個数だけ数えれば十分です。',
        'AC・WA・TLE・REをキーにしたCounterまたは辞書を使います。最後は問題文指定の順序で4行出力します。存在しない種類も0と表示する点に注意してください。',
        '''疑似コード:\ncount = {AC:0, WA:0, TLE:0, RE:0}\nN回:\n  s = input()\n  count[s] += 1\nfor s in [AC, WA, TLE, RE]:\n  print(s, "x", count[s])''',
    ),
    'abc174_b': (
        '各点が原点から距離D以下かを独立に判定できます。平方根を実際に計算する必要はありません。',
        '距離 sqrt(X^2+Y^2) <= D は、X^2+Y^2 <= D^2 と同値です。整数のまま比較すれば浮動小数誤差も避けられます。',
        '''疑似コード:\nanswer = 0\n各点 (x, y) について:\n  if x*x + y*y <= D*D:\n    answer += 1\nprint(answer)''',
    ),
    'abc175_b': (
        'N<=100なので3本の選び方を全探索できます。まずi<j<kの全組を調べ、長さが3種類とも異なるかを確認します。',
        '3辺をa<=b<=cに並べたとき、三角形を作れる条件はa+b>cです。長さの相異条件と合わせて数えます。O(N^3)で最大でも約16万組です。',
        '''疑似コード:\nanswer = 0\nfor i < j < k:\n  a,b,c = L[i],L[j],L[k]\n  if a,b,c がすべて異なる:\n    a,b,c = 昇順に並べる\n    if a + b > c:\n      answer += 1\nprint(answer)''',
    ),
}
