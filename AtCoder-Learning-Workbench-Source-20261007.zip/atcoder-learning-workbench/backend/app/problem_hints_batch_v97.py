"""Statement-checked three-stage hints for ABC149–151 B."""
HINTS_V97 = {
    'abc149_b': (
        '1回ずつK回シミュレーションする必要はありません。まず高橋君のA枚から何枚まで食べられるかをまとめて考えてください。',
        '高橋君から min(A,K) 枚を引き、その分だけKを減らします。残ったKで青木君から min(B,K) 枚を引けば十分です。',
        '''疑似コード:\nuse = min(A, K)\nA -= use\nK -= use\nB -= min(B, K)\nprint(A, B)'''
    ),
    'abc150_b': (
        '必要なのは、長さ3の連続部分文字列だけです。開始位置を左から順に調べれば十分です。',
        'i=0..N-3について S[i:i+3] が "ABC" と等しい回数を数えます。重なりがあっても開始位置ごとに独立に判定できます。',
        '''疑似コード:\nans = 0\nfor i = 0 .. N-3:\n  if S[i:i+3] == "ABC":\n    ans += 1\nprint(ans)'''
    ),
    'abc151_b': (
        '平均M以上にする条件を、N科目の合計点がいくつ以上必要かに言い換えてください。',
        '必要合計は N*M。既存N-1科目の合計を引いた値needが最後の試験で必要です。need<=0なら0、need>Kなら不可能です。',
        '''疑似コード:\nneed = N*M - sum(A)\nif need <= 0:\n  print(0)\nelif need > K:\n  print(-1)\nelse:\n  print(need)'''
    ),
}
