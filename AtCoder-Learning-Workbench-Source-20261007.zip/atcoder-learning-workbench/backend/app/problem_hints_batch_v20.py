"""Three-stage, statement-checked hints for ABC125–128 new test-bank tasks."""
HINTS_V20 = {
 'abc125_a': (
  '作られる時刻は一定間隔です。制限時刻までに何回その時刻が来るかを考えましょう。',
  'TをAで整数除算すると生産回数になります。その回数に1回の生産枚数Bを掛けます。',
  '疑似コード:\nA,B,T = 入力\n回数 = T // A\nprint(回数 * B)'),
 'abc125_b': (
  '宝石を1個追加した際に、最終的な利益が増えるかどうかだけを考えてみてください。',
  '宝石ごとに価値とコストの差が正の場合だけ選ぶと最大になります。',
  '疑似コード:\nans = 0\nfor i in 0..N-1:\n  if V[i] > C[i]: ans += V[i]-C[i]\nprint(ans)'),
 'abc125_c': (
  'ある要素だけを変更する場合、変更しない残りの要素から何が決まるか考えてください。',
  '各要素を除いた残りの最大公約数を、左右の累積GCDを使って高速に求めます。',
  '疑似コード:\nsuffix[N]=0\nfor i=N-1..0: suffix[i]=gcd(A[i],suffix[i+1])\nprefix=0; ans=0\nfor i=0..N-1:\n  ans=max(ans,gcd(prefix,suffix[i+1]))\n  prefix=gcd(prefix,A[i])\nprint(ans)'),
 'abc126_a': (
  '変更する文字は一箇所だけです。変更前後でほかの位置はそのままです。',
  '指定位置は1始まりなので、Pythonの0始まり添字ではK-1になります。該当文字をlower()で小文字にします。',
  '疑似コード:\nN,K,S=入力\n文字配列=list(S)\n文字配列[K-1]=文字配列[K-1].lower()\nprint(join(文字配列))'),
 'abc126_b': (
  '4桁を2桁ずつに分けて、月として成立するかを別々に考えてください。',
  '先頭2桁と末尾2桁が各々01〜12なら月として有効です。両方・片方・どちらも不可の4通りに分けます。',
  '疑似コード:\na = 1 <= int(S[:2]) <= 12\nb = 1 <= int(S[2:]) <= 12\nif a and b: AMBIGUOUS\nelif a: MMYY\nelif b: YYMM\nelse: NA'),
 'abc126_c': (
  'サイコロの各出目から勝てる確率を個別に考え、その結果を平均できないか考えてください。',
  '出目iからK以上になるまでに必要な表の連続回数tを数え、勝率(1/2)^tを全出目で足してNで割ります。',
  '疑似コード:\ntotal=0\nfor i=1..N:\n  score=i; probability=1\n  while score<K:\n    score*=2; probability/=2\n  total+=probability\nprint(total/N)'),
 'abc127_a': (
  '価格が変わる年齢の境目に注目して、場合分けしてください。',
  '年齢が5以下なら無料、6〜12なら半額、13以上なら定価です。Bは偶数なので整数除算できます。',
  '疑似コード:\nif A<=5: print(0)\nelif A<=12: print(B//2)\nelse: print(B)'),
 'abc127_b': (
  '次の年の値は直前の年の値だけから決まります。最初の値から順番に更新しましょう。',
  '漸化式x = r*x - Dを10回繰り返し、更新直後のxを毎回出力します。',
  '疑似コード:\nfor year in 1..10:\n  x = r*x-D\n  print(x)'),
 'abc127_c': (
  '一枚で全部を通過できるカード番号は、すべてのゲートの共通範囲に入ります。',
  '各ゲート区間の左端の最大値と右端の最小値を求め、その共通部分の長さを数えます。',
  '疑似コード:\nL=1; R=N\nfor l,r in gates:\n  L=max(L,l); R=min(R,r)\nprint(max(0,R-L+1))'),
 'abc128_a': (
  '材料を同じ単位にそろえてから、1個作るのに必要な量と比較しましょう。',
  'リンゴ1個を3片に換算し、全部の片数を2で割った整数部分がパイの個数です。',
  '疑似コード:\npieces = 3*A + P\nprint(pieces // 2)'),
 'abc128_b': (
  '並べる条件が複数ある場合、どの条件を先に比較するか整理しましょう。',
  '市名の昇順、点数の降順でソートします。元の入力順の番号も一緒に保持します。',
  '疑似コード:\nrows=[]\nfor i in 1..N: rows.append((city,-score,i))\nrows.sort()\nfor city,negative_score,i in rows: print(i)'),
}
