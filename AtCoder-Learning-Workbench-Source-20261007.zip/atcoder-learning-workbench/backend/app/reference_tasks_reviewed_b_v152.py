"""Turn 129 reviewed B batch: ABC429 B through ABC446 B."""
from __future__ import annotations

from collections import Counter
from itertools import permutations
import math
import re

TASKS = tuple(f"abc{i}_b" for i in range(429, 447))
LANES = {
    "A": TASKS[0:3], "B": TASKS[3:6], "C": TASKS[6:9],
    "D": TASKS[9:12], "E": TASKS[12:15], "F": TASKS[15:18],
}
TITLES = {
    "abc429_b":"N - 1", "abc430_b":"Count Subgrid", "abc431_b":"Robot Weight",
    "abc432_b":"Permute to Minimize", "abc433_b":"Nearest Taller", "abc434_b":"Bird Watching",
    "abc435_b":"No-Divisible Range", "abc436_b":"Magic Square", "abc437_b":"Tombola",
    "abc438_b":"Substring 2", "abc439_b":"Happy Number", "abc440_b":"Trifecta",
    "abc441_b":"Two Languages", "abc442_b":"Music Player", "abc443_b":"Setsubun",
    "abc444_b":"Digit Sum", "abc445_b":"Center Alignment", "abc446_b":"Greedy Draft",
}
PUBLISHED_SAMPLES = {
"abc429_b":[
 {"input":"4 10\n3 2 3 4\n","expected":"Yes\n"},
 {"input":"5 16\n3 3 4 2 5\n","expected":"No\n"},
 {"input":"6 16\n0 8 0 2 6 8\n","expected":"Yes\n"},
],
"abc430_b":[
 {"input":"3 2\n...\n###\n#.#\n","expected":"3\n"},
 {"input":"10 3\n..#.......\n.###......\n.#.#......\n#####.....\n#...#.....\n......####\n......#..#\n......#...\n......#..#\n......####\n","expected":"36\n"},
],
"abc431_b":[
 {"input":"31\n4\n15 92 65 35\n4\n3\n1\n4\n1\n","expected":"96\n111\n146\n131\n"},
 {"input":"41\n10\n73 8 55 26 97 48 37 47 35 55\n15\n1\n2\n7\n1\n6\n3\n10\n8\n4\n8\n1\n5\n9\n9\n3\n","expected":"114\n122\n159\n86\n134\n189\n244\n291\n317\n270\n343\n440\n475\n440\n385\n"},
],
"abc432_b":[
 {"input":"903\n","expected":"309\n"},
 {"input":"432\n","expected":"234\n"},
 {"input":"100\n","expected":"100\n"},
],
"abc433_b":[
 {"input":"4\n4 3 2 5\n","expected":"-1\n1\n2\n-1\n"},
 {"input":"3\n7 7 7\n","expected":"-1\n-1\n-1\n"},
 {"input":"6\n31 9 17 10 2 9\n","expected":"-1\n1\n1\n3\n4\n4\n"},
],
"abc434_b":[
 {"input":"10 5\n4 92\n1 16\n3 77\n4 99\n2 89\n3 8\n1 40\n5 56\n1 40\n4 77\n","expected":"32.00000000000000000000\n89.00000000000000000000\n42.50000000000000000000\n89.33333333333333333333\n56.00000000000000000000\n"},
],
"abc435_b":[
 {"input":"5\n8 6 10 5 7\n","expected":"6\n"},
 {"input":"3\n1 1 1\n","expected":"0\n"},
],
"abc436_b":[
 {"input":"3\n","expected":"8 1 6\n3 5 7\n4 9 2\n"},
 {"input":"5\n","expected":"17 24 1 8 15\n23 5 7 14 16\n4 6 13 20 22\n10 12 19 21 3\n11 18 25 2 9\n"},
],
"abc437_b":[
 {"input":"3 4 5\n12 3 5 7\n6 10 11 9\n1 2 4 8\n2\n4\n9\n6\n11\n","expected":"3\n"},
 {"input":"3 5 2\n81 63 31 16 15\n30 3 6 54 24\n26 41 48 64 66\n44\n79\n","expected":"0\n"},
 {"input":"3 5 12\n78 19 70 58 83\n12 30 80 20 27\n48 71 8 43 82\n82\n30\n43\n8\n80\n70\n20\n78\n12\n71\n19\n48\n","expected":"5\n"},
],
"abc438_b":[
 {"input":"4 2\n2025\n91\n","expected":"2\n"},
 {"input":"3 2\n438\n38\n","expected":"0\n"},
 {"input":"5 5\n00000\n11111\n","expected":"45\n"},
 {"input":"8 3\n20251227\n438\n","expected":"13\n"},
],
"abc439_b":[
 {"input":"2026\n","expected":"Yes\n"},
 {"input":"439\n","expected":"No\n"},
 {"input":"440\n","expected":"Yes\n"},
],
"abc440_b":[
 {"input":"4\n100 110 105 95\n","expected":"4 1 3\n"},
 {"input":"8\n72 74 69 70 73 75 71 77\n","expected":"3 4 7\n"},
],
"abc441_b":[
 {"input":"6 5\nahikst\naikot\n5\nasahi\nokita\nkiai\nhash\nit\n","expected":"Takahashi\nAoki\nUnknown\nTakahashi\nUnknown\n"},
 {"input":"7 6\nahiknst\nahikos\n5\nkioki\nohiki\ntashi\nnishi\nkashi\n","expected":"Aoki\nAoki\nTakahashi\nTakahashi\nUnknown\n"},
 {"input":"13 11\ndefghiqsvwxyz\nacejmoqrtwx\n15\nqhsqzhd\njcareec\nwwqxqew\nwxqxwex\njxxrtwa\ntrtqjxe\nsqyggse\nxxqwxew\nxewwxxw\nwwqxwex\nxqqxqwq\nqxxexxe\nteqeroc\neeeqqee\nvxdevyy\n","expected":"Takahashi\nAoki\nUnknown\nUnknown\nAoki\nAoki\nTakahashi\nUnknown\nUnknown\nUnknown\nUnknown\nUnknown\nAoki\nUnknown\nTakahashi\n"},
],
"abc442_b":[
 {"input":"10\n2\n1\n3\n1\n3\n1\n1\n3\n2\n2\n","expected":"No\nNo\nNo\nNo\nNo\nNo\nNo\nYes\nYes\nNo\n"},
],
"abc443_b":[
 {"input":"4 43\n","expected":"6\n"},
 {"input":"100000000 100000000\n","expected":"0\n"},
 {"input":"1234 12345678\n","expected":"3886\n"},
],
"abc444_b":[
 {"input":"30 4\n","expected":"3\n"},
 {"input":"2026 10\n","expected":"121\n"},
 {"input":"99999 45\n","expected":"1\n"},
],
"abc445_b":[
 {"input":"4\napple\nblueberry\ncoconut\ndragonfruit\n","expected":"...apple...\n.blueberry.\n..coconut..\ndragonfruit\n"},
 {"input":"6\nabc\nd\nefghi\njkl\nmnopq\nr\n","expected":".abc.\n..d..\nefghi\n.jkl.\nmnopq\n..r..\n"},
],
"abc446_b":[
 {"input":"4 5\n3\n3 1 2\n3\n3 2 1\n2\n2 3\n4\n2 5 3 1\n","expected":"3\n2\n0\n5\n"},
 {"input":"6 5\n1\n3\n2\n3 5\n5\n5 3 1 4 2\n5\n5 1 3 4 2\n5\n3 4 1 5 2\n5\n5 1 3 2 4\n","expected":"3\n5\n1\n4\n2\n0\n"},
],
}
SAMPLE_COUNTS={k:len(v) for k,v in PUBLISHED_SAMPLES.items()}
LOWER=re.compile(r"[a-z]+")
DIGITS=re.compile(r"[0-9]+")


def _lines(raw:str)->list[str]:
    if not raw.endswith("\n") or "\r" in raw: raise ValueError("newline")
    return raw[:-1].split("\n")

def _ints(s:str)->list[int]:
    try:return list(map(int,s.split()))
    except Exception as exc:raise ValueError("ints") from exc

def validate(pid:str,raw:str):
    if pid not in TASKS: raise ValueError("pid")
    l=_lines(raw)
    if pid=='abc429_b':
        if len(l)!=2:raise ValueError('shape')
        h=_ints(l[0]);a=_ints(l[1])
        if len(h)!=2:raise ValueError('head')
        n,m=h
        if not 2<=n<=100 or not 0<=m<=10000 or len(a)!=n or any(not 0<=x<=100 for x in a):raise ValueError('NA')
        return n,m,tuple(a)
    if pid=='abc430_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h;s=l[1:]
        if not(1<=m<=n<=10) or len(s)!=n or any(len(x)!=n or any(c not in '.#' for c in x) for x in s):raise ValueError('grid')
        return n,m,tuple(s)
    if pid=='abc431_b':
        if len(l)<5:raise ValueError('shape')
        x=int(l[0]);n=int(l[1]);w=_ints(l[2]);q=int(l[3]);p=[int(x) for x in l[4:]]
        if not(1<=x<=100 and 1<=n<=100 and len(w)==n and all(1<=z<=100 for z in w) and 1<=q<=100 and len(p)==q and all(1<=z<=n for z in p)):raise ValueError('data')
        return x,n,tuple(w),q,tuple(p)
    if pid=='abc432_b':
        if len(l)!=1 or not DIGITS.fullmatch(l[0]) or (len(l[0])>1 and l[0][0]=='0'):raise ValueError('X')
        x=int(l[0]);
        if not 1<=x<100000:raise ValueError('X')
        return (l[0],)
    if pid=='abc433_b':
        if len(l)!=2:raise ValueError('shape')
        n=int(l[0]);a=_ints(l[1])
        if not 1<=n<=100 or len(a)!=n or any(not 1<=x<=100 for x in a):raise ValueError('A')
        return n,tuple(a)
    if pid=='abc434_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h;rows=l[1:]
        if not(1<=m<=n<=100) or len(rows)!=n:raise ValueError('NM')
        birds=[]
        for row in rows:
            a=_ints(row)
            if len(a)!=2 or not(1<=a[0]<=m and 1<=a[1]<=100):raise ValueError('bird')
            birds.append(tuple(a))
        if set(a for a,_ in birds)!=set(range(1,m+1)):raise ValueError('coverage')
        return n,m,tuple(birds)
    if pid=='abc435_b':
        if len(l)!=2:raise ValueError('shape')
        n=int(l[0]);a=_ints(l[1])
        if not 1<=n<=50 or len(a)!=n or any(not 1<=x<=1000 for x in a):raise ValueError('A')
        return n,tuple(a)
    if pid=='abc436_b':
        if len(l)!=1:raise ValueError('shape')
        n=int(l[0])
        if not 3<=n<=99 or n%2==0:raise ValueError('N')
        return (n,)
    if pid=='abc437_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=3:raise ValueError('head')
        H,W,N=h
        if not(1<=H<=3 and 1<=W<=5 and 1<=N<=90) or len(l)!=1+H+N:raise ValueError('shape')
        grid=[]
        for row in l[1:1+H]:
            a=_ints(row)
            if len(a)!=W or any(not 1<=x<=90 for x in a):raise ValueError('grid')
            grid.append(tuple(a))
        flat=[x for r in grid for x in r]
        if len(set(flat))!=len(flat):raise ValueError('A distinct')
        b=[int(x) for x in l[1+H:]]
        if any(not 1<=x<=90 for x in b) or len(set(b))!=N:raise ValueError('B distinct')
        return H,W,N,tuple(grid),tuple(b)
    if pid=='abc438_b':
        if len(l)!=3:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h;s,t=l[1],l[2]
        if not(1<=m<=n<=100) or len(s)!=n or len(t)!=m or not DIGITS.fullmatch(s) or not DIGITS.fullmatch(t):raise ValueError('strings')
        return n,m,s,t
    if pid=='abc439_b':
        if len(l)!=1:raise ValueError('shape')
        n=int(l[0])
        if not 1<=n<=2026:raise ValueError('N')
        return (n,)
    if pid=='abc440_b':
        if len(l)!=2:raise ValueError('shape')
        n=int(l[0]);t=_ints(l[1])
        if not 3<=n<=32 or len(t)!=n or len(set(t))!=n or any(not 1<=x<=200 for x in t):raise ValueError('T')
        return n,tuple(t)
    if pid=='abc441_b':
        if len(l)<5:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h;s,t=l[1],l[2];q=int(l[3]);words=l[4:]
        if not(1<=n<=26 and 1<=m<=26 and len(s)==n and len(t)==m and LOWER.fullmatch(s) and LOWER.fullmatch(t)):raise ValueError('ST')
        if ''.join(sorted(set(s)))!=s or ''.join(sorted(set(t)))!=t:raise ValueError('sorted unique')
        if not 1<=q<=100 or len(words)!=q or any(LOWER.fullmatch(w) is None or not 1<=len(w)<=100 for w in words):raise ValueError('words')
        ss,tt=set(s),set(t)
        if any(not(set(w)<=ss or set(w)<=tt) for w in words):raise ValueError('language guarantee')
        return n,m,s,t,q,tuple(words)
    if pid=='abc442_b':
        if not l:raise ValueError('shape')
        q=int(l[0]);a=[int(x) for x in l[1:]]
        if not 1<=q<=200000 or len(a)!=q or any(x not in (1,2,3) for x in a):raise ValueError('Q')
        return q,tuple(a)
    if pid=='abc443_b':
        if len(l)!=1:raise ValueError('shape')
        a=_ints(l[0]);
        if len(a)!=2 or any(not 1<=x<=100000000 for x in a):raise ValueError('NK')
        return tuple(a)
    if pid=='abc444_b':
        if len(l)!=1:raise ValueError('shape')
        a=_ints(l[0]);
        if len(a)!=2 or any(not 1<=x<=100000 for x in a):raise ValueError('NK')
        return tuple(a)
    if pid=='abc445_b':
        if not l:raise ValueError('shape')
        n=int(l[0]);s=l[1:]
        if not 1<=n<=100 or len(s)!=n or any(LOWER.fullmatch(x) is None or not 1<=len(x)<=99 or len(x)%2==0 for x in s):raise ValueError('S')
        return n,tuple(s)
    if pid=='abc446_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h
        if not(1<=n<=100 and 1<=m<=100) or len(l)!=1+2*n:raise ValueError('shape')
        prefs=[]
        for i in range(n):
            L=int(l[1+2*i]);x=_ints(l[2+2*i])
            if not 1<=L<=m or len(x)!=L or len(set(x))!=L or any(not 1<=z<=m for z in x):raise ValueError('pref')
            prefs.append(tuple(x))
        return n,m,tuple(prefs)
    raise ValueError(pid)


def _oracle(pid:str,raw:str)->str:
    v=validate(pid,raw)
    if pid=='abc429_b':
        n,m,a=v;total=sum(a);return 'Yes' if any(total-x==m for x in a) else 'No'
    if pid=='abc430_b':
        n,m,s=v; seen=set()
        for i in range(n-m+1):
            for j in range(n-m+1): seen.add(tuple(row[j:j+m] for row in s[i:i+m]))
        return str(len(seen))
    if pid=='abc431_b':
        x,n,w,q,p=v;on=[False]*n;cur=x;out=[]
        for z in p:
            z-=1
            if on[z]:cur-=w[z]
            else:cur+=w[z]
            on[z]=not on[z];out.append(str(cur))
        return '\n'.join(out)
    if pid=='abc432_b':
        s=v[0];vals=[int(''.join(p)) for p in set(permutations(s)) if p[0]!='0'];return str(min(vals))
    if pid=='abc433_b':
        n,a=v;out=[]
        for i in range(n):
            ans=-1
            for j in range(i-1,-1,-1):
                if a[j]>a[i]:ans=j+1;break
            out.append(str(ans))
        return '\n'.join(out)
    if pid=='abc434_b':
        n,m,birds=v;tot=[0]*m;cnt=[0]*m
        for a,b in birds:tot[a-1]+=b;cnt[a-1]+=1
        return '\n'.join(repr(tot[i]/cnt[i]) for i in range(m))
    if pid=='abc435_b':
        n,a=v;ans=0
        for l in range(n):
            for r in range(l,n):
                sm=sum(a[l:r+1])
                if all(sm%x!=0 for x in a[l:r+1]):ans+=1
        return str(ans)
    if pid=='abc436_b':
        n=v[0];rows=[]
        for r in range(n):
            rows.append(' '.join(str(n*((r+c+1+n//2)%n)+((r+2*c+1)%n)+1) for c in range(n)))
        return '\n'.join(rows)
    if pid=='abc437_b':
        H,W,N,g,b=v;bs=set(b);return str(max(sum(x in bs for x in row) for row in g))
    if pid=='abc438_b':
        n,m,s,t=v;best=10**9
        for i in range(n-m+1):
            best=min(best,sum((int(s[i+j])-int(t[j]))%10 for j in range(m)))
        return str(best)
    if pid=='abc439_b':
        n=v[0];seen=set()
        while n!=1 and n not in seen:
            seen.add(n);n=sum(int(c)**2 for c in str(n))
        return 'Yes' if n==1 else 'No'
    if pid=='abc440_b':
        n,t=v;return ' '.join(str(i+1) for i,_ in sorted(enumerate(t),key=lambda z:z[1])[:3])
    if pid=='abc441_b':
        n,m,s,t,q,words=v;ss,tt=set(s),set(t);out=[]
        for w in words:
            chars=set(w)
            if chars<=ss and not chars<=tt:out.append('Takahashi')
            elif chars<=tt and not chars<=ss:out.append('Aoki')
            else:out.append('Unknown')
        return '\n'.join(out)
    if pid=='abc442_b':
        q,a=v;vol=0;play=False;out=[]
        for x in a:
            if x==1:vol+=1
            elif x==2:vol=max(0,vol-1)
            else:play=not play
            out.append('Yes' if play and vol>=3 else 'No')
        return '\n'.join(out)
    if pid=='abc443_b':
        n,k=v;total=0;y=0
        while True:
            total+=n+y
            if total>=k:return str(y)
            y+=1
    if pid=='abc444_b':
        n,k=v;return str(sum(sum(map(int,str(x)))==k for x in range(1,n+1)))
    if pid=='abc445_b':
        n,s=v;m=max(map(len,s));return '\n'.join('.'*((m-len(x))//2)+x+'.'*((m-len(x))//2) for x in s)
    if pid=='abc446_b':
        n,m,prefs=v;used=set();out=[]
        for pref in prefs:
            chosen=0
            for x in pref:
                if x not in used:chosen=x;used.add(x);break
            out.append(str(chosen))
        return '\n'.join(out)
    raise ValueError(pid)


def _numeric_tokens_ok(actual:str,expected:str,eps:float)->bool:
    try:a=[float(x) for x in actual.split()];b=[float(x) for x in expected.split()]
    except Exception:return False
    if len(a)!=len(b) or not a:return False
    for x,y in zip(a,b):
        if not math.isfinite(x) or not math.isfinite(y):return False
        if not(abs(x-y)<=eps or abs(x-y)<=eps*abs(y)):return False
    return True

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:exp=_oracle(pid,raw)
    except Exception:return False
    if pid=='abc434_b':return _numeric_tokens_ok(actual,exp,1e-5)
    return actual.rstrip('\n')==exp.rstrip('\n')

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc434_b':return _numeric_tokens_ok(stdout,expected,1e-5) and independent_check(pid,raw,expected)
    return stdout.rstrip('\n')==expected.rstrip('\n') and independent_check(pid,raw,expected)

def _case(raw:str,idx:int)->dict[str,str]:return {'input':raw,'category':f'task_specific_{idx:02d}'}

def generate(pid:str):
    out=[]
    if pid=='abc429_b':
        for i in range(1,18):
            n=2+i; a=[(i*j)%101 for j in range(1,n+1)]; total=sum(a);m=total-a[i%n] if i%2 else min(10000,total+1);out.append(_case(f'{n} {m}\n'+' '.join(map(str,a))+'\n',i))
        out.append({'input':'100 9900\n'+' '.join(['100']*100)+'\n','category':'constraint_max'})
    elif pid=='abc430_b':
        for i in range(1,18):
            n=10;m=1+((i-1)%10)
            bits=f'{i:05b}'
            s=[]
            for r in range(n):
                row=['.']*n
                if r==0:
                    for c,b in enumerate(bits):
                        if b=='1':row[c]='#'
                if r==1:row[i%10]='#'
                s.append(''.join(row))
            out.append(_case(f'{n} {m}\n'+'\n'.join(s)+'\n',i))
        s=[''.join('#' if (r+c)%3==0 else '.' for c in range(10)) for r in range(10)];out.append({'input':'10 10\n'+'\n'.join(s)+'\n','category':'constraint_max'})
    elif pid=='abc431_b':
        for i in range(1,18):
            n=1+i%10;x=1+i%100;w=[1+(i*7+j*3)%100 for j in range(n)];q=1+i%15;p=[1+(i+j*j)%n for j in range(q)];out.append(_case(f'{x}\n{n}\n'+' '.join(map(str,w))+f'\n{q}\n'+'\n'.join(map(str,p))+'\n',i))
        w=list(range(1,101));p=list(range(1,101));out.append({'input':'100\n100\n'+' '.join(map(str,w))+'\n100\n'+'\n'.join(map(str,p))+'\n','category':'constraint_max'})
    elif pid=='abc432_b':
        vals=[1,10,101,903,432,100,1203,9090,1000,9876,10203,10020,11110,50001,80808,12345,90001]
        out=[_case(f'{x}\n',i+1) for i,x in enumerate(vals)];out.append({'input':'99999\n','category':'constraint_max'})
    elif pid=='abc433_b':
        for i in range(1,18):
            n=i;a=[1+((j*17+i*13)%100) for j in range(n)];out.append(_case(f'{n}\n'+' '.join(map(str,a))+'\n',i))
        a=[1+((j*37)%100) for j in range(100)];out.append({'input':'100\n'+' '.join(map(str,a))+'\n','category':'constraint_max'})
    elif pid=='abc434_b':
        for i in range(1,18):
            m=1+i%5;n=m+i%8;birds=[(j%m+1,1+(i*11+j*7)%100) for j in range(n)];out.append(_case(f'{n} {m}\n'+'\n'.join(f'{a} {b}' for a,b in birds)+'\n',i))
        birds=[(i,100 if i%2 else 1) for i in range(1,101)];out.append({'input':'100 100\n'+'\n'.join(f'{a} {b}' for a,b in birds)+'\n','category':'constraint_max'})
    elif pid=='abc435_b':
        for i in range(1,18):
            n=i;a=[1+((i*31+j*17)%1000) for j in range(n)];out.append(_case(f'{n}\n'+' '.join(map(str,a))+'\n',i))
        out.append({'input':'50\n'+' '.join(str(951+i%50) for i in range(50))+'\n','category':'constraint_max'})
    elif pid=='abc436_b':
        vals=list(range(3,36,2));out=[_case(f'{n}\n',i+1) for i,n in enumerate(vals)];out.append({'input':'99\n','category':'constraint_max'})
    elif pid=='abc437_b':
        for i in range(1,18):
            H=1+i%3;W=1+(i*2)%5;size=H*W;grid=[list(range(r*W+1,(r+1)*W+1)) for r in range(H)];N=1+i%20;b=[1+((i*7+j*11)%90) for j in range(N)]
            # force B distinct while retaining bounds
            b=[];cur=(i*7)%90
            while len(b)<N:
                x=cur%90+1;cur+=11
                if x not in b:b.append(x)
            out.append(_case(f'{H} {W} {N}\n'+'\n'.join(' '.join(map(str,r)) for r in grid)+'\n'+'\n'.join(map(str,b))+'\n',i))
        grid=[list(range(r*5+1,r*5+6)) for r in range(3)];out.append({'input':'3 5 90\n'+'\n'.join(' '.join(map(str,r)) for r in grid)+'\n'+'\n'.join(map(str,range(1,91)))+'\n','category':'constraint_max'})
    elif pid=='abc438_b':
        for i in range(1,18):
            n=2+i;m=1+i%n;s=''.join(str((i+j*3)%10) for j in range(n));t=''.join(str((9-i+j*7)%10) for j in range(m));out.append(_case(f'{n} {m}\n{s}\n{t}\n',i))
        out.append({'input':'100 100\n'+'0'*100+'\n'+'1'*100+'\n','category':'constraint_max'})
    elif pid=='abc439_b':
        out=[_case(f'{i}\n',i) for i in range(1,18)];out.append({'input':'2026\n','category':'constraint_max'})
    elif pid=='abc440_b':
        for i in range(1,18):
            n=3+i;vals=list(range(1,n+1));shift=i%n;t=vals[shift:]+vals[:shift];out.append(_case(f'{n}\n'+' '.join(map(str,t))+'\n',i))
        t=list(range(200,168,-1));out.append({'input':'32\n'+' '.join(map(str,t))+'\n','category':'constraint_max'})
    elif pid=='abc441_b':
        S='abc';T='bcd';words=['a','d','b','bc','ab','cd','c','bbb','aaa','ddd']
        for i in range(1,18):
            q=i;ws=[words[(i+j)%len(words)] for j in range(q)];out.append(_case(f'3 3\n{S}\n{T}\n{q}\n'+'\n'.join(ws)+'\n',i))
        alpha='abcdefghijklmnopqrstuvwxyz';out.append({'input':'26 26\n'+alpha+'\n'+alpha+'\n100\n'+'\n'.join(['abcdefghijklmnopqrstuvwxyz']*100)+'\n','category':'constraint_max'})
    elif pid=='abc442_b':
        for i in range(1,18):
            q=i;a=[1+((i+j*j)%3) for j in range(q)];out.append(_case(f'{q}\n'+'\n'.join(map(str,a))+'\n',i))
        a=[1,1,1,3,2,1,3,2,1,3]*20000;out.append({'input':'200000\n'+'\n'.join(map(str,a))+'\n','category':'constraint_max'})
    elif pid=='abc443_b':
        vals=[(1,1),(1,2),(2,3),(4,43),(10,10),(10,11),(100,1000),(999,1),(1,100000),(1234,12345678),(100000,100000000),(9999999,100000000),(50000000,100000000),(100000000,1),(42,4242),(31415,92653589),(99999999,100000000)]
        out=[_case(f'{n} {k}\n',i+1) for i,(n,k) in enumerate(vals)];out.append({'input':'100000000 100000000\n','category':'constraint_max'})
    elif pid=='abc444_b':
        vals=[(1,1),(9,9),(10,1),(30,4),(99,18),(100,1),(999,27),(2026,10),(5000,5),(9999,36),(10000,1),(54321,15),(99999,45),(100000,1),(100000,2),(77777,35),(12345,15)]
        out=[_case(f'{n} {k}\n',i+1) for i,(n,k) in enumerate(vals)];out.append({'input':'100000 100000\n','category':'constraint_max'})
    elif pid=='abc445_b':
        for i in range(1,18):
            n=1+i%8;s=[]
            for j in range(n):
                L=1+2*((i+j)%10);s.append(chr(97+(i+j)%26)*L)
            out.append(_case(f'{n}\n'+'\n'.join(s)+'\n',i))
        s=[chr(97+i%26)*99 for i in range(100)];out.append({'input':'100\n'+'\n'.join(s)+'\n','category':'constraint_max'})
    elif pid=='abc446_b':
        for i in range(1,18):
            n=1+i%8;m=1+i%10;rows=[]
            for c in range(n):
                L=1+(i+c)%m;pref=[1+((c+j+i)%m) for j in range(L)];rows.extend([str(L),' '.join(map(str,pref))])
            out.append(_case(f'{n} {m}\n'+'\n'.join(rows)+'\n',i))
        rows=[]
        full=' '.join(map(str,range(1,101)))
        for _ in range(100):rows.extend(['100',full])
        out.append({'input':'100 100\n'+'\n'.join(rows)+'\n','category':'constraint_max'})
    else:raise ValueError(pid)
    if len(out)!=18 or len({x['input'] for x in out})!=18 or out[-1]['category']!='constraint_max':raise ValueError(f'{pid}: generated case construction failed ({len(out)}, {len({x["input"] for x in out})})')
    for row in out:validate(pid,row['input'])
    return out

REFERENCE_CODE={
'abc429_b':"N,M=map(int,input().split());A=list(map(int,input().split()));s=sum(A);print('Yes' if s-M in A else 'No')\n",
'abc430_b':"N,M=map(int,input().split());S=[input().strip() for _ in range(N)];a=set()\nfor i in range(N-M+1):\n for j in range(N-M+1):a.add('\\n'.join(x[j:j+M] for x in S[i:i+M]))\nprint(len(a))\n",
'abc431_b':"X=int(input());N=int(input());W=list(map(int,input().split()));Q=int(input());on=set()\nfor _ in range(Q):\n p=int(input())-1\n if p in on:X-=W[p];on.remove(p)\n else:X+=W[p];on.add(p)\n print(X)\n",
'abc432_b':"s=list(input().strip());s.sort();i=next(i for i,c in enumerate(s) if c!='0');s[0],s[i]=s[i],s[0];print(''.join(s))\n",
'abc433_b':"N=int(input());A=list(map(int,input().split()));st=[]\nfor i,x in enumerate(A):\n while st and A[st[-1]]<=x:st.pop()\n print(st[-1]+1 if st else -1);st.append(i)\n",
'abc434_b':"N,M=map(int,input().split());v=[[] for _ in range(M)]\nfor _ in range(N):a,b=map(int,input().split());v[a-1].append(b)\nfor x in v:print(sum(x)/len(x))\n",
'abc435_b':"N=int(input());A=list(map(int,input().split()));ans=0\nfor l in range(N):\n s=0\n for r in range(l,N):\n  s+=A[r]\n  if all(s%A[i] for i in range(l,r+1)):ans+=1\nprint(ans)\n",
'abc436_b':"N=int(input());A=[[0]*N for _ in range(N)];r=0;c=(N-1)//2\nfor k in range(1,N*N+1):\n A[r][c]=k\n nr=(r-1)%N;nc=(c+1)%N\n if A[nr][nc]:r=(r+1)%N\n else:r,c=nr,nc\nfor row in A:print(*row)\n",
'abc437_b':"H,W,N=map(int,input().split());where={}\nfor r in range(H):\n for x in map(int,input().split()):where[x]=r\nc=[0]*H\nfor _ in range(N):\n x=int(input())\n if x in where:c[where[x]]+=1\nprint(max(c))\n",
'abc438_b':"N,M=map(int,input().split());S=input().strip();T=input().strip();print(min(sum((int(S[i+j])-int(T[j]))%10 for j in range(M)) for i in range(N-M+1)))\n",
'abc439_b':"def f(n):return sum(int(c)**2 for c in str(n))\nN=int(input());slow=N;fast=N\nwhile True:\n slow=f(slow);fast=f(f(fast))\n if slow==1 or fast==1:print('Yes');break\n if slow==fast:print('No');break\n",
'abc440_b':"N=int(input());T=list(map(int,input().split()));print(*[i+1 for i in sorted(range(N),key=lambda i:T[i])[:3]])\n",
'abc441_b':"N,M=map(int,input().split());S=set(input().strip());T=set(input().strip());Q=int(input())\nfor _ in range(Q):\n w=set(input().strip())\n if w<=S and not w<=T:print('Takahashi')\n elif w<=T and not w<=S:print('Aoki')\n else:print('Unknown')\n",
'abc442_b':"Q=int(input());v=0;play=False\nfor _ in range(Q):\n a=int(input())\n if a==1:v+=1\n elif a==2:v=max(0,v-1)\n else:play=not play\n print('Yes' if play and v>=3 else 'No')\n",
'abc443_b':"N,K=map(int,input().split());lo=-1;hi=1\ndef s(t):return (t+1)*(2*N+t)//2\nwhile s(hi)<K:hi*=2\nwhile hi-lo>1:\n mid=(lo+hi)//2\n if s(mid)>=K:hi=mid\n else:lo=mid\nprint(hi)\n",
'abc444_b':"N,K=map(int,input().split());ds=[0]*(N+1)\nfor i in range(1,N+1):ds[i]=ds[i//10]+i%10\nprint(sum(x==K for x in ds[1:]))\n",
'abc445_b':"N=int(input());S=[input().strip() for _ in range(N)];m=max(map(len,S))\nfor s in S:\n k=(m-len(s))//2;print('.'*k+s+'.'*k)\n",
'abc446_b':"N,M=map(int,input().split());used=[False]*(M+1)\nfor _ in range(N):\n L=int(input());X=list(map(int,input().split()));ans=0\n for x in X:\n  if not used[x]:ans=x;used[x]=True;break\n print(ans)\n",
}
