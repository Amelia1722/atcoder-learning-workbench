"""Reviewed C tasks with threshold layers, capped skill DP and Decimal geometry."""
from __future__ import annotations
from bisect import bisect_left
from decimal import Decimal,localcontext
from fractions import Fraction
from itertools import combinations_with_replacement
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(164,170))
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES={'abc168_c':'numeric_tolerance_1e-9'}
Data=tuple[object,...]
Case=dict[str,str]
Quad=tuple[int,int,int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers')
    values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'fields');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==164:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');words=tuple(rows[1:]);require(all(re.fullmatch('[a-z]{1,10}',s) is not None for s in words),'words');return (words,)
    if number==165:
        n,m,q=ints(rows[0],3);require(2<=n<=10 and 1<=m<=10 and 1<=q<=50 and len(rows)==q+1,'shape');claims=tuple(cast(Quad,ints(row,4)) for row in rows[1:]);require(all(1<=a<b<=n and 0<=c<m and 1<=d<=100000 for a,b,c,d in claims) and len({(a,b,c) for a,b,c,d in claims})==q,'constraints');return n,m,claims
    if number==166:
        n,m=ints(rows[0],2);require(2<=n<=100000 and 1<=m<=100000 and len(rows)==m+2,'shape');heights=ints(rows[1],n);edges=tuple(cast(tuple[int,int],ints(row,2)) for row in rows[2:]);require(all(1<=v<=10**9 for v in heights) and all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges),'graph');return heights,edges
    if number==167:
        n,m,x=ints(rows[0],3);require(1<=n<=12 and 1<=m<=12 and 1<=x<=100000 and len(rows)==n+1,'shape');books=tuple(ints(row,m+1) for row in rows[1:]);require(all(1<=row[0]<=100000 and all(0<=v<=100000 for v in row[1:]) for row in books),'skills');return m,x,books
    if number==168:
        require(len(rows)==1,'shape');a,b,h,m=ints(rows[0],4);require(1<=a<=1000 and 1<=b<=1000 and 0<=h<=11 and 0<=m<=59,'clock');return a,b,h,m
    require(len(rows)==1 and re.fullmatch(r'(?:0|[1-9][0-9]*) [0-9]\.[0-9]{2}',rows[0]) is not None,'currency');a,b=rows[0].split(' ');require(int(a)<=10**15,'amount');return int(a),b

def _threshold_score(n:int,m:int,claims:tuple[Quad,...])->int:
    # M-1 transitions between adjacent integer levels, placed at N+1 boundaries.
    grouped:dict[tuple[int,int],dict[int,int]]={}
    for a,b,c,d in claims:grouped.setdefault((a,b),{})[c]=d
    return max(sum(scores.get(bisect_left(layers,b)-bisect_left(layers,a),0) for (a,b),scores in grouped.items()) for layers in combinations_with_replacement(range(n+1),m-1))

def _skill_dp(m:int,x:int,books:tuple[tuple[int,...],...])->int:
    costs={(0,)*m:0}
    for book in books:
        updates=dict(costs)
        for state,cost in costs.items():
            after=tuple(min(x,a+b) for a,b in zip(state,book[1:]));price=cost+book[0]
            if price<updates.get(after,10**18):updates[after]=price
        costs=updates
    return costs.get((x,)*m,-1)

def _clock_geometry(a:int,b:int,h:int,m:int)->str:
    with localcontext() as context:
        context.prec=70
        pi=Decimal('3.1415926535897932384626433832795028841971693993751058209749445923078164')
        def trig(angle:Decimal)->tuple[Decimal,Decimal]:
            angle%=2*pi
            if angle>pi:angle-=2*pi
            sine=term_s=angle;cosine=term_c=Decimal(1);square=angle*angle
            for j in range(1,100):
                term_s*=-square/((2*j)*(2*j+1));term_c*=-square/((2*j-1)*(2*j));sine+=term_s;cosine+=term_c
            return sine,cosine
        sh,ch=trig(Decimal(60*h+m)*pi/360);sm,cm=trig(Decimal(m)*pi/30)
        return str(((a*sh-b*sm)**2+(a*ch-b*cm)**2).sqrt())

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==164:
        words=sorted(cast(tuple[str,...],data[0]));return str(1+sum(a!=b for a,b in zip(words,words[1:])))
    if number==165:return str(_threshold_score(*cast(tuple[int,int,tuple[Quad,...]],data)))
    if number==166:
        heights,edges=cast(tuple[tuple[int,...],tuple[tuple[int,int],...]],data);neighbors=[0]*len(heights)
        for a,b in edges:neighbors[a-1]=max(neighbors[a-1],heights[b-1]);neighbors[b-1]=max(neighbors[b-1],heights[a-1])
        return str(sum(h>neighbor for h,neighbor in zip(heights,neighbors)))
    if number==167:return str(_skill_dp(*cast(tuple[int,int,tuple[tuple[int,...],...]],data)))
    if number==168:return _clock_geometry(*cast(tuple[int,int,int,int],data))
    a,b=cast(tuple[int,str],data);return str(Fraction(a)*Fraction(b)//1)

def numeric_valid(actual:str,expected:str)->bool:
    if len(actual)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',actual) is None:return False
    try:
        a=Decimal(actual);b=Decimal(expected)
        if not a.is_finite() or not b.is_finite() or abs(a.adjusted())>1000:return False
        difference=abs(Fraction(a)-Fraction(b));epsilon=Fraction(1,10**9)
        return difference<=epsilon or difference<=epsilon*abs(Fraction(b))
    except (ArithmeticError,ValueError):return False

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        expected=oracle(pid,raw);actual=actual.removesuffix('\n')
        return numeric_valid(actual,expected) if pid=='abc168_c' else actual==expected
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc168_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc164_c':"n=int(input());print(len({input() for _ in range(n)}))\n",
'abc165_c':"n,m,q=map(int,input().split());claims=[tuple(map(int,input().split())) for _ in range(q)];answer=0\ndef visit(seq):\n global answer\n if len(seq)==n:\n  answer=max(answer,sum(d for a,b,c,d in claims if seq[b-1]-seq[a-1]==c));return\n for v in range(seq[-1] if seq else 1,m+1):visit(seq+[v])\nvisit([]);print(answer)\n",
'abc166_c':"n,m=map(int,input().split());h=list(map(int,input().split()));good=[True]*n\nfor _ in range(m):\n a,b=map(int,input().split());a-=1;b-=1\n if h[a]<=h[b]:good[a]=False\n if h[b]<=h[a]:good[b]=False\nprint(sum(good))\n",
'abc167_c':"n,m,x=map(int,input().split());books=[list(map(int,input().split())) for _ in range(n)];best=10**18\nfor mask in range(1<<n):\n skills=[0]*m;cost=0\n for j,book in enumerate(books):\n  if mask>>j&1:\n   cost+=book[0]\n   for k,value in enumerate(book[1:]):skills[k]+=value\n if all(v>=x for v in skills):best=min(best,cost)\nprint(-1 if best==10**18 else best)\n",
'abc168_c':"from math import cos,pi,sqrt\na,b,h,m=map(int,input().split());angle=2*pi*((h*60+m)/720-m/60);print(sqrt(max(0,a*a+b*b-2*a*b*cos(angle))))\n",
'abc169_c':"a,b=input().split();cents=int(b.replace('.',''));print(int(a)*cents//100)\n"}

def line(values:tuple[int,...]|list[int])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16200+number)
    if number==164:
        def prizes(words:list[str])->str:return f'{len(words)}\n'+'\n'.join(words)+'\n'
        raws=[prizes(['a']),prizes(['a','a']),prizes(['a','b']),prizes(['ab','ba'])]+[prizes([''.join(rng.choice('abc') for _ in range(1+j%10)) for _ in range(j+3)]) for j in range(1,13)]+[prizes(['z'*10]*200000),prizes([format(j,'x').translate(str.maketrans('0123456789','ghijklmnop')).ljust(10,'z') for j in range(200000)])]
    elif number==165:
        def score(n:int,m:int,claims:list[Quad])->str:return f'{n} {m} {len(claims)}\n'+''.join(line(c) for c in claims)
        raws=[score(2,1,[(1,2,0,1)]),score(2,2,[(1,2,0,1),(1,2,1,100000)]),score(3,2,[(1,2,0,7),(2,3,1,9),(1,3,0,13)])]
        for j in range(1,15):
            n=2+j%5;m=1+j%5;triples=[(a,b,c) for a in range(1,n) for b in range(a+1,n+1) for c in range(m)];rng.shuffle(triples)
            raws.append(score(n,m,[(a,b,c,rng.randrange(1,100001)) for a,b,c in triples[:min(8,len(triples))]]))
        claims=[(a,b,b-a,100000) for a in range(1,10) for b in range(a+1,11)]+[(1,b,0,100000) for b in range(2,7)]
        raws.append(score(10,10,claims))
    elif number==166:
        def graph(heights:list[int],edges:list[tuple[int,int]])->str:return f'{len(heights)} {len(edges)}\n'+line(heights)+''.join(line(e) for e in edges)
        raws=[graph([1,1],[(1,2)]),graph([1,2],[(1,2)]),graph([2,1,3],[(1,2),(1,2)]),graph([3,2,1],[(1,2),(2,3)])]+[graph([rng.randrange(1,10**9+1) for _ in range(n)],[(j,j+1) for j in range(1,n)]) for n in range(4,16)]+[graph([10**9]*100000,[(1,2)]*100000),graph(list(range(999900001,10**9+1)),[(j,j+1) for j in range(1,100000)]+[(100000,1)])]
    elif number==167:
        def books(m:int,x:int,rows:list[tuple[int,...]])->str:return f'{len(rows)} {m} {x}\n'+''.join(line(r) for r in rows)
        raws=[books(1,1,[(1,0)]),books(1,1,[(1,1)]),books(2,5,[(1,5,0),(2,0,5)]),books(2,5,[(9,5,5),(1,3,3),(1,2,2)])]
        for j in range(1,13):
            m=1+j%5;raws.append(books(m,3+j,[(rng.randrange(1,101),)+tuple(rng.randrange(20) for _ in range(m)) for _ in range(1+j%8)]))
        raws.append(books(12,100000,[(100000,)+(0,)*12]*12));raws.append(books(12,100000,[(100000,)+(100000,)*12]*12))
    elif number==168:raws=[line(t) for t in ((1,1,0,0),(1,2,0,0),(1000,1000,0,0),(1000,1000,0,1),(1000,999,0,1),(1,1,6,0),(3,4,3,0),(3,4,9,0),(1,1000,11,59),(1000,1,11,59),(999,1000,3,17),(1000,1000,1,5),(1000,1000,11,55),(2,3,0,59),(1000,1000,5,27),(1,1,11,59),(999,999,11,59),(1000,1000,11,59))]
    else:
        pairs=((0,'0.00'),(0,'9.99'),(1,'0.00'),(1,'0.01'),(1,'9.99'),(99,'0.01'),(100,'0.01'),(101,'0.01'),(1000000000000000,'0.01'),(1000000000000000,'9.98'),(999999999999999,'9.99'),(999999999999999,'0.99'),(198,'1.10'),(999,'9.99'),(123456789012345,'1.23'),(1,'1.00'),(1000000000000000,'0.00'),(1000000000000000,'9.99'))
        raws=[f'{a} {b}\n' for a,b in pairs]
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc164_c':('同じ名前の景品は一種類として数えます。','重複を除く集合にすべての名前を追加し、その要素数を求めます。','疑似コード: prizes=set(); repeat N times: prizes.add(read_string()); print(len(prizes))。'),
'abc165_c':('長さNの非減少列を列挙できるか考えます。','次の要素を直前以上M以下から選び、完成した各列の得点を求めます。','疑似コード: dfs(prefix): if len=N: answer=max(answer,Σd where A[b]-A[a]=c); else: for v=last_or_1..M: dfs(prefix+[v]); print(answer)。'),
'abc166_c':('隣の展望台が同じ高さでも、良い展望台にはなりません。','道ごとに両端の高さを比較し、相手以下の高さの展望台を候補から外します。','疑似コード: good=[true]*N; for (a,b): if H[a]<=H[b]: good[a]=false; if H[b]<=H[a]: good[b]=false; print(count(good))。'),
'abc167_c':('本は12冊以下なので、購入する組合せをすべて試せます。','各部分集合の費用と理解度を合計し、すべての理解度がX以上なら最小費用を更新します。','疑似コード: for subset in all_subsets(books): skills=sum_skills(subset); if all skills>=X: answer=min(answer,sum_cost(subset)); print(answer or -1)。'),
'abc168_c':('時針も分が進むにつれて動くことに注意します。','時針の角度は2π(60H+M)/720、分針は2πM/60です。角度差と余弦定理で距離を求めます。','疑似コード: theta=2*pi*((60*H+M)/720-M/60); print(sqrt(A*A+B*B-2*A*B*cos(theta)))。'),
'abc169_c':('小数を浮動小数点で掛けると、切り捨て前に誤差が出る場合があります。','Bは小数第二位までなので、文字列から100倍した整数に変換します。','疑似コード: cents=parse_integer(B with decimal_point_removed); print(A*cents//100)。')}

TITLES={'abc164_c': 'gacha', 'abc165_c': 'Many Requirements', 'abc166_c': 'Peaks', 'abc167_c': 'Skill Up', 'abc168_c': ': (Colon)', 'abc169_c': 'Multiplication 3'}
PUBLISHED_SAMPLES={'abc164_c': [{'input': '3\napple\norange\napple\n', 'expected': '2\n'}, {'input': '5\ngrape\ngrape\ngrape\ngrape\ngrape\n', 'expected': '1\n'}, {'input': '4\naaaa\na\naaa\naa\n', 'expected': '4\n'}], 'abc165_c': [{'input': '3 4 3\n1 3 3 100\n1 2 2 10\n2 3 2 10\n', 'expected': '110\n'}, {'input': '4 6 10\n2 4 1 86568\n1 4 0 90629\n2 3 0 90310\n3 4 1 29211\n3 4 3 78537\n3 4 2 8580\n1 2 1 96263\n1 4 2 2156\n1 2 0 94325\n1 4 3 94328\n', 'expected': '357500\n'}, {'input': '10 10 1\n1 10 9 1\n', 'expected': '1\n'}], 'abc166_c': [{'input': '4 3\n1 2 3 4\n1 3\n2 3\n2 4\n', 'expected': '2\n'}, {'input': '6 5\n8 6 9 1 2 1\n1 3\n4 2\n4 3\n4 6\n4 6\n', 'expected': '3\n'}], 'abc167_c': [{'input': '3 3 10\n60 2 2 4\n70 8 7 9\n50 2 3 9\n', 'expected': '120\n'}, {'input': '3 3 10\n100 3 1 4\n100 1 5 9\n100 2 6 5\n', 'expected': '-1\n'}, {'input': '8 5 22\n100 3 7 5 3 1\n164 4 5 2 7 8\n334 7 2 7 2 9\n234 4 7 2 8 2\n541 5 4 3 3 6\n235 4 8 6 9 7\n394 3 6 1 6 2\n872 8 4 3 7 2\n', 'expected': '1067\n'}], 'abc168_c': [{'input': '3 4 9 0\n', 'expected': '5.00000000000000000000\n'}, {'input': '3 4 10 40\n', 'expected': '4.56425719433005567605\n'}], 'abc169_c': [{'input': '198 1.10\n', 'expected': '217\n'}, {'input': '1 0.01\n', 'expected': '0\n'}, {'input': '1000000000000000 9.99\n', 'expected': '9990000000000000\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
