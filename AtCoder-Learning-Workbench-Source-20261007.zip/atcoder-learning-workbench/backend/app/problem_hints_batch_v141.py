"""Statement-checked three-stage hints for ABC281–283 B."""
HINTS_V141 = {
    'abc281_b': (
        '条件を一つずつ分けると、文字列全体の長さ、先頭・末尾、中央6文字の3点を確認すれば十分です。',
        '長さは8、先頭と末尾は英大文字、中央6文字は数字で、さらに先頭の数字が0ではないことを確認します。中央を整数にして100000以上999999以下でも判定できます。',
        '疑似コード:\nif len(S) != 8: print("No")\nelif not uppercase(S[0]) or not uppercase(S[7]): print("No")\nelif not all digits in S[1:7]: print("No")\nelif not (100000 <= int(S[1:7]) <= 999999): print("No")\nelse: print("Yes")',
    ),
    'abc282_b': (
        '参加者は最大30人なので、2人の組を全て試しても高々435組です。各組がM問すべてを解けるか確認できます。',
        '参加者i,jの各問題kについて、`S[i][k]` と `S[j][k]` の少なくとも一方が `o` ならその問題を解けます。全M問で成立する組だけ数えます。',
        '疑似コード:\nans = 0\nfor i = 0 .. N-1:\n  for j = i+1 .. N-1:\n    ok = true\n    for k = 0 .. M-1:\n      if S[i][k] == "x" and S[j][k] == "x": ok = false\n    if ok: ans += 1\nprint(ans)',
    ),
    'abc283_b': (
        '必要なのは指定位置の値の更新と参照だけです。各クエリのたびに配列全体を作り直す必要はありません。',
        '配列Aをそのまま保持し、`1 k x` なら `A[k-1]=x`、`2 k` なら `A[k-1]` を出力します。どちらも1クエリO(1)です。',
        '疑似コード:\nA = read array\nfor query in queries:\n  if query.type == 1:\n    A[k-1] = x\n  else:\n    print(A[k-1])',
    ),
}
