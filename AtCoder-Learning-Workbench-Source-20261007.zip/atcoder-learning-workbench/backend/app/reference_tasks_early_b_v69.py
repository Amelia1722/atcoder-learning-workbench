"""ABC065–067 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS=('abc065_b','abc066_b','abc067_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
LOWER=re.compile(r'[a-z]+',re.ASCII)

def _even_string(s:str)->bool:
    if len(s)%2: return False
    m=len(s)//2
    return s[:m]==s[m:]

def _best_shorter_even_prefix(s:str)->int:
    for length in range(len(s)-1,1,-1):
        if length%2==0:
            half=length//2
            if s[:half]==s[half:length]:
                return length
    return 0

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc065_b':
        if not lines or POS.fullmatch(lines[0]) is None: raise ValueError('header')
        n=int(lines[0])
        if not 2<=n<=100_000 or len(lines)!=n+1: raise ValueError('shape')
        if any(POS.fullmatch(x) is None for x in lines[1:]): raise ValueError('mapping')
        a=list(map(int,lines[1:]))
        if any(not 1<=x<=n for x in a): raise ValueError('range')
        return n,a
    if pid=='abc066_b':
        if len(lines)!=1 or not 2<=len(lines[0])<=200 or LOWER.fullmatch(lines[0]) is None:
            raise ValueError('string')
        s=lines[0]
        if not _even_string(s) or _best_shorter_even_prefix(s)==0:
            raise ValueError('statement guarantee')
        return s
    if len(lines)!=2: raise ValueError('line count')
    head=lines[0].split(' ')
    if len(head)!=2 or any(POS.fullmatch(x) is None for x in head): raise ValueError('header')
    n,k=map(int,head)
    vals=lines[1].split(' ')
    if not (1<=k<=n<=50) or len(vals)!=n or any(POS.fullmatch(x) is None for x in vals):
        raise ValueError('sticks')
    a=list(map(int,vals))
    if any(not 1<=x<=50 for x in a): raise ValueError('range')
    return n,k,a

def independent_check(pid:str,raw:str,output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc065_b':
        n,a=value
        seen=[False]*n; cur=0; presses=0
        while not seen[cur]:
            if cur==1: return output==str(presses)
            seen[cur]=True
            cur=a[cur]-1; presses+=1
        return output=='-1'
    if pid=='abc066_b':
        return output==str(_best_shorter_even_prefix(value))
    n,k,a=value
    pool=a[:]; total=0
    for _ in range(k):
        m=max(pool); total+=m; pool.remove(m)
    return output==str(total)

def generate(pid:str,seed:int=69)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v69:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc065_b':
        def fmt(a): return f'{len(a)}\n'+''.join(f'{x}\n' for x in a)
        fixtures=[
          [2,1],[1,2],[3,1,2],[3,4,1,2],[3,3,4,2,4],[2,3,4,5,1],
          [3,2,3],[4,2,1,3],[2,1,4,3],[5,5,5,5,5],
          [4,3,2,1],[6,1,2,3,4,5],
        ]
        for a in fixtures: add('boundary' if len(a)<=2 else 'normal',fmt(a))
        while len(rows)<17:
            n=rng.randint(2,40); a=[rng.randint(1,n) for _ in range(n)]
            add('random',fmt(a))
        n=100_000; a=[1]*n
        a[0]=3
        for i in range(2,n-1): a[i]=i+2
        a[n-1]=2
        a[1]=2
        add('constraint_max',fmt(a))
    elif pid=='abc066_b':
        fixtures=['aaaa','abababab','abcabcabcabc','abaababaab','zzzz','abcabcabcabcabcabcabcabc',
                  'xyxyxyxy','aaaaaaaa','abcabcabcabcabcabc','akasakaakasakasakaakas',
                  'qwertyqwertyqwertyqwerty','abababababab']
        for s in fixtures: add('boundary' if len(s)==4 else 'normal',s+'\n')
        while len(rows)<17:
            m=rng.randint(1,20)
            v=''.join(chr(97+rng.randrange(26)) for _ in range(m))
            add('random',v*4+'\n')
        add('constraint_max','a'*200+'\n')
    else:
        def fmt(k,a): return f'{len(a)} {k}\n'+' '.join(map(str,a))+'\n'
        fixtures=[(1,[1]),(1,[50]),(3,[1,2,3,4,5]),(1,[5,5,5]),(3,[5,5,5]),
                  (2,[50,1]),(4,[4,1,3,2]),(2,[1,50,49]),(5,[9,8,7,6,5]),
                  (3,[2,2,50,1]),(1,[1,2,3,4,50]),(6,[6,5,4,3,2,1])]
        for k,a in fixtures: add('boundary' if len(a)==1 or k==len(a) else 'normal',fmt(k,a))
        while len(rows)<17:
            n=rng.randint(1,50); k=rng.randint(1,n); a=[rng.randint(1,50) for _ in range(n)]
            add('random',fmt(k,a))
        add('constraint_max',fmt(50,[50]*50))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
