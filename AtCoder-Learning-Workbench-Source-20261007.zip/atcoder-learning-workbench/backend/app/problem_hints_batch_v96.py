"""Statement-checked three-stage hints for ABC146–148 B."""
HINTS_V96 = {
    'abc146_b': (
        '各文字を同じ個数だけ進めます。Zを越えたときにAへ戻る循環だけ整理してください。',
        '各文字を0〜25の数に直し、Nを足して26で割った余りを再び英大文字へ戻すと簡潔です。',
        '''疑似コード:\nanswer = ""\nfor c in S:\n  x = ord(c) - ord("A")\n  x = (x + N) % 26\n  answer += chr(ord("A") + x)\nprint(answer)'''
    ),
    'abc147_b': (
        '回文では、先頭側と末尾側の対応する文字が一致します。どの組だけ直せばよいか数えてください。',
        'i文字目と末尾からi文字目を比較し、不一致の組ごとに1回変更すれば十分です。片側半分だけ調べます。',
        '''疑似コード:\nans = 0\nfor i = 0 .. len(S)//2 - 1:\n  if S[i] != S[len(S)-1-i]:\n    ans += 1\nprint(ans)'''
    ),
    'abc148_b': (
        '2つの文字列の同じ位置の文字を、S側→T側の順に並べる操作を位置ごとに繰り返します。',
        'i=0..N-1についてS[i]とT[i]を順番に答えへ追加すればよいです。zipを使っても構いません。',
        '''疑似コード:\nanswer = ""\nfor i = 0 .. N-1:\n  answer += S[i]\n  answer += T[i]\nprint(answer)'''
    ),
}
