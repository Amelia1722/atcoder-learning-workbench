"""ABC239–241 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc239_b', 'abc240_b', 'abc241_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc239_b': [
        {'input': '47\n', 'expected': '4\n'},
        {'input': '-24\n', 'expected': '-3\n'},
        {'input': '50\n', 'expected': '5\n'},
        {'input': '-30\n', 'expected': '-3\n'},
        {'input': '987654321987654321\n', 'expected': '98765432198765432\n'},
    ],
    'abc240_b': [
        {'input': '6\n1 4 1 2 2 1\n', 'expected': '3\n'},
        {'input': '1\n1\n', 'expected': '1\n'},
        {'input': '11\n3 1 4 1 5 9 2 6 5 3 5\n', 'expected': '7\n'},
    ],
    'abc241_b': [
        {'input': '3 2\n1 1 3\n3 1\n', 'expected': 'Yes\n'},
        {'input': '1 1\n1000000000\n1\n', 'expected': 'No\n'},
        {'input': '5 2\n1 2 3 4 5\n5 5\n', 'expected': 'No\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _row(line: str, count: int, *, positive: bool = True) -> list[int]:
    parts = line.split(' ')
    pattern = POS if positive else INT
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate239(raw: str) -> int:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or INT.fullmatch(lines[0]) is None:
        raise ValueError('shape/X')
    x = int(lines[0])
    if not -(10**18) <= x <= 10**18:
        raise ValueError('X')
    return x


def _validate240(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 1000:
        raise ValueError('N')
    a = _row(lines[1], n)
    if any(not 1 <= x <= 10**9 for x in a):
        raise ValueError('A range')
    return n, tuple(a)


def _validate241(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 3:
        raise ValueError('shape')
    n, m = _row(lines[0], 2)
    if not 1 <= m <= n <= 1000:
        raise ValueError('N/M')
    a = _row(lines[1], n)
    b = _row(lines[2], m)
    if any(not 1 <= x <= 10**9 for x in a + b):
        raise ValueError('value range')
    return n, m, tuple(a), tuple(b)


def validate(pid: str, raw: str):
    if pid == 'abc239_b':
        return _validate239(raw)
    if pid == 'abc240_b':
        return _validate240(raw)
    if pid == 'abc241_b':
        return _validate241(raw)
    raise ValueError('unknown task')


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc239_b':
        x = value
        expected = x // 10 if x >= 0 else -((-x + 9) // 10)
        return INT.fullmatch(output) is not None and int(output) == expected

    if pid == 'abc240_b':
        _, a = value
        arr = sorted(a)
        kinds = 1 + sum(arr[i] != arr[i - 1] for i in range(1, len(arr)))
        return POS.fullmatch(output) is not None and int(output) == kinds

    _, _, a, b = value
    aa = sorted(a)
    bb = sorted(b)
    i = j = 0
    while i < len(aa) and j < len(bb):
        if aa[i] < bb[j]:
            i += 1
        elif aa[i] == bb[j]:
            i += 1
            j += 1
        else:
            break
    expected = 'Yes' if j == len(bb) else 'No'
    return output == expected


def _case240(vals: list[int]) -> str:
    return f'{len(vals)}\n' + ' '.join(map(str, vals)) + '\n'


def _case241(a: list[int], b: list[int]) -> str:
    return f'{len(a)} {len(b)}\n' + ' '.join(map(str, a)) + '\n' + ' '.join(map(str, b)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc239_b':
        cases = [
            ('zero', '0\n'),
            ('one', '1\n'),
            ('nine', '9\n'),
            ('ten', '10\n'),
            ('minus_one', '-1\n'),
            ('minus_nine', '-9\n'),
            ('minus_ten', '-10\n'),
            ('minus_eleven', '-11\n'),
            ('large_negative_nonmultiple', '-999999999999999999\n'),
            ('constraint_min', '-1000000000000000000\n'),
            ('large_positive_nonmultiple', '999999999999999999\n'),
            ('positive_boundary_neighbor', '999999999999999990\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '1000000000000000000\n')

    elif pid == 'abc240_b':
        cases = [
            ('two_same', _case240([7, 7])),
            ('two_distinct', _case240([7, 8])),
            ('all_same_5', _case240([42] * 5)),
            ('all_distinct_5', _case240([1, 2, 3, 4, 5])),
            ('unsorted_duplicates', _case240([5, 1, 5, 2, 1, 3, 2, 4])),
            ('large_values', _case240([10**9, 1, 10**9, 999999999, 1])),
            ('alternating', _case240([1, 2] * 10)),
            ('ten_kinds_repeated', _case240(list(range(1, 11)) * 3)),
            ('hundred_same', _case240([123456789] * 100)),
            ('hundred_distinct', _case240(list(range(100, 200)))),
            ('many_clustered', _case240([i // 4 + 1 for i in range(200)])),
            ('n500_two_kinds', _case240([1] * 250 + [10**9] * 250)),
            ('n999_all_same', _case240([999999937] * 999)),
            ('n1000_repeated100', _case240([i % 100 + 1 for i in range(1000)])),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', _case240(list(range(1, 1001))))

    else:
        cases = [
            ('single_yes', _case241([1], [1])),
            ('single_no', _case241([1], [2])),
            ('all_same_enough', _case241([7, 7, 7], [7, 7])),
            ('all_same_shortage', _case241([7, 7, 8], [7, 7, 7])),
            ('subset_unsorted', _case241([5, 1, 3, 1, 9], [1, 9, 1])),
            ('missing_middle', _case241([1, 2, 4, 5], [2, 3])),
            ('large_values_yes', _case241([10**9, 1, 10**9], [10**9, 1])),
            ('large_values_no', _case241([10**9, 1, 2], [999999999])),
            ('n10_all_needed', _case241(list(range(1, 11)), list(range(10, 0, -1)))),
            ('n20_duplicates_yes', _case241([1] * 10 + [2] * 10, [2] * 9 + [1] * 10)),
            ('n20_duplicates_no', _case241([1] * 10 + [2] * 10, [2] * 11)),
            ('n100_half', _case241(list(range(1, 101)), list(range(51, 101)))),
            ('n500_all_same_yes', _case241([123] * 500, [123] * 500)),
            ('n999_one_missing', _case241(list(range(1, 1000)), list(range(2, 1000)) + [1000])),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', _case241(list(range(1, 1001)), list(range(1000, 0, -1))))

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
