"""Reviewed ABC029–031 B generators with problem-specific input validation and independent checks.

Evidence: public official task pages inspected on 2026-09-23; HTML originals not authenticated.
"""
from __future__ import annotations

import math
import random
import re

TASKS = ('abc029_b', 'abc030_b', 'abc031_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
NUMERIC = re.compile(r'(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unsupported task or malformed line endings')
    lines = raw[:-1].split('\n')
    if pid == 'abc029_b':
        if (len(lines) != 12 or len(set(lines)) != 12 or
                any(not 1 <= len(s) <= 10 or not LOWER.fullmatch(s) for s in lines)):
            raise ValueError('expected twelve distinct lowercase words of length 1..10')
        return lines
    if pid == 'abc030_b':
        if len(lines) != 1:
            raise ValueError('expected one clock line')
        parts = lines[0].split(' ')
        if len(parts) != 2 or any(not NONNEG.fullmatch(v) for v in parts):
            raise ValueError('invalid clock tokens')
        hour, minute = map(int, parts)
        if hour > 23 or minute > 59:
            raise ValueError('clock time out of range')
        return hour, minute
    if len(lines) < 3:
        raise ValueError('missing weekly records')
    limits = lines[0].split(' ')
    if len(limits) != 2 or any(not POS.fullmatch(s) for s in limits):
        raise ValueError('invalid workout bounds')
    lo, hi = map(int, limits)
    if not (1 <= lo <= hi <= 10000) or not POS.fullmatch(lines[1]):
        raise ValueError('invalid workout bounds or count')
    n = int(lines[1])
    if not 1 <= n <= 50 or len(lines) != n + 2:
        raise ValueError('invalid weekly record count')
    if any(not NONNEG.fullmatch(s) for s in lines[2:]):
        raise ValueError('invalid weekly record tokens')
    times = [int(s) for s in lines[2:]]
    if any(v > 10000 for v in times):
        raise ValueError('weekly exercise time exceeds limit')
    return lo, hi, times


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        data = validate(pid, raw)
    except (TypeError, ValueError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc029_b':
        # Explicit once-per-word boolean; never count occurrences of r within a word.
        count = 0
        for word in data:
            if any(letter == 'r' for letter in word):
                count += 1
        return output == str(count)
    if pid == 'abc030_b':
        if len(output) > 80 or not NUMERIC.fullmatch(output):
            return False
        try:
            actual = float(output)
        except (ValueError, OverflowError):
            return False
        if not math.isfinite(actual):
            return False
        hour, minute = data
        # All angle arithmetic before final division is exact integer half-degrees.
        twice_difference = abs(60 * (hour % 12) - 11 * minute)
        expected = min(twice_difference, 720 - twice_difference) / 2
        return math.isclose(actual, expected, rel_tol=1e-4, abs_tol=1e-4)
    lo, hi, times = data
    if len(output) > 350 or not re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:\n-?(?:0|[1-9][0-9]*))*', output):
        return False
    lines = output.split('\n')
    if len(lines) != len(times):
        return False
    for value, answer in zip(times, lines):
        if value > hi:
            if answer != '-1':
                return False
        else:
            # Binary-search the minimum nonnegative extra exercise time.
            left, right = -1, 10001
            while right - left > 1:
                mid = (left + right) // 2
                if value + mid >= lo:
                    right = mid
                else:
                    left = mid
            if answer != str(right):
                return False
    return True


def generate(pid: str, seed: int = 57) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unsupported task')
    rng = random.Random(f'abc-v57:{pid}:{seed}')
    cases: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            cases.append({'category': category, 'input': raw})

    if pid == 'abc029_b':
        def make_words(words): return '\n'.join(words) + '\n'
        bases = [
            [chr(c) for c in range(97, 109)],
            [chr(c) for c in range(111, 123)],
            ['r' * k for k in range(1, 11)] + ['r' + 's' * 9, 's' + 'r' * 9],
            ['a' * k for k in range(1, 11)] + ['b', 'c'],
            [f'{i:02d}'.replace('0', 'a').replace('1', 'b').replace('2', 'c')
             .replace('3','d').replace('4','e').replace('5','f').replace('6','g')
             .replace('7','h').replace('8','i').replace('9','j') for i in range(12)],
            ['r' + chr(97 + i) for i in range(12)],
            [chr(97 + i) + 'r' for i in range(12)],
            ['x' * (i + 1) for i in range(10)] + ['y', 'z'],
            [chr(97 + i) * 10 for i in range(12)],
            [chr(97 + i) for i in range(12)],
        ]
        # Include zero, one, and many matching words; duplicate words are forbidden.
        for words in bases:
            add('boundary' if all(len(w) == 1 for w in words) else 'normal', make_words(words))
        while len(cases) < 17:
            words = set()
            while len(words) < 12:
                words.add(''.join(rng.choices('abcdefghijklmnopqrrstuvwxyz', k=rng.randint(1, 10))))
            add('random', make_words(sorted(words)))
        add('constraint_max', make_words(['r' + chr(97+i)*9 for i in range(12)]))
    elif pid == 'abc030_b':
        for n, m in [(0,0),(0,59),(22,59),(12,0),(6,0),(3,17),(15,0),
                     (11,59),(12,59),(23,0),(0,1),(6,30),(18,30),(3,0)]:
            add('boundary' if m in (0,59) else 'normal',f'{n} {m}\n')
        while len(cases) < 17:
            add('random',f'{rng.randrange(24)} {rng.randrange(60)}\n')
        add('constraint_max','23 59\n')
    else:
        def fmt(lo, hi, times): return f'{lo} {hi}\n{len(times)}\n' + ''.join(f'{v}\n' for v in times)
        presets = [(1,1,[0]),(1,1,[1]),(1,1,[2]),(1,10000,[0]),
                   (10000,10000,[0]),(10000,10000,[10000]),
                   (10000,10000,[9999]),(1,10000,[10000]),
                   (300,400,[240,350,480]),(50,80,[10000,50,81,80,0]),
                   (1,10000,[0]*50),(1,1,[10000]*50),
                   (5000,5000,[0,4999,5000,5001,10000]),
                   (100,10000,[0,1,99,100,9999,10000])]
        for lo, hi, values in presets:
            add('boundary' if len(values) == 1 else 'normal',fmt(lo,hi,values))
        while len(cases) < 17:
            lo = rng.randint(1,10000); hi = rng.randint(lo,10000)
            values = [rng.randint(0,10000) for _ in range(rng.randint(1,50))]
            add('random',fmt(lo,hi,values))
        add('constraint_max',fmt(10000,10000,[0,10000]*25))
    if len(cases) != 18 or cases[-1]['category'] != 'constraint_max':
        raise ValueError(f'incomplete generation for {pid}: {len(cases)}')
    return cases
