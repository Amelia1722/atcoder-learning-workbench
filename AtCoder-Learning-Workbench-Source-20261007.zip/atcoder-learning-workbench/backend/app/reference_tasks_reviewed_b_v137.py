"""ABC269–271 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc269_b', 'abc270_b', 'abc271_b')
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
POS = re.compile(r'(?:[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc269_b': [
        {
            'input': '..........\n..........\n..........\n..........\n...######.\n...######.\n...######.\n...######.\n..........\n..........\n',
            'expected': '5 8\n4 9\n',
        },
        {
            'input': '..........\n..#.......\n..........\n..........\n..........\n..........\n..........\n..........\n..........\n..........\n',
            'expected': '2 2\n3 3\n',
        },
        {
            'input': '##########\n##########\n##########\n##########\n##########\n##########\n##########\n##########\n##########\n##########\n',
            'expected': '1 10\n1 10\n',
        },
    ],
    'abc270_b': [
        {'input': '10 -10 1\n', 'expected': '10\n'},
        {'input': '20 10 -10\n', 'expected': '40\n'},
        {'input': '100 1 1000\n', 'expected': '-1\n'},
    ],
    'abc271_b': [
        {
            'input': '2 2\n3 1 4 7\n2 5 9\n1 3\n2 1\n',
            'expected': '7\n5\n',
        },
        {
            'input': '3 4\n4 128 741 239 901\n2 1 1\n3 314 159 26535\n1 1\n2 2\n3 3\n1 4\n',
            'expected': '128\n1\n26535\n901\n',
        },
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate269(raw: str) -> tuple[list[str], tuple[int, int, int, int]]:
    lines = _canonical_lines(raw)
    if len(lines) != 10 or any(len(row) != 10 or any(ch not in '.#' for ch in row) for row in lines):
        raise ValueError('grid')
    pts = [(i, j) for i, row in enumerate(lines) for j, ch in enumerate(row) if ch == '#']
    if not pts:
        raise ValueError('empty')
    a = min(i for i, _ in pts)
    b = max(i for i, _ in pts)
    c = min(j for _, j in pts)
    d = max(j for _, j in pts)
    for i in range(10):
        for j in range(10):
            expected = a <= i <= b and c <= j <= d
            if (lines[i][j] == '#') != expected:
                raise ValueError('not rectangle')
    return lines, (a + 1, b + 1, c + 1, d + 1)


def _validate270(raw: str) -> tuple[int, int, int]:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    vals = _ints_line(lines[0])
    if len(vals) != 3:
        raise ValueError('shape')
    x, y, z = vals
    if any(v == 0 or not -1000 <= v <= 1000 for v in vals) or len(set(vals)) != 3:
        raise ValueError('constraints')
    return x, y, z


def _validate271(raw: str) -> tuple[list[list[int]], list[tuple[int, int]]]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 2:
        raise ValueError('header')
    n, q = head
    if not (1 <= n <= 200_000 and 1 <= q <= 200_000):
        raise ValueError('NQ')
    if len(lines) != 1 + n + q:
        raise ValueError('line count')
    seqs: list[list[int]] = []
    total = 0
    for i in range(n):
        vals = _ints_line(lines[1 + i])
        if not vals:
            raise ValueError('sequence')
        li = vals[0]
        arr = vals[1:]
        if li < 1 or len(arr) != li or any(not 1 <= x <= 10**9 for x in arr):
            raise ValueError('sequence')
        total += li
        if total > 200_000:
            raise ValueError('sum L')
        seqs.append(arr)
    queries: list[tuple[int, int]] = []
    for k in range(q):
        vals = _ints_line(lines[1 + n + k])
        if len(vals) != 2:
            raise ValueError('query')
        s, t = vals
        if not (1 <= s <= n and 1 <= t <= len(seqs[s - 1])):
            raise ValueError('query')
        queries.append((s, t))
    return seqs, queries


def validate(pid: str, raw: str):
    if pid == 'abc269_b':
        return _validate269(raw)
    if pid == 'abc270_b':
        return _validate270(raw)
    if pid == 'abc271_b':
        return _validate271(raw)
    raise ValueError('unknown task')


def _oracle269(lines: list[str]) -> tuple[int, int, int, int]:
    rows = [i + 1 for i, row in enumerate(lines) if '#' in row]
    cols = [j + 1 for j in range(10) if any(lines[i][j] == '#' for i in range(10))]
    return min(rows), max(rows), min(cols), max(cols)


def _between_origin_and_goal(x: int, y: int) -> bool:
    return (0 < y < x) or (x < y < 0)


def _reachable_without_crossing_wall(target: int, y: int) -> bool:
    return not ((0 < y < target) or (target < y < 0))


def _oracle270(x: int, y: int, z: int) -> int:
    if not _between_origin_and_goal(x, y):
        return abs(x)
    if not _reachable_without_crossing_wall(z, y):
        return -1
    return abs(z) + abs(x - z)


def _oracle271(seqs: list[list[int]], queries: list[tuple[int, int]]) -> list[int]:
    flat: list[int] = []
    starts: list[int] = []
    for arr in seqs:
        starts.append(len(flat))
        flat.extend(arr)
    return [flat[starts[s - 1] + t - 1] for s, t in queries]


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc269_b':
        m = re.fullmatch(r'(?:[1-9]|10) (?:[1-9]|10)\n(?:[1-9]|10) (?:[1-9]|10)', output, re.ASCII)
        if m is None:
            return False
        got = tuple(map(int, output.replace('\n', ' ').split()))
        return got == _oracle269(value[0])
    if pid == 'abc270_b':
        if INT.fullmatch(output) is None:
            return False
        return int(output) == _oracle270(*value)
    seqs, queries = value
    lines = output.split('\n')
    if len(lines) != len(queries) or any(POS.fullmatch(x) is None for x in lines):
        return False
    return [int(x) for x in lines] == _oracle271(seqs, queries)


def _grid(a: int, b: int, c: int, d: int) -> str:
    rows = []
    for i in range(1, 11):
        rows.append(''.join('#' if a <= i <= b and c <= j <= d else '.' for j in range(1, 11)))
    return '\n'.join(rows) + '\n'


def _seq_input(seqs: list[list[int]], queries: list[tuple[int, int]]) -> str:
    lines = [f'{len(seqs)} {len(queries)}']
    lines.extend(f"{len(arr)} {' '.join(map(str, arr))}" for arr in seqs)
    lines.extend(f'{s} {t}' for s, t in queries)
    return '\n'.join(lines) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc269_b':
        for category, box in [
            ('top_left_single', (1, 1, 1, 1)),
            ('top_row', (1, 1, 2, 9)),
            ('bottom_row', (10, 10, 1, 10)),
            ('left_col', (2, 9, 1, 1)),
            ('right_col', (1, 10, 10, 10)),
            ('middle_square', (4, 7, 4, 7)),
            ('full_height_mid_cols', (1, 10, 5, 6)),
            ('full_width_mid_rows', (3, 8, 1, 10)),
            ('vertical_line', (2, 9, 6, 6)),
            ('horizontal_line', (6, 6, 2, 9)),
            ('upper_corner_block', (1, 3, 1, 3)),
            ('lower_corner_block', (8, 10, 8, 10)),
            ('thin_middle', (2, 2, 4, 8)),
            ('near_full', (2, 10, 1, 9)),
        ]:
            add(category, _grid(*box))
        add('constraint_max', _grid(10, 10, 10, 10))
    elif pid == 'abc270_b':
        custom = [
            ('direct_positive', '5 10 -3\n'),
            ('direct_negative', '-5 10 3\n'),
            ('direct_negative_same_side_far_wall', '-10 -20 1\n'),
            ('hammer_before_wall_positive', '20 10 5\n'),
            ('hammer_opposite_positive', '20 10 -5\n'),
            ('impossible_positive', '20 10 15\n'),
            ('impossible_negative', '-20 -10 -15\n'),
            ('hammer_opposite_negative', '-20 -10 5\n'),
            ('unit_goal', '1 -1 2\n'),
            ('positive_bounds_detour', '1000 999 -1000\n'),
            ('negative_bounds_detour', '-1000 -999 1000\n'),
            ('positive_near_wall_hammer', '1000 500 499\n'),
            ('negative_near_wall_hammer', '-1000 -500 -499\n'),
            ('positive_goal_wall_opposite', '1000 -999 -998\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', '-1000 999 1000\n')
    else:
        custom: list[tuple[str, str]] = [
            ('single_single', _seq_input([[42]], [(1, 1)])),
            ('one_sequence_edges', _seq_input([[10, 20, 30, 40]], [(1, 1), (1, 4)])),
            ('two_sequences', _seq_input([[1, 2], [9, 8, 7]], [(2, 3), (1, 2), (2, 1)])),
            ('three_singletons', _seq_input([[5], [6], [7]], [(1, 1), (3, 1), (2, 1)])),
            ('max_values', _seq_input([[10**9, 1, 10**9], [999999999]], [(1, 1), (1, 3), (2, 1)])),
            ('repeated_query', _seq_input([[3, 1, 4]], [(1, 2), (1, 2), (1, 2)])),
            ('first_last', _seq_input([[8, 6, 7, 5, 3, 0 + 1, 9]], [(1, 1), (1, 7)])),
            ('many_singletons', _seq_input([[i] for i in range(1, 11)], [(10, 1), (1, 1), (5, 1)])),
            ('different_lengths', _seq_input([[1], [2, 3], [4, 5, 6], [7, 8, 9, 10]], [(4, 4), (3, 2), (2, 1)])),
            ('one_len10_q10', _seq_input([list(range(1, 11))], [(1, i) for i in range(1, 11)])),
            ('ten_len1_q10', _seq_input([[100 + i] for i in range(10)], [(i, 1) for i in range(10, 0, -1)])),
            ('long_and_short', _seq_input([list(range(1, 101)), [10**9]], [(1, 100), (2, 1), (1, 50)])),
            ('five_mixed', _seq_input([[11, 12], [21], [31, 32, 33], [41, 42, 43, 44], [51]], [(4, 2), (3, 3), (1, 1), (5, 1)])),
            ('pattern_values', _seq_input([[1, 10**9, 1, 10**9], [123456789, 987654321]], [(1, 2), (1, 4), (2, 2)])),
            ('sum_lengths_twenty', _seq_input([list(range(1, 6)), list(range(6, 16)), list(range(16, 21))], [(1, 5), (2, 10), (3, 5)])),
        ]
        for category, raw in custom:
            add(category, raw)
        vals = list(range(1, 200_001))
        queries = [(1, i) for i in range(1, 200_001)]
        add('constraint_max', _seq_input([vals], queries))

    if len(out) != 18:
        raise AssertionError((pid, len(out), [x['category'] for x in out]))
    return out
