"""ABC209–211 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc209_b', 'abc210_b', 'abc211_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
TOKENS_211 = {'H', '2B', '3B', 'HR'}
PUBLISHED_SAMPLES = {
    'abc209_b': [
        {'input': '2 3\n1 3\n', 'expected': 'Yes\n'},
        {'input': '4 10\n3 3 4 4\n', 'expected': 'No\n'},
        {'input': '8 30\n3 1 4 1 5 9 2 6\n', 'expected': 'Yes\n'},
    ],
    'abc210_b': [
        {'input': '5\n00101\n', 'expected': 'Takahashi\n'},
        {'input': '3\n010\n', 'expected': 'Aoki\n'},
    ],
    'abc211_b': [
        {'input': '3B\nHR\n2B\nH\n', 'expected': 'Yes\n'},
        {'input': '2B\n3B\nHR\n3B\n', 'expected': 'No\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    return raw[:-1].split('\n')


def _validate209(raw: str) -> tuple[int, int, tuple[int, ...]]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    first = lines[0].split(' ')
    second = lines[1].split(' ')
    if len(first) != 2 or any(POS.fullmatch(x) is None for x in first):
        raise ValueError('first row')
    n, x = map(int, first)
    if not (1 <= n <= 100 and 1 <= x <= 10000):
        raise ValueError('range')
    if len(second) != n or any(POS.fullmatch(v) is None for v in second):
        raise ValueError('prices')
    a = tuple(map(int, second))
    if any(not 1 <= v <= 100 for v in a):
        raise ValueError('price range')
    return n, x, a


def _validate210(raw: str) -> tuple[int, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape')
    n = int(lines[0])
    s = lines[1]
    if not 1 <= n <= 100000 or len(s) != n or any(c not in '01' for c in s) or '1' not in s:
        raise ValueError('range/content')
    return n, s


def _validate211(raw: str) -> tuple[str, str, str, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 4 or any(s not in TOKENS_211 for s in lines):
        raise ValueError('shape/token')
    return tuple(lines)  # type: ignore[return-value]


def validate(pid: str, raw: str):
    if pid == 'abc209_b':
        return _validate209(raw)
    if pid == 'abc210_b':
        return _validate210(raw)
    if pid == 'abc211_b':
        return _validate211(raw)
    raise ValueError('unknown task')


def _ans209(v: tuple[int, int, tuple[int, ...]]) -> str:
    n, x, a = v
    # Independent from reference loop: every second item gets exactly 1 yen discount.
    required = sum(a) - n // 2
    return 'Yes' if required <= x else 'No'


def _ans210(v: tuple[int, str]) -> str:
    _, s = v
    first_bad_1based = len(s) - len(s.lstrip('0')) + 1
    return 'Takahashi' if first_bad_1based % 2 == 1 else 'Aoki'


def _ans211(v: tuple[str, str, str, str]) -> str:
    return 'Yes' if set(v) == TOKENS_211 else 'No'


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or '\n' in output or output != output.strip():
        return False
    if pid == 'abc209_b':
        return output == _ans209(value)
    if pid == 'abc210_b':
        return output == _ans210(value)
    if pid == 'abc211_b':
        return output == _ans211(value)
    return False


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    if pid == 'abc209_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        cases = [
            ('min_exact', '1 1\n1\n'),
            ('single_no', '1 1\n2\n'),
            ('even_exact', '2 2\n1 2\n'),
            ('even_one_short', '2 1\n1 2\n'),
            ('odd_exact', '3 5\n1 2 3\n'),
            ('odd_one_short', '3 4\n1 2 3\n'),
            ('all_ones', '6 3\n1 1 1 1 1 1\n'),
            ('discount_matters', '4 6\n2 2 2 2\n'),
            ('no_despite_discount', '4 5\n2 2 2 2\n'),
            ('xmax_small_prices', '5 10000\n1 2 3 4 5\n'),
            ('n100_exact', '100 50\n1 ' + ' '.join(['1'] * 99) + '\n'),
            ('n100_one_short', '100 49\n1 ' + ' '.join(['1'] * 99) + '\n'),
            ('high_prices_no', '100 9949\n' + ' '.join(['100'] * 100) + '\n'),
            ('mixed_boundary', '7 24\n10 1 10 1 10 1 1\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '100 10000\n' + ' '.join(['100'] * 100) + '\n')
    elif pid == 'abc210_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        cases = [
            ('n1', '1\n1\n'),
            ('first_bad', '4\n1000\n'),
            ('second_bad', '4\n0100\n'),
            ('third_bad', '4\n0010\n'),
            ('fourth_bad', '4\n0001\n'),
            ('all_bad', '6\n111111\n'),
            ('first_of_many', '8\n10101010\n'),
            ('second_of_many', '8\n01111111\n'),
            ('late_odd', '9\n000000001\n'),
            ('late_even', '10\n0000000001\n'),
            ('middle_odd', '11\n00001000000\n'),
            ('middle_even', '12\n000001000000\n'),
            ('large_first', '99999\n1' + '0' * 99998 + '\n'),
            ('large_second', '99999\n01' + '0' * 99997 + '\n'),
            ('large_odd_last', '99999\n' + '0' * 99998 + '1\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '100000\n' + '0' * 99999 + '1\n')
    else:
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        cases = [
            ('canonical_yes', 'H\n2B\n3B\nHR\n'),
            ('reverse_yes', 'HR\n3B\n2B\nH\n'),
            ('rotated_yes', '2B\n3B\nHR\nH\n'),
            ('dup_h', 'H\nH\n3B\nHR\n'),
            ('dup_2b', '2B\n2B\nH\nHR\n'),
            ('dup_3b', '3B\n3B\nH\n2B\n'),
            ('dup_hr', 'HR\nHR\nH\n2B\n'),
            ('all_h', 'H\nH\nH\nH\n'),
            ('all_2b', '2B\n2B\n2B\n2B\n'),
            ('all_3b', '3B\n3B\n3B\n3B\n'),
            ('all_hr', 'HR\nHR\nHR\nHR\n'),
            ('two_pairs', 'H\nH\n2B\n2B\n'),
            ('three_same', 'HR\nHR\nHR\n3B\n'),
            ('missing_hr', 'H\n2B\n3B\n3B\n'),
            ('missing_2b', 'H\n3B\nHR\nH\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '3B\n2B\nH\nHR\n')
    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
