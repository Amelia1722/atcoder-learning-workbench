"""Evidence-bound backfill for ABC001 B / ABC002 A-B; public statements checked."""
HINTS_BACKFILL_V73 = {
    'abc001_2': (
        '距離によって変換規則が変わります。まず、与えられたメートル値がどの範囲に属するかを順番に判定してください。',
        '問題文の5つの範囲に沿って場合分けし、それぞれの式でVVを計算します。最後は必ず2桁で出力します。',
        '''疑似コード:\nif m < 100: vv = 0\nelif m <= 5000: vv = m // 100\nelif m <= 30000: vv = m // 1000 + 50\nelif m <= 70000: vv = (m // 1000 - 30) // 5 + 80\nelse: vv = 89\nprint(vvを2桁ゼロ埋め)''',
    ),
    'abc002_1': (
        '2つの金額のうち、条件を満たすのは大きい方です。大小関係だけに注目してください。',
        'XとYを比較して大きい方を出力します。Pythonならmaxを使えます。',
        '''疑似コード:\nX,Y = read_two_integers()\nprint(max(X,Y))''',
    ),
    'abc002_2': (
        '文字列を左から見て、残す文字と捨てる文字を分けてください。',
        '母音a,i,u,e,oだけを除外し、それ以外の文字を順番を保ったまま連結します。',
        '''疑似コード:\nans=[]\nfor c in W:\n  if c not in {'a','i','u','e','o'}: ans.append(c)\nprint(join(ans))''',
    ),
}
