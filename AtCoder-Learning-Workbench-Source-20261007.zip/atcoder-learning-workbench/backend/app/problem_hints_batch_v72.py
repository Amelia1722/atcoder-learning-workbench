"""Hints based on the public official statements of ABC074–076 B."""
HINTS_V72 = {
    'abc074_b': (
        '球はそれぞれ独立に回収できます。1個の球について、左のロボットと右のロボットのどちらを使う方が短いか考えてください。',
        '位置xの球を0側から回収すると往復2x、K側からなら往復2(K-x)です。各球で小さい方を選び、その合計を求めます。',
        '''疑似コード:\nanswer=0\nfor x in positions:\n  answer += 2 * min(x, K-x)\nprint(answer)''',
    ),
    'abc075_b': (
        '数字へ置き換えるのは`.`のマスだけです。そのマスの周囲で調べる範囲は最大8マスしかありません。',
        '各マスを走査し、`#`ならそのまま出力、`.`なら周囲8方向の座標が盤面内か確認して`#`の個数を数えます。',
        '''疑似コード:\nfor each cell (r,c):\n  if grid[r][c] == '#': output '#'\n  else:\n    count=0\n    for dr,dc in 8 directions:\n      if inside(r+dr,c+dc) and grid[r+dr][c+dc]=='#': count+=1\n    output count''',
    ),
    'abc076_b': (
        '今の値が決まっているとき、次の1回で選べる値は2つだけです。将来を考える前に、その2つの大小を比べてみてください。',
        'どちらの操作も現在値に対して単調増加なので、各回で小さい`2*x`と`x+K`を選べば、その後も常に小さい状態を保てます。',
        '''疑似コード:\nx=1\nrepeat N times:\n  x = min(2*x, x+K)\nprint(x)''',
    ),
}
