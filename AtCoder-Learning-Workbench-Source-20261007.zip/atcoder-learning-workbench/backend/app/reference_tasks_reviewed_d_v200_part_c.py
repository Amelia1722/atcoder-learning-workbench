"""Private ABC401..406 D; primary domains, independent checks, no shared writes."""
from __future__ import annotations
from typing import cast
from collections import Counter,deque
from bisect import bisect_left
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(401,407));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES={'abc405_d':'semantic'};CHECKER_IDS={'abc405_d':'abc405_d'};Case=dict[str,str];Data=tuple[object,...]
INF=10**9;NEG=-INF

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def maximum_independent(s:str)->int:
 zero,one=0,NEG
 for c in s:zero,one=max(zero,one) if c!='o' else NEG,zero+1 if c!='.' and zero>=0 else NEG
 return max(zero,one)
def exit_distances_heap(grid:tuple[str,...])->list[int]:
 h=len(grid);w=len(grid[0]);distance=[-1]*(h*w);heap=[]
 for r,row in enumerate(grid):
  for c,ch in enumerate(row):
   if ch=='E':distance[r*w+c]=0;heapq.heappush(heap,(0,r*w+c))
 while heap:
  d,p=heapq.heappop(heap)
  if distance[p]!=d:continue
  r,c=divmod(p,w)
  for nr,nc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
   if 0<=nr<h and 0<=nc<w and grid[nr][nc]!='#':
    q=nr*w+nc
    if distance[q]<0 or d+1<distance[q]:distance[q]=d+1;heapq.heappush(heap,(d+1,q))
 return distance

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc401_d':
  n,k=ints(r[0],2);require(1<=n<=200000 and len(r)==2 and re.fullmatch('[.o?]{'+str(n)+'}',r[1]) is not None,'string');s=r[1];require(s.count('o')<=k<=maximum_independent(s),'nonempty solution set');return k,s
 if pid=='abc402_d':
  n,m=ints(r[0],2);require(2<=n<=1000000 and 1<=m<=300000 and len(r)==m+1,'shape');chords=tuple(ints(s,2) for s in r[1:]);require(len(set(chords))==m and all(1<=a<b<=n for a,b in chords),'distinct ordered endpoints');return n,chords
 if pid=='abc403_d':
  n,d=ints(r[0],2);require(1<=n<=200000 and 0<=d<=1000000 and len(r)==2,'shape');a=ints(r[1],n);require(all(0<=v<=1000000 for v in a),'values');return d,a
 if pid=='abc404_d':
  n,m=ints(r[0],2);require(1<=n<=10 and 1<=m<=100 and len(r)==m+2,'shape');prices=ints(r[1],n);require(all(0<=c<=10**9 for c in prices),'prices');animals=[]
  for row in r[2:]:
   values=ints(row);k=values[0];zoos=values[1:];require(1<=k<=n and len(zoos)==k and len(set(zoos))==k and all(1<=z<=n for z in zoos),'animal zoos');animals.append(zoos)
  return prices,tuple(animals)
 if pid=='abc405_d':
  h,w=ints(r[0],2);require(2<=h<=1000 and 2<=w<=1000 and len(r)==h+1,'shape');grid=tuple(r[1:]);require(all(re.fullmatch('[.#E]{'+str(w)+'}',row) is not None for row in grid),'grid');distance=exit_distances_heap(grid);require(all(ch!='.' or distance[i*w+j]>=0 for i,row in enumerate(grid) for j,ch in enumerate(row)),'exit reachable for every passage');return (grid,)
 h,w,n=ints(r[0],3);require(1<=h<=200000 and 1<=w<=200000 and 1<=n<=200000 and len(r)>=n+3,'shape');points=tuple(ints(s,2) for s in r[1:n+1]);require(len(set(points))==n and all(1<=x<=h and 1<=y<=w for x,y in points),'garbage');q=ints(r[n+1],1)[0];require(1<=q<=200000 and len(r)==n+q+2,'queries');queries=tuple(ints(s,2) for s in r[n+2:]);require(all((kind==1 and 1<=p<=h) or (kind==2 and 1<=p<=w) for kind,p in queries),'query kind/range');return points,queries

def filling_extrema(k:int,s:str)->str:
 n=len(s);lo0=[INF]*(n+1);lo1=lo0.copy();hi0=[NEG]*(n+1);hi1=hi0.copy();lo0[0]=hi0[0]=0
 for i,c in enumerate(s):
  if c!='o':lo0[i+1]=min(lo0[i],lo1[i]);hi0[i+1]=max(hi0[i],hi1[i])
  if c!='.' and lo0[i]<INF:lo1[i+1]=lo0[i]+1;hi1[i+1]=hi0[i]+1
 ro0=[INF]*(n+1);ro1=ro0.copy();rh0=[NEG]*(n+1);rh1=rh0.copy();ro0[n]=rh0[n]=0
 for i in range(n-1,-1,-1):
  if s[i]!='o':ro0[i]=min(ro0[i+1],ro1[i+1]);rh0[i]=max(rh0[i+1],rh1[i+1])
  if s[i]!='.' and ro0[i+1]<INF:ro1[i]=ro0[i+1]+1;rh1[i]=rh0[i+1]+1
 result=[]
 for i,c in enumerate(s):
  if c!='?':result.append(c);continue
  zero=min(lo0[i],lo1[i])+min(ro0[i+1],ro1[i+1])<=k<=max(hi0[i],hi1[i])+max(rh0[i+1],rh1[i+1]);one=lo0[i]+1+ro0[i+1]<=k<=hi0[i]+1+rh0[i+1]
  require(zero or one,'guaranteed existence');result.append('?' if zero and one else '.' if zero else 'o')
 return ''.join(result)

def line_intersections_rank(n:int,chords:tuple[tuple[int,...],...])->int:
 keys=[(a+b)%n for a,b in chords];classes=sorted(set(keys));bit=[0]*(len(classes)+1);answer=0
 def prefix(i:int)->int:
  total=0
  while i:total+=bit[i];i-=i&-i
  return total
 for seen,key in enumerate(keys):
  rank=bisect_left(classes,key);answer+=prefix(rank)+seen-prefix(rank+1);j=rank+1
  while j<len(bit):bit[j]+=1;j+=j&-j
 return answer

def difference_matching_dual(d:int,a:tuple[int,...])->int:
 frequency=Counter(a)
 if d==0:return len(a)-len(frequency)
 previous=-10**30;capacity=0;flow=0
 for value in sorted(frequency,key=lambda v:(v%d,v)):
  current=frequency[value]
  if value-previous==d:
   amount=min(capacity,current);flow+=amount;current-=amount
  capacity=current;previous=value
 return flow

def zoo_deficiency_dijkstra(prices:tuple[int,...],animals:tuple[tuple[int,...],...])->int:
 n=len(prices);m=len(animals);masks=[0]*n
 for j,zoos in enumerate(animals):
  for z in zoos:masks[z-1]|=1<<j
 target=(1<<m)-1;powers=[3**i for i in range(n)];heap=[(0,0,0,0)];distance={0:0}
 while heap:
  cost,state,one,two=heapq.heappop(heap)
  if distance[state]!=cost:continue
  if two==target:return cost
  missing=target^two;animal=(missing&-missing).bit_length()-1
  for z in animals[animal]:
   i=z-1
   if state//powers[i]%3==2:continue
   nxt=state+powers[i];newcost=cost+prices[i]
   if newcost<distance.get(nxt,10**30):distance[nxt]=newcost;heapq.heappush(heap,(newcost,nxt,one|masks[i],two|(one&masks[i])))
 raise AssertionError('each animal has at least one zoo')

def nearest_arrows_heap(grid:tuple[str,...])->str:
 h=len(grid);w=len(grid[0]);distance=exit_distances_heap(grid);answer=[list(row) for row in grid]
 for r,row in enumerate(grid):
  for c,ch in enumerate(row):
   if ch!='.':continue
   for dr,dc,arrow in ((-1,0,'^'),(0,-1,'<'),(1,0,'v'),(0,1,'>')):
    nr,nc=r+dr,c+dc
    if 0<=nr<h and 0<=nc<w and distance[nr*w+nc]==distance[r*w+c]-1:answer[r][c]=arrow;break
 return '\n'.join(''.join(row) for row in answer)+'\n'
def nearest_arrows_valid(grid:tuple[str,...],actual:str)->bool:
 if '\r' in actual:return False
 rows=actual.removesuffix('\n').split('\n');h=len(grid);w=len(grid[0])
 if len(rows)!=h or any(len(row)!=w for row in rows):return False
 distance=exit_distances_heap(grid);direction={'^':(-1,0),'v':(1,0),'<':(0,-1),'>':(0,1)}
 for r,row in enumerate(grid):
  for c,ch in enumerate(row):
   if ch!='.':
    if rows[r][c]!=ch:return False
   else:
    arrow=rows[r][c]
    if arrow not in direction:return False
    dr,dc=direction[arrow];nr,nc=r+dr,c+dc
    if not(0<=nr<h and 0<=nc<w) or grid[nr][nc]=='#' or distance[r*w+c]<1 or distance[nr*w+nc]!=distance[r*w+c]-1:return False
 return True

def garbage_first_events(points:tuple[tuple[int,...],...],queries:tuple[tuple[int,...],...])->list[int]:
 firstrow:dict[int,int]={};firstcol:dict[int,int]={};q=len(queries);answer=[0]*q
 for i,(kind,p) in enumerate(queries):
  group=firstrow if kind==1 else firstcol;group.setdefault(p,i)
 for x,y in points:
  removal=min(firstrow.get(x,q),firstcol.get(y,q))
  if removal<q:answer[removal]+=1
 return answer

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc401_d':answer=filling_extrema(cast(int,d[0]),cast(str,d[1]))
 elif pid=='abc402_d':answer=str(line_intersections_rank(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))
 elif pid=='abc403_d':answer=str(difference_matching_dual(cast(int,d[0]),cast(tuple[int,...],d[1])))
 elif pid=='abc404_d':answer=str(zoo_deficiency_dijkstra(cast(tuple[int,...],d[0]),cast(tuple[tuple[int,...],...],d[1])))
 elif pid=='abc405_d':return nearest_arrows_heap(cast(tuple[str,...],d[0]))
 else:return ''.join(str(v)+'\n' for v in garbage_first_events(cast(tuple[tuple[int,...],...],d[0]),cast(tuple[tuple[int,...],...],d[1])))
 return answer+'\n'
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc405_d':return mode in (None,'semantic') and nearest_arrows_valid(cast(tuple[str,...],d[0]),actual)
  return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,KeyError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc401_d':'''n,k=map(int,input().split());s=list(input());need=k-s.count('o')
for i in range(n):
 if s[i]=='?' and ((i and s[i-1]=='o') or (i+1<n and s[i+1]=='o')):s[i]='.'
runs=[];i=0
while i<n:
 if s[i]!='?':i+=1;continue
 j=i
 while j<n and s[j]=='?':j+=1
 runs.append((i,j));i=j
capacity=sum((b-a+1)//2 for a,b in runs)
if need==0:s=['.' if c=='?' else c for c in s]
elif need==capacity:
 for a,b in runs:
  if (b-a)%2:
   for i in range(a,b):s[i]='o' if (i-a)%2==0 else '.'
print(''.join(s))
''',
'abc402_d':'''from collections import Counter
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);classes=Counter((next(it)+next(it))%n for _ in range(m));print(m*(m-1)//2-sum(c*(c-1)//2 for c in classes.values()))
''',
'abc403_d':'''from collections import Counter
n,d=map(int,input().split());a=list(map(int,input().split()));freq=Counter(a)
if d==0:print(n-len(freq))
else:
 groups={}
 for value,c in freq.items():groups.setdefault(value%d,[]).append((value,c))
 retained=0
 for group in groups.values():
  take=skip=0;previous=-10**30
  for value,c in sorted(group):
   if value-previous!=d:retained+=max(take,skip);take=skip=0
   take,skip=skip+c,max(take,skip);previous=value
  retained+=max(take,skip)
 print(n-retained)
''',
'abc404_d':'''from itertools import product
n,m=map(int,input().split());cost=list(map(int,input().split()));animals=[]
for _ in range(m):row=list(map(int,input().split()));animals.append([z-1 for z in row[1:]])
best=2*sum(cost)
for visits in product(range(3),repeat=n):
 price=sum(v*c for v,c in zip(visits,cost))
 if price>=best:continue
 if all(sum(visits[z] for z in zoos)>=2 for zoos in animals):best=price
 if best==0:break
print(best)
''',
'abc405_d':'''from collections import deque
h,w=map(int,input().split());grid=[list(input()) for _ in range(h)];q=deque((r,c) for r in range(h) for c in range(w) if grid[r][c]=='E')
while q:
 r,c=q.popleft()
 for dr,dc,arrow in ((-1,0,'v'),(1,0,'^'),(0,-1,'>'),(0,1,'<')):
  nr,nc=r+dr,c+dc
  if 0<=nr<h and 0<=nc<w and grid[nr][nc]=='.':grid[nr][nc]=arrow;q.append((nr,nc))
print('\\n'.join(''.join(row) for row in grid))
''',
'abc406_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));h=next(it);w=next(it);n=next(it);rows={};cols={}
for i in range(n):x=next(it);y=next(it);rows.setdefault(x,[]).append(i);cols.setdefault(y,[]).append(i)
removed=bytearray(n);q=next(it);out=[]
for _ in range(q):
 kind=next(it);p=next(it);group=rows if kind==1 else cols;indices=group.pop(p,[]);count=0
 for i in indices:
  if not removed[i]:removed[i]=1;count+=1
 out.append(str(count))
print('\\n'.join(out))
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc401_d':
  def fill(k:int,s:str)->str:return f'{len(s)} {k}\n{s}\n'
  raws=[fill(0,'.'),fill(0,'?'),fill(1,'?'),fill(1,'o'),fill(1,'???'),fill(2,'????'),fill(2,'?????'),fill(1,'?o???')]
  while len(raws)<16:
   n=10+len(raws);base=[]
   for i in range(n):base.append('o' if (i==0 or base[-1]!='o') and rng.randrange(3)==0 else '.')
   k=base.count('o');s=''.join('?' if rng.randrange(2) else c for c in base);raws.append(fill(k,s))
  raws+=[fill(100000,'?'*199999),fill(100000,'?'*200000)]
 elif pid=='abc402_d':
  def lines(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(line(p) for p in a)
  raws=[lines(2,[(1,2)]),lines(4,[(1,2),(3,4)]),lines(5,[(1,2),(3,4)]),lines(4,[(1,3),(2,4)]),lines(4,[(1,2),(1,3)])]
  while len(raws)<16:
   n=5+len(raws);pairs=[(a,b) for a in range(1,n+1) for b in range(a+1,n+1)];raws.append(lines(n,rng.sample(pairs,4+len(raws))))
  raws+=[lines(1000000,[(1,b) for b in range(2,300002)]),lines(1000000,[(a,1000000-a) for a in range(1,300001)])]
 elif pid=='abc403_d':
  def diff(d:int,a:list[int])->str:return f'{len(a)} {d}\n'+line(a)
  raws=[diff(0,[0]),diff(0,[0,0,0]),diff(1,[0,1]),diff(1,[0]+[1]*10+[2]),diff(2,[0,2,4,6]),diff(1000000,[0,1000000]),diff(0,[0,1,2]),diff(1,[0,1,2,3])]
  while len(raws)<16:raws.append(diff(rng.randrange(11),[rng.randrange(30) for _ in range(10+len(raws))]))
  raws+=[diff(1,list(range(200000))),diff(1000000,[0]*100000+[1000000]*100000)]
 elif pid=='abc404_d':
  def zoos(c:list[int],animals:list[tuple[int,...]])->str:return f'{len(c)} {len(animals)}\n'+line(c)+''.join(line((len(p),)+p) for p in animals)
  raws=[zoos([0],[(1,)]),zoos([10**9],[(1,)]),zoos([5,3],[(1,2)]),zoos([5,3],[(1,),(2,)])]
  while len(raws)<16:
   n=2+len(raws)%8;c=[rng.randrange(10**9+1) for _ in range(n)];animals=[tuple(rng.sample(range(1,n+1),rng.randint(1,n))) for _ in range(5+len(raws))];raws.append(zoos(c,animals))
  from itertools import combinations
  pairs=list(combinations(range(1,11),2));raws+=[zoos([10**9]*10,(pairs*3)[:100]),zoos([10**9]*10,[tuple(range(1,11))]*100)]
 elif pid=='abc405_d':
  def grid(rows:list[str])->str:return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'
  raws=[grid(['##','##']),grid(['EE','EE']),grid(['E.','..']),grid(['E.','.E']),grid(['E#','##']),grid(['E#E','.#.','.#.'])]
  while len(raws)<16:
   h=3+len(raws)%5;w=3+len(raws)%7;rows=[''.join('E' if rng.randrange(7)==0 else '.' for _ in range(w)) for _ in range(h)];rows[0]='E'+rows[0][1:];raws.append(grid(rows))
  split=['.'*500+'#'+'.'*499 for _ in range(1000)];split[0]='E'+split[0][1:];split[-1]=split[-1][:-1]+'E';plain=['.'*1000 for _ in range(1000)];plain[0]='E'+plain[0][1:];raws+=[grid(split),grid(plain)]
 else:
  def garbage(h:int,w:int,p:list[tuple[int,int]],queries:list[tuple[int,int]])->str:return f'{h} {w} {len(p)}\n'+''.join(line(t) for t in p)+str(len(queries))+'\n'+''.join(line(t) for t in queries)
  raws=[garbage(1,1,[(1,1)],[(1,1)]),garbage(1,1,[(1,1)],[(2,1)]),garbage(1,1,[(1,1)],[(1,1)]*3),garbage(2,2,[(1,1),(1,2),(2,1)],[(2,1),(1,1),(2,2)])]
  while len(raws)<16:
   h=3+len(raws)%5;w=3+len(raws)%7;points=rng.sample([(x,y) for x in range(1,h+1) for y in range(1,w+1)],min(h*w,5+len(raws)));queries=[(rng.randint(1,2),1) for _ in range(10+len(raws))];queries=[(kind,rng.randint(1,h if kind==1 else w)) for kind,_ in queries];raws.append(garbage(h,w,points,queries))
  raws+=[garbage(200000,200000,[(1,y) for y in range(1,200001)],[(2,y) for y in range(1,200001)]),garbage(200000,200000,[(x,x) for x in range(1,200001)],[(1,x) for x in range(1,200001)])]
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i==16 else 'random'} for i,raw in enumerate(raws)]
HINTS={
'abc401_d':('確定したoの隣は必ず.です。残る?の連続区間を考えます。','長さLの自由区間に置けるoは最大ceil(L/2)個です。残りKが最大数に等しい場合、奇数長区間は交互配置に確定します。','疑似コード: o隣の?を.にする。need=K-固定o数、cap=sum ceil(runLength/2)。need==0なら全?を.。need==capなら奇数長runをo.o...oに確定、偶数長は?のまま。他の場合は全自由?を維持して出力。'),
'abc402_d':('円上の二点を通る直線の向きは、二点の角度の平均から決まります。','直線が平行である条件は(A+B) mod Nが等しいことです。全直線対から、同じ向きの組を引きます。','疑似コード: cnt[(A+B)%N]を各直線で増やす。answer=M*(M-1)/2-sum cnt[v]*(cnt[v]-1)/2。円の外で交わる直線も数える。'),
'abc403_d':('同じ値の要素をまとめ、差Dの値どうしだけをつなぎます。','D>0なら各剰余類のグラフは道です。頻度を重みとした独立集合をDPし、残せる最大個数を求めます。','疑似コード: D==0ならN-異なる値数。各v%Dの値をsortし、連続差Dの道でtake=skip+freq,skip=max(oldTake,oldSkip)。切れ目ごとに最大保持を合計。N-合計を出力。'),
'abc404_d':('同じ動物園を3回以上訪れる必要はありません。','各動物園の訪問数を0/1/2とする3^N通りを試し、全動物を2度以上見られる候補を比較します。','疑似コード: best=2*sum C。全visits in {0,1,2}^Nについてcost=sum visits[i]*C[i]。各動物の所属園visits合計>=2ならbest=min(best,cost)。bestを出力。'),
'abc405_d':('非常口から通路へ逆向きに広がると、最寄り非常口までの距離が求まります。','全てのEを始点にBFSし、初めて見つけた通路の矢印を、そこへ来た方向の逆向きにします。','疑似コード: queueに全E。popしたマスの隣が.なら、その隣へpop元を指す矢印を書いてqueueへ。BFS順で距離が1ずつ減る矢印となる。#とEを保持してグリッドを出力。'),
'abc406_d':('各行・列に落ちているゴミの番号をまとめておきます。','ゴミが既に捨てられたかを記録し、問い合わせた行・列の一覧を処理後に空にします。','疑似コード: row[x],col[y]へ各ゴミidを登録。queryの一覧をpopして未削除idだけcount++/削除。countを出力。各idは行と列で最大2回しか処理しない。')}

TITLES={'abc401_d': 'Logical Filling', 'abc402_d': 'Line Crossing', 'abc403_d': 'Forbidden Difference', 'abc404_d': "Goin' to the Zoo", 'abc405_d': 'Escape Route', 'abc406_d': 'Garbage Removal'}

PUBLISHED_SAMPLES={'abc401_d': [{'input': '4 2\no???\n', 'expected': 'o.??\n'}, {'input': '5 2\n?????\n', 'expected': '?????\n'}, {'input': '7 3\n.o???o.\n', 'expected': '.o.o.o.\n'}], 'abc402_d': [{'input': '8 3\n1 5\n1 8\n2 4\n', 'expected': '2\n'}, {'input': '5 10\n2 5\n1 5\n1 2\n2 4\n2 3\n1 3\n1 4\n3 5\n3 4\n4 5\n', 'expected': '40\n'}], 'abc403_d': [{'input': '5 2\n3 1 4 1 5\n', 'expected': '1\n'}, {'input': '4 3\n1 6 1 8\n', 'expected': '0\n'}, {'input': '10 3\n1 6 2 10 2 3 2 10 6 4\n', 'expected': '2\n'}], 'abc404_d': [{'input': '4 3\n1000 300 700 200\n3 1 3 4\n3 1 2 4\n2 1 3\n', 'expected': '1800\n'}, {'input': '7 6\n500 500 500 500 500 500 1000\n3 1 2 7\n3 2 3 7\n3 3 4 7\n3 4 5 7\n3 5 6 7\n3 6 1 7\n', 'expected': '2000\n'}], 'abc405_d': [{'input': '3 4\n...E\n.#..\n....\n', 'expected': '>>>E\n^#>^\n>>>^\n'}, {'input': '3 2\n##\n##\n##\n', 'expected': '##\n##\n##\n'}, {'input': '7 20\n....................\n..#..#..####..#E##..\n..#..#..#..#..#.....\n..E###..#..#..####..\n.....#..#..E.....#..\n.....#..####..####..\n....................\n', 'expected': '>v<<<<<>>>>>>>>v<<<<\n>v#^<#^^####v^#E##vv\n>v#^<#v^#>v#vv#^<<<<\n>>E###vv#>v#vv####^<\n>>^<<#vv#>>E<<<<<#^<\n>>^<<#vv####^<####^<\n>>^<<<<<>>>>^<<<<<^<\n'}], 'abc406_d': [{'input': '3 4 5\n1 2\n1 3\n3 4\n3 1\n2 2\n5\n1 1\n1 2\n2 2\n2 4\n1 2\n', 'expected': '2\n1\n0\n1\n0\n'}, {'input': '1 2 1\n1 2\n7\n2 1\n2 1\n2 1\n2 1\n2 1\n2 1\n2 1\n', 'expected': '0\n0\n0\n0\n0\n0\n0\n'}, {'input': '4 4 16\n1 1\n1 2\n1 3\n1 4\n2 1\n2 2\n2 3\n2 4\n3 1\n3 2\n3 3\n3 4\n4 1\n4 2\n4 3\n4 4\n7\n2 1\n1 1\n2 2\n1 2\n2 3\n1 3\n2 4\n', 'expected': '4\n3\n3\n2\n2\n1\n1\n'}]}

SAMPLE_COUNTS={'abc401_d': 3, 'abc402_d': 2, 'abc403_d': 3, 'abc404_d': 2, 'abc405_d': 3, 'abc406_d': 3}
