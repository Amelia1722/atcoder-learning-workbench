"""Statement-checked three-stage hints for ABC248–250 B."""
HINTS_V130 = {
    'abc248_b': (
        '1回叫ぶたびに現在の個数がK倍になります。B以上になるまで何回倍率を掛ければよいかをそのまま追えます。',
        'Aから始めて、値がB未満の間だけK倍し、掛けた回数を数えます。K≥2なので回数は多くありません。',
        '疑似コード:\ncount = 0\ncurrent = A\nwhile current < B:\n  current *= K\n  count += 1\nprint(count)',
    ),
    'abc249_b': (
        '必要な条件は3つです。大文字があること、小文字があること、同じ文字が二度現れないことを別々に確認します。',
        '大文字・小文字の存在は各文字を走査して判定できます。重複はsetの要素数と元の文字列長を比較すると確認できます。',
        '疑似コード:\nhas_upper = any(c is uppercase for c in S)\nhas_lower = any(c is lowercase for c in S)\nall_unique = len(set(S)) == len(S)\nif has_upper and has_lower and all_unique: print("Yes")\nelse: print("No")',
    ),
    'abc250_b': (
        '元はN×Nのチェッカーボードです。各1マスを縦A行・横B列へ拡大したものとして考えます。',
        '出力上の位置(i,j)が属する元タイルは(i//A, j//B)です。その2つの添字の和の偶奇で`.`か`#`かが決まります。',
        '疑似コード:\nfor i in 0 .. A*N-1:\n  row = ""\n  for j in 0 .. B*N-1:\n    if (i//A + j//B) % 2 == 0: row += "."\n    else: row += "#"\n  print(row)',
    ),
}
