"""ABC024/025 B from manually inspected public official pages; HTML originals not authenticated."""
from __future__ import annotations
import random
import re

TASKS = ('abc024_b', 'abc025_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)


def number(token: str) -> int:
    if not POS.fullmatch(token):
        raise ValueError('noncanonical positive integer')
    return int(token)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('invalid task or input framing')
    rows = raw[:-1].split('\n')
    if pid == 'abc024_b':
        head = rows[0].split(' ')
        if len(head) != 2:
            raise ValueError('expected N T')
        n, t = map(number, head)
        if not 1 <= n <= 100_000 or not 1 <= t <= 100_000 or len(rows) != n + 1:
            raise ValueError('count/duration/row constraints')
        times = [number(row) for row in rows[1:]]
        if any(x > 1_000_000 for x in times) or times != sorted(times):
            raise ValueError('timestamps invalid or unsorted')
        return t, times
    head = rows[0].split(' ')
    if len(head) != 3:
        raise ValueError('expected N A B')
    n, a, b = map(number, head)
    if not 1 <= n <= 100 or not 1 <= a <= b <= 100 or len(rows) != n + 1:
        raise ValueError('moves or interval constraints')
    moves = []
    for row in rows[1:]:
        pair = row.split(' ')
        if len(pair) != 2 or pair[0] not in ('East', 'West'):
            raise ValueError('direction or spacing invalid')
        distance = number(pair[1])
        if distance > 100:
            raise ValueError('distance constraint')
        moves.append((pair[0], distance))
    return a, b, moves


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc024_b':
        duration, times = value
        # Merge half-open [time,time+duration) intervals, not reference's gap formula.
        start, end = times[0], times[0] + duration
        total = 0
        for x in times[1:]:
            if x > end:
                total += end - start
                start, end = x, x + duration
            else:
                end = max(end, x + duration)
        return output == str(total + end - start)
    a, b, moves = value
    pos = 0
    for direction, distance in moves:
        step = a if distance < a else b if distance > b else distance
        pos += step if direction == 'East' else -step
    return output == ('East ' + str(pos) if pos > 0 else 'West ' + str(-pos) if pos < 0 else '0')


def generate(pid: str, seed: int = 55) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unsupported problem')
    rng = random.Random(f'abc-v55:{pid}:{seed}')
    cases: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(kind: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); cases.append({'category': kind, 'input': raw})
    if pid == 'abc024_b':
        def fmt(t: int, times: list[int]) -> str:
            return f'{len(times)} {t}\n' + ''.join(f'{x}\n' for x in times)
        presets = [
            (1,[1]), (100000,[1000000]), (1,[1,1]), (1,[1,2]),
            (10,[20,100,105,217,314]),(10,list(range(1,11))),
            (100000,[1,1,1]),(100000,[1,1000000]),
            (2,[1,2,3,4]),(5,[1,6,11,16]),(5,[1,5,9,13]),
            (10,[1,1,10,10,20]),(1,[999999,1000000]),
            (99999,[1,100000,100001,1000000]),
        ]
        for t, times in presets: add('boundary' if len(times) < 3 else 'normal', fmt(t,times))
        while len(cases) < 17:
            t = rng.randint(1,100000)
            times = sorted(rng.randint(1,1000000) for _ in range(rng.randint(1,180)))
            add('random',fmt(t,times))
        add('constraint_max', fmt(100000,[1+(i%1000000) for i in range(100000)]))
    else:
        def fmt(a: int, b: int, moves: list[tuple[str,int]]) -> str:
            return f'{len(moves)} {a} {b}\n'+''.join(f'{s} {d}\n' for s,d in moves)
        presets = [
            (1,1,[('East',1)]),(1,1,[('West',100)]),
            (100,100,[('East',1)]),(100,100,[('West',100)]),
            (5,10,[('East',7),('West',3),('West',11)]),
            (3,8,[('West',6),('East',3),('East',1)]),
            (25,25,[('East',1),('East',1),('West',1),('East',100),('West',1)]),
            (1,100,[('East',100),('West',100)]),
            (10,20,[('West',1),('East',100)]),
            (99,100,[('East',98),('West',100)]),
            (50,50,[('East',5),('West',5)]),
            (1,1,[('East',1)]*100),
            (100,100,[('West',1)]*100),
            (1,100,[('East',100),('West',1)]*50),
        ]
        for a,b,moves in presets: add('boundary' if len(moves)==1 else 'normal',fmt(a,b,moves))
        while len(cases)<17:
            a=rng.randint(1,100); b=rng.randint(a,100)
            moves=[(rng.choice(('East','West')),rng.randint(1,100)) for _ in range(rng.randint(1,100))]
            add('random',fmt(a,b,moves))
        add('constraint_max',fmt(100,100,[('East' if i%2==0 else 'West',100) for i in range(100)]))
    if len(cases)!=18 or cases[-1]['category']!='constraint_max':
        raise ValueError(f'expected 18 distinct cases, found {len(cases)} for {pid}')
    return cases
