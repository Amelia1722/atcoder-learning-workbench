"""Statement-checked three-stage hints for ABC176–178 B."""
HINTS_V106 = {
    'abc176_b': (
        'Nは最大20万桁なので、Pythonの整数へ変換する必要はありません。9の倍数判定は各桁の和だけでできます。',
        '文字列としてNを受け取り、各文字を数字に変換して合計し、その合計が9で割り切れるかを判定します。O(|N|)です。',
        '''疑似コード:
s = input()
total = 各文字を数字にした値の合計
if total % 9 == 0:
  print("Yes")
else:
  print("No")''',
    ),
    'abc177_b': (
        'TをSのどこに重ねるかを全て試せます。各開始位置ごとに、対応する文字が何個違うか数えてみてください。',
        '開始位置iを0から|S|-|T|まで動かし、S[i+j]とT[j]の不一致数を数えます。その最小値が答えです。最大でも約1000×1000比較です。',
        '''疑似コード:
answer = |T|
for i = 0 .. |S|-|T|:
  diff = 0
  for j = 0 .. |T|-1:
    if S[i+j] != T[j]:
      diff += 1
  answer = min(answer, diff)
print(answer)''',
    ),
    'abc178_b': (
        '積xyの最大値は、区間内部ではなく端点の組み合わせに現れます。符号が混ざるケースを考えると、単にb*dだけを見るのは危険です。',
        'xの端点はa,b、yの端点はc,dなので、a*c, a*d, b*c, b*dの4通りを比較すれば十分です。',
        '''疑似コード:
candidates = [a*c, a*d, b*c, b*d]
print(max(candidates))''',
    ),
}
