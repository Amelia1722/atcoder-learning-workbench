"""ABC086–088 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc086_b','abc087_b','abc088_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG=re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc086_b':
        if len(lines)!=1: raise ValueError('lines')
        parts=lines[0].split(' ')
        if len(parts)!=2 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('ab')
        a,b=map(int,parts)
        if not (1<=a<=100 and 1<=b<=100): raise ValueError('range')
        return a,b
    if pid=='abc087_b':
        if len(lines)!=4 or any(NONNEG.fullmatch(x) is None for x in lines): raise ValueError('format')
        a,b,c,x=map(int,lines)
        if not (0<=a<=50 and 0<=b<=50 and 0<=c<=50 and a+b+c>=1 and 50<=x<=20000 and x%50==0):
            raise ValueError('range')
        return a,b,c,x
    if len(lines)!=2 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
    n=int(lines[0]); parts=lines[1].split(' ')
    if not (1<=n<=100 and len(parts)==n and all(POS.fullmatch(x) is not None for x in parts)):
        raise ValueError('N/array')
    a=list(map(int,parts))
    if any(not 1<=x<=100 for x in a): raise ValueError('range')
    return a

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc086_b':
        a,b=value; v=int(str(a)+str(b)); square=False
        k=1
        while k*k<=v:
            if k*k==v: square=True; break
            k+=1
        return output==('Yes' if square else 'No')
    if pid=='abc087_b':
        a,b,c,x=value; count=0
        for i in range(a+1):
            for j in range(b+1):
                for k in range(c+1):
                    if 500*i+100*j+50*k==x: count+=1
        return output==str(count)
    cards=list(value); alice=bob=0; turn=0
    while cards:
        best=max(cards); cards.remove(best)
        if turn%2==0: alice+=best
        else: bob+=best
        turn+=1
    return output==str(alice-bob)

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc086_b':
        vals=[(1,1),(1,21),(2,25),(4,9),(9,81),(10,24),(12,10),(16,9),(25,6),(36,1),(49,1),(64,4),(81,1),(99,99),(100,1),(100,10),(100,99)]
        for a,b in vals: add('boundary' if a in (1,100) or b in (1,100) else 'normal',f'{a} {b}\n')
        add('constraint_max','100 100\n')
    elif pid=='abc087_b':
        vals=[
          (1,0,0,500),(0,1,0,100),(0,0,1,50),(2,2,2,100),(5,1,0,150),(30,40,50,6000),
          (50,0,0,20000),(0,50,0,5000),(0,0,50,2500),(1,1,1,650),(2,3,4,700),(10,10,10,1000),
          (50,50,1,50),(1,50,50,20000),(50,1,50,19950),(25,25,25,10000),(50,50,50,50)]
        for a,b,c,x in vals:
            add('boundary' if 0 in (a,b,c) or 50 in (a,b,c) or x in (50,20000) else 'normal',f'{a}\n{b}\n{c}\n{x}\n')
        add('constraint_max','50\n50\n50\n20000\n')
    else:
        vals=[
          [1],[100],[3,1],[2,7,4],[20,18,2,18],[1,1],[1,2,3],[3,3,3],[100,1,100,1],
          list(range(1,11)),list(range(10,0,-1)),[50]*11,[1,100]*10,[99,98,97,96,95],
          list(range(1,51)),[100]*99,[1]*100]
        for a in vals:
            add('boundary' if len(a) in (1,99,100) or max(a)==100 else 'normal',f'{len(a)}\n'+' '.join(map(str,a))+'\n')
        add('constraint_max','100\n'+' '.join(['100']*100)+'\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
