"""Reviewed six C tasks with reverse permutation, combinatorics and bitset closure."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (199,201,202,203,204,205))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Query=tuple[int,int,int]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==199:
        require(len(rows)>=4,'shape');n=ints(rows[0],1)[0];s=rows[1];q=ints(rows[2],1)[0];require(1<=n<=200000 and len(s)==2*n and re.fullmatch('[A-Z]+',s) is not None and 1<=q<=300000 and len(rows)==q+3,'shape');queries=tuple(cast(Query,ints(row,3)) for row in rows[3:]);require(all(t==1 and 1<=a<b<=2*n or t==2 and a==b==0 for t,a,b in queries),'queries');return n,s,queries
    if number==201:
        require(len(rows)==1 and re.fullmatch('[ox?]{10}',rows[0]) is not None,'memory');return (rows[0],)
    if number==202:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==4,'shape');arrays=tuple(ints(row,n) for row in rows[1:]);require(all(1<=v<=n for a in arrays for v in a),'values');return (arrays,)
    if number==203:
        n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=10**9 and len(rows)==n+1,'shape');friends=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=10**18 and 1<=b<=10**9 for a,b in friends),'gifts');return k,friends
    if number==204:
        n,m=ints(rows[0],2);require(2<=n<=2000 and 0<=m<=min(2000,n*(n-1)) and len(rows)==m+1,'shape');edges=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(len(set(edges))==m and all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges),'edges');return n,edges
    require(len(rows)==1,'shape');a,b,c=ints(rows[0],3);require(-10**9<=a<=10**9 and -10**9<=b<=10**9 and 1<=c<=10**9,'powers');return a,b,c

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==199:
        n,s,queries=cast(tuple[int,str,tuple[Query,...]],data);mapping=list(range(2*n));offset=0
        for t,a,b in reversed(queries):
            if t==2:offset=n-offset
            else:
                a=(a-1+offset)%(2*n);b=(b-1+offset)%(2*n);mapping[a],mapping[b]=mapping[b],mapping[a]
        answer=['']*(2*n)
        for origin,destination in enumerate(mapping):answer[destination]=s[(origin+offset)%(2*n)]
        return ''.join(answer)
    if number==201:
        memory=cast(str,data[0]);required=memory.count('o');allowed=10-memory.count('x');return str(sum((-1)**j*comb(required,j)*(allowed-j)**4 for j in range(required+1)))
    if number==202:
        a,b,c=cast(tuple[tuple[int,...],tuple[int,...],tuple[int,...]],data[0]);ordered=sorted(a);return str(sum(bisect_right(ordered,b[j-1])-bisect_left(ordered,b[j-1]) for j in c))
    if number==203:
        k,friends=cast(tuple[int,tuple[Pair,...]],data);gifts=[0];barriers=[];maximum=0
        for a,b in sorted(friends):maximum=max(maximum,a-gifts[-1]);barriers.append(maximum);gifts.append(gifts[-1]+b)
        return str(k+gifts[bisect_right(barriers,k)])
    if number==204:
        n,edges=cast(tuple[int,tuple[Pair,...]],data);reachable=[1<<j for j in range(n)]
        for a,b in edges:reachable[a-1]|=1<<(b-1)
        for k in range(n):
            bit=1<<k;row=reachable[k]
            for j in range(n):
                if reachable[j]&bit:reachable[j]|=row
        return str(sum(row.bit_count() for row in reachable))
    a,b,c=cast(tuple[int,int,int],data)
    def signed(v:int)->tuple[int,int]:return (0,0) if v==0 else (-1 if v<0 and c%2 else 1,abs(v))
    sa,ma=signed(a);sb,mb=signed(b)
    order=(sa>sb)-(sa<sb) if sa!=sb else ((ma>mb)-(ma<mb))*sa
    return '<' if order<0 else '>' if order>0 else '='

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc199_c':"n=int(input());s=list(input());q=int(input());offset=0\nfor _ in range(q):\n t,a,b=map(int,input().split())\n if t==2:offset=n-offset\n else:\n  a=(a-1+offset)%(2*n);b=(b-1+offset)%(2*n);s[a],s[b]=s[b],s[a]\nprint(''.join(s[offset:]+s[:offset]))\n",
'abc201_c':"s=input();answer=0\nfor n in range(10000):\n digits=set(f'{n:04}')\n if all((s[j]!='o' or str(j) in digits) and (s[j]!='x' or str(j) not in digits) for j in range(10)):answer+=1\nprint(answer)\n",
'abc202_c':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));b=list(map(int,input().split()));c=list(map(int,input().split()));counts=Counter(a);print(sum(counts[b[j-1]] for j in c))\n",
'abc203_c':"n,money=map(int,input().split());friends=sorted(tuple(map(int,input().split())) for _ in range(n));position=0\nfor a,b in friends:\n distance=a-position\n if distance>money:break\n money-=distance;position=a;money+=b\nprint(position+money)\n",
'abc204_c':"n,m=map(int,input().split());graph=[[] for _ in range(n)]\nfor _ in range(m):\n a,b=map(int,input().split());graph[a-1].append(b-1)\nanswer=0\nfor start in range(n):\n seen={start};pending=[start]\n while pending:\n  for v in graph[pending.pop()]:\n   if v not in seen:seen.add(v);pending.append(v)\n answer+=len(seen)\nprint(answer)\n",
'abc205_c':"a,b,c=map(int,input().split());power=1 if c%2 else 2;a=a**power;b=b**power;print('<' if a<b else '>' if a>b else '=')\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16400+number)
    if number==199:
        def text(n:int,s:str,q:list[Query])->str:return f'{n}\n{s}\n{len(q)}\n'+''.join(line(t) for t in q)
        raws=[text(1,'AB',[(1,1,2)]),text(1,'AB',[(2,0,0)]),text(1,'AA',[(2,0,0)]),text(2,'ABCD',[(2,0,0),(1,1,4)])]
        for j in range(1,13):
            n=j+1;q=[]
            for _ in range(j*3):
                if rng.randrange(3)==0:q.append((2,0,0))
                else:a,b=sorted(rng.sample(range(1,2*n+1),2));q.append((1,a,b))
            raws.append(text(n,''.join(rng.choice('ABCDE') for _ in range(2*n)),q))
        raws.extend([text(200000,'AB'*200000,[(2,0,0),(1,1,400000)]*149999+[(1,2,399999),(2,0,0)]),text(200000,'Z'*400000,[(2,0,0)]*300000)])
    elif number==201:
        raws=[s+'\n' for s in ['xxxxxxxxxx','??????????','oooooooooo','oxxxxxxxxx','ooxxxxxxxx','oooxxxxxxx','ooooxxxxxx','oooooxxxxx','o?????????','oo????????','ooo???????','oooo??????','?xxxxxxxxx','??xxxxxxxx','???xxxxxxx','????xxxxxx','o?o?o?o?xx','ooooo?????']]
    elif number==202:
        def arrays(a:list[int],b:list[int],c:list[int])->str:return f'{len(a)}\n'+line(a)+line(b)+line(c)
        raws=[arrays([1],[1],[1]),arrays([1,1],[2,2],[1,2]),arrays([1,2],[1,2],[1,2]),arrays([2,2],[2,1],[1,1])]
        for n in range(3,15):raws.append(arrays(*[[rng.randint(1,n) for _ in range(n)] for _ in range(3)]))
        raws.extend([arrays(list(range(1,100001)),list(range(100000,0,-1)),list(range(1,100001))),arrays([100000]*100000,[100000]*100000,[100000]*100000)])
    elif number==203:
        def friends(k:int,p:list[Pair])->str:return f'{len(p)} {k}\n'+''.join(line(t) for t in p)
        raws=[friends(1,[(1,1)]),friends(1,[(2,1)]),friends(1,[(1,1),(2,1)]),friends(1,[(1,1),(1,1)])]
        for n in range(3,15):raws.append(friends(n,[(rng.randint(1,n*5),rng.randint(1,n)) for _ in range(n)]))
        raws.extend([friends(10**9,[(j+1,10**9) for j in range(200000)]),friends(10**9,[(10**18,10**9)]*200000)])
    elif number==204:
        def graph(n:int,e:list[Pair])->str:return f'{n} {len(e)}\n'+''.join(line(t) for t in e)
        raws=[graph(2,[]),graph(2,[(1,2)]),graph(2,[(1,2),(2,1)]),graph(3,[(1,2),(2,3)])]
        for n in range(4,16):e=[(a,b) for a in range(1,n+1) for b in range(1,n+1) if a!=b and rng.randrange(5)==0];raws.append(graph(n,e))
        raws.extend([graph(2000,[(j,j+1) for j in range(1,2000)]),graph(2000,[(j,j%2000+1) for j in range(1,2001)])])
    else:raws=[line(t) for t in ((-10**9,-10**9,1),(-2,3,1),(-2,3,2),(-3,-2,1),(-3,-2,2),(0,1,1),(1,0,2),(0,0,10**9),(-1,1,10**9),(-1,1,999999999),(3,2,4),(2,3,3),(-10**9,10**9,999999999),(-10**9,10**9,10**9),(10**9,999999999,10**9),(-999999999,-10**9,10**9),(10**9,-10**9,999999999),(10**9,10**9,10**9))]
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc199_c':('前後半の交換を毎回コピーせずに表せないか考えます。','文字配列を固定し、先頭位置を0またはNとして持ちます。交換位置を先頭位置だけずらして配列へ対応させます。','疑似コード: offset=0; for (t,a,b): if t==2: offset=N-offset; else: swap(S[(a-1+offset)%(2*N)],S[(b-1+offset)%(2*N)]); print(S[offset:]+S[:offset])。'),
'abc201_c':('暗証番号は先頭の0も含む4桁で、候補は10000個です。','候補に含まれる数字の集合を作り、oの数字を全て含み、xの数字を一つも含まないか調べます。','疑似コード: answer=0; for n=0..9999: digits=set(format4(n)); if all required digits present and forbidden digits absent: answer+=1; print(answer)。'),
'abc202_c':('jを固定すると、B[C[j]]に等しいAの個数を知りたいです。','Aの各値の出現回数を先に数えます。Cの各要素についてBを参照し、その出現回数を足します。','疑似コード: count=frequency(A); answer=0; for j in C: answer+=count[B[j-1]]; print(answer)。'),
'abc203_c':('友達がいる村を近い順に訪ねれば、到達可否を判断できます。','位置でソートし、次の村までの費用を払えるときだけ移動して贈り物を加えます。払えなくなったら所持金の分だけ進みます。','疑似コード: position=0; for (a,b) in sorted(friends): if a-position>money: break; money-=a-position; position=a; money+=b; print(position+money)。'),
'abc204_c':('出発点を固定し、到達できる都市を全て探します。','各都市を始点としてDFSを行い、訪問済み都市の数を合計します。道路を0本使う旅行も含めます。','疑似コード: answer=0; for start in cities: seen={start}; DFS directed edges adding unseen destinations; answer+=len(seen); print(answer)。'),
'abc205_c':('指数が偶数か奇数かで、負の数の符号が変わります。','正の奇数乗は元の値の大小を保ちます。偶数乗は二乗した値の大小と同じです。大きな冪を計算する必要はありません。','疑似コード: p=1 if C odd else 2; x=A**p; y=B**p; print(< if x<y else > if x>y else =)。')}

TITLES={'abc199_c': 'IPFL', 'abc201_c': 'Secret Number', 'abc202_c': 'Made Up', 'abc203_c': 'Friends and Travel costs', 'abc204_c': 'Tour', 'abc205_c': 'POW'}
PUBLISHED_SAMPLES={'abc199_c': [{'input': '2\nFLIP\n2\n2 0 0\n1 1 4\n', 'expected': 'LPFI\n'}, {'input': '2\nFLIP\n6\n1 1 3\n2 0 0\n1 1 2\n1 2 3\n2 0 0\n1 1 4\n', 'expected': 'ILPF\n'}], 'abc201_c': [{'input': 'ooo???xxxx\n', 'expected': '108\n'}, {'input': 'o?oo?oxoxo\n', 'expected': '0\n'}, {'input': 'xxxxx?xxxo\n', 'expected': '15\n'}], 'abc202_c': [{'input': '3\n1 2 2\n3 1 2\n2 3 2\n', 'expected': '4\n'}, {'input': '4\n1 1 1 1\n1 1 1 1\n1 2 3 4\n', 'expected': '16\n'}, {'input': '3\n2 3 3\n1 3 3\n1 1 1\n', 'expected': '0\n'}], 'abc203_c': [{'input': '2 3\n2 1\n5 10\n', 'expected': '4\n'}, {'input': '5 1000000000\n1 1000000000\n2 1000000000\n3 1000000000\n4 1000000000\n5 1000000000\n', 'expected': '6000000000\n'}, {'input': '3 2\n5 5\n2 1\n2 2\n', 'expected': '10\n'}], 'abc204_c': [{'input': '3 3\n1 2\n2 3\n3 2\n', 'expected': '7\n'}, {'input': '3 0\n', 'expected': '3\n'}, {'input': '4 4\n1 2\n2 3\n3 4\n4 1\n', 'expected': '16\n'}], 'abc205_c': [{'input': '3 2 4\n', 'expected': '>\n'}, {'input': '-7 7 2\n', 'expected': '=\n'}, {'input': '-8 6 3\n', 'expected': '<\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
