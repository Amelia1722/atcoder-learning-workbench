"""Independently authored verified ABC A/B task fixtures (batch 3).

Each task has a manually audited official statement and sample, an exact input
validator, deterministic normal/boundary/random/max test inputs, and a checker
implemented separately from backend/data/reference_solutions. This remains a
finite check, not a proof of every possible reference program behavior.
"""
from __future__ import annotations

from collections import Counter
from itertools import combinations
from random import Random
import re

OFFICIAL = 'https://atcoder.jp/contests/{contest}/tasks/{problem}'

# Source information and samples taken from the individual AtCoder task pages.
BATCH3 = {
    'abc143_a': ('12 4\n', '4', '1<=A,B<=100'),
    'abc143_b': ('3\n3 1 2\n', '11', '2<=N<=50; 0<=d_i<=100'),
    'abc152_a': ('3 3\n', 'Yes', '1<=N<=100; 0<=M<=N'),
    'abc152_b': ('4 3\n', '3333', '1<=a,b<=9'),
    'abc154_a': ('red blue\n3 4\nred\n', '2 4', 'S,T distinct lowercase length 1..10; U equals S or T; 1<=A,B<=10'),
    'abc154_b': ('sardine\n', 'xxxxxxx', 'lowercase S length 1..100'),
    'abc200_a': ('2021\n', '21', '1<=N<=3000'),
    'abc200_b': ('2021 4\n', '50531', '1<=N<=100000; 1<=K<=20'),
    'abc212_a': ('50 50\n', 'Alloy', '0<=A,B<=100; A+B>0'),
    'abc212_b': ('7777\n', 'Weak', 'four decimal digits including leading zeros'),
    'abc231_a': ('1000\n', '10', '1<=D<=10000; numerical answer tolerance 1e-3'),
    'abc231_b': ('5\nsnuke\nsnuke\ntakahashi\ntakahashi\ntakahashi\n', 'takahashi',
                 '1<=N<=100; lowercase names length 1..10; unique highest count'),
    'abc251_a': ('abc\n', 'abcabc', 'lowercase S length 1..3'),
    'abc251_b': ('2 10\n1 3\n', '3', '1<=N<=300; 1<=W,A_i<=1000000'),
}
BATCH3 = {
    pid: {
        'source_url': OFFICIAL.format(contest=pid.split('_')[0], problem=pid),
        'sample_input': sample_in, 'sample_output': sample_out,
        'constraints': constraints,
    }
    for pid, (sample_in, sample_out, constraints) in BATCH3.items()
}
LOWER = re.compile(r'[a-z]+\Z')
PAIR_RANGES = {
    'abc143_a': ((1,100),(1,100)),
    'abc152_a': ((1,100),(0,100)),
    'abc152_b': ((1,9),(1,9)),
    'abc200_b': ((1,100000),(1,20)),
    'abc212_a': ((0,100),(0,100)),
}
SINGLE_RANGES = {'abc200_a': (1,3000), 'abc231_a': (1,10000)}
STRING_RANGES = {'abc154_b': (1,100), 'abc251_a': (1,3)}


def validate(pid: str, data: str):
    if pid not in BATCH3:
        raise ValueError('未対応の問題ID')
    x = data.split()
    if pid in PAIR_RANGES:
        if len(x)!=2 or any(re.fullmatch(r'[0-9]+',v) is None for v in x):
            raise ValueError('2つの非負整数が必要です')
        a,b=map(int,x)
        (amin,amax),(bmin,bmax)=PAIR_RANGES[pid]
        if not amin<=a<=amax or not bmin<=b<=bmax:
            raise ValueError('整数の値域違反')
        if pid=='abc152_a' and b>a:raise ValueError('MはN以下です')
        if pid=='abc212_a' and a+b==0:raise ValueError('A+Bは正です')
        return a,b
    if pid in SINGLE_RANGES:
        if len(x)!=1 or re.fullmatch(r'[0-9]+',x[0]) is None:raise ValueError('整数1つが必要です')
        n=int(x[0]);a,b=SINGLE_RANGES[pid]
        if not a<=n<=b:raise ValueError('整数の値域違反')
        return n
    if pid in STRING_RANGES:
        a,b=STRING_RANGES[pid]
        if len(x)!=1 or not LOWER.fullmatch(x[0]) or not a<=len(x[0])<=b:
            raise ValueError('小文字文字列の長さ違反')
        return x[0]
    if pid=='abc212_b':
        if len(x)!=1 or re.fullmatch(r'[0-9]{4}',x[0]) is None:
            raise ValueError('先頭0を許す4桁の数字が必要です')
        return x[0]
    if pid=='abc154_a':
        if len(x)!=5:raise ValueError('S T / A B / U の入力が必要です')
        s,t,sa,sb,u=x
        if not all(LOWER.fullmatch(z) for z in (s,t,u)) or not all(1<=len(z)<=10 for z in (s,t)):
            raise ValueError('文字列制約違反')
        if s==t or u not in (s,t):raise ValueError('S!=TかつUはS,Tいずれかです')
        if any(re.fullmatch(r'[0-9]+',z) is None for z in (sa,sb)):raise ValueError('整数でない数量')
        a,b=int(sa),int(sb)
        if not 1<=a<=10 or not 1<=b<=10:raise ValueError('数量の値域違反')
        return s,t,a,b,u
    if pid=='abc231_b':
        if not x or re.fullmatch(r'[0-9]+',x[0]) is None:raise ValueError('Nが必要です')
        n=int(x[0]); names=x[1:]
        if not 1<=n<=100 or len(names)!=n or any(not LOWER.fullmatch(s) or len(s)>10 for s in names):
            raise ValueError('N・票数・文字列長の制約違反')
        count=Counter(names)
        if sum(v==max(count.values()) for v in count.values()) != 1:
            raise ValueError('最多得票の候補が一意ではありません')
        return names
    if pid in ('abc143_b','abc251_b'):
        if not x or any(re.fullmatch(r'[0-9]+',z) is None for z in x):
            raise ValueError('入力は非負整数のみです')
        ints=list(map(int,x))
        if pid=='abc143_b':
            n=ints[0]
            if not 2<=n<=50 or len(ints)!=n+1 or any(not 0<=a<=100 for a in ints[1:]):
                raise ValueError('N・値域・配列長の制約違反')
            return ints[1:]
        if len(ints)<3:raise ValueError('N W おもり列が必要です')
        n,w=ints[:2]
        if not 1<=n<=300 or not 1<=w<=10**6 or len(ints)!=n+2 or any(not 1<=a<=10**6 for a in ints[2:]):
            raise ValueError('N/W/Aの制約違反')
        return w,ints[2:]
    raise AssertionError(pid)


def generate(pid: str, count: int, seed: int, include_large: bool):
    if pid not in BATCH3 or not 1<=count<=80:raise ValueError('問題ID/ケース数が不正')
    r=Random(seed);cases=[];seen=set()
    def add(category,data):
        validate(pid,data)
        if data in seen:
            if category=='constraint_max':
                # Upgrade an existing boundary case into the maximum case.
                next(c for c in cases if c['input']==data)['category']='constraint_max'
        else:
            seen.add(data);cases.append({'category':category,'input':data})
    def arr(a):return f'{len(a)}\n'+' '.join(map(str,a))+'\n'
    def weights(a,w):return f'{len(a)} {w}\n'+' '.join(map(str,a))+'\n'
    def names(a):return f'{len(a)}\n'+'\n'.join(a)+'\n'
    if pid in PAIR_RANGES:
        if pid=='abc143_a':pairs=[(1,1),(1,100),(100,1),(100,100),(99,49),(100,50),(100,49),(12,4)]
        elif pid=='abc152_a':pairs=[(1,0),(1,1),(100,0),(100,100),(100,99),(3,3),(3,2)]
        elif pid=='abc152_b':pairs=[(1,1),(1,9),(9,1),(9,9),(4,3),(7,7),(2,3),(3,2)]
        elif pid=='abc200_b':pairs=[(1,1),(1,20),(100000,1),(100000,20),(200,20),(40000,2),(2021,4),(8691,20)]
        else:pairs=[(0,1),(1,0),(100,0),(0,100),(100,100),(1,1),(50,50),(100,2)]
        for a,b in pairs:add('usual',f'{a} {b}\n')
        (la,ha),(lb,hb)=PAIR_RANGES[pid]
        trials=0
        while len(cases)<count and trials<5000:
            a,b=r.randint(la,ha),r.randint(lb,hb);trials+=1
            if pid=='abc152_a':b=r.randint(0,a)
            if pid=='abc212_a' and a+b==0:continue
            add('random',f'{a} {b}\n')
        if include_large:
            maximum=(ha,ha if pid=='abc152_a' else hb)
            if pid=='abc212_a':maximum=(100,100)
            if pid=='abc200_b':maximum=(100000,20)
            add('constraint_max',f'{maximum[0]} {maximum[1]}\n')
    elif pid in SINGLE_RANGES:
        lo,hi=SINGLE_RANGES[pid]
        for v in sorted({lo,lo+1,hi-1,hi,100 if hi>=100 else lo,101 if hi>=101 else lo,
                         200 if hi>=200 else lo,201 if hi>=201 else lo,2021 if hi>=2021 else hi}):
            add('boundary',f'{v}\n')
        while len(cases)<count:add('random',f'{r.randint(lo,hi)}\n')
        if include_large:add('constraint_max',f'{hi}\n')
    elif pid in STRING_RANGES:
        lo,hi=STRING_RANGES[pid]
        for s in ['a','z','abc','xxx','zz','sardine','x'*hi,'z'*hi,'a'*hi,'ab'*(hi//2)+'a'*(hi%2)]:
            if lo<=len(s)<=hi:add('usual',s+'\n')
        while len(cases)<count:
            n=r.randint(lo,hi);add('random',''.join(r.choice('abcxyz') for _ in range(n))+'\n')
        if include_large:add('constraint_max','z'*hi+'\n')
    elif pid=='abc212_b':
        for s in ['0000','9999','7777','0123','9012','7890','8901','0112','1212','1235','0001','9876']:
            add('boundary',s+'\n')
        while len(cases)<count:add('random',f'{r.randrange(10000):04d}\n')
        if include_large:add('constraint_max','9999\n')
    elif pid=='abc154_a':
        def ball(s,t,a,b,u):add('usual',f'{s} {t}\n{a} {b}\n{u}\n')
        for s,t,a,b,u in [('red','blue',3,4,'red'),('red','blue',5,5,'blue'),('a','b',1,1,'a'),
                          ('a','b',1,1,'b'),('abcdefghij','zyxwvutsrq',10,10,'abcdefghij'),
                          ('z','a',10,10,'a'),('a','z',1,10,'a'),('a','z',10,1,'z')]:ball(s,t,a,b,u)
        while len(cases)<count:
            a,b=r.randint(1,10),r.randint(1,10)
            s,t=r.sample(['a','b','abc','xyz','abcdefghij','zyxwvutsrq'],2)
            ball(s,t,a,b,r.choice([s,t]))
        if include_large:add('constraint_max','abcdefghij zyxwvutsrq\n10 10\nzyxwvutsrq\n')
    elif pid=='abc231_b':
        for arr_ in [['a'],['a','a'],['a','b','a'],['snuke','snuke','takahashi','takahashi','takahashi'],
                     ['abcdefghij']*6+['zyxwvutsrq']*5,['a']*100,['a']*50+['b']*49+['a']]:
            add('usual',names(arr_))
        while len(cases)<count:
            n=r.randint(1,100);win=r.choice(['a','b','abcdefghij'])
            choices=['a','b','abcdefghij','zyxwvutsrq','abc']
            rest=[r.choice(choices) for _ in range(n//3)]
            candidate=[win]*(n-len(rest))+rest
            # Ensure the unique-max promise even for short N or unlucky draws.
            if len(Counter(candidate)) and sum(v==max(Counter(candidate).values()) for v in Counter(candidate).values())==1:
                r.shuffle(candidate);add('random',names(candidate))
        if include_large:add('constraint_max',names(['a']*100))
    elif pid=='abc143_b':
        for a in [[0,0],[100,100],[0,100],[3,1,2],[5,0,7,8,3,3,2],[100]*50,[0]*50,list(range(50))]:
            add('usual',arr(a))
        while len(cases)<count:add('random',arr([r.randint(0,100) for _ in range(r.randint(2,50))]))
        if include_large:add('constraint_max',arr([100]*50))
    else:  # abc251_b
        for a,w in [([1],1),([10**6],1),([10**6],10**6),([1,3],10),([2,3],1),
                    ([3,3,3,3],12),([202,20,5,1,4,2,100],251),([1]*300,10**6),
                    ([10**6]*300,10**6),([1,2,3]*100,10**6)]:
            add('usual',weights(a,w))
        while len(cases)<count:
            n=r.randint(1,30);w=r.choice([1,2,100,10**6,r.randint(1,10**6)])
            a=[r.choice([1,w,10**6,r.randint(1,10**6)]) for _ in range(n)]
            add('random',weights(a,w))
        if include_large:add('constraint_max',weights([1,2,3]*100,10**6))
    # The UI treats the LAST bank case as the maximum-scale case. Move it
    # there even when its input was already generated among the small cases.
    if include_large:
        maxima=[c for c in cases if c['category']=='constraint_max']
        if not maxima:
            raise RuntimeError('最大規模入力を生成できませんでした')
        maximum=maxima[-1]
        return [c for c in cases if c['input']!=maximum['input']][:count] + [maximum]
    return cases[:count]


def independent_check(pid: str, data: str, expected: str) -> bool:
    """Separate simple formulation or exhaustive check of the problem condition."""
    x=validate(pid,data)
    s=expected.strip()
    if pid=='abc143_a':
        a,b=x;return s==str(sum(i>=2*b for i in range(a)))
    if pid=='abc143_b':
        return s==str((sum(x)**2-sum(t*t for t in x))//2)
    if pid=='abc152_a':
        n,m=x;return s==('Yes' if n-m==0 else 'No')
    if pid=='abc152_b':
        a,b=x;return s==sorted([str(a)*b,str(b)*a])[0]
    if pid=='abc154_a':
        name1,name2,a,b,u=x
        return s==f'{a-int(u==name1)} {b-int(u==name2)}'
    if pid=='abc154_b':return s=='x'*len(x)
    if pid=='abc200_a':return s==str(-(-x//100))
    if pid=='abc200_b':
        n,k=x
        for _ in range(k):
            if n%200==0:n//=200
            else:n=int(f'{n}200')
        return s==str(n)
    if pid=='abc212_a':
        a,b=x;return s==('Gold' if b==0 else 'Silver' if a==0 else 'Alloy')
    if pid=='abc212_b':
        digits=list(map(int,x));equal=all(z==digits[0] for z in digits)
        sequence=all((digits[i]-digits[i-1])%10==1 for i in range(1,4))
        return s==('Weak' if equal or sequence else 'Strong')
    if pid=='abc231_a':
        # Compare numeric answers, as the original judge accepts multiple formats.
        try:return abs(float(s)-x/100)<=1e-9
        except ValueError:return False
    if pid=='abc231_b':
        votes=Counter(x)
        return s==max(votes, key=votes.get)
    if pid=='abc251_a':return s==x*(6//len(x))
    if pid=='abc251_b':
        w,a=x
        achievable=set()
        # Different *indices*, not necessarily different weight values.
        for k in (1,2,3):
            for picked in combinations(a,k):
                v=sum(picked)
                if v<=w:achievable.add(v)
        return s==str(len(achievable))
    raise AssertionError(pid)
