"""ABC107–109 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc107_b','abc108_b','abc109_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
INT=re.compile(r'-?(?:0|[1-9][0-9]*)', re.ASCII)
LOWER=re.compile(r'[a-z]{1,10}', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc107_b':
        if len(lines)<2 or re.fullmatch(r'[1-9][0-9]* [1-9][0-9]*',lines[0],re.ASCII) is None:
            raise ValueError('header')
        h,w=map(int,lines[0].split())
        if not (1<=h<=100 and 1<=w<=100) or len(lines)!=h+1:
            raise ValueError('shape/range')
        g=lines[1:]
        if any(len(row)!=w or any(ch not in '.#' for ch in row) for row in g) or not any('#' in row for row in g):
            raise ValueError('grid')
        return h,w,g
    if pid=='abc108_b':
        if len(lines)!=1:
            raise ValueError('line count')
        ts=lines[0].split(' ')
        if len(ts)!=4 or any(INT.fullmatch(t) is None for t in ts):
            raise ValueError('format')
        x1,y1,x2,y2=map(int,ts)
        if any(abs(x)>100 for x in (x1,y1,x2,y2)) or (x1,y1)==(x2,y2):
            raise ValueError('range/distinct')
        return x1,y1,x2,y2
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N')
    n=int(lines[0])
    if not 2<=n<=100 or len(lines)!=n+1 or any(LOWER.fullmatch(w) is None for w in lines[1:]):
        raise ValueError('words')
    return lines[1:]

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc107_b':
        h,w,g=value
        rows=[i for i in range(h) if '#' in g[i]]
        cols=[j for j in range(w) if any(g[i][j]=='#' for i in range(h))]
        expected='\n'.join(''.join(g[i][j] for j in cols) for i in rows)
        return output==expected
    if pid=='abc108_b':
        if re.fullmatch(r'-?(?:0|[1-9][0-9]*) -?(?:0|[1-9][0-9]*) -?(?:0|[1-9][0-9]*) -?(?:0|[1-9][0-9]*)',output,re.ASCII) is None:
            return False
        x1,y1,x2,y2=value; dx=x2-x1; dy=y2-y1
        expected=(x2-dy,y2+dx,x1-dy,y1+dx)
        return tuple(map(int,output.split()))==expected
    if output not in ('Yes','No'): return False
    words=value
    ok=len(set(words))==len(words) and all(words[i][-1]==words[i+1][0] for i in range(len(words)-1))
    return output==('Yes' if ok else 'No')

def _grid(rows:list[str])->str:
    return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'

def _words(words:list[str])->str:
    return f'{len(words)}\n'+'\n'.join(words)+'\n'

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc107_b':
        cases=[
          ['#'], ['..#..'], ['.','#','.'], ['##','##'], ['#.','.#'],
          ['##.#','....','##.#','.#.#'], ['#..','.#.','..#'], ['.....','.....','..#..','.....'],
          ['.#..','....','..#.'], ['#....','....#'], ['.#.','###','.#.'], ['....#','.....','#....'],
          ['#.#.#'], ['#','.','#','.','#'], ['###','...','###'], ['....','.#..','....','..#.'],
          ['#..#','....','....','#..#']]
        for g in cases: add('boundary' if len(g)==1 or len(g[0])==1 else 'normal',_grid(g))
        add('constraint_max',_grid(['#'*100 for _ in range(100)]))
    elif pid=='abc108_b':
        vals=[(0,0,0,1),(2,3,6,6),(31,-41,-59,26),(0,0,1,0),(0,0,-1,0),(0,0,0,-1),
              (-100,-100,100,-100),(-100,100,-100,-100),(100,-100,-100,100),(5,5,6,6),(-5,7,-3,2),
              (100,0,99,100),(0,100,-100,99),(-99,-100,100,99),(42,-17,42,83),(-100,1,100,2),(1,-100,2,100)]
        for v in vals: add('boundary' if 100 in map(abs,v) else 'normal',' '.join(map(str,v))+'\n')
        add('constraint_max','100 100 -100 -100\n')
    else:
        cases=[
          ['a','ab'], ['ab','bc'], ['ab','ba','ab'], ['hoge','english','hoge','enigma'],
          ['abc','cde','efg'], ['abc','def'], ['a','a'], ['z','za','az'], ['aa','ab','ba'],
          ['apple','egg','grape'], ['abc','cba','abcx'], ['a','aa','aaa','aaaa'],
          ['ab','bc','ca','ad'], ['x','xy','yz','zx'], ['abc','c','cpp','php','python'],
          ['aa','ab','bb','ba'], ['one','e','eon']]
        for ws in cases: add('boundary' if len(ws)==2 else 'normal',_words(ws))
        max_words=[]
        for i in range(100):
            max_words.append('a'+chr(97+i//26)+chr(97+i%26)+'a')
        add('constraint_max',_words(max_words))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
