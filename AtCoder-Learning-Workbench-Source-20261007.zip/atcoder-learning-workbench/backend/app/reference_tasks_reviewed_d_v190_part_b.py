"""Private reviewed ABC210--215 D tasks with independent integer oracles."""
from __future__ import annotations
from dataclasses import dataclass
from heapq import heappop,heappush,heapify
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(210,216))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
MOD=10**9+7

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a

def valid_tree(n:int,edges:tuple[tuple[int,...],...])->None:
 p=list(range(n));size=[1]*n
 def root(v:int)->int:
  while p[v]!=v:p[v]=p[p[v]];v=p[v]
  return v
 require(len(edges)==n-1,'tree edges')
 for e in edges:
  a,b=e[:2];require(1<=a<=n and 1<=b<=n,'vertices');a=root(a-1);b=root(b-1);require(a!=b,'tree cycle')
  if size[a]<size[b]:a,b=b,a
  p[b]=a;size[a]+=size[b]
 require(size[root(0)]==n,'connected')

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc210_d':
  h,w,c=ints(r[0],3);require(2<=h<=1000 and 2<=w<=1000 and 1<=c<=10**9 and len(r)==h+1,'shape');g=tuple(ints(s,w) for s in r[1:]);require(all(1<=v<=10**9 for row in g for v in row),'A');return c,g
 if pid=='abc211_d':
  n,m=ints(r[0],2);require(2<=n<=200000 and 0<=m<=200000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=a<b<=n for a,b in edges) and len(set(edges))==m,'simple ordered edges');return n,edges
 if pid=='abc212_d':
  q=ints(r[0],1)[0];require(1<=q<=200000 and len(r)==q+1,'Q');queries=tuple(ints(s) for s in r[1:]);active=outputs=0
  for row in queries:
   kind=row[0];require(kind in (1,2,3) and len(row)==(1 if kind==3 else 2),'query shape')
   if kind<3:require(1<=row[1]<=10**9,'X')
   if kind==1:active+=1
   if kind==3:require(active>0,'empty extraction');active-=1;outputs+=1
  require(outputs>=1,'at least one extraction');return (queries,)
 if pid in ('abc213_d','abc214_d'):
  n=ints(r[0],1)[0];require(2<=n<=(200000 if pid=='abc213_d' else 100000) and len(r)==n,'N');edges=tuple(ints(s,2 if pid=='abc213_d' else 3) for s in r[1:]);valid_tree(n,edges)
  if pid=='abc214_d':require(all(1<=e[2]<=10**7 for e in edges),'weight')
  return n,edges
 n,m=ints(r[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=v<=100000 for v in a),'A');return m,a

def railway_transform(c:int,g:tuple[tuple[int,...],...])->int:
 # Separable Manhattan distance transform. Vertical sources exclude the target row;
 # horizontal closure then covers every different-row station. Same-row stations
 # are handled by exclusive one-dimensional transforms, so self-pairs never enter.
 h=len(g);w=len(g[0]);inf=10**30;d=[inf]*(h*w);answer=inf
 for col in range(w):
  best=inf
  for row in range(h):
   at=row*w+col;d[at]=best;best=min(best,g[row][col])+c
  best=inf
  for row in range(h-1,-1,-1):
   at=row*w+col;d[at]=min(d[at],best);best=min(best,g[row][col])+c
 for row,values in enumerate(g):
  distance=d[row*w:(row+1)*w]
  for col in range(1,w):distance[col]=min(distance[col],distance[col-1]+c)
  for col in range(w-2,-1,-1):distance[col]=min(distance[col],distance[col+1]+c)
  best=inf
  for col,a in enumerate(values):answer=min(answer,a+distance[col],a+best);best=min(best,a)+c
  best=inf
  for a in reversed(values):answer=min(answer,a+best);best=min(best,a)+c
 return answer

def paths_dijkstra(n:int,edges:tuple[tuple[int,int],...])->int:
 graph=[[] for _ in range(n)]
 for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
 dist=[n+1]*n;dist[0]=0;heap=[(0,0)];order=[]
 while heap:
  d,v=heappop(heap)
  if d!=dist[v]:continue
  order.append(v)
  for u in graph[v]:
   if d+1<dist[u]:dist[u]=d+1;heappush(heap,(d+1,u))
 ways=[0]*n;ways[0]=1
 for v in order:
  ways[v]%=MOD
  for u in graph[v]:
   if dist[u]==dist[v]+1:ways[u]+=ways[v]
 return ways[-1]%MOD

@dataclass(slots=True)
class LazyTreap:
 key:int
 priority:int
 count:int=1
 lazy:int=0
 left:LazyTreap|None=None
 right:LazyTreap|None=None

def treap_add(t:LazyTreap|None,delta:int)->None:
 if t is not None:t.key+=delta;t.lazy+=delta

def treap_push(t:LazyTreap)->None:
 if t.lazy:treap_add(t.left,t.lazy);treap_add(t.right,t.lazy);t.lazy=0

def treap_insert(t:LazyTreap|None,x:int,priority:int)->LazyTreap:
 if t is None:return LazyTreap(x,priority)
 treap_push(t)
 if x==t.key:t.count+=1;return t
 if x<t.key:
  t.left=treap_insert(t.left,x,priority)
  if t.left.priority<t.priority:
   u=t.left;treap_push(u);t.left=u.right;u.right=t;return u
 else:
  t.right=treap_insert(t.right,x,priority)
  if t.right.priority<t.priority:
   u=t.right;treap_push(u);t.right=u.left;u.left=t;return u
 return t

def treap_extract(t:LazyTreap)->tuple[int,LazyTreap|None]:
 treap_push(t)
 if t.left is not None:value,t.left=treap_extract(t.left);return value,t
 if t.count>1:t.count-=1;return t.key,t
 return t.key,t.right

def multiset_treap(queries:tuple[tuple[int,...],...])->list[int]:
 root:LazyTreap|None=None;out=[];rng=random.Random(212190)
 for row in queries:
  if row[0]==1:root=treap_insert(root,row[1],rng.getrandbits(64))
  elif row[0]==2:treap_add(root,row[1])
  else:
   require(root is not None,'nonempty');value,root=treap_extract(cast(LazyTreap,root));out.append(value)
 return out

def tour_literal_heaps(n:int,edges:tuple[tuple[int,int],...])->list[int]:
 graph=[[] for _ in range(n)]
 for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
 for neighbors in graph:heapify(neighbors)
 visited=[False]*n;parent=[-1]*n;visited[0]=True;v=0;out=[1]
 while True:
  while graph[v] and visited[graph[v][0]]:heappop(graph[v])
  if graph[v]:u=heappop(graph[v]);parent[u]=v;visited[u]=True;v=u
  elif v==0:break
  else:v=parent[v]
  out.append(v+1)
 return out

def maximum_paths_centroid(n:int,edges:tuple[tuple[int,int,int],...])->int:
 graph:list[list[tuple[int,int]]]=[[] for _ in range(n)]
 for a,b,w in edges:graph[a-1].append((b-1,w));graph[b-1].append((a-1,w))
 removed=[False]*n;parent=[-1]*n;sizes=[0]*n;pending=[0];answer=0
 def pair_sum(values:list[int])->int:return sum(i*v for i,v in enumerate(sorted(values)))
 while pending:
  start=pending.pop();parent[start]=-1;order=[start]
  for v in order:
   for u,_ in graph[v]:
    if not removed[u] and u!=parent[v]:parent[u]=v;order.append(u)
  total=len(order);centroid=start
  for v in reversed(order):
   sizes[v]=1;largest=0
   for u,_ in graph[v]:
    if not removed[u] and parent[u]==v:sizes[v]+=sizes[u];largest=max(largest,sizes[u])
   if max(largest,total-sizes[v])<=total//2:centroid=v
  removed[centroid]=True;all_values=[0]
  for u,w in graph[centroid]:
   if removed[u]:continue
   pending.append(u);values=[];stack=[(u,centroid,w)]
   while stack:
    v,p,mx=stack.pop();values.append(mx)
    for child,weight in graph[v]:
     if child!=p and not removed[child]:stack.append((child,v,max(mx,weight)))
   answer-=pair_sum(values);all_values.extend(values)
  answer+=pair_sum(all_values)
 return answer

def coprime_divisor_sieve(m:int,a:tuple[int,...])->list[int]:
 limit=max(max(a),m);present=bytearray(limit+1)
 for x in a:present[x]=1
 prime=bytearray(b'\x01')*(limit+1);prime[0:2]=b'\x00\x00';bad=bytearray(limit+1);spf=list(range(limit+1))
 for p in range(2,limit+1):
  if not prime[p]:continue
  bad[p]=int(any(present[v] for v in range(p,limit+1,p)))
  for multiple in range(p*p,limit+1,p):prime[multiple]=0;spf[multiple]=min(spf[multiple],p)
 out=[]
 for k in range(1,m+1):
  value=k;valid=True
  while value>1:
   p=spf[value]
   if bad[p]:valid=False;break
   while value%p==0:value//=p
  if valid:out.append(k)
 return out

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc210_d':return str(railway_transform(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))+'\n'
 if pid=='abc211_d':return str(paths_dijkstra(cast(int,d[0]),cast(tuple[tuple[int,int],...],d[1])))+'\n'
 if pid=='abc212_d':return ''.join(str(v)+'\n' for v in multiset_treap(cast(tuple[tuple[int,...],...],d[0])))
 if pid=='abc213_d':return line(tour_literal_heaps(cast(int,d[0]),cast(tuple[tuple[int,int],...],d[1])))
 if pid=='abc214_d':return str(maximum_paths_centroid(cast(int,d[0]),cast(tuple[tuple[int,int,int],...],d[1])))+'\n'
 out=coprime_divisor_sieve(cast(int,d[0]),cast(tuple[int,...],d[1]));return str(len(out))+'\n'+''.join(str(v)+'\n' for v in out)

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  expected=oracle(pid,raw);tokens=actual.split();return len(tokens)==len(expected.split()) and all(re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s) is not None for s in tokens) and tuple(map(int,tokens))==tuple(map(int,expected.split()))
 except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc210_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));h=next(it);w=next(it);c=next(it);a=[[next(it) for _ in range(w)] for _ in range(h)];answer=10**30
for reverse in (False,True):
 prev=[10**30]*w
 for row in a:
  if reverse:row=row[::-1]
  cur=[10**30]*w
  for j,x in enumerate(row):
   best=min(prev[j],cur[j-1] if j else 10**30)+c
   answer=min(answer,x+best);cur[j]=min(x,best)
  prev=cur
print(answer)
''',
'abc211_d':'''import sys
from collections import deque
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);g=[[] for _ in range(n)]
for _ in range(m):a=next(it)-1;b=next(it)-1;g[a].append(b);g[b].append(a)
d=[-1]*n;ways=[0]*n;d[0]=0;ways[0]=1;q=deque([0]);mod=10**9+7
while q:
 v=q.popleft()
 for u in g[v]:
  if d[u]<0:d[u]=d[v]+1;q.append(u)
  if d[u]==d[v]+1:ways[u]=(ways[u]+ways[v])%mod
print(ways[-1])
''',
'abc212_d':'''import sys,heapq
it=iter(map(int,sys.stdin.buffer.read().split()));q=next(it);heap=[];offset=0;out=[]
for _ in range(q):
 p=next(it)
 if p==1:heapq.heappush(heap,next(it)-offset)
 elif p==2:offset+=next(it)
 else:out.append(str(heapq.heappop(heap)+offset))
print('\\n'.join(out))
''',
'abc213_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);g=[[] for _ in range(n)]
for _ in range(n-1):a=next(it)-1;b=next(it)-1;g[a].append(b);g[b].append(a)
for row in g:row.sort(reverse=True)
stack=[(0,-1,True)];out=[]
while stack:
 v,p,enter=stack.pop();out.append(str(v+1))
 if enter:
  for u in g[v]:
   if u!=p:stack.append((v,p,False));stack.append((u,v,True))
print(' '.join(out))
''',
'abc214_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);edges=[(next(it)-1,next(it)-1,next(it)) for _ in range(n-1)];parent=list(range(n));size=[1]*n;answer=0
def find(v):
 while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
 return v
for a,b,w in sorted(edges,key=lambda e:e[2]):
 a=find(a);b=find(b)
 if size[a]<size[b]:a,b=b,a
 answer+=w*size[a]*size[b];parent[b]=a;size[a]+=size[b]
print(answer)
''',
'abc215_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);a=[next(it) for _ in range(n)];limit=max(a);spf=list(range(limit+1))
for p in range(2,int(limit**0.5)+1):
 if spf[p]==p:
  for v in range(p*p,limit+1,p):
   if spf[v]==v:spf[v]=p
bad=set()
for x in a:
 while x>1:
  p=spf[x];bad.add(p)
  while x%p==0:x//=p
valid=bytearray(b'\\x01')*(m+1)
for p in bad:
 for v in range(p,m+1,p):valid[v]=0
out=[str(v) for v in range(1,m+1) if valid[v]];print(len(out));print('\\n'.join(out))
'''}

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(190000+int(pid[3:6]));raws:list[str]=[]
 if pid=='abc210_d':
  def grid(c:int,g:list[list[int]])->str:return line((len(g),len(g[0]),c))+''.join(line(row) for row in g)
  raws=[grid(1,[[1,1],[1,1]]),grid(10**9,[[1,10**9],[10**9,1]]),grid(1,[[1,10**9],[10**9,1]]),grid(1,[[9,2],[1,9]]),grid(7,[[99,99,1],[1,99,99]])]
  for i in range(11):
   h=2+i%5;w=2+(i*3)%7;raws.append(grid((1,10**9,17)[i%3],[[rng.randint(1,10**9) for _ in range(w)] for _ in range(h)]))
  raws+=[grid(1,[[1 if (r+c)%2 else 10**9 for c in range(1000)] for r in range(1000)]),grid(10**9,[[10**9]*1000 for _ in range(1000)])]
 elif pid=='abc211_d':
  def graph(n:int,e:list[tuple[int,int]])->str:return line((n,len(e)))+''.join(line(x) for x in e)
  raws=[graph(2,[]),graph(2,[(1,2)]),graph(4,[(1,2),(1,3),(2,4),(3,4)]),graph(5,[(1,2),(2,3),(4,5)]),graph(5,[(1,3),(2,3),(2,4),(4,5)])]
  for i in range(10):
   n=6+i*2;e=[(a,b) for a in range(1,n) for b in range(a+1,n+1) if rng.random()<.2+.05*(i%3)];rng.shuffle(e);raws.append(graph(n,e))
  # Layered graph: 2 choices per level, checks modular path counts.
  layers=70;e=[(1,2),(1,3)]
  for j in range(layers-1):e.extend((a,b) for a in (2+2*j,3+2*j) for b in (4+2*j,5+2*j))
  e.extend([(2*layers,2*layers+2),(2*layers+1,2*layers+2)]);raws.append(graph(2*layers+2,e))
  raws.append(graph(200000,[]));raws.append(graph(200000,[(j,j+1) for j in range(1,200000)]+[(1,200000)]))
 elif pid=='abc212_d':
  def queries(q:list[tuple[int,...]])->str:return str(len(q))+'\n'+''.join(line(x) for x in q)
  raws=[queries([(1,1),(3,)]),queries([(2,10**9),(1,1),(3,)]),queries([(1,1),(2,10**9),(1,1),(3,),(3,)]),queries([(1,5),(1,5),(2,5),(1,5),(3,),(3,),(3,)]),queries([(1,10**9)]+[(2,10**9)]*4+[(3,)])]
  for i in range(10):
   q=[];active=0
   for j in range(10+i*9):
    kind=rng.choice([1,2,3]) if active else rng.choice([1,2])
    if kind==1:q.append((1,rng.randint(1,10**9)));active+=1
    elif kind==2:q.append((2,rng.randint(1,10**9)))
    else:q.append((3,));active-=1
   if not active:q.append((1,1))
   q.append((3,));raws.append(queries(q))
  raws[-1]=queries([(1,10**9)]*95000+[(2,10**9)]*10000+[(3,)]*95000)
  raws.append(queries([(1,10**9)]+[(2,10**9)]*199998+[(3,)]))
  raws.append(queries([(1,j) for j in range(100000,0,-1)]+[(3,)]*100000))
  raws.append(queries([(1,10**9),(3,)]*100000))
 elif pid=='abc213_d':
  def tree(n:int,e:list[tuple[int,int]])->str:return str(n)+'\n'+''.join(line(x) for x in e)
  raws=[tree(2,[(1,2)]),tree(2,[(2,1)]),tree(4,[(1,2),(4,2),(3,1)]),tree(6,[(1,j) for j in range(2,7)])]
  for i in range(12):
   n=5+i*7;e=[(rng.randrange(1,v),v) for v in range(2,n+1)];e=[(b,a) if rng.randrange(2) else (a,b) for a,b in e];rng.shuffle(e);raws.append(tree(n,e))
  raws.append(tree(200000,[(200000,j) for j in range(199999,0,-1)]));raws.append(tree(200000,[(j+1,j) for j in range(1,200000)]))
 elif pid=='abc214_d':
  def tree(n:int,e:list[tuple[int,int,int]])->str:return str(n)+'\n'+''.join(line(x) for x in e)
  raws=[tree(2,[(1,2,1)]),tree(2,[(2,1,10**7)]),tree(3,[(1,2,1),(2,3,10**7)]),tree(6,[(1,j,7) for j in range(2,7)])]
  for i in range(12):
   n=5+i*9;e=[(rng.randrange(1,v),v,rng.choice([1,10**7,rng.randrange(1,10**7)])) for v in range(2,n+1)];e=[(b,a,w) if rng.randrange(2) else (a,b,w) for a,b,w in e];rng.shuffle(e);raws.append(tree(n,e))
  raws.append(tree(100000,[(j//2,j,1+j%997) for j in range(2,100001)]));raws.append(tree(100000,[(j+1,j,10**7) for j in range(1,100000)]))
 else:
  def array(m:int,a:list[int])->str:return line((len(a),m))+line(a)
  raws=[array(1,[1]),array(1,[100000]),array(100,[1]),array(12,[6,1,5]),array(100,[99991,99991]),array(100,[2,3,5,7])]
  for i in range(10):raws.append(array(20+i*17,[rng.randint(1,100000) for _ in range(2+i*9)]))
  raws.append(array(100000,[1]*100000));raws.append(array(100000,[100000]*100000))
 require(len(raws)==len(set(raws))==18,'18 distinct')
 cases=[]
 for i,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'reviewed_{i:02d}'})
 return cases

TITLES={'abc210_d': 'National Railway',
 'abc211_d': 'Number of Shortest paths',
 'abc212_d': 'Querying Multiset',
 'abc213_d': 'Takahashi Tour',
 'abc214_d': 'Sum of Maximum Weights',
 'abc215_d': 'Coprime 2'}
PUBLISHED_SAMPLES={'abc210_d': [{'input': '3 4 2\n1 7 7 9\n9 6 3 7\n7 8 6 4\n', 'expected': '10\n'},
              {'input': '3 3 1000000000\n'
                        '1000000 1000000 1\n'
                        '1000000 1000000 1000000\n'
                        '1 1000000 1000000\n',
               'expected': '1001000001\n'}],
 'abc211_d': [{'input': '4 5\n2 4\n1 2\n2 3\n1 3\n3 4\n', 'expected': '2\n'},
              {'input': '4 3\n1 3\n2 3\n2 4\n', 'expected': '1\n'},
              {'input': '2 0\n', 'expected': '0\n'},
              {'input': '7 8\n1 3\n1 4\n2 3\n2 4\n2 5\n2 6\n5 7\n6 7\n', 'expected': '4\n'}],
 'abc212_d': [{'input': '5\n1 3\n1 5\n3\n2 2\n3\n', 'expected': '3\n7\n'},
              {'input': '6\n'
                        '1 1000000000\n'
                        '2 1000000000\n'
                        '2 1000000000\n'
                        '2 1000000000\n'
                        '2 1000000000\n'
                        '3\n',
               'expected': '5000000000\n'}],
 'abc213_d': [{'input': '4\n1 2\n4 2\n3 1\n', 'expected': '1 2 4 2 1 3 1\n'},
              {'input': '5\n1 2\n1 3\n1 4\n1 5\n', 'expected': '1 2 1 3 1 4 1 5 1\n'}],
 'abc214_d': [{'input': '3\n1 2 10\n2 3 20\n', 'expected': '50\n'},
              {'input': '5\n1 2 1\n2 3 2\n4 2 5\n3 5 14\n', 'expected': '76\n'}],
 'abc215_d': [{'input': '3 12\n6 1 5\n', 'expected': '3\n1\n7\n11\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
HINTS={'abc210_d': ('駅を建てる2マスは異なる必要があります。マンハッタン距離を行方向と列方向に分けて考えましょう。',
              '一方の駅が現在のマスより上かつ左にある場合、駅費用に座標の項を足し引きして最小値を引き継げます。列を反転した走査も行うと反対側を覆えます。',
              '疑似コード: answer=無限大。通常列順と反転列順の各走査で、best=min(上の状態,左の状態)+C; answer=min(answer,A+best); '
              'state=min(A,best)。現在のAを候補に入れる前に比較して同じ駅の重複を防ぐ。'),
 'abc211_d': ('全ての道路の所要時間は1です。最短距離を求めると、最短経路が使える辺もわかります。',
              'BFSで距離と経路数を管理します。隣の距離が現在の距離+1であるときだけ経路数を足しましょう。',
              '疑似コード: '
              'dist[1]=0,ways[1]=1,queue=[1]。vを取り出し、未訪問uのdistをdist[v]+1にしてqueueへ。dist[u]==dist[v]+1ならways[u]=(ways[u]+ways[v]) '
              'mod 1000000007。ways[N]を出力。'),
 'abc212_d': ('全てのボールに同じ値を加えても、袋内の大小関係は変わりません。',
              '全体加算の累積値と最小ヒープを分けて持ちます。新しく入れるボールには過去の加算が作用しない点に注意しましょう。',
              '疑似コード: offset=0,heap=空。操作1 XならheapへX-offsetを追加。操作2 '
              'Xならoffset+=X。操作3ならheap最小値を取り出しoffsetを足して出力。64ビットを超えない範囲でも32ビット整数には収まらない。'),
 'abc213_d': ('道路数がN-1で連結なので、グラフは木です。未訪問の隣へ進み、行き止まりで親に戻る動きを考えましょう。',
              '隣接頂点を番号順に処理する深さ優先探索になります。行きに加え、子の探索から戻った親も出力に入れます。',
              '疑似コード: '
              '隣接リストを昇順に整列。visit(v,parent)でvを出力し、各u!=parentについてvisit(u,v)の後にvを出力。深い木に備えて明示スタックの入場・帰還イベントで実装。'),
 'abc214_d': ('木の2頂点間の道は一意です。その道の最大辺が初めて使える時点を考えてください。',
              '辺を軽い順に追加すると、2つの成分をつなぐ重みwの辺が新しく結ぶ頂点対は、両成分のサイズの積だけあります。',
              '疑似コード: 全頂点を単独成分にする。辺を重み昇順に処理し、両端の成分サイズs,tを取得、answer+=w*s*t、成分を併合。同じ重みの辺も順に処理してよい。'),
 'abc215_d': ('あるAとkが共通の素因数を持つとき、最大公約数は1になりません。',
              'Aのいずれかを割る素数を集め、その素数の倍数を1からMの候補から除きます。A=1は何も除外しません。',
              '疑似コード: '
              '各Aを素因数分解して禁止素数集合へ。valid[1..M]=true。禁止素数pのp,2p,...<=Mをfalseにする。残った個数を出力し、残った数を昇順で各行に出力。')}
