"""Six reviewed C tasks: bulk jewel conversions, cycle peeling and diagonal intersection."""
from __future__ import annotations
from collections import deque
from itertools import combinations
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (260,262,263,264,265,266))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Point=tuple[int,int]
Matrix=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def cross(a:Point,b:Point,c:Point)->int:return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def proper_intersection(a:Point,b:Point,c:Point,d:Point)->bool:return cross(a,b,c)*cross(a,b,d)<0 and cross(c,d,a)*cross(c,d,b)<0
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==260:
        require(len(rows)==1,'shape');n,x,y=ints(rows[0],3);require(1<=n<=10 and 1<=x<=5 and 1<=y<=5,'jewels');return n,x,y
    if number==262:
        n=ints(rows[0],1)[0];require(2<=n<=500000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=n for v in a),'mapping');return (a,)
    if number==263:
        require(len(rows)==1,'shape');n,m=ints(rows[0],2);require(1<=n<=m<=10,'sequence');return n,m
    if number==264:
        h,w=ints(rows[0],2);require(1<=h<=10 and 1<=w<=10 and len(rows)>=h+3,'shape');a=tuple(ints(row,w) for row in rows[1:h+1]);bh,bw=ints(rows[h+1],2);require(1<=bh<=h and 1<=bw<=w and len(rows)==h+bh+2,'target');b=tuple(ints(row,bw) for row in rows[h+2:]);require(all(1<=v<=10**9 for matrix in (a,b) for row in matrix for v in row),'values');return a,b
    if number==265:
        h,w=ints(rows[0],2);require(1<=h<=500 and 1<=w<=500 and len(rows)==h+1 and all(len(row)==w and set(row)<={'U','D','L','R'} for row in rows[1:]),'arrows');return (tuple(rows[1:]),)
    require(len(rows)==4,'shape');points=tuple(cast(Point,ints(row,2)) for row in rows);require(len(set(points))==4 and all(-100<=v<=100 for point in points for v in point) and all(cross(a,b,c)!=0 for a,b,c in combinations(points,3)),'vertices');a,b,c,d=points;require(not proper_intersection(a,b,c,d) and not proper_intersection(b,c,d,a) and sum(points[j][0]*points[(j+1)%4][1]-points[j][1]*points[(j+1)%4][0] for j in range(4))>0,'simple counterclockwise');return (points,)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==260:
        n,x,y=cast(tuple[int,int,int],data);red=[0]*(n+1);blue=[0]*(n+1);red[n]=1
        for level in range(n,1,-1):red[level-1]+=red[level];blue[level]+=red[level]*x;red[level-1]+=blue[level];blue[level-1]+=blue[level]*y
        return str(blue[1])
    if number==262:
        a=cast(tuple[int,...],data[0]);degree=[0]*len(a)
        for target in a:degree[target-1]+=1
        pending=deque(j for j,d in enumerate(degree) if d==0)
        while pending:
            target=a[pending.popleft()]-1;degree[target]-=1
            if degree[target]==0:pending.append(target)
        fixed=twocycles=0
        for start in range(len(a)):
            if not degree[start]:continue
            length=0;j=start
            while degree[j]:degree[j]=0;length+=1;j=a[j]-1
            fixed+=length==1;twocycles+=length==2
        return str(fixed*(fixed-1)//2+twocycles)
    if number==263:
        n,m=cast(tuple[int,int],data);sequences=sorted(tuple(j+1 for j in range(m) if mask>>j&1) for mask in range(1<<m) if mask.bit_count()==n);return '\n'.join(' '.join(map(str,row)) for row in sequences)
    if number==264:
        a,b=cast(tuple[Matrix,Matrix],data);w=len(a[0]);width=len(b[0])
        for mask in range(1<<w):
            if mask.bit_count()!=width:continue
            columns=[j for j in range(w) if mask>>j&1];matched=0
            for row in a:
                if tuple(row[j] for j in columns)==b[matched]:matched+=1
                if matched==len(b):return 'Yes'
        return 'No'
    if number==265:
        grid=cast(tuple[str,...],data[0]);h=len(grid);w=len(grid[0]);directions={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}
        def following(index:int)->int:
            if index==-1:return -1
            r,c=divmod(index,w);dr,dc=directions[grid[r][c]];r+=dr;c+=dc;return r*w+c if 0<=r<h and 0<=c<w else -1
        slow=following(0);fast=following(following(0))
        while slow!=-1 and fast!=-1 and slow!=fast:slow=following(slow);fast=following(following(fast))
        if slow!=-1 and fast!=-1:return '-1'
        index=0
        while following(index)!=-1:index=following(index)
        r,c=divmod(index,w);return f'{r+1} {c+1}'
    a,b,c,d=cast(tuple[Point,...],data[0]);return 'Yes' if proper_intersection(a,c,b,d) else 'No'

def _canonical_263(actual:str)->str:return '\n'.join(row.rstrip(' \t') for row in actual.removesuffix('\n').split('\n'))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return (_canonical_263(actual) if pid=='abc263_c' else actual.removesuffix('\n'))==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc263_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc260_c':"n,x,y=map(int,input().split());red=0;blue=1\nfor _ in range(2,n+1):newblue=red+y*blue;red=red+x*newblue;blue=newblue\nprint(red)\n",
'abc262_c':"n=int(input());a=list(map(int,input().split()));fixed=sum(v==j for j,v in enumerate(a,1));answer=fixed*(fixed-1)//2\nfor i,v in enumerate(a,1):\n if i<v and a[v-1]==i:answer+=1\nprint(answer)\n",
'abc263_c':"from itertools import combinations\nn,m=map(int,input().split())\nfor row in combinations(range(1,m+1),n):print(*row)\n",
'abc264_c':"from itertools import combinations\nh,w=map(int,input().split());a=[list(map(int,input().split())) for _ in range(h)];bh,bw=map(int,input().split());b=[list(map(int,input().split())) for _ in range(bh)];answer=False\nfor rows in combinations(range(h),bh):\n for columns in combinations(range(w),bw):\n  if [[a[r][c] for c in columns] for r in rows]==b:answer=True\nprint('Yes' if answer else 'No')\n",
'abc265_c':"h,w=map(int,input().split());s=[input() for _ in range(h)];r=c=0;seen=set();directions={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}\nwhile (r,c) not in seen:\n seen.add((r,c));dr,dc=directions[s[r][c]];nr,nc=r+dr,c+dc\n if not(0<=nr<h and 0<=nc<w):print(r+1,c+1);break\n r,c=nr,nc\nelse:print(-1)\n",
'abc266_c':"p=[tuple(map(int,input().split())) for _ in range(4)];answer=True\nfor j in range(4):\n a,b,c=[p[(j+k)%4] for k in range(3)];answer&=(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])>0\nprint('Yes' if answer else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16700+number)
    if number==260:raws=[line(v) for v in ((1,1,1),(1,5,5),(2,1,1),(2,3,4),(3,1,5),(3,5,1),(4,2,3),(4,3,2),(5,2,2),(5,4,4),(6,1,1),(6,5,5),(7,3,4),(8,4,3),(9,1,5),(9,5,1),(10,1,1),(10,5,5))]
    elif number==262:
        def mapping(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[mapping([1,1]),mapping([1,2]),mapping([2,1]),mapping([2,3,1])]
        for n in range(4,16):raws.append(mapping([rng.randint(1,n) for _ in range(n)]))
        raws.extend([mapping([j+2 if j%2==0 else j for j in range(500000)]),mapping(list(range(1,500001)))])
    elif number==263:raws=[line(v) for v in ((1,1),(1,2),(2,2),(1,3),(2,3),(3,3),(2,4),(3,4),(2,5),(3,5),(4,5),(3,6),(4,7),(4,8),(4,9),(1,10),(5,10),(10,10))]
    elif number==264:
        def matrix(a:list[list[int]],b:list[list[int]])->str:return f'{len(a)} {len(a[0])}\n'+''.join(line(row) for row in a)+f'{len(b)} {len(b[0])}\n'+''.join(line(row) for row in b)
        raws=[matrix([[1]],[[1]]),matrix([[1]],[[2]]),matrix([[1,2],[3,4]],[[4]]),matrix([[1,2],[3,4]],[[2,1]])]
        for n in range(2,14):
            h=2+n%9;w=2+(n*3)%9;a=[[rng.randint(1,100) for _ in range(w)] for _ in range(h)];rows=sorted(rng.sample(range(h),max(1,h//2)));cols=sorted(rng.sample(range(w),max(1,w//2)));b=[[a[r][c] for c in cols] for r in rows]
            if n%3==0:b[0][0]=1000
            raws.append(matrix(a,b))
        raws.extend([matrix([[1]*10 for _ in range(10)],[[2]*5 for _ in range(5)]),matrix([[10**9]*10 for _ in range(10)],[[10**9]*10 for _ in range(10)])])
    elif number==265:
        def arrows(a:list[str])->str:return f'{len(a)} {len(a[0])}\n'+'\n'.join(a)+'\n'
        raws=[arrows(['U']),arrows(['D']),arrows(['RL']),arrows(['RR'])]
        for n in range(2,14):raws.append(arrows([''.join(rng.choice('UDLR') for _ in range(n)) for _ in range(n+1)]))
        snake=['R'*499+'D' if r%2==0 else 'D'+'L'*499 for r in range(500)];cycle=snake.copy();cycle[-1]='U'+'L'*499;raws.extend([arrows(cycle),arrows(snake)])
    else:
        def quad(p:list[Point])->str:return ''.join(line(v) for v in p)
        raws=[quad([(-100,-100),(-99,-100),(-99,-99),(-100,-99)]),quad([(0,0),(1,0),(1,1),(0,1)]),quad([(0,0),(1,1),(-1,0),(1,-1)]),quad([(-2,-1),(3,-1),(3,2),(-2,2)])]
        for size in range(2,14):raws.append(quad([(0,0),(size,0),(size,size+1),(0,size+1)]))
        raws.extend([quad([(0,0),(100,100),(-100,0),(100,-100)]),quad([(-100,-100),(100,-100),(100,100),(-100,100)])])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc260_c':('各レベルの赤・青一個から得られる、レベル1の青の個数を考えます。','レベル1の赤は0、青は1です。次の青は前の赤+Y×前の青、次の赤は前の赤+X×次の青です。','疑似コード: red=0; blue=1; repeat levels2..N: next_blue=red+Y*blue; red=red+X*next_blue; blue=next_blue; print(red)。'),
'abc262_c':('条件を満たすのは、二つとも自分の番号を持つ場合か、互いの番号を持つ場合です。','固定点の数fからf*(f-1)/2を加えます。残りはa[i]=jかつa[j]=iを、i<jのときだけ数えます。','疑似コード: f=count a[i]==i; answer=f*(f-1)/2; for i: j=a[i]; if i<j and a[j]==i: answer+=1; print(answer)。'),
'abc263_c':('1からMのうちN個を選ぶ組合せが、そのまま増加列です。','組合せを辞書順に列挙して、一行ずつ出力します。','疑似コード: for sequence in combinations(1..M,N): print elements separated by spaces。'),
'abc264_c':('残す行と列を選べば、削除後の行列が決まります。','H2個の行とW2個の列の組合せを全て試し、その部分行列がBと一致するか確認します。順番は変えられません。','疑似コード: for rows in combinations(H1,H2): for cols in combinations(W1,W2): if A[rows][cols]==B: Yes; if none: No。'),
'abc265_c':('同じマスを二度訪れたら、その後も同じ動きを繰り返します。','訪問済み集合を持って矢印に従います。次のマスが盤面外なら現在位置、再訪なら-1を出力します。','疑似コード: current=(1,1); seen=set(); while current not seen: seen.add(current); next=arrow_neighbor(current); if next outside: print(current); stop; current=next; print(-1) on revisit。'),
'abc266_c':('各頂点で同じ方向へ曲がっているかを調べます。','公式の反時計回りの単純四角形では、凸なら連続する二辺の外積が全て正です。整数演算で符号を調べます。','疑似コード: for i=0..3: require cross(P[i],P[(i+1)%4],P[(i+2)%4])>0; print(Yes if all else No)。')}

TITLES={'abc260_c': 'Changing Jewels', 'abc262_c': 'Min Max Pair', 'abc263_c': 'Monotonically Increasing', 'abc264_c': 'Matrix Reducing', 'abc265_c': 'Belt Conveyor', 'abc266_c': 'Convex Quadrilateral'}
PUBLISHED_SAMPLES={'abc260_c': [{'input': '2 3 4\n', 'expected': '12\n'}, {'input': '1 5 5\n', 'expected': '0\n'}, {'input': '10 5 5\n', 'expected': '3942349900\n'}], 'abc262_c': [{'input': '4\n1 3 2 4\n', 'expected': '2\n'}, {'input': '10\n5 8 2 2 1 6 7 2 9 10\n', 'expected': '8\n'}], 'abc263_c': [{'input': '2 3\n', 'expected': '1 2 \n1 3 \n2 3 \n'}, {'input': '3 5\n', 'expected': '1 2 3 \n1 2 4 \n1 2 5 \n1 3 4 \n1 3 5 \n1 4 5 \n2 3 4 \n2 3 5 \n2 4 5 \n3 4 5 \n'}], 'abc264_c': [{'input': '4 5\n1 2 3 4 5\n6 7 8 9 10\n11 12 13 14 15\n16 17 18 19 20\n2 3\n6 8 9\n16 18 19\n', 'expected': 'Yes\n'}, {'input': '3 3\n1 1 1\n1 1 1\n1 1 1\n1 1\n2\n', 'expected': 'No\n'}], 'abc265_c': [{'input': '2 3\nRDU\nLRU\n', 'expected': '1 3\n'}, {'input': '2 3\nRRD\nULL\n', 'expected': '-1\n'}, {'input': '9 44\nRRDDDDRRRDDDRRRRRRDDDRDDDDRDDRDDDDDDRRDRRRRR\nRRRDLRDRDLLLLRDRRLLLDDRDLLLRDDDLLLDRRLLLLLDD\nDRDLRLDRDLRDRLDRLRDDLDDLRDRLDRLDDRLRRLRRRDRR\nDDLRRDLDDLDDRLDDLDRDDRDDDDRLRRLRDDRRRLDRDRDD\nRDLRRDLRDLLLLRRDLRDRRDRRRDLRDDLLLLDDDLLLLRDR\nRDLLLLLRDLRDRLDDLDDRDRRDRLDRRRLDDDLDDDRDDLDR\nRDLRRDLDDLRDRLRDLDDDLDDRLDRDRDLDRDLDDLRRDLRR\nRDLDRRLDRLLLLDRDRLLLRDDLLLLLRDRLLLRRRRLLLDDR\nRRRRDRDDRRRDDRDDDRRRDRDRDRDRRRRRRDDDRDDDDRRR\n', 'expected': '9 5\n'}], 'abc266_c': [{'input': '0 0\n1 0\n1 1\n0 1\n', 'expected': 'Yes\n'}, {'input': '0 0\n1 1\n-1 0\n1 -1\n', 'expected': 'No\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
