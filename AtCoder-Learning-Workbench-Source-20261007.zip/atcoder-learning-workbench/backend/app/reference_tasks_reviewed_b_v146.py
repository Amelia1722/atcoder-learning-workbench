"""Turn 123: 18 real B tasks (ABC321 B through ABC338 B).

Public AtCoder statements, constraints, and all published samples were manually reviewed.
Official HTML is not archived/authenticated; these entries therefore remain full_size=False.
"""
from __future__ import annotations

import re
from itertools import product

TASKS = tuple(f"abc{i}_b" for i in range(321, 339))
LANES = {
    "A": ("abc321_b", "abc322_b", "abc323_b"),
    "B": ("abc324_b", "abc325_b", "abc326_b"),
    "C": ("abc327_b", "abc328_b", "abc329_b"),
    "D": ("abc330_b", "abc331_b", "abc332_b"),
    "E": ("abc333_b", "abc334_b", "abc335_b"),
    "F": ("abc336_b", "abc337_b", "abc338_b"),
}
TITLES = {
    "abc321_b": "Cutoff",
    "abc322_b": "Prefix and Suffix",
    "abc323_b": "Round-Robin Tournament",
    "abc324_b": "3-smooth Numbers",
    "abc325_b": "World Meeting",
    "abc326_b": "326-like Numbers",
    "abc327_b": "A^A",
    "abc328_b": "11/11",
    "abc329_b": "Next",
    "abc330_b": "Minimize Abs 1",
    "abc331_b": "Buy One Carton of Milk",
    "abc332_b": "Glass and Mug",
    "abc333_b": "Pentagon",
    "abc334_b": "Christmas Trees",
    "abc335_b": "Tetrahedral Number",
    "abc336_b": "CTZ",
    "abc337_b": "Extended ABC",
    "abc338_b": "Frequency",
}
INT = re.compile(r"(?:0|[1-9][0-9]*)", re.ASCII)
SINT = re.compile(r"(?:0|-?[1-9][0-9]*)", re.ASCII)
LOWER = re.compile(r"[a-z]+", re.ASCII)
ABC = re.compile(r"[ABC]+", re.ASCII)

PUBLISHED_SAMPLES = {
    "abc321_b": [
        {"input":"5 180\n40 60 80 50\n","expected":"70\n"},
        {"input":"3 100\n100 100\n","expected":"0\n"},
        {"input":"5 200\n0 0 99 99\n","expected":"-1\n"},
        {"input":"10 480\n59 98 88 54 70 24 8 94 46\n","expected":"45\n"},
    ],
    "abc322_b": [
        {"input":"3 7\nabc\nabcdefg\n","expected":"1\n"},
        {"input":"3 4\nabc\naabc\n","expected":"2\n"},
        {"input":"3 3\nabc\nxyz\n","expected":"3\n"},
        {"input":"3 3\naaa\naaa\n","expected":"0\n"},
    ],
    "abc323_b": [
        {"input":"3\n-xx\no-x\noo-\n","expected":"3 2 1\n"},
        {"input":"7\n-oxoxox\nx-xxxox\noo-xoox\nxoo-ooo\nooxx-ox\nxxxxx-x\noooxoo-\n","expected":"4 7 3 1 5 2 6\n"},
    ],
    "abc324_b": [
        {"input":"324\n","expected":"Yes\n"},
        {"input":"5\n","expected":"No\n"},
        {"input":"32\n","expected":"Yes\n"},
        {"input":"37748736\n","expected":"Yes\n"},
    ],
    "abc325_b": [
        {"input":"3\n5 0\n3 3\n2 18\n","expected":"8\n"},
        {"input":"2\n1 10\n1000000 20\n","expected":"1000000\n"},
        {"input":"6\n31 3\n20 8\n11 5\n4 3\n47 14\n1 18\n","expected":"67\n"},
    ],
    "abc326_b": [
        {"input":"320\n","expected":"326\n"},
        {"input":"144\n","expected":"144\n"},
        {"input":"516\n","expected":"600\n"},
    ],
    "abc327_b": [
        {"input":"27\n","expected":"3\n"},
        {"input":"100\n","expected":"-1\n"},
        {"input":"10000000000\n","expected":"10\n"},
    ],
    "abc328_b": [
        {"input":"12\n31 29 31 30 31 30 31 31 30 31 30 31\n","expected":"13\n"},
        {"input":"10\n10 1 2 3 4 5 6 7 8 100\n","expected":"1\n"},
        {"input":"30\n73 8 55 26 97 48 37 47 35 55 5 17 62 2 60 23 99 73 34 75 7 46 82 84 29 41 32 31 52 32\n","expected":"15\n"},
    ],
    "abc329_b": [
        {"input":"5\n2 1 3 3 2\n","expected":"2\n"},
        {"input":"4\n4 3 2 1\n","expected":"3\n"},
        {"input":"8\n22 22 18 16 22 18 18 22\n","expected":"18\n"},
    ],
    "abc330_b": [
        {"input":"5 4 7\n3 1 4 9 7\n","expected":"4 4 4 7 7\n"},
        {"input":"3 10 10\n11 10 9\n","expected":"10 10 10\n"},
    ],
    "abc331_b": [
        {"input":"16 120 150 200\n","expected":"300\n"},
        {"input":"10 100 50 10\n","expected":"10\n"},
        {"input":"99 600 800 1200\n","expected":"10000\n"},
    ],
    "abc332_b": [
        {"input":"5 300 500\n","expected":"200 500\n"},
        {"input":"5 100 200\n","expected":"0 0\n"},
    ],
    "abc333_b": [
        {"input":"AC\nEC\n","expected":"Yes\n"},
        {"input":"DA\nEA\n","expected":"No\n"},
        {"input":"BD\nBD\n","expected":"Yes\n"},
    ],
    "abc334_b": [
        {"input":"5 3 -1 6\n","expected":"3\n"},
        {"input":"-2 2 1 1\n","expected":"0\n"},
        {"input":"-177018739841739480 2436426 -80154573737296504 585335723211047198\n","expected":"273142010859\n"},
    ],
    "abc335_b": [
        {"input":"3\n","expected":"0 0 0\n0 0 1\n0 0 2\n0 0 3\n0 1 0\n0 1 1\n0 1 2\n0 2 0\n0 2 1\n0 3 0\n1 0 0\n1 0 1\n1 0 2\n1 1 0\n1 1 1\n1 2 0\n2 0 0\n2 0 1\n2 1 0\n3 0 0\n"},
        {"input":"4\n","expected":"0 0 0\n0 0 1\n0 0 2\n0 0 3\n0 0 4\n0 1 0\n0 1 1\n0 1 2\n0 1 3\n0 2 0\n0 2 1\n0 2 2\n0 3 0\n0 3 1\n0 4 0\n1 0 0\n1 0 1\n1 0 2\n1 0 3\n1 1 0\n1 1 1\n1 1 2\n1 2 0\n1 2 1\n1 3 0\n2 0 0\n2 0 1\n2 0 2\n2 1 0\n2 1 1\n2 2 0\n3 0 0\n3 0 1\n3 1 0\n4 0 0\n"},
    ],
    "abc336_b": [
        {"input":"2024\n","expected":"3\n"},
        {"input":"18\n","expected":"1\n"},
        {"input":"5\n","expected":"0\n"},
    ],
    "abc337_b": [
        {"input":"AAABBBCCCCCCC\n","expected":"Yes\n"},
        {"input":"ACABABCBC\n","expected":"No\n"},
        {"input":"A\n","expected":"Yes\n"},
        {"input":"ABBBBBBBBBBBBBCCCCCC\n","expected":"Yes\n"},
    ],
    "abc338_b": [
        {"input":"frequency\n","expected":"e\n"},
        {"input":"atcoder\n","expected":"a\n"},
        {"input":"pseudopseudohypoparathyroidism\n","expected":"o\n"},
    ],
}
SAMPLE_COUNTS = {pid: len(rows) for pid, rows in PUBLISHED_SAMPLES.items()}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith("\n") or "\r" in raw:
        raise ValueError("noncanonical")
    body = raw[:-1]
    if body.endswith("\n"):
        raise ValueError("extra blank")
    return body.split("\n")


def _ints(line: str, *, signed: bool = False) -> list[int]:
    parts = line.split(" ")
    pat = SINT if signed else INT
    if not parts or any(pat.fullmatch(x) is None for x in parts) or " ".join(parts) != line:
        raise ValueError("integer line")
    return [int(x) for x in parts]


def _validate321(raw):
    lines = _canonical_lines(raw)
    if len(lines) != 2: raise ValueError("shape")
    nx = _ints(lines[0]); a = _ints(lines[1])
    if len(nx) != 2: raise ValueError("shape")
    n, x = nx
    if not (3 <= n <= 100 and 0 <= x <= 100*(n-2)) or len(a) != n-1 or any(not 0 <= v <= 100 for v in a):
        raise ValueError("constraints")
    return n, x, tuple(a)


def _validate322(raw):
    lines = _canonical_lines(raw)
    if len(lines) != 3: raise ValueError("shape")
    nm = _ints(lines[0])
    if len(nm) != 2: raise ValueError("shape")
    n, m = nm; s, t = lines[1], lines[2]
    if not (1 <= n <= m <= 100) or len(s) != n or len(t) != m or LOWER.fullmatch(s) is None or LOWER.fullmatch(t) is None:
        raise ValueError("constraints")
    return n, m, s, t


def _validate323(raw):
    lines = _canonical_lines(raw); h = _ints(lines[0]) if lines else []
    if len(h) != 1 or not 2 <= h[0] <= 100 or len(lines) != h[0]+1: raise ValueError("N")
    n = h[0]; s = tuple(lines[1:])
    for i, row in enumerate(s):
        if len(row) != n: raise ValueError("row length")
        for j, ch in enumerate(row):
            if i == j:
                if ch != '-': raise ValueError("diagonal")
            elif ch not in 'ox': raise ValueError("result char")
    for i in range(n):
        for j in range(i+1, n):
            if (s[i][j], s[j][i]) not in (("o","x"),("x","o")): raise ValueError("inconsistent match")
    return n, s


def _validate324(raw):
    lines = _canonical_lines(raw); a = _ints(lines[0]) if len(lines)==1 else []
    if len(a) != 1 or not 1 <= a[0] <= 10**18: raise ValueError("N")
    return (a[0],)


def _validate325(raw):
    lines = _canonical_lines(raw); h = _ints(lines[0]) if lines else []
    if len(h) != 1 or not 1 <= h[0] <= 1000 or len(lines) != h[0]+1: raise ValueError("N")
    rows=[]
    for line in lines[1:]:
        a=_ints(line)
        if len(a)!=2 or not 1<=a[0]<=10**6 or not 0<=a[1]<24: raise ValueError("base")
        rows.append(tuple(a))
    return h[0], tuple(rows)


def _validate326(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0]) if len(lines)==1 else []
    if len(a)!=1 or not 100<=a[0]<=919: raise ValueError("N")
    return (a[0],)


def _validate327(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0]) if len(lines)==1 else []
    if len(a)!=1 or not 1<=a[0]<=10**18: raise ValueError("B")
    return (a[0],)


def _validate328(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=2: raise ValueError("shape")
    h=_ints(lines[0]); d=_ints(lines[1])
    if len(h)!=1 or not 1<=h[0]<=100 or len(d)!=h[0] or any(not 1<=x<=100 for x in d): raise ValueError("calendar")
    return h[0], tuple(d)


def _validate329(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=2: raise ValueError("shape")
    h=_ints(lines[0]); a=_ints(lines[1])
    if len(h)!=1 or not 2<=h[0]<=100 or len(a)!=h[0] or any(not 1<=x<=100 for x in a) or len(set(a))<2: raise ValueError("A")
    return h[0], tuple(a)


def _validate330(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=2: raise ValueError("shape")
    nlr=_ints(lines[0]); a=_ints(lines[1])
    if len(nlr)!=3: raise ValueError("shape")
    n,l,r=nlr
    if not (1<=n<=2*10**5 and 1<=l<=r<=10**9) or len(a)!=n or any(not 1<=x<=10**9 for x in a): raise ValueError("constraints")
    return n,l,r,tuple(a)


def _validate331(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0]) if len(lines)==1 else []
    if len(a)!=4: raise ValueError("shape")
    n,s,m,l=a
    if not 1<=n<=100 or any(not 1<=x<=10**4 for x in (s,m,l)): raise ValueError("constraints")
    return n,s,m,l


def _validate332(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0]) if len(lines)==1 else []
    if len(a)!=3: raise ValueError("shape")
    k,g,m=a
    if not (1<=k<=100 and 1<=g<m<=1000): raise ValueError("constraints")
    return k,g,m


def _validate333(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=2: raise ValueError("shape")
    for s in lines:
        if len(s)!=2 or any(c not in "ABCDE" for c in s) or s[0]==s[1]: raise ValueError("segment")
    return lines[0], lines[1]


def _validate334(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0], signed=True) if len(lines)==1 else []
    if len(a)!=4: raise ValueError("shape")
    A,M,L,R=a
    if not (-10**18<=A<=10**18 and 1<=M<=10**9 and -10**18<=L<=R<=10**18): raise ValueError("constraints")
    return A,M,L,R


def _validate335(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0]) if len(lines)==1 else []
    if len(a)!=1 or not 0<=a[0]<=21: raise ValueError("N")
    return (a[0],)


def _validate336(raw):
    lines=_canonical_lines(raw); a=_ints(lines[0]) if len(lines)==1 else []
    if len(a)!=1 or not 1<=a[0]<=10**9: raise ValueError("N")
    return (a[0],)


def _validate337(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1 or not 1<=len(lines[0])<=100 or ABC.fullmatch(lines[0]) is None: raise ValueError("S")
    return (lines[0],)


def _validate338(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1 or not 1<=len(lines[0])<=1000 or LOWER.fullmatch(lines[0]) is None: raise ValueError("S")
    return (lines[0],)


def validate(pid: str, raw: str):
    if pid not in TASKS: raise ValueError("unknown task")
    return globals()[f"_validate{pid[3:6]}"](raw)


def _oracle321(n,x,a):
    s=sum(a); lo=min(a); hi=max(a)
    if s-hi >= x: return 0
    need=x-(s-lo-hi)
    return need if lo <= need <= hi and 0 <= need <= 100 else -1


def _oracle322(n,m,s,t):
    pre=all(s[i]==t[i] for i in range(n))
    suf=all(s[i]==t[m-n+i] for i in range(n))
    return 0 if pre and suf else 1 if pre else 2 if suf else 3


def _oracle323(n,s):
    wins=[0]*n
    for i in range(n):
        for j in range(i+1,n):
            if s[i][j]=='o': wins[i]+=1
            else: wins[j]+=1
    return sorted(range(1,n+1), key=lambda i:(-wins[i-1],i))


def _oracle324(n):
    p2=1
    while p2<=n:
        p3=1
        while p2*p3<n: p3*=3
        if p2*p3==n:return True
        p2*=2
    return False


def _oracle325(n,rows):
    score=[0]*24
    for w,x in rows:
        for local_start in range(9,18):
            score[(local_start-x)%24]+=w
    return max(score)


def _oracle326(n):
    vals=sorted(100*h+10*t+h*t for h in range(1,10) for t in range(10) if h*t<=9)
    return next(v for v in vals if v>=n)


def _oracle327(b):
    mp={a**a:a for a in range(1,16)}
    return mp.get(b,-1)


def _oracle328(n,d):
    ans=0
    for month,days in enumerate(d,1):
        for day in range(1,days+1):
            if len(set(str(month)+str(day)))==1: ans+=1
    return ans


def _oracle329(n,a):
    first=second=-1
    for x in a:
        if x>first:
            if x!=first: second=first
            first=x
        elif x!=first and x>second:
            second=x
    return second


def _oracle330(n,l,r,a):
    return [l if x<l else r if x>r else x for x in a]


def _oracle331(n,s,m,l):
    inf=10**18; lim=n+12; dp=[inf]*(lim+13); dp[0]=0
    for eggs in range(lim+1):
        if dp[eggs]==inf: continue
        for add,cost in ((6,s),(8,m),(12,l)):
            ne=min(lim+12,eggs+add); dp[ne]=min(dp[ne],dp[eggs]+cost)
    return min(dp[n:])


def _oracle332(k,g,m):
    glass=mug=0
    for _ in range(k):
        if glass==g:
            glass=0
        elif mug==0:
            mug=m
        else:
            moved=min(g-glass,mug); glass+=moved; mug-=moved
    return glass,mug


def _oracle333(s,t):
    edges={"AB","BC","CD","DE","AE"}
    def short(seg): return ''.join(sorted(seg)) in edges
    return short(s)==short(t)


def _oracle334(a,m,l,r):
    k=-((a-l)//m)  # ceil((l-a)/m) using floor division identity
    first=a+k*m
    if first<l: first+=m
    if first>r:return 0
    return (r-first)//m+1


def _oracle335(n):
    vals=[p for p in product(range(n+1),repeat=3) if sum(p)<=n]
    vals.sort()
    return [f"{x} {y} {z}" for x,y,z in vals]


def _oracle336(n):
    return (n & -n).bit_length()-1


def _oracle337(s):
    return all(a<=b for a,b in zip(s,s[1:]))


def _oracle338(s):
    counts=[0]*26
    for ch in s: counts[ord(ch)-97]+=1
    best=max(counts)
    return chr(97+next(i for i,c in enumerate(counts) if c==best))


def independent_check(pid: str, raw: str, output: str) -> bool:
    try: v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or '\r' in output: return False
    try:
        if pid in {"abc324_b","abc333_b","abc337_b"}:
            if output not in ("Yes","No"): return False
            return (output=="Yes")==globals()[f"_oracle{pid[3:6]}"](*v)
        if pid in {"abc323_b","abc330_b"}:
            parts=output.split(" ")
            if not parts or any(SINT.fullmatch(x) is None for x in parts) or " ".join(parts)!=output:return False
            return list(map(int,parts))==globals()[f"_oracle{pid[3:6]}"](*v)
        if pid=="abc332_b":
            parts=output.split(" ")
            if len(parts)!=2 or any(INT.fullmatch(x) is None for x in parts):return False
            return tuple(map(int,parts))==_oracle332(*v)
        if pid=="abc335_b":
            if output=='': return False
            return output.split('\n')==_oracle335(*v)
        if pid=="abc338_b":
            return len(output)==1 and 'a'<=output<='z' and output==_oracle338(*v)
        if '\n' in output or SINT.fullmatch(output) is None:return False
        return int(output)==globals()[f"_oracle{pid[3:6]}"](*v)
    except Exception:
        return False


def official_expected_matches_reference(pid: str, raw: str, expected: str, actual: str) -> bool:
    return actual==expected and independent_check(pid,raw,actual[:-1] if actual.endswith('\n') else actual)


def _add(out,seen,pid,category,raw):
    validate(pid,raw)
    if raw not in seen:
        seen.add(raw); out.append({"category":category,"input":raw})


def _tournament(n:int, shift:int=0) -> str:
    g=[['-']*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1,n):
            win_i=((i*17+j*31+shift)%5)<3
            g[i][j]='o' if win_i else 'x'; g[j][i]='x' if win_i else 'o'
    return str(n)+'\n'+'\n'.join(''.join(r) for r in g)+'\n'


def generate(pid: str) -> list[dict[str,str]]:
    out=[];seen=set();custom=[];max_case=''
    if pid=='abc321_b':
        custom=[('minimum','3 0\n0 0\n'),('tie_low','3 50\n50 50\n'),('zero_needed','4 100\n0 100 100\n'),('impossible','4 200\n0 99 99\n'),('middle','5 150\n10 50 80 100\n')]
        for x in (1,10,25,49,50,51,75,99,100,180): custom.append((f'x{x}',f'5 {min(x,300)}\n10 20 30 40\n'))
        custom += [('many','10 350\n10 20 30 40 50 60 70 80 90\n'),('duplicates','6 250\n50 50 50 50 50\n')]
        max_case='100 9800\n'+' '.join(['100']*99)+'\n'
    elif pid=='abc322_b':
        pairs=[('a','a'),('a','ab'),('a','ba'),('ab','abxxab'),('ab','abxx'),('ab','xxab'),('ab','xxxx'),('aaa','aaaaa'),('abc','abcabc'),('abc','zabc'),('abc','abcz'),('xyz','xyxyz'),('zz','zzzz'),('m','abcdefghijklmnopqrstuvwxyz'),('q','abcdefghijklmnopq')]
        custom=[(f'case{i}',f'{len(s)} {len(t)}\n{s}\n{t}\n') for i,(s,t) in enumerate(pairs)]
        custom += [('equal100','100 100\n'+'a'*100+'\n'+'a'*100+'\n'),('both100','50 100\n'+'a'*50+'\n'+'a'*100+'\n')]
        max_case='100 100\n'+'a'*99+'b\n'+'a'*99+'b\n'
    elif pid=='abc323_b':
        custom=[('n2a','2\n-o\nx-\n'),('n2b','2\n-x\no-\n')]
        for n in range(3,16): custom.append((f'n{n}',_tournament(n,n)))
        custom += [('n20',_tournament(20,4)),('n30',_tournament(30,2))]
        max_case=_tournament(100,7)
    elif pid=='abc324_b':
        vals=[1,2,3,4,6,8,9,12,18,24,27,32,36,72,5,7,10]
        custom=[(f'n{x}',f'{x}\n') for x in vals]
        max_case='1000000000000000000\n'
    elif pid=='abc325_b':
        custom=[('single9','1\n1 9\n'),('single0','1\n100 0\n'),('single23','1\n7 23\n'),('two_same','2\n5 0\n6 0\n')]
        for k in range(1,12):
            rows=[(k*10+i+1,(i*7+k)%24) for i in range(5)]
            custom.append((f'mix{k}',str(len(rows))+'\n'+'\n'.join(f'{w} {x}' for w,x in rows)+'\n'))
        custom += [('allzones','24\n'+'\n'.join(f'{i+1} {i}' for i in range(24))+'\n'),('weightmax','2\n1000000 0\n999999 12\n')]
        max_case='1000\n'+'\n'.join(f'1000000 {i%24}' for i in range(1000))+'\n'
    elif pid=='abc326_b':
        vals=[100,101,109,110,111,119,120,143,144,145,199,320,326,399,400,516,918]
        custom=[(f'n{x}',f'{x}\n') for x in vals];max_case='919\n'
    elif pid=='abc327_b':
        vals=[1,2,4,8,9,16,27,81,256,3125,46656,823543,16777216,387420489,100,999999937,10**12]
        custom=[(f'n{i}',f'{x}\n') for i,x in enumerate(vals)];max_case='1000000000000000000\n'
    elif pid=='abc328_b':
        custom=[('one','1\n1\n'),('eleven','1\n11\n'),('two','2\n1 22\n'),('months11','11\n'+' '.join(['11']*11)+'\n')]
        for n in range(3,14): custom.append((f'n{n}',f'{n}\n'+' '.join(str((i*7+n)%100+1) for i in range(n))+'\n'))
        custom += [('all1','20\n'+' '.join(['1']*20)+'\n'),('all99','50\n'+' '.join(['99']*50)+'\n')]
        max_case='100\n'+' '.join(['100']*100)+'\n'
    elif pid=='abc329_b':
        custom=[('min','2\n1 2\n'),('dupe','3\n2 2 1\n'),('descending','5\n5 4 3 2 1\n'),('gap','4\n1 100 1 50\n')]
        for k in range(2,13): custom.append((f'k{k}',f'{k}\n'+' '.join(str((i%3)+k) for i in range(k-1))+' 1\n'))
        custom += [('twovalues','20\n'+' '.join(['100']*10+['99']*10)+'\n'),('mixed','10\n1 1 2 2 3 3 4 4 5 5\n')]
        max_case='100\n'+' '.join(map(str,range(1,101)))+'\n'
    elif pid=='abc330_b':
        custom=[('one_inside','1 1 10\n5\n'),('one_low','1 5 10\n1\n'),('one_high','1 5 10\n99\n'),('point','4 7 7\n1 7 8 100\n')]
        for k in range(1,12):
            a=[1,k,5*k,10**9]
            custom.append((f'k{k}',f'4 {k} {min(10**9,k+100)}\n'+' '.join(map(str,a))+'\n'))
        custom += [('boundaries','6 10 20\n1 9 10 20 21 100\n'),('largevals','3 999999998 1000000000\n1 999999999 1000000000\n')]
        arr=['1' if i%3==0 else '1000000000' if i%3==1 else '500000000' for i in range(200000)]
        max_case='200000 1 1000000000\n'+' '.join(arr)+'\n'
    elif pid=='abc331_b':
        vals=[(1,1,1,1),(6,10,100,100),(7,10,100,100),(8,100,10,100),(12,100,100,10),(13,2,3,4),(24,100,100,100),(25,3,4,5),(50,10,7,13),(99,600,800,1200)]
        custom=[(f'case{i}',f'{n} {s} {m} {l}\n') for i,(n,s,m,l) in enumerate(vals)]
        for k in range(1,8): custom.append((f'k{k}',f'{10+k} {k} {2*k+1} {3*k+2}\n'))
        max_case='100 10000 10000 10000\n'
    elif pid=='abc332_b':
        vals=[(1,1,2),(2,1,2),(3,1,2),(4,1,2),(5,1,2),(6,1,2),(10,3,5),(20,7,11),(50,99,100),(100,1,1000)]
        custom=[(f'case{i}',f'{k} {g} {m}\n') for i,(k,g,m) in enumerate(vals)]
        for k in range(1,8): custom.append((f'mix{k}',f'{10+k} {10+k} {30+k}\n'))
        max_case='100 999 1000\n'
    elif pid=='abc333_b':
        segs=['AB','AC','AD','AE','BC','BD','BE','CD','CE','DE']
        pairs=[]
        for i,s in enumerate(segs):
            for t in segs:
                if len(pairs)>=17: break
                pairs.append((s,t))
            if len(pairs)>=17: break
        custom=[(f'case{i}',f'{s}\n{t}\n') for i,(s,t) in enumerate(pairs)]
        max_case='EA\nDB\n'
    elif pid=='abc334_b':
        vals=[(0,1,0,0),(0,1,-5,5),(5,3,-1,6),(-2,2,1,1),(10,7,0,100),(10,7,11,16),(-10,7,-30,-1),(999999999999999999,999999999,-999999999999999999,999999999999999999)]
        custom=[(f'case{i}',f'{a} {m} {l} {r}\n') for i,(a,m,l,r) in enumerate(vals)]
        for k in range(1,10): custom.append((f'k{k}',f'{-100*k} {k+1} {-1000*k} {1000*k}\n'))
        max_case='1000000000000000000 1000000000 -1000000000000000000 1000000000000000000\n'
    elif pid=='abc335_b':
        custom=[(f'n{i}',f'{i}\n') for i in range(17)]
        max_case='21\n'
    elif pid=='abc336_b':
        vals=[1,2,3,4,5,8,16,24,32,64,96,128,1024,2024,999999999,536870912,999999998]
        custom=[(f'n{x}',f'{x}\n') for x in vals];max_case='1000000000\n'
    elif pid=='abc337_b':
        vals=['A','B','C','AB','AC','BC','ABC','AAABBBCCC','BA','CA','CB','ABA','ABCA','CCAAA','BBBBCCCC','AAAAACCCCC','BAC']
        custom=[(f's{i}',s+'\n') for i,s in enumerate(vals)];max_case='A'*33+'B'*33+'C'*34+'\n'
    elif pid=='abc338_b':
        vals=['a','z','aa','ab','ba','abc','cba','mississippi','banana','zzzyyy','abcdefghijklmnopqrstuvwxyz','aabbcc','bbbbaaaa','frequency','atcoder','abracadabra','xyxyxyx']
        custom=[(f's{i}',s+'\n') for i,s in enumerate(vals)];max_case='z'*1000+'\n'
    for cat,raw in custom:
        if len(out)>=17: break
        _add(out,seen,pid,cat,raw)
    _add(out,seen,pid,'constraint_max',max_case)
    if len(out)!=18 or len({x['input'] for x in out})!=18 or out[-1]['category']!='constraint_max':
        raise AssertionError(f'{pid}: expected 18 distinct cases ending max, got {len(out)}')
    return out


REFERENCE_CODE = {
'abc321_b':'''n,x=map(int,input().split());a=list(map(int,input().split()))\nfor z in range(101):\n b=sorted(a+[z])\n if sum(b[1:-1])>=x:print(z);break\nelse:print(-1)\n''',
'abc322_b':'''n,m=map(int,input().split());s=input().strip();t=input().strip();p=t.startswith(s);q=t.endswith(s);print(0 if p and q else 1 if p else 2 if q else 3)\n''',
'abc323_b':'''n=int(input());s=[input().strip() for _ in range(n)];a=[(-s[i].count('o'),i+1) for i in range(n)];a.sort();print(*(i for _,i in a))\n''',
'abc324_b':'''n=int(input())\nwhile n%2==0:n//=2\nwhile n%3==0:n//=3\nprint('Yes' if n==1 else 'No')\n''',
'abc325_b':'''n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];ans=0\nfor h in range(24):\n cur=sum(w for w,x in a if 9<=((h+x)%24)<18);ans=max(ans,cur)\nprint(ans)\n''',
'abc326_b':'''n=int(input())\nwhile True:\n s=str(n)\n if int(s[0])*int(s[1])==int(s[2]):print(n);break\n n+=1\n''',
'abc327_b':'''b=int(input());ans=-1\nfor a in range(1,19):\n if a**a==b:ans=a;break\nprint(ans)\n''',
'abc328_b':'''n=int(input());d=list(map(int,input().split()));ans=0\nfor i in range(1,n+1):\n for j in range(1,d[i-1]+1):\n  s=str(i)+str(j)\n  if len(set(s))==1:ans+=1\nprint(ans)\n''',
'abc329_b':'''n=int(input());a=list(map(int,input().split()));b=sorted(set(a));print(b[-2])\n''',
'abc330_b':'''n,l,r=map(int,input().split());a=list(map(int,input().split()));print(*(min(r,max(l,x)) for x in a))\n''',
'abc331_b':'''n,s,m,l=map(int,input().split());ans=10**18\nfor i in range(20):\n for j in range(20):\n  for k in range(20):\n   if 6*i+8*j+12*k>=n:ans=min(ans,s*i+m*j+l*k)\nprint(ans)\n''',
'abc332_b':'''k,g,m=map(int,input().split());x=y=0\nfor _ in range(k):\n if x==g:x=0\n elif y==0:y=m\n else:\n  z=min(g-x,y);x+=z;y-=z\nprint(x,y)\n''',
'abc333_b':'''s=input().strip();t=input().strip()\ndef d(u):\n x=abs(ord(u[0])-ord(u[1]));return min(x,5-x)\nprint('Yes' if d(s)==d(t) else 'No')\n''',
'abc334_b':'''a,m,l,r=map(int,input().split());print((r-a)//m-((l-1-a)//m))\n''',
'abc335_b':'''n=int(input())\nfor x in range(n+1):\n for y in range(n+1-x):\n  for z in range(n+1-x-y):print(x,y,z)\n''',
'abc336_b':'''n=int(input());ans=0\nwhile n%2==0:ans+=1;n//=2\nprint(ans)\n''',
'abc337_b':'''s=input().strip();print('Yes' if ''.join(sorted(s))==s else 'No')\n''',
'abc338_b':'''from collections import Counter\ns=input().strip();c=Counter(s);m=max(c.values());print(min(k for k,v in c.items() if v==m))\n''',
}
