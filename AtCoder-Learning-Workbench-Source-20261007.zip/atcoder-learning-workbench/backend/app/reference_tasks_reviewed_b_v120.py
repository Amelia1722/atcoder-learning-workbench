"""ABC218–220 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc218_b', 'abc219_b', 'abc220_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER = re.compile(r'[a-z]{1,10}', re.ASCII)
T_RE = re.compile(r'[123]{1,1000}', re.ASCII)
OUT_LOWER = re.compile(r'[a-z]+', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc218_b': [
        {'input': '1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26\n', 'expected': 'abcdefghijklmnopqrstuvwxyz\n'},
        {'input': '2 1 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26\n', 'expected': 'bacdefghijklmnopqrstuvwxyz\n'},
        {'input': '5 11 12 16 25 17 18 1 7 10 4 23 20 3 2 24 26 19 14 9 6 22 8 13 15 21\n', 'expected': 'eklpyqragjdwtcbxzsnifvhmou\n'},
    ],
    'abc219_b': [
        {'input': 'mari\nto\nzzo\n1321\n', 'expected': 'marizzotomari\n'},
        {'input': 'abra\ncad\nabra\n123\n', 'expected': 'abracadabra\n'},
        {'input': 'a\nb\nc\n1\n', 'expected': 'a\n'},
    ],
    'abc220_b': [
        {'input': '2\n1011 10100\n', 'expected': '220\n'},
        {'input': '7\n123 456\n', 'expected': '15642\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _validate218(raw: str) -> tuple[int, ...]:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    parts = lines[0].split(' ')
    if len(parts) != 26 or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('P syntax')
    vals = tuple(map(int, parts))
    if set(vals) != set(range(1, 27)):
        raise ValueError('P permutation')
    return vals


def _validate219(raw: str) -> tuple[tuple[str, str, str], str]:
    lines = _canonical_lines(raw)
    if len(lines) != 4:
        raise ValueError('shape')
    strings = tuple(lines[:3])
    t = lines[3]
    if any(LOWER.fullmatch(x) is None for x in strings) or T_RE.fullmatch(t) is None:
        raise ValueError('string syntax/range')
    return (strings[0], strings[1], strings[2]), t


def _parse_base(token: str, k: int) -> int:
    if POS.fullmatch(token) is None:
        raise ValueError('number syntax')
    value = 0
    for ch in token:
        d = ord(ch) - ord('0')
        if not 0 <= d < k:
            raise ValueError('digit out of base')
        value = value * k + d
        if value > 100000:
            raise ValueError('value range')
    if value < 1:
        raise ValueError('value range')
    return value


def _validate220(raw: str) -> tuple[int, int, int]:
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/K syntax')
    k = int(lines[0])
    if not 2 <= k <= 10:
        raise ValueError('K range')
    parts = lines[1].split(' ')
    if len(parts) != 2:
        raise ValueError('A/B shape')
    a = _parse_base(parts[0], k)
    b = _parse_base(parts[1], k)
    return k, a, b


def validate(pid: str, raw: str):
    if pid == 'abc218_b':
        return _validate218(raw)
    if pid == 'abc219_b':
        return _validate219(raw)
    if pid == 'abc220_b':
        return _validate220(raw)
    raise ValueError('unknown task')


def _ans218(vals: tuple[int, ...]) -> str:
    return ''.join(chr(ord('a') + x - 1) for x in vals)


def _ans219(value: tuple[tuple[str, str, str], str]) -> str:
    strings, t = value
    return ''.join(strings[int(ch) - 1] for ch in t)


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or '\n' in output or output != output.strip():
        return False
    if pid == 'abc218_b':
        return len(output) == 26 and OUT_LOWER.fullmatch(output) is not None and output == _ans218(value)
    if pid == 'abc219_b':
        return OUT_LOWER.fullmatch(output) is not None and output == _ans219(value)
    if pid == 'abc220_b':
        return POS.fullmatch(output) is not None and int(output) == value[1] * value[2]
    return False


def _case218(vals: list[int]) -> str:
    return ' '.join(map(str, vals)) + '\n'


def _digits(n: int, k: int) -> str:
    out: list[str] = []
    while n:
        out.append(str(n % k))
        n //= k
    return ''.join(reversed(out)) or '0'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    if pid == 'abc218_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        base = list(range(1, 27))
        variants = [
            ('reverse', list(reversed(base))),
            ('rotate1', base[1:] + base[:1]),
            ('rotate13', base[13:] + base[:13]),
            ('swap_last', base[:-2] + [26, 25]),
            ('pair_swaps', [x for i in range(1, 27, 2) for x in (i + 1, i)]),
            ('odds_evens', list(range(1, 27, 2)) + list(range(2, 27, 2))),
            ('evens_odds', list(range(2, 27, 2)) + list(range(1, 27, 2))),
            ('middle_reverse', base[:5] + list(reversed(base[5:21])) + base[21:]),
            ('first_last_swap', [26] + base[1:25] + [1]),
            ('block_reverse', list(reversed(base[:13])) + list(reversed(base[13:]))),
            ('zigzag', [x for pair in zip(range(1, 14), range(26, 13, -1)) for x in pair]),
            ('step5', [((5 * i) % 26) + 1 for i in range(26)]),
            ('step7', [((7 * i) % 26) + 1 for i in range(26)]),
            ('step11', [((11 * i) % 26) + 1 for i in range(26)]),
        ]
        for category, vals in variants:
            add(category, _case218(vals))
        add('constraint_max', _case218([13, 26, 12, 25, 11, 24, 10, 23, 9, 22, 8, 21, 7, 20, 6, 19, 5, 18, 4, 17, 3, 16, 2, 15, 1, 14]))
    elif pid == 'abc219_b':
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        cases = [
            ('single2', 'a\nb\nc\n2\n'),
            ('single3', 'a\nb\nc\n3\n'),
            ('all_same_source', 'abc\ndef\nghi\n11111\n'),
            ('cycle', 'ab\ncd\nef\n123123\n'),
            ('reverse_cycle', 'ab\ncd\nef\n321321\n'),
            ('same_strings', 'x\nx\nx\n123321\n'),
            ('prefix_overlap', 'a\naa\naaa\n123321\n'),
            ('len10', 'abcdefghij\nklmnopqrst\nuvwxyzabcd\n123\n'),
            ('t_len10', 'abc\ndef\nghi\n1231231231\n'),
            ('alternating', 'aaa\nb\ncc\n121212121212\n'),
            ('mixed', 'z\nabc\nmnop\n33221123\n'),
            ('t_100_1', 'a\nb\nc\n' + '1' * 100 + '\n'),
            ('t_100_cycle', 'ab\ncd\nef\n' + ('123' * 33 + '1') + '\n'),
            ('t_999', 'abc\ndef\nghi\n' + '321' * 333 + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', 'abcdefghij\nklmnopqrst\nuvwxyzabcd\n' + ('123' * 333 + '1') + '\n')
    else:
        for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
            add(f'sample{i}', row['input'])
        cases = [
            ('base2_min', '2\n1 1\n'),
            ('base2_small', '2\n10 11\n'),
            ('base2_equal', '2\n111111 111111\n'),
            ('base3', '3\n10201 21012\n'),
            ('base4', '4\n123 321\n'),
            ('base5', '5\n444 1000\n'),
            ('base6', '6\n12345 54321\n'),
            ('base8', '8\n777 1000\n'),
            ('base9', '9\n8888 12345\n'),
            ('base10_min', '10\n1 1\n'),
            ('base10_mid', '10\n99999 2\n'),
            ('value_100000_base3', f"3\n{_digits(100000, 3)} {_digits(99999, 3)}\n"),
            ('value_100000_base7', f"7\n{_digits(100000, 7)} {_digits(100000, 7)}\n"),
            ('asymmetric', f"2\n{_digits(100000, 2)} {_digits(1, 2)}\n"),
            ('base10_max', '10\n100000 100000\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', f"2\n{_digits(100000, 2)} {_digits(100000, 2)}\n")
    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
