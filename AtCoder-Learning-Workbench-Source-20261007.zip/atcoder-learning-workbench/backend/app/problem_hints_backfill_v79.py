"""Evidence-bound hint backfill for ABC008 B / ABC009 B / ABC010 B."""
HINTS_BACKFILL_V79={
'abc008_2':('必要なのは候補者ごとの得票数です。同じ名前が何回現れたか数えてください。','dictやCounterで名前ごとの出現回数を数え、最大回数の名前を1つ出力します。同率ならどれでも正解です。','疑似コード:\ncounts = Counter(votes)\nanswer = name_with_max_count(counts)\nprint(answer)'),
'abc009_2':('同じ最高額が複数あっても、それらは「1番目」と「2番目」には分かれません。異なる価格だけを見る必要があります。','価格をsetで重複除去して降順に並べ、2番目の値を出力します。','疑似コード:\nprices = sorted(set(A), reverse=True)\nprint(prices[1])'),
'abc010_2':('各花について、2種類どちらの花占いでも最後が「嫌い」にならない枚数まで、必要なだけ減らします。','安全なのは枚数が奇数で、さらに3で割った余りが2でない状態です。条件を満たすまで1枚ずつ減らして回数を数えます。','疑似コード:\nanswer = 0\nfor x in petals:\n  while x % 2 == 0 or x % 3 == 2:\n    x -= 1\n    answer += 1\nprint(answer)')}
