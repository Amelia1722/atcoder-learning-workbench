"""Three-stage reviewed hints for ABC099–103 A/B and selected C tasks."""
HINTS_V15 = {'abc099_a': ('名前が切り替わる境目の番号に注目してください。', '999と1000のどちら側かを条件分岐で判定します。', '疑似コード:\nNを読む\nN <= 999 なら ABC を表示\nそれ以外なら ABD を表示'),
 'abc099_b': ('2つの塔の高さの差から、塔が並ぶ場所を特定できないか考えてください。',
              '隣接する三角数の差は東側の塔番号です。元の塔の高さから見えている高さを引きます。',
              '疑似コード:\nd = b-a\nwest_height = d*(d-1)//2\nprint(west_height-a)'),
 'abc101_a': ('記号ごとに値がどちらへ変化するか、その回数を数えてください。', '+の個数から-の個数を引きます。', '疑似コード:\nSを読む\nprint(count(S,"+")-count(S,"-"))'),
 'abc101_b': ('大きな整数の桁を一つずつ取り出して合計してみてください。',
              '十進表記の各桁の和でNを割り、余りが0か確認します。',
              '疑似コード:\ndigit_sum=sum(int(c) for c in str(N))\nprint("Yes" if N%digit_sum==0 else "No")'),
 'abc101_c': ('1回で変更できる新しい要素数を考え、既に変えた区間と重ねてください。',
              '最小値1を含む連続区間を広げると、2回目以降は1回につき最大K-1個増やせます。',
              '疑似コード:\nremaining=N-1\nanswer=ceil(remaining/(K-1))\nprint(answer)'),
 'abc103_a': ('順番を工夫すれば、行き戻りの余計な差を払わずに済みます。',
              '3つの数を昇順に並べて隣同士の絶対差を足します。最大値−最小値と同じです。',
              '疑似コード:\nB=sort(A1,A2,A3)\nprint(B[2]-B[0])'),
 'abc103_b': ('操作を繰り返したときの文字列は、元の文字列をどう切り出す形になるでしょうか。',
              'Sを2回連結した文字列にTが連続部分文字列として含まれるかを判定します。',
              '疑似コード:\nprint("Yes" if T in S+S else "No")'),
 'abc103_c': ('余りに必ず成り立つ上限を各項ごとに考えてください。',
              '各項の最大はai-1です。mを全aiの最小公倍数から1引いた値にすれば同時達成できます。',
              '疑似コード:\nanswer=0\nfor x in A:answer+=x-1\nprint(answer)'),
 'abc104_a': ('境界となる値の直前と直後で、次に参加できる大会が変わります。',
              'Rを1200、2800と比較する条件分岐です。',
              '疑似コード:\nif R<1200:print("ABC")\nelif R<2800:print("ARC")\nelse:print("AGC")'),
 'abc104_b': ('文字列のどの位置に大文字があってよいか、分けて確認してください。',
              '先頭Aと途中のCを確認し、それ以外すべてが小文字か検査します。',
              '疑似コード:\n'
              'positions=[i for i in range(2,len(S)-1) if S[i]=="C"]\n'
              'ok=(S[0]=="A" and len(positions)==1)\n'
              'if ok:ok=all(S[i].islower() for i in range(1,len(S)) if i!=positions[0])\n'
              'print("AC" if ok else "WA")')}
