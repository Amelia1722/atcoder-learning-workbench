"""Evidence-bound backfill for ABC032–034 B; public statement checked."""
HINTS_BACKFILL_V66 = {
    'abc032_b': (
        'パスワード候補は文字が連続する区間です。同じ候補が何度も出た場合はどう扱うでしょうか。',
        '長さkのすべての連続部分文字列を集合setに入れます。kが文字列より長いなら候補は0個です。',
        '疑似コード:\ns,k=入力\nseen=set()\nfor i in 0..len(s)-k:\n  seen.add(s[i:i+k])\nprint(len(seen))',
    ),
    'abc033_b': (
        '人口の条件にある「過半数」と「ちょうど半数」の違いを明確にしてください。',
        '全町の人口合計を求めてから、ある町の人口の2倍が合計より厳密に大きいか調べます。なければatcoderです。',
        '疑似コード:\ntotal=sum(各町の人口)\nfor name,pop in towns:\n  if 2*pop>total: print(name); stop\nprint("atcoder")',
    ),
    'abc034_b': (
        '番号が連続した2人ずつのペアです。番号の偶奇で相手がどちら側になるか考えてください。',
        '奇数なら相手はn+1、偶数ならn-1です。1と10^9の端でも成り立ちます。',
        '疑似コード:\nn=入力\nif n%2==1: print(n+1)\nelse: print(n-1)',
    ),
}
