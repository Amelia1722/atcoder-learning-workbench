"""Independent reverse dependencies, quotient blocks, thresholds and graph search."""
from __future__ import annotations
from collections import Counter
from math import isqrt
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (226,227,228,229,230,232))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
Triple=tuple[int,int,int]
Skill=tuple[int,tuple[int,...]]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==227:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**11,'limit');return (n,)
    if number==226:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');skills=[];edges=0
        for i,row in enumerate(rows[1:],1):
            a=ints(row);require(len(a)>=2,'skill fields');t,k=a[:2];deps=a[2:];require(1<=t<=10**9 and 0<=k<i and len(deps)==len(set(deps))==k and all(1<=v<i for v in deps),'skill');skills.append((t,deps));edges+=k
        require(edges<=200000,'edge total');return (tuple(skills),)
    if number==228:
        n,k=ints(rows[0],2);require(1<=k<=n<=100000 and len(rows)==n+1,'shape');scores=tuple(cast(Triple,ints(row,3)) for row in rows[1:]);require(all(0<=v<=300 for row in scores for v in row),'score');return k,scores
    if number==229:
        n,w=ints(rows[0],2);require(1<=n<=300000 and 1<=w<=300000000 and len(rows)==n+1,'shape');cheese=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=10**9 and 1<=b<=1000 for a,b in cheese),'cheese');return w,cheese
    if number==230:
        require(len(rows)==2,'shape');n,a,b=ints(rows[0],3);p,q,r,s=ints(rows[1],4);require(1<=n<=10**18 and 1<=a<=n and 1<=b<=n and 1<=p<=q<=n and 1<=r<=s<=n and (q-p+1)*(s-r+1)<=300000,'window');return n,a,b,p,q,r,s
    n,m=ints(rows[0],2);require(1<=n<=8 and 0<=m<=n*(n-1)//2 and len(rows)==2*m+1,'shape');a=tuple(cast(Pair,ints(row,2)) for row in rows[1:m+1]);b=tuple(cast(Pair,ints(row,2)) for row in rows[m+1:]);require(len(set(a))==len(set(b))==m and all(1<=u<v<=n for u,v in a+b),'simple graph');return n,a,b
def _middle_triples(n:int)->int:
    answer=0
    for b in range(1,isqrt(n)+1):
        limit=min(b,n//(b*b));a=1;quotient=n//b
        while a<=limit:
            c=quotient//a;end=min(limit,quotient//c);answer+=(end-a+1)*(c-b+1);a=end+1
    return answer
def _graph_match(n:int,a:tuple[Pair,...],b:tuple[Pair,...])->bool:
    left=[set() for _ in range(n)];right=[set() for _ in range(n)]
    for u,v in a:left[u-1].add(v-1);left[v-1].add(u-1)
    for u,v in b:right[u-1].add(v-1);right[v-1].add(u-1)
    if sorted(map(len,left))!=sorted(map(len,right)):return False
    order=sorted(range(n),key=lambda j:-len(left[j]));mapping:dict[int,int]={};used:set[int]=set()
    def visit(depth:int)->bool:
        if depth==n:return True
        u=order[depth]
        for v in range(n):
            if v in used or len(left[u])!=len(right[v]) or any((old in left[u])!=(image in right[v]) for old,image in mapping.items()):continue
            mapping[u]=v;used.add(v)
            if visit(depth+1):return True
            used.remove(v);del mapping[u]
        return False
    return visit(0)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==226:
        skills=cast(tuple[Skill,...],data[0]);needed=[False]*len(skills);needed[-1]=True;answer=0
        for j in range(len(skills)-1,-1,-1):
            if needed[j]:
                t,deps=skills[j];answer+=t
                for v in deps:needed[v-1]=True
        return str(answer)
    if number==227:return str(_middle_triples(cast(int,data[0])))
    if number==228:
        k,scores=cast(tuple[int,tuple[Triple,...]],data);counts=Counter(map(sum,scores));above=[0]*1202;running=0
        for value in range(1200,-1,-1):above[value]=running;running+=counts[value]
        return '\n'.join('Yes' if above[sum(row)+300]<k else 'No' for row in scores)
    if number==229:
        w,cheese=cast(tuple[int,tuple[Pair,...]],data);weights:Counter[int]=Counter()
        for a,b in cheese:weights[a]+=b
        if sum(weights.values())<=w:return str(sum(a*b for a,b in weights.items()))
        low=1;high=10**9+1
        while high-low>1:
            middle=(low+high)//2
            if sum(b for a,b in weights.items() if a>=middle)>=w:low=middle
            else:high=middle
        mass=sum(b for a,b in weights.items() if a>low);return str(sum(a*b for a,b in weights.items() if a>low)+(w-mass)*low)
    if number==230:
        n,a,b,p,q,r,s=cast(tuple[int,int,int,int,int,int,int],data);rows=[]
        for i in range(p,q+1):
            row=['.']*(s-r+1)
            for j in (b+i-a,b-i+a):
                if r<=j<=s:row[j-r]='#'
            rows.append(''.join(row))
        return '\n'.join(rows)
    n,a,b=cast(tuple[int,tuple[Pair,...],tuple[Pair,...]],data);return 'Yes' if _graph_match(n,a,b) else 'No'
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc226_c':"n=int(input());skills=[]\nfor _ in range(n):\n a=list(map(int,input().split()));skills.append((a[0],a[2:]))\npending=[n-1];seen=set();answer=0\nwhile pending:\n j=pending.pop()\n if j in seen:continue\n seen.add(j);t,deps=skills[j];answer+=t;pending.extend(v-1 for v in deps)\nprint(answer)\n",
'abc227_c':"from math import isqrt\nn=int(input());answer=0;a=1\nwhile a*a*a<=n:\n for b in range(a,isqrt(n//a)+1):answer+=n//(a*b)-b+1\n a+=1\nprint(answer)\n",
'abc228_c':"n,k=map(int,input().split());scores=[sum(map(int,input().split())) for _ in range(n)];threshold=sorted(scores,reverse=True)[k-1]\nprint('\\n'.join('Yes' if s+300>=threshold else 'No' for s in scores))\n",
'abc229_c':"n,w=map(int,input().split());cheese=sorted((tuple(map(int,input().split())) for _ in range(n)),reverse=True);answer=0\nfor a,b in cheese:\n take=min(w,b);answer+=a*take;w-=take\nprint(answer)\n",
'abc230_c':"n,a,b=map(int,input().split());p,q,r,s=map(int,input().split())\nfor i in range(p,q+1):print(''.join('#' if abs(i-a)==abs(j-b) else '.' for j in range(r,s+1)))\n",
'abc232_c':"from itertools import permutations\nn,m=map(int,input().split());a=[tuple(map(int,input().split())) for _ in range(m)];b={tuple(map(int,input().split())) for _ in range(m)};answer=False\nfor p in permutations(range(1,n+1)):\n if {tuple(sorted((p[u-1],p[v-1]))) for u,v in a}==b:answer=True;break\nprint('Yes' if answer else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');n=int(pid[3:6]);rng=random.Random(16500+n)
    if n==226:
        def skills(rows:list[Skill])->str:return str(len(rows))+'\n'+''.join(line((t,len(deps),*deps)) for t,deps in rows)
        raws=[skills([(1,())]),skills([(10**9,())]),skills([(1,()),(2,())]),skills([(1,()),(2,(1,))])]
        for size in range(3,15):raws.append(skills([(rng.randint(1,100),tuple(j for j in range(1,i) if rng.randrange(3)==0)) for i in range(1,size+1)]))
        raws.extend([skills([(10**9,())]+[(10**9,(i-1,)) for i in range(2,200001)]),skills([(10**9,())]*199999+[(10**9,tuple(range(1,200000)))])])
    elif n==227:raws=[f'{v}\n' for v in (1,2,3,4,7,8,9,26,27,28,63,64,65,100,999,1000,10**11-1,10**11)]
    elif n==228:
        def scores(k:int,rows:list[Triple])->str:return f'{len(rows)} {k}\n'+''.join(line(row) for row in rows)
        raws=[scores(1,[(0,0,0)]),scores(1,[(300,300,300)]),scores(1,[(100,100,100),(200,200,200)]),scores(1,[(99,100,100),(200,200,200)])]
        for size in range(3,15):raws.append(scores(rng.randint(1,size),[cast(Triple,tuple(rng.randint(0,300) for _ in range(3))) for _ in range(size)]))
        raws.extend([scores(1,[(0,0,0)]*99999+[(300,300,300)]),scores(100000,[(300,300,300)]*100000)])
    elif n==229:
        def cheese(w:int,rows:list[Pair])->str:return f'{len(rows)} {w}\n'+''.join(line(row) for row in rows)
        raws=[cheese(1,[(1,1)]),cheese(300000000,[(10**9,1000)]),cheese(3,[(10,2),(9,2)]),cheese(1,[(1,1000),(2,1)])]
        for size in range(3,15):raws.append(cheese(rng.randint(1,size*50),[(rng.randint(1,100),rng.randint(1,100)) for _ in range(size)]))
        raws.extend([cheese(1,[(j+1,1000) for j in range(300000)]),cheese(300000000,[(10**9,1000)]*300000)])
    elif n==230:
        def window(n:int,a:int,b:int,p:int,q:int,r:int,s:int)->str:return f'{n} {a} {b}\n{p} {q} {r} {s}\n'
        raws=[window(1,1,1,1,1,1,1),window(2,1,1,1,2,1,2),window(3,2,2,1,3,1,3),window(3,1,3,1,3,1,3)]
        for size in range(4,16):raws.append(window(size,rng.randint(1,size),rng.randint(1,size),1,size,1,size))
        raws.extend([window(10**18,1,10**18,1,300000,10**18,10**18),window(10**18,10**18,10**18,10**18,10**18,10**18-299999,10**18)])
    else:
        def graph(n:int,a:list[Pair],b:list[Pair])->str:return f'{n} {len(a)}\n'+''.join(line(edge) for edge in a+b)
        raws=[graph(1,[],[]),graph(2,[],[]),graph(2,[(1,2)],[(1,2)]),graph(3,[(1,2)],[(2,3)])]
        for j in range(12):
            size=4+j%5;edges=[(u,v) for u in range(1,size+1) for v in range(u+1,size+1)];a=rng.sample(edges,rng.randint(1,len(edges)-1));p=list(range(1,size+1));rng.shuffle(p);b=sorted(tuple(sorted((p[u-1],p[v-1]))) for u,v in a) if j%2 else rng.sample(edges,len(a));raws.append(graph(size,a,b))
        cycle=[(j,j+1) for j in range(1,8)]+[(1,8)];other=[(1,2),(2,3),(3,4),(1,4),(5,6),(6,7),(7,8),(5,8)];complete=[(u,v) for u in range(1,9) for v in range(u+1,9)];raws.extend([graph(8,cycle,other),graph(8,complete,complete)])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc226_c':('技Nに直接・間接に必要な技だけを集めます。','依存先は必ず番号が小さいので、DFSで必要な技を訪ね、重複を除いて時間を足します。','疑似コード: pending=[N]; seen=set(); while pending: i=pop(); if i already seen: continue; add i to seen; pending.extend(dependencies[i]); print(sum(T[i] for i in seen))。'),
'abc227_c':('AとBを決めれば、Cの範囲を数えられます。','AはA^3<=N、BはA<=BかつA*B^2<=Nを満たすものだけです。CはBからN//(A*B)までです。','疑似コード: answer=0; for A while A^3<=N: for B=A..isqrt(N//A): answer+=N//(A*B)-B+1; print(answer)。'),
'abc228_c':('対象の生徒だけが300点を取り、他の生徒は0点を取る状況が最も有利です。','現在の合計点を大きい順に並べたK番目と、自分の合計点+300を比較します。同点なら同じ順位です。','疑似コード: total=[sum(row)]; threshold=sorted(total,descending)[K-1]; for score in total: print(Yes if score+300>=threshold else No)。'),
'abc229_c':('1グラムあたりのおいしさが大きいチーズを優先します。','おいしさの降順に並べ、残り重量と在庫の小さい方だけ使います。整数グラムの選択で最適値が得られます。','疑似コード: answer=0; for (A,B) in sorted descending by A: take=min(W,B); answer+=A*take; W-=take; print(answer)。'),
'abc230_c':('表示する範囲のマスだけ判定すれば十分です。','2本の対角線上にある条件は、中心からの行・列の距離の絶対値が等しいことです。','疑似コード: for i=P..Q: row=""; for j=R..S: row+=# if abs(i-A)==abs(j-B) else .; print(row)。'),
'abc232_c':('頂点数は8以下なので、番号の対応を全て試せます。','各順列で一方の辺の両端を変換し、もう一方の辺集合と一致するか調べます。無向辺は小さい番号を先にします。','疑似コード: for P in permutations(1..N): mapped={sorted(P[u],P[v]) for (u,v) in edgesA}; if mapped==edgesB: print Yes and stop; print No。')}

TITLES={'abc226_c': 'Martial artist', 'abc227_c': 'ABC conjecture', 'abc228_c': 'Final Day', 'abc229_c': 'Cheese', 'abc230_c': 'X drawing', 'abc232_c': 'Graph Isomorphism'}
PUBLISHED_SAMPLES={'abc226_c': [{'input': '3\n3 0\n5 1 1\n7 1 1\n', 'expected': '10\n'}, {'input': '5\n1000000000 0\n1000000000 0\n1000000000 0\n1000000000 0\n1000000000 4 1 2 3 4\n', 'expected': '5000000000\n'}], 'abc227_c': [{'input': '4\n', 'expected': '5\n'}, {'input': '100\n', 'expected': '323\n'}, {'input': '100000000000\n', 'expected': '5745290566750\n'}], 'abc228_c': [{'input': '3 1\n178 205 132\n112 220 96\n36 64 20\n', 'expected': 'Yes\nYes\nNo\n'}, {'input': '2 1\n300 300 300\n200 200 200\n', 'expected': 'Yes\nYes\n'}, {'input': '4 2\n127 235 78\n192 134 298\n28 56 42\n96 120 250\n', 'expected': 'Yes\nYes\nNo\nYes\n'}], 'abc229_c': [{'input': '3 5\n3 1\n4 2\n2 3\n', 'expected': '15\n'}, {'input': '4 100\n6 2\n1 5\n3 9\n8 7\n', 'expected': '100\n'}, {'input': '10 3141\n314944731 649\n140276783 228\n578012421 809\n878510647 519\n925326537 943\n337666726 611\n879137070 306\n87808915 39\n756059990 244\n228622672 291\n', 'expected': '2357689932073\n'}], 'abc230_c': [{'input': '5 3 2\n1 5 1 5\n', 'expected': '...#.\n#.#..\n.#...\n#.#..\n...#.\n'}, {'input': '5 3 3\n4 5 2 5\n', 'expected': '#.#.\n...#\n'}, {'input': '1000000000000000000 999999999999999999 999999999999999999\n999999999999999998 1000000000000000000 999999999999999998 1000000000000000000\n', 'expected': '#.#\n.#.\n#.#\n'}], 'abc232_c': [{'input': '4 4\n1 2\n1 3\n1 4\n3 4\n1 3\n1 4\n2 3\n3 4\n', 'expected': 'Yes\n'}, {'input': '5 6\n1 2\n1 3\n1 4\n3 4\n3 5\n4 5\n1 2\n1 3\n1 4\n1 5\n3 5\n4 5\n', 'expected': 'No\n'}, {'input': '8 0\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
