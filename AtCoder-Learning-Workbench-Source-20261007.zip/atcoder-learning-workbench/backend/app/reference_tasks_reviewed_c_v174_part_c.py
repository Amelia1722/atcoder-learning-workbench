"""Reviewed C tasks with readiness histograms, grant timestamps and turn bounds."""
from __future__ import annotations
from bisect import bisect_right
from collections import defaultdict
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(402,408))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[int,...],...]
Pairs=tuple[tuple[int,int],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==402:
        n,m=ints(rows[0],2);require(1<=n<=300000 and 1<=m<=300000 and len(rows)==m+2,'shape');meals=[];total=0
        for row in rows[1:-1]:a=ints(row);k=a[0];ingredients=a[1:];require(1<=k<=n and len(ingredients)==k and len(set(ingredients))==k and all(1<=v<=n for v in ingredients),'ingredients');meals.append(ingredients);total+=k
        b=ints(rows[-1],n);require(total<=300000 and set(b)==set(range(1,n+1)),'sum/order');return n,tuple(meals),b
    if number==403:
        n,m,q=ints(rows[0],3);require(1<=n<=200000 and 1<=m<=200000 and 1<=q<=200000 and len(rows)==q+1,'shape');queries=[]
        for row in rows[1:]:a=ints(row);require(a[0] in (1,2,3) and len(a)==(2 if a[0]==2 else 3) and 1<=a[1]<=n and (a[0]==2 or 1<=a[2]<=m),'query');queries.append(a)
        return tuple(queries),
    if number==404:
        n,m=ints(rows[0],2);require(3<=n<=200000 and 0<=m<=200000 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in a) and len({tuple(sorted(pair)) for pair in a})==m,'simple graph');return n,a
    if number in (405,406):
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n)
        if number==405:require(2<=n<=300000 and all(1<=v<=10000 for v in a),'values')
        else:require(4<=n<=300000 and set(a)==set(range(1,n+1)),'permutation')
        return (a,)
    require(len(rows)==1 and 1<=len(rows[0])<=500000 and re.fullmatch('[0-9]+',rows[0]) is not None,'digits');return (rows[0],)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==402:
        n,meals,b=cast(tuple[int,tuple[tuple[int,...],...],tuple[int,...]],data);day={v:j for j,v in enumerate(b,1)};ready=[0]*(n+1)
        for ingredients in meals:ready[max(day[v] for v in ingredients)]+=1
        total=0;out=[]
        for count in ready[1:]:total+=count;out.append(str(total))
        return '\n'.join(out)
    if number==403:
        queries=cast(Queries,data[0]);all_grants:dict[int,int]={};pair_grants:dict[tuple[int,int],int]={};requests=[]
        for t,q in enumerate(queries):
            if q[0]==1:pair_grants.setdefault((q[1],q[2]),t)
            elif q[0]==2:all_grants.setdefault(q[1],t)
            else:requests.append((t,q[1],q[2]))
        return '\n'.join('Yes' if min(all_grants.get(x,len(queries)),pair_grants.get((x,y),len(queries)))<t else 'No' for t,x,y in requests)
    if number==404:
        n,a=cast(tuple[int,Pairs],data);parent=list(range(n));size=[1]*n;degree=[0]*n
        def root(v:int)->int:
            while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
            return v
        for u,v in a:
            u-=1;v-=1;degree[u]+=1;degree[v]+=1;x,y=root(u),root(v)
            if x!=y:
                if size[x]<size[y]:x,y=y,x
                parent[y]=x;size[x]+=size[y]
        return 'Yes' if all(d==2 for d in degree) and size[root(0)]==n else 'No'
    if number==405:
        a=cast(tuple[int,...],data[0]);return str((sum(a)**2-sum(v*v for v in a))//2)
    if number==406:
        a=cast(tuple[int,...],data[0]);signs=[x<y for x,y in zip(a,a[1:])];turns=[j for j in range(1,len(signs)) if signs[j]!=signs[j-1]];answer=0
        for j,up in enumerate(signs):
            if not up:continue
            p=bisect_right(turns,j)
            if p+1<len(turns):second=turns[p+1];third=turns[p+2] if p+2<len(turns) else len(signs);answer+=third-second
        return str(answer)
    s=cast(str,data[0]);digits=list(map(int,s));return str(len(s)+digits[-1]+sum((x-y)%10 for x,y in zip(digits,digits[1:])))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc402_c':"n,m=map(int,input().split());dependent=[[] for _ in range(n)];remaining=[]\nfor j in range(m):\n a=list(map(int,input().split()));remaining.append(a[0])\n for v in a[1:]:dependent[v-1].append(j)\nb=list(map(int,input().split()));answer=0\nfor v in b:\n for j in dependent[v-1]:\n  remaining[j]-=1\n  if remaining[j]==0:answer+=1\n print(answer)\n",
'abc403_c':"n,m,q=map(int,input().split());all_users=set();pairs=set()\nfor _ in range(q):\n a=list(map(int,input().split()))\n if a[0]==1:pairs.add((a[1],a[2]))\n elif a[0]==2:all_users.add(a[1])\n else:print('Yes' if a[1] in all_users or (a[1],a[2]) in pairs else 'No')\n",
'abc404_c':"n,m=map(int,input().split());adj=[[] for _ in range(n)]\nfor _ in range(m):\n u,v=map(int,input().split());u-=1;v-=1;adj[u].append(v);adj[v].append(u)\nseen={0};stack=[0]\nwhile stack:\n v=stack.pop()\n for w in adj[v]:\n  if w not in seen:seen.add(w);stack.append(w)\nprint('Yes' if len(seen)==n and all(len(seq)==2 for seq in adj) else 'No')\n",
'abc405_c':"n=int(input());a=list(map(int,input().split()));prefix=0;answer=0\nfor v in a:answer+=prefix*v;prefix+=v\nprint(answer)\n",
'abc406_c':"from itertools import groupby\nn=int(input());a=list(map(int,input().split()));runs=[(sign,len(list(seq))) for sign,seq in groupby(x<y for x,y in zip(a,a[1:]))];answer=0\nfor j in range(len(runs)-2):\n if runs[j][0] and not runs[j+1][0] and runs[j+2][0]:answer+=runs[j][1]*runs[j+2][1]\nprint(answer)\n",
'abc407_c':"s=input();offset=0;answer=len(s)\nfor ch in reversed(s):\n digit=int(ch);extra=(digit-offset)%10;answer+=extra;offset=(offset+extra)%10\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17400+number)
    if number==402:
        def restaurant(n:int,meals:list[list[int]],b:list[int])->str:return f'{n} {len(meals)}\n'+''.join(f'{len(a)} '+' '.join(map(str,a))+'\n' for a in meals)+line(b)
        raws=[restaurant(n,meals,b) for n,meals,b in ((1,[[1]],[1]),(2,[[1]],[1,2]),(2,[[1,2]],[2,1]),(3,[[1,2],[2,3]],[1,2,3]))]
        for n in range(3,15):b=list(range(1,n+1));rng.shuffle(b);raws.append(restaurant(n,[rng.sample(range(1,n+1),rng.randint(1,n)) for _ in range(n)],b))
        raws.extend([restaurant(300000,[list(range(1,300001))],list(range(1,300001))),restaurant(300000,[[j] for j in range(1,300001)],list(range(300000,0,-1)))])
    elif number==403:
        def access(n:int,m:int,qs:list[str])->str:return f'{n} {m} {len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[access(n,m,qs) for n,m,qs in ((1,1,['1 1 1']),(1,1,['3 1 1']),(1,1,['2 1','3 1 1']),(2,2,['1 1 1','3 1 2','1 1 1','3 1 1']))];raws.extend(access(n,n,[f'{k} {rng.randint(1,n)}'+('' if k==2 else f' {rng.randint(1,n)}') for k in [rng.randint(1,3) for _ in range(n+5)]]) for n in range(3,15));raws.extend([access(200000,200000,['1 200000 200000']*100000+['3 200000 200000']*100000),access(200000,200000,['2 200000']+['3 200000 200000']*199999)])
    elif number==404:
        def graph(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{u} {v}\n' for u,v in a)
        raws=[graph(n,a) for n,a in ((3,[]),(3,[(1,2),(2,3),(3,1)]),(3,[(1,2),(2,3)]),(6,[(1,2),(2,3),(3,1),(4,5),(5,6),(6,4)]))];raws.extend(graph(n,rng.sample([(u,v) for u in range(1,n+1) for v in range(u+1,n+1)],n)) for n in range(4,16));raws.extend([graph(200000,[(j,j+1) for j in range(1,100000)]+[(100000,1)]+[(j,j+1) for j in range(100001,200000)]+[(200000,100001)]),graph(200000,[(j,j+1) for j in range(1,200000)]+[(200000,1)])])
    elif number==405:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1,1],[1,2],[10000,10000],[1,2,3])];raws.extend(arr([rng.randint(1,10000) for _ in range(n)]) for n in range(4,16));raws.extend([arr([1,10000]*150000),arr([10000]*300000)])
    elif number==406:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1,2,3,4],[1,4,2,3],[4,3,2,1],[2,1,4,3])]
        for n in range(5,17):a=list(range(1,n+1));rng.shuffle(a);raws.append(arr(a))
        raws.extend([arr(list(range(1,100001))+list(range(200000,100000,-1))+list(range(200001,300001))),arr(list(range(300000,0,-1)))])
    else:raws=[s+'\n' for s in ('0','1','9','10')];raws.extend(''.join(rng.choice('0123456789') for _ in range(n))+'\n' for n in range(2,14));raws.extend(['90'*250000+'\n','9'*500000+'\n'])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc402_c':('ある料理を食べられるのは、全食材を克服した日です。','各食材を使う料理一覧を持ち、残る苦手食材数を減らします。0になった料理を合計へ加えます。','疑似コード: dependent[食材]へ料理番号を追加しremaining=K; 各Bの日にdependent[B]のremaining--; 0になればanswer++; 毎日answerを出力。'),
'abc403_c':('ページ個別の権限と、全ページ権限を分けて記録します。','ユーザ・ページの組を集合、全権限ユーザを別の集合で管理します。','疑似コード: query1でpair(X,Y)追加; query2でallへX追加; query3はX in allまたはpair in grantedならYes。'),
'abc404_c':('サイクルでは全頂点の次数が2です。','次数2だけでは複数サイクルもあり得るので、全頂点が連結かも調べます。','疑似コード: adjacencyを作る; 頂点1からDFSで全N頂点に到達し、全adjacency長が2ならYes、他はNo。'),
'abc405_c':('現在の要素と、それより前の要素すべてとの積をまとめて足せます。','前の要素の和prefixがあれば、現在vの寄与はprefix*vです。','疑似コード: prefix=0,answer=0; 各vでanswer+=prefix*v; prefix+=v; answerを出力。'),
'abc406_c':('チルダ型の隣接比較は、増加・減少・増加の3区間です。','増減の連続区間を圧縮し、増加→減少→増加の3区間で左と右の選び方を掛けます。','疑似コード: 各隣接比較をsignにし連続run長を作る; (+,-,+)の3runごとに最初の長さ*最後の長さを加算。'),
'abc407_c':('逆から見ると、最後の数字を0へ戻してから末尾を消せます。','右から必要な数字との差をmod10で加算し、累積の増分を保持します。','疑似コード: answer=|S|,offset=0; 右からdigitを見てextra=(digit-offset)%10; answer+=extra; offset=(offset+extra)%10; answerを出力。')}

TITLES={'abc402_c': 'Dislike Foods', 'abc403_c': '403 Forbidden', 'abc404_c': 'Cycle Graph?', 'abc405_c': 'Sum of Product', 'abc406_c': '~', 'abc407_c': 'Security 2'}
PUBLISHED_SAMPLES={'abc402_c': [{'input': '5 4\n2 1 2\n3 3 4 5\n3 1 2 5\n1 3\n1 3 2 5 4\n', 'expected': '0\n1\n2\n3\n4\n'}, {'input': '9 8\n1 4\n5 6 9 7 4 3\n4 2 4 1 3\n1 1\n5 7 9 8 1 5\n2 9 8\n1 2\n1 1\n6 5 2 7 8 4 1 9 3\n', 'expected': '0\n0\n1\n1\n1\n2\n4\n6\n8\n'}], 'abc403_c': [{'input': '2 3 5\n1 1 2\n3 1 1\n3 1 2\n2 2\n3 2 3\n', 'expected': 'No\nYes\nYes\n'}, {'input': '5 5 10\n2 2\n3 4 4\n1 1 1\n1 4 1\n1 4 2\n1 4 4\n1 2 4\n3 3 2\n3 5 4\n3 2 1\n', 'expected': 'No\nNo\nNo\nYes\n'}], 'abc404_c': [{'input': '4 4\n2 4\n3 1\n4 1\n2 3\n', 'expected': 'Yes\n'}, {'input': '4 6\n1 2\n1 3\n1 4\n2 3\n2 4\n3 4\n', 'expected': 'No\n'}], 'abc405_c': [{'input': '3\n4 2 3\n', 'expected': '26\n'}, {'input': '2\n9 45\n', 'expected': '405\n'}, {'input': '10\n7781 8803 8630 9065 8831 9182 8593 7660 7548 8617\n', 'expected': '3227530139\n'}], 'abc406_c': [{'input': '6\n1 3 6 4 2 5\n', 'expected': '2\n'}, {'input': '6\n1 2 3 4 5 6\n', 'expected': '0\n'}, {'input': '12\n11 3 8 9 5 2 10 4 1 6 12 7\n', 'expected': '4\n'}], 'abc407_c': [{'input': '21\n', 'expected': '4\n'}, {'input': '407\n', 'expected': '17\n'}, {'input': '2025524202552420255242025524\n', 'expected': '150\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
