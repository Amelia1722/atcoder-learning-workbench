"""Three-stage hints for reviewed ABC110–112 B tasks."""
HINTS_V84={
'abc110_b':(
 '必要なのは、A側のすべての値より大きく、B側のすべての値以下になる整数Zが存在するかです。各側で最も厳しい境界だけ残せます。',
 'A側の下限はmax(X, x_i)、B側の上限はmin(Y, y_i)です。整数同士なので、下限 < 上限なら下限+1をZにできます。',
 '疑似コード:\nleft = max(X, max(xs))\nright = min(Y, min(ys))\nif left < right: print("No War")\nelse: print("War")'),
'abc111_b':(
 '条件を満たす3桁の数は111,222,...,999の9個だけです。N以上で最初のものを探せば十分です。',
 'd=1..9について111*dを小さい順に見て、初めてN以上になった値が答えです。',
 '疑似コード:\nfor d in 1..9:\n  x = 111 * d\n  if x >= N:\n    print(x)\n    break'),
'abc112_b':(
 '使える経路は時間t_iがT以下のものだけです。その中の最小コストだけを求めます。',
 '条件を満たす経路のc_iを集め、1つでもあればmin、なければ文字列TLEを出力します。',
 '疑似コード:\ncosts = []\nfor c,t in routes:\n  if t <= T: costs.append(c)\nif costs: print(min(costs))\nelse: print("TLE")')
}
