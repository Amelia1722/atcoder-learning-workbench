"""ABC105–112 A/B curated validators, generators and independent checks.

Statements/constraints were checked against the official AtCoder task pages.
Reference programs are local, independently authored Python programs.
"""
from __future__ import annotations

from random import Random
import re

SAMPLES = {
 'abc105_a': ('7 3\n','1','1<=N,K<=100'),
 'abc105_b': ('11\n','Yes','1<=N<=100'),
 'abc106_a': ('2 2\n','1','2<=A,B<=100'),
 'abc106_b': ('105\n','1','1<=N<=200'),
 'abc107_a': ('4 2\n','3','1<=N<=100; 1<=i<=N'),
 'abc107_b': ('4 4\n##.#\n....\n##.#\n.#.#\n','###\n###\n.##','1<=H,W<=100; cells . or #; at least one #'),
 'abc108_a': ('3\n','2','2<=K<=100'),
 'abc108_b': ('0 0 0 1\n','-1 1 -1 0','|x1|,|y1|,|x2|,|y2|<=100; p1!=p2'),
 'abc109_a': ('3 1\n','Yes','1<=A,B<=3'),
 'abc109_b': ('4\nhoge\nenglish\nhoge\nenigma\n','No','2<=N<=100; each word lowercase length 1..10'),
 'abc110_a': ('1 5 2\n','53','1<=A,B,C<=9'),
 'abc110_b': ('3 2 10 20\n8 15 13\n16 22\n','No War','1<=N,M<=100; -100<=X<Y<=100; xi,yi in -100..100; xi distinct, yi distinct'),
 'abc111_a': ('119\n','991','n is a 3-digit number consisting only of 1 and 9'),
 'abc111_b': ('112\n','222','100<=N<=999'),
 'abc112_a': ('1\n','Hello World','N is 1 or 2; if N=2, 1<=A,B<=9'),
 'abc112_b': ('3 70\n7 60\n1 80\n4 50\n','4','1<=N<=100; 1<=T,ci,ti<=1000; (ci,ti) pairs distinct'),
}
BATCH10 = {pid:{'sample_input':sin,'sample_output':sout,
    'source_url':f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}','constraints':cons}
    for pid,(sin,sout,cons) in SAMPLES.items()}

_INT = re.compile(r'-?\d+')
_POS = re.compile(r'\d+')

def _ints(data:str, signed=False):
    t=data.split(); pat=_INT if signed else _POS
    if not t or any(pat.fullmatch(x) is None for x in t): raise ValueError('整数形式が不正です')
    return list(map(int,t))

def validate(pid:str,data:str):
    if pid not in BATCH10: raise ValueError('未対応の問題ID')
    if pid=='abc107_b':
        lines=data.strip().splitlines()
        if not lines: raise ValueError('入力が空です')
        head=lines[0].split()
        if len(head)!=2 or any(_POS.fullmatch(x) is None for x in head): raise ValueError('H Wが必要です')
        h,w=map(int,head); grid=lines[1:]
        if not 1<=h<=100 or not 1<=w<=100 or len(grid)!=h: raise ValueError('H/W/行数が不正です')
        if any(len(row)!=w or re.fullmatch(r'[.#]+',row) is None for row in grid): raise ValueError('グリッド形式が不正です')
        if not any('#' in row for row in grid): raise ValueError('黒マスが必要です')
        return h,w,grid
    if pid=='abc109_b':
        lines=data.strip().splitlines()
        if not lines or _POS.fullmatch(lines[0].strip()) is None: raise ValueError('Nが必要です')
        n=int(lines[0]); words=[x.strip() for x in lines[1:]]
        if not 2<=n<=100 or len(words)!=n or any(re.fullmatch(r'[a-z]{1,10}',w) is None for w in words): raise ValueError('N/単語が不正です')
        return n,words
    if pid=='abc111_a':
        t=data.split()
        if len(t)!=1 or re.fullmatch(r'[19]{3}',t[0]) is None: raise ValueError('1/9だけの3桁が必要です')
        return t[0]
    if pid=='abc112_a':
        z=_ints(data)
        if z[0]==1:
            if z!=[1]: raise ValueError('N=1は1行のみです')
            return (1,)
        if len(z)!=3 or z[0]!=2 or any(not 1<=v<=9 for v in z[1:]): raise ValueError('N=2ではA,Bが必要です')
        return tuple(z)
    z=_ints(data, signed=(pid in ('abc108_b','abc110_b')))
    if pid in ('abc105_a','abc109_a'):
        if len(z)!=2: raise ValueError('2整数が必要です')
        lo,hi=(1,100) if pid=='abc105_a' else (1,3)
        if any(not lo<=v<=hi for v in z): raise ValueError('値域違反')
        return tuple(z)
    if pid in ('abc105_b','abc106_b','abc108_a','abc111_b'):
        if len(z)!=1: raise ValueError('1整数が必要です')
        lo,hi={'abc105_b':(1,100),'abc106_b':(1,200),'abc108_a':(2,100),'abc111_b':(100,999)}[pid]
        if not lo<=z[0]<=hi: raise ValueError('値域違反')
        return z[0]
    if pid=='abc106_a':
        if len(z)!=2 or any(not 2<=v<=100 for v in z): raise ValueError('A,B:2..100')
        return tuple(z)
    if pid=='abc107_a':
        if len(z)!=2 or not 1<=z[0]<=100 or not 1<=z[1]<=z[0]: raise ValueError('N/iが不正')
        return tuple(z)
    if pid=='abc108_b':
        if len(z)!=4 or any(abs(v)>100 for v in z) or z[:2]==z[2:]: raise ValueError('座標が不正')
        return tuple(z)
    if pid=='abc110_a':
        if len(z)!=3 or any(not 1<=v<=9 for v in z): raise ValueError('A,B,C:1..9')
        return tuple(z)
    if pid=='abc110_b':
        if len(z)<6: raise ValueError('N M X Y x yが必要です')
        n,m,x,y=z[:4]
        if not 1<=n<=100 or not 1<=m<=100 or not -100<=x<y<=100 or len(z)!=4+n+m: raise ValueError('N/M/X/Y/個数が不正')
        xs=z[4:4+n];ys=z[4+n:]
        if any(not -100<=v<=100 for v in xs+ys) or x in xs or y in ys or len(set(xs))!=n or len(set(ys))!=m: raise ValueError('都市座標の制約違反')
        return n,m,x,y,xs,ys
    if pid=='abc112_b':
        if len(z)<4: raise ValueError('N T と経路が必要です')
        n,t=z[:2]; rem=z[2:]
        if not 1<=n<=100 or not 1<=t<=1000 or len(rem)!=2*n: raise ValueError('N/T/経路数が不正')
        pairs=list(zip(rem[::2],rem[1::2]))
        if any(not 1<=c<=1000 or not 1<=tm<=1000 for c,tm in pairs) or len(set(pairs))!=n: raise ValueError('経路制約違反')
        return n,t,pairs
    raise AssertionError(pid)


def generate(pid:str,count:int,seed:int,include_large:bool):
    if pid not in BATCH10 or not 1<=count<=80: raise ValueError('問題ID/件数が不正')
    rnd=Random(seed);cases=[];seen=set()
    def add(cat,data):
        validate(pid,data)
        if data not in seen:
            seen.add(data);cases.append({'category':cat,'input':data})
        elif cat == 'constraint_max':
            for c in cases:
                if c['input'] == data:
                    c['category'] = cat
                    break
    def nums(cat,*v): add(cat,' '.join(map(str,v))+'\n')
    if pid=='abc105_a':
        for a in ((1,1),(2,1),(2,2),(7,3),(99,100),(100,99),(100,100),(97,10),(10,97),(81,9),(82,9),(100,1)): nums('boundary',*a)
        while len(cases)<count: nums('random',rnd.randint(1,100),rnd.randint(1,100))
        if include_large: nums('constraint_max',100,100)
    elif pid=='abc105_b':
        for n in (1,2,3,4,7,8,10,11,13,14,15,17,18,20,24,27,28,99,100): nums('boundary',n)
        while len(cases)<count: nums('random',rnd.randint(1,100))
        if include_large: nums('constraint_max',100)
    elif pid=='abc106_a':
        for a,b in ((2,2),(2,100),(100,2),(100,100),(3,3),(5,7),(99,100),(50,50),(2,3),(3,2),(10,10),(42,73)):nums('boundary',a,b)
        while len(cases)<count:nums('random',rnd.randint(2,100),rnd.randint(2,100))
        if include_large:nums('constraint_max',100,100)
    elif pid=='abc106_b':
        for n in (1,7,9,15,45,104,105,106,135,189,199,200):nums('boundary',n)
        while len(cases)<count:nums('random',rnd.randint(1,200))
        if include_large:nums('constraint_max',200)
    elif pid=='abc107_a':
        for n,i in ((1,1),(2,1),(2,2),(4,2),(15,11),(100,1),(100,100),(100,50),(99,50),(3,2),(50,25),(50,26)):nums('boundary',n,i)
        while len(cases)<count:
            n=rnd.randint(1,100);nums('random',n,rnd.randint(1,n))
        if include_large:nums('constraint_max',100,100)
    elif pid=='abc107_b':
        def grid(cat,g):add(cat,f'{len(g)} {len(g[0])}\n'+'\n'.join(g)+'\n')
        for g in (["#"],["#..","...","..."],["...",".#.","..."],["##.#","....","##.#",".#.#"],["#..",".#.","..#"],["###","###"],[".#..#"],[".","#","."]):grid('boundary',list(g))
        while len(cases)<count:
            h=rnd.randint(1,8);w=rnd.randint(1,8);g=[''.join('#' if rnd.random()<.25 else '.' for _ in range(w)) for _ in range(h)]
            if not any('#' in r for r in g):g[rnd.randrange(h)]=g[rnd.randrange(h)] if False else ('#'+'.'*(w-1))
            grid('random',g)
        if include_large:
            g=['.'*99+'#']+['.'*100 for _ in range(98)]+['#'+'.'*99]
            grid('constraint_max',g)
    elif pid=='abc108_a':
        for k in (2,3,4,5,6,7,10,11,49,50,51,99,100):nums('boundary',k)
        while len(cases)<count:nums('random',rnd.randint(2,100))
        if include_large:nums('constraint_max',100)
    elif pid=='abc108_b':
        pts=[(0,0,0,1),(2,3,6,6),(31,-41,-59,26),(-100,-100,100,100),(-100,100,100,-100),(0,0,1,0),(0,0,-1,0),(100,100,99,100),(-100,0,-99,0),(5,5,5,-5),(100,-100,-100,-100),(1,2,3,4)]
        for p in pts:nums('boundary',*p)
        while len(cases)<count:
            x1,y1,x2,y2=[rnd.randint(-100,100) for _ in range(4)]
            if (x1,y1)!=(x2,y2):nums('random',x1,y1,x2,y2)
        if include_large:nums('constraint_max',-100,-100,100,100)
    elif pid=='abc109_a':
        for a in range(1,4):
            for b in range(1,4):nums('boundary',a,b)
        if include_large:nums('constraint_max',3,3)
    elif pid=='abc109_b':
        def words(cat,ws):add(cat,str(len(ws))+'\n'+'\n'.join(ws)+'\n')
        for ws in (['a','a'],['a','ab'],['ab','bc'],['ab','ca'],['abc','cde','efg'],['hoge','english','hoge','enigma'],['a','aa','aaa','aaaa'],['abc','cba','abc'],['z','za','ab','bc']):words('boundary',ws)
        while len(cases)<count:
            n=rnd.randint(2,15);ws=[];last=rnd.choice('abc')
            for i in range(n):
                length=rnd.randint(1,6);w=last+''.join(rnd.choice('abc') for _ in range(length-1));ws.append(w);last=w[-1]
            if rnd.random()<.35: ws[-1]=ws[0]
            words('random',ws)
        if include_large:
            # 100 unique chained lowercase words, each <=10 chars.
            ws=[]
            for i in range(100):
                a=chr(97+(i%26));b=chr(97+((i+1)%26));ws.append(a+f'{i:02d}'.translate(str.maketrans('0123456789','abcdefghij'))+b)
            # repair chain by forcing each first char to previous last
            for i in range(1,100):ws[i]=ws[i-1][-1]+ws[i][1:]
            words('constraint_max',ws)
    elif pid=='abc110_a':
        for v in ((1,1,1),(9,9,9),(1,5,2),(6,6,7),(1,9,1),(9,1,1),(1,1,9),(2,3,4),(4,3,2),(8,9,7),(5,5,1),(1,5,5)):nums('boundary',*v)
        while len(cases)<count:nums('random',*(rnd.randint(1,9) for _ in range(3)))
        if include_large:nums('constraint_max',9,9,9)
    elif pid=='abc110_b':
        def world(cat,n,m,x,y,xs,ys):add(cat,f'{n} {m} {x} {y}\n'+' '.join(map(str,xs))+'\n'+' '.join(map(str,ys))+'\n')
        fixed=[(3,2,10,20,[8,15,13],[16,22]),(4,2,-48,-1,[-20,-35,-91,-23],[-22,66]),(1,1,-1,1,[0],[-1]),(1,1,-100,100,[99],[98]),(2,2,0,3,[1,2],[-1,2]),(2,2,0,3,[-1,1],[2,4])]
        for args in fixed:world('boundary',*args)
        while len(cases)<count:
            x=rnd.randint(-100,99);y=rnd.randint(x+1,100)
            poolx=[v for v in range(-100,101) if v!=x];pooly=[v for v in range(-100,101) if v!=y]
            n=rnd.randint(1,min(12,len(poolx)));m=rnd.randint(1,min(12,len(pooly)))
            world('random',n,m,x,y,rnd.sample(poolx,n),rnd.sample(pooly,m))
        if include_large:
            x=-100;y=100;xs=list(range(-99,1));ys=list(range(0,100));world('constraint_max',100,100,x,y,xs,ys)
    elif pid=='abc111_a':
        for s in ('111','119','191','911','199','919','991','999'):add('boundary',s+'\n')
        if include_large:add('constraint_max','999\n')
    elif pid=='abc111_b':
        for n in (100,110,111,112,221,222,223,550,750,776,777,778,888,889,998,999):nums('boundary',n)
        while len(cases)<count:nums('random',rnd.randint(100,999))
        if include_large:nums('constraint_max',999)
    elif pid=='abc112_a':
        add('boundary','1\n')
        for a in (1,2,5,9):
            for b in (1,5,9):add('boundary',f'2\n{a}\n{b}\n')
        while len(cases)<count:add('random',f'2\n{rnd.randint(1,9)}\n{rnd.randint(1,9)}\n')
        if include_large:add('constraint_max','2\n9\n9\n')
    elif pid=='abc112_b':
        def routes(cat,t,pairs):add(cat,f'{len(pairs)} {t}\n'+'\n'.join(f'{c} {tm}' for c,tm in pairs)+'\n')
        fixed=[(70,[(7,60),(1,80),(4,50)]),(3,[(1,1000),(2,4),(3,1000),(4,500)]),(1,[(1,1)]),(1000,[(1000,1000)]),(5,[(9,5),(1,6),(3,4)]),(10,[(5,10),(4,10),(3,11)])]
        for t,p in fixed:routes('boundary',t,p)
        while len(cases)<count:
            n=rnd.randint(1,15);t=rnd.randint(1,1000);pairs=[];used=set()
            while len(pairs)<n:
                p=(rnd.randint(1,1000),rnd.randint(1,1000))
                if p not in used:used.add(p);pairs.append(p)
            routes('random',t,pairs)
        if include_large:routes('constraint_max',1000,[(i+1,1000-i) for i in range(100)])
    # Make maximum-scale case the final case, matching Learning Lab's contract.
    max_cases=[c for c in cases if c['category']=='constraint_max']
    normal=[c for c in cases if c['category']!='constraint_max']
    result=normal[:count]
    if include_large and max_cases:
        # If max input was already present among normal, remove duplicate before append.
        m=max_cases[-1]
        result=[c for c in result if c['input']!=m['input']]
        result.append(m)
    return result


def independent_check(pid:str,data:str,expected:str)->bool:
    args=validate(pid,data);s=expected.strip()
    if pid=='abc105_a':
        n,k=args;return s==str(0 if n%k==0 else 1)
    if pid=='abc105_b':
        n=args;return s==('Yes' if any(4*a+7*b==n for a in range(26) for b in range(15)) else 'No')
    if pid=='abc106_a':
        a,b=args;return s==str((a-1)*(b-1))
    if pid=='abc106_b':
        n=args
        cnt=0
        for x in range(1,n+1,2):
            d=sum(x%k==0 for k in range(1,x+1))
            cnt+=d==8
        return s==str(cnt)
    if pid=='abc107_a':
        n,i=args;return s==str(n+1-i)
    if pid=='abc107_b':
        h,w,g=args
        rows=[i for i in range(h) if '#' in g[i]];cols=[j for j in range(w) if any(g[i][j]=='#' for i in range(h))]
        out='\n'.join(''.join(g[i][j] for j in cols) for i in rows)
        return s==out
    if pid=='abc108_a':
        k=args;odds=(k+1)//2;evens=k//2;return s==str(odds*evens)
    if pid=='abc108_b':
        x1,y1,x2,y2=args
        try:v=list(map(int,s.split()))
        except ValueError:return False
        if len(v)!=4:return False
        x3,y3,x4,y4=v
        # Check all four side vectors are successive 90-degree CCW rotations.
        pts=[(x1,y1),(x2,y2),(x3,y3),(x4,y4)]
        vec=[(pts[(i+1)%4][0]-pts[i][0],pts[(i+1)%4][1]-pts[i][1]) for i in range(4)]
        return all(vec[(i+1)%4]==(-vec[i][1],vec[i][0]) for i in range(4))
    if pid=='abc109_a':
        a,b=args;return s==('Yes' if a%2==1 and b%2==1 else 'No')
    if pid=='abc109_b':
        n,ws=args;ok=len(set(ws))==n and all(ws[i][-1]==ws[i+1][0] for i in range(n-1));return s==('Yes' if ok else 'No')
    if pid=='abc110_a':
        a=list(args);best=max(int(f'{x}{y}')+z for x,y,z in __import__('itertools').permutations(a));return s==str(best)
    if pid=='abc110_b':
        n,m,x,y,xs,ys=args;exists=any(x<z<=y and all(v<z for v in xs) and all(v>=z for v in ys) for z in range(-101,102));return s==('No War' if exists else 'War')
    if pid=='abc111_a':
        trans=str.maketrans('19','91');return s==args.translate(trans)
    if pid=='abc111_b':
        n=args;targets=[111*i for i in range(1,10)];return s==str(min(v for v in targets if v>=n))
    if pid=='abc112_a':
        return s==('Hello World' if args[0]==1 else str(args[1]+args[2]))
    if pid=='abc112_b':
        n,t,pairs=args;valid=[c for c,tm in pairs if tm<=t];return s==(str(min(valid)) if valid else 'TLE')
    return False
