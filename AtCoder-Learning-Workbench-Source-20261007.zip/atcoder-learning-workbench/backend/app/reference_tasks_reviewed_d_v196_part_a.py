from __future__ import annotations
from bisect import bisect_right
from functools import lru_cache
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(317,323));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...];Point=tuple[int,int]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v

class VectorUnion:
 def __init__(self,n:int)->None:self.parent=list(range(n));self.size=[1]*n;self.offset=[(0,0)]*n
 def root(self,v:int)->tuple[int,Point]:
  if self.parent[v]==v:return v,(0,0)
  r,(x,y)=self.root(self.parent[v]);dx,dy=self.offset[v];self.parent[v]=r;self.offset[v]=(x+dx,y+dy);return r,self.offset[v]
 def impose(self,u:int,v:int,delta:Point)->bool:
  ru,(ux,uy)=self.root(u);rv,(vx,vy)=self.root(v);dx,dy=delta
  if ru==rv:return (vx-ux,vy-uy)==delta
  if self.size[ru]<=self.size[rv]:self.parent[ru]=rv;self.offset[ru]=(vx-ux-dx,vy-uy-dy);self.size[rv]+=self.size[ru]
  else:self.parent[rv]=ru;self.offset[rv]=(dx+ux-vx,dy+uy-vy);self.size[ru]+=self.size[rv]
  return True

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc317_d':
  n=ints(r[0],1)[0];require(1<=n<=100 and len(r)==n+1,'N');districts=tuple(ints(s,3) for s in r[1:]);require(all(0<=x<=10**9 and 0<=y<=10**9 and (x+y)%2==1 and z>=1 for x,y,z in districts),'districts');seats=sum(z for x,y,z in districts);require(seats<=100000 and seats%2==1,'total seats');return (districts,)
 if pid=='abc318_d':
  n=ints(r[0],1)[0];require(2<=n<=16 and len(r)==n,'N');upper=tuple(ints(s,n-j-1) for j,s in enumerate(r[1:]));require(all(1<=v<=10**9 for row in upper for v in row),'weights');return n,upper
 if pid=='abc319_d':
  n,m=ints(r[0],2);require(1<=m<=n<=200000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=x<=10**9 for x in a),'Li');return m,a
 if pid=='abc320_d':
  n,m=ints(r[0],2);require(1<=n<=200000 and 0<=m<=200000 and len(r)==m+1,'shape');edges=tuple(ints(s,4) for s in r[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v and abs(x)<=10**9 and abs(y)<=10**9 for u,v,x,y in edges),'edge');union=VectorUnion(n)
  for u,v,x,y in edges:require(union.impose(u-1,v-1,(x,y)),'consistent information')
  return n,edges
 if pid=='abc321_d':
  n,m,p=ints(r[0],3);require(1<=n<=200000 and 1<=m<=200000 and 1<=p<=200000000 and len(r)==3,'shape');a=ints(r[1],n);b=ints(r[2],m);require(all(1<=v<=10**8 for v in a+b),'price');return p,a,b
 require(len(r)==12 and all(re.fullmatch(r'[.#]{4}',s) is not None for s in r),'boards');pieces=[]
 for at in range(0,12,4):
  cells=frozenset((i,j) for i in range(4) for j in range(4) if r[at+i][j]=='#');require(bool(cells),'nonempty');remaining=set(cells);queue=[remaining.pop()]
  for x,y in queue:
   for point in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
    if point in remaining:remaining.remove(point);queue.append(point)
  require(not remaining,'connected');pieces.append(cells)
 return (tuple(pieces),)

def election_loss_budget(districts:tuple[tuple[int,...],...])->int:
 total=sum(z for x,y,z in districts);budget=total//2;losing=[(z,(y-x+1)//2) for x,y,z in districts if x<y];all_cost=sum(c for z,c in losing);saved=[-1]*(budget+1);saved[0]=0
 for seats,cost in losing:
  for loss in range(budget,seats-1,-1):
   if saved[loss-seats]>=0:saved[loss]=max(saved[loss],saved[loss-seats]+cost)
 return all_cost-max(saved)

def matching_physical_bounds(n:int,upper:tuple[tuple[int,...],...])->int:
 weights=[[0]*n for _ in range(n)]
 for u,row in enumerate(upper):
  for v,value in enumerate(row,u+1):weights[u][v]=weights[v][u]=value
 best=0
 def visit(remaining:tuple[int,...],score:int)->None:
  nonlocal best
  if len(remaining)<=1:best=max(best,score);return
  maxima=[max(weights[u][v] for v in remaining if v!=u) for u in remaining]
  if score+sum(maxima)//2<=best:return
  u=remaining[0]
  if len(remaining)%2:visit(remaining[1:],score)
  for v in sorted(remaining[1:],key=lambda v:weights[u][v],reverse=True):visit(tuple(x for x in remaining[1:] if x!=v),score+weights[u][v])
 visit(tuple(range(n)),0);return best

def width_prefix_jumps(m:int,a:tuple[int,...])->int:
 prefix=[0]
 for value in a:prefix.append(prefix[-1]+value+1)
 low=max(a)-1;high=prefix[-1]-1
 while high-low>1:
  width=(low+high)//2;start=0;rows=0
  while start<len(a) and rows<m:start=bisect_right(prefix,prefix[start]+width+1)-1;rows+=1
  if start==len(a):high=width
  else:low=width
 return high

def coordinates_union(n:int,edges:tuple[tuple[int,...],...])->list[Point|None]:
 union=VectorUnion(n)
 for u,v,x,y in edges:require(union.impose(u-1,v-1,(x,y)),'consistent')
 anchor,(ax,ay)=union.root(0);answer=[]
 for v in range(n):root,(x,y)=union.root(v);answer.append((x-ax,y-ay) if root==anchor else None)
 return answer

def dinner_price_sweep(p:int,a:tuple[int,...],b:tuple[int,...])->int:
 aa=sorted(a);bb=sorted(b);count=len(bb);small_sum=sum(bb);answer=0
 for x in aa:
  while count and x+bb[count-1]>p:count-=1;small_sum-=bb[count]
  answer+=small_sum+x*count+p*(len(bb)-count)
 return answer

def piece_placements(piece:frozenset[Point])->set[int]:
 cells=piece;out=set()
 for _ in range(4):
  minx=min(x for x,y in cells);miny=min(y for x,y in cells);normalized={(x-minx,y-miny) for x,y in cells};height=max(x for x,y in normalized)+1;width=max(y for x,y in normalized)+1
  for dx in range(5-height):
   for dy in range(5-width):out.add(sum(1<<((x+dx)*4+y+dy) for x,y in normalized))
  cells=frozenset((y,-x) for x,y in cells)
 return out

def polyomino_exact_cover(pieces:tuple[frozenset[Point],...])->bool:
 if sum(map(len,pieces))!=16:return False
 placements=[piece_placements(piece) for piece in pieces];full=(1<<16)-1
 def visit(used:int,covered:int)->bool:
  if covered==full:return used==7
  lowest=(full^covered)&-(full^covered)
  for i in range(3):
   if used>>i&1:continue
   for placement in placements[i]:
    if placement&lowest and not placement&covered and visit(used|1<<i,covered|placement):return True
  return False
 return visit(0,0)

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc317_d':return str(election_loss_budget(cast(tuple[tuple[int,...],...],d[0])))+'\n'
 if pid=='abc318_d':return str(matching_physical_bounds(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))+'\n'
 if pid=='abc319_d':return str(width_prefix_jumps(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc320_d':return ''.join('undecidable\n' if point is None else line(point) for point in coordinates_union(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))
 if pid=='abc321_d':return str(dinner_price_sweep(cast(int,d[0]),cast(tuple[int,...],d[1]),cast(tuple[int,...],d[2])))+'\n'
 return ('Yes' if polyomino_exact_cover(cast(tuple[frozenset[Point],...],d[0])) else 'No')+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  expected=oracle(pid,raw);return actual.split()==expected.split() and (pid in ('abc320_d','abc322_d') or all(re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s) is not None for s in actual.split()))
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc317_d':'''import sys
n=int(input());districts=[tuple(map(int,input().split())) for _ in range(n)];total=sum(z for x,y,z in districts);dp=[0]+[10**30]*total
for x,y,z in districts:
 cost=max(0,(y-x+1)//2)
 for seats in range(total,z-1,-1):dp[seats]=min(dp[seats],dp[seats-z]+cost)
print(min(dp[total//2+1:]))
''',
'abc318_d':'''n=int(input());weight=[[0]*n for _ in range(n)]
for i in range(n-1):
 for j,v in enumerate(map(int,input().split()),i+1):weight[i][j]=weight[j][i]=v
dp=[-1]*(1<<n);dp[0]=0
for mask in range(1<<n):
 if dp[mask]<0:continue
 unused=[i for i in range(n) if not mask>>i&1]
 if not unused:continue
 first=unused[0]
 if len(unused)%2:dp[mask|1<<first]=max(dp[mask|1<<first],dp[mask])
 for second in unused[1:]:nextmask=mask|1<<first|1<<second;dp[nextmask]=max(dp[nextmask],dp[mask]+weight[first][second])
print(dp[-1])
''',
'abc319_d':'''n,m=map(int,input().split());a=list(map(int,input().split()));low=max(a)-1;high=sum(a)+n-1
while high-low>1:
 width=(low+high)//2;rows=1;used=0
 for x in a:
  if used and used+1+x>width:rows+=1;used=x
  else:used+=x+int(used>0)
 if rows<=m:high=width
 else:low=width
print(high)
''',
'abc320_d':'''from collections import deque
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);graph=[[] for _ in range(n)]
for _ in range(m):
 u=next(it)-1;v=next(it)-1;x=next(it);y=next(it);graph[u].append((v,x,y));graph[v].append((u,-x,-y))
positions=[None]*n;positions[0]=(0,0);queue=deque([0])
while queue:
 u=queue.popleft();x,y=positions[u]
 for v,dx,dy in graph[u]:
  if positions[v] is None:positions[v]=(x+dx,y+dy);queue.append(v)
print('\\n'.join('undecidable' if p is None else str(p[0])+' '+str(p[1]) for p in positions))
''',
'abc321_d':'''from bisect import bisect_right
n,m,p=map(int,input().split());a=list(map(int,input().split()));b=sorted(map(int,input().split()));prefix=[0]
for v in b:prefix.append(prefix[-1]+v)
answer=0
for x in a:k=bisect_right(b,p-x);answer+=x*k+prefix[k]+p*(m-k)
print(answer)
''',
'abc322_d':'''pieces=[]
for _ in range(3):pieces.append([input() for _ in range(4)])
def placements(board):
 out=set()
 for _ in range(4):
  cells=[(r,c) for r in range(4) for c in range(4) if board[r][c]=='#']
  for dr in range(-3,4):
   for dc in range(-3,4):
    moved=[(r+dr,c+dc) for r,c in cells]
    if all(0<=r<4 and 0<=c<4 for r,c in moved):out.add(sum(1<<(r*4+c) for r,c in moved))
  board=[''.join(board[3-c][r] for c in range(4)) for r in range(4)]
 return out
if sum(row.count('#') for board in pieces for row in board)!=16:print('No')
else:
 a,b,c=map(placements,pieces);full=(1<<16)-1;print('Yes' if any(not x&y and (full^(x|y)) in c for x in a for y in b) else 'No')
'''}

def render_pieces(pieces:tuple[frozenset[Point],...])->str:return ''.join(''.join('#' if (r,c) in piece else '.' for c in range(4))+'\n' for piece in pieces for r in range(4))
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(196000+int(pid[3:6]));raws=[]
 if pid=='abc317_d':
  def districts(a:list[tuple[int,int,int]])->str:return str(len(a))+'\n'+''.join(line(v) for v in a)
  raws=[districts([(0,1,1)]),districts([(1,0,1)]),districts([(10**9-1,10**9,99999)]),districts([(0,1,1),(2,1,1),(0,5,1)])]
  for j in range(12):
   n=j+3;a=[]
   for _ in range(n):x=rng.randrange(10**9);y=rng.randrange(10**9);y+=int((x+y)%2==0);a.append((x,y,rng.randrange(1,1000)))
   if sum(z for x,y,z in a)%2==0:x,y,z=a[-1];a[-1]=(x,y,z+1)
   raws.append(districts(a))
  raws.append(districts([(0,999999999,1000)]*99+[(0,999999999,999)]));raws.append(districts([(10**9,10**9-1,1000)]*99+[(10**9,10**9-1,999)]))
 elif pid=='abc318_d':
  def matrix(n:int,rows:list[list[int]])->str:return str(n)+'\n'+''.join(line(row) for row in rows)
  raws=[matrix(2,[[1]]),matrix(2,[[10**9]]),matrix(3,[[1,9],[10]]),matrix(4,[[1,100,2],[2,100],[1]])]
  for j in range(12):n=3+j%10;raws.append(matrix(n,[[rng.randrange(1,10**9+1) for _ in range(n-i-1)] for i in range(n-1)]))
  raws.append(matrix(16,[[rng.randrange(1,10**9+1) for _ in range(15-i)] for i in range(15)]));raws.append(matrix(16,[[10**9]*(15-i) for i in range(15)]))
 elif pid=='abc319_d':
  def array(m:int,a:list[int])->str:return line((len(a),m))+line(a)
  raws=[array(1,[1]),array(1,[10**9]),array(1,[1,1]),array(2,[1,1])]
  for j in range(12):n=j+3;raws.append(array(rng.randrange(1,n+1),[rng.randrange(1,10**9+1) for _ in range(n)]))
  raws.append(array(1,[10**9]*200000));raws.append(array(200000,[10**9]*200000))
 elif pid=='abc320_d':
  def graph(n:int,edges:list[tuple[int,int,int,int]])->str:return line((n,len(edges)))+''.join(line(edge) for edge in edges)
  raws=[graph(1,[]),graph(2,[]),graph(2,[(1,2,10**9,-10**9)]),graph(3,[(1,2,1,2),(1,2,1,2),(2,3,2,3),(1,3,3,5)])]
  for j in range(12):
   n=j+3;positions=[(rng.randrange(-10**8,10**8+1),rng.randrange(-10**8,10**8+1)) for _ in range(n)];edges=[]
   for u,v in ((u,v) for u in range(n) for v in range(u+1,n)):
    if rng.randrange(3)==0:x,y=positions[u];xx,yy=positions[v];edges.append((u+1,v+1,xx-x,yy-y))
   raws.append(graph(n,edges))
  raws.append(graph(200000,[(i,i+1,10**9,10**9) for i in range(1,200000)]));raws.append(graph(200000,[(i,i+1,-10**9,-10**9) for i in range(1,200000)]+[(1,2,-10**9,-10**9)]))
 elif pid=='abc321_d':
  def dinner(p:int,a:list[int],b:list[int])->str:return line((len(a),len(b),p))+line(a)+line(b)
  raws=[dinner(1,[1],[1]),dinner(200000000,[10**8],[10**8]),dinner(5,[1,2,3],[1,2,3]),dinner(1,[1,2],[1,2])]
  for j in range(12):raws.append(dinner(rng.randrange(1,200000001),[rng.randrange(1,10**8+1) for _ in range(j+2)],[rng.randrange(1,10**8+1) for _ in range(j+3)]))
  raws.append(dinner(200000000,list(range(1,200001)),list(range(1,200001))));raws.append(dinner(200000000,[10**8]*200000,[10**8]*200000))
 else:
  single=frozenset({(0,0)});full=frozenset((r,c) for r in range(4) for c in range(4));pieces=[(single,)*3,(full,single,single),(frozenset((r,c) for r in range(2) for c in range(4)),frozenset((2,c) for c in range(4)),frozenset((3,c) for c in range(4)))]
  for j in range(13):
   cells={(rng.randrange(4),rng.randrange(4))};group=[]
   for i in range(3):
    cells={(rng.randrange(4),rng.randrange(4))};target=rng.randrange(1,17)
    while len(cells)<target:
     x,y=rng.choice(tuple(cells));dx,dy=rng.choice(((1,0),(-1,0),(0,1),(0,-1)));point=(x+dx,y+dy)
     if 0<=point[0]<4 and 0<=point[1]<4:cells.add(point)
    group.append(frozenset(cells))
   pieces.append(tuple(group))
  snake=[(r,c if r%2==0 else 3-c) for r in range(4) for c in range(4)];pieces.append((frozenset(snake[:5]),frozenset(snake[5:10]),frozenset(snake[10:])));pieces.append((full,full,full));raws=[render_pieces(cast(tuple[frozenset[Point],...],piece)) for piece in pieces]
 require(len(raws)==len(set(raws))==18,'18 distinct');cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02d}'})
 return cases
HINTS={
'abc317_d':('選挙区ごとに勝つための最少の鞍替え人数を計算しましょう。','その区で勝つにはmax(0,(Y-X+1)//2)人を鞍替えさせれば十分です。獲得議席数を状態にした最小費用の部分和DPで、総議席の過半数を目指します。','疑似コード: total=ΣZ,dp[0]=0,他INF。各区のcost=max(0,(Y-X+1)//2)でseats=total..Zを降順にdp[seats]=min(dp[seats],dp[seats-Z]+cost)。min(dp[total//2+1:])を出力。'),
'abc318_d':('既に使った頂点の集合をbitmaskで表します。','未使用の最初の頂点を一つ固定し、他の未使用頂点と組み合わせます。残りが奇数のときは、その頂点を使わない選択も必要です。','疑似コード: dp[0]=0,他-1。各maskで未使用最小uを取る。残数奇数ならuのみ使用済みへ同じ点数で遷移。他の未使用vとのペアではmask|bit(u)|bit(v)をdp[mask]+D[u][v]で最大化。全使用済みdpを出力。'),
'abc319_d':('横幅が決まれば、左からできるだけ詰めた時の行数が最少です。','幅が広がるほど必要な行数は増えないので二分探索できます。下限は最大単語幅、上限は全てを一行に置く幅です。','疑似コード: l=max(L)-1,r=ΣL+N-1。midで順に単語を置き、空白1込みで超えるなら次行へ。行数<=Mならr=mid、他l=mid。r-l=1になったrを出力。'),
'abc320_d':('人の相対位置を、逆向きの情報も含むグラフにしましょう。','人1の座標を(0,0)として探索します。既知の座標に辺の相対位置を加えれば、隣の人の座標がわかります。人1から到達不能なら一意に定まりません。','疑似コード: A→Bに(X,Y)、B→Aに(-X,-Y)を追加。pos[1]=(0,0)としてBFSし未確定隣接vへpos[v]=pos[u]+delta。各人のposかundecidableを出力。'),
'abc321_d':('主菜を一つ固定すると、副菜との和がP以下になる範囲がわかります。','副菜価格をソートし累積和を作ります。P-A以下の個数を二分探索し、その範囲はAと副菜価格の和、残りは一律Pを加えます。','疑似コード: Bをsortしprefix作成。各Aでk=upper_bound(B,P-A)。answer+=A*k+prefix[k]+P*(M-k)。answerを出力。'),
'abc322_d':('各ピースの四つの回転と、盤内に収まる全ての平行移動を調べましょう。','盤の占有状態を16bit整数にします。一つ目と二つ目が重ならない配置を選び、その補集合を三つ目で埋められるか確認します。裏返しは含めません。','疑似コード: 各pieceの4回転で移動量-3..3を全列挙し全#が盤内の占有maskを保存。面積合計!=16ならNo。一つ目aと二つ目bでa&b==0、full^(a|b)が三つ目mask集合にあればYes、他No。')}

TITLES={'abc317_d': 'President', 'abc318_d': 'General Weighted Max Matching', 'abc319_d': 'Minimum Width', 'abc320_d': 'Relative Position', 'abc321_d': 'Set Menu', 'abc322_d': 'Polyomino'}
PUBLISHED_SAMPLES={'abc317_d': [{'input': '1\n3 8 1\n', 'expected': '3\n'}, {'input': '2\n3 6 2\n1 8 5\n', 'expected': '4\n'}, {'input': '3\n3 4 2\n1 2 3\n7 2 6\n', 'expected': '0\n'}, {'input': '10\n1878 2089 16\n1982 1769 13\n2148 1601 14\n2189 2362 15\n2268 2279 16\n2394 2841 18\n2926 2971 20\n3091 2146 20\n3878 4685 38\n4504 4617 29\n', 'expected': '86\n'}], 'abc318_d': [{'input': '4\n1 5 4\n7 8\n6\n', 'expected': '13\n'}, {'input': '3\n1 2\n3\n', 'expected': '3\n'}, {'input': '16\n5 6 5 2 1 7 9 7 2 5 5 2 4 7 6\n8 7 7 9 8 1 9 6 10 8 8 6 10 3\n10 5 8 1 10 7 8 4 8 6 5 1 10\n7 4 1 4 5 4 5 10 1 5 1 2\n2 9 9 7 6 2 2 8 3 5 2\n9 10 3 1 1 2 10 7 7 5\n10 6 1 8 9 3 2 4 2\n10 10 8 9 2 10 7 9\n5 8 8 7 5 8 2\n4 2 2 6 8 3\n2 7 3 10 3\n5 7 10 3\n8 5 7\n9 1\n4\n', 'expected': '75\n'}], 'abc319_d': [{'input': '13 3\n9 5 2 7 1 8 8 2 1 5 2 3 6\n', 'expected': '26\n'}, {'input': '10 1\n1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '10000000009\n'}, {'input': '30 8\n8 55 26 97 48 37 47 35 55 5 17 62 2 60 23 99 73 34 75 7 46 82 84 29 41 32 31 52 32 60\n', 'expected': '189\n'}], 'abc320_d': [{'input': '3 2\n1 2 2 1\n1 3 -1 -2\n', 'expected': '0 0\n2 1\n-1 -2\n'}, {'input': '3 2\n2 1 -2 -1\n2 3 -3 -3\n', 'expected': '0 0\n2 1\n-1 -2\n'}, {'input': '5 7\n1 2 0 0\n1 2 0 0\n2 3 0 0\n3 1 0 0\n2 1 0 0\n3 2 0 0\n4 5 0 0\n', 'expected': '0 0\n0 0\n0 0\nundecidable\nundecidable\n'}], 'abc321_d': [{'input': '2 2 7\n3 5\n6 1\n', 'expected': '24\n'}, {'input': '1 3 2\n1\n1 1 1\n', 'expected': '6\n'}, {'input': '7 12 25514963\n2436426 24979445 61648772 23690081 33933447 76190629 62703497\n11047202 71407775 28894325 31963982 22804784 50968417 30302156 82631932 61735902 80895728 23078537 7723857\n', 'expected': '2115597124\n'}], 'abc322_d': [{'input': '....\n###.\n.#..\n....\n....\n.###\n.##.\n....\n..#.\n.##.\n.##.\n.##.\n', 'expected': 'Yes\n'}, {'input': '###.\n#.#.\n##..\n....\n....\n..#.\n....\n....\n####\n##..\n#...\n#...\n', 'expected': 'Yes\n'}, {'input': '##..\n#..#\n####\n....\n....\n##..\n.##.\n....\n.#..\n.#..\n.#..\n.#..\n', 'expected': 'No\n'}, {'input': '....\n..#.\n....\n....\n....\n..#.\n....\n....\n....\n..#.\n....\n....\n', 'expected': 'No\n'}, {'input': '....\n####\n#...\n#...\n....\n####\n...#\n..##\n....\n..##\n..#.\n..##\n', 'expected': 'No\n'}, {'input': '###.\n.##.\n..#.\n.###\n....\n...#\n..##\n...#\n....\n#...\n#...\n#...\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
