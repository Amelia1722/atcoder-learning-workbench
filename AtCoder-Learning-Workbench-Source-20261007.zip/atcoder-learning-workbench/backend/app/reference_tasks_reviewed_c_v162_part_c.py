"""Reviewed six new C tasks amid protected legacy ready tasks."""
from __future__ import annotations
from bisect import bisect_right
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in (170,172,173,175,176,179))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'field count');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');number=int(pid[3:6])
    if number==170:
        x,n=ints(rows[0],2);require(1<=x<=100 and 0<=n<=100,'limits')
        if n==0:require(rows==[rows[0]] or rows==[rows[0],''],'empty list');return x,()
        require(len(rows)==2,'shape');ps=ints(rows[1],n);require(all(1<=p<=100 for p in ps) and len(set(ps))==n,'forbidden set');return x,ps
    require(all(rows),'blank')
    if number==172:
        n,m,k=ints(rows[0],3);require(1<=n<=200000 and 1<=m<=200000 and 1<=k<=10**9 and len(rows)==3,'shape');a=ints(rows[1],n);b=ints(rows[2],m);require(all(1<=v<=10**9 for v in a+b),'times');return k,a,b
    if number==173:
        h,w,k=ints(rows[0],3);require(1<=h<=6 and 1<=w<=6 and 1<=k<=h*w and len(rows)==h+1,'shape');grid=tuple(rows[1:]);require(all(len(row)==w and set(row)<={'.','#'} for row in grid),'cells');return k,grid
    if number==175:
        require(len(rows)==1,'shape');x,k,d=ints(rows[0],3);require(-10**15<=x<=10**15 and 1<=k<=10**15 and 1<=d<=10**15,'moves');return x,k,d
    if number==179:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(2<=n<=1000000,'integer');return (n,)
    n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'heights');return (a,)

def row_subset_polynomial(k:int,grid:tuple[str,...])->int:
    width=len(grid[0]);masks=[sum((c=='#')<<j for j,c in enumerate(row)) for row in grid];answer=0
    for columns in range(1<<width):
        dp=[1]+[0]*k
        for row in masks:
            weight=(row&columns).bit_count();following=dp.copy()
            for count in range(k-weight+1):following[count+weight]+=dp[count]
            dp=following
        answer+=dp[k]
    return answer

def quotient_group_sum(limit:int)->int:
    start=1;answer=0
    while start<=limit:
        quotient=limit//start;end=limit//quotient;answer+=(end-start+1)*quotient;start=end+1
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==170:
        x,ps=cast(tuple[int,tuple[int,...]],data);ordered=sorted(ps);left=right=x
        while bisect_right(ordered,left)>0 and ordered[bisect_right(ordered,left)-1]==left:left-=1
        while bisect_right(ordered,right)>0 and ordered[bisect_right(ordered,right)-1]==right:right+=1
        return str(left if x-left<=right-x else right)
    if number==172:
        k,a,b=cast(tuple[int,tuple[int,...],tuple[int,...]],data);prefix=[0]
        for time in b:prefix.append(prefix[-1]+time)
        elapsed=0;best=bisect_right(prefix,k)-1
        for count,time in enumerate(a,1):
            elapsed+=time
            if elapsed>k:break
            best=max(best,count+bisect_right(prefix,k-elapsed)-1)
        return str(best)
    if number==173:return str(row_subset_polynomial(*cast(tuple[int,tuple[str,...]],data)))
    if number==175:
        x,k,d=cast(tuple[int,int,int],data);floor=(x+k*d)//(2*d);choices={0,k,max(0,min(k,floor)),max(0,min(k,floor+1))};return str(min(abs(x+(k-2*j)*d) for j in choices))
    if number==179:return str(quotient_group_sum(cast(int,data[0])-1))
    a=cast(tuple[int,...],data[0]);records=[(0,a[0])]
    for j,v in enumerate(a):
        if v>records[-1][1]:records.append((j,v))
    records.append((len(a),0));prefix=[0]
    for v in a:prefix.append(prefix[-1]+v)
    return str(sum(height*(end-start)-(prefix[end]-prefix[start]) for (start,height),(end,_) in zip(records,records[1:])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc170_c':"x,n=map(int,input().split());p=set(map(int,input().split())) if n else set();print(min((v for v in range(102) if v not in p),key=lambda v:(abs(x-v),v)))\n",
'abc172_c':"n,m,k=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));a=[0]+a;b=[0]+b\nfor j in range(1,n+1):a[j]+=a[j-1]\nfor j in range(1,m+1):b[j]+=b[j-1]\nright=m;best=0\nfor left in range(n+1):\n if a[left]>k:break\n while right>0 and a[left]+b[right]>k:right-=1\n if a[left]+b[right]<=k:best=max(best,left+right)\nprint(best)\n",
'abc173_c':"h,w,k=map(int,input().split());grid=[input() for _ in range(h)];answer=0\nfor rows in range(1<<h):\n for columns in range(1<<w):\n  black=sum(grid[r][c]=='#' and not(rows>>r&1) and not(columns>>c&1) for r in range(h) for c in range(w))\n  answer+=black==k\nprint(answer)\n",
'abc175_c':"x,k,d=map(int,input().split());x=abs(x);toward=min(k,x//d);x-=toward*d;k-=toward;print(x if k%2==0 else abs(x-d))\n",
'abc176_c':"n=int(input());a=list(map(int,input().split()));highest=0;answer=0\nfor height in a:highest=max(highest,height);answer+=highest-height\nprint(answer)\n",
'abc179_c':"n=int(input());print(sum((n-1)//a for a in range(1,n)))\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16200+number);raws:list[str]=[]
    if number==170:
        def forbidden(x:int,p:list[int])->str:return f'{x} {len(p)}\n'+line(p)
        raws=[forbidden(1,[]),forbidden(100,[]),forbidden(1,[1]),forbidden(100,[100]),forbidden(50,[50]),forbidden(50,[49,50,51])]+[forbidden(30+j,list(range(20,40+j))) for j in range(1,11)]+[forbidden(1,list(range(1,101))),forbidden(100,list(range(1,101)))]
    elif number==172:
        def books(k:int,a:list[int],b:list[int])->str:return f'{len(a)} {len(b)} {k}\n'+line(a)+line(b)
        raws=[books(1,[1],[1]),books(2,[1],[1]),books(1,[2],[2]),books(2,[2,1],[1,2])]+[books(10+j*3,[rng.randrange(1,21) for _ in range(j+1)],[rng.randrange(1,21) for _ in range(j+2)]) for j in range(1,13)]+[books(10**9,[1]*200000,[1]*200000),books(10**9,[10**9]*200000,[10**9]*200000)]
    elif number==173:
        def paint(k:int,grid:list[str])->str:return f'{len(grid)} {len(grid[0])} {k}\n'+'\n'.join(grid)+'\n'
        raws=[paint(1,['.']),paint(1,['#']),paint(2,['##']),paint(3,['##','##'])]
        while len(raws)<17:
            h=rng.randrange(1,7);w=rng.randrange(1,7);grid=[''.join(rng.choice('.#') for _ in range(w)) for _ in range(h)];raw=paint(rng.randrange(1,h*w+1),grid)
            if raw not in raws:raws.append(raw)
        raws.append(paint(36,['######']*6))
    elif number==175:raws=[line(t) for t in ((0,1,1),(1,1,1),(-1,1,1),(0,2,1),(6,2,4),(-6,2,4),(7,4,3),(10,1,2),(10**15,1,1),(-10**15,1,1),(1,10**15,1),(0,10**15,10**15),(0,10**15-1,10**15),(10**15,10**15,1),(-10**15,10**15,1),(10**15,1,10**15),(-10**15,10**15,10**15),(10**15,10**15,10**15))]
    elif number==176:
        def steps(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[steps([1]),steps([10**9]),steps([2,1]),steps([1,2])]+[steps([rng.randrange(1,101) for _ in range(n)]) for n in range(3,15)]+[steps([10**9]+[1]*199999),steps([10**9]*200000)]
    else:raws=[f'{n}\n' for n in (2,3,4,5,6,7,8,9,10,12,20,100,101,999,1000,999999,999983,1000000)]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc170_c':('禁止されていない整数を、Xとの差と値の小ささで比べます。','禁止値は1から100までなので、0から101までを調べれば答えが含まれます。','疑似コード: candidates=integers0..101 excluding P; print(argmin candidates by (abs(value-X),value))。'),
'abc172_c':('読む本は、両方の机の上から何冊かという形になります。','両方の累積和を作り、A側を増やしながらB側の冊数を減らす二本のポインタで調べます。','疑似コード: prefixA,prefixB=cumulative times; right=M; for left=0..N: while prefixA[left]+prefixB[right]>K and right>0: right-=1; if feasible: best=max(best,left+right); print(best)。'),
'abc173_c':('行と列が最大6つずつなので、選び方をすべて調べられます。','行マスクと列マスクを列挙し、どちらにも選ばれていない黒マスを数えます。','疑似コード: for row_mask in0..2^H-1: for column_mask in0..2^W-1: black=count unpainted black cells; if black==K: answer+=1; print(answer)。'),
'abc175_c':('まず原点へ近づけるだけ近づき、残りの移動は往復で消費できます。','abs(X)//D回まで近づくと、残り距離がD未満になります。残り回数の偶奇で、余りかD−余りのどちらかです。','疑似コード: X=abs(X); used=min(K,X//D); X-=used*D; remaining=K-used; print(X if remaining even else abs(X-D))。'),
'abc176_c':('各人は、それまでの最大身長以上にしなければなりません。','左から最大身長を更新し、現在の身長との差を踏み台の高さとして加算します。','疑似コード: maximum=answer=0; for height in A: maximum=max(maximum,height); answer+=maximum-height; print(answer)。'),
'abc179_c':('Aを決めると、Cが正になるBの個数を数えられます。','A×BはN−1以下なので、Bは1からfloor((N−1)/A)までです。','疑似コード: print(sum((N-1)//A for A=1..N-1))。')}

TITLES={'abc170_c': 'Forbidden List', 'abc172_c': 'Tsundoku', 'abc173_c': 'H and V', 'abc175_c': 'Walking Takahashi', 'abc176_c': 'Step', 'abc179_c': 'A x B + C'}
PUBLISHED_SAMPLES={'abc170_c': [{'input': '6 5\n4 7 10 6 5\n', 'expected': '8\n'}, {'input': '10 5\n4 7 10 6 5\n', 'expected': '9\n'}, {'input': '100 0\n', 'expected': '100\n'}], 'abc172_c': [{'input': '3 4 240\n60 90 120\n80 150 80 150\n', 'expected': '3\n'}, {'input': '3 4 730\n60 90 120\n80 150 80 150\n', 'expected': '7\n'}, {'input': '5 4 1\n1000000000 1000000000 1000000000 1000000000 1000000000\n1000000000 1000000000 1000000000 1000000000\n', 'expected': '0\n'}], 'abc173_c': [{'input': '2 3 2\n..#\n###\n', 'expected': '5\n'}, {'input': '2 3 4\n..#\n###\n', 'expected': '1\n'}, {'input': '2 2 3\n##\n##\n', 'expected': '0\n'}, {'input': '6 6 8\n..##..\n.#..#.\n#....#\n######\n#....#\n#....#\n', 'expected': '208\n'}], 'abc175_c': [{'input': '6 2 4\n', 'expected': '2\n'}, {'input': '7 4 3\n', 'expected': '1\n'}, {'input': '10 1 2\n', 'expected': '8\n'}, {'input': '1000000000000000 1000000000000000 1000000000000000\n', 'expected': '1000000000000000\n'}], 'abc176_c': [{'input': '5\n2 1 5 4 3\n', 'expected': '4\n'}, {'input': '5\n3 3 3 3 3\n', 'expected': '0\n'}], 'abc179_c': [{'input': '3\n', 'expected': '3\n'}, {'input': '100\n', 'expected': '473\n'}, {'input': '1000000\n', 'expected': '13969985\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
