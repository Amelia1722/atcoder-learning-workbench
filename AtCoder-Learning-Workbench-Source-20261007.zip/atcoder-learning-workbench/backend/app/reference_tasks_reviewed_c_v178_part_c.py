"""Private mixed C/D reviewed tasks; official legacy identifiers are preserved."""
from __future__ import annotations
from bisect import bisect_right
from collections import Counter
from functools import cache
from typing import cast
import random,re
TASKS=('abc473_c','abc474_c','abc475_c','abc476_c','abc001_4','abc002_4')
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' if p.endswith('_4') else 'C' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def minute(s:str)->int:
    require(re.fullmatch('[0-9]{4}',s) is not None,'time format');h,m=int(s[:2]),int(s[2:]);require(0<=h<=24 and 0<=m<60 and (h<24 or m==0),'time domain');return 60*h+m
def clock(t:int)->str:return f'{t//60:02}{t%60:02}'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc473_c':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=k<=n<=200000 and all(1<=v<=k for v in a),'domain');return k,a
    if pid=='abc474_c':
        n,q=ints(rows[0],2);require(1<=n<=200000 and 1<=q<=200000 and len(rows)==q+2,'shape');p=ints(rows[1],n);a=tuple(ints(row,1)[0] for row in rows[2:]);require(set(p)==set(range(1,n+1)) and all(1<=v<=n for v in a),'permutation/queries');return p,a
    if pid=='abc475_c':
        require(len(rows)==2,'shape');n,s,l=ints(rows[0],3);a=ints(rows[1],n-1);require(2<=n<=8000 and 1<=s<=n and 0<=l<=10**18 and all(1<=v<=10**9 for v in a),'domain');return s,l,a
    if pid=='abc476_c':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(3<=n<=500000 and all(1<=v<=10**9 for v in a),'domain');return (a,)
    if pid=='abc001_4':
        n=ints(rows[0],1)[0];require(1<=n<=30000 and len(rows)==n+1,'shape');a=[]
        for row in rows[1:]:
            require(re.fullmatch('[0-9]{4}-[0-9]{4}',row) is not None,'time interval');s,e=minute(row[:4]),minute(row[5:]);require(s<e,'positive interval');a.append((s,e))
        return (tuple(a),)
    n,m=ints(rows[0],2);require(1<=n<=12 and 0<=m<=n*(n-1)//2 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=u<v<=n for u,v in a) and len(set(a))==m,'edges');return n,a
class Fenwick:
    def __init__(self,n:int)->None:self.tree=[0]*(n+1)
    def add(self,j:int)->None:
        while j<len(self.tree):self.tree[j]+=1;j+=j&-j
    def kth(self,k:int)->int:
        j=0;step=1<<(len(self.tree).bit_length()-1)
        while step:
            nxt=j+step
            if nxt<len(self.tree) and self.tree[nxt]<k:k-=self.tree[nxt];j=nxt
            step//=2
        return j+1
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc473_c':
        k,a=cast(tuple[int,tuple[int,...]],data);freq=Counter(a);counts=[freq[j] for j in range(1,k+1)];left=[0];right=[0]*(k+1)
        for count in counts:left.append(max(left[-1],count))
        for j in range(k-1,-1,-1):right[j]=max(right[j+1],counts[j])
        return str(sum(count+1>=max(left[j],right[j+1]) for j,count in enumerate(counts)))
    if pid=='abc474_c':
        p,a=cast(tuple[tuple[int,...],tuple[int,...]],data);n=len(p);before=[0]*(n+1);after=[0]*(n+1)
        for j,v in enumerate(p):before[v]=p[j-1] if j else 0;after[v]=p[j+1] if j+1<n else 0
        head,tail=p[0],p[-1]
        for v in a:
            if v==tail:continue
            prev,nxt=before[v],after[v]
            if prev:after[prev]=nxt
            else:head=nxt
            before[nxt]=prev;after[tail]=v;before[v]=tail;after[v]=0;tail=v
        out=[]
        while head:out.append(head);head=after[head]
        return ' '.join(map(str,out))
    if pid=='abc475_c':
        s,budget,a=cast(tuple[int,int,tuple[int,...]],data);position=[0]
        for distance in a:position.append(position[-1]+distance)
        origin=position[s-1];left=[origin-position[j] for j in range(s-1,-1,-1)];right=[position[j]-origin for j in range(s-1,len(position))];best=1
        for distances,other in ((left,right),(right,left)):
            for j,d in enumerate(distances):
                remaining=budget-2*d
                if remaining>=0:best=max(best,j+bisect_right(other,remaining))
        return str(best)
    if pid=='abc476_c':
        a=cast(tuple[int,...],data[0]);values=sorted(set(a));ranks={v:j+1 for j,v in enumerate(values)};tree=Fenwick(len(values));out=[]
        for j,v in enumerate(a,1):
            tree.add(ranks[v])
            if j>=3:out.append(str(values[tree.kth(j-2)-1]))
        return '\n'.join(out)
    if pid=='abc001_4':
        a=cast(tuple[tuple[int,int],...],data[0]);wet=[False]*288
        for s,e in a:
            for slot in range(s//5,(e+4)//5):wet[slot]=True
        out=[];start=-1
        for j,active in enumerate(wet+[False]):
            if active and start<0:start=j
            if not active and start>=0:out.append(clock(5*start)+'-'+clock(5*j));start=-1
        return '\n'.join(out)
    n,a=cast(tuple[int,tuple[tuple[int,int],...]],data);edges=set(a);conflicts=[(u-1,v-1) for u in range(1,n+1) for v in range(u+1,n+1) if (u,v) not in edges]
    @cache
    def cover(mask:int)->int:
        for u,v in conflicts:
            if mask>>u&1 and mask>>v&1:return 1+min(cover(mask&~(1<<u)),cover(mask&~(1<<v)))
        return 0
    return str(n-cover((1<<n)-1))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc473_c':"n,k=map(int,input().split());a=list(map(int,input().split()));freq=[0]*k\nfor v in a:freq[v-1]+=1\nmaximum=max(freq);print(sum(v>=maximum-1 for v in freq))\n",
'abc474_c':"n,q=map(int,input().split());p=list(map(int,input().split()));last=[-1]*(n+1)\nfor j in range(q):last[int(input())]=j\nprint(*([v for v in p if last[v]<0]+sorted((v for v in p if last[v]>=0),key=lambda v:last[v])))\n",
'abc475_c':"n,s,l=map(int,input().split());a=list(map(int,input().split()));pos=[0]\nfor v in a:pos.append(pos[-1]+v)\norigin=pos[s-1];best=1\nfor left in range(s):\n dl=origin-pos[left]\n for right in range(s-1,n):\n  dr=pos[right]-origin\n  if dl+dr+min(dl,dr)<=l:best=max(best,right-left+1)\n  else:break\nprint(best)\n",
'abc476_c':"from heapq import heappush,heapreplace\nn=int(input());a=list(map(int,input().split()));heap=[]\nfor v in a:\n if len(heap)<3:heappush(heap,v)\n elif v>heap[0]:heapreplace(heap,v)\n if len(heap)==3:print(heap[0])\n",
'abc001_4':"n=int(input());intervals=[]\nfor _ in range(n):\n s,e=input().split('-');s=int(s[:2])*60+int(s[2:]);e=int(e[:2])*60+int(e[2:]);intervals.append((s//5*5,(e+4)//5*5))\nmerged=[]\nfor s,e in sorted(intervals):\n if merged and s<=merged[-1][1]:merged[-1][1]=max(e,merged[-1][1])\n else:merged.append([s,e])\nfor s,e in merged:print(f'{s//60:02}{s%60:02}-{e//60:02}{e%60:02}')\n",
'abc002_4':"n,m=map(int,input().split());edges=set()\nfor _ in range(m):u,v=map(int,input().split());edges.add((u-1,v-1))\nbest=1\nfor mask in range(1,1<<n):\n members=[j for j in range(n) if mask>>j&1]\n if all((u,v) in edges for j,u in enumerate(members) for v in members[j+1:]):best=max(best,len(members))\nprint(best)\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(17800+int(pid[3:6]))
    if pid=='abc473_c':
        def school(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[school(k,a) for k,a in ((1,[1]),(2,[1,1]),(2,[1,2]),(3,[1,1,1]))];raws.extend(school(n,[rng.randint(1,n) for _ in range(n)]) for n in range(3,15));raws.extend([school(200000,[1]*200000),school(200000,list(range(1,200001)))])
    elif pid=='abc474_c':
        def move(p:list[int],a:list[int])->str:return f'{len(p)} {len(a)}\n'+line(p)+''.join(f'{v}\n' for v in a)
        raws=[move(p,a) for p,a in (([1],[1]),([1,2],[1]),([2,1],[1]),([1,2,3],[1,2,1]))]
        for n in range(3,15):p=list(range(1,n+1));rng.shuffle(p);raws.append(move(p,[rng.randint(1,n) for _ in range(25)]))
        raws.extend([move(list(range(1,200001)),[1]*200000),move(list(range(200000,0,-1)),list(range(1,200001)))])
    elif pid=='abc475_c':
        def walk(s:int,l:int,a:list[int])->str:return f'{len(a)+1} {s} {l}\n'+line(a)
        raws=[walk(s,l,a) for s,l,a in ((1,0,[1]),(1,1,[1]),(2,1,[1]),(2,3,[1,1]))];raws.extend(walk(rng.randint(1,n),rng.randint(0,1000),[rng.randint(1,100) for _ in range(n-1)]) for n in range(3,15));raws.extend([walk(4000,3999,[1]*7999),walk(4000,10**18,[10**9]*7999)])
    elif pid=='abc476_c':
        def third(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[third(a) for a in ([1,1,1],[1,2,3],[3,2,1],[3,3,2,3])];raws.extend(third([rng.randint(1,20) for _ in range(n)]) for n in range(5,17));raws.extend([third(list(range(1,500001))),third([10**9]*500000)])
    elif pid=='abc001_4':
        def rain(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(clock(s)+'-'+clock(e)+'\n' for s,e in a)
        raws=[rain(a) for a in ([(0,1)],[(1439,1440)],[(59,61)],[(0,5),(5,10)])]
        for n in range(3,15):
            a=[]
            for _ in range(n):s=rng.randrange(1440);a.append((s,rng.randint(s+1,1440)))
            raws.append(rain(a))
        raws.extend([rain([(j,j+1) for j in range(0,1440,10)]*208+[(0,1)]*48),rain([(0,1440)]*30000)])
    else:
        def clique(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{u} {v}\n' for u,v in a)
        raws=[clique(n,a) for n,a in ((1,[]),(2,[]),(2,[(1,2)]),(3,[(1,2),(2,3)]))]
        for j in range(12):
            n=4+j//2;edges=[(u,v) for u in range(1,n+1) for v in range(u+1,n+1)];raws.append(clique(n,rng.sample(edges,min(len(edges),j+2))))
        raws.extend([clique(12,[]),clique(12,[(u,v) for u in range(1,13) for v in range(u+1,13)])])
    require(len(raws)==len(set(raws))==18,'unique');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc473_c':('入ったクラスだけ人数が1人増えます。','各クラス人数が元の最大人数−1以上なら、入った後に最大人数へ届きます。','疑似コード: freq[A[i]-1]++; maximum=max(freq); freq>=maximum-1のクラス数を出力。'),
'abc474_c':('一度も動かない要素と、動いた要素を分けて考えます。','未操作の要素は元の順、操作済みの要素は最後に操作された時刻の順になります。','疑似コード: last[value]=最後のquery添字; 元Pの未操作要素を並べ、操作済み要素をlast昇順sortして後ろへ連結。'),
'abc475_c':('訪れる街はSを含む連続区間です。','左右端までの距離をdl,drとすると、必要な最小移動距離はdl+dr+min(dl,dr)です。','疑似コード: prefix距離; left<=S<=rightを全列挙しcost=dl+dr+min(dl,dr); cost<=Lなら区間長でbest更新。'),
'abc476_c':('上位3個だけ残せば、各prefixの答えが分かります。','サイズ3の最小heapで上位3個を持ちます。新しい値が最小より大きければ入れ替えます。','疑似コード: 各Aをheapへ追加（サイズ3未満）; サイズ3ならA>heap最小時のみ置換; 3個揃った各時点のheap最小を出力。'),
'abc001_4':('時刻を分へ直すと、5分単位の丸めと比較が簡単です。','開始を切り下げ、終了を切り上げ、開始順にsortして重なるか接する区間を併合します。','疑似コード: start=(分//5)*5; end=((分+4)//5)*5; sort後start<=末尾endならend=max更新、他は追加; HHMM-HHMM形式で出力。'),
'abc002_4':('Nが12以下なので、議員の部分集合を全て試せます。','各集合の全ての2人が知り合いなら派閥を作れます。最大の集合サイズを求めます。','疑似コード: mask=1..2^N-1; 含まれる全pairがedgeか確認; 全てあるならbest=max(best,popcount(mask)); best出力。')}

TITLES={'abc473_c': 'Change Schools', 'abc474_c': 'Remove and Append', 'abc475_c': 'Walk the Line', 'abc476_c': 'Third Largest Number', 'abc001_4': '感雨時刻の整理', 'abc002_4': '派閥'}
PUBLISHED_SAMPLES={'abc473_c': [{'input': '8 5\n3 3 5 5 4 4 3 2\n', 'expected': '3\n'}, {'input': '6 1\n1 1 1 1 1 1\n', 'expected': '1\n'}, {'input': '14 8\n6 1 5 3 8 4 3 4 3 5 1 2 5 1\n', 'expected': '4\n'}], 'abc474_c': [{'input': '4 2\n2 4 3 1\n3\n2\n', 'expected': '4 1 3 2\n'}, {'input': '3 3\n1 2 3\n1\n1\n1\n', 'expected': '2 3 1\n'}, {'input': '2 5\n2 1\n1\n1\n2\n2\n1\n', 'expected': '2 1\n'}], 'abc475_c': [{'input': '6 3 10\n5 2 4 1 6\n', 'expected': '4\n'}, {'input': '8 8 17\n2 3 4 4 3 5 1\n', 'expected': '6\n'}, {'input': '2 1 1000000000000000000\n10000\n', 'expected': '2\n'}, {'input': '9 6 28\n5 4 9 2 3 6 1 4\n', 'expected': '6\n'}], 'abc476_c': [{'input': '5\n1 2 1 2 3\n', 'expected': '1\n1\n2\n'}, {'input': '10\n1 1 1 3 2 5 4 3 6 5\n', 'expected': '1\n1\n1\n2\n3\n3\n4\n5\n'}, {'input': '10\n11 9 1 3 17 19 10 19 17 3\n', 'expected': '1\n3\n9\n11\n11\n17\n17\n17\n'}], 'abc001_4': [{'input': '4\n1148-1210\n1323-1401\n1106-1123\n1129-1203\n', 'expected': '1105-1210\n1320-1405\n'}, {'input': '1\n0000-2400\n', 'expected': '0000-2400\n'}, {'input': '6\n1157-1306\n1159-1307\n1158-1259\n1230-1240\n1157-1306\n1315-1317\n', 'expected': '1155-1310\n1315-1320\n'}], 'abc002_4': [{'input': '5 3\n1 2\n2 3\n1 3\n', 'expected': '3\n'}, {'input': '5 3\n1 2\n2 3\n3 4\n', 'expected': '2\n'}, {'input': '7 9\n1 2\n1 3\n2 3\n4 5\n4 6\n4 7\n5 6\n5 7\n6 7\n', 'expected': '4\n'}, {'input': '12 0\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
