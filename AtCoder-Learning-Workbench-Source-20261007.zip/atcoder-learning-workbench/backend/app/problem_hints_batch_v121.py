"""Statement-checked three-stage hints for ABC221–223 B."""
HINTS_V121 = {
    'abc221_b': (
        '操作できるのは隣り合う2文字の交換を高々1回だけです。まずSとTが最初から同じなら、その時点でYesです。',
        'Sの各隣接位置 i, i+1 を1つずつ交換してTと一致するか試しても、長さは最大100なので十分高速です。',
        '''疑似コード:\nif S == T:\n  print Yes\nelse:\n  for i = 0 .. len(S)-2:\n    U = copy of S\n    swap U[i], U[i+1]\n    if U == T:\n      print Yes and stop\n  print No''',
    ),
    'abc222_b': (
        '「不可」になる条件は点数がP点未満です。P点ちょうどは不可ではありません。',
        'Aを1回走査し、`a < P` を満たす要素の個数だけ数えればよいです。',
        '''疑似コード:\nanswer = 0\nfor a in A:\n  if a < P:\n    answer += 1\nprint answer''',
    ),
    'abc223_b': (
        '左シフトと右シフトを何回しても、得られるのはSの巡回シフトだけです。異なる開始位置を全て候補にできます。',
        '各iについて `S[i:] + S[:i]` を作れば全巡回シフトを列挙できます。その中の辞書順最小・最大を取ります。',
        '''疑似コード:\nrotations = empty list\nfor i = 0 .. len(S)-1:\n  append S[i:] + S[:i] to rotations\nprint minimum(rotations)\nprint maximum(rotations)''',
    ),
}
