"""ABC125–127 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc125_b', 'abc126_b', 'abc127_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
DIGITS4 = re.compile(r'[0-9]{4}', re.ASCII)


def _split_positive(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(token) is None for token in parts):
        raise ValueError('noncanonical positive integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc125_b':
        if len(lines) != 3 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and two rows')
        n = int(lines[0])
        if not 1 <= n <= 20:
            raise ValueError('N range')
        values = _split_positive(lines[1], n)
        costs = _split_positive(lines[2], n)
        if any(not 1 <= x <= 50 for x in values + costs):
            raise ValueError('value/cost range')
        return values, costs

    if pid == 'abc126_b':
        if len(lines) != 1 or DIGITS4.fullmatch(lines[0]) is None:
            raise ValueError('S must be exactly four ASCII digits')
        return lines[0]

    if len(lines) != 1:
        raise ValueError('one input line required')
    values = _split_positive(lines[0], 3)
    r, d, x = values
    if not 2 <= r <= 5 or not 1 <= d <= 100 or not d < x <= 200:
        raise ValueError('r/D/x range')
    return r, d, x


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc125_b':
        if output != '0' and POS.fullmatch(output) is None:
            return False
        values, costs = value
        # Subset-sum style state expansion checks all obtainable X-Y totals,
        # rather than reusing the optimized sum(max(0, V_i-C_i)) formula.
        reachable = {0}
        for v, c in zip(values, costs):
            delta = v - c
            reachable |= {score + delta for score in tuple(reachable)}
        return output == str(max(reachable))

    if pid == 'abc126_b':
        if output not in {'YYMM', 'MMYY', 'AMBIGUOUS', 'NA'}:
            return False
        s = value
        # Enumerate the two format languages explicitly instead of using the
        # reference implementation's direct 1..12 numeric tests.
        yymm = {f'{year:02d}{month:02d}' for year in range(100) for month in range(1, 13)}
        mmyy = {f'{month:02d}{year:02d}' for year in range(100) for month in range(1, 13)}
        left = s in yymm
        right = s in mmyy
        expected = 'AMBIGUOUS' if left and right else ('YYMM' if left else ('MMYY' if right else 'NA'))
        return output == expected

    r, d, x0 = value
    rows = output.split('\n')
    if len(rows) != 10 or any(POS.fullmatch(row) is None for row in rows):
        return False
    actual = list(map(int, rows))
    # Closed form of x_n = r*x_{n-1}-D, independent of iterative reference code.
    expected = [pow(r, n) * x0 - d * (pow(r, n) - 1) // (r - 1) for n in range(1, 11)]
    return actual == expected


def _gem(values: list[int], costs: list[int]) -> str:
    return f'{len(values)}\n' + ' '.join(map(str, values)) + '\n' + ' '.join(map(str, costs)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc125_b':
        fixed = [
            ('sample1', [10, 2, 5], [6, 3, 4]),
            ('sample2', [13, 21, 6, 19], [11, 30, 6, 15]),
            ('sample3', [1], [50]),
            ('single_profit', [50], [1]),
            ('single_equal', [1], [1]),
            ('all_losses', [1, 2, 3, 4], [5, 6, 7, 8]),
            ('all_profits', [5, 6, 7, 8], [1, 2, 3, 4]),
            ('mixed_zero', [10, 20, 30], [10, 1, 50]),
            ('alternating', [50, 1, 50, 1, 50, 1], [1, 50, 1, 50, 1, 50]),
            ('duplicates', [25] * 6, [20, 25, 30, 20, 25, 30]),
            ('ascending_vs_desc', list(range(1, 21)), list(range(20, 0, -1))),
            ('near_upper', [50, 49, 48, 47, 46], [49, 48, 47, 46, 45]),
            ('one_winner', [1] * 19 + [50], [50] * 19 + [1]),
            ('one_loser', [50] * 19 + [1], [1] * 19 + [50]),
            ('twenty_equal', [50] * 20, [50] * 20),
            ('twenty_small_profit', [2] * 20, [1] * 20),
            ('twenty_small_loss', [1] * 20, [2] * 20),
        ]
        for category, values, costs in fixed:
            add(category, _gem(values, costs))
        add('constraint_max', _gem([50] * 20, [1] * 20))

    elif pid == 'abc126_b':
        fixed = [
            ('sample1', '1905'), ('sample2', '0112'), ('sample3', '1700'),
            ('both_zero', '0000'), ('yymm_january', '0001'), ('yymm_december', '0012'),
            ('mmyy_january', '0100'), ('ambiguous_low', '0101'), ('ambiguous_high', '1212'),
            ('mmyy_year99', '1299'), ('yymm_year99', '9912'), ('both_invalid_mid', '1313'),
            ('month13_left', '1301'), ('month13_right', '0113'), ('leading_zero_year', '0501'),
            ('leading_zero_month', '0105'), ('boundary_12_00', '1200'),
        ]
        for category, s in fixed:
            add(category, s + '\n')
        add('constraint_max', '9999\n')

    else:
        fixed = [
            ('sample1', (2, 10, 20)), ('sample2', (4, 40, 60)),
            ('min_r_min_d', (2, 1, 2)), ('min_r_near_max_x', (2, 1, 200)),
            ('min_r_max_d_min_x', (2, 100, 101)), ('min_r_max_d_max_x', (2, 100, 200)),
            ('max_r_min_d_min_x', (5, 1, 2)), ('max_r_min_d_max_x', (5, 1, 200)),
            ('max_r_max_d_min_x', (5, 100, 101)), ('max_r_mid_d_max_x', (5, 50, 200)),
            ('middle1', (3, 20, 21)), ('middle2', (3, 99, 100)),
            ('middle3', (4, 1, 2)), ('middle4', (4, 100, 200)),
            ('d_just_below_x', (2, 99, 100)), ('d_just_below_x_max_r', (5, 99, 100)),
            ('mixed', (3, 73, 150)),
        ]
        for category, (r, d, x) in fixed:
            add(category, f'{r} {d} {x}\n')
        add('constraint_max', '5 100 200\n')

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
