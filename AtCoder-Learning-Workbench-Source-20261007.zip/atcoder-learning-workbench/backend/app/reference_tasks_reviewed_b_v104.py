"""ABC170–172 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc170_b', 'abc171_b', 'abc172_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc170_b': [
        {'input':'3 8\n','expected':'Yes\n'},
        {'input':'2 100\n','expected':'No\n'},
        {'input':'1 2\n','expected':'Yes\n'},
    ],
    'abc171_b': [
        {'input':'5 3\n50 100 80 120 80\n','expected':'210\n'},
        {'input':'1 1\n1000\n','expected':'1000\n'},
    ],
    'abc172_b': [
        {'input':'cupofcoffee\ncupofhottea\n','expected':'4\n'},
        {'input':'abcde\nbcdea\n','expected':'5\n'},
        {'input':'apple\napple\n','expected':'0\n'},
    ],
}


def _canon_pos_row(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical positive integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc170_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        x, y = _canon_pos_row(lines[0], 2)
        if not (1 <= x <= 100 and 1 <= y <= 100):
            raise ValueError('range')
        return x, y
    if pid == 'abc171_b':
        if len(lines) != 2:
            raise ValueError('expected two rows')
        n, k = _canon_pos_row(lines[0], 2)
        if not (1 <= k <= n <= 1000):
            raise ValueError('N/K range')
        prices = _canon_pos_row(lines[1], n)
        if any(p > 1000 for p in prices):
            raise ValueError('price range')
        return n, k, prices
    if len(lines) != 2 or LOWER.fullmatch(lines[0]) is None or LOWER.fullmatch(lines[1]) is None:
        raise ValueError('expected two lowercase strings')
    s, t = lines
    if len(s) != len(t) or not (1 <= len(s) <= 200_000):
        raise ValueError('length range')
    return s, t


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc170_b':
        if output not in ('Yes', 'No'):
            return False
        x, y = value
        expected = (y % 2 == 0 and 2*x <= y <= 4*x)
        return output == ('Yes' if expected else 'No')
    if not re.fullmatch(r'0|[1-9][0-9]*', output, re.ASCII):
        return False
    if pid == 'abc171_b':
        _, k, prices = value
        return output == str(sum(sorted(prices)[:k]))
    s, t = value
    return output == str(sum(a != b for a, b in zip(s, t)))


def _170(x:int, y:int)->str:
    return f'{x} {y}\n'

def _171(n:int, k:int, prices:list[int])->str:
    assert n == len(prices)
    return f'{n} {k}\n' + ' '.join(map(str, prices)) + '\n'

def _172(s:str, t:str)->str:
    return f'{s}\n{t}\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category:str, raw:str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid == 'abc170_b':
        vals=[
            ('sample1',3,8),('sample2',2,100),('sample3',1,2),
            ('one_turtle',1,4),('odd_legs',1,3),('too_few_legs',1,1),
            ('all_cranes',25,50),('all_turtles',25,100),('mixed_even',24,72),
            ('odd_inside_range',24,73),('below_min_even',24,46),('above_max_even',24,98),
            ('x50_y100',50,100),('x50_y99',50,99),('x51_y100',51,100),
            ('small_mixed',2,6),('near_upper',24,94),
        ]
        for cat,x,y in vals: add(cat,_170(x,y))
        add('constraint_max',_170(100,100))
    elif pid == 'abc171_b':
        vals=[
            ('sample1',5,3,[50,100,80,120,80]),('sample2',1,1,[1000]),
            ('single_min',1,1,[1]),('choose_one',5,1,[5,4,3,2,1]),
            ('choose_all',5,5,[5,4,3,2,1]),('duplicates',6,3,[10,10,10,20,20,30]),
            ('already_sorted',6,4,[1,2,3,4,5,6]),('reverse_sorted',6,4,[6,5,4,3,2,1]),
            ('all_equal',8,5,[7]*8),('max_prices_choose_one',10,1,[1000]*10),
            ('mixed_extremes',7,4,[1,1000,2,999,3,998,4]),
            ('k_n_minus_one',6,5,[100,200,300,400,500,600]),
            ('n1000_k1',1000,1,list(range(1,1001))),
            ('n1000_k999',1000,999,list(range(1,1001))),
            ('n1000_duplicates',1000,500,[1]*500+[1000]*500),
            ('n999_k500',999,500,[((i*37)%1000)+1 for i in range(999)]),
            ('large_all_one',1000,999,[1]*1000),
        ]
        for cat,n,k,p in vals: add(cat,_171(n,k,p))
        add('constraint_max',_171(1000,1000,[1000]*1000))
    else:
        vals=[
            ('sample1','cupofcoffee','cupofhottea'),('sample2','abcde','bcdea'),('sample3','apple','apple'),
            ('one_same','a','a'),('one_diff','a','z'),('all_same','aaaaaa','aaaaaa'),
            ('all_diff','aaaaaa','bbbbbb'),('one_middle_diff','abcde','abzde'),
            ('alternating','abababab','babababa'),('alphabet_shift','abcdefghijklmnopqrstuvwxyz','bcdefghijklmnopqrstuvwxyza'),
            ('len100_same','a'*100,'a'*100),('len100_one_diff','a'*99+'b','a'*100),
            ('len100_all_diff','a'*100,'z'*100),('len999_pattern','abc'*333,'abd'*333),
            ('len1000_half', 'a'*500+'b'*500, 'a'*500+'c'*500),
            ('len199999_one_diff','a'*199998+'b','a'*199999),
            ('len200000_same','x'*200000,'x'*200000),
        ]
        for cat,s,t in vals: add(cat,_172(s,t))
        add('constraint_max',_172('a'*200000,'b'*200000))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
