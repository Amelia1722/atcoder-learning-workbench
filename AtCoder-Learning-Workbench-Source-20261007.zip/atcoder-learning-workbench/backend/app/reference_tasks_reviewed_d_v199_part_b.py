from __future__ import annotations
from bisect import bisect_right
from functools import lru_cache
from itertools import combinations
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{i}_d' for i in range(377,383));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:tuple[int,...]|list[int])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc377_d':
  n,m=ints(r[0],2);require(1<=n<=200000 and 1<=m<=200000 and len(r)==n+1,'shape');segments=tuple(ints(row,2) for row in r[1:]);require(all(1<=l<=rr<=m for l,rr in segments),'segments');return m,segments
 if pid=='abc378_d':
  h,w,k=ints(r[0],3);grid=tuple(r[1:]);require(1<=h<=10 and 1<=w<=10 and 1<=k<=11 and len(grid)==h and all(re.fullmatch('[.#]{'+str(w)+'}',row) for row in grid) and any('.' in row for row in grid),'grid');return k,grid
 if pid=='abc379_d':
  q=ints(r[0],1)[0];queries=tuple(ints(row) for row in r[1:]);require(1<=q<=200000 and len(queries)==q and any(row[0]==3 for row in queries),'queries');require(all(row==(1,) or len(row)==2 and row[0] in (2,3) and 1<=row[1]<=10**9 for row in queries),'querydomain');return (queries,)
 if pid=='abc380_d':
  require(len(r)==3 and re.fullmatch('[A-Za-z]{1,200000}',r[0]) is not None,'string');q=ints(r[1],1)[0];queries=ints(r[2],q);require(1<=q<=200000 and all(1<=k<=10**18 for k in queries),'queries');return r[0],queries
 if pid=='abc381_d':
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)==2,'N');a=ints(r[1],n);require(all(1<=v<=n for v in a),'Ai');return (a,)
 require(len(r)==1,'rows');n,m=ints(r[0],2);require(2<=n<=12 and 10*n-9<=m<=10*n,'NM');return n,m

def segments_reverse_left(m:int,segments:tuple[tuple[int,...],...])->int:
 best=[m+1]*(m+1)
 for left,right in segments:best[left]=min(best[left],right)
 minimum=m+1;answer=0
 for left in range(m,0,-1):minimum=min(minimum,best[left]);answer+=minimum-left
 return answer

@lru_cache(None)
def relative_walks(k:int)->tuple[tuple[tuple[int,int],...],...]:
 results=[];path=[(0,0)];seen={(0,0)}
 def visit()->None:
  if len(path)==k+1:results.append(tuple(path));return
  x,y=path[-1]
  for point in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
   if point not in seen:seen.add(point);path.append(point);visit();path.pop();seen.remove(point)
 visit();return tuple(results)

def translated_simple_walks(k:int,grid:tuple[str,...])->int:
 h,w=len(grid),len(grid[0]);free=sum(1<<(i*w+j) for i,row in enumerate(grid) for j,char in enumerate(row) if char=='.');answer=0
 for path in relative_walks(k):
  minr=min(r for r,c in path);maxr=max(r for r,c in path);minc=min(c for r,c in path);maxc=max(c for r,c in path)
  if maxr-minr>=h or maxc-minc>=w:continue
  colmask=((1<<(w-maxc+minc))-1)<<(-minc);valid=sum(colmask<<(r*w) for r in range(-minr,h-maxr))
  for row,col in path:
   delta=row*w+col;valid&=free>>delta if delta>=0 else free<<(-delta)
   if not valid:break
  answer+=valid.bit_count()
 return answer

def garden_historical_rank(queries:tuple[tuple[int,...],...])->list[int]:
 planted=[];time=0;removed=0;answer=[]
 for row in queries:
  if row[0]==1:planted.append(time)
  elif row[0]==2:time+=row[1]
  else:eligible=bisect_right(planted,time-row[1]);answer.append(max(0,eligible-removed));removed=max(removed,eligible)
 return answer

def recursive_mirror_queries(s:str,queries:tuple[int,...])->list[str]:
 lengths=[len(s)]
 while lengths[-1]<max(queries):lengths.append(2*lengths[-1])
 result=[]
 for k in queries:
  position=k-1;flipped=False
  for half in reversed(lengths[:-1]):
   if position>=half:position-=half;flipped=not flipped
  char=s[position];result.append(char.swapcase() if flipped else char)
 return result

def paired_window_feasible(a:tuple[int,...],length:int)->bool:
 if length==0:return True
 for parity in (0,1):
  pairs=[a[i] if a[i]==a[i+1] else 0 for i in range(parity,len(a)-1,2)];counts:dict[int,int]={};duplicates=0;invalid=0
  for i,value in enumerate(pairs):
   if value==0:invalid+=1
   else:
    counts[value]=counts.get(value,0)+1
    if counts[value]==2:duplicates+=1
   if i>=length:
    old=pairs[i-length]
    if old==0:invalid-=1
    else:
     if counts[old]==2:duplicates-=1
     counts[old]-=1
   if i>=length-1 and invalid==0 and duplicates==0:return True
 return False

def longest_pairs_feasibility(a:tuple[int,...])->int:
 low=0;high=len(a)//2+1
 while high-low>1:
  mid=(high+low)//2
  if paired_window_feasible(a,mid):low=mid
  else:high=mid
 return 2*low

def distance_combinations(n:int,m:int)->str:
 top=m-9*(n-1);count=comb(top,n);rows=[str(count)]
 for values in combinations(range(1,top+1),n):rows.append(' '.join(str(v+9*i) for i,v in enumerate(values)))
 return '\n'.join(rows)+'\n'

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc377_d':return str(segments_reverse_left(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))+'\n'
 if pid=='abc378_d':return str(translated_simple_walks(cast(int,d[0]),cast(tuple[str,...],d[1])))+'\n'
 if pid=='abc379_d':return ''.join(str(v)+'\n' for v in garden_historical_rank(cast(tuple[tuple[int,...],...],d[0])))
 if pid=='abc380_d':return ' '.join(recursive_mirror_queries(cast(str,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc381_d':return str(longest_pairs_feasibility(cast(tuple[int,...],d[0])))+'\n'
 return distance_combinations(cast(int,d[0]),cast(int,d[1]))
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={
'abc377_d':'''n,m=map(int,input().split());starts=[0]*(m+1)
for _ in range(n):l,r=map(int,input().split());starts[r]=max(starts[r],l)
left=0;answer=0
for r in range(1,m+1):left=max(left,starts[r]);answer+=r-left
print(answer)
''',
'abc378_d':'''h,w,k=map(int,input().split());g=[input() for _ in range(h)];neighbors=[[] for _ in range(h*w)]
for i in range(h):
 for j in range(w):
  if g[i][j]=='#':continue
  for x,y in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
   if 0<=x<h and 0<=y<w and g[x][y]=='.':neighbors[i*w+j].append(x*w+y)
visited=[False]*(h*w)
def dfs(p,remaining):
 if remaining==0:return 1
 count=0
 for q in neighbors[p]:
  if not visited[q]:visited[q]=True;count+=dfs(q,remaining-1);visited[q]=False
 return count
answer=0
for p in range(h*w):
 if g[p//w][p%w]=='.':visited[p]=True;answer+=dfs(p,k);visited[p]=False
print(answer)
''',
'abc379_d':'''from collections import deque
q=int(input());time=0;planted=deque()
for _ in range(q):
 row=list(map(int,input().split()))
 if row[0]==1:planted.append(time)
 elif row[0]==2:time+=row[1]
 else:
  answer=0
  while planted and time-planted[0]>=row[1]:planted.popleft();answer+=1
  print(answer)
''',
'abc380_d':'''s=input();q=int(input());queries=list(map(int,input().split()));out=[]
for k in queries:
 block,pos=divmod(k-1,len(s));c=s[pos];out.append(c.swapcase() if block.bit_count()%2 else c)
print(' '.join(out))
''',
'abc381_d':'''n=int(input());a=list(map(int,input().split()));best=0
for parity in (0,1):
 left=parity;previous={}
 for i in range(parity,n-1,2):
  if a[i]!=a[i+1]:left=i+2;continue
  left=max(left,previous.get(a[i],-2)+2);previous[a[i]]=i;best=max(best,i+2-left)
print(best)
''',
'abc382_d':'''import sys
n,m=map(int,input().split());out=[];path=[]
def dfs(low):
 if len(path)==n:out.append(' '.join(map(str,path)));return
 maximum=m-10*(n-len(path)-1)
 for v in range(low,maximum+1):path.append(v);dfs(v+10);path.pop()
dfs(1);sys.stdout.write(str(len(out))+'\\n'+'\\n'.join(out)+'\\n')
'''}
def generate(pid:str)->list[Case]:
 rng=random.Random(199000+TASKS.index(pid));raws=[]
 if pid=='abc377_d':
  configs=[(1,((1,1),)),(2,((1,1),)),(2,((1,2),)),(3,((2,2),)),(4,((1,2),(3,4))),(5,((1,5),)*3)]
  for m in (6,7,8,9,10,17,100,1000,5000,10000):
   segments=[]
   for _ in range(min(m,100)):
    a,b=sorted((rng.randint(1,m),rng.randint(1,m)));segments.append((a,b))
   configs.append((m,tuple(segments)))
  configs += [(200000,((1,200000),)*200000),(200000,tuple((i,i) for i in range(1,200001)))];raws=[line((len(seg),m))+''.join(line(p) for p in seg) for m,seg in configs]
 elif pid=='abc378_d':
  configs=[(1,('.',)),(1,('..',)),(2,('..','..')),(3,('..','..')),(4,('..','..')),(11,('............'[:10],)),(1,('.#','#.'))]
  for i in range(9):
   h=2+i%5;w=3+i%5;grid=[''.join('#' if rng.randrange(4)==0 else '.' for _ in range(w)) for _ in range(h)];grid[0]='.'+grid[0][1:];configs.append((1+i%8,tuple(grid)))
  configs += [(11,tuple('.#'*5 if i%2==0 else '#.'*5 for i in range(10))),(11,('.'*10,)*10)];raws=[line((len(g),len(g[0]),k))+'\n'.join(g)+'\n' for k,g in configs]
 elif pid=='abc379_d':
  configs=[((3,1),),((1,),(3,1)),((1,),(2,1),(3,1)),((1,),(2,1),(3,2),(3,1)),((1,),(1,),(2,10**9),(3,10**9),(3,1)),((2,10**9),(1,),(3,1))]
  for length in (7,8,9,10,17,50,100,1000,5000,10000):
   rows=[]
   for _ in range(length-1):kind=rng.randint(1,3);rows.append((1,) if kind==1 else (kind,rng.randint(1,10**9)))
   rows.append((3,1));configs.append(tuple(rows))
  configs += [((3,10**9),)*200000,((1,),)*99999+((2,10**9),)*100000+((3,10**9),)];raws=[line((len(q),))+''.join(line(row) for row in q) for q in configs]
 elif pid=='abc380_d':
  configs=[('A',(1,)),('a',(1,)),('a',(2,)),('Z',(1,2,3,4,5,6,7,8)),('aB',tuple(range(1,17))),('Az',(10**18,10**18-1)),('z',(10**18,))]
  for n in (3,4,5,6,10,17,100,1000,10000):configs.append((''.join(rng.choice('aAzZ') for _ in range(n)),tuple(rng.randint(1,10**18) for _ in range(n))))
  configs += [('A',(10**18,)*200000),('Az'*100000,tuple(10**18-i for i in range(200000)))];raws=[s+'\n'+line((len(q),))+line(q) for s,q in configs]
 elif pid=='abc381_d':
  arrays=[(1,),(1,1),(1,2),(1,2,2),(1,1,1),(1,1,2,2),(1,1,2,2,1,1),(1,2,2,3,3,4,4),(1,1,1,2,2)]
  arrays += [tuple(rng.randint(1,n) for _ in range(n)) for n in (10,11,17,100,1000,10000,100000)]
  arrays += [tuple(v for i in range(1,100001) for v in (i,i)),(200000,)*200000];raws=[line((len(a),))+line(a) for a in arrays]
 else:raws=[line(p) for p in ((2,11),(2,12),(2,20),(3,21),(3,23),(3,30),(4,31),(4,40),(5,41),(5,50),(6,60),(7,70),(8,80),(9,90),(10,100),(11,110),(12,111),(12,120))]
 require(len(raws)==len(set(raws))==18,'18distinct');result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result
HINTS:dict[str,tuple[str,str,str]]={
'abc377_d':('右端rを固定したとき、許される左端lの範囲を考えます。','R_i<=rの区間を完全に含まないためには、lがそれらのL_iの最大値より大きい必要があります。','疑似コード: 各右端Rに対応するLの最大値を保存; forbidden=0; r=1..Mでforbidden=max(forbidden,保存[r]); answer+=r-forbidden; 合計を出力。'),
'abc378_d':('始点をすべて試し、経路を再帰的に延ばします。','現在の経路に含まれるマスを訪問済みにします。再帰から戻ったら訪問済みを解除して別の経路を試します。','疑似コード: 各空き始点をvisitedにする; dfs(position,remaining): remaining=0なら1; 未訪問の四近傍空きマスをvisitedにしdfs(隣,remaining-1)を合計、戻ると解除; 全始点のdfs(start,K)を合計。'),
'abc379_d':('すべての植物の高さを毎回更新せず、累積経過時間を管理します。','植えた時刻を記録すると、高さは現在時刻との差です。古い植物ほど高いので、収穫できる植物は先頭から取り除けます。','疑似コード: time=0、deque空; 種類1はtimeを末尾へ; 種類2はtime+=T; 種類3はdeque先頭についてtime-植えた時刻>=Hの間popして数え、その個数を出力。'),
'abc380_d':('元のSが繰り返されるブロックごとに、大文字小文字の反転だけが変わります。','0始まりのブロック番号の2進表記で1が奇数個なら反転します。位置は元のSの長さで割った余りです。','疑似コード: 各Kについてblock,pos=divmod(K-1,len(S)); char=S[pos]; popcount(block)が奇数ならcharの大小文字を反転; 各charを空白区切りで出力。'),
'abc381_d':('ペアの開始位置は偶数番目か奇数番目の2通りです。','それぞれの開始位置で、等しい2要素のペアを1つの値として扱います。値が重複しない最長の連続区間を管理します。','疑似コード: 各開始偶奇で左端と各値の最後のペア位置を持つ; 不一致ペアなら左端をその直後へ; 一致ペアなら左端=max(左端,同じ値の前回位置+2); 最後の位置を更新し現在の長さで答えを最大化。'),
'abc382_d':('辞書順を保つため、各位置の候補を小さい順に試します。','残りの要素は最低でも10ずつ大きくなるので、今の要素の上限をMから逆算できます。','疑似コード: dfs(lower): 長さNなら数列を保存; upper=M-10*(N-現在長さ-1); value=lower..upperで末尾へ追加してdfs(value+10)、戻ると削除; 最初dfs(1); 保存件数と各数列を順に出力。')}

TITLES={'abc377_d': 'Many Segments 2', 'abc378_d': 'Count Simple Paths', 'abc379_d': 'Home Garden', 'abc380_d': 'Strange Mirroring', 'abc381_d': '1122 Substring', 'abc382_d': 'Keep Distance'}
PUBLISHED_SAMPLES={'abc377_d': [{'input': '2 4\n1 2\n3 4\n', 'expected': '5\n'}, {'input': '6 5\n1 1\n2 2\n3 3\n4 4\n5 5\n1 5\n', 'expected': '0\n'}, {'input': '6 20\n8 12\n14 20\n11 13\n5 19\n4 11\n1 6\n', 'expected': '102\n'}], 'abc378_d': [{'input': '2 2 2\n.#\n..\n', 'expected': '2\n'}, {'input': '2 3 1\n.#.\n#.#\n', 'expected': '0\n'}, {'input': '10 10 11\n....#..#..\n.#.....##.\n..#...##..\n...#......\n......##..\n..#......#\n#........#\n..##......\n.###....#.\n...#.....#\n', 'expected': '218070\n'}], 'abc379_d': [{'input': '6\n1\n2 15\n1\n3 10\n2 20\n3 20\n', 'expected': '1\n1\n'}, {'input': '15\n1\n1\n2 226069413\n3 1\n1\n1\n2 214168203\n1\n3 214168203\n1\n1\n1\n2 314506461\n2 245642315\n3 1\n', 'expected': '2\n2\n4\n'}], 'abc380_d': [{'input': 'aB\n16\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16\n', 'expected': 'a B A b A b a B A b a B a B A b\n'}, {'input': 'qWeRtYuIoP\n8\n1 1 2 3 5 8 13 21\n', 'expected': 'q q W e t I E Q\n'}, {'input': 'AnUoHrjhgfLMcDIpzxXmEWPwBZvbKqQuiJTtFSlkNGVReOYCdsay\n5\n1000000000000000000 123456789 1 987654321 999999999999999999\n', 'expected': 'K a A Z L\n'}], 'abc381_d': [{'input': '8\n2 3 1 1 2 2 1 1\n', 'expected': '4\n'}, {'input': '3\n1 2 2\n', 'expected': '2\n'}, {'input': '1\n1\n', 'expected': '0\n'}], 'abc382_d': [{'input': '3 23\n', 'expected': '10\n1 11 21\n1 11 22\n1 11 23\n1 12 22\n1 12 23\n1 13 23\n2 12 22\n2 12 23\n2 13 23\n3 13 23\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
