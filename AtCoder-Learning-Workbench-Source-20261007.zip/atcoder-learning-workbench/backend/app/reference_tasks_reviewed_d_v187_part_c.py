"""Private ABC162..167 D: strict domains and independent algorithms."""
from __future__ import annotations
from functools import lru_cache
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(162,168))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc166_d':'semantic'}
CHECKER_IDS={'abc166_d':'abc166_d'}
MOD=10**9+7
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
@lru_cache(maxsize=128)
def fifth_gap_search(x:int)->tuple[int,int]|None:
    # A>B. For same signs, maximum absolute endpoint >=120 implies
    # X >=120^5-119^5=1,019,663,401. Opposite signs imply each |endpoint|<=63.
    # Thus all valid numerical solutions lie in [-119,119]. Reflecting
    # (A,B) to (-B,-A) lets us assume B >= -(A-B)/2.
    for gap in range(1,239):
        low=-(gap//2);high=119-gap
        if low>high:break
        if (low+gap)**5-low**5>x:break
        while low<=high:
            middle=(low+high)//2;value=(middle+gap)**5-middle**5
            if value==x:return middle+gap,middle
            if value<x:low=middle+1
            else:high=middle-1
    return None

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc162_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(1<=n<=4000 and len(s)==n and re.fullmatch('[RGB]+',s) is not None,'range');return (s,)
    if pid=='abc163_d':
        require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=n+1,'range');return n,k
    if pid=='abc164_d':require(len(rows)==1 and re.fullmatch('[1-9]{1,200000}',rows[0]) is not None,'S');return (rows[0],)
    if pid=='abc165_d':
        require(len(rows)==1,'shape');a,b,n=ints(rows[0],3);require(1<=a<=10**6 and 1<=b<=10**12 and 1<=n<=10**12,'range');return a,b,n
    if pid=='abc166_d':
        require(len(rows)==1,'shape');x=ints(rows[0],1)[0];require(1<=x<=10**9 and fifth_gap_search(x) is not None,'range/existence');return (x,)
    require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(2<=n<=200000 and 1<=k<=10**18 and all(1<=v<=n for v in a),'range');return k,a

def rgb_mirrors(s:str)->int:
    n=len(s);bits={c:0 for c in 'RGB'};mirrors={c:0 for c in 'RGB'}
    for j,c in enumerate(s):bits[c]|=1<<j;mirrors[c]|=1<<(n-1-j)
    answer=s.count('R')*s.count('G')*s.count('B');leftmask=0
    for middle,c in enumerate(s):
        other=[d for d in 'RGB' if d!=c];shift=2*middle-(n-1)
        reflected={d:mirrors[d]<<shift if shift>=0 else mirrors[d]>>(-shift) for d in other}
        answer-=(bits[other[0]]&reflected[other[1]]&leftmask).bit_count()+(bits[other[1]]&reflected[other[0]]&leftmask).bit_count();leftmask=(leftmask<<1)|1
    return answer

def subset_sum_cubic(n:int,k:int)->int:
    # Disjoint digit-count ranges: for count t, all sums between extremes occur.
    hi=n+1;lo=k-1
    sum1=hi*(hi+1)//2-lo*(lo+1)//2
    sum2=hi*(hi+1)*(2*hi+1)//6-lo*(lo+1)*(2*lo+1)//6
    return ((n+1)*sum1-sum2+hi-lo)%MOD

def divisible_prefix(s:str)->int:
    inverse10=pow(10,-1,2019);inverse_weight=1;prefix=0;frequency=[0]*2019;frequency[0]=1;answer=0
    for c in s:
        prefix=(prefix*10+int(c))%2019;inverse_weight=inverse_weight*inverse10%2019;key=prefix*inverse_weight%2019;answer+=frequency[key];frequency[key]+=1
    return answer

def floor_threshold(a:int,b:int,n:int)->int:
    # An objective value y occurs iff ceil(y*B/A) is an attainable residue.
    # Search output levels instead of evaluating the endpoint formula.
    limit=min(n,b-1);low=0;high=a-1
    while low<high:
        middle=(low+high+1)//2;first=(middle*b+a-1)//a
        if first<=limit:low=middle
        else:high=middle-1
    return low

def fifth_valid(x:int,actual:str)->bool:
    fields=actual.split()
    if len(fields)!=2 or any(re.fullmatch(r'(?:0|-?[1-9][0-9]*)',t) is None for t in fields):return False
    try:
        a,b=map(int,fields);return a**5-b**5==x
    except (ValueError,OverflowError):return False

def teleport_doubling(k:int,a:tuple[int,...])->int:
    jump=[v-1 for v in a];current=0
    while k:
        if k&1:current=jump[current]
        k>>=1
        if k:jump=[jump[j] for j in jump]
    return current+1

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc162_d':return str(rgb_mirrors(cast(str,data[0])))
    if pid=='abc163_d':return str(subset_sum_cubic(*cast(tuple[int,int],data)))
    if pid=='abc164_d':return str(divisible_prefix(cast(str,data[0])))
    if pid=='abc165_d':return str(floor_threshold(*cast(tuple[int,int,int],data)))
    if pid=='abc166_d':
        pair=fifth_gap_search(cast(int,data[0]));require(pair is not None,'existence');return ' '.join(map(str,cast(tuple[int,int],pair)))
    return str(teleport_doubling(*cast(tuple[int,tuple[int,...]],data)))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='abc166_d':return fifth_valid(cast(int,data[0]),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc162_d':"n=int(input());s=input();answer=s.count('R')*s.count('G')*s.count('B')\nfor i in range(n):\n for j in range(i+1,n):\n  k=2*j-i\n  if k<n and s[i]!=s[j] and s[i]!=s[k] and s[j]!=s[k]:answer-=1\nprint(answer)\n",
'abc163_d':"n,k=map(int,input().split());answer=0\nfor count in range(k,n+2):\n smallest=count*(count-1)//2;largest=count*(2*n-count+1)//2;answer+=largest-smallest+1\nprint(answer%1000000007)\n",
'abc164_d':"s=input();counts=[0]*2019;counts[0]=1;remainder=0;power=1;answer=0\nfor ch in reversed(s):\n remainder=(remainder+int(ch)*power)%2019;answer+=counts[remainder];counts[remainder]+=1;power=power*10%2019\nprint(answer)\n",
'abc165_d':"a,b,n=map(int,input().split());x=min(n,b-1);print(a*x//b-a*(x//b))\n",
'abc166_d':"x=int(input());powers={j**5:j for j in range(-200,201)}\nfor a in range(-200,201):\n if a**5-x in powers:print(a,powers[a**5-x]);break\n",
'abc167_d':"n,k=map(int,input().split());a=list(map(int,input().split()));visited={};path=[];u=1\nwhile u not in visited:\n visited[u]=len(path);path.append(u);u=a[u-1]\nstart=visited[u];cycle=len(path)-start\nprint(path[k] if k<len(path) else path[start+(k-start)%cycle])\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18700+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc162_d':
        def text(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[text(s) for s in ['R','RGB','RRGB','RGRB','RRRGGG']]
        raws += [text(''.join(rng.choice('RGB') for _ in range(n))) for n in range(4,15)]
        raws += [text(''.join(rng.choice('RGB') for _ in range(4000))),text('RGB'*1333+'B')]
    elif pid=='abc163_d':raws=[line((1,1)),line((1,2)),line((2,1)),line((2,3))]+[line((n,rng.randint(1,n+1))) for n in range(3,15)]+[line((200000,1)),line((200000,200001))]
    elif pid=='abc164_d':raws=[s+'\n' for s in ['1','9','18171','999999','2119','123456789']]+[''.join(rng.choice('123456789') for _ in range(n))+'\n' for n in range(2,12)]+[''.join(rng.choice('123456789') for _ in range(200000))+'\n','9'*200000+'\n']
    elif pid=='abc165_d':
        values=[(1,1,1),(10**6,1,10**12),(1,10**12,1),(10**6,10**12,1),(10**6,3,10**12),(1,2,1)]
        values += [(rng.randint(1,10**6),rng.randint(1,10**12),rng.randint(1,10**12)) for _ in range(10)]
        values += [(999999,10**12,10**12-1),(10**6,10**12,10**12)];raws=[line(v) for v in values]
    elif pid=='abc166_d':
        values=[1,2,31,32,33,64,211,242,243,244,275,486,781,992,1023,1024,985959031,999329769];raws=[f'{x}\n' for x in values]
    else:
        def mapping(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[mapping(1,[1,1]),mapping(10**18,[2,1]),mapping(1,[2,2]),mapping(3,[2,3,1])]
        raws += [mapping(rng.randint(1,10**18),[rng.randint(1,n) for _ in range(n)]) for n in range(3,15)]
        raws += [mapping(10**18,list(range(2,200001))+[100000]),mapping(10**18,[200000]*200000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc162_d':('三色の個数の積で、色が異なる三個の組を数えられます。','そこから等間隔の三個を引きます。最初の二つi,jを決めると、三つ目はk=2j-iで決まります。','疑似コード: answer=count(R)*count(G)*count(B); 全i<jでk=2j-i; k<Nかつ三色全て異なるならanswer--; answerを出力。'),
'abc163_d':('選んだ個数が違えば、10^100の部分によって和の範囲も重なりません。','個数tが固定なら、小さいt個の和から大きいt個の和まで全整数を実現できます。その区間長を足します。','疑似コード: answer=0; t=K..N+1でlo=t*(t-1)/2,hi=t*(2N-t+1)/2; answer+=hi-lo+1; MODで割った余りを出力。'),
'abc164_d':('右端からの累積値を2019で割った余りを考えます。','10と2019は互いに素なので、右端からの累積余りが等しい二箇所の間は2019の倍数です。','疑似コード: freq[0]=1,remainder=0,power=1; Sを右から走査; remainder=(remainder+digit*power)%2019; answer+=freq[remainder]; freq[remainder]++; power=power*10%2019; answerを出力。'),
'abc165_d':('xをBで割った商の部分は、二つの項で打ち消されます。','x mod Bだけを考えればよく、その余りが大きいほど目的値も大きくなります。x=min(N,B-1)で最大になります。','疑似コード: x=min(N,B-1); floor(A*x/B)-A*floor(x/B)を整数演算で出力。'),
'abc166_d':('五乗は単調増加です。Xが10^9以下なので、解の値には有限の探索範囲を証明できます。','同符号で絶対値が120以上なら隣接する五乗の差が10^9を超え、異符号でも五乗の和から小さい範囲に限られます。-200から200の五乗表で探せます。','疑似コード: powers={b^5:b for b=-200..200}; a=-200..200でa^5-Xがpowersにあればa,powers[a^5-X]を出力して終了。'),
'abc167_d':('町の訪問列は、初めて同じ町に戻ると周期に入ります。','各町を初めて訪れた位置と経路を保存し、最初の重複から周期の始点と長さを求めます。大きなKを周期長で減らせます。','疑似コード: u=1; 未訪問uの訪問位置とpathを記録しu=A[u]; start=初訪問位置[u],cycle=len(path)-start; K<len(path)ならpath[K]、他はpath[start+(K-start)%cycle]を出力。')}

TITLES={'abc162_d': 'RGB Triplets', 'abc163_d': 'Sum of Large Numbers', 'abc164_d': 'Multiple of 2019', 'abc165_d': 'Floor Function', 'abc166_d': 'I hate Factorization', 'abc167_d': 'Teleporter'}
PUBLISHED_SAMPLES={'abc162_d': [{'input': '4\nRRGB\n', 'expected': '1\n'}, {'input': '39\nRBRBGRBGGBBRRGBBRRRBGGBRBGBRBGBRBBBGBBB\n', 'expected': '1800\n'}], 'abc163_d': [{'input': '3 2\n', 'expected': '10\n'}, {'input': '200000 200001\n', 'expected': '1\n'}, {'input': '141421 35623\n', 'expected': '220280457\n'}], 'abc164_d': [{'input': '1817181712114\n', 'expected': '3\n'}, {'input': '14282668646\n', 'expected': '2\n'}, {'input': '2119\n', 'expected': '0\n'}], 'abc165_d': [{'input': '5 7 4\n', 'expected': '2\n'}, {'input': '11 10 9\n', 'expected': '9\n'}], 'abc166_d': [{'input': '33\n', 'expected': '2 -1\n'}, {'input': '1\n', 'expected': '0 -1\n'}], 'abc167_d': [{'input': '4 5\n3 2 4 1\n', 'expected': '4\n'}, {'input': '6 727202214173249351\n6 5 2 5 3 2\n', 'expected': '2\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
