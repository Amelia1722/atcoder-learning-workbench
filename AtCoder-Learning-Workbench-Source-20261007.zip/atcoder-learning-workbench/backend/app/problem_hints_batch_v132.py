"""Statement-checked three-stage hints for ABC254–256 B."""
HINTS_V132 = {
 'abc254_b': (
  '端は常に1で、内側は1つ上の行の左上と右上の和です。前の行から次の行を順番に作ればよいです。',
  '最初の行[1]から始め、行iでは先頭と末尾を1、内側jをprev[j-1]+prev[j]として作ります。N≤30なのでそのまま二重ループで十分です。',
  '疑似コード:\nrow = [1]\nrepeat N times:\n  print(row)\n  next = [1]\n  for j = 1 .. len(row)-1:\n    next.append(row[j-1] + row[j])\n  next.append(1)\n  row = next',
 ),
 'abc255_b': (
  '各人について「最も近い明かりを持つ人までの距離」を求めます。その値の最大が、全員を照らすために必要な最小の強さです。',
  'N≤1000なので、各人とK人の明かり所持者との距離を全て調べても最大約100万組です。平方距離で最小値を取り、最後に最大値の平方根を取れます。',
  '疑似コード:\nans2 = 0\nfor person i:\n  nearest2 = INF\n  for light holder a:\n    d2 = (Xi-Xa)^2 + (Yi-Ya)^2\n    nearest2 = min(nearest2, d2)\n  ans2 = max(ans2, nearest2)\nprint(sqrt(ans2))',
 ),
 'abc256_b': (
  '各手番でまず0番マスに新しい駒を置き、その後、盤上の全駒をA_iマス進めます。4以上へ出た駒の数だけ得点を増やします。',
  '0〜3の4マスだけをboolean配列で管理できます。各A_iについて新しい配列を作り、移動先が4未満ならそこをTrue、4以上ならPを1増やします。',
  '疑似コード:\nboard = [False]*4\nP = 0\nfor a in A:\n  board[0] = True\n  next = [False]*4\n  for x in 0..3:\n    if board[x]:\n      if x+a >= 4: P += 1\n      else: next[x+a] = True\n  board = next\nprint(P)',
 ),
}
