"""Reviewed C tasks with partial graph matching, meet-in-middle and ring shifts."""
from __future__ import annotations
from bisect import bisect_left
from collections import defaultdict
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (371,373,374,375,376,377))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pairs=tuple[tuple[int,int],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==371:
        n=ints(rows[0],1)[0];require(1<=n<=8,'vertices');p=1;graphs=[]
        for _ in range(2):
            require(p<len(rows),'graph');m=ints(rows[p],1)[0];p+=1;require(0<=m<=n*(n-1)//2 and p+m<=len(rows),'edges');edges=tuple(ints(row,2) for row in rows[p:p+m]);p+=m;require(len(set(edges))==m and all(1<=a<b<=n for a,b in edges),'simple');graphs.append(edges)
        require(len(rows)==p+n-1,'cost rows');cost=tuple(ints(row,n-j-1) for j,row in enumerate(rows[p:]));require(all(1<=v<=10**6 for seq in cost for v in seq),'cost');return n,tuple(graphs),cost
    if number==373:
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];require(1<=n<=500000,'length');a,b=ints(rows[1],n),ints(rows[2],n);require(all(-10**9<=v<=10**9 for seq in (a,b) for v in seq),'values');return a,b
    if number==374:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=20 and all(1<=v<=10**8 for v in a),'departments');return (a,)
    if number==375:
        n=ints(rows[0],1)[0];a=tuple(rows[1:]);require(2<=n<=3000 and n%2==0 and len(a)==n and all(len(s)==n and set(s)<=set('.#') for s in a),'grid');return (a,)
    if number==376:
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];a,b=ints(rows[1],n),ints(rows[2],n-1);require(2<=n<=200000 and all(1<=v<=10**9 for seq in (a,b) for v in seq),'toys');return a,b
    n,m=ints(rows[0],2);require(1<=n<=10**9 and 1<=m<=200000 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(len(set(a))==m and all(1<=r<=n and 1<=c<=n for r,c in a),'pieces');return n,a
def graph_minimum(n:int,graphs:tuple[Pairs,...],cost:tuple[tuple[int,...],...])->int:
    g,h=({(a-1,b-1) for a,b in edges} for edges in graphs);mapping:list[int]=[];best=sum(map(sum,cost));used=[False]*n
    def search(total:int)->None:
        nonlocal best
        if total>=best:return
        depth=len(mapping)
        if depth==n:best=total;return
        for vertex in range(n):
            if used[vertex]:continue
            extra=0
            for j,other in enumerate(mapping):
                exists=(min(vertex,other),max(vertex,other)) in g
                if exists!=((j,depth) in h):extra+=cost[j][depth-j-1]
            used[vertex]=True;mapping.append(vertex);search(total+extra);mapping.pop();used[vertex]=False
    search(0);return best
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==371:return str(graph_minimum(*cast(tuple[int,tuple[Pairs,...],tuple[tuple[int,...],...]],data)))
    if number==373:
        a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);ordered=sorted(b);low=-2*10**9-1;high=2*10**9+1
        while high-low>1:
            middle=(low+high)//2
            if any(bisect_left(ordered,middle-v)<len(ordered) for v in a):low=middle
            else:high=middle
        return str(low)
    if number==374:
        a=cast(tuple[int,...],data[0]);split=len(a)//2;left=[0];right=[0]
        for v in a[:split]:left+= [x+v for x in left]
        for v in a[split:]:right+= [x+v for x in right]
        right.sort();total=sum(a);best=total
        for x in left:
            p=bisect_left(right,(total+1)//2-x)
            for j in (p-1,p):
                if 0<=j<len(right):best=min(best,max(x+right[j],total-x-right[j]))
        return str(best)
    if number==375:
        a=cast(tuple[str,...],data[0]);n=len(a);out=[['.']*n for _ in range(n)]
        for ring in range(n//2):
            lo=ring;hi=n-1-ring;side=hi-lo;coords=[(lo,c) for c in range(lo,hi)]+[(r,hi) for r in range(lo,hi)]+[(hi,c) for c in range(hi,lo,-1)]+[(r,lo) for r in range(hi,lo,-1)];shift=(ring+1)*side%len(coords)
            for j,(r,c) in enumerate(coords):rr,cc=coords[(j+shift)%len(coords)];out[rr][cc]=a[r][c]
        return '\n'.join(''.join(row) for row in out)
    if number==376:
        a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);aa=sorted(a);bb=sorted(b);n=len(aa);prefix=[True]*n;suffix=[True]*n
        for j in range(n-1):prefix[j+1]=prefix[j] and aa[j]<=bb[j]
        for j in range(n-2,-1,-1):suffix[j]=suffix[j+1] and aa[j+1]<=bb[j]
        return str(next((aa[j] for j in range(n) if prefix[j] and suffix[j]),-1))
    n,a=cast(tuple[int,Pairs],data);rowcols:dict[int,list[int]]=defaultdict(list)
    for r,c in a:
        for dr in range(-2,3):
            for dc in range(-2,3):
                if (dr==dc==0 or abs(dr)*abs(dc)==2) and 1<=r+dr<=n and 1<=c+dc<=n:rowcols[r+dr].append(c+dc)
    occupied=0
    for columns in rowcols.values():
        columns.sort();previous=0
        for c in columns:
            if c!=previous:occupied+=1;previous=c
    return str(n*n-occupied)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc371_c':"from itertools import permutations\nn=int(input());graphs=[]\nfor _ in range(2):\n m=int(input());graphs.append({tuple(int(v)-1 for v in input().split()) for _ in range(m)})\ng,h=graphs;cost=[[0]*n for _ in range(n)]\nfor i in range(n-1):\n for j,v in enumerate(map(int,input().split()),i+1):cost[i][j]=cost[j][i]=v\nanswer=sum(sum(row) for row in cost)\nfor p in permutations(range(n)):\n value=0\n for i in range(n):\n  for j in range(i+1,n):\n   if ((i,j) in g)!=((min(p[i],p[j]),max(p[i],p[j])) in h):value+=cost[p[i]][p[j]]\n answer=min(answer,value)\nprint(answer)\n",
'abc373_c':"n=int(input());a=list(map(int,input().split()));b=list(map(int,input().split()));print(max(a)+max(b))\n",
'abc374_c':"n=int(input());a=list(map(int,input().split()));sums=[0]\nfor v in a:sums += [x+v for x in sums]\ntotal=sum(a);print(min(max(x,total-x) for x in sums))\n",
'abc375_c':"n=int(input());a=[input() for _ in range(n)];out=[['.']*n for _ in range(n)]\nfor r in range(n):\n for c in range(n):\n  turns=(min(r,c,n-1-r,n-1-c)+1)%4;x,y=r,c\n  for _ in range(turns):x,y=y,n-1-x\n  out[x][y]=a[r][c]\nprint(*map(''.join,out),sep='\\n')\n",
'abc376_c':"n=int(input());a=sorted(map(int,input().split()),reverse=True);b=sorted(map(int,input().split()),reverse=True);j=0;answer=-1;failed=False\nfor v in a:\n if j<len(b) and v<=b[j]:j+=1\n elif answer==-1:answer=v\n else:failed=True\nprint(-1 if failed else answer)\n",
'abc377_c':"n,m=map(int,input().split());blocked=set();moves=((0,0),(1,2),(1,-2),(-1,2),(-1,-2),(2,1),(2,-1),(-2,1),(-2,-1))\nfor _ in range(m):\n r,c=map(int,input().split())\n for dr,dc in moves:\n  if 1<=r+dr<=n and 1<=c+dc<=n:blocked.add((r+dr,c+dc))\nprint(n*n-len(blocked))\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17300+number)
    if number==371:
        def graph(n:int,g:list[tuple[int,int]],h:list[tuple[int,int]],maxcost:bool=False)->str:return f'{n}\n{len(g)}\n'+''.join(f'{a} {b}\n' for a,b in g)+f'{len(h)}\n'+''.join(f'{a} {b}\n' for a,b in h)+''.join(line([10**6 if maxcost else rng.randint(1,100) for _ in range(n-j-1)]) for j in range(n-1))
        raws=[graph(1,[],[]),graph(2,[],[]),graph(2,[(1,2)],[]),graph(3,[(1,2)],[(2,3)])]
        for j in range(12):n=3+j%6;edges=[(a,b) for a in range(1,n+1) for b in range(a+1,n+1)];raws.append(graph(n,rng.sample(edges,rng.randrange(len(edges)+1)),rng.sample(edges,rng.randrange(len(edges)+1))))
        raws.extend([graph(8,[(j,j+1) for j in range(1,8)],[(1,j) for j in range(2,9)],True),graph(8,[(a,b) for a in range(1,9) for b in range(a+1,9)],[],True)])
    elif number==373:
        def arrays(a:list[int],b:list[int])->str:return f'{len(a)}\n'+line(a)+line(b)
        raws=[arrays(a,b) for a,b in (([0],[0]),([-1],[-1]),([1],[-1]),([1,5],[7,2]))];raws.extend(arrays([rng.randint(-100,100) for _ in range(n)],[rng.randint(-100,100) for _ in range(n)]) for n in range(3,15));raws.extend([arrays([-10**9]*500000,[-10**9]*500000),arrays([10**9]*500000,[10**9]*500000)])
    elif number==374:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1,1],[1,2],[1,1,1],[8,3,2])];raws.extend(arr([rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([arr([2**j for j in range(20)]),arr([10**8]*20)])
    elif number==375:
        def grid(a:list[str])->str:return f'{len(a)}\n'+'\n'.join(a)+'\n'
        raws=[grid(a) for a in (['..','..'],['##','##'],['#.','..'],['#.','.#'])];raws.extend(grid([''.join(rng.choice('.#') for _ in range(n)) for _ in range(n)]) for n in range(4,28,2));raws.extend([grid([''.join('#' if (r*13+c*7)%17<8 else '.' for c in range(3000)) for r in range(3000)]),grid(['#'*3000]*3000)])
    elif number==376:
        def toys(a:list[int],b:list[int])->str:return f'{len(a)}\n'+line(a)+line(b)
        raws=[toys(a,b) for a,b in (([1,1],[1]),([2,2],[1]),([1,2],[1]),([1,2,3],[2,3]))];raws.extend(toys([rng.randint(1,100) for _ in range(n)],[rng.randint(1,100) for _ in range(n-1)]) for n in range(3,15));raws.extend([toys(list(range(1,200001)),list(range(1,200000))),toys([10**9]*200000,[10**9]*199999)])
    else:
        def pieces(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{r} {c}\n' for r,c in a)
        raws=[pieces(n,a) for n,a in ((1,[(1,1)]),(2,[(1,1)]),(3,[(2,2)]),(4,[(1,1),(4,4)]))]
        for n in range(3,15):raws.append(pieces(n,rng.sample([(r,c) for r in range(1,n+1) for c in range(1,n+1)],n+2)))
        raws.extend([pieces(10**9,[(1+j*4,1+j*4) for j in range(200000)]),pieces(10**9,[(10**9,10**9-j) for j in range(200000)])])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc371_c':('頂点の対応を固定すると、必要な辺の追加・削除が一意に決まります。','Nは8以下なので全ての頂点対応を列挙し、異なる辺の変更費用を足します。','疑似コード: G頂点からH頂点への全permutation Pを列挙; 各i<jでGの辺有無とHのP[i],P[j]の辺有無が違えばA[P[i],P[j]]を加算; 最小費用を出力。'),
'abc373_c':('iとjは独立に選べます。','Aから最大値、Bから最大値を選べばよいです。','疑似コード: largestA=max(A); largestB=max(B); largestA+largestBを出力。'),
'abc374_c':('グループAに入れる部署の部分集合を決めればBも決まります。','2^N通りの部分集合の合計xを求め、max(x,total-x)を最小化します。','疑似コード: sums=[0]; 各Kでsumsへ既存x+Kを追加; total=sum(K); min(max(x,total-x) for x in sums)を出力。'),
'abc375_c':('外周から何層目にあるかは回転しても変わりません。','深さdのマスはd+1回時計回りに90度回転します。回数を4で割った余りだけ処理します。','疑似コード: depth=min(r,c,N-1-r,N-1-c); turns=(depth+1)%4; 座標(r,c)をturns回(r,c)=(c,N-1-r)へ変換; 出力先へ元の文字を書く。'),
'abc376_c':('大きいおもちゃから、大きい既存の箱と対応させます。','入らないおもちゃを一つだけ新しい箱に割り当てます。二つ以上入らなければ不可能です。','疑似コード: A,B降順sort; Aを順に見て現在Bに入れば次箱へ; 入らなければ新箱用に記録; 2回目なら-1、1回だけなら記録した大きさを出力。'),
'abc377_c':('使えないマスは、既存のコマの位置とその8方向の攻撃先だけです。','盤面全体を持たず、使えない座標を集合へ保存して重複を除きます。','疑似コード: 各コマについて自身と(±1,±2),(±2,±1)の盤内座標をsetへ; N*N-len(set)を出力。')}

TITLES={'abc371_c': 'Make Isomorphic', 'abc373_c': 'Max Ai+Bj', 'abc374_c': 'Separated Lunch', 'abc375_c': 'Spiral Rotation', 'abc376_c': 'Prepare Another Box', 'abc377_c': 'Avoid Knight Attack'}
PUBLISHED_SAMPLES={'abc371_c': [{'input': '5\n4\n1 2\n2 3\n3 4\n4 5\n4\n1 2\n1 3\n1 4\n1 5\n3 1 4 1\n5 9 2\n6 5\n3\n', 'expected': '9\n'}, {'input': '5\n3\n1 2\n2 3\n3 4\n4\n1 2\n2 3\n3 4\n4 5\n9 1 1 1\n1 1 1\n1 1\n9\n', 'expected': '3\n'}, {'input': '5\n3\n1 2\n2 3\n3 4\n4\n1 2\n2 3\n3 4\n4 5\n5 4 4 4\n4 4 4\n4 4\n5\n', 'expected': '5\n'}, {'input': '2\n0\n0\n371\n', 'expected': '0\n'}, {'input': '8\n13\n1 8\n5 7\n4 6\n1 5\n7 8\n1 6\n1 2\n5 8\n2 6\n5 6\n6 7\n3 7\n4 8\n15\n3 5\n1 7\n4 6\n3 8\n7 8\n1 2\n5 6\n1 6\n1 5\n1 4\n2 8\n2 6\n2 4\n4 7\n1 3\n7483 1694 5868 3296 9723 5299 4326\n5195 4088 5871 1384 2491 6562\n1149 6326 2996 9845 7557\n4041 7720 1554 5060\n8329 8541 3530\n4652 3874\n3748\n', 'expected': '21214\n'}], 'abc373_c': [{'input': '2\n-1 5\n3 -7\n', 'expected': '8\n'}, {'input': '6\n15 12 3 -13 -1 -19\n7 17 -13 -10 18 4\n', 'expected': '33\n'}], 'abc374_c': [{'input': '5\n2 3 5 10 12\n', 'expected': '17\n'}, {'input': '2\n1 1\n', 'expected': '1\n'}, {'input': '6\n22 25 26 45 22 31\n', 'expected': '89\n'}], 'abc375_c': [{'input': '8\n.......#\n.......#\n.####..#\n.####..#\n.##....#\n.##....#\n.#######\n.#######\n', 'expected': '........\n#######.\n#.....#.\n#.###.#.\n#.#...#.\n#.#####.\n#.......\n########\n'}, {'input': '6\n.#.#.#\n##.#..\n...###\n###...\n..#.##\n#.#.#.\n', 'expected': '#.#.#.\n.#.#.#\n#.#.#.\n.#.#.#\n#.#.#.\n.#.#.#\n'}, {'input': '12\n.......#.###\n#...#...#..#\n###.#..#####\n..#.#.#.#...\n.#.....#.###\n.......#.#..\n#...#..#....\n#####.......\n...#...#.#.#\n..###..#..##\n#..#.#.#.#.#\n.####.......\n', 'expected': '.#..##...##.\n#.#.#.#.#...\n###.##..#...\n#.#.#.#.#...\n#.#.##...##.\n............\n............\n.###.###.###\n...#...#.#..\n.###...#.###\n...#...#...#\n.###...#.###\n'}], 'abc376_c': [{'input': '4\n5 2 3 7\n6 2 8\n', 'expected': '3\n'}, {'input': '4\n3 7 2 5\n8 1 6\n', 'expected': '-1\n'}, {'input': '8\n2 28 17 39 57 56 37 32\n34 27 73 28 76 61 27\n', 'expected': '37\n'}], 'abc377_c': [{'input': '8 6\n1 4\n2 1\n3 8\n4 5\n5 2\n8 3\n', 'expected': '38\n'}, {'input': '1000000000 1\n1 1\n', 'expected': '999999999999999997\n'}, {'input': '20 10\n1 4\n7 11\n7 15\n8 10\n11 6\n12 5\n13 1\n15 2\n20 10\n20 15\n', 'expected': '338\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
