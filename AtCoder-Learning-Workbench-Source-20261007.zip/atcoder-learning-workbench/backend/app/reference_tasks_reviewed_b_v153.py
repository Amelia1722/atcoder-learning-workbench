"""Turn 130 reviewed B batch: ABC447 B through ABC464 B."""
from __future__ import annotations

from collections import Counter
from itertools import combinations, product, permutations
import math
import re

TASKS = tuple(f"abc{i}_b" for i in range(447, 465))
LANES = {
    "A": TASKS[0:3], "B": TASKS[3:6], "C": TASKS[6:9],
    "D": TASKS[9:12], "E": TASKS[12:15], "F": TASKS[15:18],
}
TITLES = {
    "abc447_b":"mpp", "abc448_b":"Pepper Addiction", "abc449_b":"Deconstruct Chocolate",
    "abc450_b":"Split Ticketing", "abc451_b":"Personnel Change", "abc452_b":"Draw Frame",
    "abc453_b":"Sensor Data Logging", "abc454_b":"Mapping", "abc455_b":"Spiral Galaxy",
    "abc456_b":"456", "abc457_b":"Arrays", "abc458_b":"Count Adjacent Cells",
    "abc459_b":"459", "abc460_b":"Two Rings", "abc461_b":"The Honest Woodcutters",
    "abc462_b":"Gift", "abc463_b":"Train Reservation", "abc464_b":"Crop",
}
PUBLISHED_SAMPLES = {
"abc447_b":[
 {"input":"mississippi\n","expected":"mpp\n"},
 {"input":"atcoder\n","expected":"\n"},
 {"input":"beginner\n","expected":"bgir\n"},
],
"abc448_b":[
 {"input":"7 5\n4 4 8 3 7\n1 2\n2 3\n5 2\n4 10\n2 3\n5 4\n2 3\n","expected":"15\n"},
 {"input":"1 1\n1\n1 1\n","expected":"1\n"},
 {"input":"15 10\n7 94 100 82 63 81 75 2 76 73\n10 44\n5 77\n10 47\n7 32\n2 82\n5 90\n3 37\n6 70\n6 28\n3 25\n2 26\n10 56\n1 69\n5 46\n7 26\n","expected":"438\n"},
],
"abc449_b":[
 {"input":"7 9 5\n2 4\n1 3\n2 1\n2 1\n1 3\n","expected":"28\n15\n4\n4\n9\n"},
],
"abc450_b":[
 {"input":"3\n45 450\n45\n","expected":"Yes\n"},
 {"input":"4\n25 40 65\n30 55\n25\n","expected":"No\n"},
],
"abc451_b":[
 {"input":"5 4\n1 2\n2 1\n3 1\n2 2\n2 4\n","expected":"1\n-1\n-1\n1\n"},
 {"input":"10 5\n3 2\n3 4\n1 2\n2 2\n4 4\n3 1\n3 4\n4 2\n3 3\n3 2\n","expected":"0\n4\n-5\n1\n0\n"},
],
"abc452_b":[
 {"input":"4 5\n","expected":"#####\n#...#\n#...#\n#####\n"},
 {"input":"5 6\n","expected":"######\n#....#\n#....#\n#....#\n######\n"},
],
"abc453_b":[
 {"input":"6 10\n30 35 40 21 30 12 31\n","expected":"0 30\n2 40\n3 21\n6 31\n"},
],
"abc454_b":[
 {"input":"3 4\n1 2 4\n","expected":"Yes\nNo\n"},
 {"input":"4 2\n1 2 1 2\n","expected":"No\nYes\n"},
 {"input":"4 4\n1 3 2 1\n","expected":"No\nNo\n"},
 {"input":"5 5\n1 3 4 2 5\n","expected":"Yes\nYes\n"},
],
"abc455_b":[
 {"input":"3 2\n.#\n#.\n##\n","expected":"10\n"},
 {"input":"4 5\n.#.#.\n####.\n##..#\n....#\n","expected":"54\n"},
],
"abc456_b":[
 {"input":"1 2 3 4 5 6\n1 2 3 4 5 6\n1 2 3 4 5 6\n","expected":"0.0277777778\n"},
 {"input":"4 5 6 4 5 6\n4 4 5 5 6 6\n6 5 4 4 5 6\n","expected":"0.2222222222\n"},
],
"abc457_b":[
 {"input":"3\n3 10 20 30\n1 7\n4 5 6 7 8\n3 4\n","expected":"8\n"},
 {"input":"4\n2 9 1\n3 8 2 6\n1 5\n2 4 3\n2 2\n","expected":"2\n"},
 {"input":"1\n5 100 200 300 400 500\n1 5\n","expected":"500\n"},
],
"abc458_b":[
 {"input":"4 5\n","expected":"2 3 3 3 2\n3 4 4 4 3\n3 4 4 4 3\n2 3 3 3 2\n"},
 {"input":"1 1\n","expected":"0\n"},
 {"input":"12 8\n","expected":"2 3 3 3 3 3 3 2\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n3 4 4 4 4 4 4 3\n2 3 3 3 3 3 3 2\n"},
],
"abc459_b":[
 {"input":"2\nalgorithm\nheuristic\n","expected":"24\n"},
 {"input":"3\ni\nlove\nyou\n","expected":"459\n"},
],
"abc460_b":[
 {"input":"7\n0 0 2 2 3 2\n0 0 2 2 3 1\n1 2 5 3 2 1\n5 4 2 8 8 3\n2 1 5 5 1 2\n0 0 1 0 0 1\n0 0 500000000 1 1000000000 500000000\n","expected":"Yes\nNo\nNo\nYes\nYes\nYes\nNo\n"},
],
"abc461_b":[
 {"input":"3\n3 1 2\n2 3 1\n","expected":"Yes\n"},
 {"input":"4\n1 2 3 4\n1 3 2 4\n","expected":"No\n"},
 {"input":"5\n2 4 5 1 3\n4 1 5 2 3\n","expected":"Yes\n"},
],
"abc462_b":[
 {"input":"4\n1 2\n1 3\n1 2\n3 1 2 3\n","expected":"1 4\n3 1 3 4\n2 2 4\n0\n"},
 {"input":"4\n3 2 3 4\n2 1 4\n2 1 2\n2 2 3\n","expected":"2 2 3\n3 1 3 4\n2 1 4\n2 1 2\n"},
 {"input":"7\n1 3\n4 3 4 6 7\n1 7\n3 2 6 7\n2 3 7\n1 4\n1 5\n","expected":"0\n1 4\n3 1 2 5\n2 2 6\n1 7\n2 2 4\n4 2 3 4 5\n"},
],
"abc463_b":[
 {"input":"3 A\nxoxox\nxxooo\noxxxx\n","expected":"Yes\n"},
 {"input":"5 C\nxoxoo\noxxoo\noxxxo\nxoxxx\noxxoo\n","expected":"No\n"},
],
"abc464_b":[
 {"input":"4 5\n.....\n..#..\n.###.\n.....\n","expected":".#.\n###\n"},
 {"input":"3 4\n#...\n....\n...#\n","expected":"#...\n....\n...#\n"},
 {"input":"5 6\n......\n......\n...#..\n......\n......\n","expected":"#\n"},
],
}
SAMPLE_COUNTS={k:len(v) for k,v in PUBLISHED_SAMPLES.items()}
LOWER=re.compile(r"[a-z]+")


def _lines(raw:str)->list[str]:
    if not raw.endswith("\n") or "\r" in raw: raise ValueError("newline")
    return raw[:-1].split("\n")
def _ints(s:str)->list[int]:
    try:return list(map(int,s.split()))
    except Exception as exc:raise ValueError("ints") from exc


def validate(pid:str,raw:str):
    if pid not in TASKS:raise ValueError('pid')
    l=_lines(raw)
    if pid=='abc447_b':
        if len(l)!=1 or not(1<=len(l[0])<=100) or not LOWER.fullmatch(l[0]):raise ValueError('S')
        return (l[0],)
    if pid=='abc448_b':
        if len(l)<3:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h;c=_ints(l[1]);rows=l[2:]
        if not(1<=n<=1000 and 1<=m<=1000) or len(c)!=m or len(rows)!=n or any(not 1<=x<=10**6 for x in c):raise ValueError('NM/C')
        dishes=[]
        for row in rows:
            a=_ints(row)
            if len(a)!=2 or not(1<=a[0]<=m and 1<=a[1]<=10**6):raise ValueError('dish')
            dishes.append(tuple(a))
        return n,m,tuple(c),tuple(dishes)
    if pid=='abc449_b':
        if len(l)<2:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=3:raise ValueError('head')
        H,W,Q=h;qs=[]
        if not(2<=H<=100 and 2<=W<=100 and 1<=Q<=100) or len(l)!=Q+1:raise ValueError('HWQ')
        ch,cw=H,W
        for row in l[1:]:
            a=_ints(row)
            if len(a)!=2 or a[0] not in (1,2):raise ValueError('query')
            t,x=a
            if t==1:
                if not 1<=x<ch:raise ValueError('R')
                ch-=x
            else:
                if not 1<=x<cw:raise ValueError('C')
                cw-=x
            qs.append((t,x))
        return H,W,tuple(qs)
    if pid=='abc450_b':
        if not l:raise ValueError('shape')
        n=int(l[0]);rows=l[1:]
        if not 3<=n<=100 or len(rows)!=n-1:raise ValueError('N')
        c=[[0]*n for _ in range(n)]
        for i,row in enumerate(rows):
            a=_ints(row)
            if len(a)!=n-i-1 or any(not 1<=x<=10**9 for x in a):raise ValueError('C')
            for off,x in enumerate(a,1):c[i][i+off]=x
        return n,tuple(tuple(r) for r in c)
    if pid=='abc451_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        n,m=h;rows=l[1:]
        if not(1<=n<=100 and 1<=m<=100) or len(rows)!=n:raise ValueError('NM')
        ab=[]
        for row in rows:
            a=_ints(row)
            if len(a)!=2 or any(not 1<=x<=m for x in a):raise ValueError('AB')
            ab.append(tuple(a))
        return n,m,tuple(ab)
    if pid=='abc452_b':
        if len(l)!=1:raise ValueError('shape')
        a=_ints(l[0]);
        if len(a)!=2 or not all(3<=x<=10 for x in a):raise ValueError('HW')
        return tuple(a)
    if pid=='abc453_b':
        if len(l)!=2:raise ValueError('shape')
        h=_ints(l[0]);a=_ints(l[1])
        if len(h)!=2:raise ValueError('head')
        t,x=h
        if not(1<=t<=100 and 1<=x<=100) or len(a)!=t+1 or any(not 0<=z<=100 for z in a):raise ValueError('data')
        return t,x,tuple(a)
    if pid=='abc454_b':
        if len(l)!=2:raise ValueError('shape')
        h=_ints(l[0]);f=_ints(l[1])
        if len(h)!=2:raise ValueError('head')
        n,m=h
        if not(1<=n<=100 and 1<=m<=100) or len(f)!=n or any(not 1<=x<=m for x in f):raise ValueError('F')
        return n,m,tuple(f)
    if pid=='abc455_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        H,W=h;g=l[1:]
        if not(1<=H<=10 and 1<=W<=10) or len(g)!=H or any(len(r)!=W or any(c not in '.#' for c in r) for r in g):raise ValueError('grid')
        return H,W,tuple(g)
    if pid=='abc456_b':
        if len(l)!=3:raise ValueError('shape')
        dice=[]
        for row in l:
            a=_ints(row)
            if len(a)!=6 or any(not 1<=x<=6 for x in a):raise ValueError('die')
            dice.append(tuple(a))
        return tuple(dice)
    if pid=='abc457_b':
        if len(l)<3:raise ValueError('shape')
        n=int(l[0]);
        if not 1<=n<=2*10**5 or len(l)!=n+2:raise ValueError('N')
        arr=[];total=0
        for row in l[1:1+n]:
            a=_ints(row)
            if not a:raise ValueError('row')
            L=a[0];vals=a[1:]
            if not 1<=L or len(vals)!=L or any(not 1<=x<=1000 for x in vals):raise ValueError('array')
            total+=L;arr.append(tuple(vals))
        if total>2*10**5:raise ValueError('sumL')
        q=_ints(l[-1])
        if len(q)!=2:raise ValueError('XY')
        x,y=q
        if not(1<=x<=n and 1<=y<=len(arr[x-1])):raise ValueError('XY')
        return n,tuple(arr),x,y
    if pid=='abc458_b':
        if len(l)!=1:raise ValueError('shape')
        a=_ints(l[0])
        if len(a)!=2 or any(not 1<=x<=50 for x in a):raise ValueError('HW')
        return tuple(a)
    if pid=='abc459_b':
        if not l:raise ValueError('shape')
        n=int(l[0]);s=l[1:]
        if not 1<=n<=10 or len(s)!=n or any(not 1<=len(x)<=10 or LOWER.fullmatch(x) is None for x in s):raise ValueError('S')
        return n,tuple(s)
    if pid=='abc460_b':
        if not l:raise ValueError('shape')
        t=int(l[0]);rows=l[1:]
        if not 1<=t<=100 or len(rows)!=t:raise ValueError('T')
        cases=[]
        for row in rows:
            a=_ints(row)
            if len(a)!=6:raise ValueError('case')
            x1,y1,r1,x2,y2,r2=a
            if any(not 0<=z<=10**9 for z in (x1,y1,x2,y2)) or not(1<=r1<=10**9 and 1<=r2<=10**9):raise ValueError('bounds')
            cases.append(tuple(a))
        return t,tuple(cases)
    if pid=='abc461_b':
        if len(l)!=3:raise ValueError('shape')
        n=int(l[0]);a=_ints(l[1]);b=_ints(l[2])
        target=set(range(1,n+1))
        if not 1<=n<=100 or len(a)!=n or len(b)!=n or set(a)!=target or set(b)!=target:raise ValueError('permutation')
        return n,tuple(a),tuple(b)
    if pid=='abc462_b':
        if not l:raise ValueError('shape')
        n=int(l[0]);rows=l[1:]
        if not 2<=n<=100 or len(rows)!=n:raise ValueError('N')
        rec=[]
        for i,row in enumerate(rows,1):
            a=_ints(row)
            if not a:raise ValueError('row')
            k=a[0];vals=a[1:]
            if not 1<=k<=n-1 or len(vals)!=k or len(set(vals))!=k or any(not 1<=x<=n or x==i for x in vals) or vals!=sorted(vals):raise ValueError('recipients')
            rec.append(tuple(vals))
        return n,tuple(rec)
    if pid=='abc463_b':
        if len(l)<2:raise ValueError('shape')
        h=l[0].split()
        if len(h)!=2:raise ValueError('head')
        n=int(h[0]);x=h[1];s=l[1:]
        if not 1<=n<=100 or x not in 'ABCDE' or len(s)!=n or any(len(r)!=5 or any(c not in 'ox' for c in r) for r in s):raise ValueError('data')
        return n,x,tuple(s)
    if pid=='abc464_b':
        if not l:raise ValueError('shape')
        h=_ints(l[0]);
        if len(h)!=2:raise ValueError('head')
        H,W=h;g=l[1:]
        if not(1<=H<=50 and 1<=W<=50) or len(g)!=H or any(len(r)!=W or any(c not in '.#' for c in r) for r in g) or not any('#' in r for r in g):raise ValueError('grid')
        return H,W,tuple(g)
    raise ValueError(pid)


def _oracle(pid:str,raw:str)->str:
    v=validate(pid,raw)
    if pid=='abc447_b':
        s=v[0];c=Counter(s);mx=max(c.values());return ''.join(ch for ch in s if c[ch]!=mx)
    if pid=='abc448_b':
        n,m,c,d=v;dem=[0]*m
        for a,b in d:dem[a-1]+=b
        return str(sum(min(c[i],dem[i]) for i in range(m)))
    if pid=='abc449_b':
        H,W,qs=v;out=[]
        for t,x in qs:
            out.append(str(x*(W if t==1 else H)))
            if t==1:H-=x
            else:W-=x
        return '\n'.join(out)
    if pid=='abc450_b':
        n,c=v
        return 'Yes' if any(c[a][b]+c[b][cc]<c[a][cc] for a,b,cc in combinations(range(n),3)) else 'No'
    if pid=='abc451_b':
        n,m,ab=v;cur=Counter(a for a,_ in ab);nxt=Counter(b for _,b in ab)
        return '\n'.join(str(nxt[j]-cur[j]) for j in range(1,m+1))
    if pid=='abc452_b':
        H,W=v;return '\n'.join('#'*W if r in (0,H-1) else '#'+'.'*(W-2)+'#' for r in range(H))
    if pid=='abc453_b':
        t,x,a=v;last=a[0];out=[f'0 {a[0]}']
        for i,z in enumerate(a[1:],1):
            if abs(z-last)>=x:out.append(f'{i} {z}');last=z
        return '\n'.join(out)
    if pid=='abc454_b':
        n,m,f=v;return ('Yes' if len(set(f))==n else 'No')+'\n'+('Yes' if set(f)==set(range(1,m+1)) else 'No')
    if pid=='abc455_b':
        H,W,g=v;ans=0
        for r1 in range(H):
            for r2 in range(r1,H):
                for c1 in range(W):
                    for c2 in range(c1,W):
                        ok=True
                        for r in range(r1,r2+1):
                            for c in range(c1,c2+1):
                                if g[r][c]!=g[r1+r2-r][c1+c2-c]:ok=False;break
                            if not ok:break
                        ans+=ok
        return str(ans)
    if pid=='abc456_b':
        dice=v;good=0
        for a in dice[0]:
            for b in dice[1]:
                for c in dice[2]:good+=sorted((a,b,c))==[4,5,6]
        return repr(good/216)
    if pid=='abc457_b':
        n,a,x,y=v;return str(a[x-1][y-1])
    if pid=='abc458_b':
        H,W=v;rows=[]
        for r in range(H):
            row=[]
            for c in range(W):row.append(str(sum(0<=r+dr<H and 0<=c+dc<W for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)))))
            rows.append(' '.join(row))
        return '\n'.join(rows)
    if pid=='abc459_b':
        n,s=v;groups=['abc','def','ghi','jkl','mno','pqrs','tuv','wxyz'];mp={ch:str(i+2) for i,g in enumerate(groups) for ch in g}
        return ''.join(mp[x[0]] for x in s)
    if pid=='abc460_b':
        t,cases=v;out=[]
        for x1,y1,r1,x2,y2,r2 in cases:
            d2=(x1-x2)**2+(y1-y2)**2;out.append('Yes' if (r1-r2)**2<=d2<=(r1+r2)**2 else 'No')
        return '\n'.join(out)
    if pid=='abc461_b':
        n,a,b=v;return 'Yes' if all(b[a[i]-1]==i+1 for i in range(n)) else 'No'
    if pid=='abc462_b':
        n,rec=v;out=[]
        for target in range(1,n+1):
            send=[i+1 for i,vals in enumerate(rec) if target in vals];out.append(str(len(send))+(' '+' '.join(map(str,send)) if send else ''))
        return '\n'.join(out)
    if pid=='abc463_b':
        n,x,s=v;j=ord(x)-65;return 'Yes' if any(row[j]=='o' for row in s) else 'No'
    if pid=='abc464_b':
        H,W,g=v;rs=[r for r in range(H) for c in range(W) if g[r][c]=='#'];cs=[c for r in range(H) for c in range(W) if g[r][c]=='#'];r1,r2=min(rs),max(rs);c1,c2=min(cs),max(cs)
        return '\n'.join(row[c1:c2+1] for row in g[r1:r2+1])
    raise ValueError(pid)


def _numeric_tokens_ok(actual:str,expected:str,eps:float)->bool:
    try:a=[float(x) for x in actual.split()];b=[float(x) for x in expected.split()]
    except Exception:return False
    if len(a)!=len(b) or not a:return False
    for x,y in zip(a,b):
        if not math.isfinite(x) or not math.isfinite(y):return False
        if not(abs(x-y)<=eps or abs(x-y)<=eps*abs(y)):return False
    return True

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:exp=_oracle(pid,raw)
    except Exception:return False
    if pid=='abc456_b':return _numeric_tokens_ok(actual,exp,1e-6)
    return actual.rstrip('\n')==exp.rstrip('\n')

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc456_b':return _numeric_tokens_ok(stdout,expected,1e-6) and independent_check(pid,raw,expected)
    return stdout.rstrip('\n')==expected.rstrip('\n') and independent_check(pid,raw,expected)

def _case(raw:str,idx:int)->dict[str,str]:return {'input':raw,'category':f'task_specific_{idx:02d}'}


def generate(pid:str):
    out=[]
    if pid=='abc447_b':
        vals=['a','ab','aaab','abcabc','mississippi','beginner','zzxyy','abababa','aabbcc','qwerty','aaaaabbbbbc','abcdeffff','xyzxyzx','banana','bookkeeper','competition','abracadabra']
        out=[_case(s+'\n',i+1) for i,s in enumerate(vals)];out.append({'input':'a'*99+'b\n','category':'constraint_max'})
    elif pid=='abc448_b':
        for i in range(1,18):
            m=1+i%7;n=i+1;c=[1+(i*17+j*13)%100 for j in range(m)];d=[(j%m+1,1+(i*11+j*7)%100) for j in range(n)]
            out.append(_case(f'{n} {m}\n'+' '.join(map(str,c))+'\n'+'\n'.join(f'{a} {b}' for a,b in d)+'\n',i))
        m=n=1000;c=['1000000']*m;d='\n'.join(f'{i%1000+1} 1000000' for i in range(n));out.append({'input':f'{n} {m}\n'+' '.join(c)+'\n'+d+'\n','category':'constraint_max'})
    elif pid=='abc449_b':
        for i in range(1,18):
            H=20+i;W=40+i;qs=[(1,1+(i%5)),(2,1+(i%7)),(1,1+(i%3))]
            out.append(_case(f'{H} {W} 3\n'+'\n'.join(f'{t} {x}' for t,x in qs)+'\n',i))
        qs=[(1,1)]*50+[(2,1)]*50;out.append({'input':'100 100 100\n'+'\n'.join(f'{t} {x}' for t,x in qs)+'\n','category':'constraint_max'})
    elif pid=='abc450_b':
        for i in range(1,18):
            n=3+i%8;rows=[]
            for a in range(n-1):rows.append(' '.join(str(1+((i*97+a*31+b*17)%1000)) for b in range(a+1,n)))
            out.append(_case(f'{n}\n'+'\n'.join(rows)+'\n',i))
        rows=[' '.join(str(10**9-(a*100+b)) for b in range(a+1,100)) for a in range(99)];out.append({'input':'100\n'+'\n'.join(rows)+'\n','category':'constraint_max'})
    elif pid=='abc451_b':
        for i in range(1,18):
            m=1+i%9;n=2+i;ab=[(1+(i+j)%m,1+(i*2+j*3)%m) for j in range(n)]
            out.append(_case(f'{n} {m}\n'+'\n'.join(f'{a} {b}' for a,b in ab)+'\n',i))
        ab='\n'.join(f'{i%100+1} {(i*37)%100+1}' for i in range(100));out.append({'input':'100 100\n'+ab+'\n','category':'constraint_max'})
    elif pid=='abc452_b':
        vals=[x for x in product(range(3,11),repeat=2) if x!=(10,10)][:17];out=[_case(f'{h} {w}\n',i+1) for i,(h,w) in enumerate(vals)];out.append({'input':'10 10\n','category':'constraint_max'})
    elif pid=='abc453_b':
        for i in range(1,18):
            t=2+i;x=1+(i*7)%100;a=[(i*13+j*17)%101 for j in range(t+1)];out.append(_case(f'{t} {x}\n'+' '.join(map(str,a))+'\n',i))
        a=[i%101 for i in range(101)];out.append({'input':'100 100\n'+' '.join(map(str,a))+'\n','category':'constraint_max'})
    elif pid=='abc454_b':
        for i in range(1,18):
            n=1+i;m=1+(i*3)%20;f=[1+(i+j*2)%m for j in range(n)];out.append(_case(f'{n} {m}\n'+' '.join(map(str,f))+'\n',i))
        out.append({'input':'100 100\n'+' '.join(map(str,range(1,101)))+'\n','category':'constraint_max'})
    elif pid=='abc455_b':
        for i in range(1,18):
            H=1+i%10;W=1+(i*3)%10;g=[''.join('#' if (r*W+c+i)%((i%4)+2)==0 else '.' for c in range(W)) for r in range(H)];out.append(_case(f'{H} {W}\n'+'\n'.join(g)+'\n',i))
        g=[''.join('#' if (r+c)%2 else '.' for c in range(10)) for r in range(10)];out.append({'input':'10 10\n'+'\n'.join(g)+'\n','category':'constraint_max'})
    elif pid=='abc456_b':
        for i in range(1,18):
            x=i; digits=[]
            for _ in range(3):digits.append(x%6+1);x//=6
            dice=[[digits[0],digits[1],digits[2],4,5,6],[1,2,3,4,5,6],[6,5,4,3,2,1]];out.append(_case('\n'.join(' '.join(map(str,row)) for row in dice)+'\n',i))
        out.append({'input':'6 6 6 6 6 6\n5 5 5 5 5 5\n4 4 4 4 4 4\n','category':'constraint_max'})
    elif pid=='abc457_b':
        for i in range(1,18):
            n=1+i;rows=[]
            for j in range(n):
                L=1+(i+j)%5;vals=[1+(i*17+j*13+k)%1000 for k in range(L)];rows.append(str(L)+' '+' '.join(map(str,vals)))
            x=1+i%n;y=1;out.append(_case(f'{n}\n'+'\n'.join(rows)+f'\n{x} {y}\n',i))
        vals=' '.join(['1000']*200000);out.append({'input':'1\n200000 '+vals+'\n1 200000\n','category':'constraint_max'})
    elif pid=='abc458_b':
        vals=[(1+i%17,1+(i*5)%19) for i in range(17)];out=[_case(f'{h} {w}\n',i+1) for i,(h,w) in enumerate(vals)];out.append({'input':'50 50\n','category':'constraint_max'})
    elif pid=='abc459_b':
        words=['apple','dog','fish','jazz','queen','tree','wolf','xyz','mobile','python','race','sun','value','keyboard','network','cloud','zebra']
        for i in range(1,18):
            n=1+i%10;s=[words[(i+j)%len(words)] for j in range(n)];out.append(_case(f'{n}\n'+'\n'.join(s)+'\n',i))
        out.append({'input':'10\n'+'\n'.join(['zzzzzzzzzz']*10)+'\n','category':'constraint_max'})
    elif pid=='abc460_b':
        for i in range(1,18):
            t=1+i%10;rows=[]
            for j in range(t):rows.append(f'{i+j} {2*i+j} {1+(i+j)%20} {3*i+j} {i+2*j} {1+(2*i+j)%20}')
            out.append(_case(f'{t}\n'+'\n'.join(rows)+'\n',i))
        rows=['0 0 1000000000 1000000000 1000000000 1000000000']*100;out.append({'input':'100\n'+'\n'.join(rows)+'\n','category':'constraint_max'})
    elif pid=='abc461_b':
        for i in range(1,18):
            n=2+i;a=list(range(1,n+1));shift=i%n;a=a[shift:]+a[:shift];b=[0]*n
            for owner,axe in enumerate(a,1):b[axe-1]=owner
            if i%2==0:b[0],b[1]=b[1],b[0]
            out.append(_case(f'{n}\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n',i))
        a=list(range(100,0,-1));b=[0]*100
        for owner,axe in enumerate(a,1):b[axe-1]=owner
        out.append({'input':'100\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n','category':'constraint_max'})
    elif pid=='abc462_b':
        for i in range(1,18):
            n=2+i;rows=[]
            for p in range(1,n+1):
                vals=[x for x in range(1,n+1) if x!=p and (x+p+i)%3==0]
                if not vals:vals=[1 if p!=1 else 2]
                rows.append(str(len(vals))+' '+' '.join(map(str,vals)))
            out.append(_case(f'{n}\n'+'\n'.join(rows)+'\n',i))
        rows=[]
        for p in range(1,101):
            vals=[x for x in range(1,101) if x!=p];rows.append('99 '+' '.join(map(str,vals)))
        out.append({'input':'100\n'+'\n'.join(rows)+'\n','category':'constraint_max'})
    elif pid=='abc463_b':
        for i in range(1,18):
            n=1+i;x='ABCDE'[i%5];rows=[''.join('o' if (r*5+c+i)%7==0 else 'x' for c in range(5)) for r in range(n)];out.append(_case(f'{n} {x}\n'+'\n'.join(rows)+'\n',i))
        out.append({'input':'100 E\n'+'\n'.join(['ooooo']*100)+'\n','category':'constraint_max'})
    elif pid=='abc464_b':
        for i in range(1,18):
            H=2+i;W=3+i;g=[['.']*W for _ in range(H)];g[i%H][(i*2)%W]='#';g[(i*3)%H][(i*5)%W]='#';out.append(_case(f'{H} {W}\n'+'\n'.join(''.join(r) for r in g)+'\n',i))
        g=[['.']*50 for _ in range(50)];g[0][0]=g[49][49]='#';out.append({'input':'50 50\n'+'\n'.join(''.join(r) for r in g)+'\n','category':'constraint_max'})
    else:raise ValueError(pid)
    if len(out)!=18 or len({x['input'] for x in out})!=18 or out[-1]['category']!='constraint_max':raise ValueError(f'{pid}: generated case construction failed ({len(out)}, {len({x["input"] for x in out})})')
    for row in out:validate(pid,row['input'])
    return out

REFERENCE_CODE={
'abc447_b':"from collections import Counter\ns=input().strip();c=Counter(s);m=max(c.values());print(''.join(x for x in s if c[x]!=m))\n",
'abc448_b':"N,M=map(int,input().split());C=list(map(int,input().split()));s=[0]*M\nfor _ in range(N):\n a,b=map(int,input().split());s[a-1]+=b\nprint(sum(min(C[i],s[i]) for i in range(M)))\n",
'abc449_b':"H,W,Q=map(int,input().split())\nfor _ in range(Q):\n t,x=map(int,input().split())\n if t==1:print(x*W);H-=x\n else:print(x*H);W-=x\n",
'abc450_b':"N=int(input());C=[[0]*N for _ in range(N)]\nfor i in range(N-1):\n a=list(map(int,input().split()))\n for j,x in enumerate(a,i+1):C[i][j]=x\nok=False\nfor b in range(1,N-1):\n for a in range(b):\n  for c in range(b+1,N):ok|=C[a][b]+C[b][c]<C[a][c]\nprint('Yes' if ok else 'No')\n",
'abc451_b':"N,M=map(int,input().split());d=[0]*M\nfor _ in range(N):\n a,b=map(int,input().split());d[a-1]-=1;d[b-1]+=1\nprint(*d,sep='\\n')\n",
'abc452_b':"H,W=map(int,input().split())\nfor i in range(H):print('#'*W if i==0 or i==H-1 else '#'+'.'*(W-2)+'#')\n",
'abc453_b':"T,X=map(int,input().split());A=list(map(int,input().split()));last=0;print(0,A[0])\nfor i in range(1,T+1):\n if abs(A[i]-A[last])>=X:print(i,A[i]);last=i\n",
'abc454_b':"N,M=map(int,input().split());F=list(map(int,input().split()));c=[0]*(M+1)\nfor x in F:c[x]+=1\nprint('Yes' if all(x<=1 for x in c) else 'No');print('Yes' if all(c[i]>=1 for i in range(1,M+1)) else 'No')\n",
'abc455_b':"H,W=map(int,input().split());S=[input().strip() for _ in range(H)];ans=0\nfor a in range(H):\n for b in range(a,H):\n  for c in range(W):\n   for d in range(c,W):\n    R=[S[r][c:d+1] for r in range(a,b+1)];ans+=R==[x[::-1] for x in R[::-1]]\nprint(ans)\n",
'abc456_b':"from itertools import permutations\nD=[list(map(int,input().split())) for _ in range(3)];cnt=[[row.count(x) for x in (4,5,6)] for row in D];good=0\nfor p in permutations(range(3)):good+=cnt[0][p[0]]*cnt[1][p[1]]*cnt[2][p[2]]\nprint(good/216)\n",
'abc457_b':"N=int(input());A=[]\nfor _ in range(N):\n z=list(map(int,input().split()));A.append(z[1:])\nX,Y=map(int,input().split());print(A[X-1][Y-1])\n",
'abc458_b':"H,W=map(int,input().split())\nfor r in range(H):print(*[(r>0)+(r+1<H)+(c>0)+(c+1<W) for c in range(W)])\n",
'abc459_b':"N=int(input());groups=['abc','def','ghi','jkl','mno','pqrs','tuv','wxyz'];mp={}\nfor i,g in enumerate(groups,2):\n for c in g:mp[c]=str(i)\nprint(''.join(mp[input().strip()[0]] for _ in range(N)))\n",
'abc460_b':"T=int(input())\nfor _ in range(T):\n x1,y1,r1,x2,y2,r2=map(int,input().split());d=(x1-x2)**2+(y1-y2)**2\n print('Yes' if (r1-r2)**2<=d<=(r1+r2)**2 else 'No')\n",
'abc461_b':"N=int(input());A=list(map(int,input().split()));B=list(map(int,input().split()));inv=[0]*N\nfor axe,owner in enumerate(B,1):inv[owner-1]=axe\nprint('Yes' if A==inv else 'No')\n",
'abc462_b':"N=int(input());ans=[[] for _ in range(N)]\nfor i in range(N):\n z=list(map(int,input().split()))[1:]\n for x in z:ans[x-1].append(i+1)\nfor a in ans:print(len(a),*a)\n",
'abc463_b':"N,X=input().split();j=ord(X)-65;print('Yes' if any(input().strip()[j]=='o' for _ in range(int(N))) else 'No')\n",
'abc464_b':"H,W=map(int,input().split());S=[input().strip() for _ in range(H)];rows=[i for i,r in enumerate(S) if '#' in r];cols=[j for j in range(W) if any(S[i][j]=='#' for i in range(H))];a,b=min(rows),max(rows);c,d=min(cols),max(cols)\nfor r in S[a:b+1]:print(r[c:d+1])\n",
}

def reference_solution(pid:str)->str:return REFERENCE_CODE[pid]
