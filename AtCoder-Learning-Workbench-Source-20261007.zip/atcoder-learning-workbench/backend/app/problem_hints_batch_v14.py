"""Manually authored three-level hints for ABC088–ABC092 task-specific bank."""
HINTS_V14 = {
 'abc088_a': (
  '大きな額の硬貨で支払える部分と、残りの額を切り分けて考えてください。',
  '500円で割った余りを、持っている1円硬貨の枚数と比較します。',
  '疑似コード:\nN,A = input_numbers()\nremain = N % 500\nprint("Yes" if remain <= A else "No")'),
 'abc088_b': (
  '交互に選ぶとき、手番ごとに何を取るのが有利か考えてください。',
  '数列を降順にソートし、大きい順に交互に取った合計の差を求めます。',
  '疑似コード:\nA = sort_descending(cards)\nalice = sum(A[0::2])\nbob = sum(A[1::2])\nprint(alice - bob)'),
 'abc088_c': (
  '同じ列を見比べたとき、行が変わると値がどの程度変化するか考えてください。',
  '行ごとの差が列によらず一定かを調べると、行の値と列の値の和に分解できるかを判定できます。',
  '疑似コード:\na[i] = C[i][0]\nb[j] = C[0][j] - C[0][0]\nprint("Yes" if every(a[i]+b[j]==C[i][j]) else "No")'),
 'abc089_a': (
  '条件を満たすグループを1つ増やすには最低何人必要か考えてください。',
  '3人以上のグループの個数を最大にするには、各グループを基本3人として人数を割ります。',
  '疑似コード:\nN=read_integer()\nprint(N // 3)'),
 'abc089_b': (
  'すべての種類が必ずあると分かっているとき、残りの種類があるかどうかだけで判定できます。',
  '必ずあるP/W/G以外のYが含まれるかを、集合または存在判定で調べます。',
  '疑似コード:\ncolors=read_colors()\nprint("Four" if "Y" in colors else "Three")'),
 'abc089_c': (
  '名前の最初の文字以外の部分は、数え方に影響するでしょうか。',
  'M/A/R/C/Hで始まる人を各頭文字ごとに数え、異なる3種類の頭文字の組合せについて人数の積を足します。',
  '疑似コード:\ncount=frequency(first_character(name) for name in names)\nans=0\nfor x,y,z in combinations("MARCH",3):\n  ans+=count[x]*count[y]*count[z]\nprint(ans)'),
 'abc090_a': (
  '取り出すのは盤面全体ではなく、左上から右下へ並ぶ3文字です。',
  '3行の文字列について、行番号と同じ列番号の文字を1つずつ選びます。',
  '疑似コード:\nrows=read_three_strings()\nprint(rows[0][0]+rows[1][1]+rows[2][2])'),
 'abc090_b': (
  '与えられた範囲を端から順に調べる方法を考えてください。',
  '整数を文字列に直し、逆順にした文字列と一致する回文数だけ数えます。',
  '疑似コード:\nans=0\nfor x in A..B:\n  s=str(x)\n  if s==reverse(s):ans+=1\nprint(ans)'),
 'abc091_a': (
  '持っているお金と買いたい品物の値段を直接比べてください。',
  '2枚の硬貨の合計金額が価格C以上かどうかで判定します。',
  '疑似コード:\na,b,c=read_integers()\nprint("Yes" if a+b>=c else "No")'),
 'abc091_b': (
  'ある文字列を選んだときの得失を、文字列ごとに整理してください。',
  '青と赤のカードについて各文字列の出現回数をCounterで数え、差の最大値と0を比較します。',
  '疑似コード:\nblue=Counter(blue_strings)\nred=Counter(red_strings)\nprint(max([0]+[blue[s]-red[s] for s in blue]))'),
 'abc092_a': (
  '電車とバスの選択は、お互いに影響するでしょうか。',
  '電車で安い方、バスで安い方をそれぞれ選んで合計します。',
  '疑似コード:\nprint(min(A,B)+min(C,D))'),
 'abc092_b': (
  '1人について、何日目に食べたかを並べてみてください。',
  'Aiごとに1, Ai+1, 2Ai+1,…のうちD日以内の日数を数え、残ったXに足します。',
  '疑似コード:\nans=X\nfor a in A:\n  ans+=(D-1)//a+1\nprint(ans)'),
 'abc092_c': (
  '1か所だけ寄らないとき、移動経路のどの部分が変化するでしょうか。',
  '元の経路の総移動距離を求め、各iについて前後の2区間を消して隣同士を直結した距離を加えます。',
  '疑似コード:\nP=[0]+A+[0]\ntotal=sum(abs(P[i+1]-P[i]) for i in 0..N)\nfor i in 1..N:\n  ans=total-abs(P[i]-P[i-1])-abs(P[i+1]-P[i])+abs(P[i+1]-P[i-1])\n  print(ans)'),
}
