"""Reviewed ABC018/019/020 B input families and independently implemented checkers.

Official statements viewed through web search; HTML originals are not archived.
"""
from __future__ import annotations
import random
import re
from itertools import groupby

TASKS = ('abc018_2', 'abc019_2', 'abc020_b')
WORD = re.compile(r'[a-z]{1,1000}', re.ASCII)
NUMBER = re.compile(r'[1-9][0-9]*', re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('invalid task/input ending')
    lines = raw[:-1].split('\n')
    if pid == 'abc018_2':
        if len(lines) < 3 or not re.fullmatch(r'[a-z]{2,100}', lines[0], re.ASCII):
            # The statement says |S| >= 1, but l < r requires |S| >= 2.
            raise ValueError('invalid reversal word')
        if not NUMBER.fullmatch(lines[1]):
            raise ValueError('invalid number of operations')
        n = int(lines[1]); s = lines[0]
        if not 1 <= n <= 100 or len(lines) != n + 2:
            raise ValueError('invalid operation count')
        operations = []
        for row in lines[2:]:
            pair = row.split(' ')
            if len(pair) != 2 or not all(NUMBER.fullmatch(x) for x in pair):
                raise ValueError('invalid reversal interval')
            l, r = map(int, pair)
            if not 1 <= l < r <= len(s):
                raise ValueError('invalid reversal interval bounds')
            operations.append((l, r))
        return s, operations
    if pid == 'abc019_2':
        if len(lines) != 1 or not WORD.fullmatch(lines[0]):
            raise ValueError('invalid compression word')
        return lines[0]
    if len(lines) != 1:
        raise ValueError('invalid integers line')
    items = lines[0].split(' ')
    if len(items) != 2 or not all(NUMBER.fullmatch(x) for x in items):
        raise ValueError('invalid integers')
    a, b = map(int, items)
    if not 1 <= a <= 999 or not 1 <= b <= 999:
        raise ValueError('invalid integer bounds')
    return a, b


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        parsed = validate(pid, raw)
    except ValueError:
        return False
    if not isinstance(output, str) or '\n' in output or '\r' in output:
        return False
    if pid == 'abc018_2':
        s, operations = parsed
        # Position mapping, rather than mutating/reversing substrings.
        locations = list(range(len(s)))
        for l, r in operations:
            left, right = l - 1, r - 1
            while left < right:
                locations[left], locations[right] = locations[right], locations[left]
                left += 1
                right -= 1
        return output == ''.join(s[i] for i in locations)
    if pid == 'abc019_2':
        # itertools.groupby is independent of the reference's manual run counter.
        return output == ''.join(ch + str(sum(1 for _ in run)) for ch, run in groupby(parsed))
    a, b = parsed
    # Arithmetic digit count, not string concatenation.
    factor = 10
    while factor <= b:
        factor *= 10
    return output == str(2 * (a * factor + b))


def generate(pid: str, seed: int = 53) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    rng = random.Random(f'abc-v53:{pid}:{seed}')
    cases = []
    seen = set()
    def add(category, raw):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            cases.append({'category': category, 'input': raw})
    if pid == 'abc018_2':
        def fmt(s, ops):
            return f'{s}\n{len(ops)}\n' + ''.join(f'{l} {r}\n' for l, r in ops)
        presets = [
            ('ab', [(1, 2)]), ('aa', [(1, 2)]), ('abc', [(1, 3)]),
            ('abcdef', [(3, 5), (1, 4)]), ('redcoat', [(1, 7), (1, 2), (3, 4)]),
            ('abcdef', [(1, 6)] * 2), ('abca', [(1, 4)] * 3),
            ('z' * 100, [(1, 100)]), ('a' * 99 + 'b', [(1, 100)]),
            ('abcdefghijklmnopqrstuvwxyz', [(1, 26), (5, 19)]),
            ('abcdefghij', [(1, 2)] * 100),
            ('ab' * 50, [(1, 100)] * 99),
        ]
        for s, ops in presets:
            add('boundary' if len(s) in (2, 100) or len(ops) == 100 else 'normal', fmt(s, ops))
        while len(cases) < 17:
            size = rng.randint(2, 100)
            word = ''.join(rng.choice('abcdef') for _ in range(size))
            ops = [tuple(sorted(rng.sample(range(1, size + 1), 2))) for _ in range(rng.randint(1, 100))]
            add('normal', fmt(word, ops))
        add('constraint_max', fmt('ab' * 50, [(1, 100)] * 100))
    elif pid == 'abc019_2':
        presets = ['a', 'z', 'ab', 'aa', 'aabbbaad', 'aabbbbbbbbbbbbxyza',
                   'edcba', 'a' * 9, 'a' * 10, 'a' * 99, 'a' * 100,
                   'ab' * 500, 'a' * 999 + 'b', 'a' * 500 + 'b' * 500,
                   'abcdefghijklmnopqrstuvwxyz' * 38 + 'abcdefghijkl']
        for s in presets:
            add('boundary' if len(s) in (1, 1000) else 'normal', s + '\n')
        while len(cases) < 17:
            s = ''.join(rng.choice('abcd') for _ in range(rng.randint(1, 1000)))
            add('normal', s + '\n')
        add('constraint_max', 'a' * 1000 + '\n')
    else:
        presets = [(1, 1), (1, 9), (1, 10), (1, 99), (1, 100), (1, 999),
                   (9, 1), (10, 1), (99, 1), (100, 1), (999, 1),
                   (12, 34), (99, 99), (999, 99), (999, 100), (1, 23), (999, 998)]
        for a, b in presets:
            add('boundary' if 1 in (a, b) or 999 in (a, b) else 'normal', f'{a} {b}\n')
        add('constraint_max', '999 999\n')
    if len(cases) != 18 or cases[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: generated {len(cases)}, expected 18')
    return cases
