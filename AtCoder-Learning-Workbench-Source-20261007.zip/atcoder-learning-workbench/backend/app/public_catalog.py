"""Read the provenance-bearing public snapshot only when the local catalog is empty."""
import json
from pathlib import Path
import re

from .database import db

SNAPSHOT = Path(__file__).resolve().parents[1] / "public_data/catalog.json"
COLUMNS = ["problem_id", "contest_id", "problem_index", "title", "contest_title",
           "contest_start_epoch", "difficulty", "is_experimental", "url", "last_synced_at"]


def load_snapshot(path: Path = SNAPSHOT) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != 1 or payload.get("columns") != COLUMNS:
        raise ValueError("Unsupported bundled public catalog format")
    if not isinstance(payload.get("fetched_at"), int) or payload["fetched_at"] <= 0:
        raise ValueError("Missing public catalog fetch timestamp")
    rows = payload.get("rows")
    if not isinstance(rows, list) or not rows or len(rows) != payload.get("diagnostics", {}).get("problems"):
        raise ValueError("Incomplete bundled public catalog")
    ids = set()
    for row in rows:
        if not isinstance(row, list) or len(row) != len(COLUMNS):
            raise ValueError("Invalid public catalog row")
        pid, contest, letter, title, _, _, difficulty, experimental, url, timestamp = row
        if (not isinstance(pid, str) or not re.fullmatch(r"[A-Za-z0-9_]+", pid)
                or not isinstance(contest, str) or not re.fullmatch(r"abc\d{3,}", contest)
                or not isinstance(letter, str) or letter not in "ABCDEFG" or len(letter) != 1 or not isinstance(title, str)
                or url != f"https://atcoder.jp/contests/{contest}/tasks/{pid}"
                or (difficulty is not None and not isinstance(difficulty, int))
                or experimental not in (0, 1) or timestamp != payload.get("fetched_at") or pid in ids):
            raise ValueError("Invalid or duplicated public catalog metadata")
        ids.add(pid)
    expected = {f"https://kenkoooo.com/atcoder/resources/{name}" for name in
                ("problems.json", "contests.json", "contest-problem.json", "problem-models.json")}
    sources = payload.get("sources", [])
    if {source.get("url") for source in sources} != expected or any(
            not re.fullmatch(r"[0-9a-f]{64}", source.get("canonical_json_sha256", "")) for source in sources):
        raise ValueError("Missing public catalog provenance")
    return payload


def initialize_public_catalog() -> dict:
    with db() as con:
        count = con.execute("SELECT COUNT(*) FROM problems").fetchone()[0]
    if count:
        return {"origin": "existing-local-database", "problems": count}
    snapshot = load_snapshot()
    from .service import store_problem_catalog
    return store_problem_catalog([tuple(row) for row in snapshot["rows"]], snapshot["diagnostics"],
                                 now=snapshot["fetched_at"], origin="bundled-public-snapshot")
