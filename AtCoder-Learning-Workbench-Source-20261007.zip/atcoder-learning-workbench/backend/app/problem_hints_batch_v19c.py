"""ABC121–124 C three-stage hints. Stage one does not name the algorithm."""
HINTS_V19C = {
 'abc121_c': (
  '同じ品物を複数の場所で買うなら、買う順番によって合計金額がどう変わるか考えましょう。',
  '1本当たりの価格が安い店から必要本数だけ購入する貪欲法です。価格の昇順に店をソートします。',
  '疑似コード:\nN,M = read_two_ints()\nstores = read_price_and_stock(N)\nsort(stores, by=price_ascending)\ntotal=0\nfor price,stock in stores:\n  amount=min(M,stock)\n  total+=price*amount\n  M-=amount\n  if M==0: break\nprint(total)'),
 'abc122_c': (
  '同じ文字列の複数区間を調べます。区間を毎回最初から数えずに済む準備を考えましょう。',
  '隣り合う2文字がACとなる回数の累積和を作成し、各区間[l,r]を差で計算します。',
  '疑似コード:\nN,Q = read_two_ints(); S=read_string()\nprefix[0..N]=0\nfor i in 1..N-1:\n  prefix[i+1]=prefix[i]+(S[i-1:i+1]=="AC")\nrepeat Q times:\n  l,r=read_two_ints()\n  print(prefix[r]-prefix[l])'),
 'abc123_c': (
  '全員が移動する時間を考える際、最も少ない人しか運べない区間に注目してください。',
  '5区間を通る最低5分に加え、最小輸送容量bに対するceil(N/b)-1分の待ち時間を加えます。',
  '疑似コード:\nN=read_integer()\ncapacity=read_five_integers()\nb=min(capacity)\nprint((N+b-1)//b+4)'),
 'abc124_c': (
  '隣同士が必ず違う色なら、全体の並び方が何通りに限られるか考えましょう。',
  '0101…と1010…という2パターンに対し、各位置の不一致を数えて小さい方を出力します。',
  '疑似コード:\nS=read_binary_string()\nwrong=sum(S[i] != str(i%2) for i in 0..len(S)-1)\nprint(min(wrong,len(S)-wrong))'),
}
