"""Reviewed ABC193--198 C: full-scale independent counting and partition oracles."""
from __future__ import annotations
from collections import Counter
from itertools import combinations
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(193,199))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'field count');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number in (193,195,196):
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];maximum=10**10 if number==193 else 10**15 if number==195 else 10**12-1;require(1<=n<=maximum,'integer');return (n,)
    if number==198:
        require(len(rows)==1,'shape');r,x,y=ints(rows[0],3);require(1<=r<=100000 and 0<=x<=100000 and 0<=y<=100000 and (x,y)!=(0,0),'geometry');return r,x,y
    n=ints(rows[0],1)[0];require((2<=n<=300000 if number==194 else 1<=n<=20) and len(rows)==2,'shape');a=ints(rows[1],n);require(all(-200<=v<=200 for v in a) if number==194 else all(0<=v<2**30 for v in a),'values');return (a,)

def integer_root(n:int,k:int)->int:
    lo=0;hi=1<<((n.bit_length()+k-1)//k)
    while hi-lo>1:
        mid=(lo+hi)//2
        if mid**k<=n:lo=mid
        else:hi=mid
    return hi if hi**k<=n else lo

def mobius(n:int)->int:
    value=n;sign=1;prime=2
    while prime*prime<=value:
        if value%prime==0:
            value//=prime;sign=-sign
            if value%prime==0:return 0
        prime+=1
    return -sign if value>1 else sign

def nonpower_count(n:int)->int:
    return n+sum(mobius(k)*(integer_root(n,k)-1) for k in range(2,n.bit_length()))

def partition_xor(a:tuple[int,...])->int:
    n=len(a);segment=[[0]*n for _ in range(n)]
    for start in range(n):
        value=0
        for end in range(start,n):value|=a[end];segment[start][end]=value
    possible=[set() for _ in range(n+1)];possible[0].add(0)
    for end in range(1,n+1):
        for start in range(end):possible[end].update(value^segment[start][end-1] for value in possible[start])
    return min(possible[n])

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==193:return str(nonpower_count(cast(int,data[0])))
    if number==194:
        counts=Counter(cast(tuple[int,...],data[0]));return str(sum((a-b)**2*counts[a]*counts[b] for a,b in combinations(counts,2)))
    if number==195:
        n=cast(int,data[0]);total=0;lower=1
        for width in range(1,len(str(n))+1):
            upper=min(n,lower*10-1);total+=(upper-lower+1)*((width-1)//3);lower*=10
        return str(total)
    if number==196:
        n=cast(int,data[0]);answer=0
        for width in range(1,7):
            lower=10**(width-1);upper=min(10**width-1,n//(10**width+1));answer+=max(0,upper-lower+1)
        return str(answer)
    if number==197:return str(partition_xor(cast(tuple[int,...],data[0])))
    r,x,y=cast(tuple[int,int,int],data);distance=x*x+y*y
    if distance==r*r:return '1'
    lo=1;hi=200001
    while hi-lo>1:
        mid=(lo+hi)//2
        if (mid*r)**2>=distance:hi=mid
        else:lo=mid
    return str(hi)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc193_c':"from math import isqrt\nn=int(input());powers=set()\nfor a in range(2,isqrt(n)+1):\n value=a*a\n while value<=n:powers.add(value);value*=a\nprint(n-len(powers))\n",
'abc194_c':"n=int(input());a=list(map(int,input().split()));print(n*sum(v*v for v in a)-sum(a)**2)\n",
'abc195_c':"n=int(input());threshold=1000;answer=0\nwhile threshold<=n:answer+=n-threshold+1;threshold*=1000\nprint(answer)\n",
'abc196_c':"n=int(input());half=1\nwhile int(str(half)*2)<=n:half+=1\nprint(half-1)\n",
'abc197_c':"n=int(input());a=list(map(int,input().split()));best=1<<30\nfor mask in range(1<<(n-1)):\n xor=0;value=0\n for j,v in enumerate(a):\n  value|=v\n  if j==n-1 or mask>>j&1:xor^=value;value=0\n best=min(best,xor)\nprint(best)\n",
'abc198_c':"from math import isqrt\nr,x,y=map(int,input().split());distance=x*x+y*y\nif distance<r*r:print(2)\nelse:\n steps=isqrt(distance)//r\n if (steps*r)**2<distance:steps+=1\n print(steps)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16300+number);raws:list[str]=[]
    if number==193:raws=[f'{n}\n' for n in (1,2,3,4,7,8,9,15,16,26,27,63,64,100000,9999999999,9999800001,9999999998,10000000000)]
    elif number==194:
        def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[array([0,0]),array([-200,200]),array([200,200]),array([-1,0,1])]+[array([rng.randrange(-200,201) for _ in range(n)]) for n in range(4,16)]+[array([-200]*150000+[200]*150000),array([200]*300000)]
    elif number==195:raws=[f'{n}\n' for n in (1,999,1000,1001,999999,1000000,1000001,999999999,1000000000,1000000001,999999999999,1000000000000,1000000000001,27182818284590,999999999999998,999999999999999,123456789012345,1000000000000000)]
    elif number==196:raws=[f'{n}\n' for n in (1,10,11,12,22,33,99,100,1010,1312,1313,1333,9999,10000,10000000,999999999998,9999999999,999999999999)]
    elif number==197:
        def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[array([0]),array([2**30-1]),array([1,1]),array([1,5,7])]+[array([rng.randrange(0,2**30) for _ in range(n)]) for n in range(4,16)]+[array([rng.randrange(0,2**30) for _ in range(20)]),array([2**30-1]*20)]
    else:raws=[line(v) for v in ((1,0,1),(1,1,0),(1,1,1),(2,1,0),(5,3,4),(5,11,0),(5,15,0),(3,4,4),(100000,1,0),(100000,0,1),(1,100000,100000),(100000,100000,0),(100000,0,100000),(99999,100000,0),(100000,99999,0),(7,100000,99999),(99999,100000,100000),(100000,100000,100000))]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc193_c':('a^bで表せる数を列挙し、重複を除きます。','aはsqrt(N)以下に絞れます。a²からaを掛けていき、N以下の累乗を集合へ入れます。','疑似コード: powers=set(); for a=2..isqrt(N): value=a*a; while value<=N: powers.add(value); value*=a; print(N-len(powers))。'),
'abc194_c':('差の二乗を展開すると、全ペアを直接列挙する必要がありません。','全体の和をS、二乗和をQとすると、答えはNQ−S²です。','疑似コード: S=sum(A); Q=sum(a*a for a in A); print(N*Q-S*S)。'),
'abc195_c':('各コンマが書かれる最小の数を考えます。','最初のコンマは1000以上、次は10⁶以上です。各境界以上の数の個数を足します。','疑似コード: threshold=1000; answer=0; while threshold<=N: answer+=N-threshold+1; threshold*=1000; print(answer)。'),
'abc196_c':('条件を満たす数は、ある正整数を文字列として2回繰り返したものです。','前半の整数を1から順に増やし、繰り返した数がNを超えたら終了します。','疑似コード: half=1; while integer(str(half)+str(half))<=N: half+=1; print(half-1)。'),
'abc197_c':('区間を分ける境界はN−1箇所で、それぞれ切るか切らないかです。','全境界マスクを列挙し、区間内ORを区間境界でXORへ合成して最小値を求めます。','疑似コード: for cut_mask in0..2^(N-1)-1: segment_or=xor=0; for index: segment_or|=A[index]; if cut or last: xor^=segment_or; segment_or=0; answer=min(answer,xor); print(answer)。'),
'abc198_c':('1歩で届くのは原点から距離がちょうどRの点だけです。','距離がR未満なら2歩。R以上なら、距離をRで割った値を切り上げます。整数二乗で境界を判定します。','疑似コード: squared=X*X+Y*Y; if squared<R*R:2; else: steps=isqrt(squared)//R; if (steps*R)^2<squared: steps+=1; print(steps)。')}

TITLES={'abc193_c': 'Unexpressed', 'abc194_c': 'Squared Error', 'abc195_c': 'Comma', 'abc196_c': 'Doubled', 'abc197_c': 'ORXOR', 'abc198_c': 'Compass Walking'}
PUBLISHED_SAMPLES={'abc193_c': [{'input': '8\n', 'expected': '6\n'}, {'input': '100000\n', 'expected': '99634\n'}], 'abc194_c': [{'input': '3\n2 8 4\n', 'expected': '56\n'}, {'input': '5\n-5 8 9 -4 -3\n', 'expected': '950\n'}], 'abc195_c': [{'input': '1010\n', 'expected': '11\n'}, {'input': '27182818284590\n', 'expected': '107730272137364\n'}], 'abc196_c': [{'input': '33\n', 'expected': '3\n'}, {'input': '1333\n', 'expected': '13\n'}, {'input': '10000000\n', 'expected': '999\n'}], 'abc197_c': [{'input': '3\n1 5 7\n', 'expected': '2\n'}, {'input': '3\n10 10 10\n', 'expected': '0\n'}, {'input': '4\n1 3 3 1\n', 'expected': '0\n'}], 'abc198_c': [{'input': '5 15 0\n', 'expected': '3\n'}, {'input': '5 11 0\n', 'expected': '3\n'}, {'input': '3 4 4\n', 'expected': '2\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
