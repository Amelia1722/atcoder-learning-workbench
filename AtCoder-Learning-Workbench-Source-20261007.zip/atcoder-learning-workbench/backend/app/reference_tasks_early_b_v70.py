"""ABC068–070 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS=('abc068_b','abc069_b','abc070_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NONNEG=re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
LOWER=re.compile(r'[a-z]+',re.ASCII)

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc068_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('N')
        n=int(lines[0])
        if not 1<=n<=100: raise ValueError('range')
        return n
    if pid=='abc069_b':
        if len(lines)!=1 or not 3<=len(lines[0])<=100 or LOWER.fullmatch(lines[0]) is None:
            raise ValueError('string')
        return lines[0]
    if len(lines)!=1: raise ValueError('line count')
    parts=lines[0].split(' ')
    if len(parts)!=4 or any(NONNEG.fullmatch(x) is None for x in parts): raise ValueError('times')
    a,b,c,d=map(int,parts)
    if not (0<=a<b<=100 and 0<=c<d<=100): raise ValueError('range/order')
    return a,b,c,d

def independent_check(pid:str,raw:str,output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc068_b':
        n=value
        best=1; best_count=-1
        for x in range(1,n+1):
            y=x; count=0
            while y%2==0:
                y//=2; count+=1
            if count>best_count:
                best_count=count; best=x
        return output==str(best)
    if pid=='abc069_b':
        s=value
        return output==s[0]+str(len(s)-2)+s[-1]
    a,b,c,d=value
    overlap=0
    for t in range(100):
        if a<=t<b and c<=t<d: overlap+=1
    return output==str(overlap)

def generate(pid:str,seed:int=70)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v70:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc068_b':
        for n in [1,2,3,4,5,7,8,15,16,17,31,32,33,63,64,65,99]:
            add('boundary' if n in (1,2,64,65,99) else 'normal',f'{n}\n')
        add('constraint_max','100\n')
    elif pid=='abc069_b':
        fixtures=['abc','xyz','aaaa','smiles','internationalization','atcoder','abcdefghij','abca','zzzzz','contest','python','helloworld']
        for s in fixtures: add('boundary' if len(s) in (3,4) else 'normal',s+'\n')
        while len(rows)<17:
            length=rng.randint(3,40)
            s=''.join(chr(97+rng.randrange(26)) for _ in range(length))
            add('random',s+'\n')
        add('constraint_max','a'+'b'*98+'z\n')
    else:
        fixtures=[(0,1,0,1),(0,1,1,2),(0,2,1,2),(0,75,25,100),(0,33,66,99),
                  (10,90,20,80),(25,75,0,100),(0,100,25,75),(50,100,0,50),(20,21,20,21),
                  (1,99,2,98),(20,80,80,100),(20,80,79,100),(30,60,0,30)]
        for a,b,c,d in fixtures:
            add('boundary' if min(b-a,d-c)==1 or b==c or d==a else 'normal',f'{a} {b} {c} {d}\n')
        while len(rows)<17:
            a=rng.randint(0,99); b=rng.randint(a+1,100)
            c=rng.randint(0,99); d=rng.randint(c+1,100)
            add('random',f'{a} {b} {c} {d}\n')
        add('constraint_max','0 100 0 100\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
