"""Private ABC264--269 D strict domains and independent discrete oracles."""
from __future__ import annotations
from collections import Counter,deque
from dataclasses import dataclass,field
from functools import lru_cache
from itertools import permutations
from math import factorial,comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(264,270));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc268_d':'semantic'}
CHECKER_IDS={'abc268_d':'abc268_d'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc264_d':require(len(r)==1 and len(r[0])==7 and set(r[0])==set('atcoder'),'permutation');return (r[0],)
 if pid=='abc265_d':
  n,p,q,rr=ints(r[0],4);require(3<=n<=200000 and all(1<=v<=10**15 for v in (p,q,rr)) and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=v<=10**9 for v in a),'Ai');return (p,q,rr),a
 if pid=='abc266_d':
  n=ints(r[0],1)[0];require(1<=n<=100000 and len(r)==n+1,'shape');events=tuple(ints(s,3) for s in r[1:]);require(all(1<=t<=100000 and 0<=x<=4 and 1<=a<=10**9 for t,x,a in events) and all(a[0]<b[0] for a,b in zip(events,events[1:])),'events');return (events,)
 if pid=='abc267_d':
  n,m=ints(r[0],2);require(1<=m<=n<=2000 and len(r)==2,'shape');a=ints(r[1],n);require(all(abs(v)<=200000 for v in a),'Ai');return m,a
 if pid=='abc268_d':
  n,m=ints(r[0],2);require(1<=n<=8 and 0<=m<=100000 and len(r)==n+m+1,'shape');words=tuple(r[1:n+1]);banned=tuple(r[n+1:]);require(all(re.fullmatch(r'[a-z]{1,16}',s) is not None for s in words) and len(set(words))==n and sum(map(len,words))+n-1<=16,'Si');require(all(re.fullmatch(r'[a-z_]{3,16}',s) is not None for s in banned) and len(set(banned))==m,'Ti');return words,banned
 n=ints(r[0],1)[0];require(1<=n<=1000 and len(r)==n+1,'shape');points=tuple(ints(s,2) for s in r[1:]);require(all(abs(v)<=1000 for point in points for v in point) and len(set(points))==n,'coordinates');return (points,)

@lru_cache(maxsize=1)
def swap_graph_distances()->dict[str,int]:
 distances={'atcoder':0};queue=deque(['atcoder'])
 while queue:
  s=queue.popleft()
  for j in range(6):
   other=s[:j]+s[j+1]+s[j]+s[j+2:]
   if other not in distances:distances[other]=distances[s]+1;queue.append(other)
 return distances

def segment_window_ends(a:tuple[int,...],target:int)->list[int]:
 n=len(a);ends=[-1]*(n+1);right=total=0
 for left,value in enumerate(a):
  while right<n and total<target:total+=a[right];right+=1
  if total==target:ends[left]=right
  total-=value
 return ends

def three_segments(targets:tuple[int,int,int],a:tuple[int,...])->bool:
 first,second,third=(segment_window_ends(a,v) for v in targets)
 return any(end>=0 and second[end]>=0 and third[second[end]]>=0 for end in first)

def catches_event_compressed(events:tuple[tuple[int,int,int],...])->int:
 best=[0]+[-10**30]*4;previous=0
 for t,x,a in events:
  elapsed=t-previous;best=[max(best[j] for j in range(5) if abs(j-position)<=elapsed) for position in range(5)];best[x]+=a;previous=t
 return max(best)

def weighted_endpoint_rank(m:int,a:tuple[int,...])->int:
 # Last chosen position i is explicit; transitions use strict previous endpoint <i.
 n=len(a);previous=[-10**30]*n
 for i in range(n-m+1):previous[i]=a[i]
 for rank in range(2,m+1):
  current=[-10**30]*n;best=-10**30
  for i in range(rank-1,n-m+rank):best=max(best,previous[i-1]);current[i]=best+rank*a[i]
  previous=current
 return max(previous)

def username_grammar(words:tuple[str,...],s:str)->bool:
 return 3<=len(s)<=16 and re.fullmatch(r'[a-z]+(?:_+[a-z]+)*',s) is not None and Counter(re.split('_+',s))==Counter(words)

def username_capacity(words:tuple[str,...])->int:
 if len(words)==1:return int(3<=len(words[0])<=16)
 return factorial(len(words))*comb(16-sum(map(len,words)),len(words)-1)

def username_exists(words:tuple[str,...],banned:tuple[str,...])->bool:
 return username_capacity(words)>sum(username_grammar(words,s) for s in banned)

@dataclass(slots=True)
class PrefixNode:
 count:int=0
 children:dict[str,PrefixNode]=field(default_factory=dict)

def username_missing_prefix(words:tuple[str,...],banned:tuple[str,...])->str|None:
 legal_banned=[s for s in banned if username_grammar(words,s)];capacity=username_capacity(words)
 if capacity==len(legal_banned):return None
 if len(words)==1:return words[0]
 root=PrefixNode();forbidden=set(legal_banned)
 for name in legal_banned:
  node=root;node.count+=1
  for char in name:node=node.children.setdefault(char,PrefixNode());node.count+=1
 full=(1<<len(words))-1
 def search(mask:int,prefix:str,node:PrefixNode|None)->str|None:
  if mask==full:return prefix if prefix not in forbidden else None
  unused=[j for j in range(len(words)) if not mask>>j&1]
  for j in unused:
   other=[k for k in unused if k!=j];remaining_length=sum(len(words[k]) for k in other);minimum_gap=int(bool(prefix));maximum_gap=16-len(prefix)-len(words[j])-remaining_length-len(other) if prefix else 0
   for gap in range(minimum_gap,maximum_gap+1):
    chunk='_'*gap+words[j];next_prefix=prefix+chunk;budget=16-len(next_prefix)-remaining_length;branch_capacity=factorial(len(other))*comb(budget,len(other));next_node=node
    for char in chunk:next_node=next_node.children.get(char) if next_node is not None else None
    boundary_node=next_node.children.get('_') if next_node is not None else None
    blocked=(boundary_node.count if boundary_node is not None else 0) if other else int(next_prefix in forbidden)
    if blocked<branch_capacity:
     answer=search(mask|1<<j,next_prefix,next_node)
     if answer is not None:return answer
  return None
 return search(0,'',root)

def username_valid(words:tuple[str,...],banned:tuple[str,...],actual:str)->bool:
 s=actual.removesuffix('\n')
 if s=='-1':return not username_exists(words,banned)
 return username_grammar(words,s) and s not in set(banned)

def hex_pair_union(points:tuple[tuple[int,int],...])->int:
 n=len(points);parent=list(range(n));size=[1]*n;answer=n
 def root(v:int)->int:
  while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
  return v
 directions={(-1,-1),(-1,0),(0,-1),(0,1),(1,0),(1,1)}
 for j,(x,y) in enumerate(points):
  for i in range(j):
   xx,yy=points[i]
   if (x-xx,y-yy) not in directions:continue
   a=root(j);b=root(i)
   if a==b:continue
   if size[a]<size[b]:a,b=b,a
   parent[b]=a;size[a]+=size[b];answer-=1
 return answer

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc264_d':return str(swap_graph_distances()[cast(str,d[0])])+'\n'
 if pid=='abc265_d':return ('Yes' if three_segments(cast(tuple[int,int,int],d[0]),cast(tuple[int,...],d[1])) else 'No')+'\n'
 if pid=='abc266_d':return str(catches_event_compressed(cast(tuple[tuple[int,int,int],...],d[0])))+'\n'
 if pid=='abc267_d':return str(weighted_endpoint_rank(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc268_d':return (username_missing_prefix(cast(tuple[str,...],d[0]),cast(tuple[str,...],d[1])) or '-1')+'\n'
 return str(hex_pair_union(cast(tuple[tuple[int,int],...],d[0])))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc268_d':return username_valid(cast(tuple[str,...],d[0]),cast(tuple[str,...],d[1]),actual)
  expected=oracle(pid,raw)
  if pid=='abc265_d':return actual.strip()==expected.strip()
  tokens=actual.split();return len(tokens)==1 and re.fullmatch(r'-?(?:0|[1-9][0-9]*)',tokens[0]) is not None and int(tokens[0])==int(expected)
 except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc264_d':'''s=input();a=['atcoder'.index(c) for c in s];print(sum(a[i]>a[j] for i in range(7) for j in range(i+1,7)))
''',
'abc265_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);p=next(it);q=next(it);r=next(it);prefix=[0]
for _ in range(n):prefix.append(prefix[-1]+next(it))
seen=set(prefix);print('Yes' if any(v+p in seen and v+p+q in seen and v+p+q+r in seen for v in prefix) else 'No')
''',
'abc266_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);events={}
for _ in range(n):t=next(it);x=next(it);a=next(it);events[t]=(x,a)
best=[0]+[-10**30]*4
for t in range(1,max(events)+1):
 best=[max(best[max(0,x-1):min(5,x+2)]) for x in range(5)]
 if t in events:x,a=events[t];best[x]+=a
print(max(best))
''',
'abc267_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);dp=[0]+[-10**30]*m
for i in range(n):
 x=next(it)
 for j in range(min(m,i+1),0,-1):dp[j]=max(dp[j],dp[j-1]+j*x)
print(dp[m])
''',
'abc268_d':'''import sys,itertools
n,m=map(int,input().split());words=[input().strip() for _ in range(n)];banned={input().strip() for _ in range(m)};extra=16-sum(map(len,words))-(n-1)
def search(order,index,name,remaining):
 if index==n:return name if len(name)>=3 and name not in banned else None
 for added in range(remaining+1):
  result=search(order,index+1,name+'_'*(added+1)+order[index],remaining-added)
  if result is not None:return result
 return None
for order in itertools.permutations(words):
 result=search(order,1,order[0],extra)
 if result is not None:print(result);sys.exit()
print(-1)
''',
'abc269_d':'''n=int(input());remaining={tuple(map(int,input().split())) for _ in range(n)};directions=[(-1,-1),(-1,0),(0,-1),(0,1),(1,0),(1,1)];answer=0
while remaining:
 answer+=1;stack=[remaining.pop()]
 while stack:
  x,y=stack.pop()
  for dx,dy in directions:
   point=(x+dx,y+dy)
   if point in remaining:remaining.remove(point);stack.append(point)
print(answer)
'''}

def legal_names(words:tuple[str,...])->list[str]:
 # Private adversarial generator only, deliberately literal unlike count oracle.
 extra=16-sum(map(len,words))-(len(words)-1);names=[]
 def visit(order:tuple[str,...],index:int,prefix:str,left:int)->None:
  if index==len(order):
   if len(prefix)>=3:names.append(prefix)
   return
  for gap in range(1,left+2):visit(order,index+1,prefix+'_'*gap+order[index],left-gap+1)
 for order in permutations(words):visit(order,1,order[0],extra)
 return names

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(193000+int(pid[3:6]));raws:list[str]=[]
 if pid=='abc264_d':
  strings=['atcoder','catredo']
  for j in range(6):s='atcoder';strings.append(s[:j]+s[j+1]+s[j]+s[j+2:])
  while len(strings)<17:
   s=''.join(rng.sample('atcoder',7))
   if s not in strings and s!='redocta':strings.append(s)
  raws=[s+'\n' for s in strings+['redocta']]
 elif pid=='abc265_d':
  def array(targets:tuple[int,int,int],a:list[int])->str:return line((len(a),)+targets)+line(a)
  raws=[array((1,1,1),[1,1,1]),array((1,1,1),[2,2,2]),array((10**15,10**15,10**15),[10**9]*3),array((2,2,2),[1]*6),array((1,2,3),[1,2,3])]
  for i in range(11):
   n=6+i*5;a=[rng.randint(1,10**9) for _ in range(n)];targets=tuple(rng.randint(1,10**15) for _ in range(3))
   if i%2==0:cuts=sorted(rng.sample(range(n+1),4));targets=tuple(sum(a[u:v]) for u,v in zip(cuts,cuts[1:]))
   raws.append(array(cast(tuple[int,int,int],targets),a))
  raws.append(array((1,1,1),[1]*200000));raws.append(array((10**15,10**15,10**15),[10**9]*200000))
 elif pid=='abc266_d':
  def events(a:list[tuple[int,int,int]])->str:return str(len(a))+'\n'+''.join(line(row) for row in a)
  raws=[events([(1,0,1)]),events([(1,4,10**9)]),events([(4,4,10**9)]),events([(1,0,100),(3,3,10),(5,4,1)])]
  for i in range(12):times=sorted(rng.sample(range(1,100001),3+i*7));raws.append(events([(t,rng.randrange(5),rng.randint(1,10**9)) for t in times]))
  raws[-1]=events([(t,0,10**9) for t in range(1,100001)])
  raws.append(events([(t,(t//4)%5,10**9) for t in range(1,100001)]));raws.append(events([(t,4,10**9) for t in range(1,100001)]))
 elif pid=='abc267_d':
  def array(m:int,a:list[int])->str:return line((len(a),m))+line(a)
  raws=[array(1,[-200000]),array(1,[200000]),array(2,[5,4,-1,8]),array(2,[-2,-1,-3]),array(1,[0])]
  for i in range(11):n=3+i*9;raws.append(array(rng.randint(1,n),[rng.randint(-200000,200000) for _ in range(n)]))
  raws[-1]=array(2000,[-200000]*2000)
  raws.append(array(1000,[rng.randint(-200000,200000) for _ in range(2000)]));raws.append(array(2000,[200000]*2000))
 elif pid=='abc268_d':
  def username(words:tuple[str,...],banned:list[str])->str:return line((len(words),len(banned)))+''.join(s+'\n' for s in words+tuple(banned))
  pair_names=legal_names(('a','b'));tight=legal_names(('aaaaa','bbbbb','cccc'))
  pairs=[(('a',),[]),(('abc',),[]),(('abc',),['abc']),(('a','b'),[]),(('a','b'),pair_names),(('a','b'),pair_names[:-1]),(('chokudai','atcoder'),['chokudai_atcoder','atcoder_chokudai']),(('ab','cd','ef','gh'),['hoge','fuga','____','_ab_cd_ef_gh_']),(('a','ab'),['a_ab','ab_a']),(('aa','b','cc'),['aa_b_cc','b_cc_aa']),(('ab',),[]),(('abcdefghijklmnop',),[]),(('abcdefghijklmnop',),['abcdefghijklmnop']),(('abcdefgh','abcdefg'),['abcdefgh_abcdefg']),(('aaaaa','bbbbb','cccc'),tight[:-1]),(('aaaaa','bbbbb','cccc'),tight)]
  raws=[username(words,banned) for words,banned in pairs];raws.append(username(tuple('abcde'),legal_names(tuple('abcde'))));many=[]
  for order in permutations(tuple('abcdefgh')):
   for gap in range(8):many.append(''.join(word+('_'*(2 if i==gap-1 else 1) if i<7 else '') for i,word in enumerate(order)))
   if len(many)>=100000:break
  raws.append(username(tuple('abcdefgh'),many))
 else:
  def points(a:list[tuple[int,int]])->str:return str(len(a))+'\n'+''.join(line(row) for row in a)
  raws=[points([(0,0)]),points([(-1000,-1000),(1000,1000)]),points([(0,0),(1,1)]),points([(0,0),(1,-1)])]
  for i in range(12):raws.append(points(rng.sample([(x,y) for x in range(-10,11) for y in range(-10,11)],3+i*5)))
  raws.append(points([(-1000+2*j,(-1000,1000)[j%2]) for j in range(1000)]));raws.append(points([(1000-j,1000-j) for j in range(1000)]))
 require(len(raws)==len(set(raws))==18,'18 distinct')
 cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'reviewed_{j:02d}'})
 return cases

TITLES={'abc264_d': '"redocta".swap(i,i+1)',
 'abc265_d': 'Iroha and Haiku (New ABC Edition)',
 'abc266_d': 'Snuke Panic (1D)',
 'abc267_d': 'Index × A(Not Continuous ver.)',
 'abc268_d': 'Unique Username',
 'abc269_d': 'Do use hexagon grid'}
PUBLISHED_SAMPLES={'abc264_d': [{'input': 'catredo\n', 'expected': '8\n'},
              {'input': 'atcoder\n', 'expected': '0\n'},
              {'input': 'redocta\n', 'expected': '21\n'}],
 'abc265_d': [{'input': '10 5 7 5\n1 3 2 2 2 3 1 4 3 2\n', 'expected': 'Yes\n'},
              {'input': '9 100 101 100\n31 41 59 26 53 58 97 93 23\n', 'expected': 'No\n'},
              {'input': '7 1 1 1\n1 1 1 1 1 1 1\n', 'expected': 'Yes\n'}],
 'abc266_d': [{'input': '3\n1 0 100\n3 3 10\n5 4 1\n', 'expected': '101\n'},
              {'input': '3\n1 4 1\n2 4 1\n3 4 1\n', 'expected': '0\n'},
              {'input': '10\n'
                        '1 4 602436426\n'
                        '2 1 623690081\n'
                        '3 3 262703497\n'
                        '4 4 628894325\n'
                        '5 3 450968417\n'
                        '6 1 161735902\n'
                        '7 1 707723857\n'
                        '8 2 802329211\n'
                        '9 0 317063340\n'
                        '10 2 125660016\n',
               'expected': '2978279323\n'}],
 'abc267_d': [{'input': '4 2\n5 4 -1 8\n', 'expected': '21\n'},
              {'input': '10 4\n-3 1 -4 1 -5 9 -2 6 -5 3\n', 'expected': '54\n'}],
 'abc268_d': [{'input': '1 1\nchokudai\nchokudai\n', 'expected': '-1\n'},
              {'input': '2 2\nchoku\ndai\nchokudai\nchoku_dai\n', 'expected': 'dai_choku\n'},
              {'input': '2 2\nchokudai\natcoder\nchokudai_atcoder\natcoder_chokudai\n',
               'expected': '-1\n'},
              {'input': '4 4\nab\ncd\nef\ngh\nhoge\nfuga\n____\n_ab_cd_ef_gh_\n',
               'expected': 'ab__ef___cd_gh\n'}],
 'abc269_d': [{'input': '6\n-1 -1\n0 1\n0 2\n1 0\n1 2\n2 0\n', 'expected': '3\n'},
              {'input': '4\n5 0\n4 1\n-3 -4\n-2 -5\n', 'expected': '4\n'},
              {'input': '5\n2 1\n2 -1\n1 0\n3 1\n1 -1\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
HINTS={'abc264_d': ('目標のatcoderでの各文字の位置を番号に置き換えてみましょう。',
              '番号列の転倒数、つまり左側の方が大きい組の数が答えです。隣接交換一回で転倒数は一つだけ変わります。',
              '疑似コード: '
              'A[i]=atcoder内のS[i]のindex。全てのi<jについてA[i]>A[j]ならanswer++。転倒を一つずつ解消する隣接交換でanswer回で目標にできる。'),
 'abc265_d': ('四つの区切り位置で、累積和の差が順にP,Q,Rになる必要があります。',
              '開始位置の累積和をvとすると、v+P,v+P+Q,v+P+Q+Rが存在すればよいです。各要素が正なので、それらの位置は厳密に増加します。',
              '疑似コード: prefix[0]=0,以後累積和を作りsetへ。各vでv+P,v+P+Q,v+P+Q+Rが全てsetにあればYes、どれもなければNo。'),
 'abc266_d': ('時刻ごとに、高橋君が五つの座標のどこにいるかを状態にします。時刻0は座標0だけが到達可能です。',
              '一秒後には同じ位置、隣の位置へ移れます。移動前の最大得点から次の状態を作り、その時刻と位置に出現する報酬を加えます。',
              '疑似コード: '
              'dp=[0,-INF,-INF,-INF,-INF]。t=1..最後の時刻でnext[x]=max(dp[x],合法なdp[x-1],dp[x+1])。イベント(t,x,A)があればnext[x]+=A。最後max(dp)を出力。'),
 'abc267_d': ('選ぶ要素は連続である必要はありません。ただし元の順序を保ち、ちょうどM個を選びます。',
              'dp[j]を、今まで見た要素からj個選んだ重み付き和の最大値とします。次の要素をj番目に選ぶと、その寄与はj*Aになります。',
              '疑似コード: dp[0]=0,他-INF。各Aを左から読みjをM..1の降順に更新: '
              'dp[j]=max(dp[j],dp[j-1]+j*A)。降順で同じ要素の再使用を防ぐ。dp[M]を出力。'),
 'abc268_d': ('文字列の順序を並べ替え、間のアンダースコアの個数を選びます。N=1ではアンダースコアを入れられません。',
              '各並べ替えについて、全長16以下の範囲で各間に一個以上のアンダースコアを配置して探索します。最終的な長さ3以上と禁止名でないことを確認してください。',
              '疑似コード: extra=16-Σlen(S)-(N-1)。各permutationで、先頭語からDFS; '
              '次の語の前に1..extra+1個の_を付けて残り余裕を更新。全語を使いlen>=3かつnot forbiddenなら出力。全探索で見つからなければ-1。'),
 'abc269_d': ('六角形グリッドの隣接方向は、通常の正方形グリッドとは異なります。公式の六方向をそのまま使いましょう。',
              '黒い点を集合に入れ、未訪問の点から六方向の黒い点だけを辿ります。一回の探索で一つの連結成分を数えます。',
              '疑似コード: remaining=黒点set,answer=0。remainingがある間、点を一つ取りanswer++; '
              'stackで(-1,-1),(-1,0),(0,-1),(0,1),(1,0),(1,1)の隣点がremaining内なら削除して探索。')}
