"""Exact private ABC102--107 D specifications, including cohosted ARC IDs."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter
from typing import cast
import random,re
TASKS=('arc100_b','abc103_d','abc104_d','abc105_d','abc106_d','arc101_b')
CONTESTS={p:f'abc{n:03}' for p,n in zip(TASKS,range(102,108))}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc100_b' or pid=='arc101_b':
        require(len(rows)==2,'array shape');n=ints(rows[0],1)[0];require((4<=n<=200000) if pid=='arc100_b' else (1<=n<=100000),'array size');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'positive array');return (a,)
    if pid=='abc103_d':
        n,m=ints(rows[0],2);require(2<=n<=100000 and 1<=m<=100000 and len(rows)==m+1,'island shape');a=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=l<r<=n for l,r in a) and len(set(a))==m,'distinct nonempty requests');return n,a
    if pid=='abc104_d':require(len(rows)==1 and re.fullmatch('[ABC?]{3,100000}',rows[0]) is not None,'ABC string');return (rows[0],)
    if pid=='abc105_d':
        require(len(rows)==2,'candy shape');n,m=ints(rows[0],2);require(1<=n<=100000 and 2<=m<=10**9,'candy bounds');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'candy values');return m,a
    n,m,q=ints(rows[0],3);require(1<=n<=500 and 1<=m<=200000 and 1<=q<=100000 and len(rows)==m+q+1,'train shape');pairs=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=l<=r<=n for l,r in pairs),'train/query bounds');return n,pairs[:m],pairs[m:]

def four_split(a:tuple[int,...])->int:
    prefix=[0]
    for value in a:prefix.append(prefix[-1]+value)
    n=len(a);left=1;right=3;best=prefix[-1]
    for middle in range(2,n-1):
        while left+1<middle and abs(2*prefix[left+1]-prefix[middle])<abs(2*prefix[left]-prefix[middle]):left+=1
        right=max(right,middle+1)
        while right+1<n and abs(2*prefix[right+1]-prefix[-1]-prefix[middle])<abs(2*prefix[right]-prefix[-1]-prefix[middle]):right+=1
        sums=(prefix[left],prefix[middle]-prefix[left],prefix[right]-prefix[middle],prefix[-1]-prefix[right]);best=min(best,max(sums)-min(sums))
    return best

def reverse_bridge_cuts(requests:tuple[Pair,...])->int:
    cut=10**20;count=0
    for left,right in sorted(requests,reverse=True):
        if right<=cut:cut=left;count+=1
    return count

def abc_position_sum(s:str)->int:
    powers=[1]*(s.count('?')+1)
    for j in range(1,len(powers)):powers[j]=3*powers[j-1]%MOD
    before_a=before_q=0;after_c=s.count('C');after_q=s.count('?');answer=0
    for ch in s:
        if ch=='C':after_c-=1
        if ch=='?':after_q-=1
        if ch in 'B?':
            left=before_a*powers[before_q]+(before_q*powers[before_q-1] if before_q else 0);right=after_c*powers[after_q]+(after_q*powers[after_q-1] if after_q else 0);answer=(answer+left*right)%MOD
        if ch=='A':before_a+=1
        if ch=='?':before_q+=1
    return answer

def candy_groups(m:int,a:tuple[int,...])->int:
    residues=[0];current=0
    for value in a:current=(current+value)%m;residues.append(current)
    residues.sort();answer=0;start=0
    while start<len(residues):
        end=start+1
        while end<len(residues) and residues[end]==residues[start]:end+=1
        count=end-start;answer+=count*(count-1)//2;start=end
    return answer

def offline_trains(n:int,trains:tuple[Pair,...],queries:tuple[Pair,...])->list[int]:
    tree=[0]*(n+1);answer=[0]*len(queries);ordered=sorted(trains,key=lambda p:p[1]);cursor=0
    for index,(left,right) in sorted(enumerate(queries),key=lambda item:item[1][1]):
        while cursor<len(ordered) and ordered[cursor][1]<=right:
            j=ordered[cursor][0]
            while j<=n:tree[j]+=1;j+=j&-j
            cursor+=1
        excluded=0;j=left-1
        while j:excluded+=tree[j];j-=j&-j
        answer[index]=cursor-excluded
    return answer

def median_threshold_count(a:tuple[int,...],threshold:int)->int:
    # Prefix scores move by exactly +/-1. Maintain how many earlier scores
    # are <= the current level by adding/removing only the crossed bucket.
    n=len(a);counts=[0]*(2*n+3);level=n+1;counts[level]=1;at_most=1;answer=0
    for value in a:
        if value>=threshold:level+=1;at_most+=counts[level]
        else:at_most-=counts[level];level-=1
        answer+=at_most;counts[level]+=1;at_most+=1
    return answer

def median_of_medians(a:tuple[int,...])->int:
    values=sorted(set(a));low=0;high=len(values);needed=(len(a)*(len(a)+1)//2+1)//2
    while low+1<high:
        middle=(low+high)//2
        if median_threshold_count(a,values[middle])>=needed:low=middle
        else:high=middle
    return values[low]

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc100_b':return str(four_split(cast(tuple[int,...],data[0])))
    if pid=='abc103_d':return str(reverse_bridge_cuts(cast(tuple[Pair,...],data[1])))
    if pid=='abc104_d':return str(abc_position_sum(cast(str,data[0])))
    if pid=='abc105_d':return str(candy_groups(*cast(tuple[int,tuple[int,...]],data)))
    if pid=='abc106_d':return '\n'.join(map(str,offline_trains(*cast(tuple[int,tuple[Pair,...],tuple[Pair,...]],data))))
    return str(median_of_medians(cast(tuple[int,...],data[0])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'arc100_b':"from bisect import bisect_left\nn=int(input());a=list(map(int,input().split()));p=[0]\nfor x in a:p.append(p[-1]+x)\nanswer=p[-1]\nfor m in range(2,n-1):\n l=bisect_left(p,(p[m]+1)//2,1,m);r=bisect_left(p,(p[-1]+p[m]+1)//2,m+1,n)\n for x in (l-1,l):\n  if not 1<=x<m:continue\n  for y in (r-1,r):\n   if not m<y<n:continue\n   v=(p[x],p[m]-p[x],p[y]-p[m],p[-1]-p[y]);answer=min(answer,max(v)-min(v))\nprint(answer)\n",
'abc103_d':"n,m=map(int,input().split());a=[tuple(map(int,input().split())) for _ in range(m)];a.sort(key=lambda p:p[1]);last=0;answer=0\nfor x,y in a:\n if last<x:last=y-1;answer+=1\nprint(answer)\n",
'abc104_d':"s=input();ways=1;a=ab=abc=0\nfor ch in s:\n if ch=='?':abc=3*abc+ab;ab=3*ab+a;a=3*a+ways;ways*=3\n elif ch=='A':a+=ways\n elif ch=='B':ab+=a\n else:abc+=ab\n ways%=1000000007;a%=1000000007;ab%=1000000007;abc%=1000000007\nprint(abc)\n",
'abc105_d':"from collections import Counter\nn,m=map(int,input().split());a=list(map(int,input().split()));count=Counter({0:1});total=answer=0\nfor x in a:total=(total+x)%m;answer+=count[total];count[total]+=1\nprint(answer)\n",
'abc106_d':"n,m,q=map(int,input().split());p=[[0]*(n+1) for _ in range(n+1)]\nfor _ in range(m):a,b=map(int,input().split());p[a][b]+=1\nfor a in range(1,n+1):\n for b in range(1,n+1):p[a][b]+=p[a-1][b]+p[a][b-1]-p[a-1][b-1]\nfor _ in range(q):a,b=map(int,input().split());print(p[b][b]-p[a-1][b]-p[b][a-1]+p[a-1][a-1])\n",
'arc101_b':"n=int(input());a=list(map(int,input().split()));values=sorted(set(a));needed=(n*(n+1)//2+1)//2\ndef count(threshold):\n tree=[0]*(2*n+3);level=n+1;answer=0\n def add(j):\n  while j<len(tree):tree[j]+=1;j+=j&-j\n add(level)\n for x in a:\n  level+=1 if x>=threshold else -1;j=level;subtotal=0\n  while j:subtotal+=tree[j];j-=j&-j\n  answer+=subtotal;add(level)\n return answer\nlo=0;hi=len(values)\nwhile lo+1<hi:\n mid=(lo+hi)//2\n if count(values[mid])>=needed:lo=mid\n else:hi=mid\nprint(values[lo])\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18400+TASKS.index(pid));raws:list[str]=[]
    if pid=='arc100_b':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([1]*4),seq([10**9]*4),seq([1,2,3,4]),seq([1,1,10**9,1])]
        raws += [seq([rng.randint(1,10**9) for _ in range(n)]) for n in range(5,17)]
        raws += [seq([(j*65537)%10**9+1 for j in range(200000)]),seq([10**9]*200000)]
    elif pid=='abc103_d':
        def islands(n:int,a:list[Pair])->str:return f'{n} {len(a)}\n'+''.join(line(v) for v in a)
        raws=[islands(2,[(1,2)]),islands(3,[(1,3)]),islands(3,[(1,2),(2,3)]),islands(4,[(1,3),(2,4)])]
        for n in range(4,16):pairs=[(a,b) for a in range(1,n+1) for b in range(a+1,n+1)];raws.append(islands(n,rng.sample(pairs,min(n,len(pairs)))))
        raws += [islands(100000,[(1,j) for j in range(2,100001)]+[(2,100000)]),islands(100000,[(j,j+1) for j in range(1,100000)]+[(1,100000)])]
    elif pid=='abc104_d':raws=[s+'\n' for s in ('ABC','AAA','???','A??C','ABCBC','?BC','A?C','AB?','CBA','?A?B?C?','ABC'*10,'?'*50,'A'*33+'B'*33+'C'*33,'?'*99999,'ABC'*33333+'?','A'*33333+'B'*33333+'C'*33334,'ABC?'*25000,'?'*100000)]
    elif pid=='abc105_d':
        def candies(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
        raws=[candies(2,[1]),candies(2,[2]),candies(10**9,[10**9]),candies(2,[1,1])]
        raws += [candies(rng.randint(2,10**9),[rng.randint(1,10**9) for _ in range(n)]) for n in range(3,15)]
        raws += [candies(10**9,list(range(1,100001))),candies(10**9,[10**9]*100000)]
    elif pid=='abc106_d':
        def trains(n:int,t:list[Pair],q:list[Pair])->str:return f'{n} {len(t)} {len(q)}\n'+''.join(line(v) for v in t+q)
        raws=[trains(1,[(1,1)],[(1,1)]),trains(2,[(1,2)],[(1,1),(1,2)]),trains(2,[(1,1),(1,1),(2,2)],[(1,1),(2,2)]),trains(3,[(1,3),(2,2)],[(2,3),(1,3)])]
        for n in range(3,15):
            t=[tuple(sorted(rng.choices(range(1,n+1),k=2))) for _ in range(n*2)];q=[tuple(sorted(rng.choices(range(1,n+1),k=2))) for _ in range(n)];raws.append(trains(n,cast(list[Pair],t),cast(list[Pair],q)))
        raws += [trains(500,[(1,500)]*200000,[(1,500)]*100000),trains(500,[(500,500)]*200000,[(1,500)]*100000)]
    else:
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([1]),seq([10**9]),seq([1,2]),seq([2,1])]
        raws += [seq([rng.randint(1,10**9) for _ in range(n)]) for n in range(3,15)]
        raws += [seq([(j*65537)%10**9+1 for j in range(100000)]),seq([10**9]*100000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'arc100_b':('中央の切れ目を固定すると、左側と右側をそれぞれ2つに分ける問題になります。','左右それぞれの2部分の和をできるだけ半分ずつにすれば、4つの和の最大値と最小値の差も最小になります。','疑似コード: prefixを作成; middle=2..N-2; 左prefix[middle]/2と右(prefix[N]+prefix[middle])/2の直前直後を二分探索; 有効な切れ目の4和を比較し最小差を出力。'),
'abc103_d':('要望は、区間[a,b)の橋を最低1本取り除く条件です。','右端が早い要望から処理し、まだ分断されていなければ右端直前の橋を取り除きます。','疑似コード: 要望をb昇順sort; last=0; 各(a,b)でlast<aならlast=b-1としてcount++; countを出力。'),
'abc104_d':('左から、空列・A・AB・ABCを作る通り数を管理します。','?を使うと既存の全パターンが3倍になり、A/B/Cとして次の状態へ進む通り数も加わります。','疑似コード: ways=1,A=AB=ABC=0; ?ならABC=3ABC+AB,AB=3AB+A,A=3A+ways,ways*=3; 他は該当遷移のみ; 毎回modしABCを出力。'),
'abc105_d':('区間和がMの倍数なら、区間の前後の累積和はMで同じ余りになります。','累積和の余りを左から数え、現在と同じ余りの過去の個数を答えに加えます。','疑似コード: freq[0]=1; prefix=answer=0; 各aでprefix=(prefix+a)%M; answer+=freq[prefix]; freq[prefix]++; answerを出力。'),
'abc106_d':('列車を始点L・終点Rの2次元の点として数えます。','p<=L<=R<=qを満たす点数は、始点・終点が[p,q]に入る正方形の点数です。2次元累積和で答えます。','疑似コード: count[L][R]++; 2Dprefix構築; 各(p,q)でS[q][q]-S[p-1][q]-S[q][p-1]+S[p-1][p-1]を出力。'),
'arc101_b':('答えがx以上かどうかを判定して二分探索できます。偶数長の中央値は上側です。','a>=xを+1、それ以外を-1にすると、区間中央値>=xは区間和>=0と同値です。累積和の大小でその区間数を数えます。','疑似コード: threshold毎に±1 prefixを生成; Fenwickで過去prefix<=現在prefixの個数を加算; その数>=ceil(全区間数/2)なら答え>=threshold; 入力値の上でbinary search。')}

TITLES={'arc100_b': 'Equal Cut', 'abc103_d': 'Islands War', 'abc104_d': 'We Love ABC', 'abc105_d': 'Candy Distribution', 'abc106_d': 'AtCoder Express 2', 'arc101_b': 'Median of Medians'}
PUBLISHED_SAMPLES={'arc100_b': [{'input': '5\n3 2 4 1 2\n', 'expected': '2\n'}, {'input': '10\n10 71 84 33 6 47 23 25 52 64\n', 'expected': '36\n'}, {'input': '7\n1 2 3 1000000000 4 5 6\n', 'expected': '999999994\n'}], 'abc103_d': [{'input': '5 2\n1 4\n2 5\n', 'expected': '1\n'}, {'input': '9 5\n1 8\n2 7\n3 5\n4 6\n7 9\n', 'expected': '2\n'}, {'input': '5 10\n1 2\n1 3\n1 4\n1 5\n2 3\n2 4\n2 5\n3 4\n3 5\n4 5\n', 'expected': '4\n'}], 'abc104_d': [{'input': 'A??C\n', 'expected': '8\n'}, {'input': 'ABCBC\n', 'expected': '3\n'}, {'input': '????C?????B??????A???????\n', 'expected': '979596887\n'}], 'abc105_d': [{'input': '3 2\n4 1 5\n', 'expected': '3\n'}, {'input': '13 17\n29 7 5 7 9 51 7 13 8 55 42 9 81\n', 'expected': '6\n'}, {'input': '10 400000000\n1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '25\n'}], 'abc106_d': [{'input': '2 3 1\n1 1\n1 2\n2 2\n1 2\n', 'expected': '3\n'}, {'input': '10 3 2\n1 5\n2 8\n7 10\n1 7\n3 10\n', 'expected': '1\n1\n'}, {'input': '10 10 10\n1 6\n2 9\n4 5\n4 7\n4 7\n5 8\n6 6\n6 7\n7 9\n10 10\n1 8\n1 9\n1 10\n2 8\n2 9\n2 10\n3 8\n3 9\n3 10\n1 10\n', 'expected': '7\n9\n10\n6\n8\n9\n6\n7\n8\n10\n'}], 'arc101_b': [{'input': '3\n10 30 20\n', 'expected': '30\n'}, {'input': '1\n10\n', 'expected': '10\n'}, {'input': '10\n5 9 5 9 8 9 3 5 4 3\n', 'expected': '8\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
