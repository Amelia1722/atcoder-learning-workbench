"""Private ABC252..257 D with exact domains and independent number/graph oracles."""
from __future__ import annotations
from collections import Counter
from typing import cast
import math,random,re
TASKS=tuple(f'abc{n}_d' for n in range(252,258))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None,signed:bool=False)->tuple[int,...]:
    token=r'(?:0|[1-9][0-9]*|-[1-9][0-9]*)' if signed else r'(?:0|[1-9][0-9]*)'
    require(re.fullmatch(token+r'(?: '+token+r')*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc252_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(3<=n<=200000 and all(1<=v<=200000 for v in a),'range');return (a,)
    if pid=='abc253_d':
        require(len(rows)==1,'shape');n,a,b=ints(rows[0],3);require(all(1<=v<=10**9 for v in (n,a,b)),'range');return n,a,b
    if pid=='abc254_d':
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000,'range');return (n,)
    if pid=='abc255_d':
        n,q=ints(rows[0],2);require(1<=n<=200000 and 1<=q<=200000 and len(rows)==q+2,'shape');a=ints(rows[1],n);queries=tuple(ints(row,1)[0] for row in rows[2:]);require(all(0<=v<=10**9 for v in a+queries),'range');return a,queries
    if pid=='abc256_d':
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');intervals=tuple(ints(row,2) for row in rows[1:]);require(all(1<=l<r<=200000 for l,r in intervals),'range');return (intervals,)
    n=ints(rows[0],1)[0];require(2<=n<=200 and len(rows)==n+1,'shape');points=tuple(ints(row,3,True) for row in rows[1:]);require(len({(x,y) for x,y,p in points})==n and all(-10**9<=x<=10**9 and -10**9<=y<=10**9 and 1<=p<=10**9 for x,y,p in points),'distinct/range');return (points,)
def distinct_newton(a:tuple[int,...])->int:
    counts=Counter(a).values();n=len(a);square=sum(v*v for v in counts);cube=sum(v**3 for v in counts);return (n**3-3*n*square+2*cube)//6
def nonzero_residue_sum(n:int,period:int)->int:
    blocks,tail=divmod(n,period)
    # Complete blocks each contain residues 1..period-1, then the final tail.
    return (period-1)*period*blocks*(blocks-1)//2+blocks*period*(period-1)//2+tail*period*blocks+tail*(tail+1)//2
def fizz_nested_blocks(n:int,a:int,b:int)->int:
    return nonzero_residue_sum(n,a)-b*nonzero_residue_sum(n//b,a//math.gcd(a,b))
def square_coprime_ratios(n:int)->int:
    limit=math.isqrt(n);phi=list(range(limit+1))
    for p in range(2,limit+1):
        if phi[p]==p:
            for j in range(p,limit+1,p):phi[j]-=phi[j]//p
    # i=g*u^2,j=g*v^2 with gcd(u,v)=1. For max(u,v)=m>1 there are 2*phi(m) ordered choices.
    return n+sum(2*phi[m]*(n//(m*m)) for m in range(2,limit+1))
def absolute_event_curve(a:tuple[int,...],queries:tuple[int,...])->list[int]:
    events=Counter(a);coordinates=sorted(set(events)|set(queries));previous=coordinates[0];value=sum(v-previous for v in a);slope=-len(a);answers:dict[int,int]={}
    for coordinate in coordinates:
        value+=slope*(coordinate-previous);answers[coordinate]=value;slope+=2*events[coordinate];previous=coordinate
    return [answers[x] for x in queries]
def interval_difference(intervals:tuple[tuple[int,...],...])->list[tuple[int,int]]:
    changes=[0]*200001
    for left,right in intervals:changes[left]+=1;changes[right]-=1
    result=[];active=0;start=0
    for point,delta in enumerate(changes):
        following=active+delta
        if active==0 and following>0:start=point
        if active>0 and following==0:result.append((start,point))
        active=following
    return result
def jump_minimax(points:tuple[tuple[int,...],...])->int:
    n=len(points);distance=[[(abs(x-xx)+abs(y-yy)+p-1)//p for xx,yy,pp in points] for x,y,p in points]
    for k in range(n):
        through=distance[k]
        for row in distance:
            prefix=row[k]
            for j,last in enumerate(through):
                candidate=max(prefix,last)
                if candidate<row[j]:row[j]=candidate
    return min(max(row) for row in distance)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc252_d':return str(distinct_newton(cast(tuple[int,...],data[0])))
    if pid=='abc253_d':n,a,b=cast(tuple[int,int,int],data);return str(fizz_nested_blocks(n,a,b))
    if pid=='abc254_d':return str(square_coprime_ratios(cast(int,data[0])))
    if pid=='abc255_d':a,queries=cast(tuple[tuple[int,...],tuple[int,...]],data);return '\n'.join(map(str,absolute_event_curve(a,queries)))
    if pid=='abc256_d':return '\n'.join(f'{l} {r}' for l,r in interval_difference(cast(tuple[tuple[int,...],...],data[0])))
    return str(jump_minimax(cast(tuple[tuple[int,...],...],data[0])))
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:
        if output_mode not in (None,'exact'):return False
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc252_d':'''from collections import Counter
n=int(input());counts=Counter(map(int,input().split()));left=0;answer=0
for count in counts.values():answer+=left*count*(n-left-count);left+=count
print(answer)
''',
'abc253_d':'''import math
n,a,b=map(int,input().split())
def multiple_sum(step):
 q=n//step;return step*q*(q+1)//2
print(n*(n+1)//2-multiple_sum(a)-multiple_sum(b)+multiple_sum(math.lcm(a,b)))
''',
'abc254_d':'''from collections import Counter
n=int(input());kernel=list(range(n+1))
for i in range(2,__import__('math').isqrt(n)+1):
 square=i*i
 for j in range(square,n+1,square):
  while kernel[j]%square==0:kernel[j]//=square
counts=Counter(kernel[1:]);print(sum(v*v for v in counts.values()))
''',
'abc255_d':'''import sys,bisect
it=iter(map(int,sys.stdin.buffer.read().split()));n,q=next(it),next(it);a=sorted(next(it) for _ in range(n));prefix=[0]
for v in a:prefix.append(prefix[-1]+v)
answers=[]
for _ in range(q):
 x=next(it);k=bisect.bisect_left(a,x);answers.append(str(x*k-prefix[k]+prefix[-1]-prefix[k]-x*(n-k)))
print('\\n'.join(answers))
''',
'abc256_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);intervals=sorted((next(it),next(it)) for _ in range(n));left,right=intervals[0];answers=[]
for l,r in intervals[1:]:
 if l>right:answers.append(f'{left} {right}');left,right=l,r
 else:right=max(right,r)
answers.append(f'{left} {right}');print('\\n'.join(answers))
''',
'abc257_d':'''n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];weights=[[(abs(x-xx)+abs(y-yy)+p-1)//p for xx,yy,pp in points] for x,y,p in points]
def feasible(s):
 graph=[[j for j,w in enumerate(row) if w<=s] for row in weights]
 def visit(start,seen):
  stack=[start];seen[start]=True
  while stack:
   v=stack.pop()
   for u in graph[v]:
    if not seen[u]:seen[u]=True;stack.append(u)
 seen=[False]*n;candidate=0
 for j in range(n):
  if not seen[j]:candidate=j;visit(j,seen)
 seen=[False]*n;visit(candidate,seen);return all(seen)
lo=-1;hi=4000000000
while hi-lo>1:
 mid=(hi+lo)//2
 if feasible(mid):hi=mid
 else:lo=mid
print(hi)
'''}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(19200+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc252_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([1,1,1]),seq([1,2,3]),seq([200000]*3),seq([1,1,2,2,3,3])]+[seq([rng.randint(1,200000) for _ in range(n)]) for n in range(4,16)]+[seq(list(range(1,200001))),seq([200000]*200000)]
    elif pid=='abc253_d':
        raws=['1 1 1\n','1 2 2\n','1000000000 1 1000000000\n','1000000000 999999937 999999929\n']+[f'{rng.randint(1,10**9)} {rng.randint(1,10**9)} {rng.randint(1,10**9)}\n' for _ in range(12)]+['1000000000 6 15\n','1000000000 1000000000 1000000000\n']
    elif pid=='abc254_d':raws=[f'{n}\n' for n in [1,2,3,4,5,8,9,16,24,25,49,64,100,999,10000,199999,65536,200000]]
    elif pid=='abc255_d':
        def queries(a:list[int],q:list[int])->str:return f'{len(a)} {len(q)}\n'+line(a)+''.join(f'{x}\n' for x in q)
        raws=[queries([0],[0]),queries([10**9],[0]),queries([0],[10**9]),queries([0,0,10**9,10**9],[0,500000000,10**9])]
        for n in range(2,14):raws.append(queries([rng.randint(0,10**9) for _ in range(n)],[rng.randint(0,10**9) for _ in range(n)]))
        raws += [queries([j*5000 for j in range(200000)],[10**9-j*5000 for j in range(200000)]),queries([10**9]*200000,[10**9]*200000)]
    elif pid=='abc256_d':
        def intervals(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[intervals([(1,2)]),intervals([(1,200000)]),intervals([(1,2),(2,3)]),intervals([(1,2),(3,4)])]
        # The fixed bounds also exercise equal endpoints, containment, and touching intervals.
        for n in range(2,14):
            a=[]
            for _ in range(n):left=rng.randint(1,199999);a.append((left,rng.randint(left+1,200000)))
            raws.append(intervals(a))
        raws += [intervals([(2*j+1,2*j+2) for j in range(100000)]*2),intervals([(199999,200000)]*200000)]
    else:
        def points(a:list[tuple[int,int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[points([(0,0,1),(1,0,1)]),points([(-10**9,-10**9,1),(10**9,10**9,1)]),points([(0,0,10**9),(1,1,1)]),points([(0,0,1),(10,0,100),(100,0,1)])]
        for n in range(3,15):raws.append(points([(j*1000003,rng.randint(-10**9,10**9),rng.randint(1,10**9)) for j in range(n)]))
        raws += [points([(j*10000000-10**9,10**9 if j%2 else -10**9,1) for j in range(200)]),points([(10**9-j,-10**9+j,10**9) for j in range(200)])]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc252_d':('同じ値の出現数ごとにまとめると、異なる三値を選ぶ計算になります。','ある値を真ん中のグループとして、前のグループの合計数×その値の個数×後のグループの合計数を加えます。グループの順序は任意です。','疑似コード: counts=各値の頻度; left=0; 各countでanswer+=left*count*(N-left-count); left+=count; answer出力。'),
'abc253_d':('全整数の和から、Aの倍数とBの倍数の和を除きます。','両方の倍数は二回引かれるため、最小公倍数の倍数の和を一度戻します。各倍数列の和は等差数列です。','疑似コード: sum(k)=k*q*(q+1)/2, q=N//k; N*(N+1)/2-sum(A)-sum(B)+sum(lcm(A,B))を出力。'),
'abc254_d':('整数から平方数の因子を全て除いた部分が一致すると、積が平方数になります。','各整数を平方数で割れるだけ割り、残った値ごとの出現数を数えます。順序つきの組なので、各頻度の二乗を足します。','疑似コード: kernel[i]=i; s=2..isqrt(N)でsquare=s*s; squareの各倍数jでkernel[j]がsquareで割れる間割る; kernel[1..N]の頻度countを数えΣcount²出力。'),
'abc255_d':('各問い合わせの答えは、全要素とXの距離の和です。','Aをソートして累積和を作り、X未満の個数kを二分探索します。左側と右側の距離の和を別々に計算できます。','疑似コード: A=sort(A), prefix累積和; k=lower_bound(A,X); answer=X*k-prefix[k]+prefix[N]-prefix[k]-X*(N-k); 各queryで出力。'),
'abc256_d':('左端の昇順で見ると、今の区間につながる区間をまとめられます。','次の左端が現在の右端以下なら、右端を最大値へ伸ばします。等しい端点もつながります。隙間があれば現在の区間を確定します。','疑似コード: intervals=sort; current=先頭; 次(l,r)でl>current.rightならcurrent出力し置換、他right=max(right,r); 最後current出力。'),
'abc257_d':('Sを固定すると、各踏み台から跳べる相手が有向グラフになります。','全頂点へ到達できる始点があるか調べ、Sを二分探索します。DFSで未訪問頂点を順に始点にして最後の始点候補を選び、その候補からもう一度到達可能性を確かめます。','疑似コード: feasible(S)でdistance(i,j)<=Pi*Sの辺を作る; seenを共有し未訪問iからDFS、最後iをcandidate; seenリセットしcandidateからDFSし全訪問ならtrue; Sを0..4e9で二分探索。')}

TITLES={'abc252_d': 'Distinct Trio', 'abc253_d': 'FizzBuzz Sum Hard', 'abc254_d': 'Together Square', 'abc255_d': '±1 Operation 2', 'abc256_d': 'Union of Interval', 'abc257_d': 'Jumping Takahashi 2'}
PUBLISHED_SAMPLES={'abc252_d': [{'input': '4\n3 1 4 1\n', 'expected': '2\n'}, {'input': '10\n99999 99998 99997 99996 99995 99994 99993 99992 99991 99990\n', 'expected': '120\n'}, {'input': '15\n3 1 4 1 5 9 2 6 5 3 5 8 9 7 9\n', 'expected': '355\n'}], 'abc253_d': [{'input': '10 3 5\n', 'expected': '22\n'}, {'input': '1000000000 314 159\n', 'expected': '495273003954006262\n'}], 'abc254_d': [{'input': '4\n', 'expected': '6\n'}, {'input': '254\n', 'expected': '896\n'}], 'abc255_d': [{'input': '5 3\n6 11 2 5 5\n5\n20\n0\n', 'expected': '10\n71\n29\n'}, {'input': '10 5\n1000000000 314159265 271828182 141421356 161803398 0 777777777 255255255 536870912 998244353\n555555555\n321654987\n1000000000\n789456123\n0\n', 'expected': '3316905982\n2811735560\n5542639502\n4275864946\n4457360498\n'}], 'abc256_d': [{'input': '3\n10 20\n20 30\n40 50\n', 'expected': '10 30\n40 50\n'}, {'input': '3\n10 40\n30 60\n20 50\n', 'expected': '10 60\n'}], 'abc257_d': [{'input': '4\n-10 0 1\n0 0 5\n10 0 1\n11 0 1\n', 'expected': '2\n'}, {'input': '7\n20 31 1\n13 4 3\n-10 -15 2\n34 26 5\n-2 39 4\n0 -50 1\n5 -20 2\n', 'expected': '18\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
