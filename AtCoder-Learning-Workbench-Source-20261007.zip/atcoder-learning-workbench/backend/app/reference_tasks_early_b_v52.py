"""Reviewed ABC015/016/017 B input families and independent output checkers.

Official pages were read via browser; original HTML was not archived/authenticated.
"""
from __future__ import annotations
import random
import re

TASKS=('abc015_2','abc016_2','abc017_2')
NAT=re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER=re.compile(r'[a-z]{1,50}', re.ASCII)


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('invalid task or newline')
    lines=raw[:-1].split('\n')
    if pid=='abc015_2':
        if len(lines)!=2 or not NAT.fullmatch(lines[0]):raise ValueError('invalid N')
        n=int(lines[0]); items=lines[1].split(' ')
        if len(items)!=n or not 1<=n<=100 or not all(NAT.fullmatch(x) for x in items):
            raise ValueError('invalid array')
        vals=list(map(int,items))
        if any(v>100 for v in vals) or sum(vals)==0:raise ValueError('invalid domain')
        return vals
    if pid=='abc016_2':
        if len(lines)!=1:raise ValueError('invalid line')
        items=lines[0].split(' ')
        if len(items)!=3 or not all(NAT.fullmatch(x) for x in items):raise ValueError('invalid triple')
        nums=tuple(map(int,items))
        if any(x>100 for x in nums):raise ValueError('invalid bound')
        return nums
    if len(lines)!=1 or not LOWER.fullmatch(lines[0]):raise ValueError('invalid word')
    return lines[0]


def independent_check(pid:str, raw:str, output:str)->bool:
    try: parsed=validate(pid,raw)
    except ValueError:return False
    if not isinstance(output,str) or '\n' in output or '\r' in output:return False
    if pid=='abc015_2':
        vals=[v for v in parsed if v]
        # A ceiling is the smallest integer k with k * count >= sum.
        return output==str(next(k for k in range(1,101) if k*len(vals)>=sum(vals)))
    if pid=='abc016_2':
        a,b,c=parsed
        matching={symbol for symbol,value in (('+',a+b),('-',a-b)) if value==c}
        return output==({frozenset():'!',frozenset({'+','-'}):'?',frozenset({'+'}):'+',frozenset({'-'}):'-'}[frozenset(matching)])
    # Independent dynamic-programming parser, unlike greedy tokenization in reference.
    s=parsed;dp=[False]*(len(s)+1);dp[0]=True
    for i in range(len(s)):
        if not dp[i]:continue
        for word in ('ch','o','k','u'):
            if s.startswith(word,i):dp[i+len(word)]=True
    return output==('YES' if dp[len(s)] else 'NO')


def generate(pid:str,seed:int=52)->list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unknown task')
    rng=random.Random(f'abc-v52:{pid}:{seed}')
    rows=[];seen=set()
    def add(kind,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw);rows.append({'category':kind,'input':raw})
    if pid=='abc015_2':
        presets=[[1],[100],[0,1],[100,0],[1,100],[1,1,100],[0,1,3,8],[1,4,9,10,15],
                 [0]*99+[1],[0]*99+[100],[1]*100,[100]*99+[1],list(range(1,101))]
        def fmt(v):return f'{len(v)}\n'+ ' '.join(map(str,v))+'\n'
        for v in presets:add('boundary' if len(v) in (1,100) else 'normal',fmt(v))
        while len(rows)<17:
            n=rng.randint(1,100);v=[rng.randint(0,100) for _ in range(n)]
            if not any(v):v[0]=1
            add('normal',fmt(v))
        add('constraint_max',fmt([100]*100))
    elif pid=='abc016_2':
        triples=[(0,0,0),(1,0,1),(1,1,2),(1,1,0),(1,1,1),(0,100,100),
                 (100,0,100),(100,100,0),(100,100,100),(0,0,1),(2,1,3),
                 (2,1,1),(2,1,2),(50,50,100),(50,50,0),(100,1,99),(1,100,0)]
        for a,b,c in triples:add('boundary' if 0 in (a,b,c) or 100 in (a,b,c) else 'normal',f'{a} {b} {c}\n')
        add('constraint_max','100 100 99\n')
    else:
        presets=['ch','o','k','u','c','h','choku','chokuou','kuccho','atcoder','cho',
                 'chch','cch','chh','x','ch'*24+'o']
        for word in presets:add('boundary' if len(word) in (1,50) else 'normal',word+'\n')
        while len(rows)<17:
            n=rng.randint(1,49)
            word=''.join(rng.choice('chokuabcxyz') for _ in range(n))
            add('normal',word+'\n')
        add('constraint_max','ch'*25+'\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: generated {len(rows)} cases, expected 18')
    return rows
