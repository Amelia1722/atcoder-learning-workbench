"""Turn 125: reviewed B tasks ABC357 B through ABC374 B.

Public AtCoder statements, constraints, and every published sample were manually reviewed.
Official HTML is not archived/authenticated; entries therefore remain full_size=False.
"""
from __future__ import annotations

import heapq
import itertools
import re
from collections import Counter

TASKS = tuple(f"abc{i}_b" for i in range(357, 375))
LANES = {
    "A": ("abc357_b", "abc358_b", "abc359_b"),
    "B": ("abc360_b", "abc361_b", "abc362_b"),
    "C": ("abc363_b", "abc364_b", "abc365_b"),
    "D": ("abc366_b", "abc367_b", "abc368_b"),
    "E": ("abc369_b", "abc370_b", "abc371_b"),
    "F": ("abc372_b", "abc373_b", "abc374_b"),
}
TITLES = {
    "abc357_b": "Uppercase and Lowercase",
    "abc358_b": "Ticket Counter",
    "abc359_b": "Couples",
    "abc360_b": "Vertical Reading",
    "abc361_b": "Intersection of Cuboids",
    "abc362_b": "Right Triangle",
    "abc363_b": "Japanese Cursed Doll",
    "abc364_b": "Grid Walk",
    "abc365_b": "Second Best",
    "abc366_b": "Vertical Writing",
    "abc367_b": "Cut .0",
    "abc368_b": "Decrease 2 max elements",
    "abc369_b": "Piano 3",
    "abc370_b": "Binary Alchemy",
    "abc371_b": "Taro",
    "abc372_b": "3^A",
    "abc373_b": "1D Keyboard",
    "abc374_b": "Unvarnished Report",
}
INT = re.compile(r"(?:0|[1-9][0-9]*)", re.ASCII)
SINT = re.compile(r"(?:0|-?[1-9][0-9]*)", re.ASCII)
LOWER = re.compile(r"[a-z]+", re.ASCII)
MIXED = re.compile(r"[A-Za-z]+", re.ASCII)
UPPER = re.compile(r"[A-Z]+", re.ASCII)

PUBLISHED_SAMPLES = {
"abc357_b":[
{"input":"AtCoder\n","expected":"atcoder\n"},
{"input":"SunTORY\n","expected":"SUNTORY\n"},
{"input":"a\n","expected":"a\n"}],
"abc358_b":[
{"input":"3 4\n0 2 10\n","expected":"4\n8\n14\n"},
{"input":"3 3\n1 4 7\n","expected":"4\n7\n10\n"},
{"input":"10 50000\n120190 165111 196897 456895 540000 552614 561627 743796 757613 991216\n","expected":"170190\n220190\n270190\n506895\n590000\n640000\n690000\n793796\n843796\n1041216\n"}],
"abc359_b":[
{"input":"3\n1 2 1 3 2 3\n","expected":"2\n"},
{"input":"2\n1 1 2 2\n","expected":"0\n"},
{"input":"4\n4 3 2 3 2 1 4 1\n","expected":"3\n"}],
"abc360_b":[
{"input":"atcoder toe\n","expected":"Yes\n"},
{"input":"beginner r\n","expected":"No\n"},
{"input":"verticalreading agh\n","expected":"No\n"}],
"abc361_b":[
{"input":"0 0 0 4 5 6\n2 3 4 5 6 7\n","expected":"Yes\n"},
{"input":"0 0 0 2 2 2\n0 0 2 2 2 4\n","expected":"No\n"},
{"input":"0 0 0 1000 1000 1000\n10 10 10 100 100 100\n","expected":"Yes\n"}],
"abc362_b":[
{"input":"0 0\n4 0\n0 3\n","expected":"Yes\n"},
{"input":"-4 3\n2 1\n3 4\n","expected":"Yes\n"},
{"input":"2 4\n-3 2\n1 -2\n","expected":"No\n"}],
"abc363_b":[
{"input":"5 10 3\n3 11 1 6 2\n","expected":"7\n"},
{"input":"2 5 2\n10 10\n","expected":"0\n"},
{"input":"3 10 1\n1 2 3\n","expected":"7\n"}],
"abc364_b":[
{"input":"2 3\n2 1\n.#.\n...\nULDRU\n","expected":"2 2\n"},
{"input":"4 4\n4 2\n....\n.#..\n...#\n....\nDUUUURULRD\n","expected":"2 4\n"},
{"input":"6 6\n1 1\n.#####\n######\n######\n######\n######\n######\nRURLDLULLRULRDL\n","expected":"1 1\n"}],
"abc365_b":[
{"input":"4\n8 2 5 1\n","expected":"3\n"},
{"input":"8\n1 2 3 4 5 10 9 11\n","expected":"6\n"}],
"abc366_b":[
{"input":"3\nabc\nde\nfghi\n","expected":"fda\ngeb\nh*c\ni\n"},
{"input":"3\natcoder\nbeginner\ncontest\n","expected":"cba\noet\nngc\ntio\nend\nsne\nter\n*r\n"}],
"abc367_b":[
{"input":"1.012\n","expected":"1.012\n"},
{"input":"12.340\n","expected":"12.34\n"},
{"input":"99.900\n","expected":"99.9\n"},
{"input":"0.000\n","expected":"0\n"}],
"abc368_b":[
{"input":"4\n1 2 3 3\n","expected":"4\n"},
{"input":"3\n1 1 100\n","expected":"2\n"}],
"abc369_b":[
{"input":"4\n3 L\n6 R\n9 L\n1 R\n","expected":"11\n"},
{"input":"3\n2 L\n2 L\n100 L\n","expected":"98\n"},
{"input":"8\n22 L\n75 L\n26 R\n45 R\n72 R\n81 R\n47 L\n29 R\n","expected":"188\n"}],
"abc370_b":[
{"input":"4\n3\n2 4\n3 1 2\n2 1 2 4\n","expected":"2\n"},
{"input":"5\n5\n5 5\n5 5 5\n5 5 5 5\n5 5 5 5 5\n","expected":"5\n"},
{"input":"6\n2\n1 5\n1 6 3\n2 6 1 4\n2 1 1 1 6\n5 6 1 2 2 5\n","expected":"5\n"}],
"abc371_b":[
{"input":"2 4\n1 M\n1 M\n2 F\n2 M\n","expected":"Yes\nNo\nNo\nYes\n"},
{"input":"4 7\n2 M\n3 M\n1 F\n4 F\n4 F\n1 F\n2 M\n","expected":"Yes\nYes\nNo\nNo\nNo\nNo\nNo\n"}],
"abc372_b":[
{"input":"6\n","expected":"2\n1 1\n"},
{"input":"100\n","expected":"4\n2 0 2 4\n"},
{"input":"59048\n","expected":"20\n0 0 1 1 2 2 3 3 4 4 5 5 6 6 7 7 8 8 9 9\n"}],
"abc373_b":[
{"input":"ABCDEFGHIJKLMNOPQRSTUVWXYZ\n","expected":"25\n"},
{"input":"MGJYIZDKSBHPVENFLQURTCWOAX\n","expected":"223\n"}],
"abc374_b":[
{"input":"abcde\nabedc\n","expected":"3\n"},
{"input":"abcde\nabcdefg\n","expected":"6\n"},
{"input":"keyence\nkeyence\n","expected":"0\n"}],
}
SAMPLE_COUNTS = {p: len(v) for p, v in PUBLISHED_SAMPLES.items()}


def _lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith("\n") or "\r" in raw:
        raise ValueError("noncanonical")
    body = raw[:-1]
    if body.endswith("\n"):
        raise ValueError("extra blank")
    return body.split("\n")


def _ints(line: str, signed: bool = False) -> list[int]:
    parts = line.split(" ")
    pat = SINT if signed else INT
    if not parts or any(pat.fullmatch(x) is None for x in parts) or " ".join(parts) != line:
        raise ValueError("integer line")
    return [int(x) for x in parts]


def _one_int(line: str, lo: int, hi: int, signed: bool = False) -> int:
    a = _ints(line, signed=signed)
    if len(a) != 1 or not lo <= a[0] <= hi:
        raise ValueError("integer")
    return a[0]


def validate(pid: str, raw: str):
    l = _lines(raw)
    if pid == "abc357_b":
        if len(l) != 1 or MIXED.fullmatch(l[0]) is None or not (1 <= len(l[0]) <= 99) or len(l[0]) % 2 == 0:
            raise ValueError("S")
        return (l[0],)
    if pid == "abc358_b":
        if len(l) != 2:
            raise ValueError("shape")
        na = _ints(l[0]); t = _ints(l[1])
        if len(na) != 2 or not (1 <= na[0] <= 100 and 1 <= na[1] <= 10**6) or len(t) != na[0]:
            raise ValueError("constraints")
        if any(not 0 <= x <= 10**6 for x in t) or any(t[i] >= t[i+1] for i in range(len(t)-1)):
            raise ValueError("T")
        return na[0], na[1], tuple(t)
    if pid == "abc359_b":
        if len(l) != 2:
            raise ValueError("shape")
        n = _one_int(l[0], 2, 100); a = _ints(l[1])
        if len(a) != 2*n or any(not 1 <= x <= n for x in a) or any(a.count(x) != 2 for x in range(1, n+1)):
            raise ValueError("A")
        return n, tuple(a)
    if pid == "abc360_b":
        if len(l) != 1:
            raise ValueError("shape")
        p = l[0].split(" ")
        if len(p) != 2 or any(LOWER.fullmatch(x) is None for x in p) or not (1 <= len(p[1]) <= len(p[0]) <= 100):
            raise ValueError("strings")
        return p[0], p[1]
    if pid == "abc361_b":
        if len(l) != 2:
            raise ValueError("shape")
        x = _ints(l[0]); y = _ints(l[1])
        if len(x) != 6 or len(y) != 6 or any(not 0 <= z <= 1000 for z in x+y):
            raise ValueError("coords")
        if not (x[0] < x[3] and x[1] < x[4] and x[2] < x[5] and y[0] < y[3] and y[1] < y[4] and y[2] < y[5]):
            raise ValueError("cuboid")
        return tuple(x), tuple(y)
    if pid == "abc362_b":
        if len(l) != 3:
            raise ValueError("shape")
        pts=[]
        for s in l:
            a=_ints(s,signed=True)
            if len(a)!=2 or any(not -1000<=v<=1000 for v in a): raise ValueError("point")
            pts.append(tuple(a))
        (x1,y1),(x2,y2),(x3,y3)=pts
        if (x2-x1)*(y3-y1)==(y2-y1)*(x3-x1): raise ValueError("collinear")
        return tuple(pts)
    if pid == "abc363_b":
        if len(l)!=2: raise ValueError("shape")
        ntp=_ints(l[0]); a=_ints(l[1])
        if len(ntp)!=3 or not(1<=ntp[0]<=100 and 1<=ntp[1]<=100 and 1<=ntp[2]<=ntp[0]) or len(a)!=ntp[0] or any(not 1<=x<=100 for x in a): raise ValueError("constraints")
        return ntp[0],ntp[1],ntp[2],tuple(a)
    if pid == "abc364_b":
        if len(l)<4: raise ValueError("shape")
        hw=_ints(l[0]); st=_ints(l[1])
        if len(hw)!=2 or not(1<=hw[0]<=50 and 1<=hw[1]<=50) or len(st)!=2 or not(1<=st[0]<=hw[0] and 1<=st[1]<=hw[1]): raise ValueError("head")
        h,w=hw
        if len(l)!=h+3: raise ValueError("rows")
        g=tuple(l[2:2+h]); x=l[-1]
        if any(len(r)!=w or any(c not in '.#' for c in r) for r in g) or g[st[0]-1][st[1]-1]!='.': raise ValueError("grid")
        if not 1<=len(x)<=50 or any(c not in 'LRUD' for c in x): raise ValueError("X")
        return h,w,st[0],st[1],g,x
    if pid == "abc365_b":
        if len(l)!=2: raise ValueError("shape")
        n=_one_int(l[0],2,100); a=_ints(l[1])
        if len(a)!=n or any(not 1<=x<=10**9 for x in a) or len(set(a))!=n: raise ValueError("A")
        return n,tuple(a)
    if pid == "abc366_b":
        if not l: raise ValueError("shape")
        n=_one_int(l[0],1,100)
        if len(l)!=n+1 or any(LOWER.fullmatch(s) is None or not 1<=len(s)<=100 for s in l[1:]): raise ValueError("S")
        return n,tuple(l[1:])
    if pid == "abc367_b":
        if len(l)!=1 or re.fullmatch(r"(?:0|[1-9][0-9]?)\.[0-9]{3}",l[0]) is None: raise ValueError("X")
        return (l[0],)
    if pid == "abc368_b":
        if len(l)!=2: raise ValueError("shape")
        n=_one_int(l[0],2,100); a=_ints(l[1])
        if len(a)!=n or any(not 1<=x<=100 for x in a): raise ValueError("A")
        return n,tuple(a)
    if pid == "abc369_b":
        if not l: raise ValueError("shape")
        n=_one_int(l[0],1,100)
        if len(l)!=n+1: raise ValueError("N")
        rows=[]
        for s in l[1:]:
            p=s.split(" ")
            if len(p)!=2 or INT.fullmatch(p[0]) is None or not 1<=int(p[0])<=100 or p[1] not in ('L','R'): raise ValueError("row")
            rows.append((int(p[0]),p[1]))
        return n,tuple(rows)
    if pid == "abc370_b":
        if not l: raise ValueError("shape")
        n=_one_int(l[0],1,100)
        if len(l)!=n+1: raise ValueError("N")
        a=[]
        for i,s in enumerate(l[1:],1):
            row=_ints(s)
            if len(row)!=i or any(not 1<=x<=n for x in row): raise ValueError("row")
            a.append(tuple(row))
        return n,tuple(a)
    if pid == "abc371_b":
        if not l: raise ValueError("shape")
        nm=_ints(l[0])
        if len(nm)!=2 or not(1<=nm[0]<=100 and 1<=nm[1]<=100) or len(l)!=nm[1]+1: raise ValueError("NM")
        rows=[]
        for s in l[1:]:
            p=s.split(" ")
            if len(p)!=2 or INT.fullmatch(p[0]) is None or not 1<=int(p[0])<=nm[0] or p[1] not in ('M','F'): raise ValueError("row")
            rows.append((int(p[0]),p[1]))
        return nm[0],nm[1],tuple(rows)
    if pid == "abc372_b":
        if len(l)!=1: raise ValueError("shape")
        return (_one_int(l[0],1,100000),)
    if pid == "abc373_b":
        if len(l)!=1 or UPPER.fullmatch(l[0]) is None or len(l[0])!=26 or set(l[0])!=set("ABCDEFGHIJKLMNOPQRSTUVWXYZ"): raise ValueError("S")
        return (l[0],)
    if pid == "abc374_b":
        if len(l)!=2 or any(LOWER.fullmatch(s) is None or not 1<=len(s)<=100 for s in l): raise ValueError("S/T")
        return l[0],l[1]
    raise KeyError(pid)


def _oracle(pid: str, data) -> str:
    if pid=="abc357_b":
        s=data[0]; u=sum(c.isupper() for c in s); return s.upper() if u>len(s)-u else s.lower()
    if pid=="abc358_b":
        n,a,t=data; end=0; out=[]
        for x in t: end=max(end,x)+a; out.append(str(end))
        return "\n".join(out)
    if pid=="abc359_b":
        n,a=data; pos={x:[] for x in range(1,n+1)}
        for i,x in enumerate(a): pos[x].append(i)
        return str(sum(v[1]-v[0]==2 for v in pos.values()))
    if pid=="abc360_b":
        s,t=data
        for w in range(1,len(s)):
            chunks=[s[i:i+w] for i in range(0,len(s),w)]
            for c in range(1,w+1):
                got=''.join(x[c-1] for x in chunks if len(x)>=c)
                if got==t:return "Yes"
        return "No"
    if pid=="abc361_b":
        x,y=data
        ok=all(max(x[i],y[i])<min(x[i+3],y[i+3]) for i in range(3))
        return "Yes" if ok else "No"
    if pid=="abc362_b":
        p=data
        ds=sorted((p[i][0]-p[j][0])**2+(p[i][1]-p[j][1])**2 for i,j in ((0,1),(1,2),(2,0)))
        return "Yes" if ds[0]+ds[1]==ds[2] else "No"
    if pid=="abc363_b":
        n,t,p,a=data; kth=sorted(a,reverse=True)[p-1]; return str(max(0,t-kth))
    if pid=="abc364_b":
        h,w,r,c,g,x=data; r-=1;c-=1; d={'L':(0,-1),'R':(0,1),'U':(-1,0),'D':(1,0)}
        for ch in x:
            dr,dc=d[ch]; nr,nc=r+dr,c+dc
            if 0<=nr<h and 0<=nc<w and g[nr][nc]=='.':r,c=nr,nc
        return f"{r+1} {c+1}"
    if pid=="abc365_b":
        n,a=data; return str(sorted(range(n),key=lambda i:a[i],reverse=True)[1]+1)
    if pid=="abc366_b":
        n,s=data; m=max(map(len,s)); out=[]
        for j in range(m): out.append(''.join((s[i][j] if j<len(s[i]) else '*') for i in range(n-1,-1,-1)).rstrip('*'))
        return '\n'.join(out)
    if pid=="abc367_b":
        return data[0].rstrip('0').rstrip('.')
    if pid=="abc368_b":
        n,a=data; total=sum(a); mx=max(a); return str(min(total//2,total-mx))
    if pid=="abc369_b":
        n,rows=data; by={'L':[],'R':[]}
        for a,s in rows:by[s].append(a)
        return str(sum(abs(v[i]-v[i-1]) for v in by.values() for i in range(1,len(v))))
    if pid=="abc370_b":
        n,a=data; cur=1
        for x in range(1,n+1):
            hi=max(cur,x); lo=min(cur,x); cur=a[hi-1][lo-1]
        return str(cur)
    if pid=="abc371_b":
        n,m,rows=data; seen=set(); out=[]
        for a,b in rows:
            if b=='M' and a not in seen:out.append('Yes');seen.add(a)
            else:out.append('No')
        return '\n'.join(out)
    if pid=="abc372_b":
        m=data[0]; out=[]; e=0
        while m:
            m,r=divmod(m,3); out.extend([e]*r); e+=1
        return str(len(out))+'\n'+' '.join(map(str,out))
    if pid=="abc373_b":
        s=data[0]; pos={c:i for i,c in enumerate(s)}; return str(sum(abs(pos[chr(65+i)]-pos[chr(66+i)]) for i in range(25)))
    if pid=="abc374_b":
        s,t=data
        if s==t:return '0'
        for i,(a,b) in enumerate(itertools.zip_longest(s,t),1):
            if a!=b:return str(i)
    raise KeyError(pid)


def _valid_372_output(m:int, actual:str)->bool:
    lines=actual.split('\n')
    if len(lines)!=2:return False
    try:
        n=int(lines[0]); arr=list(map(int,lines[1].split())) if lines[1] else []
    except ValueError:return False
    return 1<=n<=20 and len(arr)==n and all(0<=x<=10 for x in arr) and sum(3**x for x in arr)==m


def independent_check(pid: str, raw: str, actual: str) -> bool:
    try:data=validate(pid,raw)
    except (ValueError,KeyError):return False
    if pid=="abc372_b":return _valid_372_output(data[0],actual)
    return actual==_oracle(pid,data)


def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    try:data=validate(pid,raw)
    except ValueError:return False
    exp=expected.removesuffix('\n'); out=stdout.removesuffix('\n')
    if pid=="abc372_b":return _valid_372_output(data[0],exp) and _valid_372_output(data[0],out)
    return out==exp and independent_check(pid,raw,exp)


def _make_cases(pid:str)->list[dict[str,str]]:
    raws=[]
    if pid=="abc357_b":
        vals=['a','A','aBc','ABc','abcDE','ABCDEfg','AtCoder','SunTORY','z'*9,'Z'*9,'aAaaa','AaAAA','xYz'*3,'AbCdEfG','m'*49+'N'*50,'M'*51+'n'*48,'a'*97+'BB','A'*99]
        raws=[s+'\n' for s in vals]
    elif pid=="abc358_b":
        vals=[(1,1,[0]),(1,10,[5]),(2,3,[0,1]),(2,3,[0,3]),(3,2,[0,1,2]),(3,2,[0,3,6]),(4,5,[1,2,20,21]),(5,1,[0,1,2,3,4]),(5,10,[0,9,10,50,51]),(6,7,[1,8,9,15,40,41]),(3,1000000,[0,1,1000000]),(4,2,[999990,999992,999994,999996]),(10,3,list(range(10))),(10,100,[i*200 for i in range(10)]),(20,17,[i*13 for i in range(20)]),(50,1000,[i*100 for i in range(50)]),(99,1,list(range(99))),(100,1000000,list(range(0,1000000,10000)))]
        raws=[f"{n} {a}\n"+' '.join(map(str,t))+'\n' for n,a,t in vals]
    elif pid=="abc359_b":
        for n in list(range(2,18))+[100,99]:
            a=[]
            for x in range(1,n+1):a.extend([x,x])
            if n%2: a=a[1:]+a[:1]
            raws.append(f"{n}\n"+' '.join(map(str,a))+'\n')
    elif pid=="abc360_b":
        pairs=[('ab','a'),('ab','b'),('abc','ac'),('abc','b'),('abcd','ac'),('abcd','bd'),('abcde','ace'),('atcoder','toe'),('beginner','r'),('verticalreading','agh'),('aaaa','aa'),('abcdef','ad'),('abcdef','be'),('abcdef','cf'),('abcdefghij','acegi'),('xyzxyz','xx'),('a'*99+'b','ab'),('abcdefghijklmnopqrstuvwxyz'*3+'abcdefghijklmnopqrstuv','acegikmoqsuwy')]
        raws=[f"{s} {t}\n" for s,t in pairs]
    elif pid=="abc361_b":
        vals=[((0,0,0,1,1,1),(0,0,0,1,1,1)),((0,0,0,1,1,1),(1,0,0,2,1,1)),((0,0,0,2,2,2),(1,1,1,3,3,3)),((0,0,0,2,2,2),(0,2,0,2,4,2)),((1,1,1,3,3,3),(0,0,0,4,4,4)),((0,0,0,5,5,5),(2,2,5,4,4,6)),((10,20,30,40,50,60),(20,30,40,50,60,70)),((10,10,10,20,20,20),(0,0,0,10,10,10)),((0,100,200,300,400,500),(299,399,499,600,700,800)),((1,2,3,4,5,6),(2,3,4,3,4,5)),((0,0,0,1000,1,1),(500,0,0,1000,1,1)),((0,0,0,10,10,10),(3,3,3,7,7,7)),((100,100,100,200,200,200),(201,100,100,300,200,200)),((0,0,0,100,100,100),(99,99,99,1000,1000,1000)),((0,0,0,1,1000,1000),(0,999,999,1,1000,1000)),((5,5,5,6,6,6),(4,4,4,7,7,7)),((0,0,0,999,999,999),(998,998,998,1000,1000,1000)),((0,0,0,1000,1000,1000),(1,1,1,999,999,999))]
        raws=[' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n' for a,b in vals]
    elif pid=="abc362_b":
        pts=[((0,0),(1,0),(0,1)),((0,0),(3,0),(0,4)),((1,1),(2,2),(3,1)),((-1,-1),(-1,2),(3,-1)),((0,0),(2,1),(1,3)),((2,4),(-3,2),(1,-2)),((-4,3),(2,1),(3,4)),((10,10),(20,10),(10,30)),((-10,0),(0,10),(10,0)),((0,0),(2,0),(1,2)),((100,100),(101,102),(105,100)),((-1000,-1000),(-999,-1000),(-1000,1000)),((999,999),(1000,999),(999,1000)),((-1000,0),(0,1000),(1000,0)),((3,7),(8,7),(3,19)),((1,2),(4,6),(8,3)),((-500,200),(300,200),(-500,-400)),((-1000,-1000),(1000,-1000),(-1000,1000))]
        raws=['\n'.join(f'{x} {y}' for x,y in p)+'\n' for p in pts]
    elif pid=="abc363_b":
        vals=[]
        for k in range(17):
            n=1+(k%10); t=1+(k*7)%100; p=1+(k%n); a=[1+((i*11+k*3)%100) for i in range(n)]; vals.append((n,t,p,a))
        vals.append((100,100,100,[1]*100))
        raws=[f"{n} {t} {p}\n"+' '.join(map(str,a))+'\n' for n,t,p,a in vals]
    elif pid=="abc364_b":
        for k in range(17):
            h=1+(k%5);w=1+((k*2)%5);r=1+(k%h);c=1+((k*3)%w);g=[['.' for _ in range(w)] for _ in range(h)]
            if h*w>1:
                br=(r%h);bc=(c%w)
                if (br,bc)!=(r-1,c-1):g[br][bc]='#'
            x=('LRUD'*(1+k%8))[:1+(k%20)]; raws.append(f"{h} {w}\n{r} {c}\n"+'\n'.join(''.join(z) for z in g)+'\n'+x+'\n')
        h=w=50;g=['.'*50 for _ in range(50)];x=('LRUD'*13)[:50];raws.append(f"50 50\n25 25\n"+'\n'.join(g)+'\n'+x+'\n')
    elif pid=="abc365_b":
        for k in range(17):
            n=2+(k%20);a=list(range(1,n+1));a=a[k%n:]+a[:k%n];raws.append(f"{n}\n"+' '.join(map(str,a))+'\n')
        a=[10**9-i for i in range(100)];raws.append('100\n'+' '.join(map(str,a))+'\n')
    elif pid=="abc366_b":
        sets=[['a'],['a','b'],['ab','c'],['a','bc'],['abc','de','fghi'],['atcoder','beginner','contest']]
        for k in range(6,17):sets.append([chr(97+(i+k)%26)*(1+(i+k)%10) for i in range(1+(k%8))])
        sets.append([chr(97+i%26)*100 for i in range(100)])
        raws=[str(len(s))+'\n'+'\n'.join(s)+'\n' for s in sets]
    elif pid=="abc367_b":
        vals=['0.000','0.001','0.010','0.100','1.000','1.001','1.010','1.100','1.012','9.999','10.000','12.340','50.500','90.090','99.900','99.990','99.999','98.765'];raws=[x+'\n' for x in vals]
    elif pid=="abc368_b":
        for k in range(17):
            n=2+(k%12);a=[1+((i*7+k)%20) for i in range(n)];raws.append(f"{n}\n"+' '.join(map(str,a))+'\n')
        raws.append('100\n'+' '.join(['100']*100)+'\n')
    elif pid=="abc369_b":
        for k in range(17):
            n=1+(k%12);rows=[(1+((i*17+k)%100),'L' if (i+k)%2==0 else 'R') for i in range(n)];raws.append(str(n)+'\n'+'\n'.join(f'{a} {s}' for a,s in rows)+'\n')
        rows=[(1 if i%2==0 else 100,'L' if i<50 else 'R') for i in range(100)];raws.append('100\n'+'\n'.join(f'{a} {s}' for a,s in rows)+'\n')
    elif pid=="abc370_b":
        for k in range(17):
            n=k+1;rows=[]
            for i in range(1,n+1):rows.append([1+((i*7+j*11+k)%n) for j in range(i)])
            raws.append(str(n)+'\n'+'\n'.join(' '.join(map(str,r)) for r in rows)+'\n')
        n=100;rows=[[1+((i+j)%n) for j in range(i)] for i in range(1,n+1)];raws.append(str(n)+'\n'+'\n'.join(' '.join(map(str,r)) for r in rows)+'\n')
    elif pid=="abc371_b":
        for k in range(17):
            n=1+(k%10);m=1+(k%15);rows=[(1+((i+k)%n),'M' if (i*3+k)%4 else 'F') for i in range(m)];raws.append(f'{n} {m}\n'+'\n'.join(f'{a} {b}' for a,b in rows)+'\n')
        rows=[(1+(i%100),'M' if i%2 else 'F') for i in range(100)];raws.append('100 100\n'+'\n'.join(f'{a} {b}' for a,b in rows)+'\n')
    elif pid=="abc372_b":
        vals=[1,2,3,4,5,6,7,8,9,10,27,28,81,100,999,59048,99999,100000];raws=[f'{x}\n' for x in vals]
    elif pid=="abc373_b":
        vals=['ABCDEFGHIJKLMNOPQRSTUVWXYZ','BACDEFGHIJKLMNOPQRSTUVWXYZ','ZYXWVUTSRQPONMLKJIHGFEDCBA','MGJYIZDKSBHPVENFLQURTCWOAX']
        base=list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
        for k in range(4,17): vals.append(''.join(base[k:]+base[:k]))
        vals.append('QWERTYUIOPASDFGHJKLZXCVBNM')
        raws=[s+'\n' for s in vals]
    elif pid=="abc374_b":
        pairs=[('a','a'),('a','b'),('a','aa'),('aa','a'),('abc','abc'),('abc','abd'),('abc','xbc'),('abcde','abedc'),('abcde','abcdefg'),('abcdefg','abcde'),('keyence','keyence'),('aaaa','aaab'),('z','zz'),('hello','hella'),('atcoder','atcodex'),('sameprefixx','sameprefixy'),('a'*100,'a'*99+'b'),('a'*100,'a'*99)]
        raws=[s+'\n'+t+'\n' for s,t in pairs]
    else:raise KeyError(pid)
    if len(raws)!=18 or len(set(raws))!=18:raise ValueError(f'{pid}: generator did not produce 18 distinct ({len(raws)}/{len(set(raws))})')
    return [{'category':('constraint_max' if i==17 else f'case_{i+1:02d}'),'input':r} for i,r in enumerate(raws)]


def generate(pid:str)->list[dict[str,str]]:return _make_cases(pid)

REFERENCE_CODE = {
"abc357_b":'''S=input()\nu=sum(c.isupper() for c in S)\nprint(S.upper() if u>len(S)-u else S.lower())\n''',
"abc358_b":'''N,A=map(int,input().split());T=list(map(int,input().split()));end=0\nfor x in T:\n end=max(end,x)+A;print(end)\n''',
"abc359_b":'''N=int(input());A=list(map(int,input().split()));print(sum(A[i]==A[i+2] for i in range(2*N-2)))\n''',
"abc360_b":'''S,T=input().split();ok=False\nfor w in range(1,len(S)):\n for c in range(w):\n  if S[c::w]==T:ok=True\nprint('Yes' if ok else 'No')\n''',
"abc361_b":'''a,b,c,d,e,f=map(int,input().split());g,h,i,j,k,l=map(int,input().split())\nprint('Yes' if max(a,g)<min(d,j) and max(b,h)<min(e,k) and max(c,i)<min(f,l) else 'No')\n''',
"abc362_b":'''P=[tuple(map(int,input().split())) for _ in range(3)]\nfor i in range(3):\n x,y=P[i];u,v=P[(i+1)%3];p,q=P[(i+2)%3]\n if (u-x)*(p-x)+(v-y)*(q-y)==0:print('Yes');break\nelse:print('No')\n''',
"abc363_b":'''N,T,P=map(int,input().split());L=list(map(int,input().split()));d=0\nwhile sum(x+d>=T for x in L)<P:d+=1\nprint(d)\n''',
"abc364_b":'''H,W=map(int,input().split());r,c=map(int,input().split());r-=1;c-=1;G=[input() for _ in range(H)];X=input();D={'L':(0,-1),'R':(0,1),'U':(-1,0),'D':(1,0)}\nfor ch in X:\n dr,dc=D[ch];nr,nc=r+dr,c+dc\n if 0<=nr<H and 0<=nc<W and G[nr][nc]=='.':r,c=nr,nc\nprint(r+1,c+1)\n''',
"abc365_b":'''N=int(input());A=list(map(int,input().split()));B=sorted((x,i) for i,x in enumerate(A));print(B[-2][1]+1)\n''',
"abc366_b":'''N=int(input());S=[input() for _ in range(N)];M=max(map(len,S))\nfor j in range(M):\n t=''\n for i in range(N-1,-1,-1):t+=S[i][j] if j<len(S[i]) else '*'\n print(t.rstrip('*'))\n''',
"abc367_b":'''X=input();print(X.rstrip('0').rstrip('.'))\n''',
"abc368_b":'''import heapq\nN=int(input());h=[-x for x in map(int,input().split())];heapq.heapify(h);ans=0\nwhile len(h)>=2:\n a=-heapq.heappop(h);b=-heapq.heappop(h)\n if b==0:break\n a-=1;b-=1;ans+=1\n heapq.heappush(h,-a);heapq.heappush(h,-b)\nprint(ans)\n''',
"abc369_b":'''N=int(input());last={};ans=0\nfor _ in range(N):\n a,s=input().split();a=int(a)\n if s in last:ans+=abs(a-last[s])\n last[s]=a\nprint(ans)\n''',
"abc370_b":'''N=int(input());A=[list(map(int,input().split())) for _ in range(N)];x=1\nfor i in range(1,N+1):x=A[max(x,i)-1][min(x,i)-1]\nprint(x)\n''',
"abc371_b":'''N,M=map(int,input().split());seen=[False]*(N+1)\nfor _ in range(M):\n a,b=input().split();a=int(a)\n if b=='M' and not seen[a]:print('Yes');seen[a]=True\n else:print('No')\n''',
"abc372_b":'''M=int(input());A=[];e=0\nwhile M:\n M,r=divmod(M,3);A += [e]*r;e+=1\nprint(len(A));print(*A)\n''',
"abc373_b":'''S=input();ans=0\nfor i in range(25):ans+=abs(S.index(chr(65+i))-S.index(chr(66+i)))\nprint(ans)\n''',
"abc374_b":'''S=input();T=input()\nif S==T:print(0)\nelse:\n for i in range(max(len(S),len(T))):\n  if i>=len(S) or i>=len(T) or S[i]!=T[i]:print(i+1);break\n''',
}
