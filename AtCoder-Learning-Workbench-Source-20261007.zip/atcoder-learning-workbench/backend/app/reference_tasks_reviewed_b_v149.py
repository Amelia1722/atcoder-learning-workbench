"""Turn 126: reviewed B tasks ABC375 B through ABC392 B.

Public AtCoder statements, constraints, and every published sample were manually reviewed.
Official HTML is not archived/authenticated; entries therefore remain full_size=False.
"""
from __future__ import annotations

import itertools
import math
import re
from collections import Counter, deque
from fractions import Fraction

TASKS = tuple(f"abc{i}_b" for i in range(375, 393))
LANES = {
    "A": ("abc375_b", "abc376_b", "abc377_b"),
    "B": ("abc378_b", "abc379_b", "abc380_b"),
    "C": ("abc381_b", "abc382_b", "abc383_b"),
    "D": ("abc384_b", "abc385_b", "abc386_b"),
    "E": ("abc387_b", "abc388_b", "abc389_b"),
    "F": ("abc390_b", "abc391_b", "abc392_b"),
}
TITLES = {
    "abc375_b": "Traveling Takahashi Problem",
    "abc376_b": "Hands on Ring (Easy)",
    "abc377_b": "Avoid Rook Attack",
    "abc378_b": "Garbage Collection",
    "abc379_b": "Strawberries",
    "abc380_b": "Hurdle Parsing",
    "abc381_b": "1122 String",
    "abc382_b": "Daily Cookie 2",
    "abc383_b": "Humidifier 2",
    "abc384_b": "ARC Division",
    "abc385_b": "Santa Claus 1",
    "abc386_b": "Calculator",
    "abc387_b": "9x9 Sum",
    "abc388_b": "Heavy Snake",
    "abc389_b": "tcaF",
    "abc390_b": "Geometric Sequence",
    "abc391_b": "Seek Grid",
    "abc392_b": "Who is Missing?",
}
INT = re.compile(r"(?:0|[1-9][0-9]*)", re.ASCII)
SINT = re.compile(r"(?:0|-?[1-9][0-9]*)", re.ASCII)
LOWER = re.compile(r"[a-z]+", re.ASCII)
DIGITS = re.compile(r"[0-9]+", re.ASCII)

PUBLISHED_SAMPLES = {
"abc375_b":[
{"input":"2\n1 2\n-1 0\n","expected":"6.06449510224597979401\n"},
{"input":"7\n-14142 13562\n-17320 50807\n-22360 67977\n24494 89742\n-26457 51311\n28284 27124\n31622 77660\n","expected":"384694.57587932075868509383\n"},
{"input":"5\n-100000 100000\n100000 -100000\n-100000 100000\n100000 -100000\n-100000 100000\n","expected":"1414213.56237309504880168872\n"}],
"abc376_b":[
{"input":"6 3\nR 4\nL 5\nR 6\n","expected":"8\n"},
{"input":"100 2\nL 1\nR 2\n","expected":"0\n"},
{"input":"30 8\nR 23\nR 26\nR 29\nL 20\nR 29\nR 19\nL 7\nL 16\n","expected":"92\n"}],
"abc377_b":[
{"input":"...#....\n#.......\n.......#\n....#...\n.#......\n........\n........\n..#.....\n","expected":"4\n"},
{"input":"........\n........\n........\n........\n........\n........\n........\n........\n","expected":"64\n"},
{"input":".#......\n..#..#..\n....#...\n........\n..#....#\n........\n...#....\n....#...\n","expected":"4\n"}],
"abc378_b":[
{"input":"2\n7 3\n4 2\n5\n1 1\n1 3\n1 4\n1 15\n2 7\n","expected":"3\n3\n10\n17\n10\n"}],
"abc379_b":[
{"input":"7 3\nOOXOOOO\n","expected":"1\n"},
{"input":"12 2\nOXXOOOXOOOOX\n","expected":"3\n"},
{"input":"22 5\nXXOOOOOOOOXXOOOOOXXXXX\n","expected":"2\n"}],
"abc380_b":[
{"input":"|---|-|----|-|-----|\n","expected":"3 1 4 1 5\n"},
{"input":"|----------|\n","expected":"10\n"},
{"input":"|-|-|-|------|\n","expected":"1 1 1 6\n"}],
"abc381_b":[
{"input":"aabbcc\n","expected":"Yes\n"},
{"input":"aab\n","expected":"No\n"},
{"input":"zzzzzz\n","expected":"No\n"}],
"abc382_b":[
{"input":"5 2\n.@@.@\n","expected":".@...\n"},
{"input":"3 3\n@@@\n","expected":"...\n"},
{"input":"10 4\n@@@.@@.@@.\n","expected":"@@@.......\n"}],
"abc383_b":[
{"input":"2 5 1\n.###.\n.#.##\n","expected":"3\n"},
{"input":"5 5 2\n.#.#.\n.....\n.#.#.\n#.#.#\n.....\n","expected":"15\n"},
{"input":"4 4 2\n....\n.##.\n.##.\n....\n","expected":"10\n"}],
"abc384_b":[
{"input":"4 1255\n2 900\n1 521\n2 600\n1 52\n","expected":"2728\n"},
{"input":"2 3031\n1 1000\n2 -1000\n","expected":"3031\n"},
{"input":"15 2352\n2 -889\n2 420\n2 -275\n1 957\n1 -411\n1 -363\n1 151\n2 -193\n2 289\n2 -770\n2 109\n1 345\n2 551\n1 -702\n1 355\n","expected":"1226\n"}],
"abc385_b":[
{"input":"5 5 3 4\n#####\n#...#\n#.@.#\n#..@#\n#####\nLLLDRUU\n","expected":"2 3 1\n"},
{"input":"6 13 4 6\n#############\n#@@@@@@@@@@@#\n#@@@@@@@@@@@#\n#@@@@.@@@@@@#\n#@@@@@@@@@@@#\n#############\nUURUURLRLUUDDURDURRR\n","expected":"3 11 11\n"},
{"input":"12 35 7 10\n###################################\n#.................................#\n#..........@......................#\n#......@................@.........#\n#.............##............@.....#\n#...##........##....##............#\n#...##........##....##.......##...#\n#....##......##......##....##.....#\n#....##......##......##..##.......#\n#.....#######.........###.........#\n#.................................#\n###################################\nLRURRRUUDDULUDUUDLRLRDRRLULRRUDLDRU\n","expected":"4 14 1\n"}],
"abc386_b":[
{"input":"1000000007\n","expected":"6\n"},
{"input":"998244353\n","expected":"9\n"},
{"input":"32000\n","expected":"4\n"}],
"abc387_b":[
{"input":"1\n","expected":"2024\n"},
{"input":"11\n","expected":"2025\n"},
{"input":"24\n","expected":"1929\n"}],
"abc388_b":[
{"input":"4 3\n3 3\n5 1\n2 4\n1 10\n","expected":"12\n15\n20\n"},
{"input":"1 4\n100 100\n","expected":"10100\n10200\n10300\n10400\n"}],
"abc389_b":[
{"input":"6\n","expected":"3\n"},
{"input":"2432902008176640000\n","expected":"20\n"}],
"abc390_b":[
{"input":"5\n3 6 12 24 48\n","expected":"Yes\n"},
{"input":"3\n1 2 3\n","expected":"No\n"},
{"input":"2\n10 8\n","expected":"Yes\n"}],
"abc391_b":[
{"input":"3 2\n#.#\n..#\n##.\n.#\n#.\n","expected":"2 2\n"},
{"input":"2 1\n#.\n##\n.\n","expected":"1 2\n"}],
"abc392_b":[
{"input":"10 3\n3 9 2\n","expected":"7\n1 4 5 6 7 8 10\n"},
{"input":"6 6\n1 3 5 2 4 6\n","expected":"0\n\n"},
{"input":"9 1\n9\n","expected":"8\n1 2 3 4 5 6 7 8\n"}],
}
SAMPLE_COUNTS = {p: len(v) for p, v in PUBLISHED_SAMPLES.items()}


def _lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith("\n") or "\r" in raw:
        raise ValueError("noncanonical")
    body = raw[:-1]
    if body.endswith("\n"):
        raise ValueError("extra blank")
    return body.split("\n")


def _ints(line: str, signed: bool = False) -> list[int]:
    parts = line.split(" ")
    pat = SINT if signed else INT
    if not parts or any(pat.fullmatch(x) is None for x in parts) or " ".join(parts) != line:
        raise ValueError("integer line")
    return [int(x) for x in parts]


def _one_int(line: str, lo: int, hi: int, signed: bool = False) -> int:
    a = _ints(line, signed=signed)
    if len(a) != 1 or not lo <= a[0] <= hi:
        raise ValueError("integer")
    return a[0]


def _find_391(s: tuple[str, ...], t: tuple[str, ...]) -> list[tuple[int,int]]:
    n=len(s);m=len(t);out=[]
    for a in range(n-m+1):
        for b in range(n-m+1):
            if all(s[a+i][b:b+m]==t[i] for i in range(m)):
                out.append((a+1,b+1))
    return out


def validate(pid: str, raw: str):
    l = _lines(raw)
    if pid == "abc375_b":
        if not l: raise ValueError("shape")
        n=_one_int(l[0],1,200000)
        if len(l)!=n+1: raise ValueError("N")
        pts=[]
        for s in l[1:]:
            a=_ints(s,signed=True)
            if len(a)!=2 or any(not -10**9<=v<=10**9 for v in a): raise ValueError("point")
            pts.append(tuple(a))
        return n,tuple(pts)
    if pid == "abc376_b":
        if not l: raise ValueError("shape")
        nq=_ints(l[0]);
        if len(nq)!=2 or not(3<=nq[0]<=100 and 1<=nq[1]<=100) or len(l)!=nq[1]+1: raise ValueError("head")
        n,q=nq; left,right=1,2; rows=[]
        for s in l[1:]:
            p=s.split(" ")
            if len(p)!=2 or p[0] not in ('L','R') or INT.fullmatch(p[1]) is None: raise ValueError("row")
            t=int(p[1])
            if not 1<=t<=n: raise ValueError("target")
            if (p[0]=='L' and t==right) or (p[0]=='R' and t==left): raise ValueError("unachievable")
            rows.append((p[0],t))
            if p[0]=='L': left=t
            else: right=t
        return n,q,tuple(rows)
    if pid == "abc377_b":
        if len(l)!=8 or any(len(s)!=8 or any(c not in '.#' for c in s) for s in l): raise ValueError("grid")
        return (tuple(l),)
    if pid == "abc378_b":
        if not l: raise ValueError("shape")
        n=_one_int(l[0],1,100)
        if len(l)<n+2: raise ValueError("shape")
        qr=[]
        for s in l[1:n+1]:
            a=_ints(s)
            if len(a)!=2 or not(1<=a[0]<=10**9 and 0<=a[1]<a[0]): raise ValueError("schedule")
            qr.append(tuple(a))
        q=_one_int(l[n+1],1,100)
        if len(l)!=n+q+2: raise ValueError("Q")
        queries=[]
        for s in l[n+2:]:
            a=_ints(s)
            if len(a)!=2 or not(1<=a[0]<=n and 1<=a[1]<=10**9): raise ValueError("query")
            queries.append(tuple(a))
        return n,tuple(qr),q,tuple(queries)
    if pid == "abc379_b":
        if len(l)!=2: raise ValueError("shape")
        nk=_ints(l[0]);
        if len(nk)!=2 or not(1<=nk[1]<=nk[0]<=100): raise ValueError("head")
        if len(l[1])!=nk[0] or any(c not in 'OX' for c in l[1]): raise ValueError("S")
        return nk[0],nk[1],l[1]
    if pid == "abc380_b":
        if len(l)!=1 or not 3<=len(l[0])<=100 or l[0][0]!='|' or l[0][-1]!='|' or any(c not in '|-' for c in l[0]): raise ValueError("S")
        parts=l[0].split('|')
        if parts[0] or parts[-1] or any(not p or set(p)!={'-'} for p in parts[1:-1]): raise ValueError("generated form")
        return (l[0],)
    if pid == "abc381_b":
        if len(l)!=1 or LOWER.fullmatch(l[0]) is None or not 1<=len(l[0])<=100: raise ValueError("S")
        return (l[0],)
    if pid == "abc382_b":
        if len(l)!=2: raise ValueError("shape")
        nd=_ints(l[0]);
        if len(nd)!=2 or not(1<=nd[1]<=nd[0]<=100): raise ValueError("head")
        s=l[1]
        if len(s)!=nd[0] or any(c not in '.@' for c in s) or s.count('@')<nd[1]: raise ValueError("S")
        return nd[0],nd[1],s
    if pid == "abc383_b":
        if not l: raise ValueError("shape")
        hwd=_ints(l[0]);
        if len(hwd)!=3 or not(1<=hwd[0]<=10 and 1<=hwd[1]<=10 and hwd[0]*hwd[1]>=2 and 0<=hwd[2]<=hwd[0]+hwd[1]-2): raise ValueError("head")
        h,w,d=hwd
        if len(l)!=h+1: raise ValueError("rows")
        g=tuple(l[1:])
        if any(len(r)!=w or any(c not in '.#' for c in r) for r in g) or sum(r.count('.') for r in g)<2: raise ValueError("grid")
        return h,w,d,g
    if pid == "abc384_b":
        if not l: raise ValueError("shape")
        nr=_ints(l[0]);
        if len(nr)!=2 or not(1<=nr[0]<=100 and 0<=nr[1]<=4229) or len(l)!=nr[0]+1: raise ValueError("head")
        rows=[]
        for s in l[1:]:
            a=_ints(s,signed=True)
            if len(a)!=2 or a[0] not in (1,2) or not -1000<=a[1]<=1000: raise ValueError("row")
            rows.append(tuple(a))
        return nr[0],nr[1],tuple(rows)
    if pid == "abc385_b":
        if not l: raise ValueError("shape")
        a=_ints(l[0]);
        if len(a)!=4 or not(3<=a[0]<=100 and 3<=a[1]<=100 and 1<=a[2]<=a[0] and 1<=a[3]<=a[1]): raise ValueError("head")
        h,w,x,y=a
        if len(l)!=h+2: raise ValueError("rows")
        g=tuple(l[1:1+h]);t=l[-1]
        if any(len(r)!=w or any(c not in '#.@' for c in r) for r in g): raise ValueError("grid")
        if any(g[i][0]!='#' or g[i][-1]!='#' for i in range(h)) or any(g[0][j]!='#' or g[-1][j]!='#' for j in range(w)): raise ValueError("boundary")
        if g[x-1][y-1]!='.': raise ValueError("start")
        if not 1<=len(t)<=10000 or any(c not in 'UDLR' for c in t): raise ValueError("T")
        return h,w,x,y,g,t
    if pid == "abc386_b":
        if len(l)!=1 or DIGITS.fullmatch(l[0]) is None or not 1<=len(l[0])<=1000 or l[0][0]=='0': raise ValueError("S")
        return (l[0],)
    if pid == "abc387_b":
        return (_one_int(l[0],1,81),) if len(l)==1 else (_ for _ in ()).throw(ValueError("shape"))
    if pid == "abc388_b":
        if not l: raise ValueError("shape")
        nd=_ints(l[0]);
        if len(nd)!=2 or not(1<=nd[0]<=100 and 1<=nd[1]<=100) or len(l)!=nd[0]+1: raise ValueError("head")
        rows=[]
        for s in l[1:]:
            a=_ints(s)
            if len(a)!=2 or any(not 1<=v<=100 for v in a): raise ValueError("row")
            rows.append(tuple(a))
        return nd[0],nd[1],tuple(rows)
    if pid == "abc389_b":
        if len(l)!=1: raise ValueError("shape")
        x=_one_int(l[0],2,3*10**18)
        f=1; valid=False
        for n in range(1,21):
            f*=n
            if f==x: valid=True; break
        if not valid: raise ValueError("factorial guarantee")
        return (x,)
    if pid == "abc390_b":
        if len(l)!=2: raise ValueError("shape")
        n=_one_int(l[0],2,100);a=_ints(l[1])
        if len(a)!=n or any(not 1<=v<=10**9 for v in a): raise ValueError("A")
        return n,tuple(a)
    if pid == "abc391_b":
        if not l: raise ValueError("shape")
        nm=_ints(l[0]);
        if len(nm)!=2 or not(1<=nm[1]<=nm[0]<=50): raise ValueError("head")
        n,m=nm
        if len(l)!=1+n+m: raise ValueError("rows")
        s=tuple(l[1:1+n]);t=tuple(l[1+n:])
        if any(len(r)!=n or any(c not in '.#' for c in r) for r in s) or any(len(r)!=m or any(c not in '.#' for c in r) for r in t): raise ValueError("grid")
        if len(_find_391(s,t))!=1: raise ValueError("unique match guarantee")
        return n,m,s,t
    if pid == "abc392_b":
        if len(l)!=2: raise ValueError("shape")
        nm=_ints(l[0]);a=_ints(l[1])
        if len(nm)!=2 or not(1<=nm[1]<=nm[0]<=1000) or len(a)!=nm[1] or any(not 1<=v<=nm[0] for v in a) or len(set(a))!=len(a): raise ValueError("constraints")
        return nm[0],nm[1],tuple(a)
    raise KeyError(pid)


def _oracle(pid: str, data) -> str:
    if pid=="abc375_b":
        _,pts=data; prev=(0,0);total=0.0
        for p in pts+((0,0),):
            dx=prev[0]-p[0];dy=prev[1]-p[1];total += math.sqrt(dx*dx+dy*dy);prev=p
        return repr(total)
    if pid=="abc376_b":
        n,_,rows=data;pos={'L':1,'R':2};ans=0
        for hand,t in rows:
            other=pos['R' if hand=='L' else 'L'];start=pos[hand]
            q=deque([(start,0)]);seen={start}
            while q:
                v,d=q.popleft()
                if v==t: ans+=d;break
                for u in ((v-2)%n+1,v%n+1):
                    if u!=other and u not in seen:seen.add(u);q.append((u,d+1))
            pos[hand]=t
        return str(ans)
    if pid=="abc377_b":
        g=data[0];pieces=[(i,j) for i in range(8) for j in range(8) if g[i][j]=='#']
        return str(sum(g[i][j]=='.' and all(i!=r and j!=c for r,c in pieces) for i in range(8) for j in range(8)))
    if pid=="abc378_b":
        _,sched,_,queries=data;out=[]
        for t,d in queries:
            q,r=sched[t-1];k=0 if d<=r else (d-r+q-1)//q;out.append(str(k*q+r))
        return '\n'.join(out)
    if pid=="abc379_b":
        _,k,s=data;return str(sum(len(run)//k for run in s.split('X')))
    if pid=="abc380_b":
        return ' '.join(str(len(x)) for x in re.findall(r'-+',data[0]))
    if pid=="abc381_b":
        s=data[0];pairs=all(s[i]==s[i+1] for i in range(0,len(s)-1,2)) if len(s)%2==0 else False
        return 'Yes' if pairs and all(v==2 for v in Counter(s).values()) else 'No'
    if pid=="abc382_b":
        _,d,s=data;pos=[i for i,c in enumerate(s) if c=='@'];kill=set(pos[-d:]);return ''.join('.' if i in kill else c for i,c in enumerate(s))
    if pid=="abc383_b":
        h,w,d,g=data;floor=[(i,j) for i in range(h) for j in range(w) if g[i][j]=='.'];best=0
        for a,b in itertools.combinations(floor,2):
            wet={p for p in floor if min(abs(p[0]-a[0])+abs(p[1]-a[1]),abs(p[0]-b[0])+abs(p[1]-b[1]))<=d};best=max(best,len(wet))
        return str(best)
    if pid=="abc384_b":
        _,r,rows=data
        ranges={1:(1600,2799),2:(1200,2399)}
        for div,delta in rows:
            lo,hi=ranges[div]
            if lo<=r<=hi:r+=delta
        return str(r)
    if pid=="abc385_b":
        h,w,x,y,g,t=data;z=complex(x-1,y-1);delta={'U':-1,'D':1,'L':-1j,'R':1j};houses=set()
        for ch in t:
            nz=z+delta[ch];i,j=int(nz.real),int(nz.imag)
            if g[i][j]!='#':z=nz
            i,j=int(z.real),int(z.imag)
            if g[i][j]=='@':houses.add((i,j))
        return f'{int(z.real)+1} {int(z.imag)+1} {len(houses)}'
    if pid=="abc386_b":
        s=data[0];n=len(s);dp=[10**9]*(n+1);dp[0]=0
        for i in range(n):
            dp[i+1]=min(dp[i+1],dp[i]+1)
            if i+1<n and s[i:i+2]=='00':dp[i+2]=min(dp[i+2],dp[i]+1)
        return str(dp[n])
    if pid=="abc387_b":
        x=data[0];return str(sum(i*j for i in range(1,10) for j in range(1,10) if i*j!=x))
    if pid=="abc388_b":
        _,d,rows=data;return '\n'.join(str(max(t*(l+k) for t,l in rows)) for k in range(1,d+1))
    if pid=="abc389_b":
        x=data[0];n=2;y=x
        while y>1:
            if y%n: return '__invalid__'
            y//=n;n+=1
        return str(n-1)
    if pid=="abc390_b":
        _,a=data;r=Fraction(a[1],a[0]);return 'Yes' if all(Fraction(a[i],a[i-1])==r for i in range(2,len(a))) else 'No'
    if pid=="abc391_b":
        _,_,s,t=data;return ' '.join(map(str,_find_391(s,t)[0]))
    if pid=="abc392_b":
        n,_,a=data;present=[False]*(n+1)
        for x in a:present[x]=True
        miss=[str(i) for i in range(1,n+1) if not present[i]]
        return str(len(miss))+('\n'+' '.join(miss) if miss else '\n')
    raise KeyError(pid)


def _float_ok(actual: str, expected: str, tol: float=1e-6) -> bool:
    try:
        a=float(actual); e=float(expected)
    except ValueError:return False
    if not (math.isfinite(a) and math.isfinite(e)):return False
    return abs(a-e)<=tol or abs(a-e)<=tol*abs(e)


def independent_check(pid: str, raw: str, actual: str) -> bool:
    try:data=validate(pid,raw)
    except (ValueError,KeyError):return False
    expected=_oracle(pid,data)
    if pid=="abc375_b":return _float_ok(actual,expected)
    return actual==expected


def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    try:validate(pid,raw)
    except ValueError:return False
    exp=expected.removesuffix('\n');out=stdout.removesuffix('\n')
    if pid=="abc375_b":return independent_check(pid,raw,exp) and independent_check(pid,raw,out) and _float_ok(out,exp)
    return out==exp and independent_check(pid,raw,exp)


def _make_cases(pid:str)->list[dict[str,str]]:
    raws=[]
    if pid=="abc375_b":
        pts_cases=[[(1,0)],[(0,1)],[(-1,0)],[(3,4)],[(1,1),(2,2)],[(1,2),(-1,0)],[(0,0)],[(10**9,0)],[(-10**9,-10**9)],[(5,0),(5,5),(0,5)],[(1,0),(0,1),(-1,0),(0,-1)],[(100,-100),(-100,100)],[(2,3),(2,3),(2,3)],[(999999999,-999999999),(0,0)],[(1,2),(3,5),(8,13)],[(100000,-100000),(-100000,100000)],[(7,24),(-7,-24)]]
        for pts in pts_cases:raws.append(str(len(pts))+'\n'+'\n'.join(f'{x} {y}' for x,y in pts)+'\n')
        pts=['1000000000 1000000000']*200000;raws.append('200000\n'+'\n'.join(pts)+'\n')
    elif pid=="abc376_b":
        vals=[]
        for k in range(17):
            n=3+(k%12);q=1+(k%8);left,right=1,2;rows=[]
            for i in range(q):
                h='L' if (i+k)%2==0 else 'R';other=right if h=='L' else left
                t=1+((k*3+i*5)%n)
                if t==other:t=t%n+1
                rows.append((h,t));
                if h=='L':left=t
                else:right=t
            vals.append((n,rows))
        n=100;left,right=1,2;rows=[]
        for i in range(100):
            h='L' if i%2==0 else 'R';other=right if h=='L' else left;t=1+((i*37+50)%100)
            if t==other:t=t%100+1
            rows.append((h,t));
            if h=='L':left=t
            else:right=t
        vals.append((n,rows));raws=[f'{n} {len(rows)}\n'+'\n'.join(f'{h} {t}' for h,t in rows)+'\n' for n,rows in vals]
    elif pid=="abc377_b":
        grids=[]
        for k in range(17):
            g=[['.']*8 for _ in range(8)]
            for z in range(k):g[z//8][z%8]='#'
            grids.append(tuple(''.join(r) for r in g))
        grids.append(tuple('#'*8 for _ in range(8)));raws=['\n'.join(g)+'\n' for g in grids]
    elif pid=="abc378_b":
        vals=[]
        for k in range(17):
            n=1+(k%8);sched=[(2+i+k,(i+k)%(2+i+k)) for i in range(n)];q=1+(k%9);queries=[(1+(i*3+k)%n,1+((i*17+k*11)%200)) for i in range(q)];vals.append((sched,queries))
        sched=[(10**9-i, (123456789+i)%(10**9-i)) for i in range(100)];queries=[(1+i%100,10**9-i) for i in range(100)];vals.append((sched,queries))
        raws=[str(len(s))+'\n'+'\n'.join(f'{q} {r}' for q,r in s)+'\n'+str(len(z))+'\n'+'\n'.join(f'{t} {d}' for t,d in z)+'\n' for s,z in vals]
    elif pid=="abc379_b":
        vals=[(1,1,'O'),(1,1,'X'),(3,1,'OOO'),(3,2,'OOO'),(4,2,'OOOO'),(5,2,'OOXOO'),(7,3,'OOXOOOO'),(8,3,'OOOOOOOO'),(10,4,'OOOOXOOOOO'),(10,2,'OXOXOXOXOX'),(12,2,'OXXOOOXOOOOX'),(20,5,'O'*20),(20,6,'O'*20),(19,3,'OOOXXXOOOXXXOOOXXOO'),(50,7,'O'*30+'X'*20),(99,10,'O'*99),(100,1,'OX'*50),(100,100,'O'*100)]
        raws=[f'{n} {k}\n{s}\n' for n,k,s in vals]
    elif pid=="abc380_b":
        arrs=[[1],[2],[10],[1,1],[3,1,4,1,5],[1,1,1,6],[5,5],[2,3,4],[9,8,7],[1]*10,[2]*20,[50],[1,20,1],[10,10,10],[3,30,3],[24,24,24],[1]*49,[98]]
        raws=['|'+'|'.join('-'*x for x in a)+'|\n' for a in arrs]
    elif pid=="abc381_b":
        vals=['a','aa','ab','aabb','abba','aabbcc','aab','zzzzzz','aabbccdd','aabbccddee','abcdefghijklmnopqrstuvwxyz','aabbccddeeffgghhiijjkkllmm','aaaabb','xxyyzz','a'*99,'a'*98+'bb',''.join(c*2 for c in 'abcdefghijklmnopqrstuvwxy'),'a'*100]
        raws=[s+'\n' for s in vals]
    elif pid=="abc382_b":
        vals=[]
        for k in range(17):
            n=1+(k%20);s=['.' if (i+k)%3==0 else '@' for i in range(n)]
            if '@' not in s:s[0]='@'
            d=1+((k*5)%s.count('@'));vals.append((n,d,''.join(s)))
        vals.append((100,100,'@'*100));raws=[f'{n} {d}\n{s}\n' for n,d,s in vals]
    elif pid=="abc383_b":
        vals=[]
        for k in range(17):
            h=w=10;d=k;g=tuple('.'*10 for _ in range(10));vals.append((h,w,d,g))
        vals.append((10,10,18,tuple('.'*10 for _ in range(10))));raws=[f'{h} {w} {d}\n'+'\n'.join(g)+'\n' for h,w,d,g in vals]
    elif pid=="abc384_b":
        vals=[]
        for k in range(17):
            n=1+(k%12);r=(k*257)%4230;rows=[(1+(i+k)%2,((i*137+k*53)%2001)-1000) for i in range(n)];vals.append((n,r,rows))
        vals.append((100,4229,[(1 if i%2==0 else 2,1000 if i%3 else -1000) for i in range(100)]));raws=[f'{n} {r}\n'+'\n'.join(f'{d} {a}' for d,a in rows)+'\n' for n,r,rows in vals]
    elif pid=="abc385_b":
        vals=[]
        for k in range(17):
            h=3+(k%5);w=3+((k*2)%5);x=2;y=2;g=[['#']*w for _ in range(h)]
            for i in range(1,h-1):
                for j in range(1,w-1):g[i][j]='@' if (i+j+k)%5==0 else '.'
            g[x-1][y-1]='.';t=('UDLR'*(1+k%10))[:1+(k%30)];vals.append((h,w,x,y,tuple(''.join(r) for r in g),t))
        h=w=100;x=y=50;g=['#'*100]+['#'+'.'*98+'#' for _ in range(98)]+['#'*100];t='UDLR'*2500;vals.append((h,w,x,y,tuple(g),t));raws=[f'{h} {w} {x} {y}\n'+'\n'.join(g)+'\n'+t+'\n' for h,w,x,y,g,t in vals]
    elif pid=="abc386_b":
        vals=['1','10','100','1000','10000','1010','1100','200200','32000','998244353','1000000007','909090','111111','100100100','7000007','123450000','9'*999,'1'+'0'*999];raws=[s+'\n' for s in vals]
    elif pid=="abc387_b":
        vals=[1,2,3,4,5,6,7,8,9,10,11,12,16,24,36,49,64,81];raws=[f'{x}\n' for x in vals]
    elif pid=="abc388_b":
        vals=[]
        for k in range(17):
            n=1+(k%10);d=1+(k%10);rows=[(1+((i*7+k)%100),1+((i*11+2*k)%100)) for i in range(n)];vals.append((n,d,rows))
        vals.append((100,100,[(100,100)]*100));raws=[f'{n} {d}\n'+'\n'.join(f'{t} {l}' for t,l in rows)+'\n' for n,d,rows in vals]
    elif pid=="abc389_b":
        vals=[math.factorial(n) for n in range(2,19)]
        vals.append(math.factorial(20));raws=[f'{x}\n' for x in vals]
    elif pid=="abc390_b":
        vals=[(2,[1,1]),(2,[10,8]),(3,[1,2,4]),(3,[1,2,3]),(4,[3,6,12,24]),(4,[8,4,2,1]),(5,[3,6,12,24,48]),(5,[1,1,1,1,1]),(5,[16,8,4,2,1]),(6,[1,3,9,27,81,243]),(6,[2,4,8,16,32,65]),(3,[10**9,10**9,10**9]),(4,[1000000000,500000000,250000000,125000000]),(7,[1,2,4,8,16,32,64]),(8,[6561,2187,729,243,81,27,9,3]),(20,[1]*20),(99,[7]*99),(100,[10**9]*100)];raws=[f'{n}\n'+' '.join(map(str,a))+'\n' for n,a in vals]
    elif pid=="abc391_b":
        vals=[]
        for k in range(8):
            n=3+k;m=1;s=[['.' for _ in range(n)] for _ in range(n)];a=(2*k+1)%n;b=(3*k+1)%n;s[a][b]='#';ss=tuple(''.join(r) for r in s);vals.append((n,m,ss,('#',)))
        for n in range(11,20):
            s=tuple((''.join('#' if (i+j)%3==0 else '.' for j in range(n))) for i in range(n));vals.append((n,n,s,s))
        n=50;s=tuple(('#.'*25 if i%2==0 else '.#'*25) for i in range(50));vals.append((n,n,s,s));raws=[f'{n} {m}\n'+'\n'.join(s)+'\n'+'\n'.join(t)+'\n' for n,m,s,t in vals]
    elif pid=="abc392_b":
        vals=[]
        for k in range(17):
            n=2+(k%30);m=1+(k%n);a=list(range(1,n+1));a=a[k%n:]+a[:k%n];a=a[:m];vals.append((n,m,a))
        vals.append((1000,1000,list(range(1,1001))));raws=[f'{n} {m}\n'+' '.join(map(str,a))+'\n' for n,m,a in vals]
    else:raise KeyError(pid)
    if len(raws)!=18 or len(set(raws))!=18:raise ValueError(f'{pid}: generator did not produce 18 distinct ({len(raws)}/{len(set(raws))})')
    return [{'category':('constraint_max' if i==17 else f'case_{i+1:02d}'),'input':r} for i,r in enumerate(raws)]


def generate(pid:str)->list[dict[str,str]]:return _make_cases(pid)

REFERENCE_CODE = {
"abc375_b":'''import math\nN=int(input());p=(0,0);ans=0.0\nfor _ in range(N):\n q=tuple(map(int,input().split()));ans+=math.hypot(q[0]-p[0],q[1]-p[1]);p=q\nans+=math.hypot(p[0],p[1]);print(ans)\n''',
"abc376_b":'''N,Q=map(int,input().split());pos={'L':1,'R':2};ans=0\ndef dist(a,b,block):\n best=10**9\n for step in (-1,1):\n  x=a;d=0\n  while True:\n   if x==b:best=min(best,d);break\n   x=(x-1+step)%N+1;d+=1\n   if x==block:break\n return best\nfor _ in range(Q):\n h,t=input().split();t=int(t);o='R' if h=='L' else 'L';ans+=dist(pos[h],t,pos[o]);pos[h]=t\nprint(ans)\n''',
"abc377_b":'''S=[input() for _ in range(8)];rows={i for i in range(8) if '#' in S[i]};cols={j for j in range(8) if any(S[i][j]=='#' for i in range(8))};print((8-len(rows))*(8-len(cols)))\n''',
"abc378_b":'''N=int(input());qr=[tuple(map(int,input().split())) for _ in range(N)];Q=int(input())\nfor _ in range(Q):\n t,d=map(int,input().split());q,r=qr[t-1];m=d%q;print(d+(r-m)%q)\n''',
"abc379_b":'''N,K=map(int,input().split());S=input();run=ans=0\nfor c in S:\n if c=='O':\n  run+=1\n  if run==K:ans+=1;run=0\n else:run=0\nprint(ans)\n''',
"abc380_b":'''S=input();print(*[len(x) for x in S.split('|')[1:-1]])\n''',
"abc381_b":'''from collections import Counter\nS=input();print('Yes' if len(S)%2==0 and all(S[i]==S[i+1] for i in range(0,len(S),2)) and all(v==2 for v in Counter(S).values()) else 'No')\n''',
"abc382_b":'''N,D=map(int,input().split());S=list(input())\nfor i in range(N-1,-1,-1):\n if D and S[i]=='@':S[i]='.';D-=1\nprint(''.join(S))\n''',
"abc383_b":'''import itertools\nH,W,D=map(int,input().split());S=[input() for _ in range(H)];F=[(i,j) for i in range(H) for j in range(W) if S[i][j]=='.'];ans=0\nfor a,b in itertools.combinations(F,2):ans=max(ans,sum(min(abs(i-a[0])+abs(j-a[1]),abs(i-b[0])+abs(j-b[1]))<=D for i,j in F))\nprint(ans)\n''',
"abc384_b":'''N,R=map(int,input().split())\nfor _ in range(N):\n D,A=map(int,input().split())\n if (D==1 and 1600<=R<=2799) or (D==2 and 1200<=R<=2399):R+=A\nprint(R)\n''',
"abc385_b":'''H,W,X,Y=map(int,input().split());X-=1;Y-=1;S=[input() for _ in range(H)];T=input();seen=set();D={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}\nfor c in T:\n dx,dy=D[c];nx,ny=X+dx,Y+dy\n if S[nx][ny]!='#':X,Y=nx,ny\n if S[X][Y]=='@':seen.add((X,Y))\nprint(X+1,Y+1,len(seen))\n''',
"abc386_b":'''S=input();i=ans=0\nwhile i<len(S):\n if S.startswith('00',i):i+=2\n else:i+=1\n ans+=1\nprint(ans)\n''',
"abc387_b":'''X=int(input());print(sum(i*j for i in range(1,10) for j in range(1,10) if i*j!=X))\n''',
"abc388_b":'''N,D=map(int,input().split());A=[tuple(map(int,input().split())) for _ in range(N)]\nfor k in range(1,D+1):print(max(t*(l+k) for t,l in A))\n''',
"abc389_b":'''X=int(input());f=1;n=1\nwhile f<X:n+=1;f*=n\nprint(n)\n''',
"abc390_b":'''N=int(input());A=list(map(int,input().split()));print('Yes' if all(A[i]*A[i-2]==A[i-1]*A[i-1] for i in range(2,N)) else 'No')\n''',
"abc391_b":'''N,M=map(int,input().split());S=[input() for _ in range(N)];T=[input() for _ in range(M)]\nfor a in range(N-M+1):\n for b in range(N-M+1):\n  if all(S[a+i][b:b+M]==T[i] for i in range(M)):print(a+1,b+1);raise SystemExit\n''',
"abc392_b":'''N,M=map(int,input().split());A=set(map(int,input().split()));B=[i for i in range(1,N+1) if i not in A];print(len(B));print(*B)\n''',
}
