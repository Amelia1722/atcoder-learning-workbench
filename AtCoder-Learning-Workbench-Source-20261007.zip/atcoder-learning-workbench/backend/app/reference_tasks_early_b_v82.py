"""ABC104–106 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re
from math import isqrt

TASKS=('abc104_b','abc105_b','abc106_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
LETTERS=re.compile(r'[A-Za-z]+', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if len(lines)!=1: raise ValueError('line count')
    token=lines[0]
    if pid=='abc104_b':
        if LETTERS.fullmatch(token) is None or not 4<=len(token)<=10: raise ValueError('format/range')
        return token
    if POS.fullmatch(token) is None: raise ValueError('format')
    n=int(token)
    upper=100 if pid=='abc105_b' else 200
    if not 1<=n<=upper: raise ValueError('range')
    return n

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc104_b':
        if output not in ('AC','WA'): return False
        s=value
        allowed=[i for i in range(2,len(s)-1) if s[i]=='C']
        ok=s[0]=='A' and len(allowed)==1
        if ok:
            cpos=allowed[0]
            for i,ch in enumerate(s):
                if i in (0,cpos):
                    continue
                if not ('a'<=ch<='z'):
                    ok=False; break
        return output==('AC' if ok else 'WA')
    if pid=='abc105_b':
        if output not in ('Yes','No'): return False
        n=value
        ok=False
        for cakes in range(n//4+1):
            remain=n-4*cakes
            if remain%7==0:
                ok=True; break
        return output==('Yes' if ok else 'No')
    if re.fullmatch(r'(?:0|[1-9][0-9]*)',output,re.ASCII) is None: return False
    n=value
    ans=0
    for x in range(1,n+1,2):
        divisors=0
        for d in range(1,isqrt(x)+1):
            if x%d==0:
                divisors += 1 if d*d==x else 2
        if divisors==8:
            ans+=1
    return int(output)==ans

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc104_b':
        vals=['AtCoder','AaCaa','AaaCaa','ACoder','AcycliC','AtCoCo','Atcoder','aTCoder',
              'ATCoder','AtCoderX','ABCd','AabcdC','AabCdef','AabCDef','Aabccdef','AabCcdE',
              'AabCcccc']
        for s in vals:
            add('boundary' if len(s) in (4,10) else 'normal',s+'\n')
        add('constraint_max','AabCdefghi\n')
    elif pid=='abc105_b':
        vals=[1,3,4,7,8,10,11,12,13,14,15,17,18,20,23,40,99]
        for n in vals:
            add('boundary' if n in (1,3,4,7,99) else 'normal',f'{n}\n')
        add('constraint_max','100\n')
    else:
        vals=[1,7,104,105,106,134,135,136,164,165,166,188,189,190,194,195,199]
        for n in vals:
            add('boundary' if n in (1,7,104,105,106,199) else 'normal',f'{n}\n')
        add('constraint_max','200\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
