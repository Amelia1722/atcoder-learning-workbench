"""Official ABC181--186 C: strict constraints and separately derived oracles."""
from __future__ import annotations
from collections import defaultdict
from math import gcd
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(181,187))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Pair=tuple[int,int]
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'field count');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==181:
        n=ints(rows[0],1)[0];require(3<=n<=100 and len(rows)==n+1,'shape');points=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(len(set(points))==n and all(-1000<=x<=1000 and -1000<=y<=1000 for x,y in points),'distinct points');return (points,)
    if number==182:
        require(len(rows)==1 and re.fullmatch('[1-9]{1,18}',rows[0]) is not None,'nonzero digits');return (rows[0],)
    if number==183:
        n,k=ints(rows[0],2);require(2<=n<=8 and 1<=k<=10**9 and len(rows)==n+1,'shape');matrix=tuple(ints(row,n) for row in rows[1:]);require(all(matrix[i][i]==0 for i in range(n)) and all(1<=matrix[i][j]<=10**8 and matrix[i][j]==matrix[j][i] for i in range(n) for j in range(i+1,n)),'symmetric times');return k,matrix
    if number==184:
        require(len(rows)==2,'shape');a=ints(rows[0],2);b=ints(rows[1],2);require(all(1<=v<=10**9 for v in a+b),'coordinates');return a,b
    require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(12<=n<=200 if number==185 else 1<=n<=100000,'integer');return (n,)

def residue_max_length(text:str)->int:
    best=[-1]*3
    for char in text:
        digit=int(char);following=best.copy();following[digit%3]=max(following[digit%3],1)
        for remainder,length in enumerate(best):
            if length>=0:following[(remainder+digit)%3]=max(following[(remainder+digit)%3],length+1)
        best=following
    return -1 if best[0]<0 else len(text)-best[0]

def tour_count(k:int,matrix:tuple[tuple[int,...],...])->int:
    n=len(matrix);states={(1,0,0):1}
    for _ in range(n-1):
        following:dict[tuple[int,int,int],int]=defaultdict(int)
        for (mask,last,cost),count in states.items():
            for city in range(1,n):
                next_cost=cost+matrix[last][city]
                if not mask>>city&1 and next_cost<k:following[(mask|1<<city,city,next_cost)]+=count
        states=following
    return sum(count for (mask,last,cost),count in states.items() if cost+matrix[last][0]==k)

def one_move(a:Pair,b:Pair)->bool:return a[0]+a[1]==b[0]+b[1] or a[0]-a[1]==b[0]-b[1] or abs(a[0]-b[0])+abs(a[1]-b[1])<=3

def geometric_moves(a:Pair,b:Pair)->int:
    if a==b:return 0
    if one_move(a,b):return 1
    # Two diagonal families intersect at an integer grid point iff their parity agrees.
    for total,difference in ((a[0]+a[1],b[0]-b[1]),(b[0]+b[1],a[0]-a[1])):
        if (total+difference)%2==0:
            middle=((total+difference)//2,(total-difference)//2)
            if one_move(a,middle) and one_move(middle,b):return 2
    for dr in range(-3,4):
        for dc in range(-3,4):
            if abs(dr)+abs(dc)<=3 and one_move((a[0]+dr,a[1]+dc),b):return 2
    return 3

def positive_compositions(length:int)->int:
    dp=[1]+[0]*length
    for _ in range(12):
        following=[0]*(length+1);total=0
        for size in range(1,length+1):total+=dp[size-1];following[size]=total
        dp=following
    return dp[length]

def good_decimal_tree(n:int)->int:
    def octal_allowed(value:int)->bool:
        while value:
            if value%8==7:return False
            value//=8
        return True
    def visit(value:int)->int:
        if value>n:return 0
        total=int(value>0 and octal_allowed(value))
        for digit in range(10):
            if digit==7 or value==0 and digit==0:continue
            candidate=value*10+digit
            if candidate<=n:total+=visit(candidate)
        return total
    return visit(0)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==181:
        points=cast(tuple[Pair,...],data[0])
        for x,y in points:
            directions:set[Pair]=set()
            for a,b in points:
                dx=a-x;dy=b-y
                if dx==dy==0:continue
                divisor=gcd(abs(dx),abs(dy));dx//=divisor;dy//=divisor
                if dx<0 or dx==0 and dy<0:dx=-dx;dy=-dy
                if (dx,dy) in directions:return 'Yes'
                directions.add((dx,dy))
        return 'No'
    if number==182:return str(residue_max_length(cast(str,data[0])))
    if number==183:return str(tour_count(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
    if number==184:return str(geometric_moves(*cast(tuple[Pair,Pair],data)))
    if number==185:return str(positive_compositions(cast(int,data[0])))
    return str(good_decimal_tree(cast(int,data[0])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc181_c':"from itertools import combinations\nn=int(input());p=[tuple(map(int,input().split())) for _ in range(n)];print('Yes' if any((b[0]-a[0])*(c[1]-a[1])==(c[0]-a[0])*(b[1]-a[1]) for a,b,c in combinations(p,3)) else 'No')\n",
'abc182_c':"from collections import Counter\ns=input();count=Counter(int(c)%3 for c in s);r=sum(map(int,s))%3;answer=-1\nif r==0:answer=0\nelif count[r]>0 and len(s)>1:answer=1\nelif count[3-r]>=2 and len(s)>2:answer=2\nprint(answer)\n",
'abc183_c':"from itertools import permutations\nn,k=map(int,input().split());t=[list(map(int,input().split())) for _ in range(n)];answer=0\nfor p in permutations(range(1,n)):\n route=(0,)+p+(0,);answer+=sum(t[a][b] for a,b in zip(route,route[1:]))==k\nprint(answer)\n",
'abc184_c':"r,c=map(int,input().split());s,t=map(int,input().split());a=s-r;b=t-c\nif a==b==0:answer=0\nelif abs(a)==abs(b) or abs(a)+abs(b)<=3:answer=1\nelif (a+b)%2==0 or abs(a+b)<=3 or abs(a-b)<=3 or abs(a)+abs(b)<=6:answer=2\nelse:answer=3\nprint(answer)\n",
'abc185_c':"from math import comb\nprint(comb(int(input())-1,11))\n",
'abc186_c':"n=int(input());print(sum('7' not in str(v) and '7' not in oct(v) for v in range(1,n+1)))\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16300+number);raws:list[str]=[]
    if number==181:
        def points(p:list[Pair])->str:return f'{len(p)}\n'+''.join(line(v) for v in p)
        raws=[points([(0,0),(0,1),(1,0)]),points([(-1,0),(0,0),(1,0)]),points([(0,-1),(0,0),(0,1)]),points([(0,0),(1,1),(2,2)])]+[points(rng.sample([(x,y) for x in range(-10,11) for y in range(-10,11)],n)) for n in range(4,16)]+[points([(x,x*x%101) for x in range(100)]),points([(1000,-1000+20*j) for j in range(99)]+[(1000,1000)])]
    elif number==182:raws=[s+'\n' for s in ('1','2','3','9','11','22','12','35','111','112','122','123','2222','6227384','111111111111111111','111111111111111112','888888888888888888','999999999999999999')]
    elif number==183:
        def tour(k:int,matrix:list[list[int]])->str:return f'{len(matrix)} {k}\n'+''.join(line(row) for row in matrix)
        raws=[tour(1,[[0,1],[1,0]]),tour(2,[[0,1],[1,0]]),tour(200000000,[[0,10**8],[10**8,0]]),tour(3,[[0,1,1],[1,0,1],[1,1,0]])]
        for j in range(1,13):
            n=2+j%6;matrix=[[0]*n for _ in range(n)]
            for a in range(n):
                for b in range(a+1,n):matrix[a][b]=matrix[b][a]=rng.randrange(1,101)
            k=sum(matrix[i][(i+1)%n] for i in range(n))+(j%2);raws.append(tour(k,matrix))
        largest=[[0 if a==b else 10**8 for b in range(8)] for a in range(8)];raws+=[tour(800000000,largest),tour(1000000000,largest)]
    elif number==184:
        coordinates=[(1,1,1,1),(1,1,2,1),(1,1,4,1),(1,1,5,1),(1,1,7,1),(1,1,8,1),(1,1,5,6),(1,1,1,200001),(2,3,998244353,998244853),(100,100,97,100),(100,100,96,100),(100,100,95,100),(100,100,94,100),(1,10**9,10**9,1),(1,1,10**9,10**9-1),(10**9,1,1,10**9),(1,1,10**9,10**9),(10**9,10**9,10**9,10**9)];raws=[line([r,c])+line([s,t]) for r,c,s,t in coordinates]
    elif number==185:raws=[f'{n}\n' for n in (12,13,14,15,16,17,18,19,20,23,24,30,50,100,150,198,199,200)]
    else:raws=[f'{n}\n' for n in (1,2,6,7,8,14,15,16,17,20,63,64,70,77,100,77777,99999,100000)]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc181_c':('三つの点をすべて選んで、同一直線かを調べます。','割り算による傾き比較は避け、座標差の外積が0かを整数で判定します。','疑似コード: for distinct triples A,B,C: if (Bx-Ax)*(Cy-Ay)==(Cx-Ax)*(By-Ay): print(Yes); stop; print(No)。'),
'abc182_c':('3の倍数かどうかは、桁の合計の余りで決まります。','合計の余りrを消すには、余りrの桁を1つ、または余り3−rの桁を2つ消します。空の数にならないことを確認します。','疑似コード: r=sum(digits)%3; if r==0:0; elif count[r]>0 and len>1:1; elif count[3-r]>=2 and len>2:2; else:-1。'),
'abc183_c':('都市1以外を訪れる順番をすべて試せます。','都市1を経路の両端へ付け、すべての移動時間の総和がKなら数えます。','疑似コード: answer=0; for order in permutations(2..N): route=[1]+order+[1]; if sum(T[route[i]][route[i+1]])==K: answer+=1; print(answer)。'),
'abc184_c':('まず0手と1手で届く条件を調べます。','2手は同じマス色の斜め移動、斜め移動と近距離移動、近距離移動2回の場合です。残りは3手で届きます。','疑似コード: dr=r2-r1; dc=c2-c1; if both0:0; elif abs(dr)==abs(dc) or abs(dr)+abs(dc)<=3:1; elif (dr+dc)%2==0 or abs(dr+dc)<=3 or abs(dr-dc)<=3 or abs(dr)+abs(dc)<=6:2; else:3。'),
'abc185_c':('切断位置は、1からL−1までの整数位置です。','L−1個の候補から11箇所を選べば、12本すべてが正整数長になります。','疑似コード: print(combination(L-1,11))。'),
'abc186_c':('Nは10万以下なので、各整数をそのまま調べられます。','十進表記と八進表記のどちらにも7が含まれない数を数えます。','疑似コード: answer=count(v in1..N where 7 absent from decimal(v) and octal(v)); print(answer)。')}

TITLES={'abc181_c': 'Collinearity', 'abc182_c': 'To 3', 'abc183_c': 'Travel', 'abc184_c': 'Super Ryuma', 'abc185_c': 'Duodecim Ferra', 'abc186_c': 'Unlucky 7'}
PUBLISHED_SAMPLES={'abc181_c': [{'input': '4\n0 1\n0 2\n0 3\n1 1\n', 'expected': 'Yes\n'}, {'input': '14\n5 5\n0 1\n2 5\n8 0\n2 1\n0 0\n3 6\n8 6\n5 9\n7 9\n3 4\n9 2\n9 8\n7 2\n', 'expected': 'No\n'}, {'input': '9\n8 2\n2 3\n1 3\n3 7\n1 0\n8 8\n5 6\n9 7\n0 1\n', 'expected': 'Yes\n'}], 'abc182_c': [{'input': '35\n', 'expected': '1\n'}, {'input': '369\n', 'expected': '0\n'}, {'input': '6227384\n', 'expected': '1\n'}, {'input': '11\n', 'expected': '-1\n'}], 'abc183_c': [{'input': '4 330\n0 1 10 100\n1 0 20 200\n10 20 0 300\n100 200 300 0\n', 'expected': '2\n'}, {'input': '5 5\n0 1 1 1 1\n1 0 1 1 1\n1 1 0 1 1\n1 1 1 0 1\n1 1 1 1 0\n', 'expected': '24\n'}], 'abc184_c': [{'input': '1 1\n5 6\n', 'expected': '2\n'}, {'input': '1 1\n1 200001\n', 'expected': '2\n'}, {'input': '2 3\n998244353 998244853\n', 'expected': '3\n'}, {'input': '1 1\n1 1\n', 'expected': '0\n'}], 'abc185_c': [{'input': '12\n', 'expected': '1\n'}, {'input': '13\n', 'expected': '12\n'}, {'input': '17\n', 'expected': '4368\n'}], 'abc186_c': [{'input': '20\n', 'expected': '17\n'}, {'input': '100000\n', 'expected': '30555\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
