"""ABC035–037 B: manually reviewed specifications; independent task-specific oracles.

Official HTML originals are not archived or authenticated; ready is local verification only.
"""
from __future__ import annotations
import random
import re

TASKS = ('abc035_b','abc036_b','abc037_b')
POS = re.compile(r'[1-9][0-9]*',re.ASCII)
MOVE = re.compile(r'[LRUD?]+',re.ASCII)
ROW = re.compile(r'[ox]+',re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unsupported task or invalid line endings')
    lines=raw[:-1].split('\n')
    if pid == 'abc035_b':
        if len(lines)!=2 or not MOVE.fullmatch(lines[0]) or not 1<=len(lines[0])<=100000 or lines[1] not in ('1','2'):
            raise ValueError('invalid drone instructions')
        return lines[0], int(lines[1])
    if pid == 'abc036_b':
        if not lines or not POS.fullmatch(lines[0]):
            raise ValueError('invalid rotation size')
        n=int(lines[0])
        if not 1<=n<=50 or len(lines)!=n+1 or any(len(row)!=n or not ROW.fullmatch(row) for row in lines[1:]):
            raise ValueError('invalid rotation grid')
        return lines[1:]
    if not lines or len(lines[0].split(' '))!=2 or any(not POS.fullmatch(x) for x in lines[0].split(' ')):
        raise ValueError('invalid edit dimensions')
    n,q=map(int,lines[0].split(' '))
    if not 1<=n<=100 or not 1<=q<=100 or len(lines)!=q+1:
        raise ValueError('invalid edit query count')
    edits=[]
    for line in lines[1:]:
        fields=line.split(' ')
        if len(fields)!=3 or any(not POS.fullmatch(x) for x in fields):
            raise ValueError('invalid edit query')
        l,r,t=map(int,fields)
        if not 1<=l<=r<=n or not 1<=t<=10**9:
            raise ValueError('edit query out of range')
        edits.append((l,r,t))
    return n,edits


def independent_check(pid: str, raw: str, output: str) -> bool:
    try: data=validate(pid,raw)
    except (ValueError,TypeError):return False
    if not isinstance(output,str):return False
    if pid=='abc035_b':
        s,mode=data
        # Count opposite displacements independently of the reference's coordinate walk.
        d=abs(s.count('R')-s.count('L'))+abs(s.count('U')-s.count('D'))
        question=s.count('?')
        if mode==1: answer=d+question
        elif d>=question:answer=d-question
        else:answer=(question-d)%2
        return output==str(answer)
    if pid=='abc036_b':
        grid=data;n=len(grid)
        # Inverse map: original (r,c) appears at rotated (c,n-1-r).
        rotated=[['']*n for _ in range(n)]
        for r,row in enumerate(grid):
            for c,ch in enumerate(row):rotated[c][n-1-r]=ch
        return output=='\n'.join(''.join(row) for row in rotated)
    n,edits=data
    # Reverse chronology: first covering operation encountered wins per cell.
    values=[]
    for index in range(1,n+1):
        values.append(next((t for l,r,t in reversed(edits) if l<=index<=r),0))
    return output=='\n'.join(map(str,values))


def generate(pid: str, seed: int=59) -> list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unsupported task')
    rng=random.Random(f'abc-v59:{pid}:{seed}')
    rows=[];seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw);rows.append({'category':category,'input':raw})
    if pid=='abc035_b':
        presets=[('?',1),('?',2),('??',2),('???',2),('????',2),
            ('LR',2),('UD?',2),('UU?',2),('UU???',2),('L???',2),
            ('LRUD?????',2),('RRRRLL?',1),('RRRRLL?',2),
            ('U'*500+'D'*500+'?'*1000,2),('L'*10000+'?'*10000,2),
            ('?'*99999,2)]
        for s,t in presets:add('boundary' if '?' in s or len(s)>1000 else 'normal',f'{s}\n{t}\n')
        while len(rows)<17:
            s=''.join(rng.choices('LRUD?',k=rng.randint(1,2000)))
            add('random',f'{s}\n{rng.randint(1,2)}\n')
        add('constraint_max',f'{"?"*100000}\n2\n')
    elif pid=='abc036_b':
        presets=[['o'],['x'],['ox','xo'],['oo','xx'],['ox','xx'],
            ['xo','oo'],['ooo','xxx','ooo'],['oxo','xxx','oxo'],
            ['oxx','xox','xxo'],['ooo','ooo','ooo'],['xxx','xxx','xxx'],
            ['o'*4]*4,['x'*4]*4,
            [''.join('o' if j==i else 'x' for j in range(5)) for i in range(5)],
            [''.join('o' if j==0 else 'x' for j in range(6)) for i in range(6)],
            [''.join('o' if i==0 else 'x' for j in range(7)) for i in range(7)]]
        # 16 unique patterns above; deduplication handled by add().
        for grid in presets:add('boundary' if len(grid)==1 else 'normal',f'{len(grid)}\n'+'\n'.join(grid)+'\n')
        while len(rows)<17:
            n=rng.randint(2,49)
            grid=[''.join(rng.choices('ox',k=n)) for _ in range(n)]
            add('random',f'{n}\n'+'\n'.join(grid)+'\n')
        n=50;grid=[''.join('o' if (i*17+j*31)%7<3 else 'x' for j in range(n)) for i in range(n)]
        add('constraint_max',f'{n}\n'+'\n'.join(grid)+'\n')
    else:
        presets=[(1,[(1,1,1)]),(1,[(1,1,10**9)]),
          (2,[(1,1,3)]),(2,[(2,2,4)]),(2,[(1,2,1)]),
          (2,[(1,2,1),(1,2,2)]),(3,[(1,3,1),(2,2,4)]),
          (3,[(1,3,5),(1,1,6)]),(3,[(1,1,1),(3,3,2)]),
          (5,[(1,5,1),(2,4,2),(3,3,3)]),
          (5,[(1,3,10),(2,4,20)]),
          (10,[(1,10,1),(1,10,10**9)]),
          (100,[(1,100,1)]),(100,[(100,100,10**9)]),
          (100,[(1,100,10**9),(1,100,1)]),
          (100,[(i,i,i) for i in range(1,101)])]
        def fmt(n,edits):return f'{n} {len(edits)}\n'+''.join(f'{l} {r} {t}\n' for l,r,t in edits)
        for n,edits in presets:add('boundary' if n in (1,100) else 'normal',fmt(n,edits))
        while len(rows)<17:
            n=rng.randint(1,100);q=rng.randint(1,100)
            edits=[]
            for _ in range(q):
                l=rng.randint(1,n);r=rng.randint(l,n);t=rng.randint(1,10**9)
                edits.append((l,r,t))
            add('random',fmt(n,edits))
        add('constraint_max',fmt(100,[(1,100,10**9-i) for i in range(100)]))
    if len(rows)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: wanted 18 distinct cases, got {len(rows)}')
    return rows
