"""Independent energy ledgers, geometric unions and exact rational rankings."""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from itertools import accumulate
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(303,309))
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES:dict[str,str]={}
Point=tuple[int,int]
Grid=tuple[str,...]
Data=tuple[object,...]
Case=dict[str,str]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers')
    values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'fields');return values

def black(grid:Grid)->frozenset[Point]:
    return frozenset((r,c) for r,row in enumerate(grid) for c,ch in enumerate(row) if ch=='#')

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==303:
        n,m,h,k=ints(rows[0],4);require(all(1<=v<=200000 for v in (n,m,h,k)) and len(rows)==m+2,'shape')
        s=rows[1];points=tuple(ints(row,2) for row in rows[2:]);require(len(s)==n and set(s)<={'R','L','U','D'} and len(set(points))==m and all(abs(v)<=200000 for p in points for v in p),'moves/items');return h,k,s,points
    if number==304:
        n,d=ints(rows[0],2);require(1<=n<=2000 and 1<=d<=2000 and len(rows)==n+1,'shape');points=tuple(ints(row,2) for row in rows[1:]);require(len(set(points))==n and all(abs(v)<=1000 for p in points for v in p),'points');return d,points
    if number==305:
        h,w=ints(rows[0],2);require(2<=h<=500 and 2<=w<=500 and len(rows)==h+1,'shape');grid=tuple(rows[1:]);require(all(len(row)==w and set(row)<={'#','.'} for row in grid),'grid');points=black(grid);require(bool(points),'cookies')
        lo_r=min(r for r,c in points);hi_r=max(r for r,c in points);lo_c=min(c for r,c in points);hi_c=max(c for r,c in points)
        require(lo_r<hi_r and lo_c<hi_c and len(points)==(hi_r-lo_r+1)*(hi_c-lo_c+1)-1,'rectangle with one missing');return (grid,)
    if number==306:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=100000,'length');a=ints(rows[1],3*n);require(Counter(a)==dict.fromkeys(range(1,n+1),3),'three occurrences');return n,a
    if number==307:
        grids:list[Grid]=[];i=0
        for _ in range(3):
            require(i<len(rows),'sheet');h,w=ints(rows[i],2);require(1<=h<=10 and 1<=w<=10 and i+h<len(rows),'sheet size');grid=tuple(rows[i+1:i+h+1]);require(all(len(row)==w and set(row)<={'#','.'} for row in grid) and bool(black(grid)),'sheet pixels');grids.append(grid);i+=h+1
        require(i==len(rows),'extra rows');return tuple(grids)
    require(len(rows)>=3,'shape');n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==n+1,'length');a=tuple(ints(row,2) for row in rows[1:]);require(all(0<=u<=10**9 and 0<=v<=10**9 and u+v>=1 for u,v in a),'coin counts');return (a,)

def _energy_ledger(h:int,k:int,s:str,points:tuple[Point,...])->bool:
    xs=accumulate((1 if ch=='R' else -1 if ch=='L' else 0 for ch in s),initial=0)
    ys=accumulate((1 if ch=='U' else -1 if ch=='D' else 0 for ch in s),initial=0)
    available=set(points);energy=h
    for step,position in enumerate(zip(xs,ys)):
        if not step:continue
        if step>energy:return False
        if position in available and energy-step<k:
            available.remove(position);energy=step+k
    return True

def _infected(d:int,points:tuple[Point,...])->tuple[bool,...]:
    parent=list(range(len(points)));size=[1]*len(points)
    def find(i:int)->int:
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for i,(x,y) in enumerate(points):
        for j in range(i):
            u,v=points[j]
            if (x-u)**2+(y-v)**2>d*d:continue
            a,b=find(i),find(j)
            if a==b:continue
            if size[a]<size[b]:a,b=b,a
            parent[b]=a;size[a]+=size[b]
    root=find(0);return tuple(find(i)==root for i in range(len(points)))

def _placements(points:frozenset[Point],target:frozenset[Point])->frozenset[frozenset[Point]]:
    anchor=min(points);candidates=[]
    for r,c in target:
        shifted=frozenset((u+r-anchor[0],v+c-anchor[1]) for u,v in points)
        if shifted<=target:candidates.append(shifted)
    return frozenset(candidates)

def _sheet_union(a:Grid,b:Grid,x:Grid)->bool:
    ap,bp,target=black(a),black(b),black(x);bs=_placements(bp,target)
    if not bs:return False
    for placed in _placements(ap,target):
        missing=target-placed
        if not missing:return True
        anchor=min(missing)
        for u,v in bp:
            shifted=frozenset((r+anchor[0]-u,c+anchor[1]-v) for r,c in bp)
            if missing<=shifted<=target:return True
    return False

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==303:return 'Yes' if _energy_ledger(*cast(tuple[int,int,str,tuple[Point,...]],data)) else 'No'
    if number==304:
        d,points=cast(tuple[int,tuple[Point,...]],data);return '\n'.join('Yes' if yes else 'No' for yes in _infected(d,points))
    if number==305:
        points=black(cast(Grid,data[0]));lo_r=min(r for r,c in points);hi_r=max(r for r,c in points);lo_c=min(c for r,c in points);hi_c=max(c for r,c in points)
        r=(lo_r+hi_r)*(hi_r-lo_r+1)//2*(hi_c-lo_c+1)-sum(r for r,c in points)
        c=(lo_c+hi_c)*(hi_c-lo_c+1)//2*(hi_r-lo_r+1)-sum(c for r,c in points)
        return f'{r+1} {c+1}'
    if number==306:
        n,a=cast(tuple[int,tuple[int,...]],data);positions:list[list[int]]=[[] for _ in range(n+1)]
        for j,v in enumerate(a):positions[v].append(j)
        return ' '.join(map(str,sorted(range(1,n+1),key=lambda v:positions[v][1])))
    if number==307:return 'Yes' if _sheet_union(*cast(tuple[Grid,Grid,Grid],data)) else 'No'
    a=cast(tuple[Point,...],data[0]);return ' '.join(map(str,sorted(range(1,len(a)+1),key=lambda i:(-Fraction(a[i-1][0],sum(a[i-1])),i))))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc303_c':"n,m,h,k=map(int,input().split());s=input();items={tuple(map(int,input().split())) for _ in range(m)};x=y=0\nfor ch in s:\n x+=(ch=='R')-(ch=='L');y+=(ch=='U')-(ch=='D');h-=1\n if h<0:print('No');break\n if h<k and (x,y) in items:h=k;items.remove((x,y))\nelse:print('Yes')\n",
'abc304_c':"n,d=map(int,input().split());p=[tuple(map(int,input().split())) for _ in range(n)];seen=[False]*n;seen[0]=True;todo=[0]\nwhile todo:\n x,y=p[todo.pop()]\n for j,(u,v) in enumerate(p):\n  if not seen[j] and (x-u)**2+(y-v)**2<=d*d:seen[j]=True;todo.append(j)\nprint(*('Yes' if yes else 'No' for yes in seen),sep='\\n')\n",
'abc305_c':"h,w=map(int,input().split());s=[input() for _ in range(h)]\nfor r in range(h):\n for c in range(w):\n  if s[r][c]=='.' and sum(0<=r+dr<h and 0<=c+dc<w and s[r+dr][c+dc]=='#' for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)))>=2:print(r+1,c+1)\n",
'abc306_c':"n=int(input());a=list(map(int,input().split()));counts=[0]*(n+1);answer=[]\nfor v in a:\n counts[v]+=1\n if counts[v]==2:answer.append(v)\nprint(*answer)\n",
'abc307_c':"def read():\n h,w=map(int,input().split());s=[input() for _ in range(h)];return h,w,[(r,c) for r in range(h) for c in range(w) if s[r][c]=='#']\n_,_,a=read();_,_,b=read();h,w,x=read();target=sum(1<<(r*w+c) for r,c in x)\ndef masks(p):\n out=[]\n for dr in range(-9,10):\n  for dc in range(-9,10):\n   shifted=[(r+dr,c+dc) for r,c in p]\n   if all(0<=r<h and 0<=c<w for r,c in shifted):\n    mask=sum(1<<(r*w+c) for r,c in shifted)\n    if mask&target==mask:out.append(mask)\n return out\nprint('Yes' if any(am|bm==target for am in masks(a) for bm in masks(b)) else 'No')\n",
'abc308_c':"from functools import cmp_to_key\nn=int(input());a=[tuple(map(int,input().split())) for _ in range(n)]\ndef compare(i,j):\n x,y=a[i];u,v=a[j];delta=x*(u+v)-u*(x+y);return -1 if delta>0 else 1 if delta<0 else i-j\nprint(*(i+1 for i in sorted(range(n),key=cmp_to_key(compare))))\n"}

def line(values:tuple[int,...]|list[int])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16900+number)
    if number==303:
        def moves(s:str,h:int,k:int,p:list[Point])->str:return f'{len(s)} {len(p)} {h} {k}\n{s}\n'+''.join(line(v) for v in p)
        raws=[moves('R',1,1,[(0,0)]),moves('RR',1,1,[(1,0)]),moves('RR',1,1,[(2,0)]),moves('RLRLR',1,1,[(1,0),(0,0)])]
        for n in range(3,15):raws.append(moves(''.join(rng.choice('RLUD') for _ in range(n)),rng.randint(1,n),rng.randint(1,n),rng.sample([(r,c) for r in range(-3,4) for c in range(-3,4)],5)))
        raws.extend([moves('RL'*100000,1,200000,[(1,0)]+[(r,1) for r in range(199999)]),moves('R'*200000,200000,200000,[(r,0) for r in range(1,200001)])])
    elif number==304:
        def points(p:list[Point],d:int)->str:return f'{len(p)} {d}\n'+''.join(line(v) for v in p)
        raws=[points([(0,0)],1),points([(0,0),(1,0)],1),points([(0,0),(1,1)],1),points([(0,0),(3,4)],5)]
        for n in range(3,15):raws.append(points(rng.sample([(r,c) for r in range(-10,11) for c in range(-10,11)],n),rng.randint(1,10)))
        raws.extend([points([(i-1000,0) for i in range(2000)],1),points([(i-1000,-1000) for i in range(2000)],2000)])
    elif number==305:
        def cookies(h:int,w:int,a:int,b:int,c:int,d:int,hole:Point)->str:
            return f'{h} {w}\n'+''.join(''.join('#' if a<=r<=b and c<=j<=d and (r,j)!=hole else '.' for j in range(w))+'\n' for r in range(h))
        raws=[cookies(2,2,0,1,0,1,(0,0)),cookies(2,2,0,1,0,1,(0,1)),cookies(2,2,0,1,0,1,(1,0)),cookies(2,2,0,1,0,1,(1,1))]
        for n in range(3,15):raws.append(cookies(n,n+1,0,n-1,1,n,(rng.randrange(n),rng.randint(1,n))))
        raws.extend([cookies(500,500,0,499,0,499,(250,250)),cookies(500,500,0,499,0,499,(499,499))])
    elif number==306:
        def sequence(a:list[int])->str:return f'{len(a)//3}\n'+line(a)
        raws=[sequence(a) for a in ([1,1,1],[1,1,1,2,2,2],[2,1,2,1,2,1],[1,2,2,1,1,2])]
        for n in range(3,15):
            a=list(range(1,n+1))*3;rng.shuffle(a);raws.append(sequence(a))
        a=list(range(1,100001))*3;rng.shuffle(a);raws.extend([sequence(a),sequence(list(range(100000,0,-1))*3)])
    elif number==307:
        def sheets(a:list[str],b:list[str],x:list[str])->str:return ''.join(f'{len(grid)} {len(grid[0])}\n'+'\n'.join(grid)+'\n' for grid in (a,b,x))
        raws=[sheets(['#'],['#'],['#']),sheets(['#'],['#'],['##']),sheets(['##'],['#'],['#']),sheets(['#.','.#'],['#.','.#'],['##','##'])]
        for j in range(12):
            a=[''.join(rng.choice('.#') for _ in range(3)) for _ in range(3)];b=[''.join(rng.choice('.#') for _ in range(3)) for _ in range(3)];a[0]='#'+a[0][1:];b[0]='#'+b[0][1:]
            x=[''.join('#' if a[r][c]=='#' or b[r][c]=='#' else '.' for c in range(3)) for r in range(3)] if j%2 else ['#..','.#.','..#'];raws.append(sheets(a,b,x))
        raws.extend([sheets(['#'+'..'*4+'.']+['.'*10]*9,['#'+'..'*4+'.']+['.'*10]*9,['#'*10]*10),sheets(['#'*10]*10,['#'*10]*10,['#'*10]*10)])
    else:
        def coins(a:list[Point])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[coins([(0,1),(0,1)]),coins([(1,0),(0,1)]),coins([(1,3),(2,6)]),coins([(999999999,10**9),(10**9,999999999)])]
        for n in range(3,15):raws.append(coins([(rng.randint(0,100),rng.randint(1,100)) for _ in range(n)]))
        raws.extend([coins([(rng.randrange(10**9+1),rng.randint(1,10**9)) for _ in range(200000)]),coins([(10**9,10**9)]*200000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<4 or i==16 else 'deterministic_random'} for i,raw in enumerate(raws)]

HINTS={
'abc303_c':('移動後に体力が負になったら失敗です。','移動と体力減少の後、体力がK未満なら現在地のアイテムを一度だけ消費します。','疑似コード: 各移動で座標更新; H--; H<0ならNo; H<Kかつ現在地にitemがあればH=Kとしてitem削除; 最後まで進めばYes。'),
'abc304_c':('感染は距離D以内の辺をたどって広がります。','人1からBFSまたはDFSし、距離の二乗で接続を判定します。','疑似コード: seen[1]=true; queue=[1]; 各取り出したiから未訪問jを走査; 距離二乗<=D²ならseen[j]=true,queue追加; 各seenをYes/Noで出力。'),
'abc305_c':('欠けたマスには上下左右のうち少なくとも2方向にクッキーが残ります。','全ての.を調べ、4近傍にある#の数が2以上のマスを探します。元の長方形の外側では1方向以下です。','疑似コード: 各.マスで上下左右の範囲内の#を数える; count>=2なら1始まりrow,columnを出力。'),
'abc306_c':('2回目に出現する順番がそのまま答えになります。','左から出現回数を数え、2になった値を答えに追加します。','疑似コード: countを0で初期化; 各A[i]でcount[A[i]]++; 2回目ならanswerに追加; answerを出力。'),
'abc307_c':('黒マスは全てX内に入り、重ねた和集合がXと一致する必要があります。','AとBの平行移動を列挙します。透明な外周がXの外にはみ出しても構いません。','疑似コード: AとBの黒マスを集合へ; 各移動量でX内の黒集合候補を作る; 2候補のunion==XならYes; 無ければNo。'),
'abc308_c':('小数にせず分数の大小を比較します。','Ai/(Ai+Bi)とAj/(Aj+Bj)は交差積で比較でき、同じなら番号の昇順です。','疑似コード: i,jの比較はAi*(Aj+Bj)とAj*(Ai+Bi); 大きい側を先にし等しければ番号順; sortして番号を出力。')}

TITLES={'abc303_c': 'Dash', 'abc304_c': 'Virus', 'abc305_c': 'Snuke the Cookie Picker', 'abc306_c': 'Centers', 'abc307_c': 'Ideal Sheet', 'abc308_c': 'Standings'}
PUBLISHED_SAMPLES={'abc303_c': [{'input': '4 2 3 1\nRUDL\n-1 -1\n1 0\n', 'expected': 'Yes\n'}, {'input': '5 2 1 5\nLDRLD\n0 0\n-1 -1\n', 'expected': 'No\n'}], 'abc304_c': [{'input': '4 5\n2 -1\n3 1\n8 8\n0 5\n', 'expected': 'Yes\nYes\nNo\nYes\n'}, {'input': '3 1\n0 0\n-1000 -1000\n1000 1000\n', 'expected': 'Yes\nNo\nNo\n'}, {'input': '9 4\n3 2\n6 -1\n1 6\n6 5\n-2 -3\n5 3\n2 -3\n2 1\n2 6\n', 'expected': 'Yes\nNo\nNo\nYes\nYes\nYes\nYes\nYes\nNo\n'}], 'abc305_c': [{'input': '5 6\n......\n..#.#.\n..###.\n..###.\n......\n', 'expected': '2 4\n'}, {'input': '3 2\n#.\n##\n##\n', 'expected': '1 2\n'}, {'input': '6 6\n..####\n..##.#\n..####\n..####\n..####\n......\n', 'expected': '2 5\n'}], 'abc306_c': [{'input': '3\n1 1 3 2 3 2 2 3 1\n', 'expected': '1 3 2\n'}, {'input': '1\n1 1 1\n', 'expected': '1\n'}, {'input': '4\n2 3 4 3 4 1 3 1 1 4 2 2\n', 'expected': '3 4 1 2\n'}], 'abc307_c': [{'input': '3 5\n#.#..\n.....\n.#...\n2 2\n#.\n.#\n5 3\n...\n#.#\n.#.\n.#.\n...\n', 'expected': 'Yes\n'}, {'input': '2 2\n#.\n.#\n2 2\n#.\n.#\n2 2\n##\n##\n', 'expected': 'No\n'}, {'input': '1 1\n#\n1 2\n##\n1 1\n#\n', 'expected': 'No\n'}, {'input': '3 3\n###\n...\n...\n3 3\n#..\n#..\n#..\n3 3\n..#\n..#\n###\n', 'expected': 'Yes\n'}], 'abc308_c': [{'input': '3\n1 3\n3 1\n2 2\n', 'expected': '2 3 1\n'}, {'input': '2\n1 3\n2 6\n', 'expected': '1 2\n'}, {'input': '4\n999999999 1000000000\n333333333 999999999\n1000000000 999999997\n999999998 1000000000\n', 'expected': '3 1 4 2\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
