"""Reviewed C tasks: occupied Sudoku constraints, adjacency ranks and square staircase."""
from __future__ import annotations
from bisect import bisect_left
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(327,333))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Matrix=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==327:
        require(len(rows)==9,'shape');a=tuple(ints(row,9) for row in rows);require(all(1<=v<=9 for row in a for v in row),'digits');return (a,)
    if number==328:
        n,q=ints(rows[0],2);require(1<=n<=300000 and 1<=q<=300000 and len(rows)==q+2 and len(rows[1])==n and re.fullmatch('[a-z]+',rows[1]) is not None,'shape');queries=tuple(ints(row,2) for row in rows[2:]);require(all(1<=l<=r<=n for l,r in queries),'interval');return rows[1],queries
    if number==329:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows[1])==n and re.fullmatch('[a-z]+',rows[1]) is not None,'string');return (rows[1],)
    if number==330:
        require(len(rows)==1,'shape');d=ints(rows[0],1)[0];require(1<=d<=2*10**12,'number');return (d,)
    if number==331:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000,'length');a=ints(rows[1],n);require(all(1<=v<=10**6 for v in a),'values');return (a,)
    require(len(rows)==2,'shape');n,m=ints(rows[0],2);s=rows[1];require(1<=m<=n<=1000 and len(s)==n and set(s)<={'0','1','2'},'shirts');return m,s

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==327:
        a=cast(Matrix,data[0]);occupied=[0]*27
        for r,row in enumerate(a):
            for c,value in enumerate(row):
                bit=1<<(value-1)
                for unit in (r,9+c,18+3*(r//3)+c//3):
                    if occupied[unit]&bit:return 'No'
                    occupied[unit]|=bit
        return 'Yes'
    if number==328:
        s,queries=cast(tuple[str,tuple[tuple[int,int],...]],data);positions=[j for j,(a,b) in enumerate(zip(s,s[1:]),1) if a==b];return '\n'.join(str(bisect_left(positions,r)-bisect_left(positions,l)) for l,r in queries)
    if number==329:
        s=cast(str,data[0]);answer=0
        for letter in set(s):
            low=1;high=len(s)+1
            while high-low>1:
                middle=(low+high)//2
                if letter*middle in s:low=middle
                else:high=middle
            answer+=low
        return str(answer)
    if number==330:
        from math import isqrt
        d=cast(int,data[0]);x=0;y=isqrt(d)+1;answer=d
        while x<=y:
            difference=x*x+y*y-d;answer=min(answer,abs(difference))
            if answer==0:return '0'
            if difference>0:y-=1
            else:x+=1
        return str(answer)
    if number==331:
        a=cast(tuple[int,...],data[0]);largest=max(a);weighted=[0]*(largest+2)
        for v in a:weighted[v]+=v
        for j in range(largest-1,0,-1):weighted[j]+=weighted[j+1]
        return ' '.join(str(weighted[v+1]) for v in a)
    m,s=cast(tuple[int,str],data);segments=[(len(segment),segment.count('2')) for segment in s.split('0')];low=-1;high=len(s)
    while high-low>1:
        middle=(low+high)//2
        if all(twos<=middle and total<=m+middle for total,twos in segments):high=middle
        else:low=middle
    return str(high)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc327_c':"a=[list(map(int,input().split())) for _ in range(9)];groups=a+[list(row) for row in zip(*a)]+[[a[r+i][c+j] for i in range(3) for j in range(3)] for r in (0,3,6) for c in (0,3,6)];print('Yes' if all(set(group)==set(range(1,10)) for group in groups) else 'No')\n",
'abc328_c':"n,q=map(int,input().split());s=input();prefix=[0]*n\nfor j in range(1,n):prefix[j]=prefix[j-1]+(s[j]==s[j-1])\nfor _ in range(q):\n l,r=map(int,input().split());print(prefix[r-1]-prefix[l-1])\n",
'abc329_c':"from itertools import groupby\nn=int(input());s=input();longest={}\nfor char,group in groupby(s):longest[char]=max(longest.get(char,0),sum(1 for _ in group))\nprint(sum(longest.values()))\n",
'abc330_c':"from math import isqrt\nd=int(input());answer=d\nfor x in range(isqrt(d)+2):\n remainder=d-x*x\n if remainder<0:answer=min(answer,-remainder);continue\n y=isqrt(remainder);answer=min(answer,remainder-y*y,(y+1)**2-remainder)\n if answer==0:break\nprint(answer)\n",
'abc331_c':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));counts=Counter(a);answer={};total=0\nfor v in sorted(counts,reverse=True):answer[v]=total;total+=v*counts[v]\nprint(*(answer[v] for v in a))\n",
'abc332_c':"n,m=map(int,input().split());s=input();plain=m;logo=owned=0\nfor char in s:\n if char=='0':plain=m;logo=owned\n elif char=='1' and plain>0:plain-=1\n else:\n  if logo==0:owned+=1\n  else:logo-=1\nprint(owned)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17000+number)
    if number==327:
        def grid(a:list[list[int]])->str:return ''.join(line(row) for row in a)
        valid=[[(r*3+r//3+c)%9+1 for c in range(9)] for r in range(9)];raws=[grid([[1]*9]*9),grid(valid),grid([[(r+c)%9+1 for c in range(9)] for r in range(9)]),grid([row[:] for row in valid[::-1]])]
        for j in range(12):
            a=[row[:] for row in valid];r,c=divmod(j,9);a[r][c]=a[r][(c+1)%9];raws.append(grid(a))
        raws.extend([grid([[rng.randint(1,9) for _ in range(9)] for _ in range(9)]),grid([[9]*9]*9)])
    elif number==328:
        def queries(s:str,qs:list[tuple[int,int]])->str:return f'{len(s)} {len(qs)}\n{s}\n'+''.join(line(q) for q in qs)
        raws=[queries('a',[(1,1)]),queries('aa',[(1,2),(2,2)]),queries('ab',[(1,2)]),queries('aaa',[(1,3),(2,3)])];raws.extend(queries(''.join(rng.choice('abc') for _ in range(n)),[tuple(sorted((rng.randint(1,n),rng.randint(1,n)))) for _ in range(n+2)]) for n in range(3,15));raws.extend([queries('ab'*150000,[(1,300000)]*300000),queries('z'*300000,[(j+1,300000) for j in range(300000)])])
    elif number==329:
        def word(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[word(s) for s in ('a','aa','ab','aba')];raws.extend(word(''.join(rng.choice('abc') for _ in range(n))) for n in range(4,16));raws.extend([word('abcdefghijklmnopqrstuvwxyz'*7692+'abcdefgh'),word('z'*200000)])
    elif number==330:raws=[f'{d}\n' for d in (1,2,3,4,5,7,10,21,27,99,1234,99991,10**6-1,10**8+3,10**10+7,10**11+19,2*10**12-1,2*10**12)]
    elif number==331:
        def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[array(a) for a in ([1],[1,1],[1,2],[3,1,3])];raws.extend(array([rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([array(list(range(1,200001))),array([10**6]*200000)])
    else:
        def shirts(s:str,m:int)->str:return f'{len(s)} {m}\n{s}\n'
        raws=[shirts('0',1),shirts('1',1),shirts('2',1),shirts('112022',1)];raws.extend(shirts(''.join(rng.choice('012') for _ in range(n)),rng.randint(1,n)) for n in range(3,15));raws.extend([shirts('12'*500,1),shirts('2'*1000,1000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc327_c':('行・列・3x3領域の3種類を全て調べます。','各9マスの値の集合が1から9と一致するか確認します。','疑似コード: 行9本、列9本、3x3領域9個を列挙; 全てset(values)=={1..9}ならYes、他はNo。'),
'abc328_c':('隣り合う文字が等しい箇所の累積数を持ちます。','部分文字列の答えは、両端までの累積数の差です。','疑似コード: prefix[0]=0; prefix[j]=prefix[j-1]+(S[j]==S[j-1]); 質問(l,r)へprefix[r-1]-prefix[l-1]を出力。'),
'abc329_c':('各文字について、連続する最大長だけが必要です。','長さLの連続区間から同じ文字だけの部分文字列を1からL文字まで作れます。','疑似コード: Sを同じ文字の連続区間へ分解; longest[ch]=max(longest[ch],区間長); sum(longest)を出力。'),
'abc330_c':('xを決めると、yは残りの平方根付近だけを調べればよいです。','0からfloor(sqrt(D))+1までxを試し、D-x^2の整数平方根とその次を確認します。','疑似コード: 各xでr=D-x^2; r>=0ならy=isqrt(r)とy+1で誤差更新; r<0ならy=0の誤差更新; 最小を出力。'),
'abc331_c':('値の大きい順にまとめて処理します。','同じ値への答えは、既に処理したより大きな値の総和です。','疑似コード: 値別の個数を数える; 値vを降順に走査しanswer[v]=total; total+=v*count[v]; 元の順番でanswerを出力。'),
'abc332_c':('食事の日は無地を優先して使えます。','清潔な無地とロゴ入りの残数を管理し、不足した時だけロゴ入りを追加購入します。休みの日に残数を戻します。','疑似コード: plain=M, logo=owned=0; 0ならplain=M,logo=owned; 1かつplain>0ならplain--; 他はlogo>0ならlogo--、なければowned++; ownedを出力。')}

TITLES={'abc327_c': 'Number Place', 'abc328_c': 'Consecutive', 'abc329_c': 'Count xxx', 'abc330_c': 'Minimize Abs 2', 'abc331_c': 'Sum of Numbers Greater Than Me', 'abc332_c': 'T-shirts'}
PUBLISHED_SAMPLES={'abc327_c': [{'input': '1 2 3 4 5 6 7 8 9\n4 5 6 7 8 9 1 2 3\n7 8 9 1 2 3 4 5 6\n2 3 4 5 6 7 8 9 1\n5 6 7 8 9 1 2 3 4\n8 9 1 2 3 4 5 6 7\n3 4 5 6 7 8 9 1 2\n6 7 8 9 1 2 3 4 5\n9 1 2 3 4 5 6 7 8\n', 'expected': 'Yes\n'}, {'input': '1 2 3 4 5 6 7 8 9\n2 3 4 5 6 7 8 9 1\n3 4 5 6 7 8 9 1 2\n4 5 6 7 8 9 1 2 3\n5 6 7 8 9 1 2 3 4\n6 7 8 9 1 2 3 4 5\n7 8 9 1 2 3 4 5 6\n8 9 1 2 3 4 5 6 7\n9 1 2 3 4 5 6 7 8\n', 'expected': 'No\n'}, {'input': '1 2 3 4 5 6 7 8 9\n4 5 6 7 8 9 1 2 3\n7 8 9 1 2 3 4 5 6\n1 2 3 4 5 6 7 8 9\n4 5 6 7 8 9 1 2 3\n7 8 9 1 2 3 4 5 6\n1 2 3 4 5 6 7 8 9\n4 5 6 7 8 9 1 2 3\n7 8 9 1 2 3 4 5 6\n', 'expected': 'No\n'}], 'abc328_c': [{'input': '11 4\nmississippi\n3 9\n4 10\n4 6\n7 7\n', 'expected': '2\n2\n0\n0\n'}, {'input': '5 1\naaaaa\n1 5\n', 'expected': '4\n'}], 'abc329_c': [{'input': '6\naaabaa\n', 'expected': '4\n'}, {'input': '1\nx\n', 'expected': '1\n'}, {'input': '12\nssskkyskkkky\n', 'expected': '8\n'}], 'abc330_c': [{'input': '21\n', 'expected': '1\n'}, {'input': '998244353\n', 'expected': '0\n'}, {'input': '264428617\n', 'expected': '32\n'}], 'abc331_c': [{'input': '5\n1 4 1 4 2\n', 'expected': '10 0 10 0 8\n'}, {'input': '10\n31 42 59 26 53 58 97 93 23 54\n', 'expected': '456 414 190 487 361 249 0 97 513 307\n'}, {'input': '50\n1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1\n', 'expected': '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n'}], 'abc332_c': [{'input': '6 1\n112022\n', 'expected': '2\n'}, {'input': '3 1\n222\n', 'expected': '3\n'}, {'input': '2 1\n01\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
