"""ABC152–154 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc152_b', 'abc153_b', 'abc154_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc152_b': [
        {'input':'4 3\n','expected':'3333\n'},
        {'input':'7 7\n','expected':'7777777\n'},
    ],
    'abc153_b': [
        {'input':'10 3\n4 5 6\n','expected':'Yes\n'},
        {'input':'20 3\n4 5 6\n','expected':'No\n'},
        {'input':'210 5\n31 41 59 26 53\n','expected':'Yes\n'},
        {'input':'211 5\n31 41 59 26 53\n','expected':'No\n'},
    ],
    'abc154_b': [
        {'input':'sardine\n','expected':'xxxxxxx\n'},
        {'input':'xxxx\n','expected':'xxxx\n'},
        {'input':'gone\n','expected':'xxxx\n'},
    ],
}

def _parts_exact(line: str, count: int) -> list[str]:
    parts=line.split(' ')
    if len(parts)!=count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical positive integer row')
    return parts

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc152_b':
        if len(lines)!=1: raise ValueError('expected one row')
        a,b=map(int,_parts_exact(lines[0],2))
        if not (1<=a<=9 and 1<=b<=9): raise ValueError('range')
        return a,b
    if pid=='abc153_b':
        if len(lines)!=2: raise ValueError('expected two rows')
        h,n=map(int,_parts_exact(lines[0],2))
        if not (1<=h<=10**9 and 1<=n<=10**5): raise ValueError('H/N range')
        parts=lines[1].split(' ')
        if len(parts)!=n or any(POS.fullmatch(x) is None for x in parts):
            raise ValueError('A row shape')
        a=list(map(int,parts))
        if any(x>10**4 for x in a): raise ValueError('A range')
        return h,n,a
    if len(lines)!=1 or LOWER.fullmatch(lines[0]) is None or not (1<=len(lines[0])<=100):
        raise ValueError('lowercase S length')
    return lines[0]

def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or output!=output.strip() or not output: return False
    if pid=='abc152_b':
        a,b=value
        return output==min(str(a)*b,str(b)*a)
    if pid=='abc153_b':
        h,n,a=value
        return output==('Yes' if sum(a)>=h else 'No')
    return output=='x'*len(value)

def _152(a:int,b:int)->str: return f'{a} {b}\n'
def _153(h:int,a:list[int])->str: return f'{h} {len(a)}\n{" ".join(map(str,a))}\n'
def _154(s:str)->str: return s+'\n'

def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc152_b':
        vals=[
            ('sample1',4,3),('sample2',7,7),('min',1,1),('a_small',1,9),('b_small',9,1),
            ('adjacent1',2,3),('adjacent2',3,2),('same2',2,2),('same8',8,8),('lex1',5,4),
            ('lex2',4,5),('wide1',2,9),('wide2',9,2),('mid1',6,3),('mid2',3,6),
            ('high1',8,9),('high2',9,8),
        ]
        for cat,a,b in vals: add(cat,_152(a,b))
        add('constraint_max',_152(9,9))
    elif pid=='abc153_b':
        vals=[
            ('sample1',10,[4,5,6]),('sample2',20,[4,5,6]),('sample3',210,[31,41,59,26,53]),
            ('sample4',211,[31,41,59,26,53]),('min_yes',1,[1]),('single_no',2,[1]),
            ('single_exact',10000,[10000]),('exact_small',6,[1,2,3]),('one_short',7,[1,2,3]),
            ('overshoot',5,[10]),('many_ones_yes',10,[1]*10),('many_ones_no',11,[1]*10),
            ('mixed_yes',100,[1,2,3,94]),('mixed_no',101,[1,2,3,94]),
            ('h_max_no',10**9,[10**4]*99999),('near_h_max_yes',10**9-1,[10**4]*100000),
            ('large_n_small_h',1,[1]*100000),
        ]
        for cat,h,a in vals: add(cat,_153(h,a))
        add('constraint_max',_153(10**9,[10**4]*100000))
    else:
        vals=[
            ('sample1','sardine'),('sample2','xxxx'),('sample3','gone'),('min_a','a'),('min_x','x'),
            ('single_z','z'),('short','abc'),('all_x_10','x'*10),('alphabet','abcdefghijklmnopqrstuvwxyz'),
            ('mixed_lower','atcoderbeginnercontest'),('len50_a','a'*50),('len50_z','z'*50),
            ('len99','abc'*33),('len100_x','x'*100),('len100_alt','ab'*50),('len2','az'),('len3','xyz'),
        ]
        for cat,s in vals: add(cat,_154(s))
        add('constraint_max',_154('z'*100))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
