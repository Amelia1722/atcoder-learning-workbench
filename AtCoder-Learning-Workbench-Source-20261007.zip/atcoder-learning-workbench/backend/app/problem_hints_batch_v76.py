"""Hints based on the public official statements of ABC086–088 B."""
HINTS_V76 = {
    'abc086_b': (
        '2つの整数を足すのではなく、10進表記をその順番でつなげた1つの数として考えます。',
        'aとbを文字列連結して整数へ戻し、その数が平方数かを判定します。整数平方根を使うと安全です。',
        '''疑似コード:\nv = int(str(a) + str(b))\nr = integer_sqrt(v)\nif r*r == v: print("Yes")\nelse: print("No")''',
    ),
    'abc087_b': (
        '各種類の硬貨について「何枚使うか」を決めれば、1つの選び方が一意に決まります。枚数の上限は50です。',
        '500円玉・100円玉・50円玉の使用枚数を範囲内で全探索し、合計がX円になる組を数えます。',
        '''疑似コード:\nans = 0\nfor i = 0 .. A:\n  for j = 0 .. B:\n    for k = 0 .. C:\n      if 500*i + 100*j + 50*k == X: ans += 1\nprint(ans)''',
    ),
    'abc088_b': (
        '毎回どのカードを取れば自分の得点を最大にできるか考えてください。相手も同じ考え方をします。',
        '大きいカードから順に取るのが最適なので、降順に並べてAliceとBobへ交互に割り当てます。',
        '''疑似コード:\nA = sort_descending(A)\nalice = sum(A[0], A[2], A[4], ...)\nbob = sum(A[1], A[3], A[5], ...)\nprint(alice - bob)''',
    ),
}
