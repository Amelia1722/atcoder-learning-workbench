"""Six reviewed C tasks: factoradic predecessor, tree traversal and offline relation histories."""
from __future__ import annotations
from bisect import bisect_right
from collections import Counter,defaultdict,deque
from itertools import combinations
from math import factorial
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(273,279))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
Triple=tuple[int,int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number in (273,274,276):
        n=ints(rows[0],1)[0];require((1<=n<=200000 if number in (273,274) else 2<=n<=100) and len(rows)==2,'shape');a=ints(rows[1],n)
        if number==273:require(all(1<=v<=10**9 for v in a),'values')
        elif number==274:require(len(set(a))==n and all(1<=parent<2*j for j,parent in enumerate(a,1)),'consistent divisions')
        else:require(set(a)==set(range(1,n+1)) and a!=tuple(range(1,n+1)),'nonfirst permutation')
        return (a,)
    if number==275:
        require(len(rows)==9 and all(len(row)==9 and set(row)<={'.','#'} for row in rows),'board');return (tuple(rows),)
    if number==277:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');edges=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=10**9 and 1<=b<=10**9 and a!=b for a,b in edges),'ladder');return (edges,)
    n,q=ints(rows[0],2);require(2<=n<=10**9 and 1<=q<=200000 and len(rows)==q+1,'shape');queries=tuple(cast(Triple,ints(row,3)) for row in rows[1:]);require(all(t in (1,2,3) and 1<=a<=n and 1<=b<=n and a!=b for t,a,b in queries) and any(t==3 for t,a,b in queries),'operations');return (queries,)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==273:
        a=sorted(cast(tuple[int,...],data[0]),reverse=True);answer=[];j=0
        while j<len(a):
            end=j+1
            while end<len(a) and a[end]==a[j]:end+=1
            answer.append(end-j);j=end
        answer.extend([0]*(len(a)-len(answer)));return '\n'.join(map(str,answer))
    if number==274:
        parents=cast(tuple[int,...],data[0]);children=[[] for _ in range(2*len(parents)+2)]
        for j,parent in enumerate(parents,1):children[parent].extend((2*j,2*j+1))
        depth=[0]*len(children);pending=deque([1])
        while pending:
            parent=pending.popleft()
            for child in children[parent]:depth[child]=depth[parent]+1;pending.append(child)
        return '\n'.join(map(str,depth[1:]))
    if number==275:
        grid=cast(tuple[str,...],data[0]);points=[(r,c) for r,row in enumerate(grid) for c,ch in enumerate(row) if ch=='#'];answer=0
        for vertices in combinations(points,4):
            distances=sorted((a[0]-b[0])**2+(a[1]-b[1])**2 for a,b in combinations(vertices,2));answer+=distances[0]==distances[1]==distances[2]==distances[3] and distances[4]==distances[5]==2*distances[0]
        return str(answer)
    if number==276:
        p=cast(tuple[int,...],data[0]);available=list(range(1,len(p)+1));rank=0
        for j,value in enumerate(p):index=available.index(value);rank+=index*factorial(len(p)-j-1);available.pop(index)
        rank-=1;available=list(range(1,len(p)+1));answer=[]
        for remaining in range(len(p)-1,-1,-1):index,rank=divmod(rank,factorial(remaining));answer.append(available.pop(index))
        return ' '.join(map(str,answer))
    if number==277:
        edges=cast(tuple[Pair,...],data[0]);nodes=sorted({1}|{v for edge in edges for v in edge});index={v:j for j,v in enumerate(nodes)};parent=list(range(len(nodes)));sizes=[1]*len(nodes)
        def root(j:int)->int:
            while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
            return j
        for a,b in edges:
            u,v=root(index[a]),root(index[b])
            if u!=v:
                if sizes[u]<sizes[v]:u,v=v,u
                parent[v]=u;sizes[u]+=sizes[v]
        component=root(index[1]);return str(max(v for v in nodes if root(index[v])==component))
    queries=cast(tuple[Triple,...],data[0]);histories:dict[Pair,list[tuple[int,bool]]]=defaultdict(list);requests=[]
    for time,(t,a,b) in enumerate(queries):
        if t==3:requests.append((time,a,b))
        else:histories[a,b].append((time,t==1))
    def follows_at(a:int,b:int,time:int)->bool:
        events=histories.get((a,b),[]);position=bisect_right(events,(time,True))-1
        return position>=0 and events[position][1]
    return '\n'.join('Yes' if follows_at(a,b,time) and follows_at(b,a,time) else 'No' for time,a,b in requests)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc273_c':"from collections import Counter\nn=int(input());counts=Counter(map(int,input().split()));answer=[counts[v] for v in sorted(counts,reverse=True)];print(*(answer+[0]*(n-len(answer))),sep='\\n')\n",
'abc274_c':"n=int(input());a=list(map(int,input().split()));depth=[0]*(2*n+2)\nfor j,p in enumerate(a,1):depth[2*j]=depth[2*j+1]=depth[p]+1\nprint(*depth[1:],sep='\\n')\n",
'abc275_c':"s=[input() for _ in range(9)];points={(r,c) for r in range(9) for c in range(9) if s[r][c]=='#'};answer=0\nfor r,c in points:\n for u,v in points:\n  if (r,c)==(u,v):continue\n  dr,dc=u-r,v-c\n  if (u-dc,v+dr) in points and (r-dc,c+dr) in points:answer+=1\nprint(answer//4)\n",
'abc276_c':"n=int(input());p=list(map(int,input().split()));i=n-2\nwhile p[i]<p[i+1]:i-=1\nj=n-1\nwhile p[j]>p[i]:j-=1\np[i],p[j]=p[j],p[i];p[i+1:]=reversed(p[i+1:]);print(*p)\n",
'abc277_c':"from collections import defaultdict\nn=int(input());g=defaultdict(list)\nfor _ in range(n):\n a,b=map(int,input().split());g[a].append(b);g[b].append(a)\nseen={1};pending=[1]\nwhile pending:\n for v in g[pending.pop()]:\n  if v not in seen:seen.add(v);pending.append(v)\nprint(max(seen))\n",
'abc278_c':"n,q=map(int,input().split());edges=set()\nfor _ in range(q):\n t,a,b=map(int,input().split())\n if t==1:edges.add((a,b))\n elif t==2:edges.discard((a,b))\n else:print('Yes' if (a,b) in edges and (b,a) in edges else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16700+number)
    if number==273:
        def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[array([1]),array([10**9]),array([1,2]),array([2,2])]+[array([rng.randint(1,100) for _ in range(n)]) for n in range(3,15)]+[array(list(range(1,200001))),array([10**9]*200000)]
    elif number==274:
        def record(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[record([1]),record([1,2]),record([1,3]),record([1,2,3])]
        # Independent live-list removal ensures no ameba splits twice.
        for n in range(4,16):
            live=[1];a=[]
            for j in range(1,n+1):index=rng.randrange(len(live));a.append(live.pop(index));live.extend((2*j,2*j+1))
            raws.append(record(a))
        raws.extend([record([1]+[2*j for j in range(1,200000)]),record(list(range(1,200001)))])
    elif number==275:
        def board(points:set[Pair])->str:return ''.join(''.join('#' if (r,c) in points else '.' for c in range(9))+'\n' for r in range(9))
        raws=[board(set()),board({(0,0)}),board({(0,0),(0,1),(1,0),(1,1)}),board({(1,0),(0,1),(1,2),(2,1)})]
        for j in range(1,13):raws.append(board(set(rng.sample([(r,c) for r in range(9) for c in range(9)],j+4))))
        raws.extend([board({(r,c) for r in range(9) for c in range(9) if (r+c)%2==0}),board({(r,c) for r in range(9) for c in range(9)})])
    elif number==276:
        def permutation(p:list[int])->str:return f'{len(p)}\n'+line(p)
        raws=[permutation([2,1]),permutation([1,3,2]),permutation([3,1,2]),permutation([3,2,1])]
        for n in range(4,16):p=list(range(1,n+1));rng.shuffle(p);raws.append(permutation(p if p!=list(range(1,n+1)) else p[::-1]))
        raws.extend([permutation(list(range(1,99))+[100,99]),permutation(list(range(100,0,-1)))])
    elif number==277:
        def ladders(e:list[Pair])->str:return f'{len(e)}\n'+''.join(line(v) for v in e)
        raws=[ladders([(1,2)]),ladders([(2,3)]),ladders([(1,10**9)]),ladders([(1,2),(1,2)])]
        for n in range(3,15):raws.append(ladders([cast(Pair,tuple(rng.sample(range(1,101),2))) for _ in range(n)]))
        raws.extend([ladders([(j,j+1) for j in range(1,200001)]),ladders([(1,10**9)]*200000)])
    else:
        def operations(n:int,q:list[Triple])->str:return f'{n} {len(q)}\n'+''.join(line(v) for v in q)
        raws=[operations(2,[(3,1,2)]),operations(2,[(1,1,2),(3,1,2)]),operations(2,[(1,1,2),(1,2,1),(3,1,2)]),operations(2,[(2,1,2),(3,2,1)])]
        for n in range(3,15):q=[(rng.randint(1,3),*rng.sample(range(1,n+1),2)) for _ in range(n*3)]+[(3,1,n)];raws.append(operations(n,cast(list[Triple],q)))
        raws.extend([operations(10**9,[(1,1,10**9),(1,10**9,1),(3,1,10**9),(2,1,10**9),(3,1,10**9)]*40000),operations(10**9,[(3,1,10**9)]*200000)])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc273_c':('自分より大きい値の種類数は、重複を除いた降順の順位です。','値ごとに出現回数を数え、値の降順に回数を出力します。足りない行数は0です。','疑似コード: count=frequency(A); answer=[count[value] for value in distinct values descending]; pad answer with zeros to N; print each answer。'),
'abc274_c':('新しく生まれる二匹の世代は、親の世代より1大きいです。','記録順に親の世代はすでに分かっています。子2iと2i+1へ同じ世代を設定します。','疑似コード: depth[1]=0; for i=1..N: depth[2*i]=depth[2*i+1]=depth[A[i]]+1; print depth[1..2*N+1]。'),
'abc275_c':('正方形の一辺を決めると、90度回転した方向に残りの頂点が決まります。','ポーンの二点を有向辺として選び、辺ベクトルを90度回転させた残り二点があるか確認します。同じ正方形を4回数えるので4で割ります。','疑似コード: for ordered distinct vertices p,q: d=q-p; rotated=(-d.c,d.r); if p+rotated and q+rotated present: answer+=1; print(answer/4)。'),
'abc276_c':('末尾から、値を小さく変更できる最初の位置を探します。','P[i]>P[i+1]となる最も右のiを選び、右側のP[i]未満で最大の値と交換します。残りを降順にします。','疑似コード: find rightmost i with P[i]>P[i+1]; swap P[i] with largest smaller suffix value; reverse ascending suffix; print(P)。'),
'abc277_c':('はしごは双方向の辺で、階は頂点と考えられます。','存在する階だけを辞書でグラフにし、1階からDFSで到達できる階の最大値を求めます。','疑似コード: graph=undirected ladder edges; seen={1}; DFS from1 adding unseen floors; print(max(seen))。'),
'abc278_c':('フォロー関係は向きがあるので、順序付きの組で記録します。','追加・解除を集合に反映します。照会時は(A,B)と(B,A)が両方あるか確認します。','疑似コード: edges=set(); type1: add(A,B); type2: discard(A,B); type3: print(Yes if both directions present else No)。')}

TITLES={'abc273_c': '(K+1)-th Largest Number', 'abc274_c': 'Ameba', 'abc275_c': 'Counting Squares', 'abc276_c': 'Previous Permutation', 'abc277_c': 'Ladder Takahashi', 'abc278_c': 'FF'}
PUBLISHED_SAMPLES={'abc273_c': [{'input': '6\n2 7 1 8 2 8\n', 'expected': '2\n1\n2\n1\n0\n0\n'}, {'input': '1\n1\n', 'expected': '1\n'}, {'input': '10\n979861204 57882493 979861204 447672230 644706927 710511029 763027379 710511029 447672230 136397527\n', 'expected': '2\n1\n2\n1\n2\n1\n1\n0\n0\n0\n'}], 'abc274_c': [{'input': '2\n1 2\n', 'expected': '0\n1\n1\n2\n2\n'}, {'input': '4\n1 3 5 2\n', 'expected': '0\n1\n1\n2\n2\n3\n3\n2\n2\n'}], 'abc275_c': [{'input': '##.......\n##.......\n.........\n.......#.\n.....#...\n........#\n......#..\n.........\n.........\n', 'expected': '2\n'}, {'input': '.#.......\n#.#......\n.#.......\n.........\n....#.#.#\n.........\n....#.#.#\n........#\n.........\n', 'expected': '3\n'}], 'abc276_c': [{'input': '3\n3 1 2\n', 'expected': '2 3 1\n'}, {'input': '10\n9 8 6 5 10 3 1 2 4 7\n', 'expected': '9 8 6 5 10 2 7 4 3 1\n'}], 'abc277_c': [{'input': '4\n1 4\n4 3\n4 10\n8 3\n', 'expected': '10\n'}, {'input': '6\n1 3\n1 5\n1 12\n3 5\n3 12\n5 12\n', 'expected': '12\n'}, {'input': '3\n500000000 600000000\n600000000 700000000\n700000000 800000000\n', 'expected': '1\n'}], 'abc278_c': [{'input': '3 9\n1 1 2\n3 1 2\n1 2 1\n3 1 2\n1 2 3\n1 3 2\n3 1 3\n2 1 2\n3 1 2\n', 'expected': 'No\nYes\nNo\nNo\n'}, {'input': '2 8\n1 1 2\n1 2 1\n3 1 2\n1 1 2\n1 1 2\n1 1 2\n2 1 2\n3 1 2\n', 'expected': 'Yes\nNo\n'}, {'input': '10 30\n3 1 6\n3 5 4\n1 6 1\n3 1 7\n3 8 4\n1 1 6\n2 4 3\n1 6 5\n1 5 6\n1 1 8\n1 8 1\n2 3 10\n1 7 6\n3 5 6\n1 6 7\n3 6 7\n1 9 5\n3 8 6\n3 3 8\n2 6 9\n1 7 1\n3 10 8\n2 9 2\n1 10 9\n2 6 10\n2 6 8\n3 1 6\n3 1 8\n2 8 5\n1 9 10\n', 'expected': 'No\nNo\nNo\nNo\nYes\nYes\nNo\nNo\nNo\nYes\nYes\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
