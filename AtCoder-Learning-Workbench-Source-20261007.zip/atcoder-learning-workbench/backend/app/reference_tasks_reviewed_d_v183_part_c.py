"""Private ABC090--095 D review: official ARC identities and semantic outputs."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter
from math import comb
from typing import cast
import random,re
TASKS=('arc091_b','arc092_b','arc093_b','arc094_b','arc095_b','arc096_b')
CONTESTS=dict(zip(TASKS,('abc090','abc091','abc092','abc093','abc094','abc095')))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'arc093_b':'semantic','arc095_b':'semantic'}
CHECKER_IDS={p:p for p in OUTPUT_MODES}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc091_b':
        require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=n<=100000 and 0<=k<n,'remainder');return n,k
    if pid=='arc092_b':
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];a,b=ints(rows[1],n),ints(rows[2],n);require(1<=n<=200000 and all(0<=v<1<<28 for ar in (a,b) for v in ar),'xor');return a,b
    if pid=='arc093_b':
        require(len(rows)==1,'shape');a,b=ints(rows[0],2);require(1<=a<=500 and 1<=b<=500,'components');return a,b
    if pid=='arc094_b':
        q=ints(rows[0],1)[0];require(1<=q<=100 and len(rows)==q+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for pair in a for v in pair),'ranks');return (a,)
    if pid=='arc095_b':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=100000 and len(set(a))==n and all(0<=v<=10**9 for v in a),'distinct values');return (a,)
    n,c=ints(rows[0],2);require(1<=n<=100000 and 2<=c<=10**14 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=x<c and 1<=v<=10**9 for x,v in a) and all(l[0]<r[0] for l,r in zip(a,a[1:])),'sushi');return c,a

def remainder_blocks(n:int,k:int)->int:
    if k==0:return n*n
    # Sum lattice counts over maximal divisor intervals of equal floor(N/b).
    answer=0;left=k+1
    while left<=n:
        q=n//left;right=n//q;count=right-left+1;answer+=q*((left+right)*count//2-k*count)
        tail=min(right,(n-k)//q)
        if tail>=left:count=tail-left+1;answer+=(n-k+1)*count-q*(left+tail)*count//2
        left=right+1
    return answer

def pair_xor(a:tuple[int,...],b:tuple[int,...])->int:
    # Even-frequency terms cancel before counting. Stable radix partitions
    # retain low-bit order; three two-pointer thresholds replace per-item
    # binary searches in the independently sorted reference.
    aa=[v for v,count in Counter(a).items() if count%2];bb=[v for v,count in Counter(b).items() if count%2]
    if not aa or not bb:return 0
    answer=0
    for bit in range(29):
        t=1<<bit;mask=2*t-1;aa=[v for v in aa if not v&t]+[v for v in aa if v&t];bb=[v for v in bb if not v&t]+[v for v in bb if v&t];x=[v&mask for v in aa];y=[v&mask for v in bb]
        def less(threshold:int)->int:
            j=len(y)-1;count=0
            for value in x:
                while j>=0 and value+y[j]>=threshold:j-=1
                count+=j+1
            return count
        parity=(less(2*t)-less(t)+len(x)*len(y)-less(3*t))%2
        if parity:answer|=t
    return answer

def component_grid(a:int,b:int)->str:
    # Vertical background halves; the reference uses horizontal halves.
    board=[list('#'*50+'.'*50) for _ in range(100)]
    for j in range(a-1):r,c=divmod(j,25);board[2*r][2*c]='.'
    for j in range(b-1):r,c=divmod(j,25);board[2*r][51+2*c]='#'
    return '100 100\n'+'\n'.join(''.join(row) for row in board)

def grid_valid(a:int,b:int,actual:str)->bool:
    try:
        rows=actual.removesuffix('\n').split('\n');h,w=ints(rows[0],2);require(1<=h<=100 and 1<=w<=100 and len(rows)==h+1 and all(len(row)==w and set(row)<={'.','#'} for row in rows[1:]),'grid shape');board=rows[1:];seen:set[tuple[int,int]]=set();counts={'.':0,'#':0}
        for r in range(h):
            for c in range(w):
                if (r,c) in seen:continue
                color=board[r][c];counts[color]+=1;seen.add((r,c));stack=[(r,c)]
                while stack:
                    y,x=stack.pop()
                    for yy,xx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                        if 0<=yy<h and 0<=xx<w and (yy,xx) not in seen and board[yy][xx]==color:seen.add((yy,xx));stack.append((yy,xx))
        return counts['.']==a and counts['#']==b
    except (ValueError,TypeError,IndexError):return False

def rank_matching(a:int,b:int)->int:
    # For m participants, use the m smallest available first/second ranks,
    # matched in reverse order. Products are piecewise concave quadratics.
    # Checking each segment's integer vertex gives exact feasibility; binary
    # search m is independent of the reference's square-root closed formula.
    if a>b:a,b=b,a
    target=a*b
    def feasible(m:int)->bool:
        cuts=sorted({1,m+1,max(1,min(m+1,a)),max(1,min(m+1,m+2-b))})
        for left,right in zip(cuts,cuts[1:]):
            if left==right:continue
            p=int(left>=a);q=int(m+1-left>=b);centre=(m+1+q-p)//2
            for x in {left,right-1,max(left,min(right-1,centre)),max(left,min(right-1,centre+1))}:
                if (x+p)*(m+1-x+q)>=target:return False
        return True
    lo,hi=0,2*10**9
    while lo+1<hi:
        mid=(lo+hi)//2
        if feasible(mid):lo=mid
        else:hi=mid
    return lo

def binomial_pair(a:tuple[int,...])->tuple[int,int]:
    values=sorted(a);n=values[-1]
    if n<=200:return max(((x,y) for x in values for y in values if y<x),key=lambda p:comb(*p))
    j=bisect_left(values, (n+1)//2,0,len(values)-1);candidates=values[max(0,j-1):min(len(values)-1,j+1)];return n,max(candidates,key=lambda r:min(r,n-r))

def binomial_valid(a:tuple[int,...],actual:str)->bool:
    try:
        value=actual.removesuffix('\n');n,r=ints(value,2);require(n in a and r in a and n>r,'selected input pair')
        if max(a)<=200:return comb(n,r)==max(comb(x,y) for x in a for y in a if x>y)
        # Increasing the upper argument strictly improves any positive-r
        # coefficient. Nontrivial inputs therefore require the largest value.
        # Within that row C(n,r) strictly increases with min(r,n-r).
        require(n==max(a),'largest upper argument');chosen=min(r,n-r);return all(min(v,n-v)<=chosen for v in a if v!=n)
    except (ValueError,TypeError,IndexError):return False

def sushi_ranges(c:int,a:tuple[tuple[int,int],...])->int:
    # Every route needs at most one turn. Enumerate its clockwise endpoint
    # and query the two counterclockwise endpoint costs in a range-max tree.
    n=len(a);suffix=[0]*(n+1)
    for j in range(n-1,-1,-1):suffix[j]=suffix[j+1]+a[j][1]
    size=1<<n.bit_length();tree=[(-10**30,-10**30)]*(2*size)
    for j in range(n+1):distance=c-a[j][0] if j<n else 0;tree[size+j]=(suffix[j]-distance,suffix[j]-2*distance)
    for j in range(size-1,0,-1):tree[j]=(max(tree[2*j][0],tree[2*j+1][0]),max(tree[2*j][1],tree[2*j+1][1]))
    def query(left:int)->tuple[int,int]:
        right=size+n+1;left+=size;first=second=-10**30
        while left<right:
            if left&1:first=max(first,tree[left][0]);second=max(second,tree[left][1]);left+=1
            if right&1:right-=1;first=max(first,tree[right][0]);second=max(second,tree[right][1])
            left//=2;right//=2
        return first,second
    answer=prefix=0
    for i in range(n+1):
        distance=a[i-1][0] if i else 0;one,two=query(i);answer=max(answer,prefix-2*distance+one,prefix-distance+two)
        if i<n:prefix+=a[i][1]
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc091_b':return str(remainder_blocks(*cast(tuple[int,int],data)))
    if pid=='arc092_b':return str(pair_xor(*cast(tuple[tuple[int,...],tuple[int,...]],data)))
    if pid=='arc093_b':return component_grid(*cast(tuple[int,int],data))
    if pid=='arc094_b':return '\n'.join(str(rank_matching(a,b)) for a,b in cast(tuple[tuple[int,int],...],data[0]))
    if pid=='arc095_b':return ' '.join(map(str,binomial_pair(cast(tuple[int,...],data[0]))))
    return str(sushi_ranges(*cast(tuple[int,tuple[tuple[int,int],...]],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='arc093_b':return grid_valid(*cast(tuple[int,int],data),actual)
        if pid=='arc095_b':return binomial_valid(cast(tuple[int,...],data[0]),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'arc091_b':"n,k=map(int,input().split());answer=0\nif k==0:answer=n*n\nelse:\n for b in range(k+1,n+1):q,r=divmod(n,b);answer+=q*(b-k)+max(0,r-k+1)\nprint(answer)\n",
'arc092_b':"from bisect import bisect_left\nn=int(input());a=list(map(int,input().split()));b=list(map(int,input().split()));answer=0\nfor bit in range(29):\n t=1<<bit;mask=2*t-1;s=sorted(v&mask for v in b);count=0\n for v in a:\n  x=v&mask;count+=bisect_left(s,2*t-x)-bisect_left(s,t-x)+n-bisect_left(s,3*t-x)\n if count%2:answer|=t\nprint(answer)\n",
'arc093_b':"a,b=map(int,input().split());g=[list('#'*100 if j<50 else '.'*100) for j in range(100)]\nfor j in range(a-1):r,c=divmod(j,50);g[2*r][2*c]='.'\nfor j in range(b-1):r,c=divmod(j,50);g[51+2*r][2*c]='#'\nprint(100,100)\nfor row in g:print(''.join(row))\n",
'arc094_b':"from math import isqrt\nq=int(input())\nfor _ in range(q):\n a,b=map(int,input().split());p=a*b;c=isqrt(p)\n if c*c==p:c-=1\n print(2*a-2 if a==b else 2*c-2 if c*(c+1)>=p else 2*c-1)\n",
'arc095_b':"n=int(input());a=list(map(int,input().split()));largest=max(a);r=min((v for v in a if v!=largest),key=lambda v:abs(2*v-largest));print(largest,r)\n",
'arc096_b':"n,c=map(int,input().split());p=[tuple(map(int,input().split())) for _ in range(n)];x=[0]+[v[0] for v in p];v=[0]+[v[1] for v in p];cw=[0]*(n+1);ccw=[0]*(n+1);s=0\nfor i in range(1,n+1):s+=v[i];cw[i]=max(cw[i-1],s-x[i])\ns=0\nfor j in range(1,n+1):s+=v[n-j+1];ccw[j]=max(ccw[j-1],s-(c-x[n-j+1]))\nanswer=max(cw[n],ccw[n]);s=0\nfor i in range(1,n+1):s+=v[i];answer=max(answer,s-2*x[i]+ccw[n-i])\ns=0\nfor j in range(1,n+1):s+=v[n-j+1];answer=max(answer,s-2*(c-x[n-j+1])+cw[n-j])\nprint(answer)\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18300+TASKS.index(pid));raws:list[str]=[]
    if pid=='arc091_b':raws=[f'{n} {k}\n' for n,k in ((1,0),(2,0),(2,1),(3,1),(3,2),(5,2),(10,0),(10,1),(10,9),(99,33),(100,50),(101,50),(999,1),(31415,9265),(99999,99998),(100000,99999),(100000,0),(100000,50000))]
    elif pid=='arc092_b':
        def arrays(a:list[int],b:list[int])->str:return f'{len(a)}\n'+line(a)+line(b)
        raws=[arrays([0],[0]),arrays([(1<<28)-1],[(1<<28)-1]),arrays([0],[1<<27]),arrays([1,2],[3,4]),arrays([1,1],[2,3])]
        for n in range(3,14):raws.append(arrays([rng.randrange(1<<28) for _ in range(n)],[rng.randrange(1<<28) for _ in range(n)]))
        raws+=[arrays([rng.randrange(1<<28) for _ in range(199999)],[rng.randrange(1<<28) for _ in range(199999)]),arrays([(j*123457)&((1<<28)-1) for j in range(200000)],[((1<<28)-1-j*76543)&((1<<28)-1) for j in range(200000)])]
    elif pid=='arc093_b':raws=[f'{a} {b}\n' for a,b in ((1,1),(1,2),(2,1),(2,3),(7,8),(3,14),(1,500),(500,1),(2,500),(500,2),(25,25),(49,50),(50,49),(250,250),(499,500),(500,499),(499,499),(500,500))]
    elif pid=='arc094_b':
        def ranks(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(pair) for pair in a)
        raws=[ranks([(1,1)]),ranks([(1,10**9)]),ranks([(10**9,1)]),ranks([(2,2)]),ranks([(3,4)]),ranks([(2,9)]),ranks([(3,3),(4,4),(5,5)])]
        for n in range(2,11):raws.append(ranks([(rng.randint(1,10**9),rng.randint(1,10**9)) for _ in range(n)]))
        raws+=[ranks([(10**9-j,10**9-j-1) for j in range(100)]),ranks([(10**9,10**9)]*100)]
    elif pid=='arc095_b':
        def values(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[values([0,1]),values([0,10**9]),values([0,1,2]),values([0,4,6,10]),values([2,3,5]),values([1,4,6,10]),values([0,2,8,10])]
        for n in range(3,12):raws.append(values(rng.sample(range(10**9+1),n)))
        raws+=[values(list(range(99999))+[10**9]),values([0]+list(range(1,99999))+[10**9])]
        # The last two raw value sets coincide, so reverse one representative.
        raws[-2]=values(list(range(99998,-1,-1))+[10**9])
    else:
        def sushi(c:int,a:list[tuple[int,int]])->str:return f'{len(a)} {c}\n'+''.join(line(pair) for pair in a)
        raws=[sushi(2,[(1,1)]),sushi(2,[(1,10**9)]),sushi(10**14,[(10**14-1,10**9)]),sushi(10**14,[(10**14//2,1)]),sushi(20,[(2,80),(9,1),(16,120)])]
        for n in range(2,13):raws.append(sushi(1000000,[(x,rng.randint(1,10**9)) for x in sorted(rng.sample(range(1,1000000),n))]))
        raws+=[sushi(10**14,[(j,10**9) for j in range(1,50001)]+[(10**14-50001+j,10**9) for j in range(1,50001)]),sushi(10**14,[(j*999999999,10**9) for j in range(1,100001)])]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'arc091_b':('割る数bを固定して、条件を満たすaを数えます。','長さbの完全な区間ごとにb-K個あり、末尾の余り部分はmax(0,N%b-K+1)個あります。K=0は全ての組が有効です。','疑似コード: K==0ならN*N; それ以外はb=K+1..Nについてq,r=divmod(N,b); ans+=q*(b-K)+max(0,r-K+1); ansを出力。'),
'arc092_b':('xorの各ビットは、そのビットが立つ和の個数の偶奇だけで決まります。','ビットt=2^kについて各数を2tで剰余化します。和が[t,2t)または[3t,4t)に入る相手の個数を数えます。','疑似コード: bit=0..28; t=1<<bit; bを2t剰余で整列; 各aの剰余xについてlower_boundで区間[t-x,2t-x),[3t-x,4t-x)を数える; 合計が奇数なら答えのbitを立てる。'),
'arc093_b':('白と黒の大きな連結領域を一つずつ用意します。','100×100を黒い上半分と白い下半分に分けます。それぞれの内部に、互いに接しない逆色の島を置けば成分数を増やせます。','疑似コード: 上50行を#、下50行を.; 上の偶数行・偶数列へA-1個の.を配置; 下の51行目以降の隔行・隔列へB-1個の#を配置; サイズと画像を出力。'),
'arc094_b':('順位の積がA*B未満になるよう、使う二つの順位を逆順に組み合わせます。','A=Bなら答えは2*A-2です。それ以外はP=A*Bとしてc²<Pとなる最大整数cを求め、c(c+1)がP以上かどうかで最大人数を判定します。','疑似コード: A==Bなら2*A-2; 他はP=A*B; c=isqrt(P); c*c==Pならc--; c*(c+1)>=Pなら2*c-2、他なら2*c-1を出力。'),
'arc095_b':('二項係数の上側の数を大きくすると、同じ下側の数で値が増えます。','上側は入力の最大値にできます。その行の二項係数は中央に近いほど大きいため、残りから半分に最も近い値を選びます。同率ならどちらでも構いません。','疑似コード: n=max(a); rはn以外の値のうちabs(2*r-n)を最小にするもの; n,rを出力。'),
'arc096_b':('片方向に進んで終了する場合と、一度だけ向きを変える場合を考えます。','時計回り・反時計回りそれぞれの片道で得られる最大値を累積します。一方を往復してから、重複しないもう一方へ進む値を比較します。','疑似コード: cw[i]=max(cw[i-1],時計回りi個の価値合計-x[i]); ccwも反対側から同様; i個を往復する価値合計-2*距離と反対側の片道best[N-i]を全iで比較; 逆向きも比較し0以上の最大値を出力。')}

TITLES={'arc091_b': 'Remainder Reminder', 'arc092_b': 'Two Sequences', 'arc093_b': 'Grid Components', 'arc094_b': 'Worst Case', 'arc095_b': 'Binomial Coefficients', 'arc096_b': 'Static Sushi'}
PUBLISHED_SAMPLES={'arc091_b': [{'input': '5 2\n', 'expected': '7\n'}, {'input': '10 0\n', 'expected': '100\n'}, {'input': '31415 9265\n', 'expected': '287927211\n'}], 'arc092_b': [{'input': '2\n1 2\n3 4\n', 'expected': '2\n'}, {'input': '6\n4 6 0 0 3 3\n0 5 6 5 0 3\n', 'expected': '8\n'}, {'input': '5\n1 2 3 4 5\n1 2 3 4 5\n', 'expected': '2\n'}, {'input': '1\n0\n0\n', 'expected': '0\n'}], 'arc093_b': [{'input': '2 3\n', 'expected': '3 3\n##.\n..#\n#.#\n'}, {'input': '7 8\n', 'expected': '3 5\n#.#.#\n.#.#.\n#.#.#\n'}, {'input': '1 1\n', 'expected': '4 2\n..\n#.\n##\n##\n'}, {'input': '3 14\n', 'expected': '8 18\n..................\n..................\n....##.......####.\n....#.#.....#.....\n...#...#....#.....\n..#.###.#...#.....\n.#.......#..#.....\n#.........#..####.\n'}], 'arc094_b': [{'input': '8\n1 4\n10 5\n3 3\n4 11\n8 9\n22 40\n8 36\n314159265 358979323\n', 'expected': '1\n12\n4\n11\n14\n57\n31\n671644785\n'}], 'arc095_b': [{'input': '5\n6 9 4 2 11\n', 'expected': '11 6\n'}, {'input': '2\n100 0\n', 'expected': '100 0\n'}], 'arc096_b': [{'input': '3 20\n2 80\n9 120\n16 1\n', 'expected': '191\n'}, {'input': '3 20\n2 80\n9 1\n16 120\n', 'expected': '192\n'}, {'input': '1 100000000000000\n50000000000000 1\n', 'expected': '0\n'}, {'input': '15 10000000000\n400000000 1000000000\n800000000 1000000000\n1900000000 1000000000\n2400000000 1000000000\n2900000000 1000000000\n3300000000 1000000000\n3700000000 1000000000\n3800000000 1000000000\n4000000000 1000000000\n4100000000 1000000000\n5200000000 1000000000\n6600000000 1000000000\n8000000000 1000000000\n9300000000 1000000000\n9700000000 1000000000\n', 'expected': '6500000000\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
