"""Reviewed ABC042..047 D, official shared ARC canonical task identifiers."""
from __future__ import annotations
from collections import Counter,defaultdict
from math import isqrt
from typing import cast,Iterator
import random,re
MOD=1000000007
TASKS=tuple(f'arc{n:03}_b' for n in range(58,64))
CONTESTS={p:f'abc{n:03}' for p,n in zip(TASKS,range(42,48))}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'arc059_b':'semantic'}
CHECKER_IDS={'arc059_b':'arc059_b'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');n=int(pid[3:6])
    if n==58:
        require(len(rows)==1,'shape');h,w,a,b=ints(rows[0],4);require(1<=a<h<=100000 and 1<=b<w<=100000,'grid');return h,w,a,b
    if n==59:
        require(len(rows)==1 and re.fullmatch('[a-z]{2,100000}',rows[0]) is not None,'string');return (rows[0],)
    if n==60:
        require(len(rows)==2,'shape');a,b=(ints(row,1)[0] for row in rows);require(1<=a<=10**11 and 1<=b<=10**11,'digit sum');return a,b
    if n==61:
        h,w,k=ints(rows[0],3);require(3<=h<=10**9 and 3<=w<=10**9 and 0<=k<=min(100000,h*w) and len(rows)==k+1,'shape');points=tuple(ints(row,2) for row in rows[1:]);require(all(1<=r<=h and 1<=c<=w for r,c in points) and len(set(points))==k,'points');return h,w,points
    if n==62:
        require(len(rows)==1 and 1<=len(rows[0])<=100000 and set(rows[0])<=set('gp'),'hands');balance=0
        for ch in rows[0]:balance+=1 if ch=='g' else -1;require(balance>=0,'opponent prefix guarantee')
        return (rows[0],)
    require(len(rows)==2,'shape');k,t=ints(rows[0],2);values=ints(rows[1],k);require(2<=k<=100000 and 2<=t<=10**9 and all(1<=v<=10**9 for v in values) and len(set(values))==k,'prices')
    minimum=values[0];profit=False
    for v in values[1:]:profit|=v>minimum;minimum=min(minimum,v)
    require(profit,'positive profit');return t,values

def factorial_tables(n:int)->tuple[list[int],list[int]]:
    fact=[1]*(n+1)
    for j in range(1,n+1):fact[j]=fact[j-1]*j%MOD
    inv=[1]*(n+1);inv[n]=pow(fact[n],MOD-2,MOD)
    for j in range(n,0,-1):inv[j-1]=inv[j]*j%MOD
    return fact,inv

def majority_interval(s:str)->tuple[int,int]|None:
    # A +1/-1 prefix for each letter: positive subarray means strict majority.
    # Only left prefixes at least two positions before the right are eligible.
    for ch in sorted(set(s)):
        prefix=[0]
        for value in s:prefix.append(prefix[-1]+(1 if value==ch else -1))
        minimum=0;left=0
        for right in range(2,len(s)+1):
            if prefix[right-2]<minimum:minimum=prefix[right-2];left=right-2
            if prefix[right]>minimum:return left+1,right
    return None

def interval_valid(raw:str,actual:str)->bool:
    try:
        s=cast(str,validate('arc059_b',raw)[0]);a,b=ints(actual.removesuffix('\n'),2)
        if (a,b)==(-1,-1):return majority_interval(s) is None
        if not 1<=a<b<=len(s):return False
        counts=Counter(s[a-1:b]);return 2*max(counts.values())>b-a+1
    except (ValueError,TypeError,IndexError):return False

def digit_sum(n:int,b:int)->int:
    result=0
    while n:result+=n%b;n//=b
    return result

def sparse_sweep(h:int,w:int,points:tuple[tuple[int,int],...])->list[int]:
    events:dict[int,list[tuple[int,int]]]=defaultdict(list);events[1];events[h-1]
    for r,c in points:
        low=max(1,r-2);high=min(h-2,r)
        events[low].append((c,1));events[high+1].append((c,-1))
    starts=sorted(events);active:dict[int,int]={};answer=[0]*10
    for row,nextrow in zip(starts,starts[1:]):
        for c,delta in events[row]:
            active[c]=active.get(c,0)+delta
            if active[c]==0:del active[c]
        changes:dict[int,int]=defaultdict(int);changes[1];changes[w-1]
        for c,count in active.items():changes[max(1,c-2)]+=count;changes[min(w-2,c)+1]-=count
        xs=sorted(changes);count=0
        for x,y in zip(xs,xs[1:]):count+=changes[x];answer[count]+=(y-x)*(nextrow-row)
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);n=int(pid[3:6])
    if n==58:
        h,w,a,b=cast(tuple[int,int,int,int],data)
        if h*w<=10000:
            dp=[0]*w;dp[0]=1
            for r in range(h):
                for c in range(w):
                    if r>=h-a and c<b:dp[c]=0
                    elif c:dp[c]=(dp[c]+dp[c-1])%MOD
            return str(dp[-1])
        fact,inv=factorial_tables(h+w)
        def choose(total:int,k:int)->int:return fact[total]*inv[k]%MOD*inv[total-k]%MOD
        # Every valid path crosses the vertical boundary B exactly once,
        # at a row above the forbidden rectangle.
        return str(sum(choose(r+b-1,r)*choose(h-1-r+w-1-b,h-1-r) for r in range(h-a))%MOD)
    if n==59:
        found=majority_interval(cast(str,data[0]));return '-1 -1' if found is None else f'{found[0]} {found[1]}'
    if n==60:
        value,target=cast(tuple[int,int],data)
        if target>value:return '-1'
        if target==value:return str(value+1)
        difference=value-target;best=value+1
        # Each valid base divides n-s through b-1, regardless of digit count.
        for divisor in range(1,isqrt(difference)+1):
            if difference%divisor:continue
            for candidate in (divisor+1,difference//divisor+1):
                if candidate<best and digit_sum(value,candidate)==target:best=candidate
        return str(best if best<=value else -1)
    if n==61:
        h,w,points=cast(tuple[int,int,tuple[tuple[int,int],...]],data);return '\n'.join(map(str,sparse_sweep(h,w,points)))
    if n==62:
        s=cast(str,data[0]);balance=score=0
        for ch in s:
            player='p' if balance else 'g';balance+=1 if player=='g' else -1
            score+=(player=='p' and ch=='g')-(player=='g' and ch=='p')
        return str(score)
    _,prices=cast(tuple[int,tuple[int,...]],data);largest=prices[-1];gains=[]
    for value in reversed(prices[:-1]):gains.append(largest-value);largest=max(largest,value)
    maximum=max(gains);return str(gains.count(maximum))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='arc059_b':return interval_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='arc059_b':return interval_valid(raw,expected) and interval_valid(raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'arc058_b':"p=1000000007;h,w,a,b=map(int,input().split());fact=[1]*(h+w+1)\nfor i in range(1,h+w+1):fact[i]=fact[i-1]*i%p\ninv=[1]*(h+w+1);inv[-1]=pow(fact[-1],p-2,p)\nfor i in range(h+w,0,-1):inv[i-1]=inv[i]*i%p\ndef C(n,k):return fact[n]*inv[k]%p*inv[n-k]%p\nprint(sum(C(h-a-1+c,c)*C(a-1+w-1-c,a-1) for c in range(b,w))%p)\n",
'arc059_b':"s=input();answer=(-1,-1)\nfor i in range(len(s)-1):\n if s[i]==s[i+1]:answer=(i+1,i+2);break\n if i+2<len(s) and s[i]==s[i+2]:answer=(i+1,i+3);break\nprint(*answer)\n",
'arc060_b':"from math import isqrt\nn=int(input());s=int(input())\ndef f(b):\n v=n;total=0\n while v:total+=v%b;v//=b\n return total\nif n==s:print(n+1)\nelif n<s:print(-1)\nelse:\n answer=n+1\n for b in range(2,isqrt(n)+1):\n  if f(b)==s:answer=b;break\n if answer==n+1:\n  for leading in range(1,isqrt(n)+1):\n   if (n-s)%leading==0:\n    b=(n-s)//leading+1\n    if b>=2 and f(b)==s:answer=min(answer,b)\n print(answer if answer<=n else -1)\n",
'arc061_b':"from collections import defaultdict\nh,w,n=map(int,input().split());windows=defaultdict(int)\nfor _ in range(n):\n a,b=map(int,input().split())\n for r in range(a-2,a+1):\n  for c in range(b-2,b+1):\n   if 1<=r<=h-2 and 1<=c<=w-2:windows[(r,c)]+=1\nanswer=[0]*10;answer[0]=(h-2)*(w-2)-len(windows)\nfor count in windows.values():answer[count]+=1\nprint(*answer,sep='\\n')\n",
'arc062_b':"s=input();print(len(s)//2-s.count('p'))\n",
'arc063_b':"n,t=map(int,input().split());a=list(map(int,input().split()));minimum=a[0];best=0;count=0\nfor x in a[1:]:\n gain=x-minimum\n if gain>best:best=gain;count=1\n elif gain==best:count+=1\n minimum=min(minimum,x)\nprint(count)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18100+int(pid[3:6]));number=int(pid[3:6])
    if number==58:
        dims=[(2,2,1,1),(2,3,1,2),(3,2,2,1),(3,3,1,1)]
        for n in range(4,16):dims.append((n,n+2,rng.randint(1,n-1),rng.randint(1,n+1)))
        dims.extend([(100000,100000,1,1),(100000,100000,99999,99999)]);raws=[line(v) for v in dims]
    elif number==59:
        words=['aa','ab','aba','abc']
        for n in range(4,16):words.append(''.join(rng.choice('abcdef') for _ in range(n)))
        words.extend(['abcdefghijklmnopqrstuvwxyz'*3846+'abcd','z'*100000]);raws=[s+'\n' for s in words]
    elif number==60:
        pairs=[(1,1),(1,2),(2,1),(2,2)]+[(n*n+n+1,rng.randint(1,n*n+n+1)) for n in range(3,15)]+[(10**11,1),(10**11,10**11)];raws=[f'{n}\n{s}\n' for n,s in pairs]
    elif number==61:
        def board(h:int,w:int,a:list[tuple[int,int]])->str:return line((h,w,len(a)))+''.join(line(p) for p in a)
        raws=[board(3,3,[]),board(3,3,[(1,1)]),board(3,3,list(product_positions(3,3))),board(5,5,[(3,3)])]
        for n in range(4,16):
            cells=list(product_positions(n,n+2));rng.shuffle(cells);raws.append(board(n,n+2,cells[:n]))
        raws.extend([board(10**9,10**9,[(3*j+2,3*j+2) for j in range(100000)]),board(10**9,10**9,[(10**9-j,10**9) for j in range(100000)])])
    elif number==62:
        words=['g','gg','gp','ggp']
        for n in range(4,16):
            balance=0;s=''
            for j in range(n):ch=rng.choice('gp') if balance else 'g';s+=ch;balance+=1 if ch=='g' else -1
            words.append(s)
        words.extend(['gp'*50000,'g'*100000]);raws=[s+'\n' for s in words]
    else:
        def prices(a:list[int],t:int=2)->str:return line((len(a),t))+line(a)
        raws=[prices([1,2]),prices([2,1,3]),prices([1,3,2,4]),prices([3,1,4,2])]
        for n in range(5,17):
            a=rng.sample(range(1,10000),n)
            if all(a[j]<a[j-1] for j in range(1,n)):a.reverse()
            raws.append(prices(a,rng.randint(2,10**9)))
        # 50,000 independent equal-gain buy/sell pairs and a unique maximum.
        raws.extend([prices([v for j in range(50000) for v in (50000-j,10**9-j)],10**9),prices(list(range(10**9-99999,10**9+1)),10**9)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

def product_positions(h:int,w:int)->Iterator[tuple[int,int]]:
    return ((r,c) for r in range(1,h+1) for c in range(1,w+1))

HINTS={
'arc058_b':('禁止領域の境界を、経路が通過する位置で分類します。','禁止領域のすぐ上の行から下へ進む列を固定すると、その前後の経路数を二項係数で数えられます。','疑似コード: factorial/inverseを準備; c=B..W-1について C(H-A-1+c,c)×C(A-1+W-1-c,A-1) をmodで合計。'),
'arc059_b':('長いアンバランス区間があれば、同じ文字が近距離にも存在します。','隣り合う2文字、または1文字を挟んだ2文字が同じか調べれば十分です。','疑似コード: 全iでs[i]==s[i+1]ならi+1,i+2; s[i]==s[i+2]ならi+1,i+3を出力; なければ-1 -1。'),
'arc060_b':('小さい基数と大きい基数を分けて考えます。','b>sqrt(n)なら表記は2桁以下でn=p*b+q、s=p+qです。よってb=(n-s)/p+1を候補にできます。','疑似コード: n<sなら-1、n==sならn+1; b<=sqrt(n)を桁和検査; p<=sqrt(n)でn-sがpの倍数なら候補bを検査し最小を出力。'),
'arc061_b':('黒マスを含む3×3領域だけを列挙すると巨大な盤を扱えます。','1つの黒マスを含む左上座標は高々9個です。同じ領域を辞書でまとめます。','疑似コード: 各黒マス(r,c)からtop=r-2..r,left=c-2..cを範囲内ならcount++; histogram[count]を加算; zero=(H-2)(W-2)-辞書サイズ。'),
'arc062_b':('自分が出すパーの総数と、相手が出すパーの総数に注目します。','得点は自分のパー数から相手のパー数を引いた値です。グー、パーを交互に出せばパーをfloor(N/2)回使えます。','疑似コード: score=len(s)//2-s.count(p); scoreを出力。'),
'arc063_b':('最大の買値と売値の差を1下げる必要があります。','prefix最安値からの利益差の最大を調べます。価格が相異なるため、最大利益の買売ペアは互いに端点を共有しません。','疑似コード: minimum=A[0],best=0,count=0; 各価格xでgain=x-minimum; best更新ならcount=1、同値ならcount++; minimum更新; countを出力。')}

TITLES={'arc058_b': 'いろはちゃんとマス目', 'arc059_b': 'アンバランス', 'arc060_b': '桁和', 'arc061_b': 'すぬけ君の塗り絵', 'arc062_b': 'AtCoDeerくんと変なじゃんけん', 'arc063_b': '高橋君と見えざる手'}
PUBLISHED_SAMPLES={'arc058_b': [{'input': '2 3 1 1\n', 'expected': '2\n'}, {'input': '10 7 3 4\n', 'expected': '3570\n'}, {'input': '100000 100000 99999 99999\n', 'expected': '1\n'}, {'input': '100000 100000 44444 55555\n', 'expected': '738162020\n'}], 'arc059_b': [{'input': 'needed\n', 'expected': '2 5\n'}, {'input': 'atcoder\n', 'expected': '-1 -1\n'}], 'arc060_b': [{'input': '87654\n30\n', 'expected': '10\n'}, {'input': '87654\n138\n', 'expected': '100\n'}, {'input': '87654\n45678\n', 'expected': '-1\n'}, {'input': '31415926535\n1\n', 'expected': '31415926535\n'}, {'input': '1\n31415926535\n', 'expected': '-1\n'}], 'arc061_b': [{'input': '4 5 8\n1 1\n1 4\n1 5\n2 3\n3 1\n3 2\n3 4\n4 4\n', 'expected': '0\n0\n0\n2\n4\n0\n0\n0\n0\n0\n'}, {'input': '10 10 20\n1 1\n1 4\n1 9\n2 5\n3 10\n4 2\n4 7\n5 9\n6 4\n6 6\n6 7\n7 1\n7 3\n7 7\n8 1\n8 5\n8 10\n9 2\n10 4\n10 9\n', 'expected': '4\n26\n22\n10\n2\n0\n0\n0\n0\n0\n'}, {'input': '1000000000 1000000000 0\n', 'expected': '999999996000000004\n0\n0\n0\n0\n0\n0\n0\n0\n0\n'}], 'arc062_b': [{'input': 'gpg\n', 'expected': '0\n'}, {'input': 'ggppgggpgg\n', 'expected': '2\n'}], 'arc063_b': [{'input': '3 2\n100 50 200\n', 'expected': '1\n'}, {'input': '5 8\n50 30 40 10 20\n', 'expected': '2\n'}, {'input': '10 100\n7 10 4 5 9 3 6 8 2 1\n', 'expected': '2\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
