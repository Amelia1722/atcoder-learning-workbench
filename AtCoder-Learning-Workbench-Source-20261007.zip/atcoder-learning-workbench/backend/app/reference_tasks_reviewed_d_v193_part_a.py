"""Private ABC258..263 D: dominating records, physical piles, runs and factors."""
from __future__ import annotations
from collections import Counter
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(258,264));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
MOD=998244353

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def on_circle(point:tuple[int,int],circle:tuple[int,int,int])->bool:
    x,y,r=circle;return (point[0]-x)**2+(point[1]-y)**2==r*r

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc258_d':
        n,x=ints(rows[0],2);require(1<=n<=200000 and 1<=x<=10**9 and len(rows)==n+1,'N/X/shape');stages=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for row in stages for v in row),'A/B');return x,stages
    if pid=='abc259_d':
        n=ints(rows[0],1)[0];require(1<=n<=3000 and len(rows)==n+2,'N/shape');sx,sy,tx,ty=ints(rows[1],4);circles=tuple(ints(row,3) for row in rows[2:]);require(all(abs(x)<=10**9 and abs(y)<=10**9 and 1<=r<=10**9 for x,y,r in circles),'circle bounds');require(any(on_circle((sx,sy),c) for c in circles) and any(on_circle((tx,ty),c) for c in circles),'start/end circumference');return (sx,sy),(tx,ty),circles
    if pid=='abc260_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);require(1<=k<=n<=200000,'N/K');p=ints(rows[1],n);require(set(p)==set(range(1,n+1)),'permutation');return k,p
    if pid=='abc261_d':
        n,m=ints(rows[0],2);require(1<=m<=n<=5000 and len(rows)==m+2,'N/M/shape');x=ints(rows[1],n);bonus=tuple(ints(row,2) for row in rows[2:]);require(all(1<=v<=10**9 for v in x) and all(1<=c<=n and 1<=y<=10**9 for c,y in bonus) and len({c for c,y in bonus})==m,'coins/unique bonus');return x,bonus
    if pid=='abc262_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=100,'N');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'A');return (a,)
    require(len(rows)==2,'shape');n,l,r=ints(rows[0],3);require(1<=n<=200000 and abs(l)<=10**9 and abs(r)<=10**9,'N/L/R');a=ints(rows[1],n);require(all(abs(v)<=10**9 for v in a),'A');return l,r,a

def game_record_plans(x:int,stages:tuple[tuple[int,int],...])->int:
    record=10**10;total=0;answer=10**30
    for i,(a,b) in enumerate(stages[:x],1):
        total+=a+b
        if b<record:record=b;answer=min(answer,total+(x-i)*b)
    return answer

def circles_frontier(start:tuple[int,int],end:tuple[int,int],circles:tuple[tuple[int,int,int],...])->bool:
    frontier=[j for j,c in enumerate(circles) if on_circle(start,c)];targets={j for j,c in enumerate(circles) if on_circle(end,c)};remaining=set(range(len(circles)))-set(frontier)
    for index in frontier:
        if index in targets:return True
        x,y,r=circles[index];added=[]
        for other in remaining:
            xx,yy,rr=circles[other];squared=(x-xx)**2+(y-yy)**2
            if (r-rr)**2<=squared<=(r+rr)**2:added.append(other)
        for other in added:remaining.remove(other);frontier.append(other)
    return False

def physical_pile_tournament(k:int,p:tuple[int,...])->list[int]:
    n=len(p);base=1
    while base<=n:base*=2
    tree=[-1]*(2*base);piles:dict[int,list[int]]={};out=[-1]*n
    def update(value:int,present:bool)->None:
        i=base+value;tree[i]=value if present else -1;i//=2
        while i:tree[i]=max(tree[2*i],tree[2*i+1]);i//=2
    for turn,x in enumerate(p,1):
        if tree[1]<x:pile=[]
        else:
            node=1
            while node<base:node=2*node if tree[2*node]>=x else 2*node+1
            old=node-base;pile=piles.pop(old);update(old,False)
        pile.append(x)
        if len(pile)==k:
            for card in pile:out[card-1]=turn
        else:piles[x]=pile;update(x,True)
    return out

def coin_run_blocks(x:tuple[int,...],bonus:tuple[tuple[int,int],...])->int:
    n=len(x);rewards=[0]*(n+1)
    for c,y in bonus:rewards[c]=y
    for c in range(1,n+1):rewards[c]+=rewards[c-1]
    best=[0]*(n+1)
    for end in range(1,n+1):
        result=best[end-1];heads=0
        for length in range(1,end+1):
            heads+=x[end-length];prior=best[end-length-1] if end>length else 0;candidate=prior+heads+rewards[length]
            if candidate>result:result=candidate
        best[end]=result
    return best[-1]

def average_group_factors(a:tuple[int,...])->int:
    answer=0
    for target in range(1,len(a)+1):
        dp={(0,0):1}
        for residue,count in Counter(v%target for v in a).items():
            ways=[comb(count,t)%MOD for t in range(min(count,target)+1)];next_dp=dp.copy()
            for (degree,remainder),coefficient in dp.items():
                for selected in range(1,min(count,target-degree)+1):
                    key=(degree+selected,(remainder+residue*selected)%target)
                    if key[0]==target and key[1]!=0:continue
                    next_dp[key]=(next_dp.get(key,0)+coefficient*ways[selected])%MOD
            dp=next_dp
        answer=(answer+dp.get((target,0),0))%MOD
    return answer

def replace_three_phases(l:int,r:int,a:tuple[int,...])->int:
    left=original=right=0
    for value in a:left,original,right=left+l,min(left,original)+value,min(left,original,right)+r
    return min(left,original,right)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc258_d':return str(game_record_plans(*cast(tuple[int,tuple[tuple[int,int],...]],data)))+'\n'
    if pid=='abc259_d':return ('Yes' if circles_frontier(*cast(tuple[tuple[int,int],tuple[int,int],tuple[tuple[int,int,int],...]],data)) else 'No')+'\n'
    if pid=='abc260_d':return ''.join(str(v)+'\n' for v in physical_pile_tournament(*cast(tuple[int,tuple[int,...]],data)))
    if pid=='abc261_d':return str(coin_run_blocks(*cast(tuple[tuple[int,...],tuple[tuple[int,int],...]],data)))+'\n'
    if pid=='abc262_d':return str(average_group_factors(cast(tuple[int,...],data[0])))+'\n'
    return str(replace_three_phases(*cast(tuple[int,int,tuple[int,...]],data)))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc258_d':'''n,x=map(int,input().split());stages=[tuple(map(int,input().split())) for _ in range(n)];prefix=0;answer=10**30
for i,(a,b) in enumerate(stages[:x],1):prefix+=a+b;answer=min(answer,prefix+(x-i)*b)
print(answer)
''',
'abc259_d':'''n=int(input());sx,sy,tx,ty=map(int,input().split());circles=[tuple(map(int,input().split())) for _ in range(n)];parent=list(range(n));size=[1]*n
def find(v):
 while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
 return v
for i,(x,y,r) in enumerate(circles):
 for j in range(i):
  xx,yy,rr=circles[j];d=(x-xx)**2+(y-yy)**2
  if (r-rr)**2<=d<=(r+rr)**2:
   a,b=find(i),find(j)
   if a!=b:
    if size[a]<size[b]:a,b=b,a
    parent[b]=a;size[a]+=size[b]
start={find(i) for i,(x,y,r) in enumerate(circles) if (x-sx)**2+(y-sy)**2==r*r};end={find(i) for i,(x,y,r) in enumerate(circles) if (x-tx)**2+(y-ty)**2==r*r};print('Yes' if start&end else 'No')
''',
'abc260_d':'''n,k=map(int,input().split());p=list(map(int,input().split()));bit=[0]*(n+1);parent=list(range(n+1));size=[1]*(n+1);done=[-1]*(n+1);active=0
def find(v):
 while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
 return v
def add(v,delta):
 while v<=n:bit[v]+=delta;v+=v&-v
def prefix(v):
 result=0
 while v:result+=bit[v];v-=v&-v
 return result
def select(rank):
 at=0;step=1<<(n.bit_length()-1)
 while step:
  nxt=at+step
  if nxt<=n and bit[nxt]<rank:at=nxt;rank-=bit[nxt]
  step>>=1
 return at+1
for turn,x in enumerate(p,1):
 before=prefix(x-1)
 if before<active:
  old=select(before+1);add(old,-1);active-=1;root=find(old);parent[root]=x;size[x]+=size[root]
 if size[x]==k:done[x]=turn
 else:add(x,1);active+=1
print('\\n'.join(str(done[find(v)]) for v in range(1,n+1)))
''',
'abc261_d':'''n,m=map(int,input().split());x=list(map(int,input().split()));bonus=[0]*(n+1)
for _ in range(m):c,y=map(int,input().split());bonus[c]=y
dp=[0]
for value in x:dp=[max(dp)]+[score+value+bonus[count+1] for count,score in enumerate(dp)]
print(max(dp))
''',
'abc262_d':'''n=int(input());a=list(map(int,input().split()));mod=998244353;answer=0
for length in range(1,n+1):
 dp=[[0]*length for _ in range(length+1)];dp[0][0]=1
 for i,value in enumerate(a):
  shift=value%length
  for count in range(min(length-1,i),-1,-1):
   source=dp[count];dest=dp[count+1]
   for remainder,ways in enumerate(source):
    if ways:at=(remainder+shift)%length;dest[at]=(dest[at]+ways)%mod
 answer=(answer+dp[length][0])%mod
print(answer)
''',
'abc263_d':'''n,l,r=map(int,input().split());a=list(map(int,input().split()));left=[0]*(n+1);right=[0]*(n+1)
for i,x in enumerate(a,1):left[i]=min(left[i-1]+x,i*l)
for i in range(n-1,-1,-1):right[i]=min(right[i+1]+a[i],(n-i)*r)
print(min(left[i]+right[i] for i in range(n+1)))
'''}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(193000+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc258_d':
        def game(x:int,s:list[tuple[int,int]])->str:return line((len(s),x))+''.join(line(v) for v in s)
        raws=[game(1,[(1,1)]),game(10**9,[(10**9,10**9)]),game(1,[(1,2),(1,1)]),game(10,[(1,1),(1,10**9),(1,1)])]
        for n in range(2,14):raws.append(game(rng.choice([1,n,10**9]),[(rng.randrange(1,10**9+1),rng.randrange(1,10**9+1)) for _ in range(n)]))
        raws+=[game(10**9,[(1,200000-j) for j in range(200000)]),game(10**9,[(10**9,10**9)]*200000)]
    elif pid=='abc259_d':
        def circles(s:tuple[int,int],t:tuple[int,int],c:list[tuple[int,int,int]])->str:return str(len(c))+'\n'+line(s+t)+''.join(line(v) for v in c)
        raws=[circles((1,0),(-1,0),[(0,0,1)]),circles((2*10**9,10**9),(10**9,0),[(10**9,10**9,10**9)]),circles((1,0),(4,0),[(0,0,1),(3,0,1)]),circles((-2,0),(3,0),[(0,0,2),(2,0,1)])]
        for n in range(2,14):
            c=[(rng.randrange(-20,21),rng.randrange(-20,21),rng.randrange(1,11)) for _ in range(n)];s=(c[0][0]+c[0][2],c[0][1]);t=(c[-1][0]+c[-1][2],c[-1][1]);raws.append(circles(s,t,c))
        c=[(2*j,0,1) for j in range(3000)];raws.append(circles((-1,0),(5999,0),c));raws.append(circles((-2*10**9,-10**9),(2*10**9,10**9),[(-10**9,-10**9,10**9)]*2999+[(10**9,10**9,10**9)]))
    elif pid=='abc260_d':
        def deck(k:int,p:list[int])->str:return line((len(p),k))+line(p)
        raws=[deck(1,[1]),deck(1,[2,1]),deck(2,[2,1]),deck(2,[3,5,2,1,4])]
        for n in range(3,15):p=list(range(1,n+1));rng.shuffle(p);raws.append(deck(rng.randrange(1,n+1),p))
        raws+=[deck(1,list(range(1,200001))),deck(200000,list(range(200000,0,-1)))]
    elif pid=='abc261_d':
        def coin(x:list[int],b:list[tuple[int,int]])->str:return line((len(x),len(b)))+line(x)+''.join(line(v) for v in b)
        raws=[coin([1],[(1,1)]),coin([10**9],[(1,10**9)]),coin([1,1,1],[(1,10**9)]),coin([1,10,1,10],[(2,1)])]
        for n in range(2,14):
            counters=rng.sample(range(1,n+1),rng.randrange(1,n+1));raws.append(coin([rng.randrange(1,10**9+1) for _ in range(n)],[(c,rng.randrange(1,10**9+1)) for c in counters]))
        raws+=[coin([1]*5000,[(j,10**9 if j==1 else 1) for j in range(1,5001)]),coin([10**9]*5000,[(j,10**9) for j in range(5000,0,-1)])]
    elif pid=='abc262_d':
        arrays=[[1],[10**9],[1,2],[5]*5]+[[rng.randrange(1,10**9+1) for _ in range(n)] for n in range(3,15)]+[list(range(1,100))+[10**9],[10**9]*100];raws=[str(len(a))+'\n'+line(a) for a in arrays]
    else:
        def array(l:int,r:int,a:list[int])->str:return line((len(a),l,r))+line(a)
        raws=[array(0,0,[0]),array(-10**9,10**9,[10**9]),array(10**9,-10**9,[-10**9]),array(2,1,[3,-4,5])]
        for n in range(2,14):raws.append(array(rng.randrange(-10**9,10**9+1),rng.randrange(-10**9,10**9+1),[rng.randrange(-10**9,10**9+1) for _ in range(n)]))
        raws+=[array(-10**9,-10**9,[-10**9,10**9]*100000),array(10**9,10**9,[10**9]*200000)]
    require(len(raws)==len(set(raws))==18,'distinct18')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc258_d':('初めて遊ぶステージは、1番から順に解放する必要があります。','i番目まで初回クリアした後、そのステージを残りX-i回繰り返す候補を調べます。iはX以下だけ見れば十分です。','疑似コード: prefix=0; i=1..min(N,X)でprefix+=A_i+B_i; answer=min(answer,prefix+(X-i)*B_i); answerを出力。最適な再プレイ先より後の初回クリアは省けます。'),
'abc259_d':('二つの円周に共通点があれば、その円周同士を移動できます。','中心間の距離の二乗が、半径差の二乗以上かつ半径和の二乗以下なら円周が交わります。始点と終点を含む円が同じ成分か調べます。','疑似コード: 全円対で(r_i-r_j)^2<=距離^2<=(r_i+r_j)^2ならunion; 始点が円周上のroot集合と終点のroot集合が交わればYes、他はNo。'),
'abc260_d':('場にある各山の一番上の値だけで、次のカードの置き場所が決まります。','見えている値の集合でX以上の最小値を探します。山のサイズがKになったら消し、その山に属するカードの消滅時刻を記録します。','疑似コード: 各ターンXでtop>=Xの最小を順位検索; その山とXを同じ成分へ; サイズKなら成分の時刻を現在ターンにし山を消す、他はtop=Xとして登録; 各カードの成分時刻を出力。'),
'abc261_d':('直前まで連続で表が出た回数を状態に持ちます。','裏なら連続数0へ戻り、表なら連続数を一つ増やしてX_iと該当ボーナスを加えます。','疑似コード: dp[0]=0; 各Xでnext[0]=max(dp),next[j+1]=dp[j]+X+bonus[j+1]; dp=next; 最後のmax(dp)を出力。'),
'abc262_d':('選ぶ項数をkと固定すると、合計がkで割り切れるかを調べれば十分です。','kを1からNまで試し、選んだ個数と合計の余りを状態にするDPを行います。各項を一度だけ選ぶため個数を降順に更新します。','疑似コード: 各kでdp[0][0]=1; 各Aについて個数jを降順、余りrでdp[j+1][(r+A)%k]+=dp[j][r]; dp[k][0]を総和に足し、998244353で割る。'),
'abc263_d':('Lで置き換える先頭部分とRで置き換える末尾部分の境界を考えます。','先頭i個の最小総和と末尾i個の最小総和をそれぞれ計算し、全ての境界で合計します。後のRで上書きされる重なりは先頭部分を短くして解消できます。','疑似コード: left[i]=min(left[i-1]+A_i,i*L); right[i]=min(right[i+1]+A_i,(N-i)*R); 全iでleft[i]+right[i]の最小を出力。')}

TITLES={'abc258_d': 'Trophy', 'abc259_d': 'Circumferences', 'abc260_d': 'Draw Your Cards', 'abc261_d': 'Flipping and Bonus', 'abc262_d': 'I Hate Non-integer Number', 'abc263_d': 'Left Right Operation'}
PUBLISHED_SAMPLES={'abc258_d': [{'input': '3 4\n3 4\n2 3\n4 2\n', 'expected': '18\n'}, {'input': '10 1000000000\n3 3\n1 6\n4 7\n1 8\n5 7\n9 9\n2 4\n6 4\n5 1\n3 1\n', 'expected': '1000000076\n'}], 'abc259_d': [{'input': '4\n0 -2 3 3\n0 0 2\n2 0 2\n2 3 1\n-3 3 3\n', 'expected': 'Yes\n'}, {'input': '3\n0 1 0 3\n0 0 1\n0 0 2\n0 0 3\n', 'expected': 'No\n'}], 'abc260_d': [{'input': '5 2\n3 5 2 1 4\n', 'expected': '4\n3\n3\n-1\n4\n'}, {'input': '5 1\n1 2 3 4 5\n', 'expected': '1\n2\n3\n4\n5\n'}, {'input': '15 3\n3 14 15 9 2 6 5 13 1 7 10 11 8 12 4\n', 'expected': '9\n9\n9\n15\n15\n6\n-1\n-1\n6\n-1\n-1\n-1\n-1\n6\n15\n'}], 'abc261_d': [{'input': '6 3\n2 7 1 8 2 8\n2 10\n3 1\n5 5\n', 'expected': '48\n'}, {'input': '3 2\n1000000000 1000000000 1000000000\n1 1000000000\n3 1000000000\n', 'expected': '5000000000\n'}], 'abc262_d': [{'input': '3\n2 6 2\n', 'expected': '6\n'}, {'input': '5\n5 5 5 5 5\n', 'expected': '31\n'}], 'abc263_d': [{'input': '5 4 3\n5 5 0 6 3\n', 'expected': '14\n'}, {'input': '4 10 10\n1 2 3 4\n', 'expected': '10\n'}, {'input': '10 -5 -3\n9 -6 10 -1 2 10 -1 7 -15 5\n', 'expected': '-58\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
