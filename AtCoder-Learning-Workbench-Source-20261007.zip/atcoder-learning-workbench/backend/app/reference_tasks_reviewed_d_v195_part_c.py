"""Private ABC309/310/311/312/314/315 D; old-ready295 and interactive313 protected."""
from __future__ import annotations
from typing import cast
from functools import lru_cache
import heapq,re,random,math
TASKS=tuple(f'abc{n}_d' for n in (309,310,311,312,314,315));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};MOD=998244353
Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
    if pid=='abc309_d':
        n1,n2,m=ints(r[0],3);n=n1+n2;require(1<=n1<=150000 and 1<=n2<=150000 and 0<=m<=300000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=u<=v<=n and (u<=n1)==(v<=n1) for u,v in edges) and len(set(edges))==m,'edges');parent=list(range(n))
        def root(x:int)->int:
            while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
            return x
        for u,v in edges:
            a,b=root(u-1),root(v-1)
            if a!=b:parent[a]=b
        first,last=root(0),root(n-1);require(all(root(j)==(first if j<n1 else last) for j in range(n)),'two connected components');return n1,n2,edges
    if pid=='abc310_d':
        n,t,m=ints(r[0],3);require(1<=t<=n<=10 and 0<=m<=n*(n-1)//2 and len(r)==m+1,'shape');bad=tuple(ints(s,2) for s in r[1:]);require(all(1<=u<v<=n for u,v in bad) and len(set(bad))==m,'pairs');return n,t,bad
    if pid=='abc311_d':
        n,m=ints(r[0],2);grid=tuple(r[1:]);require(3<=n<=200 and 3<=m<=200 and len(grid)==n and all(re.fullmatch('[.#]{'+str(m)+'}',s) for s in grid),'grid');require(grid[0]==grid[-1]=='#'*m and all(s[0]==s[-1]=='#' for s in grid) and grid[1][1]=='.','border/start');return (grid,)
    if pid=='abc312_d':require(len(r)==1 and re.fullmatch('[()?]{1,3000}',r[0]) is not None,'brackets');return (r[0],)
    if pid=='abc314_d':
        n=ints(r[0],1)[0];require(1<=n<=500000 and len(r)>=4 and re.fullmatch('[a-zA-Z]{'+str(n)+'}',r[1]) is not None,'string');q=ints(r[2],1)[0];require(1<=q<=500000 and len(r)==q+3,'Q');queries=[]
        for row in r[3:]:
            match=re.fullmatch('([123]) (0|[1-9][0-9]*) ([a-zA-Z])',row);require(match is not None,'query');assert match is not None;t,x,c=int(match[1]),int(match[2]),match[3];require((1<=x<=n) if t==1 else (x==0 and c=='a'),'query fields');queries.append((t,x,c))
        return r[1],tuple(queries)
    h,w=ints(r[0],2);grid=tuple(r[1:]);require(2<=h<=2000 and 2<=w<=2000 and len(grid)==h and all(re.fullmatch('[a-z]{'+str(w)+'}',s) for s in grid),'cookies');return (grid,)

def bridge_heap(n1:int,n2:int,edges:tuple[tuple[int,...],...])->int:
    n=n1+n2;adj=[[] for _ in range(n)]
    for u,v in edges:adj[u-1].append(v-1);adj[v-1].append(u-1)
    def eccentricity(start:int)->int:
        d=[n+1]*n;d[start]=0;heap=[(0,start)];best=0
        while heap:
            dist,u=heapq.heappop(heap)
            if dist!=d[u]:continue
            best=max(best,dist)
            for v in adj[u]:
                if dist+1<d[v]:d[v]=dist+1;heapq.heappush(heap,(dist+1,v))
        return best
    return eccentricity(0)+eccentricity(n-1)+1

def team_subset_partition(n:int,t:int,bad:tuple[tuple[int,...],...])->int:
    good=[True]*(1<<n)
    for mask in range(1<<n):good[mask]=not any(mask>>(u-1)&1 and mask>>(v-1)&1 for u,v in bad)
    @lru_cache(None)
    def count(mask:int,left:int)->int:
        if not mask:return int(left==0)
        if left<=0 or mask.bit_count()<left:return 0
        anchor=mask&-mask;answer=0;sub=mask
        while sub:
            if sub&anchor and good[sub]:answer+=count(mask^sub,left-1)
            sub=(sub-1)&mask
        return answer
    return count((1<<n)-1,t)

def ice_segments(grid:tuple[str,...])->int:
    n,m=len(grid),len(grid[0]);horizontal={};vertical={}
    for i,row in enumerate(grid):
        j=0
        while j<m:
            if row[j]=='#':j+=1;continue
            start=j
            while j<m and row[j]=='.':j+=1
            for k in range(start,j):horizontal[i,k]=(start,j-1)
    for j in range(m):
        i=0
        while i<n:
            if grid[i][j]=='#':i+=1;continue
            start=i
            while i<n and grid[i][j]=='.':i+=1
            for k in range(start,i):vertical[k,j]=(start,i-1)
    seen={(1,1)};queue=[(1,1)];covered=[0]*n
    for i,j in queue:
        lo,hi=horizontal[i,j];covered[i]|=((1<<(hi-lo+1))-1)<<lo;top,bottom=vertical[i,j]
        for row in range(top,bottom+1):covered[row]|=1<<j
        for stop in [(i,lo),(i,hi),(top,j),(bottom,j)]:
            if stop not in seen:seen.add(stop);queue.append(stop)
    return sum(bits.bit_count() for bits in covered)

def bracket_reflection(s:str)->int:
    n=len(s)
    if n%2:return 0
    factorial=[1]*(n+1)
    for j in range(1,n+1):factorial[j]=factorial[j-1]*j%MOD
    inverse=[1]*(n+1);inverse[n]=pow(factorial[n],MOD-2,MOD)
    for j in range(n,0,-1):inverse[j-1]=inverse[j]*j%MOD
    def choose(length:int,count:int)->int:return factorial[length]*inverse[count]%MOD*inverse[length-count]%MOD if 0<=count<=length else 0
    states={0:1};i=0
    while i<n:
        if s[i]!='?':
            step=1 if s[i]=='(' else -1;states={height+step:value for height,value in states.items() if height+step>=0};i+=1;continue
        end=i
        while end<n and s[end]=='?':end+=1
        length=end-i;updated:dict[int,int]={}
        for height,value in states.items():
            for final in range((height+length)%2,min(height+length,n-end)+1,2):
                ways=(choose(length,(length+final-height)//2)-choose(length,(length+final+height+2)//2))%MOD
                if ways:updated[final]=(updated.get(final,0)+value*ways)%MOD
        states=updated;i=end
    return states.get(0,0)

def letter_backward(s:str,queries:tuple[tuple[int,int,str],...])->str:
    mode=0;resolved:dict[int,str]={}
    for t,x,c in reversed(queries):
        if t==1:
            if x-1 not in resolved:resolved[x-1]=c.lower() if mode==2 else c.upper() if mode==3 else c
        elif not mode:mode=t
    base=s.lower() if mode==2 else s.upper() if mode==3 else s
    return ''.join(resolved.get(j,c) for j,c in enumerate(base))

def cookies_bitsets(grid:tuple[str,...])->int:
    h,w=len(grid),len(grid[0]);row_bits:list[dict[str,int]]=[{} for _ in range(h)];col_bits:list[dict[str,int]]=[{} for _ in range(w)]
    for i,row in enumerate(grid):
        row_mask=1<<i
        for j,c in enumerate(row):row_bits[i][c]=row_bits[i].get(c,0)|(1<<j);col_bits[j][c]=col_bits[j].get(c,0)|row_mask
    rows=(1<<h)-1;cols=(1<<w)-1
    while rows and cols:
        first_row=(rows&-rows).bit_length()-1;first_col=(cols&-cols).bit_length()-1;remove_rows=remove_cols=0
        if cols.bit_count()>=2:
            remaining=rows
            while remaining:
                bit=remaining&-remaining;i=bit.bit_length()-1;remaining-=bit
                if row_bits[i].get(grid[i][first_col],0)&cols==cols:remove_rows|=bit
        if rows.bit_count()>=2:
            remaining=cols
            while remaining:
                bit=remaining&-remaining;j=bit.bit_length()-1;remaining-=bit
                if col_bits[j].get(grid[first_row][j],0)&rows==rows:remove_cols|=bit
        if not(remove_rows or remove_cols):break
        rows^=remove_rows;cols^=remove_cols
    return rows.bit_count()*cols.bit_count()

def oracle(pid:str,raw:str)->str:
    d=validate(pid,raw)
    if pid=='abc309_d':return str(bridge_heap(cast(int,d[0]),cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2])))
    if pid=='abc310_d':return str(team_subset_partition(cast(int,d[0]),cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2])))
    if pid=='abc311_d':return str(ice_segments(cast(tuple[str,...],d[0])))
    if pid=='abc312_d':return str(bracket_reflection(cast(str,d[0])))
    if pid=='abc314_d':return letter_backward(cast(str,d[0]),cast(tuple[tuple[int,int,str],...],d[1]))
    return str(cookies_bitsets(cast(tuple[str,...],d[0])))
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:return output_mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={'abc309_d': 'import sys\nfrom collections import deque\nit=iter(map(int,sys.stdin.buffer.read().split()));n1,n2,m=next(it),next(it),next(it);n=n1+n2;g=[[] for _ in range(n)]\nfor _ in range(m):u,v=next(it)-1,next(it)-1;g[u].append(v);g[v].append(u)\ndef far(start):\n d=[-1]*n;d[start]=0;q=deque([start])\n while q:\n  u=q.popleft()\n  for v in g[u]:\n   if d[v]<0:d[v]=d[u]+1;q.append(v)\n return max(d)\nprint(far(0)+far(n-1)+1)\n', 'abc310_d': 'import sys\nit=iter(map(int,sys.stdin.buffer.read().split()));n,t,m=next(it),next(it),next(it);bad=[0]*n\nfor _ in range(m):a,b=next(it)-1,next(it)-1;bad[a]|=1<<b;bad[b]|=1<<a\nteams=[]\ndef count(person):\n if person==n:return int(len(teams)==t)\n if len(teams)+n-person<t:return 0\n answer=0\n for j in range(len(teams)):\n  if not teams[j]&bad[person]:teams[j]|=1<<person;answer+=count(person+1);teams[j]^=1<<person\n if len(teams)<t:teams.append(1<<person);answer+=count(person+1);teams.pop()\n return answer\nprint(count(0))\n', 'abc311_d': "import sys\nn,m=map(int,input().split());g=[input() for _ in range(n)];moves=[(-1,0),(1,0),(0,-1),(0,1)];seen=set();cells={(1,1)};stack=[(1,1,k) for k in range(4)]\nwhile stack:\n i,j,k=stack.pop()\n if (i,j,k) in seen:continue\n seen.add((i,j,k));di,dj=moves[k];ii,jj=i+di,j+dj\n if g[ii][jj]=='.':cells.add((ii,jj));stack.append((ii,jj,k))\n else:\n  for nextdir in range(4):\n   if (i,j,nextdir) not in seen:stack.append((i,j,nextdir))\nprint(len(cells))\n", 'abc312_d': "s=input();n=len(s);mod=998244353;dp=[0]*(n+1);dp[0]=1\nfor c in s:\n nxt=[0]*(n+1)\n for height,value in enumerate(dp):\n  if c!=')' and height<n:nxt[height+1]=(nxt[height+1]+value)%mod\n  if c!='(' and height>0:nxt[height-1]=(nxt[height-1]+value)%mod\n dp=nxt\nprint(dp[0])\n", 'abc314_d': "import sys\nn=int(input());s=list(input());q=int(input());last=-1;mode=0;rows=[]\nfor j in range(q):\n t,x,c=input().split();t=int(t);x=int(x);rows.append((t,x,c))\n if t!=1:last=j;mode=t\nfor j,(t,x,c) in enumerate(rows):\n if t==1:s[x-1]=c\n if j==last:s=list(''.join(s).lower() if mode==2 else ''.join(s).upper())\nprint(''.join(s))\n", 'abc315_d': 'import sys\nh,w=map(int,input().split());g=[list(input().encode()) for _ in range(h)];rc=[[0]*26 for _ in range(h)];cc=[[0]*26 for _ in range(w)]\nfor i in range(h):\n for j in range(w):c=g[i][j]-97;g[i][j]=c;rc[i][c]+=1;cc[j][c]+=1\nrd=[sum(v>0 for v in row) for row in rc];cd=[sum(v>0 for v in col) for col in cc];alive_r=set(range(h));alive_c=set(range(w));cand_r={i for i in alive_r if rd[i]==1};cand_c={j for j in alive_c if cd[j]==1}\nwhile True:\n rows={i for i in cand_r if i in alive_r and rd[i]==1 and len(alive_c)>=2};cols={j for j in cand_c if j in alive_c and cd[j]==1 and len(alive_r)>=2}\n if not rows and not cols:break\n alive_r-=rows;alive_c-=cols;cand_r=set();cand_c=set()\n for i in rows:\n  for j in alive_c:\n   c=g[i][j];cc[j][c]-=1\n   if cc[j][c]==0:cd[j]-=1\n   if cd[j]==1:cand_c.add(j)\n for j in cols:\n  for i in alive_r:\n   c=g[i][j];rc[i][c]-=1\n   if rc[i][c]==0:rd[i]-=1\n   if rd[i]==1:cand_r.add(i)\nprint(len(alive_r)*len(alive_c))\n'}
TITLES:dict[str,str]={'abc309_d': 'Add One Edge', 'abc310_d': 'Peaceful Teams', 'abc311_d': 'Grid Ice Floor', 'abc312_d': 'Count Bracket Sequences', 'abc314_d': 'LOWER', 'abc315_d': 'Magical Cookies'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'abc309_d': [{'input': '3 4 6\n1 2\n2 3\n4 5\n4 6\n1 3\n6 7\n', 'expected': '5\n'}, {'input': '7 5 20\n10 11\n4 5\n10 12\n1 2\n1 5\n5 6\n2 4\n3 5\n9 10\n2 5\n1 4\n11 12\n9 12\n8 9\n5 7\n3 7\n3 6\n3 4\n8 12\n9 11\n', 'expected': '4\n'}], 'abc310_d': [{'input': '5 2 2\n1 3\n3 4\n', 'expected': '4\n'}, {'input': '5 1 2\n1 3\n3 4\n', 'expected': '0\n'}, {'input': '6 4 0\n', 'expected': '65\n'}, {'input': '10 6 8\n5 9\n1 4\n3 8\n1 6\n4 10\n5 7\n5 6\n3 7\n', 'expected': '8001\n'}], 'abc311_d': [{'input': '6 6\n######\n#....#\n#.#..#\n#..#.#\n#....#\n######\n', 'expected': '12\n'}, {'input': '21 25\n#########################\n#..............###...####\n#..............#..#...###\n#........###...#...#...##\n#........#..#..#........#\n#...##...#..#..#...#....#\n#..#..#..###...#..#.....#\n#..#..#..#..#..###......#\n#..####..#..#...........#\n#..#..#..###............#\n#..#..#.................#\n#........##.............#\n#.......#..#............#\n#..........#....#.......#\n#........###...##....#..#\n#..........#..#.#...##..#\n#.......#..#....#..#.#..#\n##.......##.....#....#..#\n###.............#....#..#\n####.................#..#\n#########################\n', 'expected': '215\n'}], 'abc312_d': [{'input': '(???(?\n', 'expected': '2\n'}, {'input': ')))))\n', 'expected': '0\n'}, {'input': '??????????????(????????(??????)?????????(?(??)\n', 'expected': '603032273\n'}], 'abc314_d': [{'input': '7\nAtCoder\n5\n1 4 i\n3 0 a\n1 5 b\n2 0 a\n1 4 Y\n', 'expected': 'atcYber\n'}, {'input': '35\nTheQuickBrownFoxJumpsOverTheLazyDog\n10\n2 0 a\n1 19 G\n1 13 m\n1 2 E\n1 21 F\n2 0 a\n1 27 b\n3 0 a\n3 0 a\n1 15 i\n', 'expected': 'TEEQUICKBROWMFiXJUGPFOVERTBELAZYDOG\n'}], 'abc315_d': [{'input': '4 3\naaa\naaa\nabc\nabd\n', 'expected': '2\n'}, {'input': '2 5\naaaaa\nabcde\n', 'expected': '4\n'}, {'input': '3 3\nooo\nooo\nooo\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={pid:len(cases) for pid,cases in PUBLISHED_SAMPLES.items()}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(int(pid[3:6]));raws:list[str]=[]
    if pid=='abc309_d':
        def pack(n1:int,n2:int,edges:list[tuple[int,int]])->str:return line((n1,n2,len(edges)))+''.join(line(e) for e in edges)
        raws=[pack(1,1,[]),pack(1,1,[(1,1)]),pack(2,2,[(1,2),(3,4)]),pack(3,1,[(1,2),(1,3),(4,4)])]
        for j in range(12):
            n1=j+3;n2=j+2;edges={(i,i+1) for i in range(1,n1)}|{(i,i+1) for i in range(n1+1,n1+n2)}
            for _ in range(j+1):
                lo,hi=(1,n1) if rng.randrange(2)==0 else (n1+1,n1+n2);edges.add(tuple(sorted((rng.randint(lo,hi),rng.randint(lo,hi)))))
            raws.append(pack(n1,n2,sorted(edges)))
        raws.extend([pack(150000,150000,[(1,i) for i in range(2,150001)]+[(150001,i) for i in range(150002,300001)]+[(1,1),(300000,300000)]),pack(150000,150000,[(i,i+1) for i in range(1,150000)]+[(i,i+1) for i in range(150001,300000)]+[(1,1),(300000,300000)])])
    elif pid=='abc310_d':
        def pack(n:int,t:int,bad:list[tuple[int,int]])->str:return line((n,t,len(bad)))+''.join(line(e) for e in bad)
        raws=[pack(1,1,[]),pack(2,1,[(1,2)]),pack(2,2,[(1,2)]),pack(3,2,[])]
        for j in range(12):
            n=3+j%8;t=1+j//8;bad=[(u,v) for u in range(1,n+1) for v in range(u+1,n+1) if rng.randrange(3)==0];raw=pack(n,t,bad)
            if raw in raws:raw=pack(n,n,bad)
            raws.append(raw)
        raws.extend([pack(10,5,[]),pack(10,10,[(u,v) for u in range(1,11) for v in range(u+1,11)])])
    elif pid=='abc311_d':
        def pack(grid:list[str])->str:return line((len(grid),len(grid[0])))+'\n'.join(grid)+'\n'
        raws=[pack(['###','#.#','###']),pack(['####','#..#','####']),pack(['#####','#...#','#.#.#','#...#','#####']),pack(['#####','#.###','###.#','#####'])]
        for j in range(12):
            n=j+5;w=j+4;grid=['#'*w]+['#'+''.join('.' if rng.randrange(3) else '#' for _ in range(w-2))+'#' for _ in range(n-2)]+['#'*w];grid[1]='#.'+grid[1][2:];raws.append(pack(grid))
        raws.extend([pack(['#'*200]+['#'+''.join('.' if r%2==0 or c==1 or c==198 else '#' for c in range(1,199))+'#' for r in range(1,199)]+['#'*200]),pack(['#'*200]+['#'+'.'*198+'#']*198+['#'*200])])
    elif pid=='abc312_d':
        raws=['(\n','?\n','()\n','??\n']
        for j in range(12):raws.append(''.join(rng.choice('()?') for _ in range(j+7))+'\n')
        raws.extend(['('*750+'?'*1500+')'*750+'\n','?'*3000+'\n'])
    elif pid=='abc314_d':
        def pack(s:str,q:list[tuple[int,int,str]])->str:return f'{len(s)}\n{s}\n{len(q)}\n'+''.join(f'{t} {x} {c}\n' for t,x,c in q)
        raws=[pack('a',[(1,1,'a')]),pack('Z',[(2,0,'a')]),pack('aB',[(3,0,'a'),(1,1,'c')]),pack('Ab',[(1,1,'Z'),(2,0,'a'),(1,2,'Y')])]
        for j in range(12):
            n=j+3;q=[]
            for _ in range(j+7):
                t=rng.randint(1,3);q.append((1,rng.randint(1,n),rng.choice('aAbBzZ')) if t==1 else (t,0,'a'))
            raws.append(pack(''.join(rng.choice('aAbBzZ') for _ in range(n)),q))
        raws.extend([pack('Z'*500000,[(1,500000,'A' if j%2 else 'z') for j in range(499999)]+[(2,0,'a')]),pack('Z'*500000,[(3 if j%2 else 2,0,'a') for j in range(500000)])])
    else:
        def pack(grid:list[str])->str:return line((len(grid),len(grid[0])))+'\n'.join(grid)+'\n'
        raws=[pack(['aa','aa']),pack(['ab','ba']),pack(['aa','ab']),pack(['abc','abc'])]
        for j in range(12):raws.append(pack([''.join(rng.choice('abc') for _ in range(j+3)) for _ in range(j+2)]))
        raws.extend([pack(['a'*(i+1)+'b'*(1999-i) for i in range(2000)]),pack(['a'*2000]*2000)])
    require(len(raws)==len(set(raws))==18,'18 distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'random'} for j,raw in enumerate(raws)]
HINTS:dict[str,tuple[str,str,str]]={
'abc309_d':('追加した辺を通る前後の最短距離を考えます。','頂点1から前半の各頂点、最終頂点から後半の各頂点への距離をBFSで求め、それぞれ最大の距離を選びます。','疑似コード: 無向隣接リストを作る。BFS(1)とBFS(N1+N2)で距離を求める。各距離配列の最大値の和に追加辺の1を足して出力。'),
'abc310_d':('選手を番号順に、既存チームか新しいチームへ入れます。','チームを作る順序を固定すると同じ分割を重複して数えません。各チームの選手集合をビットで持ち、相性の悪い相手がいないか確認します。','疑似コード: DFS(i)で既存の各teamにbad[i]&team==0ならiを追加して再帰し戻す。team数<Tなら新team{i}を追加して再帰し戻す。i=Nでteam数=Tなら1、他0を返し総和を出す。'),
'abc311_d':('停止位置だけでなく、移動している方向も状態にすると通過マスを数えられます。','位置と方向の組を探索します。前が氷なら同方向へ1マス進み、岩なら今いる位置で四方向へ切り替えます。','疑似コード: (2,2,四方向)をstackへ入れる。未訪問の(位置,方向)を取り出し、前が氷ならそのマスを到達集合へ入れ同方向状態を追加。岩なら同位置の四方向状態を追加。到達集合の大きさを出力。'),
'abc312_d':('左括弧の数から右括弧の数を引いた値が、どの接頭辞でも負にならない条件を使います。','処理した文字までの括弧の差を状態にし、?は左右両方へ遷移させます。最後に差が0の通り数が答えです。','疑似コード: dp[0]=1。各文字cで次配列を0にし、c!=右括弧なら高さh+1へ、c!=左括弧かつh>0ならh-1へdp[h]を加算する。998244353で剰余をとり、最後dp[0]を出力。'),
'abc314_d':('全体の大文字・小文字変換は、最後のものだけがそれ以前の文字に影響します。','最後の全体変換の位置を先に調べます。操作を順に再生し、その位置でだけ文字列全体を変換します。','疑似コード: 全queryを読み、t=2/3の最後のindexとmodeを記録。順にqueryを処理し、t=1ならS[x-1]=c。最後の全体変換indexに来たらmodeに従いS全体をlower/upperにする。Sを出力。'),
'abc315_d':('同じ色だけが2枚以上残る行・列を、同じ回の状態からまとめて削除します。','行別・列別の26色の個数と色種類数を持ちます。削除した行・列と交差する生存側だけを更新し、次に一色になった候補を集めます。','疑似コード: 各行列の色個数/種類数を集計。候補から、生存かつ種類1かつ反対側の残数>=2の行列を同時に選ぶ。両方を生存集合から除き、削除行×生存列と削除列×生存行で個数を減らし新候補を集める。候補が空になれば残行数×残列数を出す。')}
