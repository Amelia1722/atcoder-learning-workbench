"""ABC044–046 B: task-specific, manually reviewed public specifications (HTML not archived)."""
from __future__ import annotations
import random
import re
from collections import deque

TASKS = ('abc044_b', 'abc045_b', 'abc046_b')
INTEGER = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)
CARDS = re.compile(r'[abc]+', re.ASCII)
LIMIT = 2**31 - 1


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown task or noncanonical input')
    lines = raw[:-1].split('\n')
    if pid == 'abc044_b':
        if len(lines) != 1 or not 1 <= len(lines[0]) <= 100 or LOWER.fullmatch(lines[0]) is None:
            raise ValueError('w must be 1..100 ASCII lowercase letters')
        return lines[0]
    if pid == 'abc045_b':
        if len(lines) != 3 or any(not 1 <= len(s) <= 100 or CARDS.fullmatch(s) is None for s in lines):
            raise ValueError('exactly three 1..100-card decks in {a,b,c}')
        return tuple(lines)
    if len(lines) != 1:
        raise ValueError('expected one N K line')
    tokens = lines[0].split(' ')
    if len(tokens) != 2 or any(INTEGER.fullmatch(token) is None for token in tokens):
        raise ValueError('expected two canonical integers')
    n, k = map(int, tokens)
    if not 1 <= n <= 1000 or not 2 <= k <= 1000:
        raise ValueError('N K outside constraints')
    # The official bound is a constraint ON INPUTS, not merely an output type.
    if k * pow(k - 1, n - 1) > LIMIT:
        raise ValueError('official bound: the answer must be <= 2**31-1')
    return n, k


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        data = validate(pid, raw)
    except (ValueError, TypeError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc044_b':
        # Independent parity toggling instead of Counter-based frequency counting.
        odd = set()
        for ch in data:
            if ch in odd: odd.remove(ch)
            else: odd.add(ch)
        return output == ('No' if odd else 'Yes')
    if pid == 'abc045_b':
        # Independent deque simulation; local reference uses cursors, not deque.
        decks = [deque(deck) for deck in data]
        player = 0
        while decks[player]:
            player = ord(decks[player].popleft()) - ord('a')
        return output == 'ABC'[player]
    n, k = data
    # Independent iterative DP; local reference uses pow.
    ways = k
    for _ in range(n - 1):
        ways *= k - 1
    return output == str(ways)


def generate(pid: str, seed: int = 62) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    rng = random.Random(f'abc-v62:{pid}:{seed}')
    rows: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            rows.append({'category': category, 'input': raw})
            seen.add(raw)
    if pid == 'abc044_b':
        fixtures = ['a','aa','ab','aabb','abcabc','z'*99,'z'*98,'a'*100,
                    'a'*99+'b','abcdefghijklmnopqrstuvwxyz'*2,
                    'abcdefghijklmnopqrstuvwxyz'*3,'a'*50+'b'*50,
                    'a'*49+'b'*51,'ab'*50]
        for w in fixtures: add('boundary' if len(w) in (1, 100) else 'normal',w+'\n')
        while len(rows) < 17:
            w = ''.join(rng.choice('abcxyz') for _ in range(rng.randint(1,100)))
            add('random',w+'\n')
        add('constraint_max','abcdefghijklmnopqrstuvwxyz'*3+'abcdefghijklmnopqrstuv'+'\n')
    elif pid == 'abc045_b':
        fixtures = [('a','b','c'),('b','a','c'),('c','b','a'),('aaa','a','c'),
                    ('bbb','aaa','ccc'),('aca','accc','ca'),('abcb','aacb','bccc'),
                    ('a'*20,'b','c'),('b'*20,'a'*20,'c'*20),
                    ('abc'*20,'cba'*20,'bac'*20),('c'*50,'b'*50,'a'*50),
                    ('a'*99,'b'*99,'c'*99)]
        for decks in fixtures:
            add('boundary' if min(map(len,decks))==1 else 'normal','\n'.join(decks)+'\n')
        while len(rows) < 17:
            decks = [''.join(rng.choice('abc') for _ in range(rng.randint(1,100))) for _ in range(3)]
            add('random','\n'.join(decks)+'\n')
        add('constraint_max','a'*100+'\n'+'b'*100+'\n'+'c'*100+'\n')
    else:
        fixtures = [(1,2),(1,1000),(2,2),(2,1000),(3,2),(3,3),(4,4),
                    (10,8),(100,2),(999,2),(5,10),
                    (10,3),(6,15)]
        for n,k in fixtures:
            add('boundary' if n in (1,1000) or k==1000 else 'normal',f'{n} {k}\n')
        while len(rows) < 17:
            k = rng.randint(2,1000)
            n = rng.randint(1,1000 if k == 2 else 12)
            try: add('random',f'{n} {k}\n')
            except ValueError: continue
        add('constraint_max','1000 2\n')
    if len(rows) != 18 or rows[-1]['category']!='constraint_max' or len({r['input'] for r in rows}) != 18:
        raise ValueError(f'{pid}: 18 distinct cases with last constraint_max required; got {len(rows)}')
    return rows
