"""ABC125–128 A–C (excluding already curated ABC128 C).

Problem statements and samples verified against the official task pages.
Reference solutions are separately authored in data/reference_solutions.
Only inputs and independently checked expected outputs are published.
"""
from __future__ import annotations

from math import gcd
from random import Random
import re

SAMPLES = {
    'abc125_a': ('3 5 7\n', '10', '1<=A,B,T<=20'),
    'abc125_b': ('3\n10 2 5\n6 3 4\n', '5', '1<=N<=20; 1<=Vi,Ci<=50'),
    'abc125_c': ('3\n7 6 8\n', '2', '2<=N<=100000; 1<=Ai<=1000000000'),
    'abc126_a': ('3 1\nABC\n', 'aBC', '1<=N<=50; 1<=K<=N; S consists of A,B,C'),
    'abc126_b': ('1905\n', 'YYMM', 'S is exactly four digits, leading zeros allowed'),
    'abc126_c': ('3 10\n', '0.145833333333', '1<=N,K<=100000; absolute or relative error <=1e-9'),
    'abc127_a': ('30 100\n', '100', '0<=A<=100; 2<=B<=1000; B is even'),
    'abc127_b': ('2 10 20\n', '30\n50\n90\n170\n330\n650\n1290\n2570\n5130\n10250',
                 '2<=r<=5; 1<=D<=100; D<x2000<=200'),
    'abc127_c': ('4 2\n1 3\n2 4\n', '2', '1<=N,M<=100000; 1<=Li<=Ri<=N'),
    'abc128_a': ('1 3\n', '3', '0<=A,P<=100'),
    'abc128_b': ('6\nkhabarovsk 20\nmoscow 10\nkazan 50\nkazan 35\nmoscow 60\nkhabarovsk 40\n',
                 '3\n4\n6\n1\n5\n2',
                 '1<=N<=100; 1<=len(Si)<=10 lowercase a-z; 0<=Pi<=100; Pi are pairwise distinct'),
}
BATCH15 = {pid: {'sample_input': sample, 'sample_output': output,
                 'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                 'constraints': constraints}
           for pid, (sample, output, constraints) in SAMPLES.items()}
_INTEGER = re.compile(r'(?:0|[1-9][0-9]*)\Z')
_WORD = re.compile(r'[a-z]{1,10}\Z')


def _ints(values: list[str], length: int | None = None) -> list[int]:
    if not values or (length is not None and len(values) != length) or any(_INTEGER.fullmatch(x) is None for x in values):
        raise ValueError('integer count or token format invalid')
    return [int(x) for x in values]


def validate(pid: str, data: str):
    if pid not in BATCH15:
        raise ValueError('unknown task')
    lines = data.strip().splitlines()
    if pid == 'abc126_b':
        if len(lines) != 1 or re.fullmatch(r'[0-9]{4}', lines[0]) is None:
            raise ValueError('exactly four ASCII digits required')
        return lines[0]
    if pid == 'abc126_a':
        if len(lines) != 2:
            raise ValueError('N K + S required')
        n, k = _ints(lines[0].split(), 2)
        if not 1 <= n <= 50 or not 1 <= k <= n or re.fullmatch(r'[ABC]{'+str(n)+'}', lines[1]) is None:
            raise ValueError('N K or ABC string invalid')
        return n, k, lines[1]
    if pid in ('abc125_b', 'abc125_c'):
        if len(lines) != (3 if pid == 'abc125_b' else 2):
            raise ValueError('N and array rows required')
        n, = _ints(lines[0].split(), 1)
        lo, hi = (1, 20) if pid == 'abc125_b' else (2, 100000)
        if not lo <= n <= hi:
            raise ValueError('N outside range')
        arrays = [_ints(line.split(), n) for line in lines[1:]]
        upper = 50 if pid == 'abc125_b' else 10**9
        if any(not 1 <= x <= upper for arr in arrays for x in arr):
            raise ValueError('array value outside range')
        return (n, *arrays)
    if pid == 'abc127_c':
        if not lines:
            raise ValueError('missing header')
        n, m = _ints(lines[0].split(), 2)
        if not 1 <= n <= 100000 or not 1 <= m <= 100000 or len(lines) != m+1:
            raise ValueError('N M or gate count invalid')
        ranges = [_ints(line.split(), 2) for line in lines[1:]]
        if any(not 1 <= l <= r <= n for l, r in ranges):
            raise ValueError('range invalid')
        return n, m, ranges
    if pid == 'abc128_b':
        if not lines:
            raise ValueError('missing N')
        n, = _ints(lines[0].split(), 1)
        if not 1 <= n <= 100 or len(lines) != n+1:
            raise ValueError('N/restaurant count invalid')
        restaurants=[]; scores=set()
        for line in lines[1:]:
            pair=line.split()
            if len(pair) != 2 or _WORD.fullmatch(pair[0]) is None:
                raise ValueError('restaurant name invalid')
            points, = _ints(pair[1:], 1)
            if not 0 <= points <= 100 or points in scores:
                raise ValueError('score invalid or duplicate')
            scores.add(points); restaurants.append((pair[0], points))
        return restaurants
    fields = _ints(data.split())
    if pid == 'abc125_a':
        if len(fields) != 3 or any(not 1 <= x <= 20 for x in fields):
            raise ValueError('A B T invalid')
    elif pid == 'abc126_c':
        if len(fields) != 2 or any(not 1 <= x <= 100000 for x in fields):
            raise ValueError('N K invalid')
    elif pid == 'abc127_a':
        if len(fields) != 2 or not 0 <= fields[0] <= 100 or not 2 <= fields[1] <= 1000 or fields[1]%2:
            raise ValueError('age/even price invalid')
    elif pid == 'abc127_b':
        if len(fields) != 3 or not 2 <= fields[0] <= 5 or not 1 <= fields[1] <= 100 or not fields[1] < fields[2] <= 200:
            raise ValueError('r D x invalid')
    elif pid == 'abc128_a':
        if len(fields) != 2 or any(not 0 <= x <= 100 for x in fields):
            raise ValueError('apples/pieces invalid')
    else:
        raise ValueError('unknown numeric task')
    return tuple(fields)


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str, str]]:
    if pid not in BATCH15 or not 1 <= count <= 80:
        raise ValueError('unknown task or invalid count')
    rnd=Random(seed); cases=[]; seen=set()
    def add(kind: str, data: str) -> None:
        validate(pid, data)
        if data not in seen:
            seen.add(data)
            cases.append({'category':kind, 'input':data})
    def ints(kind: str, *a: int) -> None:
        add(kind, ' '.join(map(str, a))+'\n')
    def array(kind: str, arr: list[int], costs: list[int] | None = None) -> None:
        add(kind, f'{len(arr)}\n'+' '.join(map(str,arr))+'\n'+(' '.join(map(str,costs))+'\n' if costs is not None else ''))
    def gates(kind: str, n: int, intervals: list[tuple[int,int]]) -> None:
        add(kind, f'{n} {len(intervals)}\n'+'\n'.join(f'{l} {r}' for l,r in intervals)+'\n')
    def restaurants(kind: str, items: list[tuple[str,int]]) -> None:
        add(kind, f'{len(items)}\n'+'\n'.join(f'{city} {points}' for city,points in items)+'\n')

    # Always include the published sample before the problem-specific boundaries.
    add('sample', BATCH15[pid]['sample_input'])
    if pid=='abc125_a':
        for a,b,t in [(1,1,1),(20,20,20),(20,20,19),(1,20,20),(20,1,1),(3,5,6),(3,5,5),
                      (2,1,20),(7,8,14),(6,6,12),(2,20,19),(19,20,20)]:
            ints('boundary',a,b,t)
        while len(cases)<count: ints('random',*(rnd.randint(1,20) for _ in range(3)))
        maximum='20 20 20\n'
    elif pid=='abc125_b':
        for v,c in [([1],[50]),([50],[1]),([1],[1]),([50]*20,[1]*20),([1]*20,[50]*20),
                    ([50]*20,[50]*20),([i+1 for i in range(20)],[20-i for i in range(20)]),
                    ([10,2,5],[6,3,4]),([13,21,6,19],[11,30,6,15]),([1,50]*10,[50,1]*10),
                    ([1]*19+[50],[50]*19+[1])]:array('boundary',v,c)
        while len(cases)<count:
            n=rnd.randint(1,20);array('random',[rnd.randint(1,50) for _ in range(n)],[rnd.randint(1,50) for _ in range(n)])
        maximum='20\n'+' '.join(['50']*20)+'\n'+' '.join(['1']*20)+'\n'
    elif pid=='abc125_c':
        for arr in [[1,1],[10**9,10**9],[1,10**9],[7,6,8],[12,15,18],[2,3],
                    [6,10,15,35],[7]*20,[6]*19+[7],[2,4,8,16,32],[10**9-1,10**9],
                    list(range(1,20))]:array('boundary',arr)
        while len(cases)<count:
            n=rnd.randint(2,35);array('random',[rnd.randint(1,10**9) for _ in range(n)])
        maximum='100000\n'+' '.join(str(10**9 if i%2 else 999999937) for i in range(100000))+'\n'
    elif pid=='abc126_a':
        def edit(kind,s,k):add(kind,f'{len(s)} {k}\n{s}\n')
        for s,k in [('A',1),('C',1),('ABC',1),('ABC',3),('CABA',3),('A'*50,1),('C'*50,50),
                    ('ABC'*16+'AB',25),('ABC'*16+'AB',50),('B'*50,2),('AC',2),('BC',1)]:edit('boundary',s,k)
        while len(cases)<count:
            s=''.join(rnd.choices('ABC',k=rnd.randint(1,50)));edit('random',s,rnd.randint(1,len(s)))
        maximum='50 50\n'+'ABC'*16+'AB\n'
    elif pid=='abc126_b':
        for s in ['0000','0001','0012','0100','0101','0112','1201','1212','1299','1301','9912',
                  '9999','1905','0113','1300','0013','1234','0109','1200','0009']:
            add('boundary',s+'\n')
        while len(cases)<count:add('random',f'{rnd.randint(0,9999):04d}\n')
        maximum='9999\n'
    elif pid=='abc126_c':
        for n,k in [(1,1),(1,100000),(100000,1),(100000,100000),(100000,5),(3,10),
                    (1,2),(1,3),(2,3),(3,3),(100000,99999),(99999,100000),
                    (10,1),(10,10),(10,11),(65536,65536)]:ints('boundary',n,k)
        while len(cases)<count:ints('random',rnd.randint(1,100000),rnd.randint(1,100000))
        maximum='100000 100000\n'
    elif pid=='abc127_a':
        for age,price in [(0,2),(5,2),(6,2),(12,2),(13,2),(100,1000),(0,1000),
                          (5,1000),(6,1000),(12,1000),(13,1000),(30,100),(12,100)]:ints('boundary',age,price)
        while len(cases)<count:ints('random',rnd.randint(0,100),2*rnd.randint(1,500))
        maximum='100 1000\n'
    elif pid=='abc127_b':
        for r,d,x in [(2,1,2),(2,1,200),(2,100,101),(2,100,200),(5,1,200),(5,100,101),
                      (5,100,200),(2,10,20),(4,40,60),(3,20,21),(3,99,100),(4,100,200)]:ints('boundary',r,d,x)
        while len(cases)<count:
            d=rnd.randint(1,100);ints('random',rnd.randint(2,5),d,rnd.randint(d+1,200))
        maximum='5 100 200\n'
    elif pid=='abc127_c':
        gates('constraint_min',1,[(1,1)])
        gates('disjoint',3,[(1,1),(3,3)])
        gates('single_card',10,[(1,10),(5,5),(5,10)])
        gates('all_cover',10,[(1,10)]*5)
        gates('one_gate',100000,[(1,100000)])
        gates('near_ends',100000,[(1,99999),(2,100000)])
        gates('opposite',100000,[(1,1),(100000,100000)])
        gates('sample2',10,[(3,6),(5,7),(6,9)])
        gates('identical',1,[(1,1)]*20)
        gates('zero_intersection',3,[(1,2),(2,3),(3,3),(1,1)])
        while len(cases)<count:
            n=rnd.randint(1,150);m=rnd.randint(1,80)
            gates('random',n,[(l:=rnd.randint(1,n),rnd.randint(l,n)) for _ in range(m)])
        maximum='100000 100000\n'+('1 100000\n'*100000)
    elif pid=='abc128_a':
        for a,p in [(0,0),(0,1),(0,2),(1,0),(1,1),(1,3),(100,100),(100,0),(0,100),
                    (99,99),(100,99),(99,100),(32,21)]:ints('boundary',a,p)
        while len(cases)<count:ints('random',rnd.randint(0,100),rnd.randint(0,100))
        maximum='100 100\n'
    else:
        restaurants('single',[('a',0)])
        restaurants('same_city',[('a',i) for i in range(100,0,-1)])
        restaurants('reverse_score',[('a',i) for i in range(1,101)])
        restaurants('different_cities',[(chr(97+i),100-i) for i in range(20)])
        restaurants('same_prefix',[(name,i) for i,name in enumerate(['a','aa','aaa','ab','b','ba'])])
        restaurants('long_names',[('a'*10,0),('z'*10,100)])
        restaurants('sample2',[('yakutsk',i) for i in range(10,101,10)])
        restaurants('mixed',[('z',3),('a',5),('z',7),('a',9),('b',1)])
        while len(cases)<count:
            n=rnd.randint(1,100)
            scores=rnd.sample(range(101),n)
            cities=[''.join(rnd.choices('abcxyz',k=rnd.randint(1,10))) for _ in range(n)]
            restaurants('random',list(zip(cities,scores)))
        maximum='100\n'+'\n'.join(f'{"abc"[i%3]} {i}' for i in range(100))+'\n'
    if include_large:
        cases=[c for c in cases if c['input'] != maximum]
        seen.discard(maximum)
        add('constraint_max',maximum)
    return cases[:count]+([c for c in cases[count:] if c['category']=='constraint_max'] if include_large else [])


def independent_check(pid: str, data: str, expected: str) -> bool:
    args=validate(pid,data)
    answer=expected.strip()
    if pid=='abc126_c':
        if re.fullmatch(r'(?:0|1)(?:\.[0-9]+)?',answer) is None:
            return False
        n,k=args
        # Group die faces by their required number of heads (different from
        # the reference program's loop over each face and repeated doubling).
        weighted=0
        for flips in range(18):
            if flips==0:
                count=max(0,n-k+1)
            else:
                lower=max(1,(k+(1<<flips)-1)//(1<<flips))
                upper=min(n,(k-1)//(1<<(flips-1)))
                count=max(0,upper-lower+1)
            weighted+=count/(1<<flips)
        return abs(float(answer)-weighted/n)<=1e-11
    if pid=='abc125_a':
        a,b,t=args;total=0
        for moment in range(1,t+1):
            if moment%a==0:total+=b
        return answer==str(total)
    if pid=='abc125_b':
        n,v,c=args
        if n<=12:
            best=0
            for mask in range(1<<n):
                gain=sum(v[i]-c[i] for i in range(n) if mask>>i&1)
                best=max(best,gain)
            return answer==str(best)
        return answer==str(sum(x-y for x,y in zip(v,c) if x>y))
    if pid=='abc125_c':
        n,arr=args
        if n<=28:
            return answer==str(max(gcd(*arr[:i],*arr[i+1:]) for i in range(n)))
        pre=[0]*(n+1)
        for i,x in enumerate(arr):pre[i+1]=gcd(pre[i],x)
        suffix=0; best=0
        for i in range(n-1,-1,-1):
            best=max(best,gcd(pre[i],suffix))
            suffix=gcd(suffix,arr[i])
        return answer==str(best)
    if pid=='abc126_a':
        _,k,s=args
        return answer==''.join(ch.lower() if index+1==k else ch for index,ch in enumerate(s))
    if pid=='abc126_b':
        valid_left=args[:2] in {f'{month:02d}' for month in range(1,13)}
        valid_right=args[2:] in {f'{month:02d}' for month in range(1,13)}
        result=('AMBIGUOUS' if valid_left and valid_right else 'MMYY' if valid_left else 'YYMM' if valid_right else 'NA')
        return answer==result
    if pid=='abc127_a':
        age,price=args
        return answer==str(0 if age<=5 else price//2 if age<=12 else price)
    if pid=='abc127_b':
        r,d,x=args
        values=[]
        for year in range(1,11):
            value=pow(r,year)*x-d*(pow(r,year)-1)//(r-1)
            values.append(str(value))
        return answer=='\n'.join(values)
    if pid=='abc127_c':
        n,m,ranges=args
        # A difference array counts gate coverage per ID (rather than tracking
        # the intersection endpoints as the reference program does).
        diff=[0]*(n+2)
        for l,r in ranges:diff[l]+=1;diff[r+1]-=1
        covered=0;result=0
        for i in range(1,n+1):
            covered+=diff[i]
            if covered==m:result+=1
        return answer==str(result)
    if pid=='abc128_a':
        apples,pieces=args
        for _ in range(apples):pieces+=3
        pies=0
        while pieces>=2:pieces-=2;pies+=1
        return answer==str(pies)
    if pid=='abc128_b':
        by_city={}
        for index,(city,points) in enumerate(args,1):
            by_city.setdefault(city,[]).append((points,index))
        ordered=[]
        for city in sorted(by_city):
            ordered.extend(index for _,index in sorted(by_city[city],reverse=True))
        return answer=='\n'.join(map(str,ordered))
    raise ValueError('unknown task')
