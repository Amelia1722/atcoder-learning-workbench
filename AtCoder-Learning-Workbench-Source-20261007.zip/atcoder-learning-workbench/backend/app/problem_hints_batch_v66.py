"""Hints based on the public official statements of ABC056–058 B."""
HINTS_V66 = {
    'abc056_b': (
        '二つの長方形が接するには、水平方向の区間をどこまで近づければよいでしょうか。すでに接している場合も考えてください。',
        '左端a,bの距離から幅Wを引いた値が正ならその分だけ移動します。0以下なら移動距離は0です。',
        '疑似コード:\nw,a,b = 入力\nprint(max(0, abs(a-b)-w))',
    ),
    'abc057_b': (
        '各生徒について候補のチェックポイント数を確認しましょう。同じ距離の候補があったらどちらを採用しますか。',
        'マンハッタン距離 abs(a-c)+abs(b-d) を全候補で計算します。最短距離の更新を厳密な「小さいときだけ」にすれば同距離は先の番号が残ります。',
        '疑似コード:\nfor 生徒 in students:\n  best=無限大; answer=未設定\n  for j,地点 in enumerate(checkpoints,1):\n    d=abs(生徒.x-地点.x)+abs(生徒.y-地点.y)\n    if d<best: best=d; answer=j\n  print(answer)',
    ),
    'abc058_b': (
        '元の文字列で奇数番目と偶数番目はどの順番で登場していたでしょうか。長さが異なる場合にも注意しましょう。',
        'OとEを先頭から交互に連結します。Oが1文字長ければ最後のOも忘れずに付けます。',
        '疑似コード:\nans=[]\nfor i in 0..len(O)-1:\n  ans.append(O[i])\n  if i<len(E): ans.append(E[i])\nprint(join(ans))',
    ),
}
