"""Statement-checked three-stage hints for ABC239–241 B."""
HINTS_V127 = {
    'abc239_b': (
        '求めるのは10で割った値の「切り捨て」です。負の数では、0方向への切り捨てと床関数は同じではない点に注意します。',
        'Pythonの整数除算 `//` は床関数なので、そのまま `X // 10` で条件を満たします。他言語では負数の除算仕様を確認してください。',
        '疑似コード:\nread X\nanswer = floor_divide(X, 10)\nprint(answer)',
    ),
    'abc240_b': (
        '同じ値が何回現れるかではなく、「異なる値が何種類あるか」だけを数えます。',
        '集合に全要素を入れると重複が自動的に消えます。集合の要素数が答えです。',
        '疑似コード:\nread N and A\nseen = empty set\nfor x in A:\n  add x to seen\nprint(size of seen)',
    ),
    'abc241_b': (
        'Bに必要な各長さの麺を、Aが必要個数以上持っているかを確認します。値が存在するだけではなく個数も重要です。',
        'Aの各値の個数を数え、Bを1本ずつ処理するたびに対応する個数を1減らします。0本の値が要求されたらNoです。',
        '疑似コード:\ncount frequencies of A\nfor x in B:\n  if count[x] == 0:\n    print("No"); stop\n  count[x] -= 1\nprint("Yes")',
    ),
}
