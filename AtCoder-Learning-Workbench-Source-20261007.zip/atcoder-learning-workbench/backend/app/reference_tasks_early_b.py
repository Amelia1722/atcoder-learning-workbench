"""ABC001 B and ABC002 B: public statement manually reviewed, not HTTP archived."""
from __future__ import annotations
import random
import re
VOWELS = frozenset('aiueo')
ALPHABET = 'abcdefghijklmnopqrstuvwxyz'

def visible_domain(m: int) -> bool:
    return (0 <= m < 100 or 100 <= m <= 5000 and m % 100 == 0 or
            6000 <= m <= 30000 and m % 1000 == 0 or
            35000 <= m <= 70000 and m % 5000 == 0 or 70000 < m <= 100000)

def validate(pid: str, text: str) -> str:
    if not isinstance(text, str) or not text.endswith('\n') or '\r' in text or text.count('\n') != 1:
        raise ValueError('invalid input')
    value = text[:-1]
    if pid == 'abc001_2':
        if not re.fullmatch(r'(?:0|[1-9][0-9]*)',value) or not visible_domain(int(value)):
            raise ValueError('invalid visibility')
    elif pid == 'abc002_2':
        if not re.fullmatch('[a-z]{1,30}', value, flags=re.ASCII) or all(c in VOWELS for c in value):
            raise ValueError('invalid word')
    else:
        raise ValueError('unknown task')
    return value

def independent_check(pid: str, inp: str, expected: str) -> bool:
    value = validate(pid,inp)
    if pid == 'abc002_2':
        answer = ''.join(filter(lambda x: x not in VOWELS, value))
    else:
        m = int(value)
        if m < 100: vv = 0
        elif m <= 5000: vv = m // 100
        elif m <= 30000: vv = m // 1000 + 50
        elif m <= 70000: vv = (m // 1000 - 30) // 5 + 80
        else: vv = 89
        answer = f'{vv:02d}'
    return expected == answer

def generate(pid: str, seed: int = 46) -> list[dict[str,str]]:
    rng = random.Random(f'v46:{pid}:{seed}')
    cases=[]; seen=set()
    def add(category: str, raw: str):
        raw += '\n'; validate(pid, raw)
        if raw not in seen:
            seen.add(raw);cases.append({'category':category,'input':raw})
    if pid == 'abc001_2':
        for m in (0,1,99,100,200,4900,5000,6000,7000,30000,35000,40000,65000,70000,70001,75000,100000):
            if visible_domain(m): add('boundary' if m in (99,100,5000,6000,30000,35000,70000,70001) else 'normal',str(m))
        while len(cases) < 18:
            m = rng.choice(list(range(0,100)) + list(range(100,5001,100)) + list(range(6000,30001,1000)) + list(range(35000,70001,5000)) + list(range(70001,100001)))
            add('normal',str(m))
        add('constraint_max','100000')
    elif pid == 'abc002_2':
        for word in ('b','chokudai','okanemochi','aoki','mazushii','aeioub','bbbb','zzzzz','a'*29+'b', 'z'*30):
            add('boundary' if len(word) in (1,30) else 'normal',word)
        while len(cases)<18:
            size=rng.randint(1,30)
            word=''.join(rng.choice(ALPHABET) for _ in range(size-1))+'z'
            add('normal',word)
        add('constraint_max','z'*30)
    else: raise ValueError('unknown task')
    maximum = '100000\n' if pid == 'abc001_2' else 'z'*30+'\n'
    cases=[case for case in cases if case['input'] != maximum][:17]
    cases.append({'category':'constraint_max','input':maximum})
    assert len(cases)==18 and len({case['input'] for case in cases})==18
    return cases
