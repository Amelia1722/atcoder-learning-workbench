"""ABC038–040 B. Public-statement transcription; HTML originals not authenticated."""
from __future__ import annotations
import math
import random
import re

TASKS=('abc038_b','abc039_b','abc040_b')
INTEGER=re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown task or noncanonical input')
    lines=raw[:-1].split('\n')
    if pid=='abc038_b':
        if len(lines)!=2:raise ValueError('two display dimensions required')
        dims=[]
        for line in lines:
            tokens=line.split(' ')
            if len(tokens)!=2 or any(not INTEGER.fullmatch(s) for s in tokens):
                raise ValueError('invalid dimensions')
            dims.extend(map(int,tokens))
        if any(not 1<=v<=100000 for v in dims):raise ValueError('dimension out of bounds')
        return tuple(dims)
    if len(lines)!=1 or not INTEGER.fullmatch(lines[0]):raise ValueError('invalid integer')
    n=int(lines[0])
    if pid=='abc039_b':
        if not 1<=n<=10**9 or math.isqrt(math.isqrt(n))**4!=n:
            raise ValueError('X must be the fourth power of a positive integer <= 1e9')
    elif not 1<=n<=100000:raise ValueError('tile count out of bounds')
    return n

def independent_check(pid: str, raw: str, output: str)->bool:
    try: data=validate(pid,raw)
    except (ValueError,TypeError):return False
    if not isinstance(output,str):return False
    if pid=='abc038_b':
        a,b,c,d=data
        # Enumerate both allowed orientations rather than use the solver's membership test.
        answer='YES' if any(h1==h2 for h1 in (a,b) for h2 in (c,d)) else 'NO'
        return output==answer
    if pid=='abc039_b':
        # Binary-search the exact fourth root, avoiding floating-point rounding.
        lo,hi=0,178
        while hi-lo>1:
            mid=(lo+hi)//2
            if mid**4<=data:lo=mid
            else:hi=mid
        return output==str(lo) and lo**4==data
    # Exhaustive independent rectangle enumeration for every height <= sqrt(n),
    # every admissible width; no reliance on optimized quotient formula.
    best=data
    for h in range(1,math.isqrt(data)+1):
        for w in range(h,data//h+1):
            score=(w-h)+(data-h*w)
            if score<best:best=score
    return output==str(best)

def generate(pid: str, seed:int=60)->list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unsupported task')
    rng=random.Random(f'abc-v60:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category:str, raw:str):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw);rows.append({'category':category,'input':raw})
    if pid=='abc038_b':
        presets=[(1,1,1,1),(1,1,1,2),(1,2,2,1),(1,2,3,1),
          (2,3,4,3),(2,3,4,5),(3,2,4,3),(7,8,8,7),
          (1,100000,100000,1),(1,100000,99999,1),
          (99999,99999,99999,99998),(100000,100000,99999,100000),
          (15,15,15,15),(10,20,30,40),(334,668,668,1002),
          (1080,1920,1920,1080)]
        for a,b,c,d in presets:add('boundary' if min(a,b,c,d)==1 or max(a,b,c,d)==100000 else 'normal',f'{a} {b}\n{c} {d}\n')
        while len(rows)<17:
            dims=[rng.randint(1,100000) for _ in range(4)]
            add('random',f'{dims[0]} {dims[1]}\n{dims[2]} {dims[3]}\n')
        add('constraint_max','100000 100000\n100000 100000\n')
    elif pid=='abc039_b':
        for i in [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,25]:
            add('boundary' if i==1 else 'normal',f'{i**4}\n')
        add('constraint_max',f'{177**4}\n')
    else:
        for n in [1,2,3,4,5,6,7,8,9,10,12,16,25,26,41,100,99999]:
            add('boundary' if n in (1,99999) else 'normal',f'{n}\n')
        add('constraint_max','100000\n')
    if len(rows)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases; got {len(rows)}')
    return rows
