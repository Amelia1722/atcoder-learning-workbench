"""Three-stage, task-specific hints for the verified ABC113–116 A/B tasks."""
HINTS_V17 = {
 'abc113_a': (
  '2つの交通手段の料金を分けて考え、どちらに割引が適用されるかを確認しましょう。',
  '鉄道運賃Xはそのままで、偶数のバス運賃Yだけ半分にして足します。',
  '疑似コード:\nX,Y = read_two_integers()\nprint(X + Y//2)'),
 'abc113_b': (
  '地点によって変わる値を計算し、目標との差が一番小さい地点を探しましょう。',
  '標高Hiの気温T-0.006*Hiと目標Aの絶対差を各地点で求め、最小になる1始まりの番号を選びます。小数誤差を避けるなら1000倍します。',
  '疑似コード:\nbest = infinity\nfor i, H in enumerate(heights, start=1):\n  delta = abs((T-A)*1000 - 6*H)\n  if delta < best: best = delta; answer = i\nprint(answer)'),
 'abc114_a': (
  '祝われる年齢は問題文に挙げられた少数の値に限られています。',
  '整数Xが3・5・7のいずれかであるかを集合への所属判定などで確認します。',
  '疑似コード:\nX = read_integer()\nif X in {3,5,7}: print("YES")\nelse: print("NO")'),
 'abc114_b': (
  '選ぶ数字は連続している必要があります。取り出せる位置を一つずつ考えてください。',
  '文字列の長さ3の連続部分文字列を全て整数に変換し、753との差の絶対値の最小を取ります。',
  '疑似コード:\nans = infinity\nfor i in 0 .. len(S)-3:\n  ans = min(ans, abs(int(S[i:i+3])-753))\nprint(ans)'),
 'abc115_a': (
  '日にちが1日前になるたび、出力の末尾に何かが増える点を考えましょう。',
  '25日ならChristmas、24日ならEveを1回、23日なら2回、22日なら3回付けます。',
  '疑似コード:\nD = read_integer()\nprint("Christmas" + " Eve" * (25-D))'),
 'abc115_b': (
  '割引される品物は複数ではなく1個だけである点に注意してください。',
  '全商品の合計から、最も高い商品1つの価格の半分を引きます。価格は偶数なので整数除算ができます。',
  '疑似コード:\nprices = read_prices()\nprint(sum(prices) - max(prices)//2)'),
 'abc116_a': (
  '直角がどの頂点にあるか確認し、直角を挟む2辺の長さを使いましょう。',
  '∠ABC=90°なのでABとBCが底辺と高さになります。面積はAB×BC÷2です。',
  '疑似コード:\nAB,BC,CA = read_three_integers()\nprint(AB*BC//2)'),
 'abc116_b': (
  '数列を実際に作るとき、今の値が以前現れたかどうかを調べる必要があります。',
  'setに登場済みの値を保存し、偶数なら2で割り奇数なら3倍して1加える操作を繰り返します。重複した時点の位置を答えます。',
  '疑似コード:\nseen={s}; index=1\nwhile True:\n  s = s//2 if s%2==0 else 3*s+1\n  index += 1\n  if s in seen: print(index); stop\n  seen.add(s)'),
}
