"""Private exact ABC114..119 D reviewed tasks."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter
from functools import lru_cache
from itertools import product
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(114,120))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
MATCH=(0,2,5,5,4,5,6,3,7,6)

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

@lru_cache(maxsize=128)
def match_reachable(n:int,digits:tuple[int,...])->bool:
    reachable=bytearray(n+1);reachable[0]=1
    for used in range(1,n+1):reachable[used]=any(used>=MATCH[digit] and reachable[used-MATCH[digit]] for digit in digits)
    return bool(reachable[n])

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc114_d':
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=100,'N');return (n,)
    if pid=='abc115_d':
        require(len(rows)==1,'shape');n,x=ints(rows[0],2);require(1<=n<=50 and 1<=x<=2**(n+2)-3,'burger');return n,x
    if pid=='abc116_d':
        n,k=ints(rows[0],2);require(1<=k<=n<=100000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=t<=n and 1<=d<=10**9 for t,d in a),'sushi');return k,a
    if pid=='abc117_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);require(1<=n<=100000 and 0<=k<=10**12,'N/K');a=ints(rows[1],n);require(all(0<=v<=10**12 for v in a),'Ai');return k,a
    if pid=='abc118_d':
        require(len(rows)==2,'shape');n,m=ints(rows[0],2);require(2<=n<=10000 and 1<=m<=9,'N/M');digits=ints(rows[1],m);require(len(set(digits))==m and all(1<=d<=9 for d in digits),'digits');require(match_reachable(n,digits),'exists');return n,digits
    a,b,q=ints(rows[0],3);require(1<=a<=100000 and 1<=b<=100000 and 1<=q<=100000 and len(rows)==1+a+b+q,'shape');values=tuple(ints(row,1)[0] for row in rows[1:]);require(all(1<=v<=10**10 for v in values) and len(set(values))==len(values),'positions globally distinct');shrines,temples,queries=values[:a],values[a:a+b],values[a+b:];require(all(x<y for x,y in zip(shrines,shrines[1:])) and all(x<y for x,y in zip(temples,temples[1:])),'sorted');return shrines,temples,queries

def factorial_divisor_patterns(n:int)->int:
    factors:Counter[int]=Counter()
    for number in range(2,n+1):
        value=number;p=2
        while p*p<=value:
            while value%p==0:factors[p]+=1;value//=p
            p+=1
        if value>1:factors[value]+=1
    dp={1:1}
    for exponent in factors.values():
        next_dp:dict[int,int]={}
        for count,ways in dp.items():
            for divisor in (1,3,5,15,25,75):
                new=count*divisor
                if divisor<=exponent+1 and 75%new==0:next_dp[new]=next_dp.get(new,0)+ways
        dp=next_dp
    return dp.get(75,0)

def burger_segments(n:int,x:int)->int:
    # Traverse actual physical layer segments; add complete subburgers wholesale.
    stack=[(n,0)];answer=0
    while stack:
        level,start=stack.pop();length=2**(level+2)-3
        if start>=x:continue
        if start+length<=x:answer+=2**(level+1)-1;continue
        if level==0:answer+=1;continue
        inner=2**(level+1)-3;center=start+inner+1
        if center<x:answer+=1
        stack.extend(((level-1,start+1),(level-1,center+1)))
    return answer

class OrderSums:
    def __init__(self,values:list[int]):
        self.values=sorted(set(values));self.count=[0]*(len(self.values)+1);self.sums=[0]*len(self.count);self.total=0;self.size=0
        for value in values:self.add(value,1)
    def add(self,value:int,change:int)->None:
        self.total+=change*value;self.size+=change;j=bisect_left(self.values,value)+1
        while j<len(self.count):self.count[j]+=change;self.sums[j]+=change*value;j+=j&-j
    def largest(self,k:int)->int:
        # Exclude the smallest size-k values, finding their boundary by Fenwick select.
        need=self.size-k;index=0;removed=0;bit=1<<(len(self.count).bit_length()-1)
        while bit:
            nxt=index+bit
            if nxt<len(self.count) and self.count[nxt]<=need:need-=self.count[nxt];removed+=self.sums[nxt];index=nxt
            bit>>=1
        if need:removed+=need*self.values[index]
        return self.total-removed

def sushi_mandatory(k:int,a:tuple[tuple[int,...],...])->int:
    best:dict[int,int]={}
    for kind,value in a:best[kind]=max(best.get(kind,0),value)
    pool=OrderSums([value for _,value in a]);answer=pool.largest(k);mandatory=0
    # For >=q distinct types, q highest type representatives can be compulsory:
    # exchange each missing representative with a smaller unmarked chosen item.
    # Extra types are allowed. max_q(best sum for >=q + q^2) equals the optimum.
    for q,value in enumerate(sorted(best.values(),reverse=True)[:k],1):
        mandatory+=value;pool.add(value,-1);answer=max(answer,mandatory+pool.largest(k-q)+q*q)
    return answer

def xor_first_difference(k:int,a:tuple[int,...])->int:
    width=40;ones=[sum(bool(value>>bit&1) for value in a) for bit in range(width)];n=len(a)
    score=lambda bit,digit:((n-ones[bit]) if digit else ones[bit])*(1<<bit)
    exact=sum(score(bit,k>>bit&1) for bit in range(width));answer=exact;prefix=0
    for bit in range(width-1,-1,-1):
        digit=k>>bit&1
        if digit:answer=max(answer,prefix+score(bit,0)+sum(max(score(lower,0),score(lower,1)) for lower in range(bit)))
        prefix+=score(bit,digit)
    return answer

def largest_match_string(n:int,digits:tuple[int,...])->str:
    dp:list[str|None]=[None]*(n+1);dp[0]=''
    for used in range(1,n+1):
        for digit in digits:
            cost=MATCH[digit]
            if cost<=used and dp[used-cost] is not None:
                candidate=cast(str,dp[used-cost])+str(digit);old=dp[used]
                if old is None or (len(candidate),candidate)>(len(old),old):dp[used]=candidate
    return cast(str,dp[n])

def faith_route(shrines:tuple[int,...],temples:tuple[int,...],queries:tuple[int,...])->list[int]:
    # Every adjacent cross-category pair [l,r] is a sufficient route interval.
    # On the same side minimize far endpoint; across x minimize2*left+right or left+2*right.
    merged=sorted([(v,0) for v in shrines]+[(v,1) for v in temples]);intervals=[(l,r) for (l,a),(r,b) in zip(merged,merged[1:]) if a!=b];starts=[l for l,r in intervals];ends=[r for l,r in intervals];answer=[]
    # Adjacent crossing intervals have strictly increasing both endpoints and disjoint interiors.
    for x in queries:
        j=bisect_left(ends,x);best=10**30
        for index in (j-1,j,j+1):
            if 0<=index<len(intervals):
                l,r=intervals[index];best=min(best,r-l+min(abs(x-l),abs(x-r)))
        answer.append(best)
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc114_d':return str(factorial_divisor_patterns(cast(int,data[0])))
    if pid=='abc115_d':return str(burger_segments(*cast(tuple[int,int],data)))
    if pid=='abc116_d':return str(sushi_mandatory(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
    if pid=='abc117_d':return str(xor_first_difference(*cast(tuple[int,tuple[int,...]],data)))
    if pid=='abc118_d':return largest_match_string(*cast(tuple[int,tuple[int,...]],data))
    return '\n'.join(map(str,faith_route(*cast(tuple[tuple[int,...],tuple[int,...],tuple[int,...]],data))))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc114_d':"n=int(input());exponents=[]\nfor p in range(2,n+1):\n if any(p%d==0 for d in range(2,int(p**.5)+1)):continue\n e=0;q=p\n while q<=n:e+=n//q;q*=p\n exponents.append(e)\nc=lambda k:sum(e>=k-1 for e in exponents)\nprint(c(75)+c(25)*(c(3)-1)+c(15)*(c(5)-1)+c(5)*(c(5)-1)//2*(c(3)-2))\n",
'abc115_d':"n,x=map(int,input().split());layers=[1];patties=[1]\nfor _ in range(n):layers.append(2*layers[-1]+3);patties.append(2*patties[-1]+1)\ndef count(level,eaten):\n if eaten<=0:return 0\n if level==0:return 1\n if eaten<=layers[level-1]+1:return count(level-1,eaten-1)\n return patties[level-1]+1+count(level-1,eaten-layers[level-1]-2)\nprint(count(n,x))\n",
'abc116_d':"import heapq\nn,k=map(int,input().split());a=sorted((tuple(map(int,input().split())) for _ in range(n)),key=lambda p:p[1],reverse=True);used=set();duplicates=[];total=0\nfor kind,value in a[:k]:\n total+=value\n if kind in used:heapq.heappush(duplicates,value)\n else:used.add(kind)\nanswer=total+len(used)**2\nfor kind,value in a[k:]:\n if kind in used:continue\n if not duplicates:break\n total+=value-heapq.heappop(duplicates);used.add(kind);answer=max(answer,total+len(used)**2)\nprint(answer)\n",
'abc117_d':"n,k=map(int,input().split());a=list(map(int,input().split()));equal=0;smaller=None\nfor bit in range(39,-1,-1):\n ones=sum((v>>bit)&1 for v in a);score=[ones*(1<<bit),(n-ones)*(1<<bit)];new_equal=new_smaller=None\n for digit in (0,1):\n  if digit==((k>>bit)&1):new_equal=equal+score[digit]\n  elif digit<((k>>bit)&1):new_smaller=equal+score[digit]\n  if smaller is not None:new_smaller=max(new_smaller if new_smaller is not None else -1,smaller+score[digit])\n equal,smaller=new_equal,new_smaller\nprint(max(equal,smaller if smaller is not None else -1))\n",
'abc118_d':"n,m=map(int,input().split());a=sorted(map(int,input().split()),reverse=True);cost=[0,2,5,5,4,5,6,3,7,6];length=[-100000]*(n+1);length[0]=0\nfor used in range(1,n+1):\n for digit in a:\n  if used>=cost[digit]:length[used]=max(length[used],length[used-cost[digit]]+1)\nanswer=[]\nwhile n:\n for digit in a:\n  if n>=cost[digit] and length[n]==length[n-cost[digit]]+1:answer.append(str(digit));n-=cost[digit];break\nprint(''.join(answer))\n",
'abc119_d':"from bisect import bisect_left\na,b,q=map(int,input().split());s=[int(input()) for _ in range(a)];t=[int(input()) for _ in range(b)]\nfor _ in range(q):\n x=int(input());i=bisect_left(s,x);j=bisect_left(t,x);answer=10**30\n for shrine in s[max(0,i-1):min(a,i+1)]:\n  for temple in t[max(0,j-1):min(b,j+1)]:answer=min(answer,abs(x-shrine)+abs(shrine-temple),abs(x-temple)+abs(temple-shrine))\n print(answer)\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18500+TASKS.index(pid))
    if pid=='abc114_d':raws=[f'{n}\n' for n in [1,2,3,4,5,6,7,8,9,10,15,20,25,30,50,75,99,100]]
    elif pid=='abc115_d':raws=[line((1,1)),line((1,2)),line((1,3)),line((1,5))]+[line((n,rng.randint(1,2**(n+2)-3))) for n in range(2,14)]+[line((50,2**51-2)),line((50,2**52-3))]
    elif pid=='abc116_d':
        def sushi(k:int,a:list[tuple[int,int]])->str:return line((len(a),k))+''.join(line(p) for p in a)
        raws=[sushi(1,[(1,1)]),sushi(1,[(1,10**9)]),sushi(2,[(1,1),(2,1)]),sushi(2,[(1,10),(1,9),(2,1)])]
        raws.extend(sushi(rng.randint(1,n),[(rng.randint(1,n),rng.randint(1,10**9)) for _ in range(n)]) for n in range(3,15));raws.extend([sushi(50000,[(j//2+1,10**9-j) for j in range(100000)]),sushi(100000,[(j+1,10**9) for j in range(100000)])])
    elif pid=='abc117_d':
        def seq(k:int,a:list[int])->str:return line((len(a),k))+line(a)
        raws=[seq(0,[0]),seq(0,[10**12]),seq(10**12,[0]),seq(7,[1,6,3])];raws.extend(seq(rng.randint(0,10**12),[rng.randint(0,10**12) for _ in range(n)]) for n in range(2,14));raws.extend([seq(10**12,[j*999983%10**12 for j in range(100000)]),seq(10**12,[10**12]*100000)])
    elif pid=='abc118_d':
        def match(n:int,a:list[int])->str:return line((n,len(a)))+line(a)
        raws=[match(2,[1]),match(3,[7]),match(4,[4]),match(5,[2,3,5])]
        for n in range(6,18):
            digits=rng.sample(range(1,10),rng.randint(1,9))
            if not match_reachable(n,tuple(digits)):digits=[1,7]
            raws.append(match(n,digits))
        raws.extend([match(10000,[8,9,7,6,5,4,3,2,1]),match(10000,list(range(1,10)))])
    else:
        def positions(s:list[int],t:list[int],q:list[int])->str:return line((len(s),len(t),len(q)))+''.join(f'{v}\n' for v in s+t+q)
        raws=[positions([1],[2],[3]),positions([1],[10**10],[2]),positions([2],[3],[1]),positions([1,8],[3,10],[5,7])]
        for n in range(2,14):
            values=rng.sample(range(1,1000),n*3);raws.append(positions(sorted(values[:n]),sorted(values[n:2*n]),values[2*n:]))
        raws.extend([positions(list(range(1,300000,3)),list(range(2,300001,3)),list(range(3,300001,3))),positions(list(range(1,100001)),list(range(10**10-99999,10**10+1)),list(range(100001,200001)))])
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc114_d':('N!の素因数ごとの指数を数えます。約数の個数は、各指数に1を足した値の積です。','75の分解は75、25×3、15×5、5×5×3です。それぞれ必要な指数を持つ異なる素数を選びます。','疑似コード: 各primeのN!指数eを算出; c(k)=e>=k-1の素数数; c75+c25*(c3-1)+c15*(c5-1)+c5*(c5-1)/2*(c3-2)を出力。'),
'abc115_d':('レベルnの層数とパティ数を、レベルn-1の値から計算します。','食べた位置が最初のパン・下半分・中央パティ・上半分のどこにあるかで分け、未完成の半分だけ再帰します。','疑似コード: L0=P0=1; Ln=2L(n-1)+3,Pn=2P(n-1)+1; count(n,x): x<=0なら0; n=0なら1; x<=L(n-1)+1ならcount(n-1,x-1); 他はP(n-1)+1+count(n-1,x-L(n-1)-2)。'),
'abc116_d':('まず美味しさが大きい順にK個を選び、種類数と美味しさの合計を調べます。','既にある種類の余分な寿司の最小値を、新しい種類の寿司に交換します。種類数が増える各段階で満足度を比較します。','疑似コード: d降順sort; 最初K個の重複種類をminheapへ; 残りの未使用typeでheap最小を交換; sum+types^2を毎回更新し最大を出力。'),
'abc117_d':('Xの各ビットを選ぶと、そのビットの寄与はAの0と1の個数から決まります。','上位ビットから、Kと一致している状態と既にKより小さい状態を分けて最大値を求めます。','疑似コード: equal=0,small=-INF; bitを上から走査; Xbit=0/1で寄与を加算; equalからはKbit以下のみ許す; smallからは自由; 新equal/smallへ最大遷移し最後の最大値を出力。'),
'abc118_d':('数の大きさは、まず桁数で比較し、桁数が同じなら左から大きい数字が優先されます。','マッチ本数ごとの最大桁数をDPで求めます。残りの最適桁数を保てる最大の数字から順に復元します。','疑似コード: length[0]=0,他=-INF; usedとdigitでlength[used]=max(length[used-cost[digit]]+1); Nからdigit降順でlength[N]=length[N-cost]+1を満たすdigitを出力しN-=cost。'),
'abc119_d':('開始位置の左右で最も近い神社と寺だけが候補になります。','左右それぞれの候補を二分探索し、神社を先に訪れる順番と寺を先に訪れる順番を両方比較します。','疑似コード: 各xでlower_boundを用いて左右のs,tを取得; 各組でabs(x-s)+abs(s-t)とabs(x-t)+abs(t-s)を比較; 最小を出力。')}

TITLES={'abc114_d': '756', 'abc115_d': 'Christmas', 'abc116_d': 'Various Sushi', 'abc117_d': 'XXOR', 'abc118_d': 'Match Matching', 'abc119_d': 'Lazy Faith'}
PUBLISHED_SAMPLES={'abc114_d': [{'input': '9\n', 'expected': '0\n'}, {'input': '10\n', 'expected': '1\n'}, {'input': '100\n', 'expected': '543\n'}], 'abc115_d': [{'input': '2 7\n', 'expected': '4\n'}, {'input': '1 1\n', 'expected': '0\n'}, {'input': '50 4321098765432109\n', 'expected': '2160549382716056\n'}], 'abc116_d': [{'input': '5 3\n1 9\n1 7\n2 6\n2 5\n3 1\n', 'expected': '26\n'}, {'input': '7 4\n1 1\n2 1\n3 1\n4 6\n4 5\n4 5\n4 5\n', 'expected': '25\n'}, {'input': '6 5\n5 1000000000\n2 990000000\n3 980000000\n6 970000000\n6 960000000\n4 950000000\n', 'expected': '4900000016\n'}], 'abc117_d': [{'input': '3 7\n1 6 3\n', 'expected': '14\n'}, {'input': '4 9\n7 4 0 3\n', 'expected': '46\n'}, {'input': '1 0\n1000000000000\n', 'expected': '1000000000000\n'}], 'abc118_d': [{'input': '20 4\n3 7 8 4\n', 'expected': '777773\n'}, {'input': '101 9\n9 8 7 6 5 4 3 2 1\n', 'expected': '71111111111111111111111111111111111111111111111111\n'}, {'input': '15 3\n5 4 6\n', 'expected': '654\n'}], 'abc119_d': [{'input': '2 3 4\n100\n600\n400\n900\n1000\n150\n2000\n899\n799\n', 'expected': '350\n1400\n301\n399\n'}, {'input': '1 1 3\n1\n10000000000\n2\n9999999999\n5000000000\n', 'expected': '10000000000\n10000000000\n14999999998\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
