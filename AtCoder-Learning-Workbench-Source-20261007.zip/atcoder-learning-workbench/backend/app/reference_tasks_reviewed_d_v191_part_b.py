"""Private ABC228--233 D domains and algorithmically independent oracles."""
from __future__ import annotations
from itertools import groupby
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(228,234));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
HASH_SIZE=1<<20
CITY_WIDTH=10**9
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc228_d':
  q=ints(r[0],1)[0];require(1<=q<=200000 and len(r)==q+1,'shape');queries=tuple(ints(s,2) for s in r[1:]);require(all(kind in (1,2) and 0<=x<=10**18 for kind,x in queries) and any(kind==2 for kind,x in queries),'queries');return (queries,)
 if pid=='abc229_d':
  require(len(r)==2 and re.fullmatch(r'[X.]{1,200000}',r[0]) is not None,'S');k=ints(r[1],1)[0];require(0<=k<=200000,'K');return r[0],k
 if pid=='abc230_d':
  n,d=ints(r[0],2);require(1<=n<=200000 and 1<=d<=10**9 and len(r)==n+1,'shape');walls=tuple(ints(s,2) for s in r[1:]);require(all(1<=l<=rr<=10**9 for l,rr in walls),'walls');return d,walls
 if pid=='abc231_d':
  n,m=ints(r[0],2);require(2<=n<=100000 and 0<=m<=100000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=a<b<=n for a,b in edges) and len(set(edges))==m,'simple ordered edges');return n,edges
 if pid=='abc232_d':
  h,w=ints(r[0],2);require(1<=h<=100 and 1<=w<=100 and len(r)==h+1 and all(re.fullmatch(r'[.#]{'+str(w)+'}',s) is not None for s in r[1:]) and r[1][0]=='.','grid');return (tuple(r[1:]),)
 n,k=ints(r[0],2);require(1<=n<=200000 and abs(k)<=10**15 and len(r)==2,'shape');a=ints(r[1],n);require(all(abs(v)<=10**9 for v in a),'Ai');return k,a

def hash_hierarchy(queries:tuple[tuple[int,int],...],size:int=HASH_SIZE)->list[int]:
 # Each 64-bit word describes free cells; upper levels describe nonempty words.
 levels:list[list[int]]=[];count=size
 while True:
  words=[(1<<min(64,count-i))-1 for i in range(0,count,64)];levels.append(words)
  if len(words)==1:break
  count=len(words)
 values=[-1]*size;out=[]
 def successor(start:int,level:int=0)->int|None:
  index,bit=divmod(start,64)
  if index>=len(levels[level]):return None
  mask=levels[level][index]>>bit
  if mask:return index*64+bit+(mask&-mask).bit_length()-1
  if level+1==len(levels):return None
  next_index=successor(index+1,level+1)
  if next_index is None:return None
  mask=levels[level][next_index];return next_index*64+(mask&-mask).bit_length()-1
 def remove(position:int)->None:
  for level in levels:
   index,bit=divmod(position,64);level[index]&=~(1<<bit)
   if level[index]:break
   position=index
 for kind,x in queries:
  at=x%size
  if kind==2:out.append(values[at]);continue
  free=successor(at)
  if free is None:free=successor(0)
  require(free is not None,'available');at=cast(int,free);values[at]=x;remove(at)
 return out

def consecutive_dots(s:str,k:int)->int:
 dots=[-1]+[j for j,c in enumerate(s) if c=='.']+[len(s)]
 if k>=len(dots)-2:return len(s)
 return max(dots[j+k+1]-dots[j]-1 for j in range(len(dots)-k-1))

def punches_intersection(d:int,walls:tuple[tuple[int,int],...])->int:
 # A wall is hit by exactly legal starts x in [max(1,L-D+1),min(R,W-D+1)].
 answer=0;upper=-1
 for left,right in sorted(walls):
  low=max(1,left-d+1);high=min(right,CITY_WIDTH-d+1)
  if low>upper:answer+=1;upper=high
  else:upper=min(upper,high)
 return answer

def linear_forest_prune(n:int,edges:tuple[tuple[int,int],...])->bool:
 graph:list[list[int]]=[[] for _ in range(n)]
 for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
 degree=[len(row) for row in graph]
 if any(v>2 for v in degree):return False
 queue=[j for j,v in enumerate(degree) if v<=1];removed=[False]*n
 for v in queue:
  if removed[v]:continue
  removed[v]=True
  for u in graph[v]:
   if not removed[u]:degree[u]-=1
   if degree[u]==1:queue.append(u)
 return all(removed)

def grid_reachable_bits(g:tuple[str,...])->int:
 reachable=0;answer=1;w=len(g[0])
 for r,row in enumerate(g):
  free=sum(1<<j for j,c in enumerate(row) if c=='.');reachable=(reachable|int(r==0))&free;run=free;step=1
  while step<w:
   reachable|=(reachable<<step)&run;run&=run<<step;step*=2
  if reachable:answer=max(answer,r+reachable.bit_length())
 return answer

def subarrays_sorted_groups(k:int,a:tuple[int,...])->int:
 total=0;prefix=[(0,0)]
 for j,v in enumerate(a,1):total+=v;prefix.append((total,j))
 groups={value:[index for _,index in entries] for value,entries in groupby(sorted(prefix),key=lambda e:e[0])}
 if k==0:return sum(len(indices)*(len(indices)-1)//2 for indices in groups.values())
 answer=0
 for value,starts in groups.items():
  ends=groups.get(value+k,[]);cursor=0
  for end in ends:
   while cursor<len(starts) and starts[cursor]<end:cursor+=1
   answer+=cursor
 return answer

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc228_d':return ''.join(str(v)+'\n' for v in hash_hierarchy(cast(tuple[tuple[int,int],...],d[0])))
 if pid=='abc229_d':return str(consecutive_dots(cast(str,d[0]),cast(int,d[1])))+'\n'
 if pid=='abc230_d':return str(punches_intersection(cast(int,d[0]),cast(tuple[tuple[int,int],...],d[1])))+'\n'
 if pid=='abc231_d':return ('Yes' if linear_forest_prune(cast(int,d[0]),cast(tuple[tuple[int,int],...],d[1])) else 'No')+'\n'
 if pid=='abc232_d':return str(grid_reachable_bits(cast(tuple[str,...],d[0])))+'\n'
 return str(subarrays_sorted_groups(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  expected=oracle(pid,raw)
  if pid=='abc231_d':return actual.strip()==expected.strip()
  tokens=actual.split();return len(tokens)==len(expected.split()) and all(re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s) is not None for s in tokens) and tuple(map(int,tokens))==tuple(map(int,expected.split()))
 except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc228_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));q=next(it);n=1<<20;a=[-1]*n;parent=list(range(n+1));out=[]
def find(v):
 while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
 return v
for _ in range(q):
 t=next(it);x=next(it);at=x%n
 if t==2:out.append(str(a[at]))
 else:
  at=find(at)
  if at==n:at=find(0)
  a[at]=x;parent[at]=find(at+1)
print('\\n'.join(out))
''',
'abc229_d':'''import sys
s=sys.stdin.readline().strip();k=int(sys.stdin.readline());left=used=answer=0
for right,ch in enumerate(s):
 used+=ch=='.'
 while used>k:used-=s[left]=='.';left+=1
 answer=max(answer,right-left+1)
print(answer)
''',
'abc230_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);d=next(it);walls=[(next(it),next(it)) for _ in range(n)];end=0;answer=0
for left,right in sorted(walls,key=lambda e:e[1]):
 if left>end:answer+=1;end=min(right,10**9-d+1)+d-1
print(answer)
''',
'abc231_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);parent=list(range(n));degree=[0]*n;valid=True
def find(v):
 while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
 return v
for _ in range(m):
 a=next(it)-1;b=next(it)-1;degree[a]+=1;degree[b]+=1;u=find(a);v=find(b)
 if u==v or degree[a]>2 or degree[b]>2:valid=False
 else:parent[v]=u
print('Yes' if valid else 'No')
''',
'abc232_d':'''import sys
h,w=map(int,sys.stdin.readline().split());g=[sys.stdin.readline().strip() for _ in range(h)];dp=[[0]*w for _ in range(h)];dp[0][0]=1;answer=1
for r in range(h):
 for c in range(w):
  if g[r][c]=='#':continue
  if r and dp[r-1][c]:dp[r][c]=max(dp[r][c],dp[r-1][c]+1)
  if c and dp[r][c-1]:dp[r][c]=max(dp[r][c],dp[r][c-1]+1)
  answer=max(answer,dp[r][c])
print(answer)
''',
'abc233_d':'''import sys
from collections import defaultdict
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);k=next(it);counts=defaultdict(int);counts[0]=1;prefix=answer=0
for _ in range(n):prefix+=next(it);answer+=counts[prefix-k];counts[prefix]+=1
print(answer)
'''}

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(191000+int(pid[3:6]));raws:list[str]=[]
 if pid=='abc228_d':
  def queries(q:list[tuple[int,int]])->str:return str(len(q))+'\n'+''.join(line(row) for row in q)
  raws=[queries([(2,0)]),queries([(1,0),(2,0)]),queries([(1,HASH_SIZE-1),(1,HASH_SIZE-1),(2,0)]),queries([(1,0),(1,HASH_SIZE),(2,0),(2,1),(2,2)]),queries([(1,10**18),(2,10**18)])]
  for i in range(11):
   base=rng.choice([0,HASH_SIZE-1,63,64,4095,4096,10**18%HASH_SIZE]);q=[(1,base+j*HASH_SIZE) for j in range(3+i)];q.extend((2,(base+j)%HASH_SIZE) for j in range(5+i));raws.append(queries(q))
  collision=(10**18//HASH_SIZE)*HASH_SIZE-1;raws.append(queries([(1,collision)]*199999+[(2,0)]));raws.append(queries([(1,10**18)]+[(2,10**18)]*199999))
 elif pid=='abc229_d':
  def string(s:str,k:int)->str:return s+'\n'+str(k)+'\n'
  raws=[string('.',0),string('X',0),string('.',200000),string('X.X.X',0),string('XX...XX',2),string('...',2)]
  for n in range(2,12):raws.append(string(''.join(rng.choice('X.') for _ in range(n*7)),rng.randrange(n*7+1)))
  raws.append(string('.'*200000,100000));raws.append(string('X'*200000,200000))
 elif pid=='abc230_d':
  def walls(d:int,a:list[tuple[int,int]])->str:return line((len(a),d))+''.join(line(row) for row in a)
  raws=[walls(1,[(1,1)]),walls(10**9,[(1,1),(10**9,10**9)]),walls(10**9-1,[(1,1),(10**9,10**9)]),walls(3,[(1,2),(4,7),(5,9)]),walls(3,[(1,2),(4,7),(4,9)]),walls(2,[(10**9,10**9),(10**9-1,10**9-1)])]
  for i in range(10):
   a=[]
   for j in range(3+i*7):l=rng.randint(1,10**9);rr=rng.randint(l,10**9);a.append((l,rr))
   raws.append(walls(rng.choice([1,10**9,rng.randint(1,10**9)]),a))
  raws.append(walls(1,[(5*j+1,5*j+1) for j in range(200000)]));raws.append(walls(10**9,[(10**9,10**9)]*200000))
 elif pid=='abc231_d':
  def graph(n:int,e:list[tuple[int,int]])->str:return line((n,len(e)))+''.join(line(row) for row in e)
  raws=[graph(2,[]),graph(2,[(1,2)]),graph(3,[(1,2),(1,3),(2,3)]),graph(4,[(1,4),(2,4),(3,4)]),graph(6,[(1,2),(2,3),(4,5)])]
  for i in range(11):
   n=5+i*5;e=[(a,b) for a in range(1,n) for b in range(a+1,n+1) if rng.random()<.04+.01*(i%4)];rng.shuffle(e);raws.append(graph(n,e))
  raws.append(graph(100000,[(j,j+1) for j in range(1,100000)]));raws.append(graph(100000,[(j,j+1) for j in range(1,100000)]+[(1,100000)]))
 elif pid=='abc232_d':
  def grid(g:list[str])->str:return line((len(g),len(g[0])))+''.join(s+'\n' for s in g)
  raws=[grid(['.']),grid(['.#']),grid(['.#','#.']),grid(['....']),grid(['.','.','.','.'])]
  for i in range(11):
   h=2+i%7;w=2+i*2;g=[''.join(rng.choice('..#') for _ in range(w)) for _ in range(h)];g[0]='.'+g[0][1:];raws.append(grid(g))
  raws.append(grid(['.'*100]+['.'+'#'*99 for _ in range(99)]));raws.append(grid(['.'*100]*100))
 else:
  def array(k:int,a:list[int])->str:return line((len(a),k))+line(a)
  raws=[array(0,[0]),array(1,[1]),array(-1,[-1]),array(0,[1,-1]),array(-10**15,[10**9,-10**9])]
  for i in range(10):raws.append(array(rng.choice([0,10**15,-10**15,rng.randint(-10**9,10**9)]),[rng.randint(-10**9,10**9) for _ in range(3+i*11)]))
  raws[-1]=array(-10**15,[-10**9]*200000)
  raws.append(array(0,[0]*200000));raws.append(array(0,[10**9,-10**9]*100000));raws.append(array(10**15,[10**9]*200000))
 require(len(raws)==len(set(raws))==18,'18 distinct')
 cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'reviewed_{j:02d}'})
 return cases

TITLES={'abc228_d': 'Linear Probing',
 'abc229_d': 'Longest X',
 'abc230_d': 'Destroyer Takahashi',
 'abc231_d': 'Neighbors',
 'abc232_d': 'Weak Takahashi',
 'abc233_d': 'Count Interval'}
PUBLISHED_SAMPLES={'abc228_d': [{'input': '4\n1 1048577\n1 1\n2 2097153\n2 3\n', 'expected': '1048577\n-1\n'}],
 'abc229_d': [{'input': 'XX...X.X.X.\n2\n', 'expected': '5\n'},
              {'input': 'XXXX\n200000\n', 'expected': '4\n'}],
 'abc230_d': [{'input': '3 3\n1 2\n4 7\n5 9\n', 'expected': '2\n'},
              {'input': '3 3\n1 2\n4 7\n4 9\n', 'expected': '1\n'},
              {'input': '5 2\n1 100\n1 1000000000\n101 1000\n9982 44353\n1000000000 1000000000\n',
               'expected': '3\n'}],
 'abc231_d': [{'input': '4 2\n1 3\n2 3\n', 'expected': 'Yes\n'},
              {'input': '4 3\n1 4\n2 4\n3 4\n', 'expected': 'No\n'}],
 'abc232_d': [{'input': '3 4\n.#..\n..#.\n..##\n', 'expected': '4\n'},
              {'input': '1 1\n.\n', 'expected': '1\n'},
              {'input': '5 5\n.....\n.....\n.....\n.....\n.....\n', 'expected': '9\n'}],
 'abc233_d': [{'input': '6 5\n8 -3 5 7 0 -4\n', 'expected': '3\n'},
              {'input': '2 -1000000000000000\n1000000000 -1000000000\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
HINTS={'abc228_d': ('配列の長さは入力では与えられず、2の20乗で固定です。操作2は衝突を探さず、指定した余りの位置を読むだけです。',
              '操作1で埋まった場所を一つずつ調べ続けると遅くなります。各位置から次に空いている位置を、経路圧縮付きの連結情報で管理しましょう。',
              '疑似コード: A=-1,parent[i]=i。findは次の空き場所を経路圧縮で返す。追加時at=find(x mod N); at==Nならfind(0); A[at]=x; '
              'parent[at]=find(at+1)。取得時A[x mod N]を出力。'),
 'abc229_d': ('ある連続区間に含まれる点の数がK以下なら、その区間を全てXにできます。',
              '右端を順に伸ばし、点の数がKを超えたら左端を進めます。条件を満たした各区間の長さの最大値が答えです。',
              '疑似コード: '
              'left=0,dots=0,answer=0。rightを順に進めS[right]が点ならdots++。dots>Kの間S[left]が点ならdots--しleft++。answer=max(answer,right-left+1)。'),
 'abc230_d': ('パンチ区間と壁が一部分でも重なれば壊せます。右端の最も早い壁を優先して考えましょう。',
              '最初に残っている壁の右端にパンチの左端を合わせると、その壁を壊しつつ右側の壁を最大限巻き込めます。ただし街からはみ出さないよう開始位置を補正します。',
              '疑似コード: 壁をR昇順に整列、end=0,answer=0。L>endならanswer++; start=min(R,1000000000-D+1); '
              'end=start+D-1。L<=endの壁は同じパンチで壊れている。'),
 'abc231_d': ('隣接条件を辺とするグラフを作ります。一列では一人に隣り合える人は二人までです。',
              '次数が3以上の頂点があると不可能です。次数が2以下でも閉じた輪は一列に置けないので、閉路を検出しましょう。',
              '疑似コード: 各辺で両端次数を増やす。次数>2ならNo。同じ成分を結ぶ辺なら閉路なのでNo、他は成分併合。全辺を処理して違反がなければYes。'),
 'abc232_d': ('右か下にだけ進むため、あるマスに着くまでに通るマス数は、その行番号と列番号の和で決まります。',
              '壁を避けながら到達可能なマスへ最長経路の値を伝えます。右下へ届かなくても、途中で止まる最長経路が答えになる点に注意しましょう。',
              '疑似コード: dp[0][0]=1。他は0。行列順に壁でないマスへ、到達済みの上と左から値+1を最大化して伝える。全マスのdpの最大値を出力。'),
 'abc233_d': ('連続部分列の和は、二つの累積和の差で表せます。負の要素もあるので、区間を伸縮するだけの方法には注意が必要です。',
              '現在の累積和をpとすると、以前の累積和p-Kの出現回数が、この位置で終わる条件を満たす区間の数です。',
              '疑似コード: counts[0]=1,prefix=0,answer=0。各Aでprefix+=A; answer+=counts[prefix-K]; '
              'counts[prefix]++。空の区間を数えないよう、答えへの加算後に現在の累積和を登録。')}
