"""Task-specific generators and *separate* output checkers for 13 ABC tasks.

Specifications were checked against the official AtCoder task pages for
ABC081, ABC083, ABC085, ABC086 and ABC087. Input constraints are enforced
before an expected output is published. These functions NEVER fetch or execute
code from the internet.
"""
from __future__ import annotations

from collections import Counter
from math import gcd
from random import Random
import re

SAMPLES = {
 'abc081_a': ('101\n','2','0/1 の3文字'),
 'abc081_b': ('3\n8 12 40\n','2','1<=N<=200; 1<=Ai<=10^9'),
 'abc081_c': ('5 2\n1 1 2 2 5\n','1','1<=K<=N<=200000; 1<=Ai<=N'),
 'abc083_a': ('3 8 7 1\n','Left','1<=A,B,C,D<=10'),
 'abc083_b': ('20 2 5\n','84','1<=N<=10000; 1<=A<=B<=36'),
 'abc083_c': ('3 20\n','3','1<=X<=Y<=10^18'),
 'abc085_a': ('2017/01/07\n','2018/01/07','2017/01/DD; 01<=DD<=31'),
 'abc085_b': ('4\n10\n8\n8\n6\n','3','1<=N<=100; 1<=di<=100'),
 'abc086_a': ('3 4\n','Even','1<=a,b<=10000'),
 'abc086_b': ('1 21\n','Yes','1<=a,b<=100'),
 'abc086_c': ('2\n3 1 2\n6 1 1\n','Yes','1<=N<=100000; 1<=ti<=100000 strictly increasing; 0<=xi,yi<=100000'),
 'abc087_a': ('1234\n150\n100\n','84','1<=A,B<=1000; A+B<=X<=10000'),
 'abc087_b': ('2\n2\n2\n100\n','2','0<=A,B,C<=50; sum>=1; X=50..20000 multiple 50'),
}
BATCH4 = {pid: {'sample_input': sin, 'sample_output': sout,
                'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                'constraints': constraint}
          for pid,(sin,sout,constraint) in SAMPLES.items()}


def validate(pid: str, data: str):
    if pid not in BATCH4:
        raise ValueError('未対応の問題ID')
    tok = data.split()
    if pid == 'abc081_a':
        if len(tok)!=1 or not re.fullmatch('[01]{3}',tok[0]):
            raise ValueError('3文字の0/1列が必要です')
        return tok[0]
    if pid == 'abc085_a':
        if len(tok)!=1 or not re.fullmatch(r'2017/01/(0[1-9]|[12][0-9]|3[01])',tok[0]):
            raise ValueError('2017/01/01〜2017/01/31に限定されます')
        return tok[0]
    if not tok or any(re.fullmatch(r'[0-9]+',s) is None for s in tok):
        raise ValueError('整数以外のトークン・負数があります')
    z = list(map(int,tok))
    if pid == 'abc081_b':
        n=z[0]; a=z[1:]
        if not 1<=n<=200 or len(a)!=n or any(not 1<=x<=10**9 for x in a):
            raise ValueError('N/Aの制約違反')
        return a
    if pid == 'abc081_c':
        if len(z)<3: raise ValueError('N K と数列が必要です')
        n,k=z[:2]; a=z[2:]
        if not 1<=k<=n<=200000 or len(a)!=n or any(not 1<=x<=n for x in a):
            raise ValueError('K/N/Aの制約違反')
        return k,a
    if pid == 'abc083_a':
        if len(z)!=4 or any(not 1<=x<=10 for x in z):raise ValueError('4整数が1〜10')
        return tuple(z)
    if pid == 'abc083_b':
        if len(z)!=3 or not 1<=z[0]<=10000 or not 1<=z[1]<=z[2]<=36:
            raise ValueError('N/A/Bの制約違反')
        return tuple(z)
    if pid == 'abc083_c':
        if len(z)!=2 or not 1<=z[0]<=z[1]<=10**18:raise ValueError('X/Yの制約違反')
        return tuple(z)
    if pid == 'abc085_b':
        n=z[0];a=z[1:]
        if not 1<=n<=100 or len(a)!=n or any(not 1<=x<=100 for x in a):
            raise ValueError('N/dの制約違反')
        return a
    if pid in ('abc086_a','abc086_b'):
        lim=10000 if pid=='abc086_a' else 100
        if len(z)!=2 or any(not 1<=x<=lim for x in z):raise ValueError('a,bの制約違反')
        return tuple(z)
    if pid == 'abc086_c':
        n=z[0]
        if not 1<=n<=100000 or len(z)!=1+3*n:raise ValueError('Nと3N個の整数が必要です')
        visits=list(zip(z[1::3],z[2::3],z[3::3]));old=0
        for t,x,y in visits:
            if not old<t<=100000 or not 0<=x<=100000 or not 0<=y<=100000:
                raise ValueError('ti昇順・xi/yi制約違反')
            old=t
        return visits
    if pid == 'abc087_a':
        if len(z)!=3:raise ValueError('X/A/Bの3整数が必要です')
        x,a,b=z
        if not 1<=a<=1000 or not 1<=b<=1000 or not a+b<=x<=10000:
            raise ValueError('X/A/Bの制約違反')
        return x,a,b
    if pid == 'abc087_b':
        if len(z)!=4:raise ValueError('A/B/C/Xの4整数が必要です')
        a,b,c,x=z
        if any(not 0<=t<=50 for t in (a,b,c)) or a+b+c==0 or not 50<=x<=20000 or x%50:
            raise ValueError('枚数・合計金額の制約違反')
        return a,b,c,x
    raise AssertionError(pid)


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str,str]]:
    if pid not in BATCH4 or not 1<=count<=80:raise ValueError('問題IDまたは生成数が不正')
    r=Random(seed);cases=[];seen=set()
    def add(cat,data):
        validate(pid,data)
        if data not in seen:
            cases.append({'category':cat,'input':data});seen.add(data)
        elif cat=='constraint_max':
            next(c for c in cases if c['input']==data)['category']='constraint_max'
    def nums(cat,*a):add(cat,' '.join(map(str,a))+'\n')
    def arr(cat,a,*,k=None,vertical=False):
        header=str(len(a)) if k is None else f'{len(a)} {k}'
        add(cat,header+'\n'+ ('\n' if vertical else ' ').join(map(str,a))+'\n')
    if pid=='abc081_a':
        for s in ('000','001','010','011','100','101','110','111'):add('exhaustive',s+'\n')
        if include_large:add('constraint_max','111\n')
    elif pid=='abc081_b':
        for a in ([1],[2],[2**29],[8,12,40],[1,10**9],[2,2,2],[2**20]*200,[1]*200,[2**29]*200):
            arr('usual',a)
        while len(cases)<count:
            n=r.randint(1,200);exp=r.randint(0,12)
            a=[max(1,min(10**9,r.randint(1,10**9)>>exp)<<exp) for _ in range(n)]
            a=[min(10**9,x) for x in a];arr('random',a)
        if include_large:arr('constraint_max',[2**29]*200)
    elif pid=='abc081_c':
        for a,k in [([1],1),([1,1,2,2,5],2),([1,2,3,4,5],1),([1]*20,1),([1,2]*20,2),([1,2]*20,1),([1,2,3]*20,2)]:
            arr('usual',a,k=k)
        while len(cases)<count:
            n=r.randint(1,70);k=r.randint(1,n);arr('random',[r.randint(1,n) for _ in range(n)],k=k)
        if include_large:arr('constraint_max',[1+(i%200000) for i in range(200000)],k=1)
    elif pid=='abc083_a':
        for a in [(1,1,1,1),(10,10,1,1),(1,1,10,10),(3,8,7,1),(3,4,5,2),(1,7,6,4),(10,10,10,10)]:nums('usual',*a)
        while len(cases)<count:nums('random',*(r.randint(1,10) for _ in range(4)))
        if include_large:nums('constraint_max',10,10,10,10)
    elif pid=='abc083_b':
        for a in [(1,1,1),(20,2,5),(10,1,2),(100,4,16),(10000,1,36),(10000,36,36),(9999,1,1),(100,1,36)]:nums('usual',*a)
        while len(cases)<count:
            n=r.randint(1,10000);a=r.randint(1,36);nums('random',n,a,r.randint(a,36))
        if include_large:nums('constraint_max',10000,1,36)
    elif pid=='abc083_c':
        for a in [(1,1),(1,2),(2,2),(3,20),(25,100),(1,10**18),(10**18,10**18),(10**18-1,10**18),(314159265,358979323846264338)]:nums('usual',*a)
        while len(cases)<count:
            x=r.randint(1,10**18);nums('random',x,r.randint(x,10**18))
        if include_large:nums('constraint_max',1,10**18)
    elif pid=='abc085_a':
        for d in (1,2,7,9,10,11,19,20,21,29,30,31):add('boundary',f'2017/01/{d:02d}\n')
        while len(cases)<count:add('random',f'2017/01/{r.randint(1,31):02d}\n')
        if include_large:add('constraint_max','2017/01/31\n')
    elif pid=='abc085_b':
        for a in ([1],[100],[10,8,8,6],[15]*3,[50,30,50,100,50,80,30],list(range(1,101)),[100]*100):arr('usual',a,vertical=True)
        while len(cases)<count:arr('random',[r.randint(1,100) for _ in range(r.randint(1,100))],vertical=True)
        if include_large:arr('constraint_max',list(range(1,101)),vertical=True)
    elif pid=='abc086_a':
        for a in [(1,1),(1,2),(3,4),(10000,10000),(9999,9999),(9999,10000),(10000,9999),(1,10000)]:nums('boundary',*a)
        while len(cases)<count:nums('random',r.randint(1,10000),r.randint(1,10000))
        if include_large:nums('constraint_max',10000,10000)
    elif pid=='abc086_b':
        for a in [(1,1),(1,21),(100,100),(12,10),(4,9),(9,9),(99,99),(1,44),(10,0)]:
            if a[1]>=1: nums('boundary',*a)
        while len(cases)<count:nums('random',r.randint(1,100),r.randint(1,100))
        if include_large:nums('constraint_max',100,100)
    elif pid=='abc086_c':
        def path(cat,v):add(cat,str(len(v))+'\n'+'\n'.join(' '.join(map(str,t)) for t in v)+'\n')
        for v in ([(1,0,0)],[(1,1,0)],[(2,0,0)],[(2,1,1)],[(2,2,1)],[(3,1,2),(6,1,1)],[(2,100,100)],[(5,1,1),(100,1,1)],[(1,1,0),(2,1,1),(3,2,1)]):path('usual',v)
        while len(cases)<count:
            n=r.randint(1,35);times=sorted(r.sample(range(1,100001),n))
            v=[(t,r.randint(0,100000),r.randint(0,100000)) for t in times]
            path('random',v)
        if include_large:path('constraint_max',[(t,t%2,0) for t in range(1,100001)])
    elif pid=='abc087_a':
        for x,a,b in [(2,1,1),(10000,1,1),(10000,1000,1000),(1234,150,100),(1000,108,108),(579,123,456),(7477,549,593),(10000,1,1000)]:
            add('usual',f'{x}\n{a}\n{b}\n')
        while len(cases)<count:
            a=r.randint(1,1000);b=r.randint(1,1000);x=r.randint(a+b,10000)
            add('random',f'{x}\n{a}\n{b}\n')
        if include_large:add('constraint_max','10000\n1000\n1000\n')
    else:
        for a,b,c,x in [(0,0,1,50),(1,0,0,50),(0,1,0,100),(2,2,2,100),(5,1,0,150),(30,40,50,6000),(50,50,50,20000),(50,50,50,50),(0,0,50,20000)]:
            if a+b+c: add('usual',f'{a}\n{b}\n{c}\n{x}\n')
        while len(cases)<count:
            a,b,c=(r.randint(0,50) for _ in range(3))
            if a+b+c==0:continue
            add('random',f'{a}\n{b}\n{c}\n{50*r.randint(1,400)}\n')
        if include_large:add('constraint_max','50\n50\n50\n20000\n')
    if include_large:
        maximum=[c for c in cases if c['category']=='constraint_max']
        if not maximum:raise RuntimeError('最大規模ケース生成に失敗')
        maximum=maximum[-1]
        return [c for c in cases if c['input'] != maximum['input']][:count]+[maximum]
    return cases[:count]


def independent_check(pid: str, data: str, expected: str) -> bool:
    v=validate(pid,data); s=expected.strip()
    if pid=='abc081_a':return s==str(sum(ch=='1' for ch in v))
    if pid=='abc081_b':
        g=gcd(*v);steps=0
        while g%2==0: g//=2;steps+=1
        return s==str(steps)
    if pid=='abc081_c':
        k,a=v;keep=sum(sorted(Counter(a).values(),reverse=True)[:k]);return s==str(len(a)-keep)
    if pid=='abc083_a':
        a,b,c,d=v;return s==('Left' if a+b>c+d else 'Right' if a+b<c+d else 'Balanced')
    if pid=='abc083_b':
        n,a,b=v;out=0
        for number in range(1,n+1):
            x=number;digit_sum=0
            while x: x,d=divmod(x,10);digit_sum+=d
            if a<=digit_sum<=b:out+=number
        return s==str(out)
    if pid=='abc083_c':
        x,y=v;return s==str((y//x).bit_length())
    if pid=='abc085_a':return s==v.replace('2017','2018',1)
    if pid=='abc085_b':return s==str(len(set(v)))
    if pid=='abc086_a':return s==('Odd' if all(x%2 for x in v) else 'Even')
    if pid=='abc086_b':
        from math import isqrt
        a,b=v;m=a*10**len(str(b))+b;return s==('Yes' if isqrt(m)**2==m else 'No')
    if pid=='abc086_c':
        old_t=old_x=old_y=0
        for t,x,y in v:
            dist=abs(x-old_x)+abs(y-old_y);dt=t-old_t
            if dt<dist or (dt-dist)&1:return s=='No'
            old_t,old_x,old_y=t,x,y
        return s=='Yes'
    if pid=='abc087_a':
        x,a,b=v;remaining=x-a;return s==str(remaining-(remaining//b)*b)
    if pid=='abc087_b':
        a,b,c,x=v;ways=0
        for n500 in range(a+1):
            for n100 in range(b+1):
                for n50 in range(c+1):
                    if n500*500+n100*100+n50*50==x:ways+=1
        return s==str(ways)
    raise AssertionError(pid)
