"""Evidence-bound backfill for ABC020/024/025 B; public statements checked."""
HINTS_BACKFILL_V72 = {
    'abc020_b': (
        'AとBを足す問題ではありません。Aの十進表記の右側にBの十進表記をそのままつなげる操作です。',
        'AとBを文字列として連結し、整数へ戻して2倍すると問題文どおりになります。Bの桁数を使って数式で連結しても構いません。',
        '''疑似コード:\nA,B = read_strings()\nvalue = int(A + B)\nprint(value * 2)''',
    ),
    'abc024_b': (
        '各人が通過すると、その時刻からT秒間ドアが開きます。隣り合う二人の間隔がT秒未満なら、開いている時間が重なります。',
        '最後の人については必ずT秒加えます。それ以前は、次の通過時刻との差とTの小さい方だけを加算すれば重複を数えません。',
        '''疑似コード:\nanswer=0\nfor i=0..N-2:\n  answer += min(T, A[i+1]-A[i])\nanswer += T\nprint(answer)''',
    ),
    'abc025_b': (
        '各移動で実際に進む距離は、指定距離をA以上B以下へ収めた値です。東西を符号で分けると合計しやすくなります。',
        '実距離は`min(B,max(A,d))`です。Eastなら加算、Westなら減算し、最後の符号に応じて出力形式を分岐します。',
        '''疑似コード:\npos=0\nfor direction,d in moves:\n  dist=min(B,max(A,d))\n  if direction=='East': pos += dist\n  else: pos -= dist\nif pos>0: print('East',pos)\nelif pos<0: print('West',-pos)\nelse: print(0)''',
    ),
}
