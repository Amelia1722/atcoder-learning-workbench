"""ABC093-098 A/B: original task-specific references and independent checks.

Specifications and official sample provenance: TEST_BANK_V14.md.
"""
from __future__ import annotations

from datetime import date
from itertools import product
from random import Random
import re

SAMPLES = {
 'abc093_a': ('bac\n', 'Yes', 'S has length 3, alphabet a/b/c'),
 'abc093_b': ('3 8 2\n', '3\n4\n7\n8', '1<=A<=B<=10**9;1<=K<=100'),
 'abc094_a': ('3 5 4\n', 'YES', '1<=A,B<=100;1<=X<=200'),
 'abc094_b': ('5 3 3\n1 2 4\n', '1', '1<=N<=100;1<=M<=100;1<=X<=N-1;1<=A1<...<AM<=N-1; Ai!=X'),
 'abc095_a': ('oxo\n', '900', 'S has length 3, alphabet o/x'),
 'abc095_b': ('3 1000\n120\n100\n140\n', '9', '2<=N<=100;1<=mi<=1000;sum(mi)<=X<=100000'),
 'abc096_a': ('5 5\n', '5', '1<=a<=12;2018-a-b must be a real calendar date'),
 'abc096_b': ('5 3 11\n1\n', '30', '1<=A,B,C<=50;1<=K<=10'),
 'abc097_a': ('4 7 9 3\n', 'Yes', '1<=a,b,c,d<=100'),
 'abc097_b': ('10\n', '9', '1<=X<=1000'),
 'abc098_a': ('3 1\n', '4', '-1000<=A,B<=1000'),
 'abc098_b': ('6\naabbca\n', '2', '2<=N<=100; S length N lowercase a-z'),
}
BATCH8 = {
 pid: {'sample_input': sin, 'sample_output': sout,
       'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
       'constraints': constraints}
 for pid, (sin, sout, constraints) in SAMPLES.items()
}


def validate(pid: str, data: str):
    if pid not in BATCH8: raise ValueError('未対応の問題ID')
    t = data.split()
    if pid in ('abc093_a', 'abc095_a'):
        alphabet = 'abc' if pid == 'abc093_a' else 'ox'
        if len(t) != 1 or re.fullmatch(f'[{alphabet}]{{3}}', t[0]) is None:
            raise ValueError('3文字の文字列が必要です')
        return t[0]
    if pid == 'abc098_b':
        if len(t) != 2 or re.fullmatch('[0-9]+', t[0]) is None:
            raise ValueError('NとSが必要です')
        n=int(t[0]);s=t[1]
        if not 2<=n<=100 or re.fullmatch('[a-z]+',s) is None or len(s)!=n:
            raise ValueError('N/Sの制約違反')
        return s
    if not t or any(re.fullmatch(r'-?[0-9]+',x) is None for x in t):
        raise ValueError('整数以外を含みます')
    z=list(map(int,t))
    if pid=='abc093_b':
        if len(z)!=3 or not 1<=z[0]<=z[1]<=10**9 or not 1<=z[2]<=100:
            raise ValueError('A/B/Kの制約違反')
        return tuple(z)
    if pid=='abc094_a':
        if len(z)!=3 or not 1<=z[0]<=100 or not 1<=z[1]<=100 or not 1<=z[2]<=200:
            raise ValueError('A/B/Xの制約違反')
        return tuple(z)
    if pid=='abc094_b':
        if len(z)<4: raise ValueError('N/M/X/料金所が必要です')
        n,m,x=z[:3];a=z[3:]
        if not 1<=n<=100 or not 1<=m<=100 or not 1<=x<n or len(a)!=m or not all(1<=v<n and v!=x for v in a) or a!=sorted(set(a)):
            raise ValueError('N/M/X/料金所の制約違反')
        return n,x,a
    if pid=='abc095_b':
        if len(z)<4: raise ValueError('N/X/mが必要です')
        n,x=z[:2];m=z[2:]
        if not 2<=n<=100 or len(m)!=n or any(not 1<=v<=1000 for v in m) or not sum(m)<=x<=100000:
            raise ValueError('N/X/mの制約違反')
        return x,m
    if pid=='abc096_a':
        if len(z)!=2: raise ValueError('a/bの2値が必要です')
        a,b=z
        try: date(2018,a,b)
        except ValueError as exc: raise ValueError('実在する2018年の年月日が必要です') from exc
        return a,b
    if pid=='abc096_b':
        if len(z)!=4 or any(not 1<=v<=50 for v in z[:3]) or not 1<=z[3]<=10:
            raise ValueError('A/B/C/Kの制約違反')
        return tuple(z)
    if pid=='abc097_a':
        if len(z)!=4 or any(not 1<=v<=100 for v in z):
            raise ValueError('a/b/c/dの制約違反')
        return tuple(z)
    if pid=='abc097_b':
        if len(z)!=1 or not 1<=z[0]<=1000:raise ValueError('Xの制約違反')
        return z[0]
    if pid=='abc098_a':
        if len(z)!=2 or any(not -1000<=v<=1000 for v in z):
            raise ValueError('A/Bの制約違反')
        return tuple(z)
    raise AssertionError(pid)


def generate(pid: str,count:int,seed:int,include_large:bool)->list[dict[str,str]]:
    if pid not in BATCH8 or not 1<=count<=80:raise ValueError('問題ID/件数不正')
    rnd=Random(seed);cases=[];seen=set()
    def add(kind:str,data:str):
        validate(pid,data)
        if data not in seen:
            seen.add(data);cases.append({'category':kind,'input':data})
        elif kind=='constraint_max':
            next(x for x in cases if x['input']==data)['category']=kind
    def nums(kind:str,*args):add(kind,' '.join(map(str,args))+'\n')
    if pid=='abc093_a':
        for s in ('bac','abc','aaa','bbb','ccc','aab','bba','cba','acb','bca','cab','bcc'):add('boundary',s+'\n')
        while len(cases)<count:add('random',''.join(rnd.choice('abc') for _ in range(3))+'\n')
        if include_large:add('constraint_max','ccc\n')
    elif pid=='abc093_b':
        for a,b,k in ((1,1,1),(1,2,100),(3,8,2),(4,8,3),(2,9,100),(10**9,10**9,100),(1,10**9,100),(10**9-199,10**9,100),(10**9-1,10**9,1),(1,199,100)):
            nums('boundary',a,b,k)
        while len(cases)<count:
            a=rnd.randint(1,10**9);nums('random',a,rnd.randint(a,10**9),rnd.randint(1,100))
        if include_large:nums('constraint_max',1,10**9,100)
    elif pid=='abc094_a':
        for a,b,x in ((1,1,1),(1,1,2),(1,1,3),(3,5,4),(2,2,6),(5,3,2),(100,100,200),(100,100,1),(100,100,100),(100,100,199)):
            nums('boundary',a,b,x)
        while len(cases)<count:nums('random',rnd.randint(1,100),rnd.randint(1,100),rnd.randint(1,200))
        if include_large:nums('constraint_max',100,100,200)
    elif pid=='abc094_b':
        def gate(kind,n,x,a):add(kind,f'{n} {len(a)} {x}\n'+' '.join(map(str,a))+'\n')
        for n,x,a in ((3,1,[2]),(3,2,[1]),(5,3,[1,2,4]),(7,2,[4,5,6]),(10,5,[1,2,3,4,6,8,9]),(100,50,list(range(1,50))+list(range(51,100))),(100,1,list(range(2,100))),(100,99,list(range(1,99)))):
            gate('boundary',n,x,a)
        while len(cases)<count:
            n=rnd.randint(3,100);x=rnd.randint(1,n-1);candidates=[v for v in range(1,n) if v!=x]
            m=rnd.randint(1,min(len(candidates),100));gate('random',n,x,sorted(rnd.sample(candidates,m)))
        if include_large:gate('constraint_max',100,50,list(range(1,50))+list(range(51,100)))
    elif pid=='abc095_a':
        for seq in product('ox',repeat=3):add('boundary',''.join(seq)+'\n')
        # only 8 unique valid inputs exist; cannot manufacture distinct random cases.
        if include_large:add('constraint_max','ooo\n')
    elif pid=='abc095_b':
        def donut(kind,x,m):add(kind,f'{len(m)} {x}\n'+'\n'.join(map(str,m))+'\n')
        for x,m in ((2,[1,1]),(1000,[120,100,140]),(100000,[1,1]),(100000,[1]*100),(100000,[1000]*100),(2000,[1000,1000]),(100000,[1000]*99+[1]),(100000,[1]*99+[1000])):
            donut('boundary',x,m)
        while len(cases)<count:
            n=rnd.randint(2,100);m=[rnd.randint(1,1000) for _ in range(n)];x=rnd.randint(sum(m),100000);donut('random',x,m)
        if include_large:donut('constraint_max',100000,[1]*100)
    elif pid=='abc096_a':
        from calendar import monthrange
        for a,b in ((1,1),(1,31),(2,1),(2,28),(5,5),(5,4),(5,6),(11,30),(12,31),(12,1)):
            nums('boundary',a,b)
        while len(cases)<count:
            a=rnd.randint(1,12);nums('random',a,rnd.randint(1,monthrange(2018,a)[1]))
        if include_large:nums('constraint_max',12,31)
    elif pid=='abc096_b':
        def trip(kind,a,b,c,k):add(kind,f'{a} {b} {c}\n{k}\n')
        for a,b,c,k in ((1,1,1,1),(1,1,1,10),(5,3,11,1),(3,3,4,2),(50,50,50,10),(50,1,1,10),(1,50,1,10),(1,1,50,10),(50,50,49,1)):
            trip('boundary',a,b,c,k)
        while len(cases)<count:trip('random',rnd.randint(1,50),rnd.randint(1,50),rnd.randint(1,50),rnd.randint(1,10))
        if include_large:trip('constraint_max',50,50,50,10)
    elif pid=='abc097_a':
        for a,b,c,d in ((1,1,1,1),(100,100,100,100),(4,7,9,3),(1,100,2,10),(1,100,100,1),(1,2,3,1),(1,2,4,1),(1,100,1,1),(100,1,2,100)):
            nums('boundary',a,b,c,d)
        while len(cases)<count:nums('random',*(rnd.randint(1,100) for _ in range(4)))
        if include_large:nums('constraint_max',100,100,100,100)
    elif pid=='abc097_b':
        for x in (1,2,3,4,7,8,9,10,16,25,26,27,28,999,1000,961,997,512):nums('boundary',x)
        while len(cases)<count:nums('random',rnd.randint(1,1000))
        if include_large:nums('constraint_max',1000)
    elif pid=='abc098_a':
        for a,b in ((-1000,-1000),(-1000,1000),(1000,-1000),(1000,1000),(0,0),(3,1),(4,-2),(1,1),(-1,1),(0,-1000)):
            nums('boundary',a,b)
        while len(cases)<count:nums('random',rnd.randint(-1000,1000),rnd.randint(-1000,1000))
        if include_large:nums('constraint_max',1000,1000)
    else: # abc098_b
        def word(kind,s):add(kind,f'{len(s)}\n{s}\n')
        for s in ('aa','ab','aabbca','a'*100,'abcdefghijklmnopqrstuvwxyz'*3+'abcdefghijklmnopqrstuv','ab'*50,'abcdefghijklmnopqrstuvwxyz'*3+'abcdefghijklmnopqrstuv','a'*50+'b'*50,'abcdefghijklmnopqrstuvwxyz','tgxgdqkyjzhyputjjtllptdfxocrylqfqjynmfbfucbir'):
            if 2<=len(s)<=100:word('boundary',s)
        while len(cases)<count:
            n=rnd.randint(2,100);word('random',''.join(rnd.choice('abcdefghijklmnopqrstuvwxyz' if rnd.randrange(3)==0 else 'abcde') for _ in range(n)))
        if include_large:word('constraint_max','abcdefghijklmnopqrstuvwxyz'*3+'abcdefghijklmnopqrstuv')
    if include_large:
        maximum=[c for c in cases if c['category']=='constraint_max']
        if not maximum:raise RuntimeError('最大規模ケースがありません')
        last=maximum[-1]
        return [c for c in cases if c['input']!=last['input']][:count]+[last]
    return cases[:count]


def independent_check(pid:str,data:str,expected:str)->bool:
    v=validate(pid,data);ans=expected.strip()
    if pid=='abc093_a':return ans==('Yes' if sorted(v)==list('abc') else 'No')
    if pid=='abc093_b':
        a,b,k=v
        # B-A may be 10**9: enumerate at most 2*K boundary integers.
        result=sorted(set(range(a,min(b+1,a+k)))|set(range(max(a,b-k+1),b+1)))
        return ans=='\n'.join(map(str,result))
    if pid=='abc094_a':
        a,b,x=v
        return ans==('YES' if any(a+i==x for i in range(b+1)) else 'NO')
    if pid=='abc094_b':
        n,x,gates=v
        left=sum(1 for position in range(x-1,0,-1) if position in gates)
        right=sum(1 for position in range(x+1,n) if position in gates)
        return ans==str(min(left,right))
    if pid=='abc095_a':
        return ans==str(sum(100 if ch=='o' else 0 for ch in v)+700)
    if pid=='abc095_b':
        x,m=v
        remain=x-sum(m);count=len(m); cheapest=min(m)
        while remain>=cheapest:
            remain-=cheapest;count+=1
        return ans==str(count)
    if pid=='abc096_a':
        a,b=v
        return ans==str(sum(date(2018,month,month)<=date(2018,a,b) for month in range(1,13)))
    if pid=='abc096_b':
        a,b,c,k=v
        values=[a,b,c]
        for _ in range(k):
            idx=values.index(max(values));values[idx]*=2
        return ans==str(sum(values))
    if pid=='abc097_a':
        a,b,c,d=v
        # Undirected path reachability in the graph with edges no longer than d.
        graph={i:{j for j,xj in enumerate((a,b,c)) if abs(xi-xj)<=d} for i,xi in enumerate((a,b,c))}
        seen={0};front=[0]
        while front:
            i=front.pop()
            for j in graph[i]-seen:seen.add(j);front.append(j)
        return ans==('Yes' if 2 in seen else 'No')
    if pid=='abc097_b':
        x=v
        power={1}
        for base in range(2,32):
            number=base*base
            while number<=x:
                power.add(number);number*=base
        return ans==str(max(power))
    if pid=='abc098_a':
        a,b=v
        return ans==str(sorted((a+b,a-b,a*b))[-1])
    if pid=='abc098_b':
        s=v
        best=0
        for i in range(1,len(s)):
            common=0
            for ch in 'abcdefghijklmnopqrstuvwxyz':
                if ch in s[:i] and ch in s[i:]:common+=1
            best=max(best,common)
        return ans==str(best)
    raise AssertionError(pid)
