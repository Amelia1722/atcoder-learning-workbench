"""Reviewed C tasks: streaming rank, offline bingo, Gray-code constraints."""
from __future__ import annotations
from bisect import bisect_left
from math import comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(353,359))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CASE_COUNTS={p:7 if p=='abc357_c' else 18 for p in TASKS}
Case=dict[str,str]
Data=tuple[object,...]
Tests=tuple[tuple[tuple[int,...],str],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==353:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=300000 and all(1<=v<10**8 for v in a),'values');return (a,)
    if number==354:
        n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for pair in a for v in pair) and len({x for x,y in a})==n and len({y for x,y in a})==n,'cards');return (a,)
    if number==355:
        require(len(rows)==2,'shape');n,t=ints(rows[0],2);a=ints(rows[1],t);require(2<=n<=2000 and 1<=t<=min(n*n,200000) and all(1<=v<=n*n for v in a) and len(set(a))==t,'bingo');return n,a
    if number==356:
        n,m,k=ints(rows[0],3);require(1<=k<=n<=15 and 1<=m<=100 and len(rows)==m+1,'shape');tests=[]
        for row in rows[1:]:
            fields=row.split(' ');require(fields[-1] in ('o','x'),'result');a=ints(' '.join(fields[:-1]));c=a[0];keys=a[1:];require(1<=c<=n and len(keys)==c and len(set(keys))==c and all(1<=v<=n for v in keys),'keys');tests.append((keys,fields[-1]))
        return n,k,tuple(tests)
    if number==357:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(0<=n<=6,'level');return (n,)
    n,m=ints(rows[0],2);require(1<=n<=10 and 1<=m<=10 and len(rows)==n+1,'shape');a=tuple(rows[1:]);require(all(len(s)==m and set(s)<=set('ox') and 'o' in s for s in a) and all(any(s[j]=='o' for s in a) for j in range(m)),'flavors');return m,a
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==353:
        a=cast(tuple[int,...],data[0]);coords=sorted(set(a));tree=[0]*(len(coords)+1);answer=0;total=0
        for j,v in enumerate(a):
            rank=bisect_left(coords,10**8-v);below=0;p=rank
            while p:below+=tree[p];p-=p&-p
            answer+=total+j*v-(j-below)*10**8;total+=v;p=bisect_left(coords,v)+1
            while p<len(tree):tree[p]+=1;p+=p&-p
        return str(answer)
    if number==354:
        a=cast(tuple[tuple[int,int],...],data[0]);strongest=0;keep=[]
        for cost,strength,j in sorted((c,v,j+1) for j,(v,c) in enumerate(a)):
            if strength>strongest:keep.append(j)
            strongest=max(strongest,strength)
        keep.sort();return str(len(keep))+'\n'+' '.join(map(str,keep))
    if number==355:
        n,a=cast(tuple[int,tuple[int,...]],data);rowtimes=[[] for _ in range(n)];coltimes=[[] for _ in range(n)];diags=[[],[]]
        for t,v in enumerate(a,1):
            r,c=divmod(v-1,n);rowtimes[r].append(t);coltimes[c].append(t)
            if r==c:diags[0].append(t)
            if r+c==n-1:diags[1].append(t)
        finishes=[max(seq) for seq in rowtimes+coltimes+diags if len(seq)==n];return str(min(finishes) if finishes else -1)
    if number==356:
        n,k,tests=cast(tuple[int,int,Tests],data);touch=[[] for _ in range(n)];counts=[0]*len(tests);bad=sum(result=='o' for keys,result in tests);answer=int(bad==0);previous=0
        for j,(keys,_) in enumerate(tests):
            for key in keys:touch[key-1].append(j)
        for index in range(1,1<<n):
            gray=index^(index>>1);flip=(gray^previous).bit_length()-1;delta=1 if gray>>flip&1 else -1
            for j in touch[flip]:
                desired=tests[j][1]=='o';bad-=int((counts[j]>=k)!=desired);counts[j]+=delta;bad+=int((counts[j]>=k)!=desired)
            answer+=bad==0;previous=gray
        return str(answer)
    if number==357:
        n=cast(int,data[0]);size=3**n;digits=[tuple((x//3**j)%3 for j in range(n)) for x in range(size)];return '\n'.join(''.join('.' if any(x==y==1 for x,y in zip(r,c)) else '#' for c in digits) for r in digits)
    m,a=cast(tuple[int,tuple[str,...]],data);masks=[sum((ch=='o')<<j for j,ch in enumerate(s)) for s in a];n=len(a)
    for k in range(1,n+1):
        ways=0
        for missing in range(1<<m):
            allowed=sum(not (mask&missing) for mask in masks);ways+=(-1 if missing.bit_count()%2 else 1)*comb(allowed,k)
        if ways:return str(k)
    raise ValueError('uncovered')
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc353_c':"n=int(input());a=sorted(map(int,input().split()));answer=sum(a)*(n-1);right=n-1;wrapped=0\nfor left in range(n):\n while right>left and a[left]+a[right]>=10**8:right-=1\n wrapped+=n-1-max(left,right)\nprint(answer-wrapped*10**8)\n",
'abc354_c':"n=int(input());a=[(*map(int,input().split()),j+1) for j in range(n)];least=10**18;out=[]\nfor strength,cost,j in sorted(a,reverse=True):\n if cost<least:out.append(j);least=cost\nprint(len(out));print(*sorted(out))\n",
'abc355_c':"n,t=map(int,input().split());a=list(map(int,input().split()));rows=[0]*n;cols=[0]*n;diag=[0,0];answer=-1\nfor turn,v in enumerate(a,1):\n r,c=divmod(v-1,n);rows[r]+=1;cols[c]+=1\n if r==c:diag[0]+=1\n if r+c==n-1:diag[1]+=1\n if n in (rows[r],cols[c],*diag):answer=turn;break\nprint(answer)\n",
'abc356_c':"n,m,k=map(int,input().split());tests=[]\nfor _ in range(m):\n parts=input().split();mask=sum(1<<(int(v)-1) for v in parts[1:-1]);tests.append((mask,parts[-1]=='o'))\nprint(sum(all(((mask&chosen).bit_count()>=k)==result for mask,result in tests) for chosen in range(1<<n)))\n",
'abc357_c':"n=int(input());grid=['#']\nfor _ in range(n):\n size=len(grid);grid=[row*3 for row in grid]+[row+'.'*size+row for row in grid]+[row*3 for row in grid]\nprint(*grid,sep='\\n')\n",
'abc358_c':"n,m=map(int,input().split());a=[sum((ch=='o')<<j for j,ch in enumerate(input())) for _ in range(n)];answer=n\nfor chosen in range(1,1<<n):\n covered=0\n for j in range(n):\n  if chosen>>j&1:covered|=a[j]\n if covered==(1<<m)-1:answer=min(answer,chosen.bit_count())\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17200+number)
    if number==353:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1,1],[1,99999999],[49999999,50000000],[50000000]*3)];raws.extend(arr([rng.randint(1,99999999) for _ in range(n)]) for n in range(3,15));raws.extend([arr([1,99999999]*150000),arr([99999999]*300000)])
    elif number==354:
        def cards(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(f'{x} {y}\n' for x,y in a)
        raws=[cards(a) for a in ([(1,1),(2,2)],[(1,2),(2,1)],[(2,1),(1,2)],[(1,3),(2,2),(3,1)])]
        for n in range(3,15):x=rng.sample(range(1,1000),n);y=rng.sample(range(1,1000),n);raws.append(cards(list(zip(x,y))))
        raws.extend([cards([(j+1,200000-j) for j in range(200000)]),cards([(10**9-199999+j,10**9-199999+j) for j in range(200000)])])
    elif number==355:
        def bingo(n:int,a:list[int])->str:return f'{n} {len(a)}\n'+line(a)
        raws=[bingo(2,[1]),bingo(2,[1,2]),bingo(2,[1,4]),bingo(3,[1,5,9])];raws.extend(bingo(n,rng.sample(range(1,n*n+1),min(n*n,n+5))) for n in range(3,15));raws.extend([bingo(2000,[1+r*2000+(r+c)%2000 for c in range(1,101) for r in range(2000)]),bingo(2000,list(range(1,200001)))])
    elif number==356:
        def keys(n:int,k:int,tests:list[tuple[list[int],str]])->str:return f'{n} {len(tests)} {k}\n'+''.join(f'{len(a)} '+' '.join(map(str,a))+' '+result+'\n' for a,result in tests)
        raws=[keys(1,1,[([1],'x')]),keys(1,1,[([1],'o')]),keys(1,1,[([1],'o'),([1],'x')]),keys(3,2,[([1,3],'o')])]
        for j in range(12):n=j+2;k=rng.randint(1,n);tests=[(rng.sample(range(1,n+1),rng.randint(1,n)),rng.choice('ox')) for _ in range(j+3)];raws.append(keys(n,k,tests))
        raws.extend([keys(15,1,[(list(range(1,16)),'o')]*100),keys(15,15,[(list(range(1,16)),'o')]*100)])
    elif number==357:raws=[f'{n}\n' for n in range(7)]
    else:
        def popcorn(a:list[str])->str:return f'{len(a)} {len(a[0])}\n'+'\n'.join(a)+'\n'
        raws=[popcorn(a) for a in (['o'],['oo'],['o','o'],['ox','xo'])]
        for j in range(12):
            n=3+j%8;m=3+j//4;a=[['o' if rng.randrange(2) else 'x' for _ in range(m)] for _ in range(n)]
            for r in range(n):a[r][r%m]='o'
            for c in range(m):a[c%n][c]='o'
            raws.append(popcorn([''.join(row) for row in a]))
        raws.extend([popcorn([''.join('o' if r==c else 'x' for c in range(10)) for r in range(10)]),popcorn(['o'*10]*10)])
    require(len(raws)==len(set(raws))==CASE_COUNTS[pid],'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==len(raws)-1 else 'boundary' if j<4 or j==len(raws)-2 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc353_c':('余りを取らない和では各要素がN-1回登場します。','和が10^8以上のペアだけ10^8を引きます。昇順配列の2本のポインタで数えましょう。','疑似コード: answer=(N-1)*sum(A); Aをsort; 左端iを増やしながら右境界jを縮めA[i]+A[j]<10^8とする; iより右の超過ペア数を合計して10^8倍をanswerから引く。'),
'abc354_c':('より強くて安いカードがあれば、そのカードは不要です。','強さの降順で見れば、これまでの最小コストより安いカードだけが残ります。','疑似コード: strength降順sort; least=∞; cost<leastなら番号を保存しleast=cost; 保存した番号を昇順に出力。'),
'abc355_c':('各行・列と2本の対角線の印の数を管理します。','宣言番号から行列位置を求め、いずれかのカウンタがNになる最初の時点を探します。','疑似コード: (r,c)=divmod(A-1,N); row[r]++,col[c]++; r=cやr+c=N-1なら対応diag++; どれかNになればturnを出力、最後までなければ-1。'),
'abc356_c':('正しい鍵の集合は2^N通りで、Nは15以下です。','集合をbitmaskで表し、各テスト集合との共通bit数を調べます。','疑似コード: chosen=0..2^N-1; 全テストについてpopcount(chosen & mask)>=Kと結果oが一致するか確認; 全て一致するchosenを数える。'),
'abc357_c':('前のレベルの模様を3×3に並べ、中央だけ白くします。','文字列の配列を使うと上下は3回連結、中央の段は模様・白・模様になります。','疑似コード: grid=[#]; N回、top=[row*3]、middle=[row+白size文字+row]、bottom=topを連結してgridを更新; 全行を出力。'),
'abc358_c':('売り場を選ぶ部分集合は最大2^10通りです。','売られる味をbitmaskにして、選んだ売り場のORが全味を覆うか確認します。','疑似コード: 各売り場をmask化; chosen=1..2^N-1で選んだmaskをOR; 全Mbitが立てばpopcount(chosen)で最小値を更新。')}

TITLES={'abc353_c': 'Sigma Problem', 'abc354_c': 'AtCoder Magics', 'abc355_c': 'Bingo 2', 'abc356_c': 'Keys', 'abc357_c': 'Sierpinski carpet', 'abc358_c': 'Popcorn'}
PUBLISHED_SAMPLES={'abc353_c': [{'input': '3\n3 50000001 50000002\n', 'expected': '100000012\n'}, {'input': '5\n1 3 99999999 99999994 1000000\n', 'expected': '303999988\n'}], 'abc354_c': [{'input': '3\n2 4\n1 1\n3 2\n', 'expected': '2\n2 3\n'}, {'input': '5\n1 1\n10 2\n100 3\n1000 4\n10000 5\n', 'expected': '5\n1 2 3 4 5\n'}, {'input': '6\n32 101\n65 78\n2 29\n46 55\n103 130\n52 40\n', 'expected': '4\n2 3 5 6\n'}], 'abc355_c': [{'input': '3 5\n5 1 8 9 7\n', 'expected': '4\n'}, {'input': '3 5\n4 2 9 7 5\n', 'expected': '-1\n'}, {'input': '4 12\n13 9 6 5 2 7 16 14 8 3 10 11\n', 'expected': '9\n'}], 'abc356_c': [{'input': '3 2 2\n3 1 2 3 o\n2 2 3 x\n', 'expected': '2\n'}, {'input': '4 5 3\n3 1 2 3 o\n3 2 3 4 o\n3 3 4 1 o\n3 4 1 2 o\n4 1 2 3 4 x\n', 'expected': '0\n'}, {'input': '11 4 9\n10 1 2 3 4 5 6 7 8 9 10 o\n11 1 2 3 4 5 6 7 8 9 10 11 o\n10 11 10 9 8 7 6 5 4 3 2 x\n10 11 9 1 4 3 7 5 6 2 10 x\n', 'expected': '8\n'}], 'abc357_c': [{'input': '1\n', 'expected': '###\n#.#\n###\n'}, {'input': '2\n', 'expected': '#########\n#.##.##.#\n#########\n###...###\n#.#...#.#\n###...###\n#########\n#.##.##.#\n#########\n'}], 'abc358_c': [{'input': '3 5\noooxx\nxooox\nxxooo\n', 'expected': '2\n'}, {'input': '3 2\noo\nox\nxo\n', 'expected': '1\n'}, {'input': '8 6\nxxoxxo\nxxoxxx\nxoxxxx\nxxxoxx\nxxoooo\nxxxxox\nxoxxox\noxoxxo\n', 'expected': '3\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
