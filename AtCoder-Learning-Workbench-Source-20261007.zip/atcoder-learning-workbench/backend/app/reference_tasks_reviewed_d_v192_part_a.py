"""Private ABC240..245 D: predecessor history, AVL ranks and low-degree division."""
from __future__ import annotations
from dataclasses import dataclass
from typing import cast
from itertools import combinations,permutations
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(240,246));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def binary_walk(x:int,s:str)->int:
    bits=list(bin(x)[2:])
    for ch in s:
        if ch=='U':require(len(bits)>1,'root parent');bits.pop()
        else:bits.append('0' if ch=='L' else '1')
    require(len(bits)<=60,'final length');out=int(''.join(bits),2);require(out<=10**18,'final vertex');return out

def convolution(a:tuple[int,...],b:tuple[int,...])->tuple[int,...]:
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return tuple(out)

def low_division(a:tuple[int,...],c:tuple[int,...])->tuple[int,...]:
    first=next(i for i,v in enumerate(a) if v);m=len(c)-len(a);b=[]
    require(all(v==0 for v in c[:first]),'initial zero coefficients')
    for j in range(m+1):
        value=c[first+j]-sum(a[first+i]*b[j-i] for i in range(1,min(len(a)-first-1,j)+1));require(value%a[first]==0,'integer quotient');b.append(value//a[first]);require(abs(b[-1])<=100,'B coefficient')
    require(b[-1]!=0 and convolution(a,tuple(b))==c,'B degree/product');return tuple(b)

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc240_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=200000,'N');a=ints(rows[1],n);require(all(2<=v<=200000 for v in a),'A');return (a,)
    if pid=='abc241_d':
        q=ints(rows[0],1)[0];require(1<=q<=200000 and len(rows)==q+1,'Q/shape');queries=tuple(ints(row) for row in rows[1:]);require(all(r[0] in (1,2,3) and len(r)==(2 if r[0]==1 else 3) and 1<=r[1]<=10**18 and (r[0]==1 or 1<=r[2]<=5) for r in queries),'queries');return (queries,)
    if pid=='abc242_d':
        require(len(rows)>=3 and re.fullmatch('[ABC]{1,100000}',rows[0]) is not None,'S');q=ints(rows[1],1)[0];require(1<=q<=100000 and len(rows)==q+2,'Q/shape');queries=tuple(ints(row,2) for row in rows[2:]);require(all(0<=t<=10**18 and 1<=k<=10**18 and (t>=60 or k<=len(rows[0])<<t) for t,k in queries),'query positions');return rows[0],queries
    if pid=='abc243_d':
        require(len(rows)==2,'shape');n,x=ints(rows[0],2);require(1<=n<=10**6 and 1<=x<=10**18 and len(rows[1])==n and re.fullmatch('[ULR]+',rows[1]) is not None,'N/X/S');binary_walk(x,rows[1]);return x,rows[1]
    if pid=='abc244_d':
        require(len(rows)==2 and all(re.fullmatch('[RGB] [RGB] [RGB]',row) is not None and len(set(row.split()))==3 for row in rows),'hat permutations');return tuple(rows[0].split()),tuple(rows[1].split())
    require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(1<=n<100 and 1<=m<100,'degrees');a=ints(rows[1],n+1);c=ints(rows[2],n+m+1);require(all(abs(v)<=100 for v in a) and all(abs(v)<=10**6 for v in c) and a[-1]!=0 and c[-1]!=0,'coefficients/degrees');low_division(a,c);return a,c

def ball_history(a:tuple[int,...])->list[int]:
    counts=[0]*len(a);before=[-1]*len(a);top=-1;length=0;out=[]
    for i,value in enumerate(a):
        if top>=0 and a[top]==value:counts[i]=counts[top]+1;before[i]=before[top]
        else:counts[i]=1;before[i]=top
        length+=1
        if counts[i]==value:length-=value;top=before[i]
        else:top=i
        out.append(length)
    return out

@dataclass(slots=True)
class RankNode:
    key:int
    count:int=1
    size:int=1
    height:int=1
    left:RankNode|None=None
    right:RankNode|None=None

def size(t:RankNode|None)->int:return t.size if t else 0
def height(t:RankNode|None)->int:return t.height if t else 0
def pull(t:RankNode)->None:t.size=t.count+size(t.left)+size(t.right);t.height=1+max(height(t.left),height(t.right))
def rotate_left(t:RankNode)->RankNode:
    u=cast(RankNode,t.right);t.right=u.left;u.left=t;pull(t);pull(u);return u
def rotate_right(t:RankNode)->RankNode:
    u=cast(RankNode,t.left);t.left=u.right;u.right=t;pull(t);pull(u);return u

def insert(t:RankNode|None,key:int)->RankNode:
    if t is None:return RankNode(key)
    if key==t.key:t.count+=1
    elif key<t.key:t.left=insert(t.left,key)
    else:t.right=insert(t.right,key)
    pull(t)
    if height(t.left)>height(t.right)+1:
        left=cast(RankNode,t.left)
        if height(left.right)>height(left.left):t.left=rotate_left(left)
        return rotate_right(t)
    if height(t.right)>height(t.left)+1:
        right=cast(RankNode,t.right)
        if height(right.left)>height(right.right):t.right=rotate_right(right)
        return rotate_left(t)
    return t

def bound_rank(t:RankNode|None,x:int,inclusive:bool)->int:
    out=0
    while t is not None:
        if t.key<x or inclusive and t.key==x:out+=size(t.left)+t.count;t=t.right
        else:t=t.left
    return out

def select_rank(t:RankNode|None,k:int)->int:
    if not 1<=k<=size(t):return -1
    while t is not None:
        left=size(t.left)
        if k<=left:t=t.left
        elif k<=left+t.count:return t.key
        else:k-=left+t.count;t=t.right
    raise AssertionError('rank tree')

def sequence_avl(queries:tuple[tuple[int,...],...])->list[int]:
    tree=None;out=[]
    for row in queries:
        if row[0]==1:tree=insert(tree,row[1])
        elif row[0]==2:out.append(select_rank(tree,bound_rank(tree,row[1],True)-row[2]+1))
        else:out.append(select_rank(tree,bound_rank(tree,row[1],False)+row[2]))
    return out

def character_parent(s:str,t:int,k:int)->str:
    def letter(depth:int,index:int)->int:
        if depth==0:return ord(s[index-1])-65
        if index==1:return (ord(s[0])-65+depth)%3
        return (letter(depth-1,(index+1)//2)+(1 if index%2 else 2))%3
    return chr(65+letter(t,k))

def hats_two_swaps(s:tuple[str,...],t:tuple[str,...])->bool:
    reachable={s}
    for _ in range(2):
        next_states=set()
        for state in reachable:
            for i,j in combinations(range(3),2):row=list(state);row[i],row[j]=row[j],row[i];next_states.add(tuple(row))
        reachable=next_states
    return t in reachable

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc240_d':return ''.join(str(v)+'\n' for v in ball_history(cast(tuple[int,...],data[0])))
    if pid=='abc241_d':return ''.join(str(v)+'\n' for v in sequence_avl(cast(tuple[tuple[int,...],...],data[0])))
    if pid=='abc242_d':
        s,queries=cast(tuple[str,tuple[tuple[int,int],...]],data);return ''.join(character_parent(s,t,k)+'\n' for t,k in queries)
    if pid=='abc243_d':return str(binary_walk(*cast(tuple[int,str],data)))+'\n'
    if pid=='abc244_d':return ('Yes' if hats_two_swaps(*cast(tuple[tuple[str,...],tuple[str,...]],data)) else 'No')+'\n'
    return line(low_division(*cast(tuple[tuple[int,...],tuple[int,...]],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc240_d':'''n=int(input());a=list(map(int,input().split()));stack=[];total=0;out=[]
for x in a:
 if stack and stack[-1][0]==x:stack[-1][1]+=1
 else:stack.append([x,1])
 total+=1
 if stack[-1][1]==x:total-=x;stack.pop()
 out.append(str(total))
print('\\n'.join(out))
''',
'abc241_d':'''import sys,bisect
q=int(input());queries=[tuple(map(int,input().split())) for _ in range(q)];values=sorted({row[1] for row in queries if row[0]==1});n=len(values);bit=[0]*(n+1);total=0;out=[]
def prefix(i):
 result=0
 while i:result+=bit[i];i-=i&-i
 return result
def select(k):
 if not 1<=k<=total:return -1
 at=0;step=1<<(n.bit_length()-1)
 while step:
  nxt=at+step
  if nxt<=n and bit[nxt]<k:at=nxt;k-=bit[nxt]
  step>>=1
 return values[at]
for row in queries:
 if row[0]==1:
  i=bisect.bisect_left(values,row[1])+1;total+=1
  while i<=n:bit[i]+=1;i+=i&-i
 elif row[0]==2:out.append(str(select(prefix(bisect.bisect_right(values,row[1]))-row[2]+1)))
 else:out.append(str(select(prefix(bisect.bisect_left(values,row[1]))+row[2])))
sys.stdout.write(''.join(v+'\\n' for v in out))
''',
'abc242_d':'''s=input();q=int(input());out=[]
for _ in range(q):
 t,k=map(int,input().split());index=k-1;root=index>>t if t<60 else 0;path=index-((root<<t) if t<60 else 0);out.append(chr(65+(ord(s[root])-65+t+path.bit_count())%3))
print('\\n'.join(out))
''',
'abc243_d':'''n,x=map(int,input().split());s=input();moves=[]
for c in s:
 if c=='U' and moves and moves[-1] in 'LR':moves.pop()
 else:moves.append(c)
for c in moves:
 if c=='U':x//=2
 elif c=='L':x*=2
 else:x=x*2+1
print(x)
''',
'abc244_d':'''s=input().split();t=input().split();p=[s.index(x) for x in t];inversions=sum(p[i]>p[j] for i in range(3) for j in range(i+1,3));print('Yes' if inversions%2==0 else 'No')
''',
'abc245_d':'''n,m=map(int,input().split());a=list(map(int,input().split()));c=list(map(int,input().split()));b=[0]*(m+1)
for j in range(m,-1,-1):
 b[j]=c[n+j]//a[n]
 for i in range(n+1):c[i+j]-=a[i]*b[j]
print(*b)
'''}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(192000+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc240_d':
        arrays=[[2],[200000],[2,2],[3,2,2,3,3]]
        arrays+=[[rng.randrange(2,8) for _ in range(n)] for n in range(3,15)];arrays+=[[2,3]*100000,[200000]*200000];raws=[str(len(a))+'\n'+line(a) for a in arrays]
    elif pid=='abc241_d':
        def queries(q:list[tuple[int,...]])->str:return str(len(q))+'\n'+''.join(line(row) for row in q)
        raws=[queries([(1,1)]),queries([(2,1,1)]),queries([(3,10**18,5)]),queries([(1,5)]*5+[(2,5,5),(3,5,5),(2,4,1),(3,6,1)])]
        for n in range(3,15):
            rows=[]
            for _ in range(n*7):
                kind=rng.randrange(1,4);x=rng.choice([1,10**18,rng.randrange(1,50)]);rows.append((1,x) if kind==1 else(kind,x,rng.randrange(1,6)))
            raws.append(queries(rows))
        raws+=[queries([(1,j) for j in range(1,100001)]+[(2,10**18,5)]*100000),queries([(3,10**18,5)]*200000)]
    elif pid=='abc242_d':
        def text(s:str,q:list[tuple[int,int]])->str:return s+'\n'+str(len(q))+'\n'+''.join(line(row) for row in q)
        raws=[text('A',[(0,1)]),text('C',[(10**18,10**18)]),text('ABC',[(0,3),(1,6)]),text('B',[(59,2**59),(60,10**18)])]
        for n in range(2,14):
            s=''.join(rng.choice('ABC') for _ in range(n));q=[]
            for _ in range(n*3):t=rng.choice([0,1,5,59,60,10**18]);q.append((t,rng.randrange(1,min(10**18,n*(1<<t) if t<60 else 10**18)+1)))
            raws.append(text(s,q))
        raws+=[text('ABC'*33333+'A',[(0,100000)]*100000),text('C'*100000,[(10**18,10**18)]*100000)]
    elif pid=='abc243_d':
        def walk(x:int,s:str)->str:return line((len(s),x))+s+'\n'
        raws=[walk(1,'L'),walk(10**18,'U'),walk(2,'URL'),walk(10**18,'R'*100+'U'*100)]
        for n in range(2,14):
            x=rng.randrange(1,1000);current=x;chars=[]
            for _ in range(n*4):
                ch=rng.choice('ULR') if current>1 else rng.choice('LR');chars.append(ch);current=current//2 if ch=='U' else current*2+int(ch=='R')
            if current>10**18:
                while current>10**18:chars.append('U');current//=2
            raws.append(walk(x,''.join(chars)))
        raws+=[walk(1,'L'*500000+'U'*500000),walk(10**18,'RU'*500000)]
    elif pid=='abc244_d':
        pairs=list((s,t) for s in permutations('RGB') for t in permutations('RGB'));selected=pairs[::2][:17]+[pairs[-1]];raws=[' '.join(s)+'\n'+' '.join(t)+'\n' for s,t in selected]
    else:
        def polynomial(a:tuple[int,...],b:tuple[int,...])->str:return line((len(a)-1,len(b)-1))+line(a)+line(convolution(a,b))
        polys=[((0,1),(0,1)),((100,1),(100,-1)),((0,0,-100),(100,0,-100)),((1,-1),(1,1))]
        for n in range(2,14):
            m=1+n%5;a=tuple(rng.randrange(-100,101) for _ in range(n))+(rng.choice([-100,-1,1,100]),);b=tuple(rng.randrange(-100,101) for _ in range(m))+(rng.choice([-100,-1,1,100]),);polys.append((a,b))
        polys+=[((0,)*99+(-100,),(-100,)*100),((100,)*100,(100,)*100)];raws=[polynomial(a,b) for a,b in polys]
    require(len(raws)==len(set(raws))==18,'distinct18')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc240_d':('消えるのは、追加したボールを含む末尾の連続部分です。','同じ数字が連続する個数をスタックで管理します。個数が数字と一致したら、その連続部分を丸ごと取り除きます。','疑似コード: 末尾と同じ値ならcount++、他は(value,1)をpush; total++; count==valueならtotal-=valueしてpop; 各時点のtotalを出力。'),
'abc241_d':('重複を保ったまま、値以下・値未満の個数を調べると順位に変換できます。','追加される値を座標圧縮してFenwick木で個数を管理します。条件内のk番目を全体の順位へ直し、個数の累積和を使って値を探します。','疑似コード: 1 xで座標xを+1; 2 x kではrank=count(<=x)-k+1; 3 x kではrank=count(<x)+k; rankが1..全個数ならFenwickの順位検索、他は-1を出力。'),
'abc242_d':('置換を二分木として見ると、元の文字の位置と左右に進んだ経路で答えが決まります。','k-1の下位tビットの1の個数が右へ進んだ回数です。左は+1、右は+2なので、元の文字にtとその1の個数を足します。tが60以上なら元の文字は先頭です。','疑似コード: index=k-1; t<60ならroot=index>>t,path=index-(root<<t)、他はroot=0,path=index; answer=(S[root]の0始まり番号+t+path.bit_count())%3; answerをA,B,Cへ戻して出力。'),
'abc243_d':('子へ進んだ直後に親へ戻る移動は打ち消せます。','LやRと、その後のUをスタックで相殺します。残った移動だけ整数に適用すると、途中の巨大な頂点番号を作らずに済みます。','疑似コード: c==Uかつ末尾がL/Rならpop、他はpush; 残ったUでX/=2、LでX*=2、RでX=2X+1; Xを出力。'),
'abc244_d':('二人の帽子を交換すると、並びの置換の偶奇が変わります。','操作回数は偶数なので、初期配置から目的配置への置換も偶置換である必要があります。可能な偶置換には同じ交換を二回足して回数を調整できます。','疑似コード: Tの各色がSのどの位置かを列Pにする; i<jかつP[i]>P[j]の個数を数える; 偶数ならYes、奇数ならNo。'),
'abc245_d':('積の最高次数の係数は、二つの最高次数の係数の積です。','Bの高い次数から係数を一つ決め、その係数とAの積をCから引く操作を繰り返します。','疑似コード: j=M..0でB[j]=C[N+j]/A[N]; i=0..NについてC[i+j]-=A[i]*B[j]; B[0..M]を出力。')}

TITLES={'abc240_d': 'Strange Balls', 'abc241_d': 'Sequence Query', 'abc242_d': 'ABC Transform', 'abc243_d': 'Moves on Binary Tree', 'abc244_d': 'Swap Hats', 'abc245_d': 'Polynomial division'}
PUBLISHED_SAMPLES={'abc240_d': [{'input': '5\n3 2 3 2 2\n', 'expected': '1\n2\n3\n4\n3\n'}, {'input': '10\n2 3 2 3 3 3 2 3 3 2\n', 'expected': '1\n2\n3\n4\n5\n3\n2\n3\n1\n0\n'}], 'abc241_d': [{'input': '11\n1 20\n1 10\n1 30\n1 20\n3 15 1\n3 15 2\n3 15 3\n3 15 4\n2 100 5\n1 1\n2 100 5\n', 'expected': '20\n20\n30\n-1\n-1\n1\n'}], 'abc242_d': [{'input': 'ABC\n4\n0 1\n1 1\n1 3\n1 6\n', 'expected': 'A\nB\nC\nB\n'}, {'input': 'CBBAACCCCC\n5\n57530144230160008 659279164847814847\n29622990657296329 861239705300265164\n509705228051901259 994708708957785197\n176678501072691541 655134104344481648\n827291290937314275 407121144297426665\n', 'expected': 'A\nA\nC\nA\nA\n'}], 'abc243_d': [{'input': '3 2\nURL\n', 'expected': '6\n'}, {'input': '4 500000000000000000\nRRUU\n', 'expected': '500000000000000000\n'}, {'input': '30 123456789\nLRULURLURLULULRURRLRULRRRUURRU\n', 'expected': '126419752371\n'}], 'abc244_d': [{'input': 'R G B\nR G B\n', 'expected': 'Yes\n'}], 'abc245_d': [{'input': '1 2\n2 1\n12 14 8 2\n', 'expected': '6 4 2\n'}, {'input': '1 1\n100 1\n10000 0 -1\n', 'expected': '100 -1\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
