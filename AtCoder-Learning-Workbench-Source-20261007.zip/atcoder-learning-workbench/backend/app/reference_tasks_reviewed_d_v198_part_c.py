"""Private ABC365..370 D official authoring; no shared registration."""
from __future__ import annotations
from typing import cast
from collections import deque
from bisect import bisect_left
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(365,371));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc365_d':
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)==2 and re.fullmatch('[RPS]{'+str(n)+'}',r[1]) is not None,'hands');return (r[1],)
 if pid=='abc366_d':
  n=ints(r[0],1)[0];require(1<=n<=100 and len(r)>n*n+1,'shape');a=tuple(ints(s,n) for s in r[1:1+n*n]);require(all(0<=v<=999 for row in a for v in row),'values');q=ints(r[1+n*n],1)[0];require(1<=q<=200000 and len(r)==n*n+q+2,'queries');queries=tuple(ints(s,6) for s in r[2+n*n:]);require(all(all(1<=t[i]<=t[i+1]<=n for i in (0,2,4)) for t in queries),'ranges');return n,a,queries
 if pid=='abc367_d':
  n,m=ints(r[0],2);require(2<=n<=200000 and 1<=m<=1000000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=x<=10**9 for x in a),'distance');return m,a
 if pid=='abc368_d':
  n,k=ints(r[0],2);require(1<=k<=n<=200000 and len(r)==n+1,'shape');edges=tuple(ints(s,2) for s in r[1:n]);chosen=ints(r[n],k);require(all(1<=u<=n and 1<=v<=n for u,v in edges) and all(1<=x<=n for x in chosen) and all(a<b for a,b in zip(chosen,chosen[1:])),'vertices');parent=list(range(n));size=[1]*n
  def root(j:int)->int:
   while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
   return j
  for u,v in edges:
   a,b=root(u-1),root(v-1);require(a!=b,'tree')
   if size[a]<size[b]:a,b=b,a
   parent[b]=a;size[a]+=size[b]
  return n,edges,chosen
 if pid=='abc369_d':
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=x<=10**9 for x in a),'strength');return (a,)
 h,w,q=ints(r[0],3);require(h>=1 and w>=1 and h*w<=400000 and 1<=q<=200000 and len(r)==q+1,'shape');queries=tuple(ints(s,2) for s in r[1:]);require(all(1<=a<=h and 1<=b<=w for a,b in queries),'coordinates');return h,w,queries

Matrix=tuple[tuple[int,...],...]
NEG=-10**30
def max_product(a:Matrix,b:Matrix)->Matrix:
 return tuple(tuple(max(a[i][k]+b[k][j] for k in range(len(a))) for j in range(len(a))) for i in range(len(a)))
def matrix_fold(leaves:list[Matrix])->Matrix:
 while len(leaves)>1:leaves=[max_product(leaves[i],leaves[i+1]) if i+1<len(leaves) else leaves[i] for i in range(0,len(leaves),2)]
 return leaves[0]
def janken_product(s:str)->int:
 # Three hand states; max-plus edge matrices are composed in balanced order.
 win={'R':'P','P':'S','S':'R'};hands='RPS';leaves=[]
 for c in s:
  leaves.append(tuple(tuple((int(hands[j]==win[c]) if j<3 and i!=j and hands[j] in (c,win[c]) else NEG) for j in range(3)) for i in range(3)))
 return max(max(row) for row in matrix_fold(leaves))
def cuboid_sweep(n:int,a:tuple[tuple[int,...],...],queries:tuple[tuple[int,...],...])->list[int]:
 events:list[list[tuple[int,int,tuple[int,...]]]]=[[] for _ in range(n+1)];answer=[0]*len(queries)
 for i,t in enumerate(queries):events[t[0]-1].append((i,-1,t));events[t[1]].append((i,1,t))
 bit=[[0]*(n+1) for _ in range(n+1)]
 def prefix(y:int,z:int)->int:
  total=0
  while y:
   j=z
   while j:total+=bit[y][j];j-=j&-j
   y-=y&-y
  return total
 for x in range(n+1):
  if x:
   slab=[[0]+list(a[(x-1)*n+y]) for y in range(n)];slab.insert(0,[0]*(n+1))
   # Linear two-dimensional Fenwick transform, then cumulative sweep update.
   for y in range(1,n+1):
    for z in range(1,n+1):
     target=z+(z&-z)
     if target<=n:slab[y][target]+=slab[y][z]
   for y in range(1,n+1):
    target=y+(y&-y)
    if target<=n:
     for z in range(1,n+1):slab[target][z]+=slab[y][z]
   for y in range(1,n+1):
    for z in range(1,n+1):bit[y][z]+=slab[y][z]
  for i,sign,t in events[x]:
   _,_,yl,yr,zl,zr=t;answer[i]+=sign*(prefix(yr,zr)-prefix(yl-1,zr)-prefix(yr,zl-1)+prefix(yl-1,zl-1))
 return answer

def circular_residue_positions(m:int,a:tuple[int,...])->int:
 n=len(a);prefix=[0]
 for x in a+a:prefix.append((prefix[-1]+x)%m)
 positions:dict[int,list[int]]={}
 for j,x in enumerate(prefix):positions.setdefault(x,[]).append(j)
 return sum(bisect_left(positions[prefix[i]],i+n)-bisect_left(positions[prefix[i]],i+1) for i in range(n))
def prune_tree(n:int,edges:tuple[tuple[int,...],...],chosen:tuple[int,...])->int:
 adj:list[list[int]]=[[] for _ in range(n)]
 for a,b in edges:adj[a-1].append(b-1);adj[b-1].append(a-1)
 protected=set(x-1 for x in chosen);degree=list(map(len,adj));queue=deque(i for i in range(n) if degree[i]<=1 and i not in protected);removed=0
 while queue:
  u=queue.popleft();removed+=1;degree[u]=0
  for v in adj[u]:
   if degree[v]:degree[v]-=1
   if degree[v]==1 and v not in protected:queue.append(v)
 return n-removed

def experience_product(a:tuple[int,...])->int:
 matrices=[((0,x),(2*x,0)) for x in a];p=matrix_fold(matrices);return max(p[0])

class DeadIntervals:
 def __init__(self,n:int)->None:self.parent=list(range(n));self.size=[1]*n;self.lo=list(range(n));self.hi=list(range(n))
 def root(self,x:int)->int:
  while self.parent[x]!=x:self.parent[x]=self.parent[self.parent[x]];x=self.parent[x]
  return x
 def join(self,a:int,b:int)->None:
  a,b=self.root(a),self.root(b)
  if a==b:return
  if self.size[a]<self.size[b]:a,b=b,a
  self.parent[b]=a;self.size[a]+=self.size[b];self.lo[a]=min(self.lo[a],self.lo[b]);self.hi[a]=max(self.hi[a],self.hi[b])
def explosion_deleted_intervals(h:int,w:int,queries:tuple[tuple[int,...],...])->int:
 n=h*w;dead=bytearray(n);horizontal=DeadIntervals(n);vertical=DeadIntervals(n);remaining=n
 def erase(p:int)->None:
  nonlocal remaining
  if dead[p]:return
  dead[p]=1;remaining-=1;r,c=divmod(p,w)
  if c and dead[p-1]:horizontal.join(p,p-1)
  if c+1<w and dead[p+1]:horizontal.join(p,p+1)
  if r and dead[p-w]:vertical.join(p,p-w)
  if r+1<h and dead[p+w]:vertical.join(p,p+w)
 for r,c in queries:
  p=(r-1)*w+c-1
  if not dead[p]:erase(p);continue
  x,y=horizontal.root(p),vertical.root(p);candidates=[]
  if horizontal.lo[x]%w:candidates.append(horizontal.lo[x]-1)
  if horizontal.hi[x]%w+1<w:candidates.append(horizontal.hi[x]+1)
  if vertical.lo[y]>=w:candidates.append(vertical.lo[y]-w)
  if vertical.hi[y]+w<n:candidates.append(vertical.hi[y]+w)
  for q in candidates:erase(q)
 return remaining

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc365_d':answer=janken_product(cast(str,d[0]))
 elif pid=='abc366_d':return ''.join(str(x)+'\n' for x in cuboid_sweep(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1]),cast(tuple[tuple[int,...],...],d[2])))
 elif pid=='abc367_d':answer=circular_residue_positions(cast(int,d[0]),cast(tuple[int,...],d[1]))
 elif pid=='abc368_d':answer=prune_tree(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1]),cast(tuple[int,...],d[2]))
 elif pid=='abc369_d':answer=experience_product(cast(tuple[int,...],d[0]))
 else:answer=explosion_deleted_intervals(cast(int,d[0]),cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2]))
 return str(answer)+'\n'
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,KeyError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc365_d':'''import sys
n=int(input());s=input().strip();hands='RPS';win={'R':'P','P':'S','S':'R'};d=[0,0,0]
for c in s:
 nd=[-10**9]*3
 for j,h in enumerate(hands):
  if h in (c,win[c]):nd[j]=max(d[k] for k in range(3) if k!=j)+(h==win[c])
 d=nd
print(max(d))
''',
'abc366_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);s=n+1;p=[0]*(s**3)
def ix(x,y,z):return (x*s+y)*s+z
for x in range(1,s):
 for y in range(1,s):
  for z in range(1,s):p[ix(x,y,z)]=next(it)+p[ix(x-1,y,z)]+p[ix(x,y-1,z)]+p[ix(x,y,z-1)]-p[ix(x-1,y-1,z)]-p[ix(x-1,y,z-1)]-p[ix(x,y-1,z-1)]+p[ix(x-1,y-1,z-1)]
q=next(it);out=[]
for _ in range(q):
 a,b,c,d,e,f=[next(it) for _ in range(6)];a-=1;c-=1;e-=1
 out.append(str(p[ix(b,d,f)]-p[ix(a,d,f)]-p[ix(b,c,f)]-p[ix(b,d,e)]+p[ix(a,c,f)]+p[ix(a,d,e)]+p[ix(b,c,e)]-p[ix(a,c,e)]))
print('\\n'.join(out))
''',
'abc367_d':'''import sys
from collections import Counter
n,m=map(int,input().split());a=list(map(int,input().split()));p=[0]
for x in a+a:p.append((p[-1]+x)%m)
c=Counter(p[1:n]);ans=0
for i in range(n):
 ans+=c[p[i]];c[p[i+1]]-=1;c[p[i+n]]+=1
print(ans)
''',
'abc368_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);k=next(it);g=[[] for _ in range(n)]
for _ in range(n-1):u=next(it)-1;v=next(it)-1;g[u].append(v);g[v].append(u)
chosen=[next(it)-1 for _ in range(k)];root=chosen[0];parent=[-1]*n;parent[root]=root;order=[root]
for u in order:
 for v in g[u]:
  if parent[v]<0:parent[v]=u;order.append(v)
marked=[False]*n
for u in chosen:marked[u]=True
for u in reversed(order):
 if marked[u]:marked[parent[u]]=True
print(sum(marked))
''',
'abc369_d':'''import sys
n=int(input());a=list(map(int,input().split()));even=0;odd=-10**30
for x in a:even,odd=max(even,odd+2*x),max(odd,even+x)
print(max(even,odd))
''',
'abc370_d':'''import sys
class Fenwick:
 def __init__(self,n):self.n=n;self.a=[0]+[i&-i for i in range(1,n+1)]
 def add(self,i,v):
  i+=1
  while i<=self.n:self.a[i]+=v;i+=i&-i
 def count(self,i):
  s=0
  while i:s+=self.a[i];i-=i&-i
  return s
 def kth(self,k):
  i=0;b=1<<(self.n.bit_length()-1)
  while b:
   j=i+b
   if j<=self.n and self.a[j]<k:i=j;k-=self.a[j]
   b>>=1
  return i
it=iter(map(int,sys.stdin.buffer.read().split()));h=next(it);w=next(it);q=next(it);rows=[Fenwick(w) for _ in range(h)];cols=[Fenwick(h) for _ in range(w)];alive=bytearray([1])*(h*w);left=h*w
for _ in range(q):
 r=next(it)-1;c=next(it)-1;p=r*w+c;targets=[]
 if alive[p]:targets=[(r,c)]
 else:
  l=rows[r].count(c);t=rows[r].count(w)
  if l:targets.append((r,rows[r].kth(l)))
  if l<t:targets.append((r,rows[r].kth(l+1)))
  u=cols[c].count(r);t=cols[c].count(h)
  if u:targets.append((cols[c].kth(u),c))
  if u<t:targets.append((cols[c].kth(u+1),c))
 for a,b in targets:
  p=a*w+b
  if alive[p]:alive[p]=0;left-=1;rows[a].add(b,-1);cols[b].add(a,-1)
print(left)
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc365_d':
  raws=['1\nR\n','1\nP\n','1\nS\n','2\nRR\n','2\nRP\n','3\nRPS\n','10\n'+'R'*10+'\n','12\n'+'RPS'*4+'\n']
  while len(raws)<16:
   n=10+len(raws);raws.append(str(n)+'\n'+''.join(rng.choice('RPS') for _ in range(n))+'\n')
  raws+=['200000\n'+'RPS'*66666+'RP\n','200000\n'+'S'*200000+'\n']
 elif pid=='abc366_d':
  def cube(n:int,a:list[list[int]],queries:list[tuple[int,...]])->str:return str(n)+'\n'+''.join(line(row) for row in a)+str(len(queries))+'\n'+''.join(line(t) for t in queries)
  raws=[cube(1,[[0]],[(1,1,1,1,1,1)]),cube(1,[[999]],[(1,1,1,1,1,1)]),cube(2,[[0,999],[1,998],[2,997],[3,996]],[(1,2,1,2,1,2),(2,2,1,1,1,2)])]
  while len(raws)<16:
   n=2+len(raws)%5;queries=[]
   for _ in range(8+len(raws)):
    pairs=[sorted([rng.randint(1,n),rng.randint(1,n)]) for _ in range(3)];queries.append(tuple(v for p in pairs for v in p))
   raws.append(cube(n,[[rng.randrange(1000) for _ in range(n)] for _ in range(n*n)],queries))
  raws.append(cube(100,[[int((y+z)%3==0)*999 for z in range(100)] for y in range(10000)],[(1,100,1,100,1,100),(25,75,30,80,10,90),(1,1,1,1,1,1)]))
  raws.append(cube(100,[[999]*100 for _ in range(10000)],[(1,100,1,100,1,100) if i%2==0 else (100,100,100,100,100,100) for i in range(200000)]))
 elif pid=='abc367_d':
  def circle(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
  raws=[circle(1,[1,1]),circle(1000000,[1,1]),circle(3,[2,1,4,3]),circle(2,[1]*9),circle(4,[4]*10),circle(7,[1,2,3,4,5,6,7])]
  while len(raws)<16:raws.append(circle(rng.randint(1,100),[rng.randint(1,10**9) for _ in range(3+len(raws))]))
  raws+=[circle(1,[1]*200000),circle(1000000,[10**9]*200000)]
 elif pid=='abc368_d':
  def tree(n:int,edges:list[tuple[int,int]],chosen:list[int])->str:return f'{n} {len(chosen)}\n'+''.join(line(e) for e in edges)+line(chosen)
  raws=[tree(1,[],[1]),tree(2,[(2,1)],[2]),tree(2,[(1,2)],[1,2]),tree(5,[(1,i) for i in range(2,6)],[2,5]),tree(5,[(i,i+1) for i in range(1,5)],[2,4])]
  while len(raws)<16:
   n=5+len(raws);edges=[(rng.randint(1,j-1),j) for j in range(2,n+1)];chosen=sorted(rng.sample(range(1,n+1),rng.randint(1,n)));raws.append(tree(n,edges,chosen))
  raws+=[tree(200000,[(1,j) for j in range(2,200001)],[199999,200000]),tree(200000,[(j,j+1) for j in range(1,200000)],list(range(1,200001)))]
 elif pid=='abc369_d':
  def exp(a:list[int])->str:return str(len(a))+'\n'+line(a)
  raws=[exp([1]),exp([10**9]),exp([1,10**9]),exp([10**9,1,10**9]),exp([1,5,3,2,7]),exp([1]*11)]
  while len(raws)<16:raws.append(exp([rng.randint(1,10**9) for _ in range(3+len(raws))]))
  raws+=[exp([1,10**9]*100000),exp([10**9]*200000)]
 else:
  def explosion(h:int,w:int,queries:list[tuple[int,int]])->str:return f'{h} {w} {len(queries)}\n'+''.join(line(t) for t in queries)
  raws=[explosion(1,1,[(1,1)]),explosion(1,1,[(1,1)]*2),explosion(1,7,[(1,4)]*5),explosion(7,1,[(4,1)]*5),explosion(3,3,[(2,2)]*6)]
  while len(raws)<16:
   h=2+len(raws)%5;w=2+len(raws)%7;raws.append(explosion(h,w,[(rng.randint(1,h),rng.randint(1,w)) for _ in range(10+len(raws))]))
  raws+=[explosion(1,400000,[(1,200000)]*200000),explosion(500,800,[(250,400)]*200000)]
 require(len(raws)==len(set(raws))==18,'18 distinct');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i==16 else 'random','name':f'{pid}_{i+1:02d}'} for i,raw in enumerate(raws)]
HINTS={
'abc365_d':('直前の手がわかれば、次に出せる手を決められます。','負ける手を除き、直前と異なる手への遷移で勝利数の最大値を更新します。','疑似コード: dp[3]=0。青木の各手cについてnextを負無限大で初期化。負けない手jについてi!=jのdp[i]+勝利点の最大をnext[j]へ。dp=nextとして最後の最大を出力。'),
'abc366_d':('直方体の和を毎回列挙せず、累積和を用意しましょう。','三次元累積和を作り、直方体の8隅の値を包除します。','疑似コード: P[x,y,z]=Aと手前3面の和から重複3辺を引き、重複点を足す。各閉区間を左端-1/右端の8隅に分け、右端を選んだ軸数に応じた符号でPを足して出力。'),
'abc367_d':('一周未満の区間の歩数がMの倍数になる条件を考えます。','列を2回並べ、累積和のMでの余りが同じ端点を数えます。','疑似コード: 二重列の余り累積Pを作る。初期頻度にP[1:N]を登録。開始iごとにfreq[P[i]]を加え、P[i+1]を除きP[i+N]を追加する。N回の合計を出力。'),
'abc368_d':('指定頂点を結ぶ道は、木の中で一意に決まります。','指定頂点の一つを根とし、指定頂点を含む部分木だけを残します。','疑似コード: 指定頂点をrootに親と巡回順を作る。markedに指定頂点を登録。逆順でmarked[u]なら親もmarkedにする。markedの個数を出力。'),
'abc369_d':('次に倒す回数の偶奇によって、得られる経験値が変わります。','倒した回数が偶数・奇数の2状態で、逃げる場合と倒す場合を比較します。','疑似コード: even=0,odd=-INF。強さxごとにnewEven=max(even,odd+2x)、newOdd=max(odd,even+x)を同時更新。最後に両状態の最大を出力。'),
'abc370_d':('各行・列で残っている壁を管理し、近い壁を検索します。','行と列のFenwick木で壁の個数を持ち、累積個数から左右上下の壁を順位検索します。','疑似コード: 全壁をaliveにし行列BITを1で初期化。対象がaliveなら削除。なければ行の前後・列の前後を累積個数とkthで検索し4対象を先に集める。対象をaliveと両BITから削除し、残数を出力。')}

TITLES={'abc365_d': 'AtCoder Janken 3', 'abc366_d': 'Cuboid Sum Query', 'abc367_d': 'Pedometer', 'abc368_d': 'Minimum Steiner Tree', 'abc369_d': 'Bonus EXP', 'abc370_d': 'Cross Explosion'}

PUBLISHED_SAMPLES={'abc365_d': [{'input': '6\nPRSSRS\n', 'expected': '5\n'}, {'input': '10\nSSSSSSSSSS\n', 'expected': '5\n'}, {'input': '24\nSPRPSRRRRRPPRPRPSSRSPRSS\n', 'expected': '18\n'}], 'abc366_d': [{'input': '2\n1 2\n3 4\n5 6\n7 8\n2\n1 2 2 2 1 1\n2 2 1 2 1 2\n', 'expected': '10\n26\n'}, {'input': '3\n733 857 714\n956 208 257\n123 719 648\n840 881 245\n245 112 746\n306 942 694\n58 870 849\n13 208 789\n687 906 783\n8\n3 3 3 3 1 1\n1 3 2 3 3 3\n2 2 2 3 1 1\n1 3 1 1 1 1\n2 3 2 3 2 3\n1 2 1 1 1 2\n3 3 2 2 1 3\n1 2 2 3 2 3\n', 'expected': '687\n3917\n551\n1631\n5180\n3311\n1010\n4326\n'}], 'abc367_d': [{'input': '4 3\n2 1 4 3\n', 'expected': '4\n'}, {'input': '2 1000000\n1 1\n', 'expected': '0\n'}, {'input': '9 5\n9 9 8 2 4 4 3 5 3\n', 'expected': '11\n'}], 'abc368_d': [{'input': '7 3\n1 2\n1 3\n2 4\n2 5\n3 6\n3 7\n1 3 5\n', 'expected': '4\n'}, {'input': '4 4\n3 1\n1 4\n2 1\n1 2 3 4\n', 'expected': '4\n'}, {'input': '5 1\n1 4\n2 3\n5 2\n1 2\n1\n', 'expected': '1\n'}], 'abc369_d': [{'input': '5\n1 5 3 2 7\n', 'expected': '28\n'}, {'input': '2\n1000000000 1000000000\n', 'expected': '3000000000\n'}], 'abc370_d': [{'input': '2 4 3\n1 2\n1 2\n1 3\n', 'expected': '2\n'}, {'input': '5 5 5\n3 3\n3 3\n3 2\n2 2\n1 2\n', 'expected': '10\n'}, {'input': '4 3 10\n2 2\n4 1\n1 1\n4 2\n2 1\n3 1\n1 3\n1 2\n4 3\n4 2\n', 'expected': '2\n'}]}

SAMPLE_COUNTS={'abc365_d': 3, 'abc366_d': 2, 'abc367_d': 3, 'abc368_d': 3, 'abc369_d': 2, 'abc370_d': 3}
