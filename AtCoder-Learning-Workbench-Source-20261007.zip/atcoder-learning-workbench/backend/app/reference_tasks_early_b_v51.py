"""Three manually reviewed B tasks; input-bound validation and a second oracle.

ABC011 B: ascii capitalization, ABC013 B: circular distance, ABC014 B: subset prices.
The HTML source itself is not authenticated; the examples are manual transcriptions.
"""
from __future__ import annotations
import random
import re
from collections import deque

TASKS = ('abc011_2','abc013_2','abc014_2')
NAT = re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
LETTERS = re.compile(r'[a-zA-Z]{1,12}',re.ASCII)


def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('problem or input framing invalid')
    lines=raw[:-1].split('\n')
    if pid=='abc011_2':
        if len(lines)!=1 or not LETTERS.fullmatch(lines[0]):raise ValueError('name out of range')
        return lines[0]
    if pid=='abc013_2':
        if len(lines)!=2 or any(not NAT.fullmatch(line) for line in lines):raise ValueError('dial shape')
        a,b=map(int,lines)
        if not (0<=a<=9 and 0<=b<=9 and a!=b):raise ValueError('dial domain')
        return a,b
    if len(lines)!=2:raise ValueError('price lines')
    head=lines[0].split(' ');values=lines[1].split(' ')
    if len(head)!=2 or any(not NAT.fullmatch(x) for x in head+values):raise ValueError('price syntax')
    n,mask=map(int,head);prices=list(map(int,values))
    if not (1<=n<=20 and 0<=mask<(1<<n) and len(prices)==n and all(0<=v<=1000 for v in prices)):
        raise ValueError('price domain')
    return n,mask,prices


def independent_check(pid:str,raw:str,output:str)->bool:
    try: parsed=validate(pid,raw)
    except ValueError:return False
    if not isinstance(output,str):return False
    if pid=='abc011_2':
        # Explicit ASCII conversion independent of str.capitalize() in the reference.
        s=parsed
        expected=''.join(chr(ord(c)-32) if i==0 and 'a'<=c<='z' else
                         chr(ord(c)+32) if i>0 and 'A'<=c<='Z' else c
                         for i,c in enumerate(s))
        return output==expected
    if pid=='abc013_2':
        a,b=parsed;distance=[-1]*10;distance[a]=0;queue=deque([a])
        while queue:
            cur=queue.popleft()
            for nxt in ((cur+1)%10,(cur-1)%10):
                if distance[nxt]<0:
                    distance[nxt]=distance[cur]+1;queue.append(nxt)
        return output==str(distance[b])
    n,mask,prices=parsed
    # Reconstruct membership by base-2 digits; separate from reference bit-shift loop.
    digits=bin(mask)[2:][::-1].ljust(n,'0')
    return output==str(sum(price for bit,price in zip(digits,prices) if bit=='1'))


def generate(pid:str,seed:int=51)->list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unknown problem')
    rng=random.Random(f'abc-v51:{pid}:{seed}')
    cases:list[dict[str,str]]=[];seen=set()
    def add(category:str,raw:str):
        validate(pid,raw)
        if raw not in seen:seen.add(raw);cases.append({'category':category,'input':raw})
    if pid=='abc011_2':
        presets=['a','A','z','Z','aA','Aa','aZ','Zz','abcdef','ABCDEF',
                 'aBcDeF','AaAaAa','zZzZzZ','abcdefghijkl','ABCDEFGHIJKL']
        for name in presets:add('boundary' if len(name) in (1,12) else 'normal',name+'\n')
        while len(cases)<17:
            n=rng.randint(1,12); s=''.join(rng.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(n))
            add('normal',s+'\n')
        add('constraint_max','zZ'*6+'\n')
    elif pid=='abc013_2':
        presets=[(0,1),(1,0),(0,9),(9,0),(0,5),(5,0),(1,6),(2,7),(3,8),
                 (4,9),(9,5),(5,9),(7,8),(8,7),(6,4),(4,6),(0,8)]
        for a,b in presets:add('boundary' if a in (0,9) or b in (0,9) else 'normal',f'{a}\n{b}\n')
        add('constraint_max','9\n1\n')
    else:
        presets=[(1,0,[0]),(1,1,[1000]),(2,1,[1,1000]),(2,2,[0,1000]),
                (4,5,[1,10,100,1000]),(4,0,[1000]*4),
                (20,(1<<20)-1,list(range(1,21))),
                (20,0,[1000]*20),(20,1,[1000]*20),
                (20,1<<19,[1000]*20),(20,0x55555,[1000]*20),
                (20,0xAAAAA,[1000]*20),(20,(1<<20)-2,[1]*20)]
        def raw(n,mask,prices):return f'{n} {mask}\n'+' '.join(map(str,prices))+'\n'
        for n,mask,prices in presets:add('boundary' if n in (1,20) else 'normal',raw(n,mask,prices))
        while len(cases)<17:
            n=rng.randint(1,20);mask=rng.randrange(1<<n);prices=[rng.randint(0,1000) for _ in range(n)]
            add('normal',raw(n,mask,prices))
        add('constraint_max',raw(20,(1<<20)-1,[1000]*20))
    if len(cases)!=18 or len(seen)!=18 or cases[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct inputs and max candidate, got {len(cases)}')
    return cases
