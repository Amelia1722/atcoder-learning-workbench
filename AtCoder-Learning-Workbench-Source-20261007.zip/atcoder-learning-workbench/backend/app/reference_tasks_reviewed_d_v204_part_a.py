"""Private exact domains and independent computations for ABC461..466 D."""
from __future__ import annotations
from bisect import bisect_left
from functools import lru_cache
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(461,467));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integer fields');a=tuple(map(int,row.split()));require(n is None or len(a)==n,'field count');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc461_d':
  h,w,k=ints(r[0],3);require(1<=h<=500 and 1<=w<=500 and 0<=k<=h*w and len(r)==h+1,'H/W/K');grid=tuple(r[1:]);require(all(len(row)==w and re.fullmatch('[01]+',row) is not None for row in grid),'grid');return h,w,k,grid
 if pid in ('abc462_d','abc463_d','abc466_d'):
  n,parameter=ints(r[0],2);limit=300000 if pid=='abc466_d' else 200000;require((1 if pid=='abc466_d' else 2)<=n<=limit,'N');require(1<=parameter<=(300000 if pid=='abc466_d' else 1000000 if pid=='abc462_d' else n),'parameter');require(len(r)==(parameter+1 if pid=='abc466_d' else n+1),'rows');pairs=tuple(ints(row,2) for row in r[1:])
  if pid=='abc462_d':require(all(1<=a<=b<=1000000 for a,b in pairs),'S/T')
  elif pid=='abc463_d':require(all(0<=a<b<=10**9 for a,b in pairs) and parameter>=2,'L/R/K')
  else:require(all(1<=a<=n and 1<=b<=n for a,b in pairs),'R/C')
  return n,parameter,pairs
 t=ints(r[0],1)[0]
 if pid=='abc465_d':
  require(1<=t<=200000 and len(r)==t+1,'T/rows');triples=tuple(ints(row,3) for row in r[1:]);require(all(0<=x<=10**18 and 0<=y<=10**18 and 2<=k<=10**18 for x,y,k in triples),'X/Y/K');return (triples,)
 require(1<=t<=10000 and len(r)==4*t+1,'T/rows');cases=[];total=0
 for i in range(t):
  n=ints(r[1+4*i],1)[0];s=r[2+4*i];x=ints(r[3+4*i],n);y=ints(r[4+4*i],n-1);require(2<=n<=200000 and len(s)==n and re.fullmatch('[SR]+',s) is not None and all(1<=v<=10**9 for v in x+y),'case domain');total+=n;cases.append((s,x,y))
 require(total<=200000,'sumN');return (tuple(cases),)

@lru_cache(maxsize=24)
def subgrid_two_nonnegative_windows(k:int,grid:tuple[str,...])->int:
 h=len(grid);w=len(grid[0]);rows=[tuple(ord(ch)-48 for ch in row) for row in grid]
 if h>w:rows=list(zip(*rows));h,w=w,h
 if k>sum(map(sum,rows)):return 0
 answer=0
 for top in range(h):
  columns=[0]*w
  for bottom in range(top,h):
   columns=[a+b for a,b in zip(columns,rows[bottom])]
   if k==0:
    run=0
    for value in columns:
     run=run+1 if value==0 else 0;answer+=run
   else:
    left1=left2=total1=total2=0;bound=k-1
    for value in columns:
     total1+=value;total2+=value
     while total1>k:total1-=columns[left1];left1+=1
     while total2>bound:total2-=columns[left2];left2+=1
     answer+=left2-left1
 return answer

def accomplice_sparse_event_segments(d:int,pairs:tuple[tuple[int,...],...])->int:
 events:dict[int,int]={}
 for start,end in pairs:
  end-=d
  if start<=end:events[start]=events.get(start,0)+1;events[end+1]=events.get(end+1,0)-1
 answer=count=0;previous=0
 for at,delta in sorted(events.items()):answer+=(at-previous)*count*(count-1)//2;count+=delta;previous=at
 return answer

@lru_cache(maxsize=24)
def cloth_successor_dag(k:int,pairs:tuple[tuple[int,...],...])->int:
 rows=sorted(pairs);starts=[a for a,b in rows];n=len(rows)
 def feasible(gap:int)->bool:
  best=[0]*(n+1)
  for i in range(n-1,-1,-1):
   next_index=bisect_left(starts,rows[i][1]+gap);take=1+best[next_index];skip=best[i+1];best[i]=take if take>skip else skip
  return best[0]>=k
 if not feasible(1):return -1
 low=1;high=10**9+1
 while high-low>1:
  middle=(low+high)//2
  if feasible(middle):low=middle
  else:high=middle
 return low

def weather_weighted_disjoint_pairs(s:str,x:tuple[int,...],y:tuple[int,...])->int:
 previous=before=0
 for i,reward in enumerate(y):
  weight=reward-(x[i] if s[i]!='R' else 0)-(x[i+1] if s[i+1]!='S' else 0);current=max(previous,before+weight);before,previous=previous,current
 return previous

def quotient_tree_digit_prefix(x:int,y:int,k:int)->int:
 def digits(value:int)->list[int]:
  out=[]
  while value:value,remainder=divmod(value,k);out.append(remainder)
  return out[::-1]
 a=digits(x);b=digits(y);common=0
 for u,v in zip(a,b):
  if u!=v:break
  common+=1
 return len(a)+len(b)-2*common

def rooks_final_timestamps(n:int,pairs:tuple[tuple[int,...],...])->int:
 row=[-1]*n;column=[-1]*n
 for t,(r,c) in enumerate(pairs):row[r-1]=t;column[c-1]=t
 return sum(row[r-1]==t and column[c-1]==t for t,(r,c) in enumerate(pairs))

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc461_d':return str(subgrid_two_nonnegative_windows(cast(int,d[2]),cast(tuple[str,...],d[3])))+'\n'
 if pid=='abc462_d':return str(accomplice_sparse_event_segments(cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2])))+'\n'
 if pid=='abc463_d':return str(cloth_successor_dag(cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2])))+'\n'
 if pid=='abc464_d':return ''.join(str(weather_weighted_disjoint_pairs(s,x,y))+'\n' for s,x,y in cast(tuple[tuple[str,tuple[int,...],tuple[int,...]],...],d[0]))
 if pid=='abc465_d':return ''.join(str(quotient_tree_digit_prefix(x,y,k))+'\n' for x,y,k in cast(tuple[tuple[int,...],...],d[0]))
 return str(rooks_final_timestamps(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[2])))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc461_d':'''def solve():
 h,w,k=map(int,input().split());rows=[[int(c) for c in input()] for _ in range(h)]
 if h>w:rows=list(zip(*rows));h,w=w,h
 answer=0
 for top in range(h):
  columns=[0]*w
  for bottom in range(top,h):
   columns=[a+b for a,b in zip(columns,rows[bottom])];counts={0:1};prefix=0
   for value in columns:
    prefix+=value;answer+=counts.get(prefix-k,0);counts[prefix]=counts.get(prefix,0)+1
 print(answer)
solve()
''',
'abc462_d':'''import sys
def solve():
 r=sys.stdin.buffer;n,d=map(int,r.readline().split());difference=[0]*1000002
 for _ in range(n):
  start,end=map(int,r.readline().split());end-=d
  if start<=end:difference[start]+=1;difference[end+1]-=1
 count=answer=0
 for delta in difference:count+=delta;answer+=count*(count-1)//2
 print(answer)
solve()
''',
'abc463_d':'''import sys
def solve():
 r=sys.stdin.buffer;n,k=map(int,r.readline().split());rows=sorted((tuple(map(int,r.readline().split())) for _ in range(n)),key=lambda p:p[1])
 def feasible(gap):
  count=0;end=-10**18
  for left,right in rows:
   if left-end>=gap:
    count+=1;end=right
    if count>=k:return True
  return False
 if not feasible(1):print(-1);return
 low=1;high=1000000001
 while high-low>1:
  middle=(low+high)//2
  if feasible(middle):low=middle
  else:high=middle
 print(low)
solve()
''',
'abc464_d':'''import sys
def solve():
 r=sys.stdin.buffer;t=int(r.readline());out=[]
 for _ in range(t):
  n=int(r.readline());s=r.readline().decode().strip();x=list(map(int,r.readline().split()));y=list(map(int,r.readline().split()));rain=0 if s[0]=='R' else -x[0];sun=0 if s[0]=='S' else -x[0]
  for i in range(1,n):rain,sun=max(rain,sun)-(x[i] if s[i]!='R' else 0),max(sun,rain+y[i-1])-(x[i] if s[i]!='S' else 0)
  out.append(str(max(rain,sun)))
 print('\\n'.join(out))
solve()
''',
'abc465_d':'''import sys
def solve():
 r=sys.stdin.buffer;t=int(r.readline());out=[]
 for _ in range(t):
  x,y,k=map(int,r.readline().split());answer=0
  while x!=y:
   if x>y:x//=k
   else:y//=k
   answer+=1
  out.append(str(answer))
 print('\\n'.join(out))
solve()
''',
'abc466_d':'''import sys
def solve():
 r=sys.stdin.buffer;n,m=map(int,r.readline().split());rows=[-1]*n;columns=[-1]*n;answer=0
 for _ in range(m):
  a,b=map(int,r.readline().split());a-=1;b-=1
  old=rows[a]
  if old>=0:rows[a]=-1;columns[old]=-1;answer-=1
  old=columns[b]
  if old>=0:columns[b]=-1;rows[old]=-1;answer-=1
  rows[a]=b;columns[b]=a;answer+=1
 print(answer)
solve()
'''}
HINTS:dict[str,tuple[str,str,str]]={
'abc461_d':('上下の行を固定すると、各列の合計からなる1次元配列になります。','その配列で和がKになる連続区間を累積和の出現回数で数えます。行が多い場合は転置して小さい側を二乗します。','疑似コード: H>Wなら転置。各topでcolumns=0。bottomを伸ばして行を加算し、freq={0:1},prefix=0。各列でprefix+=値、answer+=freq[prefix-K]、freq[prefix]++。'),
'abc462_d':('各人について犯行を開始できる整数時刻は[Si,Ti-D]です。空の区間なら参加できません。','同じ時刻に開始できる人数がcなら、犯人の組はc(c-1)/2通りです。区間を差分配列に加えて累積します。','疑似コード: Ti-D>=Siならdiff[Si]++、diff[Ti-D+1]--。各整数時刻でc+=diff、answer+=c(c-1)/2。'),
'abc463_d':('距離の下限を固定すると、その条件でK枚を選べるか判定できます。接触は重なりなので下限は1以上です。','右端が早い布から、前の右端と指定距離以上離れたものを選ぶと、以後に使える場所を最も広く残せます。','疑似コード: 右端順にsort。feasible(g)は直前endからL-end>=gの布を順に採用しK枚になればtrue。feasible(1)がfalseなら-1。他はgを二分探索して最大値を出力。'),
'abc464_d':('各日まで決めたとき、最終日が雨か晴れかの2状態を持ちます。','変更費用を引き、前日が雨で今日は晴れなら境界の報酬を加えます。元の天気も選べるので変更しない場合を含みます。','疑似コード: rain,sunを1日目の変更費用で初期化。各iでnewRain=max(rain,sun)-雨への費用、newSun=max(sun,rain+Yi-1)-晴れへの費用。最後にmax(rain,sun)。'),
'abc465_d':('整数を頂点とし、xからfloor(x/K)へ親辺を張る木を考えます。0の自己辺は無視します。','最短経路は共通祖先を通ります。大きい方を親へ移す操作を続けると、その共通祖先に到達します。','疑似コード: answer=0。X!=Yの間、大きい方をKで整数除算しanswer++。一致したらanswerを出力。'),
'abc466_d':('各行・各列には高々1個のコマが置かれます。対応する列と行を配列に記録しましょう。','指定行のコマを消して対応する列も空にし、指定列のコマも同様に消します。その後に新しいコマを置きます。','疑似コード: row/colを空で初期化。各(R,C)でrow[R]のコマを削除し両配列と個数更新、次にcol[C]も削除。row[R]=C,col[C]=Rとして個数++。')}
REFERENCE_SNIPPETS=REFERENCE_CODE

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc461_d':
  def pack(grid:list[str],k:int)->str:return line([len(grid),len(grid[0]),k])+''.join(row+'\n' for row in grid)
  raws=[pack(['0'],0),pack(['1'],0),pack(['1'],1),pack(['00'],0),pack(['11'],2),pack(['01','10'],1),pack(['00','00'],0),pack(['11','11'],3)]
  for n in range(2,9):raws.append(pack([''.join(rng.choice('01') for _ in range(n+1)) for _ in range(n)],rng.randrange(n*(n+1)+1)))
  raws +=[pack([''.join(rng.choice('01') for _ in range(500)) for _ in range(500)],100),pack(['0'*500]*500,0),pack(['1'*500]*500,250000)]
 elif pid=='abc462_d':
  def pack(d:int,rows:list[tuple[int,int]])->str:return line([len(rows),d])+''.join(line(pair) for pair in rows)
  raws=[pack(1,[(1,1)]*2),pack(1,[(1,2)]*2),pack(1,[(1,2),(2,3)]),pack(2,[(1,3),(1,3)]),pack(1000000,[(1,1000000)]*2),pack(1,[(1,1000000),(1000000,1000000)]),pack(3,[(2,8),(4,10),(6,12)]),pack(1,[(1,5),(2,4),(3,3),(1,5)])]
  for n in range(9,16):raws.append(pack(rng.randrange(1,20),[tuple(sorted((rng.randrange(1,50),rng.randrange(1,50)))) for _ in range(n)]))
  raws +=[pack(1,[(1,1000000)]*200000),pack(5000,[tuple(sorted((rng.randrange(1,1000001),rng.randrange(1,1000001)))) for _ in range(200000)]),pack(1000000,[(1,1000000)]*200000)]
 elif pid=='abc463_d':
  def pack(k:int,rows:list[tuple[int,int]])->str:return line([len(rows),k])+''.join(line(pair) for pair in rows)
  raws=[pack(2,[(0,1),(0,1)]),pack(2,[(0,1),(1,2)]),pack(2,[(0,1),(2,3)]),pack(2,[(0,1),(999999999,1000000000)]),pack(3,[(0,2),(3,4),(5,6)]),pack(2,[(0,10),(1,2),(3,4)]),pack(3,[(0,100),(1,2),(3,4),(5,6)]),pack(2,[(0,5),(5,6),(6,9)])]
  for n in range(9,16):raws.append(pack(rng.randrange(2,n+1),[(a:=rng.randrange(100),a+rng.randrange(1,25)) for _ in range(n)]))
  raws +=[pack(2,[(0,1000000000)]*200000),pack(100000,[(a:=rng.randrange(999999900),a+rng.randrange(1,100)) for _ in range(200000)]),pack(200000,[(i*5000,1000000000 if i==199999 else i*5000+1) for i in range(200000)])]
 elif pid=='abc464_d':
  def pack(cases:list[tuple[str,list[int],list[int]]])->str:return str(len(cases))+'\n'+''.join(str(len(s))+'\n'+s+'\n'+line(x)+line(y) for s,x,y in cases)
  raws=[pack([(s,[1,1],[1])]) for s in ('SS','SR','RS','RR')]
  raws +=[pack([('SR',[1,1],[10])]),pack([('RSRS',[100]*4,[1]*3)]),pack([('RRSS',[1]*4,[10]*3)]),pack([('SSSSS',[1]*5,[10]*4)])]
  for n in range(9,16):raws.append(pack([(''.join(rng.choice('SR') for _ in range(n)),[rng.randrange(1,100) for _ in range(n)],[rng.randrange(1,100) for _ in range(n-1)])]))
  raws +=[pack([('RS'*10,[1000000000]*20,[1000000000]*19)]*10000),pack([('R'*200000,[1]*200000,[1000000000]*199999)]),pack([('S'*200000,[1000000000]*200000,[1000000000]*199999)])]
 elif pid=='abc465_d':
  def pack(rows:list[tuple[int,int,int]])->str:return str(len(rows))+'\n'+''.join(line(row) for row in rows)
  raws=[pack([row]) for row in ((0,0,2),(1,0,2),(0,1,2),(1,1,2),(11,9,3),(1000000000000000000,0,2),(0,1000000000000000000,1000000000000000000),(999999999999999999,1000000000000000000,2))]
  for n in range(9,16):raws.append(pack([(rng.randrange(10**18+1),rng.randrange(10**18+1),rng.randrange(2,10**18+1)) for _ in range(n)]))
  raws +=[pack([(10**18,0,2)]*200000),pack([(10**18,10**18-1,2)]*200000),pack([(10**18,0,10**18)]*200000)]
 else:
  def pack(n:int,rows:list[tuple[int,int]])->str:return line([n,len(rows)])+''.join(line(pair) for pair in rows)
  raws=[pack(1,[(1,1)]),pack(1,[(1,1)]*2),pack(2,[(1,1),(2,2)]),pack(2,[(1,2),(2,1),(1,1)]),pack(2,[(1,1),(1,2)]),pack(2,[(1,1),(2,1)]),pack(3,[(1,1),(2,2),(1,2)]),pack(300000,[(300000,300000)])]
  for n in range(9,16):raws.append(pack(n,[(rng.randrange(1,n+1),rng.randrange(1,n+1)) for _ in range(n*2)]))
  raws +=[pack(300000,[(i,i) for i in range(1,300001)]),pack(300000,[(rng.randrange(1,300001),rng.randrange(1,300001)) for _ in range(300000)]),pack(300000,[(300000,300000)]*300000)]
 require(len(raws)==len(set(raws))==18,'18distinct');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i>=15 else 'random'} for i,raw in enumerate(raws)]

TITLES={'abc461_d': 'Count Subgrid Sum = K', 'abc462_d': 'Accomplice', 'abc463_d': 'Maximize the Gap', 'abc464_d': 'Celester', 'abc465_d': 'X to Y', 'abc466_d': 'Placing Rooks'}
PUBLISHED_SAMPLES={'abc461_d': [{'input': '3 4 3\n1001\n1101\n0110\n', 'expected': '8\n'}, {'input': '5 4 20\n0101\n1010\n0101\n1010\n0101\n', 'expected': '0\n'}, {'input': '15 20 17\n10111101101100000100\n01100000000010000011\n01110010111000111000\n11001100000111011000\n10100001100011100010\n01101000101010000101\n10110001111110000100\n10110011101100101101\n01010001110011001001\n01010110010001100110\n01110100011110011110\n01100000100111010010\n11001101100111101100\n10111100010101111011\n00101101011100010000\n', 'expected': '448\n'}], 'abc462_d': [{'input': '3 2\n9 17\n10 12\n13 20\n', 'expected': '4\n'}, {'input': '3 5\n9 17\n10 12\n13 20\n', 'expected': '0\n'}, {'input': '4 1\n1 1000000\n1 1000000\n1 1000000\n1 1000000\n', 'expected': '5999994\n'}], 'abc463_d': [{'input': '6 3\n1 12\n2 7\n5 9\n9 13\n10 18\n15 20\n', 'expected': '2\n'}, {'input': '2 2\n1 5\n5 9\n', 'expected': '-1\n'}, {'input': '20 5\n169 748\n329 586\n529 972\n432 520\n408 587\n138 250\n114 656\n299 632\n755 984\n404 772\n155 506\n832 854\n353 465\n374 387\n384 567\n555 631\n428 951\n104 705\n405 530\n102 258\n', 'expected': '35\n'}], 'abc464_d': [{'input': '5\n6\nSRRRSR\n3 1 4 1 5 9\n2 6 5 3 5\n6\nRSRSRS\n10 10 10 10 10 10\n1 1 1 1 1\n2\nRR\n4 3\n2\n10\nRSSRSSRSSR\n75 49 79 37 16 9 38 49 69 54\n23 100 73 63 66 23 51 65 67\n20\nSSSRSSSRRRRSSRSSRSSR\n343191362 223147518 135066250 426658267 693515093 8023388 383375974 712283203 40447501 19870690 318452142 356265717 283999278 209219229 418603824 39363351 392058270 254796273 110117486 64951139\n576697130 385986330 895027325 654885799 784214084 577658764 761714876 583039741 943991250 446493376 701505924 402891440 963636095 919408713 238125227 871191978 843843821 397910552 529447424\n', 'expected': '5\n3\n0\n165\n5201284760\n'}], 'abc465_d': [{'input': '4\n11 9 3\n0 0 2\n842 180 7\n1948706013487601 48019760148910476 89014537\n', 'expected': '2\n0\n7\n5\n'}], 'abc466_d': [{'input': '3 6\n1 1\n1 2\n3 3\n3 2\n1 3\n1 3\n', 'expected': '2\n'}, {'input': '2 3\n1 2\n2 1\n1 1\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
