"""Six reviewed C tasks with residue counts, convex search and reverse rotation queries."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(254,260))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==254:
        n,k=ints(rows[0],2);require(2<=n<=200000 and 1<=k<n and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'values');return k,a
    if number==255:
        require(len(rows)==1,'shape');x,a,d,n=ints(rows[0],4);require(-10**18<=x<=10**18 and -10**18<=a<=10**18 and -10**6<=d<=10**6 and 1<=n<=10**12,'progression');return x,a,d,n
    if number==256:
        require(len(rows)==1,'shape');sums=ints(rows[0],6);require(all(3<=v<=30 for v in sums),'sums');return sums
    if number==257:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==3,'shape');s=rows[1];weights=ints(rows[2],n);require(len(s)==n and set(s)<={'0','1'} and all(1<=v<=10**9 for v in weights),'people');return s,weights
    if number==258:
        n,q=ints(rows[0],2);require(2<=n<=500000 and 1<=q<=500000 and len(rows)==q+2,'shape');s=rows[1];queries=tuple(cast(Pair,ints(row,2)) for row in rows[2:]);require(len(s)==n and re.fullmatch('[a-z]+',s) is not None and all(t in (1,2) and 1<=x<=n for t,x in queries) and any(t==2 for t,x in queries),'queries');return s,queries
    require(len(rows)==2 and all(re.fullmatch('[a-z]{2,200000}',row) is not None for row in rows),'words');return rows[0],rows[1]

def _compositions(total:int)->list[tuple[int,int,int]]:return [(a,b,total-a-b) for a in range(1,total-1) for b in range(1,total-a)]
def _can_expand(s:str,t:str)->bool:
    i=j=0
    while j<len(t):
        if i<len(s) and s[i]==t[j]:i+=1;j+=1
        elif i>=2 and s[i-1]==s[i-2]==t[j]:j+=1
        else:return False
    return i==len(s)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==254:
        k,a=cast(tuple[int,tuple[int,...]],data);target=sorted(a);before=Counter((value,j%k) for j,value in enumerate(a));after=Counter((value,j%k) for j,value in enumerate(target));return 'Yes' if before==after else 'No'
    if number==255:
        x,a,d,n=cast(tuple[int,int,int,int],data);lo=0;hi=n-1
        while lo<hi:
            mid=(lo+hi)//2
            if abs(a+mid*d-x)<=abs(a+(mid+1)*d-x):hi=mid
            else:lo=mid+1
        return str(abs(a+lo*d-x))
    if number==256:
        h1,h2,h3,w1,w2,w3=cast(tuple[int,int,int,int,int,int],data)
        if h1+h2+h3!=w1+w2+w3:return '0'
        answer=0
        for row1 in _compositions(h1):
            for row2 in _compositions(h2):
                remaining=(w1-row1[0]-row2[0],w2-row1[1]-row2[1],w3-row1[2]-row2[2]);answer+=all(v>0 for v in remaining) and sum(remaining)==h3
        return str(answer)
    if number==257:
        s,weights=cast(tuple[str,tuple[int,...]],data);children=sorted(w for ch,w in zip(s,weights) if ch=='0');adults=sorted(w for ch,w in zip(s,weights) if ch=='1');return str(max(bisect_left(children,x)+len(adults)-bisect_left(adults,x) for x in {1}|{w+1 for w in weights}))
    if number==258:
        s,queries=cast(tuple[str,tuple[Pair,...]],data);total=sum(x for t,x in queries if t==1)%len(s);final=s[-total:]+s[:-total] if total else s;future=0;answer=[]
        for t,x in reversed(queries):
            if t==1:future=(future+x)%len(s)
            else:answer.append(final[(x-1+future)%len(s)])
        return '\n'.join(reversed(answer))
    s,t=cast(tuple[str,str],data);return 'Yes' if _can_expand(s,t) else 'No'

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc254_c':"n,k=map(int,input().split());a=list(map(int,input().split()))\nfor r in range(k):a[r::k]=sorted(a[r::k])\nprint('Yes' if a==sorted(a) else 'No')\n",
'abc255_c':"x,a,d,n=map(int,input().split())\nif d<0:a=a+d*(n-1);d=-d\nif d==0:answer=abs(x-a)\nelse:\n j=max(0,min(n-1,(x-a)//d));answer=min(abs(x-(a+j*d)),abs(x-(a+min(n-1,j+1)*d)))\nprint(answer)\n",
'abc256_c':"h1,h2,h3,w1,w2,w3=map(int,input().split());answer=0\nfor a in range(1,h1):\n for b in range(1,h1-a):\n  c=h1-a-b\n  for d in range(1,h2):\n   g=w1-a-d\n   if g<=0:continue\n   for e in range(1,h2-d):\n    f=h2-d-e;h=w2-b-e;i=w3-c-f\n    if h>0 and i>0 and g+h+i==h3:answer+=1\nprint(answer)\n",
'abc257_c':"n=int(input());s=input();w=list(map(int,input().split()));pairs=sorted(zip(w,s));correct=s.count('1');answer=correct;j=0\nwhile j<n:\n end=j\n while end<n and pairs[end][0]==pairs[j][0]:correct+=1 if pairs[end][1]=='0' else -1;end+=1\n answer=max(answer,correct);j=end\nprint(answer)\n",
'abc258_c':"n,q=map(int,input().split());s=input();offset=0\nfor _ in range(q):\n t,x=map(int,input().split())\n if t==1:offset=(offset-x)%n\n else:print(s[(offset+x-1)%n])\n",
'abc259_c':"from itertools import groupby\ns=input();t=input();a=[(ch,len(list(g))) for ch,g in groupby(s)];b=[(ch,len(list(g))) for ch,g in groupby(t)];valid=len(a)==len(b) and all(x==y and (u==v or u>=2 and u<=v) for (x,u),(y,v) in zip(a,b));print('Yes' if valid else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16600+number)
    if number==254:
        def swaps(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[swaps(1,[1,1]),swaps(1,[2,1]),swaps(2,[3,2,1]),swaps(2,[2,3,1])]
        for n in range(4,16):raws.append(swaps(rng.randint(1,n-1),[rng.randint(1,100) for _ in range(n)]))
        raws.extend([swaps(1,list(range(200000,0,-1))),swaps(199999,[10**9]*200000)])
    elif number==255:raws=[line(v) for v in ((-10**18,-10**18,-10**6,1),(0,0,0,1),(6,2,3,3),(7,2,3,3),(0,5,2,5),(100,5,2,5),(5,10,-2,5),(100,10,-2,5),(0,10,-2,5),(3,3,0,10**12),(10**18,-10**18,0,10**12),(-10**18,10**18,0,10**12),(999,1,7,1000),(-999,-1,-7,1000),(10**18,-10**18,10**6,10**12),(-10**18,10**18,-10**6,10**12),(-10**18,-10**18,-10**6,10**12),(10**18,10**18,10**6,10**12))]
    elif number==256:
        raws=[line([3]*6),line([3,3,3,3,3,4]),line([4]*6),line([5]*6)]
        for _ in range(12):board=[[rng.randint(1,5) for _ in range(3)] for _ in range(3)];raws.append(line([sum(row) for row in board]+[sum(board[r][c] for r in range(3)) for c in range(3)]))
        raws.extend([line([30,29,28,29,29,29]),line([30]*6)])
    elif number==257:
        def weights(s:str,a:list[int])->str:return f'{len(a)}\n{s}\n'+line(a)
        raws=[weights('0',[1]),weights('1',[1]),weights('01',[1,1]),weights('10',[1,2])]
        for n in range(3,15):raws.append(weights(''.join(rng.choice('01') for _ in range(n)),[rng.randint(1,100) for _ in range(n)]))
        raws.extend([weights('0'*100000+'1'*100000,list(range(1,200001))),weights('01'*100000,[10**9]*200000)])
    elif number==258:
        def rotations(s:str,q:list[Pair])->str:return f'{len(s)} {len(q)}\n{s}\n'+''.join(line(v) for v in q)
        raws=[rotations('aa',[(2,1)]),rotations('ab',[(2,1),(1,1),(2,1)]),rotations('ab',[(1,2),(2,2)]),rotations('abc',[(1,1),(1,2),(2,3)])]
        for n in range(4,16):q=[(rng.randint(1,2),rng.randint(1,n)) for _ in range(n*3)]+[(2,n)];raws.append(rotations(''.join(rng.choice('abcxyz') for _ in range(n)),q))
        raws.extend([rotations('abcde'*100000,[(1,499999),(2,500000)]*250000),rotations('z'*500000,[(2,500000)]*500000)])
    else:
        pairs=[('aa','aa'),('ab','aab'),('aa','aaa'),('aab','aaab'),('aab','aabb'),('abb','abbb'),('abab','abab'),('abab','aabab'),('aabb','aaabbb'),('aabb','aab'),('abba','abbbba'),('abc','abcd'),('zz','z'*10),('abcc','abcccc'),('aabbcc','aaabbbccc'),('abcabc','abcabc'),('aa','a'*200000),('z'*200000,'z'*200000)];raws=[s+'\n'+t+'\n' for s,t in pairs]
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc254_c':('交換できる位置は、Kで割った余りが同じです。','余りごとの部分列は自由に並べ替えられます。各部分列をソートして元の位置に戻し、全体が昇順か確認します。','疑似コード: for r=0..K-1: A[r::K]=sort(A[r::K]); print(Yes if A==sort(A) else No)。'),
'abc255_c':('Xに最も近い等差数列の項を探します。','公差が負なら数列を反転して正にします。X付近の添字を整数除算で求め、範囲内へ制限した前後の項を比べます。公差0は初項だけです。','疑似コード: normalize D>=0; if D==0: abs(X-A); else: i=clamp((X-A)//D,0,N-1); print(min distances to i and min(i+1,N-1))。'),
'abc256_c':('左上2×2の四つの数を決めれば、残りは行・列の和から決まります。','正の整数となる範囲で四つを列挙し、他の五つを計算します。全て正で行列の和を満たす場合だけ数えます。','疑似コード: for a,b,d,e in positive feasible ranges: c=h1-a-b; f=h2-d-e; g=w1-a-d; h=w2-b-e; i=w3-c-f; if all positive and g+h+i==h3: answer+=1; print(answer)。'),
'abc257_c':('判定の境目を動かしたとき、体重が同じ人はまとめて変化します。','最初は全員を大人と判定します。体重順に同じ体重のグループを子供判定へ変え、正しく判定した人数の最大値を更新します。','疑似コード: score=count adults; answer=score; for equal-weight group ascending: score+=children-adults; answer=max(answer,score); print(answer)。'),
'abc258_c':('文字列を毎回動かさず、先頭に対応する位置だけ記録します。','右へx回回転するなら先頭位置をxだけ戻します。問い合わせ位置を元の文字列の位置に変換します。','疑似コード: offset=0; for (t,x): if t==1: offset=(offset-x)%N; else: print(S[(offset+x-1)%N])。'),
'abc259_c':('同じ文字が連続する部分の種類と順序は操作で変わりません。','連続部分ごとに文字と長さを比較します。元が一文字なら伸ばせず、二文字以上なら元以上の長さへ伸ばせます。短くすることはできません。','疑似コード: A=run_length(S); B=run_length(T); if group counts differ: No; for corresponding groups: require same char and (same length or source>=2 and target>=source); print result。')}

TITLES={'abc254_c': 'K Swap', 'abc255_c': '±1 Operation 1', 'abc256_c': 'Filling 3x3 array', 'abc257_c': 'Robot Takahashi', 'abc258_c': 'Rotation', 'abc259_c': 'XX to XXX'}
PUBLISHED_SAMPLES={'abc254_c': [{'input': '5 2\n3 4 1 3 4\n', 'expected': 'Yes\n'}, {'input': '5 3\n3 4 1 3 4\n', 'expected': 'No\n'}, {'input': '7 5\n1 2 3 4 5 5 10\n', 'expected': 'Yes\n'}], 'abc255_c': [{'input': '6 2 3 3\n', 'expected': '1\n'}, {'input': '0 0 0 1\n', 'expected': '0\n'}, {'input': '998244353 -10 -20 30\n', 'expected': '998244363\n'}, {'input': '-555555555555555555 -1000000000000000000 1000000 1000000000000\n', 'expected': '444445\n'}], 'abc256_c': [{'input': '3 4 6 3 3 7\n', 'expected': '1\n'}, {'input': '3 4 5 6 7 8\n', 'expected': '0\n'}, {'input': '5 13 10 6 13 9\n', 'expected': '120\n'}, {'input': '20 25 30 22 29 24\n', 'expected': '30613\n'}], 'abc257_c': [{'input': '5\n10101\n60 45 30 40 80\n', 'expected': '4\n'}, {'input': '3\n000\n1 2 3\n', 'expected': '3\n'}, {'input': '5\n10101\n60 50 50 50 60\n', 'expected': '4\n'}], 'abc258_c': [{'input': '3 3\nabc\n2 2\n1 1\n2 2\n', 'expected': 'b\na\n'}, {'input': '10 8\ndsuccxulnl\n2 4\n2 7\n1 2\n2 7\n1 1\n1 2\n1 3\n2 5\n', 'expected': 'c\nu\nc\nu\n'}], 'abc259_c': [{'input': 'abbaac\nabbbbaaac\n', 'expected': 'Yes\n'}, {'input': 'xyzz\nxyyzz\n', 'expected': 'No\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
