"""Strict task-specific specifications for ABC048--053 D, canonical ARC IDs."""
from __future__ import annotations
from collections import Counter,deque
from functools import lru_cache
from heapq import heappop,heappush
from itertools import combinations
from typing import cast
import random,re

TASKS=('arc064_b','arc065_b','arc066_b','abc051_d','arc067_b','arc068_b')
CONTESTS={pid:f'abc{n:03}' for n,pid in zip(range(48,54),TASKS)}
PROBLEM_INDEXES={pid:'D' for pid in TASKS}
OUTPUT_MODES:dict[str,str]={}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]
Edge=tuple[int,int]
WeightedEdge=tuple[int,int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'fields');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc064_b':
        require(len(rows)==1 and re.fullmatch('[a-z]{3,100000}',rows[0]) is not None,'game string');s=rows[0];require(all(a!=b for a,b in zip(s,s[1:])),'adjacent distinct');return (s,)
    if pid=='arc065_b':
        n,k,l=ints(rows[0],3);require(2<=n<=200000 and 1<=k<=100000 and 1<=l<=100000 and len(rows)==k+l+1,'network shape')
        edges=tuple(cast(Edge,ints(row,2)) for row in rows[1:]);require(all(1<=a<b<=n for a,b in edges),'ordered endpoints');roads=edges[:k];rails=edges[k:];require(len(set(roads))==k and len(set(rails))==l,'duplicate network edge');return n,roads,rails
    if pid=='arc066_b':
        require(len(rows)==1,'scalar shape');n=ints(rows[0],1)[0];require(1<=n<=10**18,'xor upper bound');return (n,)
    if pid=='abc051_d':
        n,m=ints(rows[0],2);require(2<=n<=100 and n-1<=m<=min(n*(n-1)//2,1000) and len(rows)==m+1,'graph shape')
        edges=tuple(cast(WeightedEdge,ints(row,3)) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b and 1<=c<=1000 for a,b,c in edges),'weighted endpoints');require(len({(min(a,b),max(a,b)) for a,b,c in edges})==m,'parallel edges')
        graph=[[] for _ in range(n)]
        for a,b,c in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
        seen={0};stack=[0]
        while stack:
            for j in graph[stack.pop()]:
                if j not in seen:seen.add(j);stack.append(j)
        require(len(seen)==n,'connected');return n,edges
    if pid=='arc067_b':
        require(len(rows)==2,'town shape');n,a,b=ints(rows[0],3);x=ints(rows[1],n);require(2<=n<=100000 and 1<=a<=10**9 and 1<=b<=10**9,'town bounds');require(all(1<=v<=10**9 for v in x) and all(u<v for u,v in zip(x,x[1:])),'ordered positions');return a,b,x
    require(len(rows)==2,'card shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(3<=n<=100000 and n%2==1 and all(1<=v<=100000 for v in a),'card bounds');return (a,)

@lru_cache(maxsize=200000)
def game_wins(s:str)->bool:
    return any(not game_wins(s[:j]+s[j+1:]) for j in range(1,len(s)-1) if s[j-1]!=s[j+1])

def game_invariant(s:str)->bool:
    # Removing one letter toggles parity; endpoints are immutable. Every
    # terminal proper-coloured string alternates two colours. If endpoints
    # agree it has odd length, otherwise it has even length. Thus all legal
    # maximal plays have the same parity, independently of player choices.
    terminal_parity=1 if s[0]==s[-1] else 0
    return len(s)%2!=terminal_parity

def game_play(s:str,reverse:bool=False)->tuple[int,str]:
    # Actually perform legal deletions. Cached eligibility is never trusted:
    # check the current neighbours again when removing an item from the queue.
    n=len(s);previous=list(range(-1,n-1));following=list(range(1,n+1));alive=[True]*n
    queue=deque(range(n-2,0,-1) if reverse else range(1,n-1));moves=0
    while queue:
        j=queue.popleft()
        if not alive[j]:continue
        left=previous[j];right=following[j]
        if left<0 or right>=n or s[left]==s[right]:continue
        alive[j]=False;following[left]=right;previous[right]=left;moves+=1
        if left>0:queue.append(left)
        if right<n-1:queue.append(right)
    return moves,''.join(ch for j,ch in enumerate(s) if alive[j])

def components(n:int,edges:tuple[Edge,...])->list[int]:
    graph:list[list[int]]=[[] for _ in range(n)]
    for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
    labels=[-1]*n
    for start in range(n):
        if labels[start]!=-1:continue
        labels[start]=start;stack=[start]
        while stack:
            for j in graph[stack.pop()]:
                if labels[j]==-1:labels[j]=start;stack.append(j)
    return labels

@lru_cache(maxsize=10000)
def xor_count(n:int)->int:
    # u=a xor b, c=a&b: u&c=0, v=u+2*c. Their low bits are
    # (0,0),(1,0),(0,1), contributing offsets 0,1,2 respectively.
    if n<0:return 0
    if n==0:return 1
    return (xor_count(n//2)+xor_count((n-1)//2)+xor_count((n-2)//2))%MOD

def shortest_paths(n:int,edges:tuple[WeightedEdge,...])->int:
    graph:list[list[tuple[int,int]]]=[[] for _ in range(n)]
    for a,b,c in edges:graph[a-1].append((b-1,c));graph[b-1].append((a-1,c))
    distances=[]
    for start in range(n):
        dist=[10**20]*n;dist[start]=0;queue=[(0,start)]
        while queue:
            cost,node=heappop(queue)
            if cost!=dist[node]:continue
            for j,weight in graph[node]:
                value=cost+weight
                if value<dist[j]:dist[j]=value;heappush(queue,(value,j))
        distances.append(dist)
    # An edge is on some shortest path iff its endpoints' distance equals
    # its weight: that endpoint pair itself is a witness.
    return sum(distances[a-1][b-1]<c for a,b,c in edges)

def travel_cost(a:int,b:int,x:tuple[int,...])->int:
    if len(x)<=60:
        # Prim on the complete graph whose edges choose walking or teleport.
        # Triangle inequality is not needed; the optimal route's forest is
        # joined by teleports, and a line-metric forest can be uncrossed.
        n=len(x);used=[False]*n;distance=[10**30]*n;distance[0]=0;total=0
        for _ in range(n):
            j=min((j for j in range(n) if not used[j]),key=lambda j:distance[j]);used[j]=True;total+=distance[j]
            for k in range(n):
                if not used[k]:distance[k]=min(distance[k],a*abs(x[j]-x[k]),b)
        return total
    # All partitions into contiguous walking blocks. dp[i] is the cheapest
    # cover through town i. Starting a new block costs one teleport.
    best=-a*x[0];previous=0
    for position in x[1:]:
        best=min(best,previous+b-a*position);previous=a*position+best
    return previous

@lru_cache(maxsize=200000)
def eat_search(cards:tuple[int,...])->int:
    answer=len(set(cards)) if len(set(cards))==len(cards) else 0
    for indexes in combinations(range(len(cards)),3):
        low,mid,high=indexes
        # Sorted cards make the selected first/last minimum/maximum.
        remaining=cards[:low]+cards[low+1:high]+cards[high+1:]
        answer=max(answer,eat_search(remaining))
    return answer

def frequency_eating(cards:tuple[int,...])->int:
    counts=Counter(cards);single=0;double=0
    # Three equal cards become one: cancel each count down to one or two.
    for count in counts.values():
        if count%2:single+=1
        else:double+=1
    # Two doubled labels can each be made single using their triple medians.
    pairs=double//2;single+=2*pairs;double-=2*pairs
    # With one double left, discard an endpoint label along with its excess.
    # N odd ensures an odd positive number of singleton labels exists.
    return single

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc064_b':
        s=cast(str,data[0]);return 'First' if (game_wins(s) if len(s)<=12 else game_play(s)[0]%2==1) else 'Second'
    if pid=='arc065_b':
        n,roads,rails=cast(tuple[int,tuple[Edge,...],tuple[Edge,...]],data);left=components(n,roads);right=components(n,rails);pairs=list(zip(left,right));counts=Counter(pairs);return ' '.join(str(counts[pair]) for pair in pairs)
    if pid=='arc066_b':return str(xor_count(cast(int,data[0])))
    if pid=='abc051_d':return str(shortest_paths(*cast(tuple[int,tuple[WeightedEdge,...]],data)))
    if pid=='arc067_b':return str(travel_cost(*cast(tuple[int,int,tuple[int,...]],data)))
    cards=cast(tuple[int,...],data[0]);return str(eat_search(tuple(sorted(cards))) if len(cards)<=9 else frequency_eating(cards))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'arc064_b':"s=input();print('First' if (len(s)%2==0)==(s[0]==s[-1]) else 'Second')\n",
'arc065_b':"from collections import Counter\nimport sys\nit=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);k=next(it);l=next(it)\ndef build(count):\n p=list(range(n));size=[1]*n\n def find(j):\n  while p[j]!=j:p[j]=p[p[j]];j=p[j]\n  return j\n for _ in range(count):\n  a=find(next(it)-1);b=find(next(it)-1)\n  if a!=b:\n   if size[a]<size[b]:a,b=b,a\n   p[b]=a;size[a]+=size[b]\n return [find(j) for j in range(n)]\nleft=build(k);right=build(l);pairs=list(zip(left,right));counts=Counter(pairs);print(*(counts[pair] for pair in pairs))\n",
'arc066_b':"n=int(input());dp={(0,0):1}\nfor i in range(n.bit_length()+2):\n bit=(n>>i)&1;new={}\n for (carry,borrow),ways in dp.items():\n  for u,c in ((0,0),(1,0),(0,1)):\n   value=u+carry;v=value&1;nc=(value>>1)+c;nb=int(bit-v-borrow<0);key=(nc,nb);new[key]=(new.get(key,0)+ways)%1000000007\n dp=new\nprint(dp.get((0,0),0))\n",
'abc051_d':"n,m=map(int,input().split());dist=[[10**20]*n for _ in range(n)];edges=[]\nfor j in range(n):dist[j][j]=0\nfor _ in range(m):\n a,b,c=map(int,input().split());a-=1;b-=1;dist[a][b]=dist[b][a]=c;edges.append((a,b,c))\nfor k in range(n):\n dk=dist[k]\n for i in range(n):\n  di=dist[i];via=di[k]\n  for j in range(n):\n   value=via+dk[j]\n   if value<di[j]:di[j]=value\nprint(sum(dist[a][b]<c for a,b,c in edges))\n",
'arc067_b':"n,a,b=map(int,input().split());x=list(map(int,input().split()));print(sum(min(a*(v-u),b) for u,v in zip(x,x[1:])))\n",
'arc068_b':"n=int(input());a=list(map(int,input().split()));distinct=len(set(a));print(distinct if distinct%2 else distinct-1)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18100+TASKS.index(pid));raws:list[str]=[]
    if pid=='arc064_b':
        raws=['aba\n','abc\n','abab\n','abca\n','abcab\n','abcabc\n','abababa\n','abacaba\n','abcbacba\n','abcabcabc\n','abacabadaba\n','abcdefghijkl\n','abcabcabcabcabc\n','ab'*49999+'a\n','abc'*33333+'a\n','ab'*49999+'c\n','abc'*33333+'b\n','ab'*50000+'\n']
    elif pid=='arc065_b':
        def networks(n:int,roads:list[Edge],rails:list[Edge])->str:return f'{n} {len(roads)} {len(rails)}\n'+''.join(line(edge) for edge in roads+rails)
        raws=[networks(2,[(1,2)],[(1,2)]),networks(3,[(1,2)],[(2,3)]),networks(3,[(1,2)],[(1,2)]),networks(3,[(1,2),(2,3)],[(1,3)])]
        for n in range(4,16):
            roads=[(j,j+1) for j in range(1,n) if j%3!=0];rails=[(1,j) for j in range(2,n+1) if j%2==0];raws.append(networks(n,roads,rails))
        raws.append(networks(200000,[(j,j+1) for j in range(1,100001)],[(j,j+1) for j in range(100000,200000)]))
        raws.append(networks(200000,[(j,200000) for j in range(1,100001)],[(j,200000) for j in range(100000,200000)]))
    elif pid=='arc066_b':raws=[f'{n}\n' for n in (1,2,3,4,5,6,7,8,15,16,17,1422,2**59-1,2**59,2**59+1,10**18-2,10**18-1,10**18)]
    elif pid=='abc051_d':
        def graph(n:int,edges:list[WeightedEdge])->str:return f'{n} {len(edges)}\n'+''.join(line(edge) for edge in edges)
        raws=[graph(2,[(1,2,1)]),graph(2,[(2,1,1000)]),graph(3,[(1,2,1),(2,3,1),(1,3,2)]),graph(3,[(1,2,1),(2,3,1),(1,3,3)])]
        for n in range(4,16):
            edges=[(j,j+1,rng.randint(1,1000)) for j in range(1,n)];edges += [(a,b,rng.randint(1,1000)) for a in range(1,n+1) for b in range(a+2,n+1) if rng.randrange(3)==0];raws.append(graph(n,edges))
        raws.append(graph(100,[(j,j+1,1000) for j in range(1,100)]))
        edges=[(j,j+1,1) for j in range(1,100)];edges += [(a,b,1000) for a in range(1,101) for b in range(a+2,101)][:901];raws.append(graph(100,edges))
    elif pid=='arc067_b':
        def towns(a:int,b:int,x:list[int])->str:return f'{len(x)} {a} {b}\n'+line(x)
        raws=[towns(1,1,[1,2]),towns(1,10**9,[1,10**9]),towns(10**9,1,[1,10**9]),towns(2,4,[1,3,5]),towns(2,3,[1,2,4])]
        for n in range(3,14):
            x=[1]
            for _ in range(n-1):x.append(x[-1]+rng.randint(1,100))
            raws.append(towns(rng.randint(1,10**9),rng.randint(1,10**9),x))
        raws.append(towns(1,10**9,list(range(1,100000))+[10**9]))
        raws.append(towns(10**9,10**9,list(range(1,100000))+[10**9]))
    else:
        def cards(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[cards([1,1,1]),cards([1,2,3]),cards([1,1,2]),cards([1,2,2]),cards([1,1,1,2,2]),cards([1,2,3,4,5]),cards([1,1,2,2,3]),cards([1,1,2,2,3,3,4]),cards([1]*9)]
        for n in range(11,26,2):raws.append(cards([rng.randint(1,100000) for _ in range(n)]))
        raws.append(cards(list(range(1,99999))+[100000]))
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'arc064_b':('取り除いても両端の文字は変わりません。','操作不能な文字列は2文字が交互に並びます。両端が同じかどうかで終局の長さの偶奇が決まります。','疑似コード: same=(s[0]==s[-1]); 終局の長さはsameなら奇数、他は偶数; 現在の長さと終局の偶奇が違えばFirst、同じならSecondを出力。'),
'arc065_b':('道路と鉄道の連結成分を別々に求めます。','各都市を道路の代表・鉄道の代表の組で分類すると、同じ組の都市数が答えです。','疑似コード: roadDSUとrailDSUへ各辺をunion; pair[i]=(road.find(i),rail.find(i)); pairを頻度集計; 各iについてfreq[pair[i]]を出力。'),
'arc066_b':('a+b=(a xor b)+2*(a and b)を使います。','u=a xor b、c=a and bは同じ桁に同時に1を持ちません。v=u+2*c<=Nだけを数えればu<=Nも満たします。','疑似コード: 下位桁から(u_bit,c_bit)=(0,0),(1,0),(0,1)を試す; vの加算carryとN-vのborrowを状態にDP; 上位まで処理しcarry=borrow=0の通り数をmodで出力。'),
'abc051_d':('辺そのものが両端間の最短経路になるか調べます。','全点対最短距離を求め、辺の重みが両端間の距離より大きければその辺は使われません。','疑似コード: distを辺重みで初期化; k,i,jについてdist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]); 各辺(a,b,c)でdist[a][b]<cの数を出力。'),
'arc067_b':('西から東へ順番に町を訪れる最適な方法があります。','隣り合う町ごとに徒歩の疲労A*距離とテレポートBの小さい方を選びます。','疑似コード: answer=0; i=1..N-1についてanswer+=min(A*(X[i+1]-X[i]),B); answerを出力。'),
'arc068_b':('操作ごとにカードの総枚数は2枚減ります。','異なる値の数が上限です。奇数枚しか残せないので、その上限以下の最大の奇数を求めます。','疑似コード: D=len(set(A)); Dが偶数ならD-=1; Dを出力。')}

TITLES={'arc064_b': 'An Ordinary Game', 'arc065_b': '連結', 'arc066_b': 'Xor Sum', 'abc051_d': 'Candidates of No Shortest Paths', 'arc067_b': 'Walk and Teleport', 'arc068_b': 'Card Eater'}
PUBLISHED_SAMPLES={'arc064_b': [{'input': 'aba\n', 'expected': 'Second\n'}, {'input': 'abc\n', 'expected': 'First\n'}, {'input': 'abcab\n', 'expected': 'First\n'}], 'arc065_b': [{'input': '4 3 1\n1 2\n2 3\n3 4\n2 3\n', 'expected': '1 2 2 1\n'}, {'input': '4 2 2\n1 2\n2 3\n1 4\n2 3\n', 'expected': '1 2 2 1\n'}, {'input': '7 4 4\n1 2\n2 3\n2 5\n6 7\n3 5\n4 5\n3 4\n6 7\n', 'expected': '1 1 2 1 2 2 2\n'}], 'arc066_b': [{'input': '3\n', 'expected': '5\n'}, {'input': '1422\n', 'expected': '52277\n'}, {'input': '1000000000000000000\n', 'expected': '787014179\n'}], 'abc051_d': [{'input': '3 3\n1 2 1\n1 3 1\n2 3 3\n', 'expected': '1\n'}, {'input': '3 2\n1 2 1\n2 3 1\n', 'expected': '0\n'}], 'arc067_b': [{'input': '4 2 5\n1 2 5 7\n', 'expected': '11\n'}, {'input': '7 1 100\n40 43 45 105 108 115 124\n', 'expected': '84\n'}, {'input': '7 1 2\n24 35 40 68 72 99 103\n', 'expected': '12\n'}], 'arc068_b': [{'input': '5\n1 2 1 3 7\n', 'expected': '3\n'}, {'input': '15\n1 3 5 2 1 3 2 8 8 6 2 6 11 1 1\n', 'expected': '7\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}

