"""Statement-checked three-stage hints for ABC275–277 B."""
HINTS_V139 = {
    'abc275_b': (
        '求めたいのは2つの3項積の差そのものではなく、その差を998244353で割った余りです。積が非常に大きいので、合同式を使うことを考えてください。',
        '各積は途中でMODを取りながら計算して構いません。最後に左側の積から右側の積を引き、Pythonならさらに% MODを取れば0以上MOD未満にできます。',
        '疑似コード:\nMOD = 998244353\nleft = (A % MOD) * (B % MOD) % MOD\nleft = left * (C % MOD) % MOD\nright = (D % MOD) * (E % MOD) % MOD\nright = right * (F % MOD) % MOD\nprint((left - right) % MOD)',
    ),
    'abc276_b': (
        '各都市について「直接つながる都市一覧」を持てば、そのまま求める出力に近い形になります。道路1本から両端の都市へ相手を追加してください。',
        '無向グラフなので道路(a,b)を読んだらadj[a]へb、adj[b]へaを追加します。最後に各adj[i]を昇順ソートし、個数と一緒に出力します。',
        '疑似コード:\nadj = [empty list for each city]\nfor each road (a,b):\n  adj[a].append(b)\n  adj[b].append(a)\nfor city i = 1..N:\n  sort(adj[i])\n  print(len(adj[i]), adj[i] in ascending order)',
    ),
    'abc277_b': (
        '各カードについて「1文字目が許可されたスートか」「2文字目が許可されたランクか」を確認し、さらに同じ2文字列が2回以上出ていないかを確認します。',
        'スート集合を{H,D,C,S}、ランク集合を{A,2,...,9,T,J,Q,K}としてmembership判定できます。重複はsetへ追加しながら既出かを見るか、最後にsetの大きさを比較します。',
        '疑似コード:\nseen = empty set\nfor card in cards:\n  if card[0] not in valid_suits: print("No"); stop\n  if card[1] not in valid_ranks: print("No"); stop\n  if card in seen: print("No"); stop\n  seen.add(card)\nprint("Yes")',
    ),
}
