"""Statement-checked three-stage hints for ABC167–169 B."""
HINTS_V103 = {
    'abc167_b': (
        '最大化したいので、値が大きいカードから取るのが最善です。1のカード、0のカード、-1のカードの順にK枚へ達するまで取ると考えてください。',
        'まず1をmin(A,K)枚取ります。残りから0を最大B枚取り、それでもK枚に足りない枚数だけ-1を取ります。答えは「取った1の枚数 - 取った-1の枚数」です。',
        '''疑似コード:\nones = min(A, K)\nremain = K - ones\nzeros = min(B, remain)\nremain -= zeros\nminus_ones = remain\nprint(ones - minus_ones)''',
    ),
    'abc168_b': (
        '必要なのはSの長さとKの比較だけです。SがK文字以内なら一切加工しません。',
        'len(S) <= K ならSをそのまま出力し、それ以外なら S[:K] の末尾へ "..." を連結します。',
        '''疑似コード:\nif len(S) <= K:\n  print(S)\nelse:\n  print(S[:K] + "...")''',
    ),
    'abc169_b': (
        '積が10^18を超えたら-1ですが、配列に0が1つでもあれば最終積は必ず0です。まず0の存在を確認すると安全です。',
        '0がなければ左から積を更新します。掛ける前に product > 10^18 // A[i] を確認すれば、巨大な整数を作らずに超過を判定できます。',
        '''疑似コード:\nif 0 in A:\n  print(0)\n  stop\nproduct = 1\nfor x in A:\n  if product > 10^18 // x:\n    print(-1)\n    stop\n  product *= x\nprint(product)''',
    ),
}
