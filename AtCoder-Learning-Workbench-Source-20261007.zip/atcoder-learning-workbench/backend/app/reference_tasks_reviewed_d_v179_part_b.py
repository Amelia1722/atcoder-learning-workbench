"""Independent graph flows, rotated binomials, cycles, offline LCA and dual DP."""
from __future__ import annotations
from collections import deque
from decimal import Decimal,localcontext,DecimalException
from heapq import heappush,heappop
from math import comb
from typing import cast
import random,re

TASKS=tuple(f'abc{n:03}_4' for n in range(10,16))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc011_4':'numeric_tolerance_1e-9'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    if count==0:require(row=='','empty list');return ()
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def connected(n:int,edges:tuple[tuple[int,...],...],zero_based:bool=False)->bool:
    g=[[] for _ in range(n)]
    for edge in edges:
        a,b=edge[:2];a-=not zero_based;b-=not zero_based;g[a].append(b);g[b].append(a)
    seen={0};queue=[0]
    for node in queue:
        for v in g[node]:
            if v not in seen:seen.add(v);queue.append(v)
    return len(seen)==n
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');k=int(pid[3:6])
    if k==10:
        require(len(rows)>=2,'shape');n,g,e=ints(rows[0],3);require(1<=n<=100 and 0<=g<n and 0<=e<=n*(n-1)//2 and len(rows)==e+2,'size');girls=ints(rows[1],g);edges=tuple(ints(row,2) for row in rows[2:]);require(len(set(girls))==g and all(1<=v<n for v in girls),'girls');require(all(0<=a<n and 0<=b<n for a,b in edges) and len({tuple(sorted(edge)) for edge in edges})==e,'friendships');return n,girls,edges
    if k==13:
        require(len(rows)==2,'shape');n,m,d=ints(rows[0],3);a=ints(rows[1],m);require(2<=n<=100000 and 0<=m<=200000 and 1<=d<=10**9 and all(1<=v<n for v in a),'amida');return n,d,a
    require(all(rows),'blank')
    if k==11:
        require(len(rows)==2,'shape');n,d=ints(rows[0],2);x,y=ints(rows[1],2);require(1<=n<=1000 and 1<=d<=10**9 and -10**9<=x<=10**9 and -10**9<=y<=10**9,'jumps');return n,d,x,y
    if k==12:
        n,m=ints(rows[0],2);require(2<=n<=300 and n-1<=m<=44850 and len(rows)==m+1,'size');edges=tuple(ints(row,3) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b and 1<=t<=1000 for a,b,t in edges) and len({tuple(sorted((a,b))) for a,b,t in edges})==m,'routes');require(connected(n,edges),'connected');return n,edges
    if k==14:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)>=n+2,'shape');edges=tuple(ints(row,2) for row in rows[1:n]);q=ints(rows[n],1)[0];queries=tuple(ints(row,2) for row in rows[n+1:]);require(1<=q<=100000 and len(queries)==q,'Q');edgekeys={tuple(sorted(v)) for v in edges};require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges) and len(edgekeys)==n-1 and connected(n,edges),'tree');require(all(1<=a<=n and 1<=b<=n and a!=b and tuple(sorted((a,b))) not in edgekeys for a,b in queries),'new edges');return n,edges,queries
    require(k==15 and len(rows)>=3,'shape');w=ints(rows[0],1)[0];n,limit=ints(rows[1],2);items=tuple(ints(row,2) for row in rows[2:]);require(1<=w<=10000 and 1<=limit<=n<=50 and len(items)==n and all(1<=a<=1000 and 1<=b<=100 for a,b in items),'screenshots');return w,limit,items

def _flow(n:int,girls:tuple[int,...],edges:tuple[tuple[int,int],...])->int:
    sink=n;capacity=[[0]*(n+1) for _ in range(n+1)]
    for a,b in edges:
        if a!=b:capacity[a][b]=capacity[b][a]=1
    for v in girls:capacity[v][sink]=1
    flow=0
    while True:
        previous=[-1]*(n+1);previous[0]=0;queue=deque([0])
        while queue and previous[sink]<0:
            node=queue.popleft()
            for v,c in enumerate(capacity[node]):
                if c>0 and previous[v]<0:previous[v]=node;queue.append(v)
        if previous[sink]<0:return flow
        node=sink
        while node:parent=previous[node];capacity[parent][node]-=1;capacity[node][parent]+=1;node=parent
        flow+=1

def probability(n:int,d:int,x:int,y:int)->Decimal:
    if x%d or y%d:return Decimal(0)
    x//=d;y//=d
    if (n+x+y)%2 or abs(x)+abs(y)>n:return Decimal(0)
    a=(n+x+y)//2;b=(n+x-y)//2
    with localcontext() as context:context.prec=2*n+20;return Decimal(comb(n,a)*comb(n,b))/Decimal(4**n)

def numeric_match(actual:str,expected:Decimal)->bool:
    token=actual.removesuffix('\n')
    if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
    try:
        with localcontext() as context:
            context.prec=4096;value=Decimal(token)
            return value.is_finite() and abs(value-expected)<=max(Decimal('1e-9'),Decimal('1e-9')*abs(expected))
    except (DecimalException,OverflowError):return False

def _offline_lca(n:int,edges:tuple[tuple[int,int],...],queries:tuple[tuple[int,int],...])->str:
    graph=[[] for _ in range(n)];pending=[[] for _ in range(n)]
    for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
    for j,(a,b) in enumerate(queries):pending[a-1].append((b-1,j));pending[b-1].append((a-1,j))
    parent=list(range(n));ancestor=list(range(n));depth=[0]*n;black=bytearray(n);answer=[0]*len(queries)
    def root(v:int)->int:
        while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
        return v
    # Enter, union-completed-child, and exit preserve Tarjan DFS ordering.
    stack=[(0,-1,0)]
    while stack:
        node,previous,event=stack.pop()
        if event==1:parent[root(node)]=root(previous);ancestor[root(previous)]=previous;continue
        if event==2:
            black[node]=1
            for other,j in pending[node]:
                if black[other]:lca=ancestor[root(other)];answer[j]=depth[node]+depth[other]-2*depth[lca]+1
            continue
        ancestor[root(node)]=node;stack.append((node,previous,2))
        for child in reversed(graph[node]):
            if child!=previous:depth[child]=depth[node]+1;stack.append((child,node,1));stack.append((child,node,0))
    return '\n'.join(map(str,answer))

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);k=int(pid[3:6])
    if k==10:return str(_flow(*cast(tuple[int,tuple[int,...],tuple[tuple[int,int],...]],data)))
    if k==11:return str(probability(*cast(tuple[int,int,int,int],data)))
    if k==12:
        n,edges=cast(tuple[int,tuple[tuple[int,int,int],...]],data);graph=[[] for _ in range(n)]
        for a,b,t in edges:graph[a-1].append((b-1,t));graph[b-1].append((a-1,t))
        best=10**9
        for start in range(n):
            distances=[10**9]*n;distances[start]=0;heap=[(0,start)]
            while heap:
                cost,node=heappop(heap)
                if cost!=distances[node]:continue
                for v,t in graph[node]:
                    new=cost+t
                    if new<distances[v]:distances[v]=new;heappush(heap,(new,v))
            best=min(best,max(distances))
        return str(best)
    if k==13:
        n,d,swaps=cast(tuple[int,int,tuple[int,...]],data);p=list(range(n))
        for j in reversed(swaps):p[j-1],p[j]=p[j],p[j-1]
        answer=[0]*n;seen=bytearray(n)
        for start in range(n):
            if seen[start]:continue
            cycle=[];node=start
            while not seen[node]:seen[node]=1;cycle.append(node);node=p[node]
            for j,v in enumerate(cycle):answer[v]=cycle[(j+d)%len(cycle)]+1
        return '\n'.join(map(str,answer))
    if k==14:return _offline_lca(*cast(tuple[int,tuple[tuple[int,int],...],tuple[tuple[int,int],...]],data))
    w,limit,items=cast(tuple[int,int,tuple[tuple[int,int],...]],data);total=sum(b for a,b in items);inf=10**9;dp=[[inf]*(total+1) for _ in range(limit+1)];dp[0][0]=0;processed=0;value_sum=0
    for width,value in items:
        for count in range(min(processed+1,limit),0,-1):
            current,prev=dp[count],dp[count-1]
            for score in range(value_sum+1):
                if prev[score]+width<current[score+value]:current[score+value]=prev[score]+width
        processed+=1;value_sum+=value
    return str(max(score for row in dp for score,width in enumerate(row) if width<=w))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc011_4':return numeric_match(actual,probability(*cast(tuple[int,int,int,int],validate(pid,raw))))
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,DecimalException,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc011_4':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc010_4':"import sys\nsys.setrecursionlimit(10000);n,g,e=map(int,input().split());girls=list(map(int,input().split()));graph=[[] for _ in range(n+1)]\ndef add(a,b,c):\n graph[a].append([b,c,len(graph[b])]);graph[b].append([a,0,len(graph[a])-1])\nfor _ in range(e):\n a,b=map(int,input().split())\n if a!=b:add(a,b,1);add(b,a,1)\nfor v in girls:add(v,n,1)\nanswer=0\nwhile True:\n level=[-1]*(n+1);level[0]=0;queue=[0]\n for a in queue:\n  for b,c,r in graph[a]:\n   if c and level[b]<0:level[b]=level[a]+1;queue.append(b)\n if level[n]<0:break\n cursor=[0]*(n+1)\n def dfs(a):\n  if a==n:return 1\n  while cursor[a]<len(graph[a]):\n   edge=graph[a][cursor[a]];b,c,r=edge\n   if c and level[b]==level[a]+1 and dfs(b):edge[1]-=1;graph[b][r][1]+=1;return 1\n   cursor[a]+=1\n  return 0\n while dfs(0):answer+=1\nprint(answer)\n",
'abc011_4':"from math import comb\nn,d=map(int,input().split());x,y=map(int,input().split())\nif x%d or y%d:print(0.0)\nelse:\n x=abs(x)//d;y=abs(y)//d;ways=0\n for h in range(n+1):\n  v=n-h\n  if h>=x and v>=y and (h-x)%2==0 and (v-y)%2==0:ways+=comb(n,h)*comb(h,(h+x)//2)*comb(v,(v+y)//2)\n print(ways/4**n)\n",
'abc012_4':"n,m=map(int,input().split());d=[[10**9]*n for _ in range(n)]\nfor j in range(n):d[j][j]=0\nfor _ in range(m):a,b,t=map(int,input().split());d[a-1][b-1]=d[b-1][a-1]=t\nfor k in range(n):\n for i in range(n):\n  row=d[i];via=row[k];middle=d[k]\n  for j in range(n):\n   if via+middle[j]<row[j]:row[j]=via+middle[j]\nprint(min(map(max,d)))\n",
'abc013_4':"n,m,d=map(int,input().split());swaps=list(map(int,input().split()));p=list(range(n))\nfor j in swaps:p[j-1],p[j]=p[j],p[j-1]\none=[0]*n\nfor j,v in enumerate(p):one[v]=j\nanswer=list(range(n))\nwhile d:\n if d&1:answer=[one[v] for v in answer]\n one=[one[v] for v in one];d//=2\nprint('\\n'.join(str(v+1) for v in answer))\n",
'abc014_4':"import sys\nv=iter(map(int,sys.stdin.buffer.read().split()));n=next(v);g=[[] for _ in range(n)]\nfor _ in range(n-1):a=next(v)-1;b=next(v)-1;g[a].append(b);g[b].append(a)\nparent=[-1]*n;parent[0]=0;depth=[0]*n;queue=[0]\nfor a in queue:\n for b in g[a]:\n  if parent[b]<0:parent[b]=a;depth[b]=depth[a]+1;queue.append(b)\nup=[parent]\nfor _ in range(n.bit_length()):up.append([up[-1][up[-1][j]] for j in range(n)])\nout=[]\nfor _ in range(next(v)):\n a=next(v)-1;b=next(v)-1;distance=depth[a]+depth[b]\n if depth[a]<depth[b]:a,b=b,a\n gap=depth[a]-depth[b]\n for bit in range(len(up)):\n  if gap>>bit&1:a=up[bit][a]\n if a!=b:\n  for row in reversed(up):\n   if row[a]!=row[b]:a,b=row[a],row[b]\n  a=parent[a]\n out.append(str(distance-2*depth[a]+1))\nprint('\\n'.join(out))\n",
'abc015_4':"w=int(input());n,k=map(int,input().split());dp=[[-1]*(w+1) for _ in range(k+1)];dp[0][0]=0\nfor index in range(n):\n a,b=map(int,input().split())\n for count in range(min(k,index+1),0,-1):\n  row,previous=dp[count],dp[count-1]\n  for width in range(w,a-1,-1):\n   if previous[width-a]>=0:row[width]=max(row[width],previous[width-a]+b)\nprint(max(max(row) for row in dp))\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');k=int(pid[3:6]);rng=random.Random(17900+k);raws:list[str]=[]
    if k==10:
        def network(n:int,girls:list[int],edges:list[tuple[int,int]])->str:return f'{n} {len(girls)} {len(edges)}\n'+line(girls)+''.join(line(e) for e in edges)
        raws=[network(1,[],[]),network(2,[1],[]),network(2,[1],[(0,1)]),network(4,[2,3],[(0,1),(1,2),(1,3)])]
        for n in range(3,16):raws.append(network(n,list(range(1,n)),[(a,b) for a in range(n) for b in range(a+1,n) if rng.randrange(3)==0]))
        raws.append(network(100,list(range(1,100)),[(a,b) for a in range(100) for b in range(a+1,100)]))
    elif k==11:
        configs=[(1,1,0,0),(1,1,1,0),(1,1,-1,0),(1,2,1,0),(2,1,0,0),(2,1,1,1),(2,1,2,0),(3,1,0,0),(3,1,-1,-2),(10,1,10,0),(1000,1,0,0),(1000,1,1000,0),(1000,1,2,2),(999,1,1,0),(1000,10**9,-10**9,10**9),(1000,999999999,10**9,-10**9),(1000,1,10**9,10**9),(1000,10**9,10**9,10**9)]
        raws=[f'{n} {d}\n{x} {y}\n' for n,d,x,y in configs]
    elif k==12:
        def buses(n:int,e:list[tuple[int,int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(v) for v in e)
        raws=[buses(2,[(1,2,1)]),buses(2,[(2,1,1000)]),buses(3,[(1,2,1),(2,3,1)]),buses(3,[(1,2,1000),(2,3,1000),(1,3,1)])]
        for n in range(4,17):raws.append(buses(n,[(j,j+1,rng.randint(1,1000)) for j in range(1,n)]+[(a,b,rng.randint(1,1000)) for a in range(1,n+1) for b in range(a+2,n+1) if rng.randrange(4)==0]))
        raws.append(buses(300,[(a,b,1000) for a in range(1,301) for b in range(a+1,301)]))
    elif k==13:
        def amida(n:int,d:int,a:list[int])->str:return f'{n} {len(a)} {d}\n'+line(a)
        raws=[amida(2,1,[]),amida(2,1,[1]),amida(2,2,[1]),amida(3,3,[1,2])]+[amida(n,10**9-n,[rng.randrange(1,n) for _ in range(n*3)]) for n in range(3,16)]+[amida(100000,10**9,list(range(1,100000))*2+[99999,1])]
    elif k==14:
        def tree(n:int,edges:list[tuple[int,int]],queries:list[tuple[int,int]])->str:return f'{n}\n'+''.join(line(e) for e in edges)+f'{len(queries)}\n'+''.join(line(q) for q in queries)
        raws=[tree(3,[(1,2),(2,3)],[(1,3)]),tree(3,[(2,1),(3,2)],[(3,1)]),tree(4,[(1,2),(1,3),(1,4)],[(2,3),(3,4)]),tree(4,[(1,2),(2,3),(3,4)],[(1,4),(1,3),(2,4)])]
        for n in range(5,18):
            edges=[(j,rng.randrange(1,j)) for j in range(2,n+1)];keys={tuple(sorted(e)) for e in edges};qs=[(a,b) for a in range(1,n+1) for b in range(a+1,n+1) if (a,b) not in keys];raws.append(tree(n,edges,qs))
        raws.append(tree(100000,[(j,j+1) for j in range(1,100000)],[(1,100000)]*100000))
    else:
        def screenshots(w:int,k:int,items:list[tuple[int,int]])->str:return f'{w}\n{len(items)} {k}\n'+''.join(line(v) for v in items)
        raws=[screenshots(1,1,[(1,1)]),screenshots(1,1,[(2,100)]),screenshots(2,1,[(1,1),(1,100)]),screenshots(2,2,[(1,1),(1,100)])]+[screenshots(n*25,1+n%3,[(rng.randint(1,1000),rng.randint(1,100)) for _ in range(n)]) for n in range(3,16)]+[screenshots(10000,50,[(1000,100)]*50)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc010_4':('友人関係を切る操作と、女の子の閲覧を止める操作を辺の削除として表せます。','各友人関係は容量1の両向き辺、各女の子から終点へ容量1の辺を作ります。最小カットが答えです。','疑似コード: source=0,sink=N; 友人辺を両向き容量1、girl→sinkを容量1; 最大flowを増加路で計算し出力。'),
'abc011_4':('Dで割れない座標や、必要歩数と偶奇が合わない座標には届きません。','水平の移動回数hを決めると、右・左・上・下の回数が決まります。方向列の個数を組合せで数えます。','疑似コード: X,YをDで割る; h=0..Nで右=(h+|X|)/2,上=(N-h+|Y|)/2が整数か検査; C(N,h)C(h,右)C(N-h,上)を合計して4^Nで割る。'),
'abc012_4':('各候補地から一番遠いバス停までの最短時間を比べます。','Floyd-Warshallで全点間最短時間を求めます。各行の最大値のうち最小が答えです。','疑似コード: distに各路線を登録; k,i,jでdist[i][j]=min(dist[i][j],dist[i][k]+dist[k][j]); min_i max_j dist[i][j]を出力。'),
'abc013_4':('1回のあみだくじは番号の順列になります。','2回、4回、8回後の行き先を重ね、Dの二進表記で必要な回数を適用します。','疑似コード: 横線swapからone-step移動先を作る; Dの各bitが1ならanswer=one[answer]; one=one[one]としDを右シフト; 最終行き先を出力。'),
'abc014_4':('新しい辺でできる閉路の長さは、元の木の2頂点間距離に1を足したものです。','深さと二分累乗の祖先を持ち、最小共通祖先LCAを求めます。','疑似コード: DFSでdepth,parent、up[k][v]=2^k祖先; query(a,b)でLCA=cを求めdepth[a]+depth[b]-2depth[c]+1を出力。'),
'abc015_4':('幅だけでなく、使用する枚数も状態に含めます。','DP[count][width]に最大重要度を持ち、各画像を使う遷移を逆順で更新します。','疑似コード: DP[0][0]=0; 各(a,b)でcountとwidthを降順に走査しDP[count][width]=max(現値,DP[count-1][width-a]+b); 全状態の最大値を出力。')}

TITLES={'abc010_4': '浮気予防', 'abc011_4': '大ジャンプ', 'abc012_4': 'バスと避けられない運命', 'abc013_4': '阿弥陀', 'abc014_4': '閉路', 'abc015_4': '高橋くんの苦悩'}
PUBLISHED_SAMPLES={'abc010_4': [{'input': '4 2 3\n2 3\n0 1\n1 2\n1 3\n', 'expected': '1\n'}, {'input': '4 1 4\n3\n0 1\n0 2\n1 3\n2 3\n', 'expected': '1\n'}, {'input': '10 3 11\n7 8 9\n0 1\n0 2\n0 3\n0 4\n1 5\n2 5\n5 6\n6 7\n6 8\n3 9\n4 9\n', 'expected': '2\n'}, {'input': '6 2 6\n4 5\n0 1\n0 2\n1 3\n2 3\n3 4\n3 5\n', 'expected': '2\n'}, {'input': '4 3 3\n1 2 3\n1 2\n1 3\n2 3\n', 'expected': '0\n'}], 'abc011_4': [{'input': '2 10000000\n10000000 10000000\n', 'expected': '0.125\n'}, {'input': '100 2\n3 7\n', 'expected': '0.0\n'}, {'input': '11 8562174\n25686522 17124348\n', 'expected': '0.018174648284912\n'}], 'abc012_4': [{'input': '3 2\n1 2 10\n2 3 10\n', 'expected': '10\n'}, {'input': '5 5\n1 2 12\n2 3 14\n3 4 7\n4 5 9\n5 1 18\n', 'expected': '26\n'}, {'input': '4 6\n1 2 1\n2 3 1\n3 4 1\n4 1 1\n1 3 1\n4 2 1\n', 'expected': '1\n'}], 'abc013_4': [{'input': '5 7 1\n1 4 3 4 2 3 1\n', 'expected': '4\n2\n5\n3\n1\n'}, {'input': '5 7 2\n1 4 3 4 2 3 1\n', 'expected': '3\n2\n1\n5\n4\n'}, {'input': '10 20 300\n9 1 2 5 8 1 9 3 5 6 4 5 4 6 8 3 2 7 9 6\n', 'expected': '3\n7\n2\n4\n5\n9\n6\n1\n8\n10\n'}], 'abc014_4': [{'input': '5\n1 2\n1 3\n1 4\n4 5\n3\n2 3\n2 5\n2 4\n', 'expected': '3\n4\n3\n'}, {'input': '6\n1 2\n2 3\n3 4\n4 5\n5 6\n4\n1 3\n1 4\n1 5\n1 6\n', 'expected': '3\n4\n5\n6\n'}, {'input': '7\n3 1\n2 1\n2 4\n2 5\n3 6\n3 7\n5\n4 5\n1 6\n5 6\n4 7\n5 3\n', 'expected': '3\n3\n5\n5\n4\n'}], 'abc015_4': [{'input': '10\n3 2\n4 20\n3 40\n6 100\n', 'expected': '140\n'}, {'input': '10\n5 4\n9 10\n3 7\n3 1\n2 6\n4 5\n', 'expected': '18\n'}, {'input': '22\n5 3\n5 40\n8 50\n3 60\n4 70\n6 80\n', 'expected': '210\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
