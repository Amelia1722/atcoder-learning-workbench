"""ABC260–262 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc260_b', 'abc261_b', 'abc262_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc260_b': [
        {'input': '6 1 0 2\n80 60 80 60 70 70\n40 20 50 90 90 80\n', 'expected': '1\n4\n5\n'},
        {'input': '5 2 1 2\n0 100 0 100 0\n0 0 100 100 0\n', 'expected': '1\n2\n3\n4\n5\n'},
        {'input': '15 4 3 2\n30 65 20 95 100 45 70 85 20 35 95 50 40 15 85\n0 25 45 35 65 70 80 90 40 55 20 20 45 75 100\n', 'expected': '2\n4\n5\n6\n7\n8\n11\n14\n15\n'},
    ],
    'abc261_b': [
        {'input': '4\n-WWW\nL-DD\nLD-W\nLDW-\n', 'expected': 'incorrect\n'},
        {'input': '2\n-D\nD-\n', 'expected': 'correct\n'},
    ],
    'abc262_b': [
        {'input': '5 6\n1 5\n4 5\n2 3\n1 4\n3 5\n2 5\n', 'expected': '2\n'},
        {'input': '3 1\n1 2\n', 'expected': '0\n'},
        {'input': '7 10\n1 7\n5 7\n2 5\n3 6\n4 7\n1 5\n2 4\n1 3\n1 6\n2 7\n', 'expected': '4\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints(line: str, count: int, pattern: re.Pattern[str] = NONNEG) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate260(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 3:
        raise ValueError('shape')
    n, x, y, z = _ints(lines[0], 4)
    if not 1 <= n <= 1000 or any(v > n for v in (x, y, z)) or not 1 <= x + y + z <= n:
        raise ValueError('constraints')
    a = _ints(lines[1], n)
    b = _ints(lines[2], n)
    if any(v > 100 for v in a + b):
        raise ValueError('scores')
    return n, x, y, z, tuple(a), tuple(b)


def _validate261(raw: str):
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N')
    n = int(lines[0])
    if not 2 <= n <= 1000 or len(lines) != n + 1:
        raise ValueError('shape')
    rows = lines[1:]
    for i, row in enumerate(rows):
        if len(row) != n:
            raise ValueError('row length')
        for j, c in enumerate(row):
            if i == j:
                if c != '-':
                    raise ValueError('diagonal')
            elif c not in 'WLD':
                raise ValueError('result token')
    return tuple(rows)


def _validate262(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    n, m = _ints(lines[0], 2, POS)
    if not 3 <= n <= 100 or not 1 <= m <= n * (n - 1) // 2 or len(lines) != m + 1:
        raise ValueError('constraints/shape')
    edges = []
    seen = set()
    for line in lines[1:]:
        u, v = _ints(line, 2, POS)
        if not 1 <= u < v <= n or (u, v) in seen:
            raise ValueError('edge')
        seen.add((u, v))
        edges.append((u, v))
    return n, tuple(edges)


def validate(pid: str, raw: str):
    if pid == 'abc260_b':
        return _validate260(raw)
    if pid == 'abc261_b':
        return _validate261(raw)
    if pid == 'abc262_b':
        return _validate262(raw)
    raise ValueError('unknown task')


def _oracle260(n: int, x: int, y: int, z: int, a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...]:
    remaining = set(range(n))
    selected: list[int] = []
    for count, score in ((x, a), (y, b), (z, tuple(a[i] + b[i] for i in range(n)))):
        for _ in range(count):
            best = None
            for i in remaining:
                if best is None or score[i] > score[best] or (score[i] == score[best] and i < best):
                    best = i
            assert best is not None
            remaining.remove(best)
            selected.append(best + 1)
    return tuple(sorted(selected))


def _oracle261(rows: tuple[str, ...]) -> str:
    valid_pairs = {('W', 'L'), ('L', 'W'), ('D', 'D')}
    n = len(rows)
    for i in range(n):
        for j in range(i + 1, n):
            if (rows[i][j], rows[j][i]) not in valid_pairs:
                return 'incorrect'
    return 'correct'


def _oracle262(n: int, edges: tuple[tuple[int, int], ...]) -> int:
    adj = [set() for _ in range(n)]
    for u, v in edges:
        u -= 1
        v -= 1
        adj[u].add(v)
        adj[v].add(u)
    total = 0
    for u, v in ((u - 1, v - 1) for u, v in edges):
        total += len(adj[u] & adj[v])
    return total // 3


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc260_b':
        expected = _oracle260(*value)
        parts = output.split('\n')
        if len(parts) != len(expected) or any(POS.fullmatch(p) is None for p in parts):
            return False
        return tuple(map(int, parts)) == expected
    if pid == 'abc261_b':
        return output in {'correct', 'incorrect'} and output == _oracle261(value)
    if NONNEG.fullmatch(output) is None:
        return False
    n, edges = value
    return int(output) == _oracle262(n, edges)


def _table(n: int, *, bad: tuple[int, int] | None = None) -> str:
    rows = [['-'] * n for _ in range(n)]
    inv = {'W': 'L', 'L': 'W', 'D': 'D'}
    vals = ('W', 'L', 'D')
    for i in range(n):
        for j in range(i + 1, n):
            c = vals[(i * 17 + j * 31 + n) % 3]
            rows[i][j] = c
            rows[j][i] = inv[c]
    if bad is not None:
        i, j = bad
        current = rows[j][i]
        rows[j][i] = 'D' if current != 'D' else 'W'
    return f'{n}\n' + '\n'.join(''.join(r) for r in rows) + '\n'


def _graph(n: int, edges: list[tuple[int, int]]) -> str:
    return f'{n} {len(edges)}\n' + ''.join(f'{u} {v}\n' for u, v in edges)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc260_b':
        cases = [
            ('minimum_math_only', '1 1 0 0\n0\n0\n'),
            ('minimum_english_only', '1 0 1 0\n0\n0\n'),
            ('minimum_total_only', '1 0 0 1\n0\n0\n'),
            ('tie_math', '4 2 0 0\n100 100 100 100\n4 3 2 1\n'),
            ('tie_english', '4 0 2 0\n4 3 2 1\n100 100 100 100\n'),
            ('tie_total', '4 0 0 2\n100 0 60 40\n0 100 40 60\n'),
            ('stage_exclusion', '5 1 1 1\n100 90 80 70 60\n0 100 90 80 70\n'),
            ('zero_math_stage', '5 0 2 1\n90 80 70 60 50\n10 100 90 0 80\n'),
            ('zero_english_stage', '5 2 0 1\n100 90 80 70 60\n0 20 100 90 80\n'),
            ('zero_total_stage', '5 2 2 0\n100 90 80 70 60\n0 20 100 90 80\n'),
            ('all_admitted', '6 2 2 2\n10 20 30 40 50 60\n60 50 40 30 20 10\n'),
            ('all_zero_scores', '6 1 2 1\n0 0 0 0 0 0\n0 0 0 0 0 0\n'),
            ('mixed_n20', '20 5 4 3\n' + ' '.join(str((i * 37) % 101) for i in range(20)) + '\n' + ' '.join(str((i * 53 + 7) % 101) for i in range(20)) + '\n'),
            ('mixed_n100', '100 20 15 10\n' + ' '.join(str((i * 19 + 3) % 101) for i in range(100)) + '\n' + ' '.join(str((i * 47 + 11) % 101) for i in range(100)) + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        n = 1000
        add('constraint_max', f'{n} 334 333 333\n' + ' '.join(str((i * 29 + 5) % 101) for i in range(n)) + '\n' + ' '.join(str((i * 61 + 13) % 101) for i in range(n)) + '\n')
    elif pid == 'abc261_b':
        custom = [
            ('n2_wl', '2\n-W\nL-\n'),
            ('n2_ww_bad', '2\n-W\nW-\n'),
            ('n3_all_draw', '3\n-DD\nD-D\nDD-\n'),
            ('n3_cycle', '3\n-WL\nL-W\nWL-\n'),
            ('n3_bad', '3\n-WD\nW-D\nDD-\n'),
            ('n4_valid', _table(4)),
            ('n4_bad', _table(4, bad=(0, 3))),
            ('n5_valid', _table(5)),
            ('n5_bad', _table(5, bad=(1, 4))),
            ('n6_valid', _table(6)),
            ('n10_valid', _table(10)),
            ('n20_bad', _table(20, bad=(3, 17))),
            ('n50_valid', _table(50)),
            ('n100_bad', _table(100, bad=(7, 91))),
            ('n200_valid', _table(200)),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', _table(1000))
    else:
        custom = [
            ('n3_path', _graph(3, [(1, 2), (2, 3)])),
            ('n3_complete', _graph(3, [(1, 2), (1, 3), (2, 3)])),
            ('n4_path', _graph(4, [(1, 2), (2, 3), (3, 4)])),
            ('n4_one_triangle', _graph(4, [(1, 2), (1, 3), (2, 3), (3, 4)])),
            ('n4_complete', _graph(4, [(i, j) for i in range(1, 5) for j in range(i + 1, 5)])),
            ('n5_cycle', _graph(5, [(1, 2), (2, 3), (3, 4), (4, 5), (1, 5)])),
            ('n5_two_shared', _graph(5, [(1, 2), (1, 3), (2, 3), (1, 4), (2, 4), (4, 5)])),
            ('n6_disjoint_triangles', _graph(6, [(1, 2), (1, 3), (2, 3), (4, 5), (4, 6), (5, 6)])),
            ('n6_bipartite', _graph(6, [(i, j) for i in (1, 2, 3) for j in (4, 5, 6)])),
            ('n7_clique4', _graph(7, [(i, j) for i in range(1, 5) for j in range(i + 1, 5)] + [(4, 5), (5, 6), (6, 7)])),
            ('n10_sparse', _graph(10, [(i, i + 1) for i in range(1, 10)] + [(1, 3), (3, 5), (5, 7), (7, 9)])),
            ('n20_pattern', _graph(20, [(i, j) for i in range(1, 21) for j in range(i + 1, 21) if (i * 7 + j * 11) % 13 == 0])),
            ('n50_clique10', _graph(50, [(i, j) for i in range(1, 11) for j in range(i + 1, 11)] + [(i, i + 1) for i in range(10, 50)])),
            ('n100_sparse', _graph(100, [(i, i + 1) for i in range(1, 100)] + [(i, i + 2) for i in range(1, 99, 3)])),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', _graph(100, [(i, j) for i in range(1, 101) for j in range(i + 1, 101)]))

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending in constraint_max, got {len(out)}')
    return out
