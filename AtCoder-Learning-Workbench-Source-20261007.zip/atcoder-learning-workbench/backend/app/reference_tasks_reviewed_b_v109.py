"""ABC185–187 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc185_b','abc186_b','abc187_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NONNEG=re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
SIGNED=re.compile(r'(?:0|-?[1-9][0-9]*)',re.ASCII)

PUBLISHED_SAMPLES={
 'abc185_b':[
  {'input':'10 2 20\n9 11\n13 17\n','expected':'Yes\n'},
  {'input':'10 2 20\n9 11\n13 16\n','expected':'No\n'},
  {'input':'15 3 30\n5 8\n15 17\n24 27\n','expected':'Yes\n'},
  {'input':'20 1 30\n20 29\n','expected':'No\n'},
  {'input':'20 1 30\n1 10\n','expected':'No\n'},
 ],
 'abc186_b':[
  {'input':'2 3\n2 2 3\n3 2 2\n','expected':'2\n'},
  {'input':'3 3\n99 99 99\n99 0 99\n99 99 99\n','expected':'792\n'},
  {'input':'3 2\n4 4\n4 4\n4 4\n','expected':'0\n'},
 ],
 'abc187_b':[
  {'input':'3\n0 0\n1 2\n2 1\n','expected':'2\n'},
  {'input':'1\n-691 273\n','expected':'0\n'},
  {'input':'10\n-31 -35\n8 -36\n22 64\n5 73\n-14 8\n18 -58\n-41 -85\n1 -88\n-21 -85\n-11 82\n','expected':'11\n'},
 ],
}

def _ints(line:str,count:int,pattern:re.Pattern[str])->list[int]:
    p=line.split(' ')
    if len(p)!=count or any(pattern.fullmatch(x) is None for x in p): raise ValueError('noncanonical integer row')
    return list(map(int,p))

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc185_b':
        if not lines: raise ValueError('missing header')
        n,m,t=_ints(lines[0],3,POS)
        if not 1<=n<=10**9 or not 1<=m<=1000 or not 1<=t<=10**9 or len(lines)!=m+1: raise ValueError('range/line count')
        cafes=[]; prev=0
        for line in lines[1:]:
            a,b=_ints(line,2,POS)
            if not (prev<a<b<t): raise ValueError('cafe ordering')
            cafes.append((a,b)); prev=b
        return n,t,cafes
    if pid=='abc186_b':
        if not lines: raise ValueError('missing header')
        h,w=_ints(lines[0],2,POS)
        if not 1<=h<=100 or not 1<=w<=100 or len(lines)!=h+1: raise ValueError('shape/range')
        grid=[]
        for line in lines[1:]:
            row=_ints(line,w,NONNEG)
            if any(x>100 for x in row): raise ValueError('A range')
            grid.append(row)
        return grid
    if not lines or POS.fullmatch(lines[0]) is None: raise ValueError('expected N')
    n=int(lines[0])
    if not 1<=n<=1000 or len(lines)!=n+1: raise ValueError('N/line count')
    pts=[]; xs=set()
    for line in lines[1:]:
        x,y=_ints(line,2,SIGNED)
        if not (-1000<=x<=1000 and -1000<=y<=1000) or x in xs: raise ValueError('point range/distinct x')
        xs.add(x); pts.append((x,y))
    return pts

def _ans185(v)->str:
    n,t,cafes=v; cur=n; prev=0
    for a,b in cafes:
        cur-=a-prev
        if cur<=0: return 'No'
        cur=min(n,cur+(b-a)); prev=b
    cur-=t-prev
    return 'Yes' if cur>0 else 'No'

def _ans186(g)->int:
    mn=min(map(min,g)); return sum(x-mn for row in g for x in row)

def _ans187(pts)->int:
    ans=0
    for i in range(len(pts)):
        x1,y1=pts[i]
        for j in range(i+1,len(pts)):
            x2,y2=pts[j]
            if abs(y2-y1)<=abs(x2-x1): ans+=1
    return ans

def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or output!=output.strip() or '\n' in output: return False
    if pid=='abc185_b': return output in ('Yes','No') and output==_ans185(v)
    if NONNEG.fullmatch(output) is None: return False
    return int(output)==(_ans186(v) if pid=='abc186_b' else _ans187(v))

def _185(n,t,cafes): return f'{n} {len(cafes)} {t}\n'+''.join(f'{a} {b}\n' for a,b in cafes)
def _186(g): return f'{len(g)} {len(g[0])}\n'+''.join(' '.join(map(str,row))+'\n' for row in g)
def _187(pts): return f'{len(pts)}\n'+''.join(f'{x} {y}\n' for x,y in pts)

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc185_b':
        cases=[
         ('sample1',10,20,[(9,11),(13,17)]),('sample2',10,20,[(9,11),(13,16)]),('sample3',15,30,[(5,8),(15,17),(24,27)]),
         ('sample4',20,30,[(20,29)]),('sample5',20,30,[(1,10)]),('minimum',1,3,[(1,2)]),
         ('zero_at_first_cafe',5,10,[(5,6)]),('one_left_at_first_cafe',5,10,[(4,6)]),('full_cap_matters',3,10,[(1,8)]),
         ('exact_zero_home',5,9,[(2,4)]),('one_left_home',5,8,[(2,4)]),('many_short',10,25,[(2,3),(5,6),(8,9),(11,12),(14,15)]),
         ('recharge_to_full',6,20,[(3,12),(15,18)]),('late_failure',20,50,[(2,19),(25,30)]),('large_values',10**9,10**9,[(1,999999999)]),
         ('m50',100,500,[(2+8*i,5+8*i) for i in range(50)]),('m200',1000,5000,[(2+20*i,10+20*i) for i in range(200)]),
        ]
        for c,n,t,cs in cases:add(c,_185(n,t,cs))
        add('constraint_max',_185(10**9,10**9,[(2*i+1,2*i+2) for i in range(1000)]))
    elif pid=='abc186_b':
        cases=[
         ('sample1',[[2,2,3],[3,2,2]]),('sample2',[[99,99,99],[99,0,99],[99,99,99]]),('sample3',[[4,4],[4,4],[4,4]]),
         ('one_zero',[[0]]),('one_hundred',[[100]]),('row',[ [0,1,2,3,4] ]),('col',[[5],[4],[3],[2],[1]]),
         ('two_by_two',[[1,2],[3,4]]),('all_zero',[[0]*7 for _ in range(5)]),('all_100',[[100]*8 for _ in range(6)]),
         ('single_min',[[50]*10 for _ in range(10)]),('checker',[[0 if (i+j)%2==0 else 100 for j in range(10)] for i in range(10)]),
         ('gradient',[[i+j for j in range(20)] for i in range(20)]),('h100_w1',[[i%101] for i in range(100)]),('h1_w100',[[i%101 for i in range(100)]]),
         ('medium_uniform',[[73]*50 for _ in range(40)]),('medium_one_low',[[0 if (i,j)==(20,30) else 100 for j in range(60)] for i in range(50)]),
        ]
        for c,g in cases:add(c,_186(g))
        g=[[100]*100 for _ in range(100)]; g[0][0]=0; add('constraint_max',_186(g))
    else:
        cases=[
         ('sample1',[(0,0),(1,2),(2,1)]),('sample2',[(-691,273)]),('sample3',[(-31,-35),(8,-36),(22,64),(5,73),(-14,8),(18,-58),(-41,-85),(1,-88),(-21,-85),(-11,82)]),
         ('two_slope_zero',[(-1,5),(1,5)]),('slope_plus_one',[(0,0),(5,5)]),('slope_minus_one',[(0,5),(5,0)]),('too_steep',[(0,0),(1,2)]),
         ('negative_dx_order',[(10,0),(-10,5)]),('all_horizontal',[(i,0) for i in range(-5,6)]),('diagonal_plus',[(i,i) for i in range(-10,11)]),
         ('diagonal_minus',[(i,-i) for i in range(-10,11)]),('mixed_small',[(-3,7),(-1,-2),(2,1),(5,8),(9,0)]),
         ('x_extremes',[(-1000,-1000),(1000,1000)]),('y_extremes',[(-1000,-1000),(1000,1000),(0,-999)]),
         ('n100',[(-500+i,(i*37)%2001-1000) for i in range(100)]),('n500_horizontal',[(-1000+4*i,123) for i in range(500)]),
         ('n999_pattern',[(-999+2*i,((i*97)%2001)-1000) for i in range(999)]),
        ]
        for c,p in cases:add(c,_187(p))
        add('constraint_max',_187([(-1000+2*i,0) for i in range(1000)]))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
