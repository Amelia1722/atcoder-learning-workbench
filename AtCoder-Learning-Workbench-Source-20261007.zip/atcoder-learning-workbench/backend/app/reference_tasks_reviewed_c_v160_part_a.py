"""Six new C tasks: score DP, negative-base intervals, factors, subset partitions."""
from __future__ import annotations
from itertools import product
from math import gcd
from functools import reduce
from typing import cast
import random,re

TASKS=('abc104_c','abc105_c','abc118_c','abc119_c','abc120_c','abc134_c')
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES:dict[str,str]={}
Data=tuple[object,...]
Case=dict[str,str]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    result=tuple(map(int,row.split(' ')));require(count is None or len(result)==count,'fields');return result

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==104:
        d,g=ints(rows[0],2);require(1<=d<=10 and g>=100 and g%100==0 and len(rows)==d+1,'score shape')
        groups=tuple(cast(tuple[int,int],ints(r,2)) for r in rows[1:])
        require(all(1<=p<=100 and 100<=c<=10**6 and c%100==0 for p,c in groups),'groups')
        require(sum((j+1)*100*p+c for j,(p,c) in enumerate(groups))>=g,'attainable');return g,groups
    if number==105:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(-10**9<=n<=10**9,'number');return (n,)
    if number==118:
        n=ints(rows[0],1)[0];require(2<=n<=100000 and len(rows)==2,'shape');a=ints(rows[1],n)
        require(all(1<=v<=10**9 for v in a),'health');return (a,)
    if number==119:
        n,a,b,c=ints(rows[0],4);require(3<=n<=8 and 1<=c<b<a<=1000 and len(rows)==n+1,'shape')
        lengths=tuple(ints(r,1)[0] for r in rows[1:]);require(all(1<=v<=1000 for v in lengths),'bamboo');return (a,b,c),lengths
    if number==120:
        require(len(rows)==1 and re.fullmatch('[01]{1,100000}',rows[0]) is not None,'binary cubes');return (rows[0],)
    n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==n+1,'shape')
    a=tuple(ints(r,1)[0] for r in rows[1:]);require(all(1<=v<=200000 for v in a),'values');return (a,)

def _score_dp(g:int,groups:tuple[tuple[int,int],...])->int:
    # At an exact problem count retain the greatest achievable score.
    dp=[0]
    for index,(p,c) in enumerate(groups,1):
        following=[-1]*(len(dp)+p)
        for count,score in enumerate(dp):
            if score<0:continue
            for take in range(p+1):following[count+take]=max(following[count+take],score+100*index*take+(c if take==p else 0))
        dp=following
    return next(count for count,score in enumerate(dp) if score>=g)

def _negative_base_interval(n:int)->str:
    if n==0:return '0'
    powers=[1];minimum=[0];maximum=[0]
    while not minimum[-1]<=n<=maximum[-1]:
        value=powers[-1];minimum.append(minimum[-1]+min(value,0));maximum.append(maximum[-1]+max(value,0));powers.append(value*-2)
    width=len(minimum)-1;digits=[];remaining=n
    for j in range(width-1,-1,-1):
        if minimum[j]<=remaining<=maximum[j]:digits.append('0')
        else:
            remaining-=powers[j];require(minimum[j]<=remaining<=maximum[j],'representable remainder');digits.append('1')
    require(remaining==0 and digits[0]=='1','unique representation');return ''.join(digits)

def _common_factors(values:tuple[int,...])->int:
    first=values[0];factors=[];p=2
    while p*p<=first:
        if first%p==0:
            power=1
            while first%p==0:first//=p;power*=p
            factors.append((p,power))
        p=3 if p==2 else p+2
    if first>1:factors.append((first,first))
    result=1
    for p,power in factors:
        while power>1 and any(v%power for v in values):power//=p
        result*=power
    return result

def _bamboo_partition(targets:tuple[int,int,int],lengths:tuple[int,...])->int:
    limit=1<<len(lengths);sums=[0]*limit
    for mask in range(1,limit):bit=mask&-mask;sums[mask]=sums[mask^bit]+lengths[bit.bit_length()-1]
    dp={0:0};full=limit-1
    for target in targets:
        following:dict[int,int]={}
        for used,cost in dp.items():
            remaining=full^used;subset=remaining
            while subset:
                merged=used|subset;value=cost+10*(subset.bit_count()-1)+abs(sums[subset]-target)
                following[merged]=min(following.get(merged,10**9),value);subset=(subset-1)&remaining
        dp=following
    return min(dp.values())

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==104:return str(_score_dp(*cast(tuple[int,tuple[tuple[int,int],...]],data)))
    if number==105:return _negative_base_interval(cast(int,data[0]))
    if number==118:return str(_common_factors(cast(tuple[int,...],data[0])))
    if number==119:return str(_bamboo_partition(*cast(tuple[tuple[int,int,int],tuple[int,...]],data)))
    if number==120:
        s=cast(str,data[0]);stack:list[str]=[];removed=0
        for c in s:
            if stack and stack[-1]!=c:stack.pop();removed+=2
            else:stack.append(c)
        return str(removed)
    a=cast(tuple[int,...],data[0]);prefix=[0]
    for v in a:prefix.append(max(prefix[-1],v))
    suffix=[0]*(len(a)+1)
    for j in range(len(a)-1,-1,-1):suffix[j]=max(suffix[j+1],a[j])
    return '\n'.join(str(max(prefix[j],suffix[j+1])) for j in range(len(a)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc104_c':'''d,g=map(int,input().split());groups=[tuple(map(int,input().split())) for _ in range(d)];answer=sum(p for p,c in groups)
for mask in range(1<<d):
 score=sum((100*(j+1)*p+c) for j,(p,c) in enumerate(groups) if mask>>j&1);count=sum(p for j,(p,c) in enumerate(groups) if mask>>j&1)
 if score<g:
  for j in range(d-1,-1,-1):
   if not mask>>j&1:
    take=min(groups[j][0]-1,(g-score+100*(j+1)-1)//(100*(j+1)));count+=take;score+=take*100*(j+1);break
 if score>=g:answer=min(answer,count)
print(answer)
''',
'abc105_c':'''n=int(input());digits=[]
while n:
 n,r=divmod(n,-2)
 if r<0:n+=1;r+=2
 digits.append(str(r))
print(''.join(digits[::-1]) or '0')
''',
'abc118_c':'''from math import gcd
from functools import reduce
n=int(input());a=list(map(int,input().split()));print(reduce(gcd,a))
''',
'abc119_c':'''from itertools import product
n,a,b,c=map(int,input().split());lengths=[int(input()) for _ in range(n)];answer=10**9
for choices in product(range(4),repeat=n):
 sums=[0,0,0];counts=[0,0,0]
 for length,group in zip(lengths,choices):
  if group<3:sums[group]+=length;counts[group]+=1
 if min(counts)>0:answer=min(answer,sum(abs(x-y) for x,y in zip(sums,(a,b,c)))+10*(sum(counts)-3))
print(answer)
''',
'abc120_c':'''s=input();print(2*min(s.count('0'),s.count('1')))
''',
'abc134_c':'''n=int(input());a=[int(input()) for _ in range(n)];s=sorted(a)
for value in a:print(s[-2] if value==s[-1] else s[-1])
'''}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16000+number)
    if number==104:
        def scores(g:int,groups:list[tuple[int,int]])->str:return f'{len(groups)} {g}\n'+''.join(line(group) for group in groups)
        raws=[scores(100,[(1,100)]),scores(200,[(1,100)]),scores(10000,[(100,100)]),scores(10100,[(100,100)])]
        for j in range(1,14):
            d=1+j%5;groups=[(1+(j+k)%8,100*(1+(j*3+k)%20)) for k in range(d)];total=sum(100*(k+1)*p+c for k,(p,c) in enumerate(groups));raws.append(scores(100*(1+(j*7)%(total//100)),groups))
        raws.append(scores(10550000,[(100,1000000)]*10))
    elif number==105:raws=[f'{v}\n' for v in (0,1,-1,2,-2,3,-3,4,-4,7,-7,8,-8,123456789,-123456789,999999999,-1000000000,1000000000)]
    elif number==118:
        def monsters(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[monsters([1,1]),monsters([2,3]),monsters([6,10,15]),monsters([10**9,999999937])]+[monsters([rng.randrange(1,1001)*(j%5+1) for _ in range(j+2)]) for j in range(1,14)]+[monsters([10**9]*100000)]
    elif number==119:
        def bamboo(target:tuple[int,int,int],a:list[int])->str:return f'{len(a)} '+line(target)+''.join(f'{v}\n' for v in a)
        raws=[bamboo((3,2,1),[1,1,1]),bamboo((3,2,1),[3,2,1]),bamboo((1000,999,998),[1,1,1]),bamboo((100,90,80),[40,40,40,90,100])]
        for j in range(1,14):raws.append(bamboo((10+j*7,7+j*4,1+j),[rng.randrange(1,101) for _ in range(3+j%6)]))
        raws.append(bamboo((1000,999,998),[1000]*8))
    elif number==120:raws=['0\n','1\n','01\n','10\n']+[''.join(rng.choice('01') for _ in range(n))+'\n' for n in range(3,16)]+['0'*50000+'1'*50000+'\n']
    else:
        def values(a:list[int])->str:return f'{len(a)}\n'+''.join(f'{v}\n' for v in a)
        raws=[values([1,1]),values([1,200000]),values([200000,1]),values([200000,200000])]+[values([rng.randrange(1,200001) for _ in range(n)]) for n in range(3,16)]+[values(list(range(1,200001)))]
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc104_c':('各得点帯の全問を解いたかどうかを考えます。','全問完了する得点帯の集合を全列挙し、まだ点が足りないときは残った最高得点帯から必要数を解きます。','疑似コード: for complete_mask: score=sum(full_score+bonus); count=sum(full_count); if score<G: choose highest incomplete group, take=min(p-1,ceil((G-score)/value)); if score>=G: answer=min(answer,count)。'),
'abc105_c':('負の基数でも、次の桁は0か1です。','-2で割った余りが負なら、余りに2を足して商に1を足します。','疑似コード: digits=[]; while N!=0: q,r=divmod(N,-2); if r<0: q+=1;r+=2; digits.append(r); N=q; print(reverse(digits))。N=0なら0。'),
'abc118_c':('攻撃で体力が減っても、全体の最大公約数は変わりません。','最小の最終体力は、すべての体力の最大公約数です。','疑似コード: answer=A[0]; for value in A[1:]: answer=gcd(answer,value); print(answer)。'),
'abc119_c':('各竹は、3種類の材料か不使用のどれかに割り当てます。','4^N通りを全列挙し、各種類を最低1本使う条件と、結合コスト・長さ調整コストを計算します。','疑似コード: for assignments in {A,B,C,unused}^N: if all three groups nonempty: cost=sum(abs(group_length-target))+10*(used_count-3); answer=min(answer,cost)。'),
'abc120_c':('1回の操作で0と1を一つずつ消します。','両方の色が残っていれば境界に異色の隣接があるので、少ない方の個数分だけ必ず操作できます。','疑似コード: zeros=count(0); ones=count(1); print(2*min(zeros,ones))。'),
'abc134_c':('削除した値が最大値だった場合だけ、次に大きい値が必要です。','配列をソートして最大値と2番目を保存します。最大値が複数あるときもこの方法で扱えます。','疑似コード: sorted=sort(A); for value in A: print(sorted[-2] if value==sorted[-1] else sorted[-1])。')}

TITLES={'abc104_c': 'All Green', 'abc105_c': 'Base -2 Number', 'abc118_c': 'Monsters Battle Royale', 'abc119_c': 'Synthetic Kadomatsu', 'abc120_c': 'Unification', 'abc134_c': 'Exception Handling'}
PUBLISHED_SAMPLES={'abc104_c': [{'input': '2 700\n3 500\n5 800\n', 'expected': '3\n'}, {'input': '2 2000\n3 500\n5 800\n', 'expected': '7\n'}, {'input': '2 400\n3 500\n5 800\n', 'expected': '2\n'}, {'input': '5 25000\n20 1000\n40 1000\n50 1000\n30 1000\n1 1000\n', 'expected': '66\n'}], 'abc105_c': [{'input': '-9\n', 'expected': '1011\n'}, {'input': '123456789\n', 'expected': '11000101011001101110100010101\n'}, {'input': '0\n', 'expected': '0\n'}], 'abc118_c': [{'input': '4\n2 10 8 40\n', 'expected': '2\n'}, {'input': '4\n5 13 8 1000000000\n', 'expected': '1\n'}, {'input': '3\n1000000000 1000000000 1000000000\n', 'expected': '1000000000\n'}], 'abc119_c': [{'input': '5 100 90 80\n98\n40\n30\n21\n80\n', 'expected': '23\n'}, {'input': '8 100 90 80\n100\n100\n90\n90\n90\n80\n80\n80\n', 'expected': '0\n'}, {'input': '8 1000 800 100\n300\n333\n400\n444\n500\n555\n600\n666\n', 'expected': '243\n'}], 'abc120_c': [{'input': '0011\n', 'expected': '4\n'}, {'input': '11011010001011\n', 'expected': '12\n'}, {'input': '0\n', 'expected': '0\n'}], 'abc134_c': [{'input': '3\n1\n4\n3\n', 'expected': '4\n3\n4\n'}, {'input': '2\n5\n5\n', 'expected': '5\n5\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
