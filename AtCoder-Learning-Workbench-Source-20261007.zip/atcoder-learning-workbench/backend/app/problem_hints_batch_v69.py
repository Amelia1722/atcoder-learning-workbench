"""Hints based on the public official statements of ABC065–067 B."""
HINTS_V69 = {
    'abc065_b': (
        '光っているボタンは常に1個です。今どの番号が光っているかだけを追えば十分です。',
        'ボタン1からa_iへの遷移を順にたどります。2に着く前に同じボタンへ戻ったら、その後も同じ周期を繰り返すので到達不能です。',
        '''疑似コード:
current=1; seen=set(); count=0
while current not in seen:
  if current==2: print(count); stop
  seen.add(current)
  current=a[current]
  count+=1
print(-1)''',
    ),
    'abc066_b': (
        '末尾から1文字以上消す必要があります。残した長さについて、前半と後半が同じかを調べてください。',
        '元の長さより短い候補を長い順に調べ、偶数長だけについて前半と後半を比較します。最初に一致した長さが最大です。',
        '''疑似コード:
for length=len(S)-1 down to 2:
  if length is odd: continue
  half=length//2
  if S[:half]==S[half:length]:
    print(length); stop''',
    ),
    'abc067_b': (
        'ちょうどK本を選び、合計だけを最大にします。選ぶ順序は答えに影響しません。',
        '棒の長さを大きい順に並べ、先頭K本を選べば合計が最大になります。',
        '''疑似コード:
L=sort_descending(L)
print(sum(L[0:K]))''',
    ),
}
