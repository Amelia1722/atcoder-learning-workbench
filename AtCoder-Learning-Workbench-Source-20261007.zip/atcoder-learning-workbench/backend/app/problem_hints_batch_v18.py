"""ABC117–120 A/B hand-curated three-stage hints; stage 1 avoids algorithm names."""
HINTS_V18 = {
 'abc117_a': (
  '同じ時間でも、二つの世界では流れる速さが違います。どちらの世界の時間を求めるか整理しましょう。',
  '世界Bでの時間Tを、時間の進む倍率Xで割ると世界Aで経過する時間です。小数の割り算を使います。',
  '疑似コード:\nT, X = read_two_integers()\nanswer = T / X\nprint(answer)'),
 'abc117_b': (
  '一本だけ長い辺があると、残りの辺をつなげても形を閉じられないことがあります。',
  '最大の辺と、それ以外の辺の合計を比較します。最大辺が残りの合計より真に短いかが条件です。',
  '疑似コード:\nN = read_integer()\nL = read_integer_array()\nlongest = max(L)\nif longest < sum(L)-longest: print("Yes")\nelse: print("No")'),
 'abc118_a': (
  '二つの整数の関係を調べ、条件によって実行する計算を切り替えましょう。',
  'BをAで割った余りが0ならAはBの約数です。条件に応じて和か差を出力します。',
  '疑似コード:\nA,B = read_two_integers()\nif B % A == 0: print(A+B)\nelse: print(B-A)'),
 'abc118_b': (
  '各人の好みをひとつずつ比べて、最後まで全員に共通する種類だけを残しましょう。',
  'setの積集合を人ごとに取り続けます。最初は1からMまで全種類を候補にします。',
  '疑似コード:\ncommon = set(1..M)\nrepeat N times:\n  K, liked = read_foods()\n  common = common ∩ set(liked)\nprint(len(common))'),
 'abc119_a': (
  '二つの時期を分ける境目の日付に注目し、入力がどちら側か調べましょう。',
  'yyyy/mm/ddのゼロ埋め形式は文字列の辞書順が日付順と一致します。2019/04/30との大小を比較します。',
  '疑似コード:\nS = read_string()\nif S <= "2019/04/30": print("Heisei")\nelse: print("TBD")'),
 'abc119_b': (
  '単位が違う金額は、そのまま合計できません。先に同じ単位へそろえましょう。',
  'JPYはそのまま、BTCは380000倍して円へ換算し、全員の円換算額を合計します。',
  '疑似コード:\ntotal = 0\nrepeat N times:\n  amount, unit = read_amount_and_unit()\n  if unit == "BTC": total += amount * 380000\n  else: total += amount\nprint(total)'),
 'abc120_a': (
  '手持ちの金額でできる最大回数と、満足するまでの回数を両方考えてください。',
  '金額Bで買える回数はB//Aです。上限Cがあるので二つのうち小さい方を選びます。',
  '疑似コード:\nA,B,C = read_three_integers()\nprint(min(B//A,C))'),
 'abc120_b': (
  '候補は大きいものから並べると、求める順位のものを見つけやすくなります。',
  'AとBの両方の約数を大きい順に調べ、見つけた個数がKに達したものを答えます。',
  '疑似コード:\nA,B,K = read_three_integers()\nfor d in range(min(A,B),0,-1):\n  if A%d==0 and B%d==0:\n    K -= 1\n    if K==0: print(d); break'),
}
