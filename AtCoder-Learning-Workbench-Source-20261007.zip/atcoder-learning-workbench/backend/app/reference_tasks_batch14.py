"""ABC121–124 C: original implementations, strict official input shapes, independent checks."""
from __future__ import annotations

from bisect import bisect_left, bisect_right
import heapq
from random import Random
import re

SAMPLES = {
 'abc121_c': ('2 5\n4 9\n2 4\n','12','1<=N,M<=100000; 1<=Ai<=1e9; 1<=Bi<=100000; sum(Bi)>=M'),
 'abc122_c': ('8 3\nACACTACG\n3 7\n2 3\n1 8\n','2\n0\n3','2<=N<=100000; 1<=Q<=100000; S in ACGT^N; 1<=li<ri<=N'),
 'abc123_c': ('5\n3\n2\n4\n3\n5\n','7','1<=N,A,B,C,D,E<=10^15'),
 'abc124_c': ('000\n','1','1<=len(S)<=100000; S contains only 0,1'),
}
BATCH14 = {pid: {'sample_input': inp,'sample_output': out,
                'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                'constraints': constraints} for pid,(inp,out,constraints) in SAMPLES.items()}
_POS = re.compile(r'[1-9][0-9]*\Z')


def _posints(tokens: list[str], count: int | None = None) -> list[int]:
    if not tokens or (count is not None and len(tokens)!=count) or any(_POS.fullmatch(t) is None for t in tokens):
        raise ValueError('positive integer count/format mismatch')
    return list(map(int,tokens))


def validate(pid: str, data: str):
    if pid not in BATCH14:raise ValueError('unknown task')
    if pid=='abc124_c':
        t=data.split()
        if len(t)!=1 or re.fullmatch('[01]{1,100000}',t[0]) is None:
            raise ValueError('binary string length/content invalid')
        return t[0]
    if pid=='abc123_c':
        x=_posints(data.split(),6)
        if any(z>10**15 for z in x):raise ValueError('transport bound')
        return tuple(x)
    lines=data.strip().splitlines()
    if len(lines)<2:raise ValueError('missing input rows')
    n,m=_posints(lines[0].split(),2)
    if pid=='abc121_c':
        if not 1<=n<=100000 or not 1<=m<=100000 or len(lines)!=n+1:
            raise ValueError('store header/row count invalid')
        shops=[];stock=0
        for line in lines[1:]:
            a,b=_posints(line.split(),2)
            if not 1<=a<=10**9 or not 1<=b<=100000:raise ValueError('store price/stock out of range')
            shops.append((a,b));stock+=b
        if stock<m:raise ValueError('total stock insufficient')
        return n,m,shops
    if not 2<=n<=100000 or not 1<=m<=100000 or len(lines)!=m+2:
        raise ValueError('N/Q/row count invalid')
    s=lines[1]
    if len(s)!=n or re.fullmatch('[ACGT]+',s) is None:raise ValueError('DNA length/content invalid')
    queries=[]
    for line in lines[2:]:
        l,r=_posints(line.split(),2)
        if not 1<=l<r<=n:raise ValueError('query index out of range or not strict')
        queries.append((l,r))
    return n,m,s,queries


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str,str]]:
    if pid not in BATCH14 or not 1<=count<=80:raise ValueError('unknown task or invalid count')
    rnd=Random(seed); cases=[];seen=set()
    def add(category:str, content:str):
        validate(pid,content)
        if content not in seen:
            seen.add(content);cases.append({'category':category,'input':content})
    if pid=='abc121_c':
        def shops(kind,m,items):
            add(kind,f'{len(items)} {m}\n'+'\n'.join(f'{a} {b}' for a,b in items)+'\n')
        shops('sample',5,[(4,9),(2,4)])
        shops('constraint_min',1,[(1,1)])
        shops('max_cost',100000,[(10**9,100000)])
        shops('one_shop',100000,[(1,100000)])
        shops('all_same_price',12,[(3,4),(3,4),(3,4)])
        shops('one_cheap',10,[(10**9,100000),(1,1)])
        shops('exact_stock',3,[(6,1),(2,1),(3,1)])
        shops('multiple_stores',30,[(6,18),(2,5),(3,10),(7,9)])
        shops('reversed_sorted',5,[(9,2),(8,1),(1,2)])
        shops('huge_stock',1,[(10**9,100000)])
        while len(cases)<count:
            n=rnd.randint(1,30);m=rnd.randint(1,100000)
            items=[(rnd.randint(1,10**9),rnd.randint(1,100000)) for _ in range(n)]
            if sum(b for _,b in items)<m:items[0]=(items[0][0],100000)
            shops('random',m,items)
        maximum='100000 100000\n'+'\n'.join(f'{1+(i*7919)%1000000000} 1' for i in range(100000))+'\n'
    elif pid=='abc122_c':
        def dna(kind,s,qs):
            add(kind,f'{len(s)} {len(qs)}\n{s}\n'+'\n'.join(f'{l} {r}' for l,r in qs)+'\n')
        dna('sample','ACACTACG',[(3,7),(2,3),(1,8)])
        dna('constraint_min','AC',[(1,2)])
        dna('one_not_ac','CA',[(1,2)])
        dna('all_a','A'*20,[(1,20),(1,2),(19,20)])
        dna('all_c','C'*20,[(1,20),(2,3)])
        dna('alternating','AC'*20,[(1,40),(2,40),(1,39),(2,3)])
        dna('boundary_cross','AAC',[(1,2),(2,3),(1,3)])
        dna('long_n_short_q','AC'*50000,[(1,2),(99999,100000)])
        dna('no_pairs','GT'*20,[(1,40)])
        dna('overlap','ACACAC',[(1,6),(2,5),(3,6)])
        while len(cases)<count:
            n=rnd.randint(2,50);s=''.join(rnd.choices('ACGT',k=n))
            q=rnd.randint(1,35)
            qs=[]
            for _ in range(q):
                l=rnd.randint(1,n-1);r=rnd.randint(l+1,n);qs.append((l,r))
            dna('random',s,qs)
        s='AC'*50000
        queries='\n'.join(f'{1+i%99999} 100000' for i in range(100000))
        maximum=f'100000 100000\n{s}\n{queries}\n'
    elif pid=='abc123_c':
        def transport(kind, nums):add(kind,'\n'.join(map(str,nums))+'\n')
        upper=10**15
        for args in ((1,1,1,1,1,1),(upper,upper,upper,upper,upper,upper),
                     (upper,1,upper,upper,upper,upper),(upper,upper,1,upper,upper,upper),
                     (upper,upper,upper,upper,upper,1),(5,3,2,4,3,5),
                     (10,123,123,123,123,123),(10000000007,2,3,5,7,11),
                     (upper,1,1,1,1,1),(upper,upper,upper,upper,upper,1),
                     (1,upper,upper,upper,upper,upper),(11,3,3,3,3,3)):
            transport('boundary',args)
        while len(cases)<count:
            transport('random',[rnd.randint(1,10**15) for _ in range(6)])
        maximum='\n'.join([str(10**15)]*6)+'\n'
    else:
        for s in ('0','1','00','11','01','10','000','10010010','0'*100000,
                  '1'*100000,'01'*50000,'10'*50000,'0'*99999+'1',
                  '1'+'0'*99999,'00110011','01010101010'):
            add('boundary',s+'\n')
        while len(cases)<count:
            s=''.join(rnd.choices('01',k=rnd.randint(1,100)))
            add('random',s+'\n')
        maximum='1'*100000+'\n'
    if include_large:
        cases=[x for x in cases if x['input']!=maximum]
        seen.discard(maximum)
        add('constraint_max',maximum)
    return cases[:count]+([c for c in cases[count:] if c['category']=='constraint_max'] if include_large else [])


def independent_check(pid: str, data: str, expected: str) -> bool:
    args=validate(pid,data)
    if pid=='abc121_c':
        _,m,shops=args
        heap=list(shops);heapq.heapify(heap);paid=0
        while m:
            price,stock=heapq.heappop(heap)
            x=min(m,stock);paid+=x*price;m-=x
        return expected.strip()==str(paid)
    if pid=='abc122_c':
        _,q,s,queries=args
        positions=[i+1 for i in range(len(s)-1) if s[i:i+2]=='AC']
        lines=expected.split()
        if len(lines)!=q:return False
        return all(re.fullmatch('[0-9]+',x) is not None and
                   int(x)==bisect_right(positions,r-1)-bisect_left(positions,l)
                   for (l,r),x in zip(queries,lines))
    if pid=='abc123_c':
        n,*capacity=args
        if n<=60:
            cities=[n,0,0,0,0,0]
            for minute in range(1,90):
                # Move east to west: newcomers must wait until next minute.
                for i in range(4,-1,-1):
                    moved=min(cities[i],capacity[i])
                    cities[i]-=moved
                    cities[i+1]+=moved
                if cities[5]==n:return expected.strip()==str(minute)
            return False
        return expected.strip()==str((n+min(capacity)-1)//min(capacity)+4)
    s=args
    # Independent dynamic program for minimum repainting with alternating colors.
    dp0=0 if s[0]=='0' else 1
    dp1=0 if s[0]=='1' else 1
    for ch in s[1:]:
        dp0,dp1=dp1+(ch!='0'),dp0+(ch!='1')
    return expected.strip()==str(min(dp0,dp1))
