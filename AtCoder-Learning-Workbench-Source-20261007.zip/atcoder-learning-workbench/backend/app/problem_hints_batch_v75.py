"""Hints based on the public official statements of ABC083–085 B."""
HINTS_V75 = {
    'abc083_b': (
        '1からNまでの各整数を調べても、Nは最大1万です。各整数について条件を直接確認できます。',
        '各整数xの10進法での桁和を求め、A以上B以下なら答えへxを加えます。',
        '''疑似コード:\nans = 0\nfor x = 1 .. N:\n  s = digit_sum(x)\n  if A <= s <= B: ans += x\nprint(ans)''',
    ),
    'abc084_b': (
        '郵便番号でハイフンが置かれる位置は1か所だけです。その前後に何が必要か確認してください。',
        '0-indexedではS[A]がハイフンで、S[:A]とS[A+1:]がすべて数字ならYesです。',
        '''疑似コード:\nif S[A] == "-" and S[0:A] is all digits and S[A+1:] is all digits:\n  print("Yes")\nelse:\n  print("No")''',
    ),
    'abc085_b': (
        '同じ直径の餅は、上下に重ねると「上が下より小さい」という条件を満たせません。',
        '使える段数は異なる直径の種類数そのものです。setで重複を取り除いて数えられます。',
        '''疑似コード:\ndiameters = read N values\nprint(len(set(diameters)))''',
    ),
}
