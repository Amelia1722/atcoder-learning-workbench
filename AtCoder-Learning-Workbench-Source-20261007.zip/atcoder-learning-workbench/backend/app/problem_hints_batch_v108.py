"""Statement-checked three-stage hints for ABC182–184 B."""
HINTS_V108 = {
    'abc182_b': (
        'kの候補を難しく絞る必要はありません。A_iは最大1000なので、2から1000まで全部試して「何個割り切れるか」を数えられます。',
        '各kについてA全体を走査し、A_i % k == 0の個数を数えます。その個数が最大になったkを保持します。N<=100なのでO(1000N)で十分です。最大が同率ならどれを出しても構いません。',
        '疑似コード:\nbest_k = 2\nbest_count = -1\nfor k = 2..1000:\n  count = 0\n  for a in A:\n    if a % k == 0:\n      count += 1\n  if count > best_count:\n    best_count = count\n    best_k = k\nprint(best_k)',
    ),
    'abc183_b': (
        '反射後の点Gをx軸の反対側へ鏡映して考えると、「Sから鏡映したGへ引いた直線がx軸と交わる位置」を求める問題になります。',
        'G=(Gx,Gy)を(Gx,-Gy)へ移した直線のy=0でのx座標を求めます。内分の比から x=(Sx*Gy + Gx*Sy)/(Sy+Gy) です。',
        '疑似コード:\nnumerator = Sx * Gy + Gx * Sy\ndenominator = Sy + Gy\nx = numerator / denominator\nprint(x)',
    ),
    'abc184_b': (
        'クイズ結果を左からそのままシミュレーションします。不正解xでは点数を1減らしますが、0未満にはしません。',
        'oならscore += 1、xならscore = max(0, score-1)です。文字列を1回走査するだけなのでO(N)です。',
        '疑似コード:\nscore = X\nfor c in S:\n  if c == "o":\n    score += 1\n  else:\n    score = max(0, score - 1)\nprint(score)',
    ),
}
