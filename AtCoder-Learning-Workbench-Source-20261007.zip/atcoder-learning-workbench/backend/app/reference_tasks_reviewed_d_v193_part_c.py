"""Private ABC270..274/276 D; ABC275 D is protected existing ready content."""
from __future__ import annotations
from collections import Counter,deque
from dataclasses import dataclass
from typing import cast
import heapq,math,random,re
TASKS=tuple(f'abc{n}_d' for n in (270,271,272,273,274,276))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc271_d':'semantic'}
CHECKER_IDS={'abc271_d':'abc271_d'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None,signed:bool=False)->tuple[int,...]:
    token=r'(?:0|[1-9][0-9]*|-[1-9][0-9]*)' if signed else r'(?:0|[1-9][0-9]*)';require(re.fullmatch(token+r'(?: '+token+r')*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc270_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],k);require(1<=n<=10000 and 1<=k<=100 and a[0]==1 and all(x<y for x,y in zip(a,a[1:])) and a[-1]<=n,'moves');return n,a
    if pid=='abc271_d':
        n,s=ints(rows[0],2);require(1<=n<=100 and 1<=s<=10000 and len(rows)==n+1,'shape');cards=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<=100 and 1<=b<=100 for a,b in cards),'cards');return s,cards
    if pid=='abc272_d':
        require(len(rows)==1,'shape');n,m=ints(rows[0],2);require(1<=n<=400 and 1<=m<=10**6,'range');return n,m
    if pid=='abc273_d':
        h,w,r,c=ints(rows[0],4);require(2<=h<=10**9 and 2<=w<=10**9 and 1<=r<=h and 1<=c<=w,'board');require(len(rows)>=3,'shape');n=ints(rows[1],1)[0];require(0<=n<=200000 and len(rows)>=n+3,'walls');walls=tuple(ints(row,2) for row in rows[2:2+n]);require(len(set(walls))==n and (r,c) not in walls and all(1<=rr<=h and 1<=cc<=w for rr,cc in walls),'wall positions');q=ints(rows[2+n],1)[0];require(1<=q<=200000 and len(rows)==n+q+3,'queries');queries=[]
        for row in rows[3+n:]:
            match=re.fullmatch(r'([LRUD]) ([1-9][0-9]*)',row);require(match is not None,'query');assert match is not None;length=int(match[2]);require(length<=10**9,'length');queries.append((match[1],length))
        return h,w,r,c,walls,tuple(queries)
    if pid=='abc274_d':
        require(len(rows)==2,'shape');n,x,y=ints(rows[0],3,True);a=ints(rows[1],n);require(2<=n<=1000 and abs(x)<=10000 and abs(y)<=10000 and all(1<=v<=10 for v in a),'range');return x,y,a
    require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=1000 and all(1<=v<=10**9 for v in a),'range');return (a,)
def stone_threshold_game(n:int,moves:tuple[int,...])->int:
    first=[1]*(n+1);opponent=[1]*(n+1)
    for remaining in range(1,n+1):
        first_mask=0;opponent_mask=(1<<(remaining+1))-1
        for move in moves:
            if move>remaining:break
            first_mask|=(opponent[remaining-move]<<move)|((1<<move)-1)
            opponent_mask&=first[remaining-move]
        first[remaining]=first_mask;opponent[remaining]=opponent_mask
    return first[n].bit_length()-1
def card_reachable(s:int,cards:tuple[tuple[int,...],...])->list[int]:
    states=[1];mask=(1<<(s+1))-1
    for a,b in cards:states.append(((states[-1]<<a)|(states[-1]<<b))&mask)
    return states
def card_witness(s:int,cards:tuple[tuple[int,...],...])->str:
    states=card_reachable(s,cards)
    if not(states[-1]>>s&1):return 'No'
    result=[]
    for j in range(len(cards)-1,-1,-1):
        a,b=cards[j]
        if s>=a and states[j]>>(s-a)&1:result.append('H');s-=a
        else:result.append('T');s-=b
    return 'Yes\n'+''.join(reversed(result))
def leaps_dijkstra(n:int,m:int)->list[list[int]]:
    offsets=set()
    for x in range(math.isqrt(m)+1):
        y=math.isqrt(m-x*x)
        if x*x+y*y==m:
            for sx in (-1,1):
                for sy in (-1,1):offsets.add((sx*x,sy*y))
    distance=[[10**9]*n for _ in range(n)];distance[0][0]=0;heap=[(0,0,0)]
    while heap:
        d,x,y=heapq.heappop(heap)
        if distance[x][y]!=d:continue
        for dx,dy in offsets:
            xx,yy=x+dx,y+dy
            if 0<=xx<n and 0<=yy<n and d+1<distance[xx][yy]:distance[xx][yy]=d+1;heapq.heappush(heap,(d+1,xx,yy))
    return [[-1 if v==10**9 else v for v in row] for row in distance]
@dataclass(slots=True)
class FreeInterval:
    low:int
    high:int
    left:FreeInterval|None=None
    right:FreeInterval|None=None
def free_tree(walls:list[int],limit:int)->FreeInterval|None:
    bounds=[0]+sorted(walls)+[limit+1];gaps=[(l+1,r-1) for l,r in zip(bounds,bounds[1:]) if l+1<=r-1]
    def build(lo:int,hi:int)->FreeInterval|None:
        if lo==hi:return None
        middle=(lo+hi)//2;l,r=gaps[middle];return FreeInterval(l,r,build(lo,middle),build(middle+1,hi))
    return build(0,len(gaps))
def containing(root:FreeInterval|None,point:int,limit:int)->tuple[int,int]:
    if root is None:return 1,limit
    while root is not None:
        if point<root.low:root=root.left
        elif point>root.high:root=root.right
        else:return root.low,root.high
    raise ValueError('position is blocked')
def movement_free_intervals(h:int,w:int,r:int,c:int,walls:tuple[tuple[int,...],...],queries:tuple[tuple[str,int],...])->list[tuple[int,int]]:
    row_walls:dict[int,list[int]]={};column_walls:dict[int,list[int]]={}
    for rr,cc in walls:row_walls.setdefault(rr,[]).append(cc);column_walls.setdefault(cc,[]).append(rr)
    rows={rr:free_tree(a,w) for rr,a in row_walls.items()};columns={cc:free_tree(a,h) for cc,a in column_walls.items()};out=[]
    for direction,length in queries:
        if direction in 'LR':low,high=containing(rows.get(r),c,w);c=max(low,c-length) if direction=='L' else min(high,c+length)
        else:low,high=containing(columns.get(c),r,h);r=max(low,r-length) if direction=='U' else min(high,r+length)
        out.append((r,c))
    return out
def axis_subset(target:int,lengths:tuple[int,...])->bool:
    total=sum(lengths)
    if abs(target)>total or (total+target)%2:return False
    needed=(total+target)//2;bits=1;mask=(1<<(needed+1))-1
    for v in lengths:bits=(bits|(bits<<v))&mask
    return bool(bits>>needed&1)
def division_ancestors(a:tuple[int,...])->int:
    counts=Counter(a);totals:dict[int,int]|None=None
    for value,frequency in sorted(counts.items()):
        distance={value:0};queue=deque([value])
        while queue:
            current=queue.popleft()
            for divisor in (2,3):
                if current%divisor==0:
                    nxt=current//divisor
                    if nxt not in distance:distance[nxt]=distance[current]+1;queue.append(nxt)
        if totals is None:totals={v:d*frequency for v,d in distance.items()}
        else:totals={v:cost+distance[v]*frequency for v,cost in totals.items() if v in distance}
        if not totals:return -1
    assert totals is not None;return min(totals.values())
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc270_d':n,a=cast(tuple[int,tuple[int,...]],data);return str(stone_threshold_game(n,a))
    if pid=='abc271_d':s,cards=cast(tuple[int,tuple[tuple[int,...],...]],data);return card_witness(s,cards)
    if pid=='abc272_d':n,m=cast(tuple[int,int],data);return '\n'.join(' '.join(map(str,row)) for row in leaps_dijkstra(n,m))
    if pid=='abc273_d':h,w,r,c,walls,queries=cast(tuple[int,int,int,int,tuple[tuple[int,...],...],tuple[tuple[str,int],...]],data);return '\n'.join(f'{rr} {cc}' for rr,cc in movement_free_intervals(h,w,r,c,walls,queries))
    if pid=='abc274_d':x,y,a=cast(tuple[int,int,tuple[int,...]],data);return 'Yes' if axis_subset(x-a[0],a[2::2]) and axis_subset(y,a[1::2]) else 'No'
    return str(division_ancestors(cast(tuple[int,...],data[0])))
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:
        expected_mode=OUTPUT_MODES.get(pid,'exact')
        if output_mode not in (None,expected_mode):return False
        if pid!='abc271_d':return actual.removesuffix('\n')==oracle(pid,raw)
        s,cards=cast(tuple[int,tuple[tuple[int,...],...]],validate(pid,raw));rows=actual.removesuffix('\n').split('\n')
        if rows==['No']:return not(card_reachable(s,cards)[-1]>>s&1)
        if len(rows)!=2 or rows[0]!='Yes' or len(rows[1])!=len(cards) or not set(rows[1])<=set('HT'):return False
        return sum(pair[0] if ch=='H' else pair[1] for pair,ch in zip(cards,rows[1]))==s
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc270_d':'''n,k=map(int,input().split());moves=list(map(int,input().split()));dp=[0]*(n+1)
for remaining in range(1,n+1):dp[remaining]=max(remaining-dp[remaining-m] for m in moves if m<=remaining)
print(dp[n])
''',
'abc271_d':'''n,s=map(int,input().split());cards=[tuple(map(int,input().split())) for _ in range(n)];dp=[[False]*(s+1) for _ in range(n+1)];dp[0][0]=True
for i,(a,b) in enumerate(cards):
 for v in range(s+1):
  if dp[i][v]:
   if v+a<=s:dp[i+1][v+a]=True
   if v+b<=s:dp[i+1][v+b]=True
if not dp[n][s]:print('No')
else:
 answer=[]
 for i in range(n-1,-1,-1):
  a,b=cards[i]
  if s>=a and dp[i][s-a]:answer.append('H');s-=a
  else:answer.append('T');s-=b
 print('Yes');print(''.join(answer[::-1]))
''',
'abc272_d':'''from collections import deque
n,m=map(int,input().split());offsets=[]
for dx in range(-n+1,n):
 for dy in range(-n+1,n):
  if dx*dx+dy*dy==m:offsets.append((dx,dy))
d=[[-1]*n for _ in range(n)];d[0][0]=0;queue=deque([(0,0)])
while queue:
 x,y=queue.popleft()
 for dx,dy in offsets:
  xx,yy=x+dx,y+dy
  if 0<=xx<n and 0<=yy<n and d[xx][yy]<0:d[xx][yy]=d[x][y]+1;queue.append((xx,yy))
for row in d:print(*row)
''',
'abc273_d':'''import bisect,sys
read=sys.stdin.buffer.readline;h,w,r,c=map(int,read().split());n=int(read());rows={};cols={}
for _ in range(n):
 rr,cc=map(int,read().split());rows.setdefault(rr,[]).append(cc);cols.setdefault(cc,[]).append(rr)
for v in rows.values():v.sort()
for v in cols.values():v.sort()
out=[]
for _ in range(int(read())):
 direction,length=read().split();length=int(length)
 if direction in (b'L',b'R'):
  walls=rows.get(r,[]);j=bisect.bisect_left(walls,c)
  if direction==b'L':bound=walls[j-1]+1 if j else 1;c=max(bound,c-length)
  else:bound=walls[j]-1 if j<len(walls) else w;c=min(bound,c+length)
 else:
  walls=cols.get(c,[]);j=bisect.bisect_left(walls,r)
  if direction==b'U':bound=walls[j-1]+1 if j else 1;r=max(bound,r-length)
  else:bound=walls[j]-1 if j<len(walls) else h;r=min(bound,r+length)
 out.append(f'{r} {c}')
print('\\n'.join(out))
''',
'abc274_d':'''n,x,y=map(int,input().split());a=list(map(int,input().split()))
def reachable(target,lengths,initial):
 states={initial}
 for v in lengths:states={p+direction*v for p in states for direction in (-1,1)}
 return target in states
print('Yes' if reachable(x,a[2::2],a[0]) and reachable(y,a[1::2],0) else 'No')
''',
'abc276_d':'''import math,functools
n=int(input());a=list(map(int,input().split()));g=functools.reduce(math.gcd,a);answer=0
for v in a:
 v//=g
 for divisor in (2,3):
  while v%divisor==0:v//=divisor;answer+=1
 if v!=1:print(-1);break
else:print(answer)
'''}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(19300+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc270_d':
        def stones(n:int,a:list[int])->str:return f'{n} {len(a)}\n'+line(a)
        raws=[stones(1,[1]),stones(10000,[1]),stones(2,[1,2]),stones(10,[1,4])]
        for n in range(3,15):a=[1]+sorted(rng.sample(range(2,n+1),rng.randint(0,n-1)));raws.append(stones(n,a))
        raws += [stones(10000,list(range(1,101))),stones(10000,[1]+list(range(9902,10001)))]
    elif pid=='abc271_d':
        def cards(s:int,a:list[tuple[int,int]])->str:return f'{len(a)} {s}\n'+''.join(line(v) for v in a)
        raws=[cards(1,[(1,1)]),cards(10000,[(1,1)]),cards(2,[(1,2)]),cards(100,[(100,100)])]
        for n in range(2,14):a=[(rng.randint(1,100),rng.randint(1,100)) for _ in range(n)];s=sum(rng.choice(v) for v in a)+(n%2);raws.append(cards(s,a))
        raws += [cards(9950,[(99,100)]*100),cards(10000,[(100,100)]*100)]
    elif pid=='abc272_d':raws=[f'{n} {m}\n' for n,m in [(1,1),(1,10**6),(2,1),(2,2),(3,3),(4,5),(5,8),(6,10),(7,13),(8,25),(9,50),(10,65),(11,100),(12,125),(20,325),(400,325),(400,1),(400,10**6)]]
    elif pid=='abc273_d':
        def grid(h:int,w:int,r:int,c:int,a:list[tuple[int,int]],q:list[tuple[str,int]])->str:return f'{h} {w} {r} {c}\n{len(a)}\n'+''.join(line(v) for v in a)+f'{len(q)}\n'+''.join(f'{d} {l}\n' for d,l in q)
        raws=[grid(2,2,1,1,[],[('L',1)]),grid(2,2,1,1,[],[('R',10**9),('D',10**9)]),grid(2,2,1,1,[(1,2),(2,1)],[('R',1),('D',1)]),grid(10**9,10**9,1,1,[],[('R',10**9),('D',10**9),('L',10**9),('U',10**9)])]
        for n in range(3,15):h=w=n;r=c=1;walls=rng.sample([(rr,cc) for rr in range(1,h+1) for cc in range(1,w+1) if (rr,cc)!=(1,1)],n);q=[(rng.choice('LRUD'),rng.randint(1,10**9)) for _ in range(n)];raws.append(grid(h,w,r,c,walls,q))
        raws += [grid(10**9,10**9,1,1,[(j+2,j+2) for j in range(200000)],[('R',10**9),('D',10**9),('L',10**9),('U',10**9)]*50000),grid(10**9,10**9,10**9,10**9,[(10**9,j+1) for j in range(200000)],[('L',10**9),('R',10**9)]*100000)]
    elif pid=='abc274_d':
        def robot(x:int,y:int,a:list[int])->str:return f'{len(a)} {x} {y}\n'+line(a)
        raws=[robot(1,1,[1,1]),robot(-1,1,[1,1]),robot(10000,10000,[1,1]),robot(-10000,-10000,[10,10])]
        for n in range(3,15):a=[rng.randint(1,10) for _ in range(n)];x=a[0]+sum(rng.choice((-v,v)) for v in a[2::2]);y=sum(rng.choice((-v,v)) for v in a[1::2]);raws.append(robot(x+(n%3==0),y,a))
        a=[rng.randint(1,10) for _ in range(1000)];x=a[0]+sum(rng.choice((-v,v)) for v in a[2::2]);y=sum(rng.choice((-v,v)) for v in a[1::2]);raws[-1]=robot(x,y,a)
        raws += [robot(-4980,5000,[10]*1000),robot(10000,10000,[10]*1000)]
    else:
        def values(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[values([1,1]),values([1,2]),values([1,5]),values([10**9,10**9])]
        for n in range(2,14):raws.append(values([rng.randint(1,10**9) for _ in range(n)]))
        raws += [values([2**29,3**18]*500),values([10**9]*1000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc270_d':('残り石数ごとの、その手番の人が最終的に取れる最大数を考えます。','一手でm個取ると、残りremaining-m個のうち相手が取るdp[remaining-m]個以外を自分が取れます。Aに1があるので最後に全ての石が取られます。','疑似コード: dp[0]=0; remaining=1..Nでdp[remaining]=max(remaining-dp[remaining-m]) over m<=remaining; dp[N]出力。'),
'abc271_d':('カードごとに、ここまでの総和として実現できる値を記録します。','dp[i][sum]を先頭i枚で実現できるかとし、次のカードの表・裏の両方へ遷移します。Sが実現できれば、後ろから選択を復元します。','疑似コード: dp[0][0]=true; 各(a,b)で到達sumからsum+a,sum+bへtrue; dp[N][S]がfalseならNo; trueなら後ろへ、dp[i-1][S-a]ならH/S-=a、他T/S-=b; Yesと逆順を出力。'),
'abc272_d':('移動可能な座標差はdx²+dy²=Mを満たします。','盤面に収まる整数の座標差を全列挙し、左上から幅優先探索します。一手のコストが全て1なので最初の到達が最短です。','疑似コード: dx,dy=-(N-1)..N-1で二乗和Mの差を保存; dist全-1、dist[0][0]=0; BFSで各差を足した盤内未訪問点へdist+1; 各row出力。'),
'abc273_d':('移動する行や列にある、最も近い壁と外周が停止位置を決めます。','壁を行別・列別にソートします。二分探索で現在位置の直前・直後の壁を見つけ、移動予定座標を壁の一つ手前に制限します。','疑似コード: rows[r]/cols[c]へ壁登録しsort; 各queryで対応する壁列のlower_bound(current); L/Uは直前壁+1以上、R/Dは直後壁-1以下へclamp; 座標出力。'),
'abc274_d':('最初の移動は右向き固定で、以降の横方向と縦方向を独立に考えられます。','偶数indexの移動は横、奇数indexは縦です。それぞれについて、到達座標の集合を±A_iへ更新します。','疑似コード: 横states={A0},縦states={0}; 対応する各lengthでstates={pos-length,pos+length for pos in states}; xが横集合かつyが縦集合ならYes、他No。'),
'abc276_d':('全要素を同じ値にするなら、共通して残せる因子を最大限残します。','全要素の最大公約数gを求め、各A_i/gを2と3だけで1まで割れるか調べます。割れた回数の総和が最小操作数です。','疑似コード: g=gcd全要素; 各v=A_i/gで2で割れる間割りanswer++、次3も同様; 最後v!=1なら-1、全1ならanswer出力。')}

TITLES={'abc270_d': 'Stones', 'abc271_d': 'Flip and Adjust', 'abc272_d': 'Root M Leaper', 'abc273_d': 'LRUD Instructions', 'abc274_d': 'Robot Arms 2', 'abc276_d': 'Divide by 2 or 3'}
PUBLISHED_SAMPLES={'abc270_d': [{'input': '10 2\n1 4\n', 'expected': '5\n'}, {'input': '11 4\n1 2 3 6\n', 'expected': '8\n'}, {'input': '10000 10\n1 2 4 8 16 32 64 128 256 512\n', 'expected': '5136\n'}], 'abc271_d': [{'input': '3 11\n1 4\n2 3\n5 7\n', 'expected': 'Yes\nTHH\n'}, {'input': '5 25\n2 8\n9 3\n4 11\n5 1\n12 6\n', 'expected': 'No\n'}], 'abc272_d': [{'input': '3 1\n', 'expected': '0 1 2\n1 2 3\n2 3 4\n'}, {'input': '10 5\n', 'expected': '0 3 2 3 2 3 4 5 4 5\n3 4 1 2 3 4 3 4 5 6\n2 1 4 3 2 3 4 5 4 5\n3 2 3 2 3 4 3 4 5 6\n2 3 2 3 4 3 4 5 4 5\n3 4 3 4 3 4 5 4 5 6\n4 3 4 3 4 5 4 5 6 5\n5 4 5 4 5 4 5 6 5 6\n4 5 4 5 4 5 6 5 6 7\n5 6 5 6 5 6 5 6 7 6\n'}], 'abc273_d': [{'input': '5 5 4 4\n3\n5 3\n2 2\n1 4\n4\nL 2\nU 3\nL 2\nR 4\n', 'expected': '4 2\n3 2\n3 1\n3 5\n'}, {'input': '6 6 6 3\n7\n3 1\n4 3\n2 6\n3 4\n5 5\n1 1\n3 2\n10\nD 3\nU 3\nL 2\nD 2\nU 3\nD 3\nU 3\nR 3\nL 3\nD 1\n', 'expected': '6 3\n5 3\n5 1\n6 1\n4 1\n6 1\n4 1\n4 2\n4 1\n5 1\n'}], 'abc274_d': [{'input': '3 -1 1\n2 1 3\n', 'expected': 'Yes\n'}, {'input': '5 2 0\n2 2 2 2 2\n', 'expected': 'Yes\n'}, {'input': '4 5 5\n1 2 3 4\n', 'expected': 'No\n'}, {'input': '3 2 7\n2 7 4\n', 'expected': 'No\n'}, {'input': '10 8 -7\n6 10 4 1 5 9 8 6 5 1\n', 'expected': 'Yes\n'}], 'abc276_d': [{'input': '3\n1 4 3\n', 'expected': '3\n'}, {'input': '3\n2 7 6\n', 'expected': '-1\n'}, {'input': '6\n1 1 1 1 1 1\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
