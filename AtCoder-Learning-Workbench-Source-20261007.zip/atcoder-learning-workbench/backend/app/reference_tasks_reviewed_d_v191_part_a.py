"""Private ABC222..227 D: value-axis DP, tournament topology, and train ropes."""
from __future__ import annotations
from dataclasses import dataclass
from collections import deque
from fractions import Fraction
from math import gcd
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(222,228));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
MOD=998244353

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

@dataclass(slots=True)
class TrainNode:
    number:int
    size:int=1
    height:int=1
    left:TrainNode|None=None
    right:TrainNode|None=None
    parent:TrainNode|None=None

def size(t:TrainNode|None)->int:return t.size if t else 0

def height(t:TrainNode|None)->int:return t.height if t else 0

def pull(t:TrainNode)->None:
    t.size=1+size(t.left)+size(t.right)
    t.height=1+max(height(t.left),height(t.right))
    for child in (t.left,t.right):
        if child is not None:child.parent=t

def rotate_left(a:TrainNode)->TrainNode:
    b=cast(TrainNode,a.right);a.right=b.left;b.left=a;pull(a);pull(b);b.parent=None;return b

def rotate_right(a:TrainNode)->TrainNode:
    b=cast(TrainNode,a.left);a.left=b.right;b.right=a;pull(a);pull(b);b.parent=None;return b

def balance(t:TrainNode)->TrainNode:
    pull(t)
    if height(t.left)>height(t.right)+1:
        left=cast(TrainNode,t.left)
        if height(left.right)>height(left.left):t.left=rotate_left(left)
        return rotate_right(t)
    if height(t.right)>height(t.left)+1:
        right=cast(TrainNode,t.right)
        if height(right.left)>height(right.right):t.right=rotate_right(right)
        return rotate_left(t)
    t.parent=None;return t

def join(a:TrainNode|None,middle:TrainNode,b:TrainNode|None)->TrainNode:
    if height(a)>height(b)+1:
        left=cast(TrainNode,a);left.right=join(left.right,middle,b);return balance(left)
    if height(b)>height(a)+1:
        right=cast(TrainNode,b);right.left=join(a,middle,right.left);return balance(right)
    middle.left=a;middle.right=b;middle.parent=None;pull(middle);return middle

def pop_first(t:TrainNode)->tuple[TrainNode,TrainNode|None]:
    if t.left is None:
        rest=t.right;t.right=None;t.parent=None;pull(t)
        if rest is not None:rest.parent=None
        return t,rest
    first,t.left=pop_first(t.left);return first,balance(t)

def merge(a:TrainNode|None,b:TrainNode|None)->TrainNode|None:
    if a is None or b is None:
        out=a if a is not None else b
        if out is not None:out.parent=None
        return out
    middle,rest=pop_first(b);return join(a,middle,rest)

def split(t:TrainNode|None,k:int)->tuple[TrainNode|None,TrainNode|None]:
    if t is None:return None,None
    left,right=t.left,t.right;left_size=size(left);t.left=t.right=t.parent=None;pull(t)
    if k<=left_size:
        a,b=split(left,k);return a,join(b,t,right)
    a,b=split(right,k-left_size-1);return join(left,t,a),b

def root_rank(node:TrainNode)->tuple[TrainNode,int]:
    rank=size(node.left)
    while node.parent is not None:
        parent=node.parent
        if parent.right is node:rank+=size(parent.left)+1
        node=parent
    return node,rank

def train_ropes(n:int,queries:tuple[tuple[int,...],...],produce:bool=True)->list[str]:
    nodes=[TrainNode(j+1) for j in range(n)];out=[];total=0
    for row in queries:
        kind,x=row[:2];a,rank=root_rank(nodes[x-1])
        if kind==1:
            y=row[2];b,other=root_rank(nodes[y-1]);require(a is not b and rank==a.size-1 and other==0,'legal concatenation');merge(a,b)
        elif kind==2:
            y=row[2];b,other=root_rank(nodes[y-1]);require(a is b and other==rank+1,'direct rear/front connection');split(a,other)
        else:
            total+=a.size;require(total<=10**6,'output train total')
            if produce:
                sequence=[];stack:list[TrainNode]=[];current:TrainNode|None=a
                while current is not None or stack:
                    if current is not None:stack.append(current);current=current.left
                    else:current=stack.pop();sequence.append(current.number);current=current.right
                out.append(line([len(sequence)]+sequence))
    return out

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc222_d':
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];require(1<=n<=3000,'N');a=ints(rows[1],n);b=ints(rows[2],n);require(all(0<=x<=y<=3000 for x,y in zip(a,b)) and all(x<=y for x,y in zip(a,a[1:])) and all(x<=y for x,y in zip(b,b[1:])),'bounds/nondecreasing');return a,b
    if pid=='abc223_d':
        n,m=ints(rows[0],2);require(2<=n<=200000 and 1<=m<=200000 and len(rows)==m+1,'N/M/shape');edges=tuple(ints(row,2) for row in rows[1:]);require(all(1<=x<=n and 1<=y<=n and x!=y for x,y in edges),'endpoints');return n,edges
    if pid=='abc224_d':
        m=ints(rows[0],1)[0];require(0<=m<=36 and len(rows)==m+2,'M/shape');edges=tuple(ints(row,2) for row in rows[1:-1]);positions=ints(rows[-1],8);require(all(1<=x<=9 and 1<=y<=9 and x!=y for x,y in edges) and len({tuple(sorted(e)) for e in edges})==m,'simple graph');require(all(1<=p<=9 for p in positions) and len(set(positions))==8,'piece positions');return edges,positions
    if pid=='abc225_d':
        n,q=ints(rows[0],2);require(2<=n<=100000 and 1<=q<=100000 and len(rows)==q+1,'N/Q/shape');queries=tuple(ints(row) for row in rows[1:]);require(all(r[0] in (1,2,3) and len(r)==(2 if r[0]==3 else 3) and all(1<=x<=n for x in r[1:]) for r in queries),'queries');train_ropes(n,queries,False);return n,queries
    if pid=='abc226_d':
        n=ints(rows[0],1)[0];require(2<=n<=500 and len(rows)==n+1,'N/shape');points=tuple(ints(row,2) for row in rows[1:]);require(all(0<=v<=10**9 for p in points for v in p) and len(set(points))==n,'bounds/distinct');return (points,)
    n,k=ints(rows[0],2);require(len(rows)==2 and 1<=k<=n<=200000,'N/K/shape');a=ints(rows[1],n);require(all(1<=x<=10**12 for x in a),'employees');return k,a

def value_axis_paths(a:tuple[int,...],b:tuple[int,...])->int:
    dp=[1]+[0]*len(a)
    for value in range(b[-1]+1):
        current=dp.copy()
        for i,(low,high) in enumerate(zip(a,b),1):
            if low<=value<=high:current[i]=(dp[i]+current[i-1])%MOD
        dp=current
    return dp[-1]

def topological_tournament(n:int,edges:tuple[tuple[int,int],...])->list[int]:
    graph=[[] for _ in range(n)];degree=[0]*n
    for a,b in edges:graph[a-1].append(b-1);degree[b-1]+=1
    base=1
    while base<n:base*=2
    inf=10**9;tree=[inf]*(2*base);tree[base:base+n]=degree
    for i in range(base-1,0,-1):tree[i]=min(tree[2*i],tree[2*i+1])
    def update(i:int,value:int)->None:
        i+=base;tree[i]=value;i//=2
        while i:tree[i]=min(tree[2*i],tree[2*i+1]);i//=2
    out=[]
    for _ in range(n):
        if tree[1]!=0:return [-1]
        at=1
        while at<base:at=2*at if tree[2*at]==0 else 2*at+1
        node=at-base;out.append(node+1);update(node,inf)
        for neighbor in graph[node]:degree[neighbor]-=1;update(neighbor,degree[neighbor])
    return out

def puzzle_bidirectional(edges:tuple[tuple[int,int],...],positions:tuple[int,...])->int:
    graph=[[] for _ in range(9)]
    for a,b in edges:graph[a-1].append(b-1);graph[b-1].append(a-1)
    occupied=tuple(p-1 for p in positions);start=occupied+(next(p for p in range(9) if p not in occupied),);goal=tuple(range(9))
    if start==goal:return 0
    fronts=({start},{goal});seen=({start:0},{goal:0});depth=[0,0]
    while fronts[0] and fronts[1]:
        side=int(len(fronts[0])>len(fronts[1]));current=set();depth[side]+=1;meeting=[]
        for state in fronts[side]:
            blank=state[8]
            for neighbor in graph[blank]:
                tile=state.index(neighbor);moved=list(state);moved[tile]=blank;moved[8]=neighbor;new=tuple(moved)
                if new in seen[side]:continue
                seen[side][new]=depth[side];current.add(new)
                if new in seen[1-side]:meeting.append(depth[side]+seen[1-side][new])
        if meeting:return min(meeting)
        fronts[side].clear();fronts[side].update(current)
    return -1

def rational_directions(points:tuple[tuple[int,int],...])->int:
    slopes:set[Fraction|None]=set()
    for i,(x,y) in enumerate(points):
        for xx,yy in points[:i]:slopes.add(Fraction(y-yy,x-xx) if x!=xx else None)
    return 2*len(slopes)

def project_waterfill(k:int,a:tuple[int,...])->int:
    ordered=sorted(a);total=sum(ordered)
    while ordered[-1]>total//k:total-=ordered.pop();k-=1
    return total//k

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc222_d':return str(value_axis_paths(*cast(tuple[tuple[int,...],tuple[int,...]],data)))+'\n'
    if pid=='abc223_d':return line(topological_tournament(*cast(tuple[int,tuple[tuple[int,int],...]],data)))
    if pid=='abc224_d':return str(puzzle_bidirectional(*cast(tuple[tuple[tuple[int,int],...],tuple[int,...]],data)))+'\n'
    if pid=='abc225_d':return ''.join(train_ropes(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
    if pid=='abc226_d':return str(rational_directions(cast(tuple[tuple[int,int],...],data[0])))+'\n'
    return str(project_waterfill(*cast(tuple[int,tuple[int,...]],data)))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
    except (ValueError,TypeError,IndexError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc222_d':'''n=int(input());a=list(map(int,input().split()));b=list(map(int,input().split()));mod=998244353;d=[0]*3001;d[0]=1
for low,high in zip(a,b):
 total=0;nextd=[0]*3001
 for v,x in enumerate(d):
  total=(total+x)%mod
  if low<=v<=high:nextd[v]=total
 d=nextd
print(sum(d)%mod)
''',
'abc223_d':'''import sys,heapq
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);graph=[[] for _ in range(n)];degree=[0]*n
for _ in range(m):a=next(it)-1;b=next(it)-1;graph[a].append(b);degree[b]+=1
heap=[v for v in range(n) if not degree[v]];heapq.heapify(heap);out=[]
while heap:
 v=heapq.heappop(heap);out.append(v+1)
 for u in graph[v]:
  degree[u]-=1
  if degree[u]==0:heapq.heappush(heap,u)
print(*out if len(out)==n else [-1])
''',
'abc224_d':'''from collections import deque
m=int(input());g=[[] for _ in range(9)]
for _ in range(m):a,b=map(int,input().split());g[a-1].append(b-1);g[b-1].append(a-1)
state=['0']*9
for piece,position in enumerate(map(int,input().split()),1):state[position-1]=str(piece)
start=''.join(state);goal='123456780';distance={start:0};q=deque([start]);answer=-1
while q:
 state=q.popleft();d=distance[state]
 if state==goal:answer=d;break
 blank=state.index('0')
 for neighbor in g[blank]:
  row=list(state);row[blank],row[neighbor]=row[neighbor],row[blank];new=''.join(row)
  if new not in distance:distance[new]=d+1;q.append(new)
print(answer)
''',
'abc225_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);q=next(it);previous=[-1]*n;following=[-1]*n;out=[]
for _ in range(q):
 kind=next(it);x=next(it)-1
 if kind<3:
  y=next(it)-1
  if kind==1:following[x]=y;previous[y]=x
  else:following[x]=-1;previous[y]=-1
 else:
  while previous[x]>=0:x=previous[x]
  cars=[]
  while x>=0:cars.append(x+1);x=following[x]
  out.append(str(len(cars))+' '+' '.join(map(str,cars))+'\\n')
sys.stdout.write(''.join(out))
''',
'abc226_d':'''from math import gcd
n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];directions=set()
for x,y in points:
 for xx,yy in points:
  dx=xx-x;dy=yy-y
  if dx or dy:
   d=gcd(abs(dx),abs(dy));directions.add((dx//d,dy//d))
print(len(directions))
''',
'abc227_d':'''n,k=map(int,input().split());a=list(map(int,input().split()));low=0;high=sum(a)//k+1
while high-low>1:
 middle=(low+high)//2
 if sum(min(x,middle) for x in a)>=k*middle:low=middle
 else:high=middle
print(low)
'''}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(191000+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc222_d':
        def arrays(a:list[int],b:list[int])->str:return str(len(a))+'\n'+line(a)+line(b)
        raws=[arrays([0],[0]),arrays([0],[3000]),arrays([3000],[3000]),arrays([0,0],[0,1])]
        for n in range(2,14):
            a=sorted(rng.randrange(0,12) for _ in range(n));b=sorted(v+rng.randrange(0,12) for v in a);raws.append(arrays(a,b))
        raws+=[arrays(list(range(1,3001)),[3000]*3000),arrays([0]*3000,[3000]*3000)]
    elif pid=='abc223_d':
        def graph(n:int,e:list[tuple[int,int]])->str:return line((n,len(e)))+''.join(line(row) for row in e)
        raws=[graph(2,[(1,2)]),graph(2,[(2,1)]),graph(2,[(1,2),(1,2)]),graph(2,[(1,2),(2,1)])]
        for n in range(3,15):
            permutation=list(range(1,n+1));rng.shuffle(permutation);e=[(permutation[i],permutation[j]) for i in range(n) for j in range(i+1,n) if rng.randrange(4)==0];e=e or[(permutation[0],permutation[-1])]
            if n%4==0:e.extend([(permutation[-1],permutation[0]),(permutation[0],permutation[-1])])
            rng.shuffle(e);raws.append(graph(n,e))
        raws+=[graph(200000,[(j+1,j) for j in range(1,200000)]+[(200000,1)]),graph(200000,[(1,2)]*200000)]
    elif pid=='abc224_d':
        def puzzle(e:list[tuple[int,int]],p:list[int])->str:return str(len(e))+'\n'+''.join(line(row) for row in e)+line(p)
        grid=[(r*3+c+1,r*3+c+2) for r in range(3) for c in range(2)]+[(r*3+c+1,(r+1)*3+c+1) for r in range(2) for c in range(3)]
        raws=[puzzle([],list(range(1,9))),puzzle([],[2,1,3,4,5,6,7,8]),puzzle([(9,8)],[1,2,3,4,5,6,7,9]),puzzle(grid,[1,2,3,4,5,6,8,7])]
        for j in range(12):
            n=3+j%3;vertices=list(range(1,n))+[9];e=[(x,y) for i,x in enumerate(vertices) for y in vertices[i+1:] if rng.randrange(4)!=0];p=vertices.copy();rng.shuffle(p);positions=p[:n-1]+list(range(n,9));raws.append(puzzle(e,positions))
        raws+=[puzzle(grid,[9,4,7,6,5,2,3,1]),puzzle([(a,b) for a in range(1,9) for b in range(a+1,10)],[9,8,7,6,5,4,3,2])]
    elif pid=='abc225_d':
        def trains(n:int,q:list[tuple[int,...]])->str:return line((n,len(q)))+''.join(line(row) for row in q)
        raws=[trains(2,[(3,1)]),trains(2,[(1,1,2)]),trains(2,[(1,1,2),(2,1,2)]),trains(3,[(1,2,1),(1,1,3),(3,1),(2,1,3),(3,2),(3,3)])]
        for n in range(3,15):
            groups=[[j] for j in range(1,n+1)];q=[]
            for _ in range(n*5):
                kind=rng.randrange(3)
                if kind==0 and len(groups)>1:
                    i,j=rng.sample(range(len(groups)),2);a,b=groups[i],groups[j];q.append((1,a[-1],b[0]));groups=[v for k,v in enumerate(groups) if k not in (i,j)]+[a+b]
                elif kind==1 and any(len(v)>1 for v in groups):
                    i=rng.choice([k for k,v in enumerate(groups) if len(v)>1]);a=groups.pop(i);cut=rng.randrange(1,len(a));q.append((2,a[cut-1],a[cut]));groups.extend([a[:cut],a[cut:]])
                else:q.append((3,rng.randrange(1,n+1)))
            raws.append(trains(n,q))
        chain=[(1,j,j+1) for j in range(90001,100000)];queries=chain+[(3,95000)]*100+[(1,1,2)]+[(1,2,3),(2,2,3)]*44950;raws.append(trains(100000,queries))
        raws.append(trains(100000,[(1,99999,100000),(2,99999,100000)]*50000))
    elif pid=='abc226_d':
        def points(p:list[tuple[int,int]])->str:return str(len(p))+'\n'+''.join(line(row) for row in p)
        raws=[points([(0,0),(0,1)]),points([(0,0),(10**9,10**9)]),points([(0,0),(1,0),(2,0)]),points([(0,0),(0,10**9),(10**9,0),(10**9,10**9)])]
        for n in range(3,15):raws.append(points(rng.sample([(x,y) for x in range(7) for y in range(7)],n)))
        raws+=[points([(j,j*j) for j in range(500)]),points([(0,0),(10**9,10**9)]+[(j*2000000,(j*j*65537)%1000000001) for j in range(1,499)])]
    else:
        def employees(k:int,a:list[int])->str:return line((len(a),k))+line(a)
        raws=[employees(1,[1]),employees(1,[10**12]),employees(2,[1,10**12]),employees(3,[1,1,3,4])]
        for n in range(2,14):raws.append(employees(rng.randrange(1,n+1),[rng.randrange(1,10**12+1) for _ in range(n)]))
        raws+=[employees(1,[10**12]*200000),employees(200000,[10**12]*200000)]
    require(len(raws)==len(set(raws))==18,'distinct18')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]

HINTS={
'abc222_d':('各位置の値を決めるとき、直前以下の値からだけ遷移できます。','dp[v]を直前の値がvの個数とし、累積和を使って範囲a_i..b_iの次の状態を作ります。','疑似コード: dp[0]=1; 各iでprefix[v]=sum(dp[0..v]); next[v]=prefix[v] if a_i<=v<=b_i else 0; 各加算を998244353で割り、最後のdp総和を出力。'),
'abc223_d':('まだ選んでいない頂点のうち、先行条件を全て満たしたものを選びます。','入次数0の頂点を最小ヒープに入れ、常に最小番号を取り出すと辞書順最小になります。重複条件も辺として数えます。','疑似コード: indegreeと隣接辺を作り、indegree0をheapへ; 最小vを出力順に追加し各v->uのindegreeを減らす; 0になったuをheapへ; N個選べなければ-1。'),
'abc224_d':('頂点上のコマ配置と空き頂点を一つの状態として扱います。','空き頂点と隣接コマを交換する遷移は全て1操作なので、配置のBFSで最短距離が求まります。非連結でも同じ方法で判定できます。','疑似コード: 初期配置をqueueと距離0へ; 空きと隣接頂点をswapした未訪問配置を距離+1で追加; 完成配置の距離を出力、到達しなければ-1。'),
'abc225_d':('各電車に直接つながる前後の電車を管理します。','連結・分離は二つの隣接情報を更新します。出力時は先頭まで戻り、後部へ順にたどります。出力個数の合計保証を使えます。','疑似コード: prev,nextをなしで初期化; 1 x yでnext[x]=y,prev[y]=x; 2で両方なし; 3 xでprevを先頭まで、次にnextを末尾まで走査し個数と列を出力。'),
'abc226_d':('同じ向きの平行な移動には、同じ魔法を繰り返し使えます。','各移動ベクトルを成分の最大公約数で割った最短の整数ベクトルにします。反対方向は別の魔法です。','疑似コード: 全i!=jでdx=x_j-x_i,dy=y_j-y_i,g=gcd(abs(dx),abs(dy)); 集合へ(dx/g,dy/g)を追加し集合サイズを出力。'),
'abc227_d':('プロジェクトをx個作るなら、各部署から使える人数は最大x人です。','sum(min(A_i,x))>=K*xが実現可能条件です。xが増えると条件は満たしにくくなるため二分探索できます。','疑似コード: low=0,high=sum(A)/K+1; midでsum(min(A_i,mid))>=K*midならlow=mid、他はhigh=mid; 隣接するまで繰り返しlowを出力。')}

TITLES={'abc222_d': 'Between Two Arrays', 'abc223_d': 'Restricted Permutation', 'abc224_d': '8 Puzzle on Graph', 'abc225_d': 'Play Train', 'abc226_d': 'Teleportation', 'abc227_d': 'Project Planning'}
PUBLISHED_SAMPLES={'abc222_d': [{'input': '2\n1 1\n2 3\n', 'expected': '5\n'}, {'input': '3\n2 2 2\n2 2 2\n', 'expected': '1\n'}, {'input': '10\n1 2 3 4 5 6 7 8 9 10\n1 4 9 16 25 36 49 64 81 100\n', 'expected': '978222082\n'}], 'abc223_d': [{'input': '4 3\n2 1\n3 4\n2 4\n', 'expected': '2 1 3 4\n'}, {'input': '2 3\n1 2\n1 2\n2 1\n', 'expected': '-1\n'}], 'abc224_d': [{'input': '5\n1 2\n1 3\n1 9\n2 9\n3 9\n3 9 2 4 5 6 7 8\n', 'expected': '5\n'}, {'input': '5\n1 2\n1 3\n1 9\n2 9\n3 9\n1 2 3 4 5 6 7 8\n', 'expected': '0\n'}, {'input': '12\n8 5\n9 6\n4 5\n4 1\n2 5\n8 9\n2 1\n3 6\n8 7\n6 5\n7 4\n2 3\n1 2 3 4 5 6 8 7\n', 'expected': '-1\n'}, {'input': '12\n6 5\n5 4\n4 1\n4 7\n8 5\n2 1\n2 5\n6 9\n3 6\n9 8\n8 7\n3 2\n2 3 4 6 1 9 7 8\n', 'expected': '16\n'}], 'abc225_d': [{'input': '7 14\n1 6 3\n1 4 1\n1 5 2\n1 2 7\n1 3 5\n3 2\n3 4\n3 6\n2 3 5\n2 4 1\n1 1 5\n3 2\n3 4\n3 6\n', 'expected': '5 6 3 5 2 7\n2 4 1\n5 6 3 5 2 7\n4 1 5 2 7\n1 4\n2 6 3\n'}], 'abc226_d': [{'input': '3\n1 2\n3 6\n7 4\n', 'expected': '6\n'}, {'input': '3\n1 2\n2 2\n4 2\n', 'expected': '2\n'}, {'input': '4\n0 0\n0 1000000000\n1000000000 0\n1000000000 1000000000\n', 'expected': '8\n'}], 'abc227_d': [{'input': '3 3\n2 3 4\n', 'expected': '2\n'}, {'input': '4 2\n1 1 3 4\n', 'expected': '4\n'}, {'input': '4 3\n1 1 3 4\n', 'expected': '2\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
