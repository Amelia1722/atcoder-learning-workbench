"""Statement-checked three-stage hints for ABC194–196 B."""
HINTS_V112={
 'abc194_b':(
  '仕事Aと仕事Bに誰を割り当てるかを考えます。同じ人なら時間は和、違う人なら長い方です。',
  '従業員iをA、従業員jをBに割り当てる全組を試せます。i=jなら A_i+B_i、i!=jなら max(A_i,B_j) を候補にします。N<=1000なのでO(N^2)で十分です。',
  '疑似コード:\nans = INF\nfor i in 0..N-1:\n  for j in 0..N-1:\n    if i == j: t = A[i] + B[j]\n    else: t = max(A[i], B[j])\n    ans = min(ans, t)\nprint(ans)',
 ),
 'abc195_b':(
  'みかんをn個選ぶと、合計重量として作れる範囲は A*n グラム以上 B*n グラム以下です。',
  '目標は1000*Wグラムです。したがって A*n <= 1000*W <= B*n を満たす整数nの最小値と最大値を求めます。存在しなければUNSATISFIABLEです。',
  '疑似コード:\ntotal = 1000 * W\nmin_n = ceil(total / B)\nmax_n = floor(total / A)\nif min_n > max_n: print("UNSATISFIABLE")\nelse: print(min_n, max_n)',
 ),
 'abc196_b':(
  '必要なのは小数点以下を捨てた整数部分だけです。Xは非常に大きいので、数値へ変換する必要はありません。',
  '入力を文字列として読み、小数点があればその直前まで、なければ文字列全体を出力すればよいです。',
  '疑似コード:\nX = 文字列として読む\nif "." in X:\n  print(Xを"."で分割した先頭部分)\nelse:\n  print(X)',
 ),
}
