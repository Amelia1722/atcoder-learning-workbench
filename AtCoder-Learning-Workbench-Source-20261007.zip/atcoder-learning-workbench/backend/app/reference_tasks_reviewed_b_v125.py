"""ABC233–235 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
import re

TASKS = ('abc233_b', 'abc234_b', 'abc235_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc233_b': [
        {'input': '3 7\nabcdefgh\n', 'expected': 'abgfedch\n'},
        {'input': '1 7\nreviver\n', 'expected': 'reviver\n'},
        {'input': '4 13\nmerrychristmas\n', 'expected': 'meramtsirhcyrs\n'},
    ],
    'abc234_b': [
        {'input': '3\n0 0\n0 1\n1 1\n', 'expected': '1.4142135624\n'},
        {'input': '5\n315 271\n-2 -621\n-205 -511\n-952 482\n165 463\n', 'expected': '1455.7159750446\n'},
    ],
    'abc235_b': [
        {'input': '5\n1 5 10 4 2\n', 'expected': '10\n'},
        {'input': '3\n100 1000 100000\n', 'expected': '100000\n'},
        {'input': '4\n27 1828 1828 9242\n', 'expected': '1828\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _row(line: str, count: int, pattern: re.Pattern[str]) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate233(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    lr = _row(lines[0], 2, POS)
    l, r = lr
    s = lines[1]
    if LOWER.fullmatch(s) is None or not 1 <= len(s) <= 100_000:
        raise ValueError('S')
    if not 1 <= l <= r <= len(s):
        raise ValueError('L/R')
    return l, r, s


def _validate234(raw: str):
    lines = _canonical_lines(raw)
    if not lines or POS.fullmatch(lines[0]) is None:
        raise ValueError('N')
    n = int(lines[0])
    if not 2 <= n <= 100 or len(lines) != n + 1:
        raise ValueError('N/shape')
    pts = []
    seen = set()
    for line in lines[1:]:
        x, y = _row(line, 2, SIGNED)
        if not (-1000 <= x <= 1000 and -1000 <= y <= 1000):
            raise ValueError('coordinate range')
        if (x, y) in seen:
            raise ValueError('duplicate point')
        seen.add((x, y))
        pts.append((x, y))
    return tuple(pts)


def _validate235(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 2 <= n <= 100_000:
        raise ValueError('N')
    hs = _row(lines[1], n, POS)
    if any(not 1 <= h <= 1_000_000_000 for h in hs):
        raise ValueError('H')
    return tuple(hs)


def validate(pid: str, raw: str):
    if pid == 'abc233_b':
        return _validate233(raw)
    if pid == 'abc234_b':
        return _validate234(raw)
    if pid == 'abc235_b':
        return _validate235(raw)
    raise ValueError('unknown task')


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc233_b':
        l, r, s = value
        expected = ''.join(s[i] if i < l - 1 or i >= r else s[l + r - 2 - i] for i in range(len(s)))
        return output == expected

    if pid == 'abc234_b':
        try:
            actual = Decimal(output)
        except InvalidOperation:
            return False
        if not actual.is_finite() or actual < 0:
            return False
        pts = value
        max_sq = max((x1-x2)**2 + (y1-y2)**2
                     for i, (x1, y1) in enumerate(pts)
                     for x2, y2 in pts[i+1:])
        with localcontext() as ctx:
            ctx.prec = 90
            truth = Decimal(max_sq).sqrt()
            diff = abs(actual - truth)
            tolerance = Decimal('1e-6')
            return diff <= tolerance or diff <= abs(truth) * tolerance

    hs = value
    index = 0
    while index + 1 < len(hs) and hs[index] < hs[index + 1]:
        index += 1
    return POS.fullmatch(output) is not None and int(output) == hs[index]


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc233_b':
        cases = [
            ('single_char', '1 1\na\n'),
            ('first_two', '1 2\nab\n'),
            ('last_two', '4 5\nabcde\n'),
            ('middle_odd', '2 4\nabcde\n'),
            ('whole_even', '1 6\nabcdef\n'),
            ('whole_palindrome', '1 5\nabcba\n'),
            ('same_char_segment', '2 4\naaaab\n'),
            ('one_char_inside', '3 3\nabcdef\n'),
            ('repeated_pattern', '2 7\nabababab\n'),
            ('edge_right', '5 9\nabcdefghi\n'),
            ('len26', '5 22\nabcdefghijklmnopqrstuvwxyz\n'),
            ('len99_full', '1 99\n' + 'a'*98 + 'b\n'),
            ('len1000_middle', '101 900\n' + ('abcd'*250) + '\n'),
            ('len99999_tail', '99990 99999\n' + 'x'*99998 + 'y\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '1 100000\n' + ('abcdefghijklmnopqrstuvwxyz' * 3846 + 'abcd')[:100000] + '\n')

    elif pid == 'abc234_b':
        cases = [
            ('two_horizontal', '2\n0 0\n1 0\n'),
            ('two_vertical', '2\n0 0\n0 -7\n'),
            ('two_diagonal', '2\n-3 -4\n3 4\n'),
            ('negative_quadrant', '3\n-1 -1\n-2 -5\n-9 -2\n'),
            ('axis_extremes', '4\n-1000 0\n1000 0\n0 -1000\n0 1000\n'),
            ('corner_extremes', '4\n-1000 -1000\n-1000 1000\n1000 -1000\n1000 1000\n'),
            ('close_points', '3\n1 1\n1 2\n2 1\n'),
            ('line_points', '5\n-2 -2\n-1 -1\n0 0\n1 1\n2 2\n'),
            ('mixed_six', '6\n7 3\n-8 1\n4 -9\n11 12\n0 0\n-5 -6\n'),
            ('n20_grid', '20\n' + ''.join(f'{i} {i*i%17}\n' for i in range(20))),
            ('n50_curve', '50\n' + ''.join(f'{i-25} {(i*i*7)%101-50}\n' for i in range(50))),
            ('n99_unique', '99\n' + ''.join(f'{i-49} {500-i}\n' for i in range(99))),
            ('near_max_coords', '3\n999 1000\n-1000 -999\n0 1\n'),
            ('large_asymmetric', '5\n-1000 777\n999 -888\n123 456\n-321 654\n0 0\n'),
            ('n100_sparse', '100\n' + ''.join(f'{-1000+20*i} {-999+19*i}\n' for i in range(100))),
        ]
        for category, raw in cases:
            add(category, raw)
        points = []
        for i in range(100):
            x = -1000 + (i % 50) * 40
            y = -1000 if i < 50 else 1000
            points.append((x, y))
        add('constraint_max', '100\n' + ''.join(f'{x} {y}\n' for x, y in points))

    else:
        cases = [
            ('two_increasing', '2\n1 2\n'),
            ('two_decreasing', '2\n2 1\n'),
            ('two_equal', '2\n5 5\n'),
            ('stop_second', '4\n1 9 9 10\n'),
            ('strict_all', '6\n1 2 3 4 5 6\n'),
            ('stop_early', '6\n10 20 5 100 200 300\n'),
            ('starts_max', '5\n100 1 2 3 4\n'),
            ('equal_after_rise', '5\n1 2 3 3 100\n'),
            ('large_heights', '4\n999999998 999999999 1000000000 1\n'),
            ('alternating', '8\n1 3 2 4 3 5 4 6\n'),
            ('n20_rise_then_fall', '20\n' + ' '.join(map(str, list(range(1,11)) + list(range(10,0,-1)))) + '\n'),
            ('n100_flat', '100\n' + ' '.join(['42']*100) + '\n'),
            ('n1000_increasing', '1000\n' + ' '.join(map(str, range(1,1001))) + '\n'),
            ('n99999_stop_last', '99999\n' + ' '.join(map(str, list(range(1,99999)) + [99998])) + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '100000\n' + ' '.join(map(str, range(999900001, 1000000001))) + '\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
