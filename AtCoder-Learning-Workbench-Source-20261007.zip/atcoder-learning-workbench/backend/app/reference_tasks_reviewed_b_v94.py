"""ABC140–142 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc140_b', 'abc141_b', 'abc142_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc140_b': [
        {'input':'3\n3 1 2\n2 5 4\n3 6\n','expected':'14\n'},
        {'input':'4\n2 3 4 1\n13 5 8 24\n45 9 15\n','expected':'74\n'},
        {'input':'2\n1 2\n50 50\n50\n','expected':'150\n'},
    ],
    'abc141_b': [
        {'input':'RUDLUDR\n','expected':'Yes\n'},
        {'input':'DULL\n','expected':'No\n'},
        {'input':'UUUUUUUUUUUUUUU\n','expected':'Yes\n'},
        {'input':'ULURU\n','expected':'No\n'},
        {'input':'RDULULDURURLRDULRLR\n','expected':'Yes\n'},
    ],
    'abc142_b': [
        {'input':'4 150\n150 140 100 200\n','expected':'2\n'},
        {'input':'1 500\n499\n','expected':'0\n'},
        {'input':'5 1\n100 200 300 400 500\n','expected':'5\n'},
    ],
}


def _ints(line: str, count: int, pattern=POS) -> list[int]:
    parts=line.split(' ')
    if len(parts)!=count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int,parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc140_b':
        if len(lines)!=4 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected four rows')
        n=int(lines[0])
        if not 2<=n<=20: raise ValueError('N range')
        a=_ints(lines[1],n); b=_ints(lines[2],n); c=_ints(lines[3],n-1)
        if sorted(a)!=list(range(1,n+1)): raise ValueError('A permutation')
        if any(not 1<=x<=50 for x in b+c): raise ValueError('B/C range')
        return n,a,b,c
    if pid=='abc141_b':
        if len(lines)!=1 or not 1<=len(lines[0])<=100 or any(ch not in 'LRUD' for ch in lines[0]):
            raise ValueError('S shape/range')
        return lines[0]
    if len(lines)!=2:
        raise ValueError('expected two rows')
    n,k=_ints(lines[0],2)
    if not 1<=n<=100000 or not 1<=k<=500: raise ValueError('N/K range')
    h=_ints(lines[1],n)
    if any(not 1<=x<=500 for x in h): raise ValueError('height range')
    return n,k,h


def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or output!=output.strip() or not output: return False
    if pid=='abc140_b':
        if NONNEG.fullmatch(output) is None: return False
        n,a,b,c=value
        ans=sum(b)
        for x,y in zip(a,a[1:]):
            if y==x+1: ans+=c[x-1]
        return output==str(ans)
    if pid=='abc141_b':
        s=value
        ok=all((i%2==0 and ch!='L') or (i%2==1 and ch!='R') for i,ch in enumerate(s))
        return output==('Yes' if ok else 'No')
    if NONNEG.fullmatch(output) is None: return False
    n,k,h=value
    return output==str(sum(x>=k for x in h))


def _abc140(n,a,b,c):
    return f"{n}\n"+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n'+' '.join(map(str,c))+'\n'

def _abc142(n,k,h):
    return f"{n} {k}\n"+' '.join(map(str,h))+'\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc140_b':
        fixed=[
          ('sample1',3,[3,1,2],[2,5,4],[3,6]),
          ('sample2',4,[2,3,4,1],[13,5,8,24],[45,9,15]),
          ('sample3',2,[1,2],[50,50],[50]),
          ('minimum_reverse',2,[2,1],[1,1],[1]),
          ('minimum_bonus',2,[1,2],[1,1],[1]),
          ('n3_no_bonus',3,[3,2,1],[1,2,3],[4,5]),
          ('n3_two_bonus',3,[1,2,3],[3,2,1],[4,5]),
          ('one_bonus_front',4,[1,2,4,3],[10,20,30,40],[1,2,3]),
          ('one_bonus_back',4,[4,2,3,1],[1,1,1,1],[9,8,7]),
          ('mixed5',5,[2,3,1,5,4],[5,4,3,2,1],[10,20,30,40]),
          ('ascending5',[5,[1,2,3,4,5],[1]*5,[1]*4][0],[1,2,3,4,5],[1]*5,[1]*4),
          ('descending5',5,[5,4,3,2,1],[50]*5,[50]*4),
          ('zigzag6',6,[1,3,2,4,6,5],[2,4,6,8,10,12],[1,3,5,7,9]),
          ('all_bonus10',10,list(range(1,11)),list(range(1,11)),[50]*9),
          ('no_bonus10',10,list(range(10,0,-1)),[50]*10,[50]*9),
          ('perm10',10,[2,1,4,3,6,5,8,7,10,9],[7]*10,[11]*9),
          ('n19',19,list(range(2,20))+[1],[i%50+1 for i in range(19)],[50-i for i in range(18)]),
        ]
        for cat,n,a,b,c in fixed: add(cat,_abc140(n,a,b,c))
        add('constraint_max',_abc140(20,list(range(1,21)),[50]*20,[50]*19))
    elif pid=='abc141_b':
        vals=[
          ('sample1','RUDLUDR'),('sample2','DULL'),('sample3','UUUUUUUUUUUUUUU'),
          ('sample4','ULURU'),('sample5','RDULULDURURLRDULRLR'),
          ('min_R','R'),('min_U','U'),('min_D','D'),('min_bad','L'),
          ('len2_yes','RL'),('len2_yes_ud','UD'),('len2_bad_even','RR'),
          ('len3_bad_odd','RLL'),('len4_yes','RLRL'),('all_D_20','D'*20),
          ('alternating_99','RL'*49+'R'),('almost_max_bad','U'*98+'L'+'U'),
        ]
        for cat,s in vals: add(cat,s+'\n')
        add('constraint_max','U'*100+'\n')
    else:
        vals=[
          ('sample1',4,150,[150,140,100,200]),('sample2',1,500,[499]),('sample3',5,1,[100,200,300,400,500]),
          ('single_equal',1,1,[1]),('single_max_equal',1,500,[500]),('single_below',1,2,[1]),
          ('all_below',4,500,[1,100,200,499]),('all_equal',4,250,[250]*4),('all_above',4,250,[251,300,400,500]),
          ('boundary_mix',5,300,[299,300,301,1,500]),('k1_min',3,1,[1,1,1]),('k500_mix',3,500,[500,499,500]),
          ('n10_half',10,250,[100,200,249,250,251,300,1,500,249,250]),
          ('n20_pattern',20,100,[50,100,150,99,101]*4),('n99_equal',99,333,[333]*99),
          ('n100_alt',100,400,[399,400]*50),('large_99999',99999,500,[499]*99998+[500]),
        ]
        for cat,n,k,h in vals: add(cat,_abc142(n,k,h))
        add('constraint_max',_abc142(100000,500,[500]*100000))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
