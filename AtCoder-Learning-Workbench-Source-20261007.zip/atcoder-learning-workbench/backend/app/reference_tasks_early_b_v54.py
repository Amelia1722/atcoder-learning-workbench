"""ABC021–023 B: manually reviewed public statements, not authenticated HTML originals."""
from __future__ import annotations
import random
import re
from collections import Counter

TASKS = ('abc021_b', 'abc022_b', 'abc023_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)


def _positive(token: str) -> int:
    if not POS.fullmatch(token):
        raise ValueError('integer lexeme invalid')
    return int(token)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('unknown problem or input format')
    rows = raw[:-1].split('\n')
    if pid == 'abc021_b':
        if len(rows) != 4:
            raise ValueError('expected four input lines')
        n = _positive(rows[0]); k = _positive(rows[2])
        pair = rows[1].split(' '); intermediate = rows[3].split(' ')
        if len(pair) != 2 or len(intermediate) != k:
            raise ValueError('wrong a,b or K lengths')
        a, b = map(_positive, pair)
        path = list(map(_positive, intermediate))
        if not 2 <= n <= 100 or not 1 <= k <= 100 or not (1 <= a <= n and 1 <= b <= n and a != b):
            raise ValueError('N/K/a/b outside constraints')
        if any(not 1 <= p <= n for p in path) or path[0] == a or path[-1] == b:
            raise ValueError('path bounds or endpoint adjacency')
        if any(path[i] == path[i-1] for i in range(1, k)):
            raise ValueError('adjacent intermediate towns must differ')
        return n, a, b, path
    if pid == 'abc022_b':
        if not rows:
            raise ValueError('missing N')
        n = _positive(rows[0])
        if not 1 <= n <= 100_000 or len(rows) != n+1:
            raise ValueError('flower count outside constraints')
        flowers = [_positive(x) for x in rows[1:]]
        if any(x > 100_000 for x in flowers):
            raise ValueError('flower kind outside constraints')
        return flowers
    if len(rows) != 2:
        raise ValueError('expected N and S')
    n = _positive(rows[0]); s = rows[1]
    if not 1 <= n <= 100 or not re.fullmatch(r'[a-z]{1,100}', s, re.ASCII) or len(s) != n:
        raise ValueError('N or lowercase string outside constraints')
    return s


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError):
        return False
    if not isinstance(output, str) or not re.fullmatch(r'(0|[1-9][0-9]*|-[1-9][0-9]*|YES|NO)', output, re.ASCII):
        return False
    if pid == 'abc021_b':
        _, a, b, path = value
        return output == ('YES' if len(set([a, b, *path])) == len(path) + 2 else 'NO')
    if pid == 'abc022_b':
        # Frequency surplus is independent of the reference solution's streaming set.
        counts = Counter(value)
        return output == str(sum(freq-1 for freq in counts.values()))
    s = value
    if len(s) % 2 == 0:
        return output == '-1'
    steps = (len(s)-1)//2
    if s[steps] != 'b':
        return output == '-1'
    for i in range(1, steps+1):
        left, right = s[steps-i], s[steps+i]
        if (left, right) != (('a','c'), ('c','a'), ('b','b'))[(i-1)%3]:
            return output == '-1'
    return output == str(steps)


def generate(pid: str, seed: int = 54) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown problem')
    rng = random.Random(f'abc-v54:{pid}:{seed}')
    cases: list[dict[str, str]] = []; seen: set[str] = set()
    def add(category: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            cases.append({'category':category,'input':raw}); seen.add(raw)
    if pid == 'abc021_b':
        def fmt(n,a,b,p): return f'{n}\n{a} {b}\n{len(p)}\n'+ ' '.join(map(str,p))+'\n'
        presets = [
            (3,1,3,[2]), (3,1,3,[3,2]), (3,1,3,[2,1]),
            (5,1,5,[3,4,2]), (7,1,3,[2,4,2,7]),
            (4,1,4,[2,1,3]), (4,1,4,[2,4,3]),
            (5,1,5,[2,3,4]), (3,2,3,[1]), (3,3,2,[1]),
            (100,1,100,list(range(2,100))),
            (100,1,100,list(range(2,100))+[2]),
            (100,98,100,list(range(1,99))+[99,1]),
        ]
        for n,a,b,p in presets: add('boundary' if n in (2,100) else 'normal',fmt(n,a,b,p))
        while len(cases) < 17:
            n=rng.randint(3,100); a,b=rng.sample(range(1,n+1),2)
            k=rng.randint(1,100); p=[]
            for i in range(k):
                excluded={a} if i==0 else {p[-1]}
                if i==k-1: excluded.add(b)
                allowed=[v for v in range(1,n+1) if v not in excluded]
                if not allowed: break
                p.append(rng.choice(allowed))
            if len(p)==k: add('random',fmt(n,a,b,p))
        add('constraint_max', fmt(100,99,100,list(range(1,99))+[99,1]))
    elif pid == 'abc022_b':
        def fmt(p): return str(len(p))+'\n'+''.join(str(x)+'\n' for x in p)
        presets=[[1],[100000],[1,1],[1,2,3,2,1], [3,1,4,1,5,9,2,6,5,3,5],
                 [1]*20,list(range(1,100)),[1,100000,1,100000],
                 [100000-i for i in range(100)], [1]*999, list(range(1,1001)),
                 [i%9+1 for i in range(1000)], [i%500+1 for i in range(10000)]]
        for p in presets: add('boundary' if len(p)==1 else 'normal',fmt(p))
        while len(cases)<17:
            n=rng.randint(1,1000)
            p=[rng.choice([1,100000,rng.randint(1,100000)]) for _ in range(n)]
            add('random',fmt(p))
        add('constraint_max',fmt([1+(i%100000) for i in range(100000)]))
    else:
        def fmt(s): return str(len(s))+'\n'+s+'\n'
        def construct(k):
            s='b'
            for i in range(1,k+1):
                l,r=(('a','c'),('c','a'),('b','b'))[(i-1)%3]
                s=l+s+r
            return s
        words=['b','a','c','abc','cabca','bcabcab','abcabc','atcoder',
               construct(9),construct(49),'b'*100,'a'*100,'a'*99+'b',
               'abc'*33+'a', 'q', 'a'*2+'b', 'c'*51+'a'*49]
        for s in words: add('boundary' if len(s) in (1,100) else 'normal',fmt(s))
        while len(cases)<17:
            n=rng.randint(1,100)
            s=''.join(rng.choice('abcxyz') for _ in range(n))
            add('random',fmt(s))
        add('constraint_max',fmt(construct(49)+'z'))
    if len(cases)!=18 or cases[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases, got {len(cases)}')
    return cases
