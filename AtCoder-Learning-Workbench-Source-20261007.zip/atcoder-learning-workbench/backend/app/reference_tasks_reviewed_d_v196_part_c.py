"""Private ABC329..334 D; official missing316 and old ready295 protected."""
from __future__ import annotations
from typing import cast
from dataclasses import dataclass
from collections import deque
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(329,335));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
    if pid=='abc329_d':
        n,m=ints(r[0],2);require(1<=n<=200000 and 1<=m<=200000 and len(r)==2,'shape');a=ints(r[1],m);require(all(1<=v<=n for v in a),'votes');return n,a
    if pid=='abc330_d':
        n=ints(r[0],1)[0];grid=tuple(r[1:]);require(2<=n<=2000 and len(grid)==n and all(re.fullmatch('[ox]{'+str(n)+'}',s) for s in grid),'grid');return (grid,)
    if pid=='abc331_d':
        n,q=ints(r[0],2);require(1<=n<=1000 and 1<=q<=200000 and len(r)==1+n+q,'shape');grid=tuple(r[1:n+1]);require(all(re.fullmatch('[BW]{'+str(n)+'}',s) for s in grid),'tile');queries=tuple(ints(s,4) for s in r[n+1:]);require(all(0<=a<=c<10**9 and 0<=b<=d<10**9 for a,b,c,d in queries),'rectangle');return grid,queries
    if pid=='abc332_d':
        h,w=ints(r[0],2);require(2<=h<=5 and 2<=w<=5 and len(r)==1+2*h,'shape');rows=tuple(ints(s,w) for s in r[1:]);require(all(1<=v<=10**9 for row in rows for v in row),'values');return h,w,rows[:h],rows[h:]
    if pid=='abc333_d':
        n=ints(r[0],1)[0];require(2<=n<=300000 and len(r)==n,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=u<v<=n for u,v in edges),'ordered endpoints');parent=list(range(n));size=[1]*n
        def root(j:int)->int:
            while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
            return j
        for u,v in edges:
            a,b=root(u-1),root(v-1);require(a!=b,'tree cycle')
            if size[a]<size[b]:a,b=b,a
            parent[b]=a;size[a]+=size[b]
        return n,edges
    n,q=ints(r[0],2);require(1<=n<=200000 and 1<=q<=200000 and len(r)==q+2,'shape');costs=ints(r[1],n);budgets=tuple(ints(s,1)[0] for s in r[2:]);require(all(1<=v<=10**9 for v in costs) and all(1<=v<=2*10**14 for v in budgets),'cost/budget');return costs,budgets

def election_heap(n:int,a:tuple[int,...])->list[int]:
    count=[0]*n;heap=[];out=[]
    for candidate in a:
        count[candidate-1]+=1;heapq.heappush(heap,(-count[candidate-1],candidate));out.append(heap[0][1])
    return out

def graph_three_edge_walks(grid:tuple[str,...])->int:
    n=len(grid);column_degrees=[sum(grid[i][j]=='o' for i in range(n)) for j in range(n)];answer=0
    for row in grid:
        incoming=[column_degrees[j]-1 for j,c in enumerate(row) if c=='o'];total=sum(incoming)
        # Extend each two-edge row-column-row walk through another column.
        answer+=sum(total-value for value in incoming)
    return answer

def periodic_rectangles(grid:tuple[str,...],queries:tuple[tuple[int,...],...])->list[int]:
    n=len(grid);prefix=[[0]*(n+1) for _ in range(n+1)]
    for i,row in enumerate(grid):
        running=0
        for j,c in enumerate(row):running+=c=='B';prefix[i+1][j+1]=prefix[i][j+1]+running
    def pieces(start:int,end:int)->list[tuple[int,int,int]]:
        length=end-start+1;periods,extra=divmod(length,n);result=[(0,n,periods)] if periods else [];offset=start%n;stop=offset+extra
        if extra:
            if stop<=n:result.append((offset,stop,1))
            else:result.extend([(offset,n,1),(0,stop-n,1)])
        return result
    out=[]
    for a,b,c,d in queries:
        answer=0
        for lo,hi,count in pieces(a,c):
            for left,right,multiple in pieces(b,d):answer+=count*multiple*(prefix[hi][right]-prefix[lo][right]-prefix[hi][left]+prefix[lo][left])
        out.append(answer)
    return out

def swapping_bfs(h:int,w:int,a:tuple[tuple[int,...],...],b:tuple[tuple[int,...],...])->int:
    initial=tuple(v for row in a for v in row);target=tuple(v for row in b for v in row)
    if sorted(initial)!=sorted(target):return -1
    distance={initial:0};queue=deque([initial])
    while queue:
        state=queue.popleft();steps=distance[state]
        if state==target:return steps
        for i in range(h-1):
            nxt=list(state);start=i*w;nxt[start:start+2*w]=state[start+w:start+2*w]+state[start:start+w];key=tuple(nxt)
            if key not in distance:distance[key]=steps+1;queue.append(key)
        for j in range(w-1):
            nxt=list(state)
            for i in range(h):left=i*w+j;nxt[left],nxt[left+1]=nxt[left+1],nxt[left]
            key=tuple(nxt)
            if key not in distance:distance[key]=steps+1;queue.append(key)
    return -1

def leaf_messages(n:int,edges:tuple[tuple[int,...],...])->int:
    graph=[[] for _ in range(n)]
    for u,v in edges:graph[u-1].append(v-1);graph[v-1].append(u-1)
    degree=[len(row) for row in graph];weight=[1]*n;queue=deque(j for j in range(1,n) if degree[j]==1);branches=[]
    while queue:
        leaf=queue.popleft();degree[leaf]=0
        for neighbor in graph[leaf]:
            if degree[neighbor]==0:continue
            if neighbor==0:branches.append(weight[leaf]);degree[0]-=1
            else:
                weight[neighbor]+=weight[leaf];degree[neighbor]-=1
                if degree[neighbor]==1:queue.append(neighbor)
            break
    return n-max(branches)

@dataclass(slots=True)
class CostNode:
    count:int
    total:int
    value:int
    left:CostNode|None=None
    right:CostNode|None=None

def cost_trie(values:tuple[int,...])->CostNode:
    def build(a:list[int],bit:int)->CostNode:
        node=CostNode(len(a),sum(a),a[0])
        if min(a)==max(a):return node
        while bit>=0:
            low=[v for v in a if not v>>bit&1];high=[v for v in a if v>>bit&1]
            if low and high:node.left=build(low,bit-1);node.right=build(high,bit-1);return node
            bit-=1
        raise AssertionError('different values share all bits')
    return build(list(values),29)

def affordable_trie(node:CostNode,budget:int)->int:
    if node.total<=budget:return node.count
    if node.left is None:return min(node.count,budget//node.value)
    assert node.right is not None
    if node.left.total>budget:return affordable_trie(node.left,budget)
    return node.left.count+affordable_trie(node.right,budget-node.left.total)

def oracle(pid:str,raw:str)->str:
    d=validate(pid,raw)
    if pid=='abc329_d':return '\n'.join(map(str,election_heap(cast(int,d[0]),cast(tuple[int,...],d[1]))))
    if pid=='abc330_d':return str(graph_three_edge_walks(cast(tuple[str,...],d[0])))
    if pid=='abc331_d':return '\n'.join(map(str,periodic_rectangles(cast(tuple[str,...],d[0]),cast(tuple[tuple[int,...],...],d[1]))))
    if pid=='abc332_d':return str(swapping_bfs(cast(int,d[0]),cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2]),cast(tuple[tuple[int,...],...],d[3])))
    if pid=='abc333_d':return str(leaf_messages(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))
    node=cost_trie(cast(tuple[int,...],d[0]));return '\n'.join(str(affordable_trie(node,budget)) for budget in cast(tuple[int,...],d[1]))
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:return output_mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={'abc329_d': "n,m=map(int,input().split());a=list(map(int,input().split()));count=[0]*(n+1);leader=1;out=[]\nfor x in a:\n count[x]+=1\n if count[x]>count[leader] or count[x]==count[leader] and x<leader:leader=x\n out.append(str(leader))\nprint('\\n'.join(out))\n", 'abc330_d': "n=int(input());g=[input() for _ in range(n)];rows=[row.count('o') for row in g];cols=[sum(g[i][j]=='o' for i in range(n)) for j in range(n)];answer=0\nfor i in range(n):\n for j in range(n):\n  if g[i][j]=='o':answer+=(rows[i]-1)*(cols[j]-1)\nprint(answer)\n", 'abc331_d': "import sys\nn,q=map(int,input().split());g=[input() for _ in range(n)];p=[[0]*(n+1) for _ in range(n+1)]\nfor i in range(n):\n for j in range(n):p[i+1][j+1]=p[i][j+1]+p[i+1][j]-p[i][j]+(g[i][j]=='B')\ndef prefix(h,w):\n a,b=divmod(h,n);c,d=divmod(w,n);return a*c*p[n][n]+a*p[n][d]+c*p[b][n]+p[b][d]\nout=[]\nfor _ in range(q):\n a,b,c,d=map(int,input().split());c+=1;d+=1;out.append(str(prefix(c,d)-prefix(a,d)-prefix(c,b)+prefix(a,b)))\nprint('\\n'.join(out))\n", 'abc332_d': 'from itertools import permutations\nh,w=map(int,input().split());a=[list(map(int,input().split())) for _ in range(h)];b=[list(map(int,input().split())) for _ in range(h)]\ndef inversions(order):return sum(x>y for i,x in enumerate(order) for y in order[i+1:])\nanswer=100\nfor rows in permutations(range(h)):\n for cols in permutations(range(w)):\n  if all(a[rows[i]][cols[j]]==b[i][j] for i in range(h) for j in range(w)):answer=min(answer,inversions(rows)+inversions(cols))\nprint(-1 if answer==100 else answer)\n', 'abc333_d': 'import sys\nn=int(input());g=[[] for _ in range(n)]\nfor _ in range(n-1):u,v=map(int,input().split());u-=1;v-=1;g[u].append(v);g[v].append(u)\nmaximum=0\nfor neighbor in g[0]:\n stack=[(neighbor,0)];count=0\n while stack:\n  u,parent=stack.pop();count+=1\n  for v in g[u]:\n   if v!=parent:stack.append((v,u))\n maximum=max(maximum,count)\nprint(n-maximum)\n', 'abc334_d': "from bisect import bisect_right\nn,q=map(int,input().split());a=sorted(map(int,input().split()));prefix=[0]\nfor x in a:prefix.append(prefix[-1]+x)\nprint('\\n'.join(str(bisect_right(prefix,int(input()))-1) for _ in range(q)))\n"}
TITLES:dict[str,str]={'abc329_d': 'Election Quick Report', 'abc330_d': 'Counting Ls', 'abc331_d': 'Tile Pattern', 'abc332_d': 'Swapping Puzzle', 'abc333_d': 'Erase Leaves', 'abc334_d': 'Reindeer and Sleigh'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'abc329_d': [{'input': '3 7\n1 2 2 3 1 3 3\n', 'expected': '1\n1\n2\n2\n1\n1\n3\n'}, {'input': '100 5\n100 90 80 70 60\n', 'expected': '100\n90\n80\n70\n60\n'}, {'input': '9 8\n8 8 2 2 8 8 2 2\n', 'expected': '8\n8\n8\n2\n8\n8\n8\n2\n'}], 'abc330_d': [{'input': '3\nooo\noxx\nxxo\n', 'expected': '4\n'}, {'input': '4\noxxx\nxoxx\nxxox\nxxxo\n', 'expected': '0\n'}, {'input': '15\nxooxxooooxxxoox\noxxoxoxxxoxoxxo\noxxoxoxxxoxoxxx\nooooxooooxxoxxx\noxxoxoxxxoxoxxx\noxxoxoxxxoxoxxo\noxxoxooooxxxoox\nxxxxxxxxxxxxxxx\nxooxxxooxxxooox\noxxoxoxxoxoxxxo\nxxxoxxxxoxoxxoo\nxooxxxooxxoxoxo\nxxxoxxxxoxooxxo\noxxoxoxxoxoxxxo\nxooxxxooxxxooox\n', 'expected': '2960\n'}], 'abc331_d': [{'input': '3 2\nWWB\nBBW\nWBW\n1 2 3 4\n0 3 4 5\n', 'expected': '4\n7\n'}, {'input': '10 5\nBBBWWWBBBW\nWWWWWBBBWB\nBBBWBBWBBB\nBBBWWBWWWW\nWWWWBWBWBW\nWBBWBWBBBB\nWWBBBWWBWB\nWBWBWWBBBB\nWBWBWBBWWW\nWWWBWWBWWB\n5 21 21 93\n35 35 70 43\n55 72 61 84\n36 33 46 95\n0 0 999999999 999999999\n', 'expected': '621\n167\n44\n344\n500000000000000000\n'}], 'abc332_d': [{'input': '4 5\n1 2 3 4 5\n6 7 8 9 10\n11 12 13 14 15\n16 17 18 19 20\n1 3 2 5 4\n11 13 12 15 14\n6 8 7 10 9\n16 18 17 20 19\n', 'expected': '3\n'}, {'input': '2 2\n1 1\n1 1\n1 1\n1 1000000000\n', 'expected': '-1\n'}, {'input': '3 3\n8 1 6\n3 5 7\n4 9 2\n8 1 6\n3 5 7\n4 9 2\n', 'expected': '0\n'}, {'input': '5 5\n710511029 136397527 763027379 644706927 447672230\n979861204 57882493 442931589 951053644 152300688\n43971370 126515475 962139996 541282303 834022578\n312523039 506696497 664922712 414720753 304621362\n325269832 191410838 286751784 732741849 806602693\n806602693 732741849 286751784 191410838 325269832\n304621362 414720753 664922712 506696497 312523039\n834022578 541282303 962139996 126515475 43971370\n152300688 951053644 442931589 57882493 979861204\n447672230 644706927 763027379 136397527 710511029\n', 'expected': '20\n'}], 'abc333_d': [{'input': '9\n1 2\n2 3\n2 4\n2 5\n1 6\n6 7\n7 8\n7 9\n', 'expected': '5\n'}, {'input': '6\n1 2\n2 3\n2 4\n3 5\n3 6\n', 'expected': '1\n'}, {'input': '24\n3 6\n7 17\n7 20\n7 11\n14 18\n17 21\n6 19\n5 22\n9 24\n11 14\n6 23\n8 17\n9 12\n4 17\n2 15\n1 17\n3 9\n10 16\n7 13\n2 16\n1 16\n5 7\n1 3\n', 'expected': '12\n'}], 'abc334_d': [{'input': '4 3\n5 3 11 8\n16\n7\n1000\n', 'expected': '3\n1\n4\n'}, {'input': '6 6\n1 2 3 4 5 6\n1\n2\n3\n4\n5\n6\n', 'expected': '1\n1\n2\n2\n2\n3\n'}, {'input': '2 2\n1000000000 1000000000\n200000000000000\n1\n', 'expected': '2\n0\n'}]}
SAMPLE_COUNTS={pid:len(cases) for pid,cases in PUBLISHED_SAMPLES.items()}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(int(pid[3:6]));raws:list[str]=[]
    if pid=='abc329_d':
        def pack(n:int,a:list[int])->str:return line((n,len(a)))+line(a)
        raws=[pack(1,[1]),pack(2,[2,1]),pack(3,[3,2,1,3,2,1]),pack(2,[1,2,2,1])]
        for j in range(12):raws.append(pack(j+3,[rng.randint(1,j+3) for _ in range(j+7)]))
        raws.extend([pack(200000,list(range(200000,0,-1))),pack(200000,[200000]*200000)])
    elif pid=='abc330_d':
        def pack(grid:list[str])->str:return f'{len(grid)}\n'+'\n'.join(grid)+'\n'
        raws=[pack(['oo','oo']),pack(['xx','xx']),pack(['oo','ox']),pack(['ox','xo'])]
        for j in range(12):raws.append(pack([''.join(rng.choice('ox') for _ in range(j+3)) for _ in range(j+3)]))
        raws.extend([pack([''.join('o' if (i+j)%2 else 'x' for j in range(2000)) for i in range(2000)]),pack(['o'*2000]*2000)])
    elif pid=='abc331_d':
        def pack(grid:list[str],q:list[tuple[int,int,int,int]])->str:return line((len(grid),len(q)))+'\n'.join(grid)+'\n'+''.join(line(row) for row in q)
        raws=[pack(['B'],[(0,0,0,0)]),pack(['W'],[(0,0,999999999,999999999)]),pack(['BW','WB'],[(1,1,2,2),(0,0,3,4)]),pack(['B'],[(999999999,999999999,999999999,999999999)])]
        for j in range(12):
            n=j+3;grid=[''.join(rng.choice('BW') for _ in range(n)) for _ in range(n)];queries=[]
            for _ in range(j+1):
                a,c=sorted((rng.randrange(10**9),rng.randrange(10**9)));b,d=sorted((rng.randrange(10**9),rng.randrange(10**9)));queries.append((a,b,c,d))
            raws.append(pack(grid,queries))
        raws.extend([pack([''.join('B' if (i+j)%2 else 'W' for j in range(1000)) for i in range(1000)],[(j,199999-j,999999999-j,999999999) for j in range(200000)]),pack(['B'*1000]*1000,[(0,0,999999999,999999999)]*200000)])
    elif pid=='abc332_d':
        def pack(a:list[list[int]],b:list[list[int]])->str:return line((len(a),len(a[0])))+''.join(line(row) for row in a+b)
        raws=[pack([[1,1],[1,1]],[[1,1],[1,1]]),pack([[1,2],[3,4]],[[3,4],[1,2]]),pack([[1,2],[3,4]],[[1,3],[2,4]]),pack([[1,2],[3,4]],[[1,2],[3,5]])]
        for j in range(12):
            h=2+j%4;w=2+(j//4)%4;a=[[rng.randint(1,8) for _ in range(w)] for _ in range(h)];rows=list(range(h));cols=list(range(w));rng.shuffle(rows);rng.shuffle(cols);b=[[a[r][c] for c in cols] for r in rows];raws.append(pack(a,b))
        a=[[10**9-(i*5+j) for j in range(5)] for i in range(5)];raws.extend([pack(a,[list(reversed(row)) for row in reversed(a)]),pack([[10**9]*5 for _ in range(5)],[[10**9]*5 for _ in range(5)])])
    elif pid=='abc333_d':
        def pack(n:int,edges:list[tuple[int,int]])->str:return f'{n}\n'+''.join(line(row) for row in edges)
        raws=[pack(2,[(1,2)]),pack(3,[(1,2),(1,3)]),pack(3,[(1,2),(2,3)]),pack(5,[(1,2),(1,3),(2,4),(3,5)])]
        for j in range(12):
            n=j+6;raws.append(pack(n,[(rng.randint(1,i-1),i) for i in range(2,n+1)]))
        raws.extend([pack(300000,[(j,j+1) for j in range(1,300000)]),pack(300000,[(1,j) for j in range(2,300001)])])
    else:
        def pack(costs:list[int],budgets:list[int])->str:return line((len(costs),len(budgets)))+line(costs)+''.join(f'{v}\n' for v in budgets)
        raws=[pack([1],[1]),pack([2],[1]),pack([1,2,3],[1,2,3,4,5,6]),pack([10**9],[2*10**14])]
        for j in range(12):raws.append(pack([rng.randint(1,10**9) for _ in range(j+3)],[rng.randint(1,2*10**14) for _ in range(j+1)]))
        raws.extend([pack([1+(j*5003)%10**9 for j in range(200000)],[1+(j*1000000007)%(2*10**14) for j in range(200000)]),pack([10**9]*200000,[2*10**14]*200000)])
    require(len(raws)==len(set(raws))==18,'18 distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'random'} for j,raw in enumerate(raws)]
HINTS:dict[str,tuple[str,str,str]]={
'abc329_d':('一票増えると、当選者が変わる候補はその票の投票先だけです。','得票数と現在の当選者を持ちます。新しい票の候補が得票数で上回るか、同票で番号が小さい場合に更新します。','疑似コード: count全0、leader=1。各投票xでcount[x]++。count[x]>count[leader]または同票かつx<leaderならleader=x。毎回leaderを出力。'),
'abc330_d':('三つ組は、同じ行と同じ列の両方を持つ角のマスが一意に決まります。','角にoがあれば、同じ行の他のoと同じ列の他のoの選び方の積が、その角を持つ三つ組の数です。','疑似コード: 各行のo数R、各列のo数Cを集計。各oマス(i,j)について(R[i]-1)*(C[j]-1)を答えへ加え、総和を出力。'),
'abc331_d':('周期Nの盤面を、完全なタイルと端の部分へ分けます。','原点からの黒マス数F(h,w)を、完全タイル、余った行、余った列、右下の端に分けて求めます。長方形は四つのFの包除で得られます。','疑似コード: タイルの2D累積和Pを作る。h=an+b,w=cn+dならF=ac*P[n][n]+a*P[n][d]+c*P[b][n]+P[b][d]。queryはF(C+1,D+1)-F(A,D+1)-F(C+1,B)+F(A,B)。'),
'abc332_d':('行と列の最終的な並びを全て試せます。','行・列はそれぞれ5以下なので、各順列でAがBと一致するか調べます。隣接交換の最小回数は順列の転倒数です。','疑似コード: 全行順列rと全列順列cで、全マスA[r[i]][c[j]]==B[i][j]を検査。一致なら転倒数(r)+転倒数(c)で最小を更新。候補がなければ-1を出力。'),
'abc333_d':('頂点1を葉にするには、頂点1から出る枝を一つ以下へ減らします。','頂点1の隣の各枝の頂点数を求めます。最も大きい枝を残し、他の枝を葉から全て削除して最後に頂点1を削除します。','疑似コード: 頂点1の各隣接頂点から親を避けたDFSで枝の頂点数を数え、最大値Mを求める。答えはN-M。'),
'abc334_d':('少ないトナカイで引けるソリから選ぶと、台数を最大にできます。','必要数をソートして累積和を作ります。予算以下となる累積和の最後の位置を二分探索します。','疑似コード: Rをsortしてprefix[0]=0、prefix[i+1]=prefix[i]+R[i]を作る。各Xでupper_bound(prefix,X)-1を出力。')}
