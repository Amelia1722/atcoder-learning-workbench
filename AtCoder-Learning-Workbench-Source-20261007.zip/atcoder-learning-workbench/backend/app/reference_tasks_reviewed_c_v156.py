"""Turn133: eighteen reviewed C tasks; ABC039 has only seven valid inputs."""
from __future__ import annotations
from collections import Counter
from functools import lru_cache
from heapq import heappop, heappush
from itertools import combinations, product
from math import comb
import random
import re
from typing import cast

TASKS=tuple(f'abc{i:03}_c' for i in (26,27,28,*range(30,39),40,41))+('arc058_a','arc059_a','arc060_a','arc061_a')
NUMBERS={p:i for p,i in zip(TASKS,(26,27,28,*range(30,39),40,41,42,43,44,45))}
CONTESTS={p:f'abc{NUMBERS[p]:03}' for p in TASKS}
LANES={chr(65+i):TASKS[i*3:i*3+3] for i in range(6)}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank');i=NUMBERS[pid]
    if i==26:
        n,=ints(rows[0],1);parents=tuple(ints(r,1)[0] for r in rows[1:]);require(1<=n<=20 and len(parents)==n-1 and all(1<=p<j for j,p in enumerate(parents,2)),'hierarchy');return n,parents
    if i==27:
        require(len(rows)==1,'shape');n,=ints(rows[0],1);require(1<=n<=(10**18 if i==27 else 8),'size');return (n,)
    if i==28:
        require(len(rows)==1,'shape');a=ints(rows[0],5);require(1<=a[0] and a[-1]<=100 and all(a[j]<a[j+1] for j in range(4)),'sorted distinct');return (a,)
    if i==30:
        require(len(rows)==4,'shape');n,m=ints(rows[0],2);x,y=ints(rows[1],2);a=ints(rows[2],n);b=ints(rows[3],m)
        require(1<=n<=100000 and 1<=m<=100000 and 1<=x<=10**9 and 1<=y<=10**9 and all(1<=t<=10**9 for t in a+b) and all(v[j]<v[j+1] for v in (a,b) for j in range(len(v)-1)),'flights');return n,m,x,y,a,b
    if i==32:
        n,k=ints(rows[0],2);a=tuple(ints(r,1)[0] for r in rows[1:]);require(1<=n<=100000 and 0<=k<=10**9 and len(a)==n and all(0<=v<=10**9 for v in a),'product');return n,k,a
    if i==33:
        require(len(rows)==1 and len(rows[0])<=100000 and re.fullmatch(r'[0-9](?:[+*][0-9])*',rows[0]) is not None,'expression');return (rows[0],)
    if i==45:
        require(len(rows)==1 and re.fullmatch(r'[1-9]{1,10}',rows[0]) is not None,'digits');return (rows[0],)
    if i==34:
        require(len(rows)==1,'shape');w,h=ints(rows[0],2);require(2<=w<=100000 and 2<=h<=100000,'grid');return w,h
    if i==35:
        n,q=ints(rows[0],2);edges=tuple(ints(r,2) for r in rows[1:]);require(1<=n<=200000 and 1<=q<=200000 and len(edges)==q and all(1<=l<=r<=n for l,r in edges),'flips');return n,edges
    if i==36:
        n,=ints(rows[0],1);a=tuple(ints(r,1)[0] for r in rows[1:]);require(1<=n<=100000 and len(a)==n and all(0<=v<=10**9 for v in a),'compression');return n,a
    if i==42:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);banned=ints(rows[1],k)
        require(1<=n<10000 and 1<=k<10 and all(0<=v<=9 for v in banned) and tuple(sorted(set(banned)))==banned and banned!=tuple(range(1,10)),'digits');return n,banned
    require(len(rows)==2,'shape')
    if i in (37,44):n,k=ints(rows[0],2)
    else:n,=ints(rows[0],1);k=0
    a=ints(rows[1],n)
    bounds={31:(2,50,-50,50),37:(1,100000,0,10**8),38:(1,100000,1,100000),40:(2,100000,0,10000),41:(2,100000,1,10**9),43:(1,100,-100,100),44:(1,50,1,50)}
    lo,hi,low,high=bounds[i];require(lo<=n<=hi and all(low<=v<=high for v in a),'array')
    if i==37:require(1<=k<=n,'window')
    if i==41:require(len(set(a))==n,'distinct heights')
    if i==44:require(1<=k<=50,'average')
    return (n,k,a) if i in (37,44) else (n,a)

def _winning(n:int)->bool:
    # Propagate intervals of losing positions from leaves toward root; this is
    # independent of the reference's depth-parity optimal-move simulation.
    win:list[tuple[int,int]]=[];depth=n.bit_length()-1
    for d in range(depth,0,-1):
        low,high=1<<d,min(n,(1<<(d+1))-1);losing=[];cursor=low
        for l,r in win:
            if cursor<l:losing.append((cursor,l-1))
            cursor=r+1
        if cursor<=high:losing.append((cursor,high))
        mapped=sorted((l//2,r//2) for l,r in losing);win=[]
        for l,r in mapped:
            if win and l<=win[-1][1]+1:win[-1]=(win[-1][0],max(r,win[-1][1]))
            else:win.append((l,r))
    return any(l<=1<=r for l,r in win)

def _product_oracle(a:tuple[int,...],k:int)->int:
    if 0 in a:return len(a)
    # Queue with capped associative product aggregates, no inverse/division.
    front:list[tuple[int,int]]=[];back:list[tuple[int,int]]=[];size=answer=0
    def aggregate()->int:return min(k+1,(front[-1][1] if front else 1)*(back[-1][1] if back else 1))
    for x in a:
        back.append((x,min(k+1,x*(back[-1][1] if back else 1))));size+=1
        while size and aggregate()>k:
            if not front:
                while back:
                    v=back.pop()[0];front.append((v,min(k+1,v*(front[-1][1] if front else 1))))
            front.pop();size-=1
        answer=max(answer,size)
    return answer

@lru_cache(maxsize=512)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);i=NUMBERS[pid]
    if i==26:
        n,parents=cast(tuple[int,tuple[int,...]],data);children=[[] for _ in range(n)]
        for j,p in enumerate(parents,1):children[p-1].append(j)
        def salary(v:int)->int:
            values=[salary(u) for u in children[v]];return min(values)+max(values)+1 if values else 1
        return str(salary(0))
    if i==27:return 'Takahashi' if _winning(cast(int,data[0])) else 'Aoki'
    if i==28:
        a=cast(tuple[int,...],data[0]);values={sum(row) for row in combinations(a,3)}
        for _ in range(2):values.remove(max(values))
        return str(max(values))
    if i==29:
        n=cast(int,data[0]);rows=['']
        for _ in range(n):rows=[prefix+ch for prefix in rows for ch in 'abc']
        return '\n'.join(rows)
    if i==30:
        n,m,x,y,a,b=cast(tuple[int,int,int,int,tuple[int,...],tuple[int,...]],data)
        events=sorted([(v,0) for v in a]+[(v,1) for v in b]);airport=0;arrival=answer=0
        for time,place in events:
            if time>=arrival and place==airport:
                arrival=time+(x if airport==0 else y);airport^=1
                if airport==0:answer+=1
        return str(answer)
    if i==31:
        n,a=cast(tuple[int,tuple[int,...]],data);prefix=[[0]*(n+1) for _ in range(2)]
        for j,v in enumerate(a):
            for p in (0,1):prefix[p][j+1]=prefix[p][j]+(v if j%2==p else 0)
        scores=[]
        for first in range(n):
            candidates=[]
            for second in range(n):
                if second==first:continue
                l,r=sorted((first,second));t=prefix[l%2][r+1]-prefix[l%2][l];b=prefix[1-l%2][r+1]-prefix[1-l%2][l]
                candidates.append((b,-second,t))
            scores.append(max(candidates)[2])
        return str(max(scores))
    if i==32:
        n,k,a=cast(tuple[int,int,tuple[int,...]],data);return str(_product_oracle(a,k))
    if i==33:
        expression=cast(str,data[0]);answer=0;nonzero=True
        for ch in expression+'+':
            if ch=='0':nonzero=False
            elif ch=='+':answer+=nonzero;nonzero=True
        return str(answer)
    if i==34:
        w,h=cast(tuple[int,int],data);return str(comb(w+h-2,w-1)%1000000007)
    if i==35:
        n,intervals=cast(tuple[int,tuple[tuple[int,int],...]],data);events=sorted([x for l,r in intervals for x in (l,r+1)]);cursor=1;state=0;parts=[]
        for point in events:
            parts.append(str(state)*(point-cursor));cursor=point;state^=1
        parts.append(str(state)*(n+1-cursor));return ''.join(parts)
    if i==36:
        n,a=cast(tuple[int,tuple[int,...]],data);rows=sorted((v,j) for j,v in enumerate(a));result=[0]*n;rank=-1;previous=None
        for v,j in rows:
            if v!=previous:rank+=1;previous=v
            result[j]=rank
        return '\n'.join(map(str,result))
    if i==37:
        n,k,a=cast(tuple[int,int,tuple[int,...]],data);return str(sum(v*(min(j,n-k)-max(0,j-k+1)+1) for j,v in enumerate(a)))
    if i==38:
        n,a=cast(tuple[int,tuple[int,...]],data);runs=[];start=0
        for j in range(1,n):
            if a[j]<=a[j-1]:runs.append(j-start);start=j
        runs.append(n-start);return str(sum(r*(r+1)//2 for r in runs))
    if i==40:
        n,a=cast(tuple[int,tuple[int,...]],data);distance=[10**18]*n;distance[0]=0;heap=[(0,0)]
        while heap:
            cost,j=heappop(heap)
            if cost!=distance[j]:continue
            for u in (j+1,j+2):
                if u<n:
                    candidate=cost+abs(a[u]-a[j])
                    if candidate<distance[u]:distance[u]=candidate;heappush(heap,(candidate,u))
        return str(distance[-1])
    if i==41:
        n,a=cast(tuple[int,tuple[int,...]],data);heap=[]
        for j,v in enumerate(a,1):heappush(heap,(-v,j))
        return '\n'.join(str(heappop(heap)[1]) for _ in range(n))
    if i==42:
        n,banned=cast(tuple[int,tuple[int,...]],data);allowed=[str(v) for v in range(10) if v not in banned];bound=str(n)
        def search(prefix:str,length:int,tight:bool)->str|None:
            if len(prefix)==length:return prefix
            for ch in allowed:
                if not prefix and ch=='0':continue
                if tight and ch<bound[len(prefix)]:continue
                result=search(prefix+ch,length,tight and ch==bound[len(prefix)])
                if result is not None:return result
            return None
        for length in range(len(bound),len(bound)+2):
            answer=search('',length,length==len(bound))
            if answer is not None:return answer
        raise AssertionError('positive digit guaranteed')
    if i==43:
        n,a=cast(tuple[int,tuple[int,...]],data);middle=sum(a)//n;return str(min(sum((v-x)**2 for v in a) for x in (middle,middle+1)))
    if i==45:
        s=cast(str,data[0]);count=1;complete=0;tail=int(s[0])
        for digit in s[1:]:
            x=int(digit);complete=2*complete+tail;tail=10*tail+2*count*x;count*=2
        return str(complete+tail)
    n,average,a=cast(tuple[int,int,tuple[int,...]],data)
    if n<=16:return str(sum(sum(row)==len(row)*average for length in range(1,n+1) for row in combinations(a,length)))
    counts={0:1}
    for v in a:
        nxt=counts.copy()
        for total,count in counts.items():nxt[total+v-average]=nxt.get(total+v-average,0)+count
        counts=nxt
    return str(counts.get(0,0)-1)

def independent_check(pid:str,raw:str,actual:str)->bool:
    return actual.removesuffix('\n')==oracle(pid,raw)
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)

REFERENCE_CODE:dict[str,str]={}
def reference(i:int,body:str)->None:
    pid=next(p for p in TASKS if NUMBERS[p]==i)
    REFERENCE_CODE[pid]='from collections import Counter\nfrom itertools import combinations, product\nfrom bisect import bisect_left\nimport sys\n'+body.strip()+'\n'
reference(26,'''
n=int(input());salary=[1]*n;children=[[] for _ in range(n)]
for j in range(1,n):children[int(input())-1].append(j)
for j in range(n-1,-1,-1):
 if children[j]:salary[j]=min(salary[k] for k in children[j])+max(salary[k] for k in children[j])+1
print(salary[0])
''')
reference(27,'''
n=int(input());depth=n.bit_length()-1;x=1;turn=0
while x<=n:
 x=x*2+int(turn==depth%2);turn^=1
print('Takahashi' if turn==0 else 'Aoki')
''')
reference(28,"a=list(map(int,input().split()));print(sorted(set(map(sum,combinations(a,3))),reverse=True)[2])")

reference(30,'''
n,m=map(int,input().split());x,y=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));t=answer=0
while True:
 i=bisect_left(a,t)
 if i==n:break
 j=bisect_left(b,a[i]+x)
 if j==m:break
 t=b[j]+y;answer+=1
print(answer)
''')
reference(31,'''
n=int(input());a=list(map(int,input().split()));ans=-10**9
for i in range(n):
 best=-10**9;score=0
 for j in range(n):
  if j==i:continue
  l,r=sorted((i,j));part=a[l:r+1];other=sum(part[1::2])
  if other>best:best=other;score=sum(part[::2])
 ans=max(ans,score)
print(ans)
''')
reference(32,'''
n,k=map(int,input().split());a=[int(input()) for _ in range(n)]
if 0 in a:print(n)
else:
 left=ans=0;value=1
 for right,x in enumerate(a):
  value*=x
  while left<=right and value>k:value//=a[left];left+=1
  ans=max(ans,right-left+1)
 print(ans)
''')
reference(33,"print(sum('0' not in term for term in input().split('+')))")
reference(34,'''
w,h=map(int,input().split());mod=1000000007;factor=[1]*(w+h-1)
for i in range(1,len(factor)):factor[i]=factor[i-1]*i%mod
print(factor[w+h-2]*pow(factor[w-1],mod-2,mod)*pow(factor[h-1],mod-2,mod)%mod)
''')
reference(35,'''
n,q=map(int,input().split());diff=[0]*(n+1)
for _ in range(q):
 l,r=map(int,input().split());diff[l-1]^=1;diff[r]^=1
state=0;result=[]
for j in range(n):state^=diff[j];result.append(str(state))
print(''.join(result))
''')
reference(36,"n=int(input());a=[int(input()) for _ in range(n)];rank={v:j for j,v in enumerate(sorted(set(a)))};print('\\n'.join(str(rank[v]) for v in a))")
reference(37,'''
n,k=map(int,input().split());a=list(map(int,input().split()));current=sum(a[:k]);answer=current
for j in range(k,n):current+=a[j]-a[j-k];answer+=current
print(answer)
''')
reference(38,'''
n=int(input());a=list(map(int,input().split()));current=answer=1
for j in range(1,n):current=current+1 if a[j]>a[j-1] else 1;answer+=current
print(answer)
''')
reference(40,'''
n=int(input());a=list(map(int,input().split()));dp=[0]*n;dp[1]=abs(a[1]-a[0])
for j in range(2,n):dp[j]=min(dp[j-1]+abs(a[j]-a[j-1]),dp[j-2]+abs(a[j]-a[j-2]))
print(dp[-1])
''')
reference(41,"n=int(input());a=list(map(int,input().split()));print('\\n'.join(str(i+1) for i in sorted(range(n),key=lambda j:-a[j])))")
reference(42,'''
n,k=map(int,input().split());banned=set(input().split())
while set(str(n))&banned:n+=1
print(n)
''')
reference(43,"n=int(input());a=list(map(int,input().split()));print(min(sum((v-x)**2 for v in a) for x in range(-100,101)))")
reference(44,'''
n,a=map(int,input().split());xs=list(map(int,input().split()));dp={(0,0):1}
for x in xs:
 nxt=dp.copy()
 for (count,total),ways in dp.items():nxt[count+1,total+x]=nxt.get((count+1,total+x),0)+ways
 dp=nxt
print(sum(ways for (count,total),ways in dp.items() if count and total==count*a))
''')

reference(45,'''
s=input();ans=0
for mask in range(1<<(len(s)-1)):
 current=int(s[0]);total=0
 for j,digit in enumerate(s[1:]):
  if mask&(1<<j):total+=current;current=int(digit)
  else:current=current*10+int(digit)
 ans+=total+current
print(ans)
''')

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def column(a:list[int])->str:return ''.join(f'{v}\n' for v in a)
def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
def generate(pid:str)->list[Case]:
    i=NUMBERS[pid];rng=random.Random(15600+i);raws:list[str]=[]
    if i==26:
        raws=['1\n','2\n1\n','4\n1\n1\n1\n','4\n1\n2\n3\n']
        raws += [f'{n}\n'+column([rng.randrange(1,j) for j in range(2,n+1)]) for n in range(5,18)]
        maximum='20\n'+column(list(range(1,20)))
    elif i==27:
        raws=[f'{n}\n' for n in (1,2,3,4,5,6,7,8,15,16,17,31,32,33,2**59-1,2**59,2**59+1)];maximum=f'{10**18}\n'
    elif i==28:
        raws=[line([1,2,3,4,5]),line([1,2,3,98,99]),line([1,10,30,70,100]),line([10,20,30,40,50])]
        raws += [line(sorted(rng.sample(range(1,96),5))) for _ in range(13)];maximum=line([96,97,98,99,100])
    elif i==29:
        # Only eight canonical legal input values exist: this task shares the
        # finite-domain exception with ABC039; never fabricate 18 inputs.
        raise ValueError('ABC029 C has exactly eight valid inputs; domain exception required')
    elif i==30:
        def flights(a:list[int],b:list[int],x:int,y:int)->str:return f'{len(a)} {len(b)}\n{x} {y}\n'+line(a)+line(b)
        raws=[flights([1],[1],1,1),flights([1],[2],1,1),flights([1,3],[2,4],1,1),flights([1,2],[2,3],2,2)]
        raws += [flights(sorted(rng.sample(range(1,300),j+2)),sorted(rng.sample(range(1,300),j+3)),j+1,14-j) for j in range(13)]
        maximum=flights(list(range(1,200000,2)),list(range(2,200001,2)),10**9,10**9)
    elif i==31:
        raws=[array([-50,-50]),array([1,1,1]),array([0,50,-50,0]),array([10,1,1,10])]+[array([rng.randrange(-50,51) for _ in range(n)]) for n in range(5,18)];maximum=array([50,-50]*25)
    elif i==32:
        def sequence(a:list[int],k:int)->str:return f'{len(a)} {k}\n'+column(a)
        raws=[sequence([0],0),sequence([1],0),sequence([10**9],10**9),sequence([2,2,2],4),sequence([10**9,0,10**9],1)]
        raws += [sequence([rng.randrange(1,10) for _ in range(n)],n*10) for n in range(4,16)];maximum=sequence([1]*100000,10**9)
    elif i==33:
        raws=['0\n','1\n','0+1\n','1*0+2*3\n','9*9*9\n']+['+'.join('*'.join(str(rng.randrange(10)) for _ in range(1+j%4)) for _ in range(j))+'\n' for j in range(2,14)];maximum='+'.join(['9']*50000)+'\n'
    elif i==34:
        raws=['2 2\n','2 100000\n','100000 2\n','3 3\n']+[f'{n} {n+7}\n' for n in range(4,17)];maximum='100000 100000\n'
    elif i==35:
        def flips(n:int,edges:list[tuple[int,int]])->str:return f'{n} {len(edges)}\n'+''.join(f'{l} {r}\n' for l,r in edges)
        raws=[flips(1,[(1,1)]),flips(1,[(1,1)]*2),flips(3,[(1,3),(2,2)]),flips(4,[(1,1),(4,4)])]
        raws += [flips(n,[tuple(sorted((rng.randrange(1,n+1),rng.randrange(1,n+1)))) for _ in range(n)]) for n in range(5,18)];maximum=flips(200000,[(1,200000)]*200000)
    elif i==36:
        raws=['1\n0\n','2\n0\n0\n','3\n1000000000\n0\n500000000\n','3\n3\n2\n1\n']+[f'{n}\n'+column([rng.randrange(20) for _ in range(n)]) for n in range(4,17)];maximum='100000\n'+column(list(range(999900001,1000000001)))
    elif i==37:
        def windows(a:list[int],k:int)->str:return f'{len(a)} {k}\n'+line(a)
        raws=[windows([0],1),windows([10**8],1),windows([1,2,3],1),windows([1,2,3],3)]+[windows([rng.randrange(100) for _ in range(n)],rng.randrange(1,n+1)) for n in range(4,17)];maximum=windows([10**8]*100000,50000)
    elif i==38:
        raws=[array([1]),array([1,1]),array([3,2,1]),array([1,2,3,1,2])]+[array([rng.randrange(1,50) for _ in range(n)]) for n in range(4,17)];maximum=array(list(range(1,100001)))
    elif i==40:
        raws=[array([0,0]),array([0,10000]),array([0,10000,0]),array([10,0,10,0])]+[array([rng.randrange(10001) for _ in range(n)]) for n in range(5,18)];maximum=array([0,10000]*50000)
    elif i==41:
        raws=[array([1,2]),array([2,1]),array([10**9,1]),array([5,1,3])]+[array(rng.sample(range(1,100000),n)) for n in range(4,17)];maximum=array(list(range(999900001,1000000001)))
    elif i==42:
        def digits(n:int,banned:list[int])->str:return f'{n} {len(banned)}\n'+line(banned)
        raws=[digits(1,[0]),digits(1,[1]),digits(9,list(range(9))),digits(9999,list(range(10))[0:1]+list(range(2,10)))]+[digits(11+j*501,sorted(rng.sample(range(10),1+j%8))) for j in range(13)];maximum=digits(9999,list(range(9)))
    elif i==43:
        raws=[array([-100]),array([100]),array([-100,100]),array([-1,0]),array([1,2])]+[array([rng.randrange(-100,101) for _ in range(n)]) for n in range(3,15)];maximum=array([-100,100]*50)
    elif i==45:
        raws=['1\n','9\n','11\n','99\n','123\n']+[''.join(str(rng.randrange(1,10)) for _ in range(2+j%8))+'\n' for j in range(12)];maximum='9999999999\n'
    else:
        def cards(a:list[int],average:int)->str:return f'{len(a)} {average}\n'+line(a)
        raws=[cards([1],1),cards([1],50),cards([1,50],25),cards([3]*33,3),cards([1,2,3],2)]+[cards([rng.randrange(1,51) for _ in range(n)],rng.randrange(1,51)) for n in range(4,16)];maximum=cards([50]*50,50)
    raws.append(maximum);require(len(raws)==len(set(raws))==18,'eighteen distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'edge_or_seeded'} for j,raw in enumerate(raws)]

TITLES={'abc026_c': '高橋君の給料', 'abc027_c': '倍々ゲーム', 'abc028_c': '数を3つ選ぶマン', 'abc030_c': '飛行機乗り', 'abc031_c': '数列ゲーム', 'abc032_c': '列', 'abc033_c': '数式の書き換え', 'abc034_c': '経路', 'abc035_c': 'オセロ', 'abc036_c': '座圧', 'abc037_c': '総和', 'abc038_c': '単調増加', 'abc040_c': '柱柱柱柱柱', 'abc041_c': '背の順', 'arc058_a': 'こだわり者いろはちゃん', 'arc059_a': 'いっしょ', 'arc060_a': '高橋君とカード', 'arc061_a': 'たくさんの数式'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'abc026_c': [{'input': '5\n1\n1\n1\n1\n', 'expected': '3\n'}, {'input': '7\n1\n1\n2\n2\n3\n3\n', 'expected': '7\n'}, {'input': '6\n1\n2\n3\n3\n2\n', 'expected': '11\n'}, {'input': '10\n1\n2\n3\n4\n5\n6\n7\n8\n9\n', 'expected': '1023\n'}], 'abc027_c': [{'input': '1\n', 'expected': 'Aoki\n'}, {'input': '5\n', 'expected': 'Takahashi\n'}, {'input': '7\n', 'expected': 'Aoki\n'}, {'input': '10\n', 'expected': 'Takahashi\n'}, {'input': '123456789123456789\n', 'expected': 'Aoki\n'}], 'abc028_c': [{'input': '1 2 3 4 5\n', 'expected': '10\n'}, {'input': '1 2 3 5 8\n', 'expected': '14\n'}], 'abc030_c': [{'input': '3 4\n2 3\n1 5 7\n3 8 12 13\n', 'expected': '2\n'}, {'input': '1 1\n1 1\n1\n1\n', 'expected': '0\n'}, {'input': '6 7\n5 3\n1 7 12 19 20 26\n4 9 15 23 24 31 33\n', 'expected': '3\n'}], 'abc031_c': [{'input': '6\n1 -3 3 9 1 6\n', 'expected': '6\n'}, {'input': '3\n5 5 5\n', 'expected': '10\n'}, {'input': '8\n-1 10 -1 2 -1 10 -1 0\n', 'expected': '-1\n'}], 'abc032_c': [{'input': '7 6\n4\n3\n1\n1\n2\n10\n2\n', 'expected': '4\n'}, {'input': '6 10\n10\n10\n10\n10\n0\n10\n', 'expected': '6\n'}, {'input': '6 9\n10\n10\n10\n10\n10\n10\n', 'expected': '0\n'}, {'input': '4 0\n1\n2\n3\n4\n', 'expected': '0\n'}], 'abc033_c': [{'input': '0+0+2*0\n', 'expected': '0\n'}, {'input': '3*1+1*2\n', 'expected': '2\n'}, {'input': '3*1*4+0+2*0+5*2+9*8*6+1+3\n', 'expected': '5\n'}], 'abc034_c': [{'input': '4 3\n', 'expected': '10\n'}, {'input': '123 456\n', 'expected': '210368064\n'}], 'abc035_c': [{'input': '5 4\n1 4\n2 5\n3 3\n1 5\n', 'expected': '01010\n'}, {'input': '20 8\n1 8\n4 13\n8 8\n3 18\n5 20\n19 20\n2 7\n4 9\n', 'expected': '10110000011110000000\n'}], 'abc036_c': [{'input': '5\n3\n3\n1\n6\n1\n', 'expected': '1\n1\n0\n2\n0\n'}], 'abc037_c': [{'input': '5 3\n1 2 4 8 16\n', 'expected': '49\n'}, {'input': '20 10\n100000000 100000000 98667799 100000000 100000000 100000000 100000000 99986657 100000000 100000000 100000000 100000000 100000000 98995577 100000000 100000000 99999876 100000000 100000000 99999999\n', 'expected': '10988865195\n'}], 'abc038_c': [{'input': '5\n1 2 3 2 1\n', 'expected': '8\n'}, {'input': '4\n1 2 3 4\n', 'expected': '10\n'}, {'input': '6\n3 3 4 1 2 2\n', 'expected': '8\n'}, {'input': '6\n1 5 2 3 4 2\n', 'expected': '10\n'}], 'abc040_c': [{'input': '4\n100 150 130 120\n', 'expected': '40\n'}, {'input': '4\n100 125 80 110\n', 'expected': '40\n'}, {'input': '9\n314 159 265 358 979 323 846 264 338\n', 'expected': '310\n'}], 'abc041_c': [{'input': '3\n140 180 160\n', 'expected': '2\n3\n1\n'}, {'input': '2\n1000000000 1\n', 'expected': '1\n2\n'}, {'input': '8\n3 1 4 15 9 2 6 5\n', 'expected': '4\n5\n7\n8\n3\n1\n6\n2\n'}], 'arc058_a': [{'input': '1000 8\n1 3 4 5 6 7 8 9\n', 'expected': '2000\n'}, {'input': '9999 1\n0\n', 'expected': '9999\n'}], 'arc059_a': [{'input': '2\n4 8\n', 'expected': '8\n'}, {'input': '3\n1 1 3\n', 'expected': '3\n'}, {'input': '3\n4 2 5\n', 'expected': '5\n'}, {'input': '4\n-100 -100 -100 -100\n', 'expected': '0\n'}], 'arc060_a': [{'input': '4 8\n7 9 8 9\n', 'expected': '5\n'}, {'input': '3 8\n6 6 9\n', 'expected': '0\n'}, {'input': '8 5\n3 6 2 8 7 6 5 9\n', 'expected': '19\n'}, {'input': '33 3\n3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3\n', 'expected': '8589934591\n'}], 'arc061_a': [{'input': '125\n', 'expected': '176\n'}, {'input': '9999999999\n', 'expected': '12656242944\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
