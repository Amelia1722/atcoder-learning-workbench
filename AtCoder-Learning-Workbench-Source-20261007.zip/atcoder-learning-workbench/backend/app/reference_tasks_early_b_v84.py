"""ABC110–112 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc110_b','abc111_b','abc112_b')
INT=re.compile(r'-?(?:0|[1-9][0-9]*)', re.ASCII)
POS=re.compile(r'[1-9][0-9]*', re.ASCII)


def _tokens(line:str, count:int)->list[str]:
    parts=line.split(' ')
    if len(parts)!=count or any(INT.fullmatch(t) is None for t in parts):
        raise ValueError('integer format')
    return parts


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc110_b':
        if len(lines)!=3: raise ValueError('line count')
        h=_tokens(lines[0],4); n,m,x,y=map(int,h)
        if not (1<=n<=100 and 1<=m<=100 and -100<=x<y<=100): raise ValueError('header range')
        tx=_tokens(lines[1],n); ty=_tokens(lines[2],m)
        xs=list(map(int,tx)); ys=list(map(int,ty))
        if any(v < -100 or v > 100 for v in xs+ys): raise ValueError('city range')
        if len(set(xs))!=n or len(set(ys))!=m or x in xs or y in ys: raise ValueError('city constraints')
        return n,m,x,y,xs,ys
    if pid=='abc111_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
        n=int(lines[0])
        if not 100<=n<=999: raise ValueError('range')
        return n
    if len(lines)<2:
        raise ValueError('line count')
    h=_tokens(lines[0],2); n,t=map(int,h)
    if not (1<=n<=100 and 1<=t<=1000) or len(lines)!=n+1: raise ValueError('shape/range')
    routes=[]
    for line in lines[1:]:
        a=_tokens(line,2); c,tm=map(int,a)
        if not (1<=c<=1000 and 1<=tm<=1000): raise ValueError('route range')
        routes.append((c,tm))
    if len(set(routes))!=n: raise ValueError('duplicate route pair')
    return n,t,routes


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc110_b':
        if output not in ('War','No War'): return False
        _,_,x,y,xs,ys=value
        ok=max([x,*xs]) < min([y,*ys])
        return output==('No War' if ok else 'War')
    if pid=='abc111_b':
        if re.fullmatch(r'[1-9][0-9]{2}',output,re.ASCII) is None: return False
        n=value
        expected=next(111*d for d in range(1,10) if 111*d>=n)
        return int(output)==expected
    if output!='TLE' and re.fullmatch(r'[1-9][0-9]{0,3}',output,re.ASCII) is None:
        return False
    _,t,routes=value
    costs=[c for c,tm in routes if tm<=t]
    expected=str(min(costs)) if costs else 'TLE'
    return output==expected


def _war(n,m,x,y,xs,ys)->str:
    return f'{n} {m} {x} {y}\n'+' '.join(map(str,xs))+'\n'+' '.join(map(str,ys))+'\n'


def _routes(t, pairs)->str:
    return f'{len(pairs)} {t}\n'+'\n'.join(f'{c} {tm}' for c,tm in pairs)+'\n'


def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc110_b':
        cases=[
          (1,1,0,1,[-1],[0]), (1,1,0,2,[1],[1]), (1,1,-2,-1,[-1],[-2]),
          (3,2,10,20,[8,15,13],[16,22]), (4,2,-48,-1,[-20,-35,-91,-23],[-22,66]),
          (5,3,6,8,[-10,3,1,5,-100],[100,6,14]), (2,2,-1,1,[-2,0],[0,2]),
          (2,2,-100,100,[-99,99],[-98,98]), (3,3,0,100,[1,2,3],[4,5,6]),
          (3,3,-10,10,[-9,-8,9],[-7,-6,8]), (2,3,-5,5,[-4,-3],[-2,-1,0]),
          (3,2,-5,5,[-4,0,4],[1,2]), (1,2,98,100,[99],[98,99]),
          (2,1,-100,-98,[-99,-97],[-100]), (4,4,-2,3,[-100,-1,0,1],[2,4,50,100]),
          (4,4,-2,3,[-100,-1,0,2],[1,4,50,100]), (5,5,-20,20,[-19,-18,-17,-16,-15],[15,16,17,18,19])
        ]
        for n,m,x,y,xs,ys in cases:
            add('boundary' if n==1 or m==1 or abs(x)==100 or abs(y)==100 else 'normal',_war(n,m,x,y,xs,ys))
        xs=list(range(-99,1))
        ys=list(range(0,100))
        add('constraint_max',_war(100,100,-100,100,xs,ys))
    elif pid=='abc111_b':
        vals=[100,110,111,112,221,222,223,332,333,334,554,555,556,749,750,777,998]
        for n in vals:
            add('boundary' if n in (100,111,112,998) else 'normal',f'{n}\n')
        add('constraint_max','999\n')
    else:
        cases=[
          (1,[(1,1)]), (1,[(1000,2)]), (1000,[(1000,1000)]),
          (70,[(7,60),(1,80),(4,50)]), (3,[(1,1000),(2,4),(3,1000),(4,500)]),
          (9,[(25,8),(5,9),(4,10),(1000,1000),(6,1)]), (10,[(3,10),(2,11),(1,12)]),
          (500,[(10,500),(9,499),(8,501),(7,1)]), (1000,[(1000,999),(1,1000)]),
          (999,[(1,1000),(2,999)]), (1,[(5,1),(4,2),(3,3),(2,4),(1,5)]),
          (100,[(100,100),(99,100),(98,101),(97,99),(96,1000)]),
          (250,[(600,251),(500,250),(400,249),(300,248),(200,500),(100,1)]),
          (750,[(1000,750),(999,751),(998,749)]), (1000,[(4,1),(3,2),(2,3),(1,4)]),
          (333,[(333,334),(334,333),(335,332)]), (2,[(1,3),(1000,1000)])
        ]
        for t,pairs in cases:
            add('boundary' if len(pairs)==1 or t in (1,1000) else 'normal',_routes(t,pairs))
        pairs=[(i+1, (i*37)%1000+1) for i in range(100)]
        add('constraint_max',_routes(1000,pairs))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
