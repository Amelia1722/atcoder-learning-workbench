"""Three-stage hints for Turn 132's pure-C batch."""
from __future__ import annotations
HINTS_V155:dict[str,tuple[str,str,str]]={
'abc008_3':('コインごとに表になる確率を求め、期待値を足します。','他の約数コインがd枚なら、相対順序で自分の順位は0〜dに一様です。前の約数が偶数枚なら表です。','疑似コード: ans=0; 各iで d=count(j!=i and C[i]%C[j]==0); ans+=((d+2)//2)/(d+1); print(ans)。'),
'abc009_3':('先頭から、実現可能な最小文字を選びます。','候補文字を使った後、残り文字の頻度と元の接尾辞を比較し、最低不一致数がK以内か調べます。','疑似コード: remaining=Counter(S); changed=0; 各位置iで候補cを昇順に試す; cを仮に減らす; cost=changed+(c!=S[i])+sum(max(0,tail[x]-remaining[x])); cost<=Kならcを確定、それ以外戻す。'),
'abc010_3':('出発点→家→到着点の距離を調べます。','その距離がT*V以下の家があれば可能です。','疑似コード: 各家(x,y)で d1=hypot(x-txa,y-tya),d2=hypot(x-txb,y-tyb); d1+d2<=T*VならYES; どれも無ければNO。'),
'abc011_3':('0へ到達するための最少操作数をDPで求めます。','NG数字の状態を到達不可とし、1〜3前の状態へ1回で遷移できます。','疑似コード: dp[0]=0,他INF; x=1..Nで xがNGでなければ dp[x]=1+min(dp[max(0,x-3):x]); dp[N]<=100ならYES。'),
'abc012_3':('九九全体の合計は2025です。','忘れた積は2025-Nです。1〜9の全組を調べます。','疑似コード: a=1..9,b=1..9で a*b==2025-Nなら print(a,"x",b)。'),
'abc013_3':('先に食事をしてから抜けば、最後の満腹度が正なら安全です。','普通の食事回数xを列挙し、正の満腹度に必要な質素な食事の最少回数を求めます。','疑似コード: x=0..N; y=max(0,(N*E-H-x*(B+E))//(D+E)+1); x+y<=Nならans=min(ans,x*A+y*C)。'),
'abc014_3':('閉区間を差分配列へ登録します。','左端で+1、右端の次で-1し、累積和の最大を取ります。','疑似コード: diff[1000002]=0; 各(a,b)でdiff[a]++,diff[b+1]--; current=0; 全位置でcurrent+=diff[pos]; ans=max(ans,current)。'),
'abc015_3':('選択肢は最大5^5通りです。','質問ごとに到達可能なXORを更新しても解けます。','疑似コード: possible={0}; 各質問rowで possible={x^y for x in possible for y in row}; 0が含まれればFound、それ以外Nothing。'),
'abc016_3':('友達の友達の集合を作ります。','全ての友達の友達を合併し、自分と直接の友達を除きます。','疑似コード: 各iで candidates=union(friends[j] for j in friends[i]); print(len(candidates-friends[i]-{i}))。'),
'abc017_3':('獲得しない宝石を1種類選ぶと考えます。','各宝石を含む遺跡の得点和が失う得点です。その最小値を全得点から引きます。','疑似コード: diff[l]+=s,diff[r+1]-=s; total+=s; 宝石1..Mの累積和lossの最小minimumを求める; print(total-minimum)。'),
'abc018_3':('菱形の各列は縦に連続した白マスです。','上下方向の白マス連続長を前計算し、中心から横にd離れた列の必要長K-dを確認します。','疑似コード: up/downを白マスの連続長として作る; 盤面内の各中心(y,x)で 全xx in x-K+1..x+K-1に min(up[y][xx],down[y][xx])>=K-abs(xx-x)ならans++。'),
'abc019_3':('2倍しても同じなら2の因子を全て除去できます。','奇数になるまで2で割り、残った値の種類数を数えます。','疑似コード: normalized=set(); 各aで while a%2==0: a//=2; normalized.add(a); print(len(normalized))。'),
'abc020_c':('壁の通過時間xを増やすと到達は難しくなります。','xを二分探索し、Dijkstraで移動先の色に応じた最短時間を求めます。','疑似コード: lo=1,hi=T+1; while hi-lo>1: mid=(lo+hi)//2; edge cost=移動先が#ならmid、他1; shortest(mid)<=Tならlo=mid、それ以外hi=mid; print(lo)。'),
'abc021_c':('BFSで最短距離と経路数を持ちます。','距離が1増える辺だけ経路数を加算します。道路の重複保証はないため入力本数を保持します。','疑似コード: dist[a]=0,ways[a]=1; queueでuを取り出す; 隣vが未訪問ならdist[v]=dist[u]+1; dist[v]==dist[u]+1ならways[v]+=ways[u] mod 1000000007; print(ways[b])。'),
'abc022_c':('家1から出る道と戻る道は別です。','家1を除いたグラフで、家1の隣家どうしの最短距離を求めます。','疑似コード: 家1の辺をaroundへ退避; 各(start,cost)で残りのグラフのDijkstra; 他の(end,other)との cost+dist[end]+other の最小を出力; 無ければ-1。'),
'abc023_c':('行の飴数と列の飴数を足します。','飴が置かれた交点だけ二重計上になるため、後から補正します。','疑似コード: rows/colsを集計; rowfreq, colfreqから sum(rowfreq[a]*colfreq[K-a]); 各飴位置でsum==Kならans--、sum==K+1ならans++。'),
'abc024_c':('目的地に向けて、その日に動ける限り進みます。','現在位置が当日の区間内なら、目的地まで行くか目的地側の端まで進みます。','疑似コード: 各(S,T)でposition=S; 日iの[L,R]にpositionが含まれれば、Tも含まれるならiを出力して終了; そうでなければposition=(T>position ? R : L)。'),
'abc025_c':('盤面状態をメモ化して最善手を探索します。','総得点が一定なので、先手は自分の得点を最大化、後手はそれを最小化します。','疑似コード: solve(board); 全9マス埋まれば同記号の隣接辺の点数和; 各空きマスに手番の記号を置いてsolve; 先手番max、後手番min; first=solve(empty); print(first,total-first)。'),
}
