"""Private ABC443..448 D domains, independent oracles and chocolate semantics."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter
from functools import lru_cache
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(443,449));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc445_d':'semantic'};CHECKER_IDS={'abc445_d':'abc445_d'};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integer fields');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'field count');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

@lru_cache(maxsize=32)
def chocolate_strip_layout(h:int,w:int,pieces:tuple[tuple[int,...],...])->tuple[tuple[int,int],...]:
 heights:dict[int,list[int]]={};widths:dict[int,list[int]]={};used=bytearray(len(pieces));out=[(0,0)]*len(pieces);remaining_h,remaining_w=h,w
 for i,(a,b) in enumerate(pieces):heights.setdefault(a,[]).append(i);widths.setdefault(b,[]).append(i)
 for _ in pieces:
  vertical=heights.get(remaining_h,[]);horizontal=widths.get(remaining_w,[])
  while vertical and used[vertical[-1]]:vertical.pop()
  while horizontal and used[horizontal[-1]]:horizontal.pop()
  require(bool(vertical or horizontal),'sequential rectangular cut guarantee')
  if vertical:
   i=vertical.pop();a,b=pieces[i];require(b<=remaining_w,'strip width');remaining_w-=b;out[i]=(1,remaining_w+1)
  else:
   i=horizontal.pop();a,b=pieces[i];require(a<=remaining_h,'strip height');remaining_h-=a;out[i]=(remaining_h+1,1)
  used[i]=1
 require(remaining_h==0 or remaining_w==0,'complete strips');return tuple(out)

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc443_d':
  t=ints(r[0],1)[0];require(1<=t<=50000 and len(r)==1+2*t,'T/rows');cases=[];total=0
  for i in range(t):
   n=ints(r[1+2*i],1)[0];a=ints(r[2+2*i],n);require(2<=n<=300000 and all(1<=v<=n for v in a),'N/R');total+=n;cases.append(a)
  require(total<=300000,'sumN');return (tuple(cases),)
 if pid in ('abc444_d','abc446_d'):
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)==2,'N/rows');a=ints(r[1],n);require(all(1<=v<=(200000 if pid=='abc444_d' else 10**9) for v in a),'Ai');return (a,)
 if pid=='abc445_d':
  h,w,n=ints(r[0],3);require(1<=h<=10**9 and 1<=w<=10**9 and 2<=n<=200000 and len(r)==n+1,'shape');pieces=tuple(ints(row,2) for row in r[1:]);require(all(1<=a<=h and 1<=b<=w for a,b in pieces) and sum(a*b for a,b in pieces)==h*w,'piece bounds/area');chocolate_strip_layout(h,w,pieces);return h,w,pieces
 if pid=='abc447_d':require(len(r)==1 and re.fullmatch('[ABC]{1,1000000}',r[0]) is not None,'S');return (r[0],)
 n=ints(r[0],1)[0];require(2<=n<=200000 and len(r)==n+1,'N/rows');a=ints(r[1],n);require(all(1<=v<=10**9 for v in a),'Ai');edges=tuple(ints(row,2) for row in r[2:]);parent=list(range(n))
 def root(v:int)->int:
  while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
  return v
 for u,v in edges:
  require(1<=u<=n and 1<=v<=n and u!=v,'endpoints');x,y=root(u-1),root(v-1);require(x!=y,'tree');parent[x]=y
 return a,edges

def pawn_multisource_distance(a:tuple[int,...])->int:
 n=len(a);distance=list(a);heap=[(v,i) for i,v in enumerate(a)];heapq.heapify(heap)
 while heap:
  value,i=heapq.heappop(heap)
  if distance[i]!=value:continue
  for j in (i-1,i+1):
   if 0<=j<n and value+1<distance[j]:distance[j]=value+1;heapq.heappush(heap,(value+1,j))
 return sum(a)-sum(distance)

def repunits_base_billion(a:tuple[int,...])->str:
 blocks=max(a)//9+2;diff=[0]*(blocks+1);partial=[0]*blocks
 for length in a:
  q,r=divmod(length,9);diff[0]+=1;diff[q]-=1;partial[q]+=(10**r-1)//9
 active=carry=0;digits=[]
 for i in range(blocks):active+=diff[i];value=active*111111111+partial[i]+carry;digits.append(value%10**9);carry=value//10**9
 while carry:digits.append(carry%10**9);carry//=10**9
 while len(digits)>1 and digits[-1]==0:digits.pop()
 return str(digits[-1])+''.join(f'{v:09d}' for v in reversed(digits[:-1]))

def chocolate_layout_valid(h:int,w:int,pieces:tuple[tuple[int,...],...],actual:str)->bool:
 rows=actual.removesuffix('\n').split('\n')
 if len(rows)!=len(pieces):return False
 rectangles=[];events=[];ys=set()
 for i,(row,(a,b)) in enumerate(zip(rows,pieces)):
  if re.fullmatch(r'[+-]?[0-9]+ [+-]?[0-9]+',row) is None:return False
  normalized=[]
  for token in row.split():
   sign=-1 if token.startswith('-') else 1;digits=token.lstrip('+-').lstrip('0') or '0'
   if len(digits)>10:return False
   normalized.append(sign*int(digits))
  x,y=normalized;x-=1;y-=1
  if not (0<=x and x+a<=h and 0<=y and y+b<=w):return False
  rectangles.append((x,x+a,y,y+b));ys.update((y,y+b));events.append((x,1,i));events.append((x+a,-1,i))
 coordinates=sorted(ys);rank={v:i+1 for i,v in enumerate(coordinates)};size=len(coordinates);count=[0]*(size+1);weighted=[0]*(size+1)
 def add(y:int,delta:int)->None:
  at=rank[y]
  while at<=size:count[at]+=delta;weighted[at]+=delta*y;at+=at&-at
 def integral(y:int)->int:
  at=rank[y];c=s=0
  while at:c+=count[at];s+=weighted[at];at-=at&-at
  return y*c-s
 for x,kind,i in sorted(events):
  _,_,left,right=rectangles[i]
  if kind==1 and integral(right)-integral(left)>0:return False
  add(left,kind);add(right,-kind)
 return sum(a*b for a,b in pieces)==h*w

def straight_value_buckets(a:tuple[int,...])->int:
 positions:dict[int,list[int]]={}
 for i,v in enumerate(a):positions.setdefault(v,[]).append(i)
 last_value=-1;last_positions:list[int]=[];last_best:list[int]=[];answer=0
 for value,row in sorted(positions.items()):
  best=[];prefix=0
  for i in row:
   at=bisect_left(last_positions,i)-1 if value==last_value+1 else -1;current=(last_best[at] if at>=0 else 0)+1;prefix=max(prefix,current);best.append(prefix);answer=max(answer,current)
  last_value=value;last_positions=row;last_best=best
 return answer

def abc_global_chain_feasibility(s:str)->int:
 aa=[];bb=[];cc=[]
 for i,char in enumerate(s):
  if char=='A':aa.append(i)
  elif char=='B':bb.append(i)
  else:cc.append(i)
 def feasible(k:int)->bool:
  if k==0:return True
  chosen=[];at=len(bb)-1
  for index in range(len(cc)-1,len(cc)-k-1,-1):
   while at>=0 and bb[at]>=cc[index]:at-=1
   if at<0:return False
   chosen.append(bb[at]);at-=1
  at=len(aa)-1
  for middle in chosen:
   while at>=0 and aa[at]>=middle:at-=1
   if at<0:return False
   at-=1
  return True
 low=0;high=min(len(aa),len(bb),len(cc))+1
 while high-low>1:
  middle=(low+high)//2
  if feasible(middle):low=middle
  else:high=middle
 return low

def tree_offline_value_intervals(a:tuple[int,...],edges:tuple[tuple[int,...],...])->list[bool]:
 n=len(a);adj=[[] for _ in a]
 for u,v in edges:adj[u-1].append(v-1);adj[v-1].append(u-1)
 parent=[-1]*n;order=[];stack=[0]
 while stack:
  v=stack.pop();order.append(v)
  for u in adj[v]:
   if u!=parent[v]:parent[u]=v;stack.append(u)
 tin=[0]*n;subtree=[1]*n
 for i,v in enumerate(order):tin[v]=i
 for v in reversed(order[1:]):subtree[parent[v]]+=subtree[v]
 groups:dict[int,list[int]]={}
 for v in order:groups.setdefault(a[v],[]).append(v)
 repeated=[False]*n
 for group in groups.values():
  active=[]
  for v in group:
   while active and tin[active[-1]]+subtree[active[-1]]<=tin[v]:active.pop()
   repeated[v]=bool(active);active.append(v)
 for v in order[1:]:repeated[v]=repeated[v] or repeated[parent[v]]
 return repeated

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc443_d':return ''.join(str(pawn_multisource_distance(a))+'\n' for a in cast(tuple[tuple[int,...],...],d[0]))
 if pid=='abc444_d':return repunits_base_billion(cast(tuple[int,...],d[0]))+'\n'
 if pid=='abc445_d':return ''.join(line(v) for v in chocolate_strip_layout(*cast(tuple[int,int,tuple[tuple[int,...],...]],d)))
 if pid=='abc446_d':return str(straight_value_buckets(cast(tuple[int,...],d[0])))+'\n'
 if pid=='abc447_d':return str(abc_global_chain_feasibility(cast(str,d[0])))+'\n'
 return ''.join(('Yes' if v else 'No')+'\n' for v in tree_offline_value_intervals(*cast(tuple[tuple[int,...],tuple[tuple[int,...],...]],d)))
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc445_d':return chocolate_layout_valid(*cast(tuple[int,int,tuple[tuple[int,...],...]],d),actual)
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));rows:list[str]=[]
 if pid=='abc443_d':
  def pack(cases:list[list[int]])->str:return str(len(cases))+'\n'+''.join(str(len(a))+'\n'+line(a) for a in cases)
  rows=[pack([a]) for a in ([1,1],[2,2],[1,2],[2,1],[3,1,3],[1,3,1],[4,4,1,4],[6,1,6,1,6,1])]
  for n in range(9,16):rows.append(pack([[rng.randrange(1,n+1) for _ in range(n)]]))
  rows+=[pack([[6,1,6,1,6,1]]*50000),pack([[1,300000]*150000]),pack([[1]+[300000]*299999])]
 elif pid=='abc444_d':
  def pack(a:list[int])->str:return str(len(a))+'\n'+line(a)
  rows=[pack(a) for a in ([1],[9],[10],[200000],[1,1],[1,9,10],[9]*9,[1,2,3,4,5,6,7,8,9,10])]
  for n in range(9,16):rows.append(pack([rng.randrange(1,200001) for _ in range(n)]))
  rows+=[pack([1]*200000),pack([rng.randrange(1,200001) for _ in range(200000)]),pack([200000]*200000)]
 elif pid=='abc445_d':
  def pack(h:int,w:int,n:int,high_offset:bool=False)->str:
   a=h;b=w;pieces=[]
   if high_offset:pieces=[(a-100000,b),(100000,b-100000)];a=b=100000
   while len(pieces)<n-1:
    horizontal=a>1 and (b==1 or rng.randrange(2)==0)
    if horizontal:pieces.append((1,b));a-=1
    else:require(b>1,'enough cuts');pieces.append((a,1));b-=1
   pieces.append((a,b));rng.shuffle(pieces);return line([h,w,n])+''.join(line(p) for p in pieces)
  rows=[pack(1,2,2),pack(2,1,2),pack(2,2,2),pack(2,2,3),pack(3,5,4),pack(5,3,5),pack(4,6,6),pack(10**9,10**9,2)]
  for n in range(9,16):rows.append(pack(20,21,n))
  rows+=[pack(10**9,10**9,200000),pack(1,10**9,200000),pack(10**9,10**9,200000,True)]
 elif pid=='abc446_d':
  def pack(a:list[int])->str:return str(len(a))+'\n'+line(a)
  rows=[pack(a) for a in ([1],[10**9],[1,2],[2,1],[1,1,2,2,3],[1,3,2,4],[3,1,2,3,4],[5,4,3,2,1])]
  for n in range(9,16):rows.append(pack([rng.randrange(1,21) for _ in range(n)]))
  rows[14]=pack(list(range(200000,0,-1)));rows+=[pack([10**9]*200000),pack([rng.randrange(1,10**9+1) for _ in range(200000)]),pack(list(range(10**9-199999,10**9+1)))]
 elif pid=='abc447_d':
  values=['A','B','C','ABC','CBA','AABBCC','ABABC','AAABBBCCC']
  for n in range(9,16):values.append(''.join(rng.choice('ABC') for _ in range(10+n)))
  values+=['ABC'*333333+'A','A'*333334+'B'*333333+'C'*333333,'A'*1000000];rows=[s+'\n' for s in values]
 else:
  def tree(a:list[int],e:list[tuple[int,int]])->str:return str(len(a))+'\n'+line(a)+''.join(line(p) for p in e)
  rows=[tree([1,1],[(1,2)]),tree([1,2],[(2,1)]),tree([1,2,2],[(1,2),(1,3)]),tree([1,2,1],[(1,2),(2,3)]),tree([1,2,2,3,3],[(1,2),(1,3),(2,4),(3,5)])]
  for n in range(6,16):rows.append(tree([rng.randrange(1,5) for _ in range(n)],[(i,rng.randrange(1,i)) for i in range(2,n+1)]))
  chain=[(i,i+1) for i in range(1,200000)];rows+=[tree(list(range(1,200001)),chain),tree([rng.randrange(1,1001) for _ in range(200000)],[(i,rng.randrange(1,i)) for i in range(2,200001)]),tree([10**9]*200000,chain)]
 require(len(rows)==len(set(rows))==18,'18 distinct');return [{'input':s,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i>=14 else 'varied'} for i,s in enumerate(rows)]

REFERENCE_CODE={
'abc443_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);out=[]
for _ in range(t):
 n=next(it);a=[next(it) for i in range(n)];original=sum(a)
 for i in range(1,n):a[i]=min(a[i],a[i-1]+1)
 for i in range(n-2,-1,-1):a[i]=min(a[i],a[i+1]+1)
 out.append(str(original-sum(a)))
print('\\n'.join(out))
''',
'abc444_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a=list(it);maximum=max(a);end=[0]*(maximum+1)
for value in a:end[value]+=1
active=n;carry=0;digits=[]
for i in range(maximum):
 value=active+carry;digits.append(str(value%10));carry=value//10;active-=end[i+1]
while carry:digits.append(str(carry%10));carry//=10
print(''.join(reversed(digits)))
''',
'abc445_d':'''import sys,heapq
it=iter(map(int,sys.stdin.buffer.read().split()));h=next(it);w=next(it);n=next(it);parts=[(next(it),next(it)) for i in range(n)];heights=[(-a,i) for i,(a,b) in enumerate(parts)];widths=[(-b,i) for i,(a,b) in enumerate(parts)];heapq.heapify(heights);heapq.heapify(widths);used=bytearray(n);out=[None]*n;top=left=0
for _ in range(n):
 while heights and used[heights[0][1]]:heapq.heappop(heights)
 while widths and used[widths[0][1]]:heapq.heappop(widths)
 if heights and -heights[0][0]==h:
  _,i=heapq.heappop(heights);a,b=parts[i];out[i]=(top+1,left+1);left+=b;w-=b
 else:
  _,i=heapq.heappop(widths);a,b=parts[i];assert b==w;out[i]=(top+1,left+1);top+=a;h-=a
 used[i]=1
sys.stdout.write(''.join(str(x)+' '+str(y)+'\\n' for x,y in out))
''',
'abc446_d':'''n=int(input());a=list(map(int,input().split()));dp={};answer=0
for value in a:dp[value]=max(dp.get(value,0),dp.get(value-1,0)+1);answer=max(answer,dp[value])
print(answer)
''',
'abc447_d':'''s=input();a=ab=answer=0
for char in s:
 if char=='A':a+=1
 elif char=='B' and a:a-=1;ab+=1
 elif char=='C' and ab:ab-=1;answer+=1
print(answer)
''',
'abc448_d':'''import sys
from collections import Counter
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a=[next(it) for i in range(n)];adj=[[] for _ in range(n)]
for _ in range(n-1):u=next(it)-1;v=next(it)-1;adj[u].append(v);adj[v].append(u)
counts=Counter();duplicates=0;answer=['No']*n;stack=[(0,-1,False)]
while stack:
 v,p,exit=stack.pop();value=a[v]
 if exit:
  if counts[value]==2:duplicates-=1
  counts[value]-=1;continue
 counts[value]+=1
 if counts[value]==2:duplicates+=1
 answer[v]='Yes' if duplicates else 'No';stack.append((v,p,True))
 for u in adj[v]:
  if u!=p:stack.append((u,v,False))
print('\\n'.join(answer))
'''}
HINTS:dict[str,tuple[str,str,str]]={
'abc443_d':('各駒は上へしか動かせません。隣の駒から許される最大の行番号を伝えます。','左から一回、右から一回、隣の行番号+1以下に制限すると、全隣接条件を満たす最も低い配置が得られます。','疑似コード: original=sum(R)。左からR[i]=min(R[i],R[i-1]+1)、右からR[i]=min(R[i],R[i+1]+1)。original-sum(R)を出力。'),
'abc444_d':('桁ごとに 1 がいくつ足されるかを数え、繰り上がりを処理します。巨大な整数そのものは作りません。','下から i 桁目には Ai が i より大きい数の本数だけ 1 があります。各長さの終了数を持つと、本数を順に減らせます。','疑似コード: end[Ai]++、active=N、carry=0。i=0..maxA-1でv=active+carry、digit=v%10、carry=v//10、active-=end[i+1]。残りcarryの桁も足し、逆順で文字列を出力。'),
'abc445_d':('現在残っている長方形の高さか幅と同じ辺を持つピースを、一辺に沿って置きます。','入力の切り方の保証により、そのようなピースが存在します。高さ・幅の最大値をヒープで取得し、配置済みを取り除きます。','疑似コード: 高さ/幅のmaxheap、used=false、top=left=0。高さが残りHのピースを左端へ置いてleft+=w、W-=w。なければ幅が残りWのピースを上端へ置いてtop+=h、H-=h。各元番号の1始まり座標を出力。'),
'abc446_d':('値 v で終わる最長の条件付き部分列を保持します。次の値は必ず v+1 です。','元の順序で処理し、現在の値を末尾に追加する候補は値-1で終わる部分列の長さ+1です。大きな値なので辞書を使います。','疑似コード: dp={}、answer=0。各vでdp[v]=max(dp[v],dp.get(v-1,0)+1)、answer=max(answer,dp[v])。answerを出力。'),
'abc447_d':('左から A、AB、ABC の未完了な組を数えます。文字を別の組で重複利用してはいけません。','B を見つけたら未使用の A と組み合わせ、C を見つけたら未完了の AB を完成させます。完成した組を取り除いても残りの順序は変わりません。','疑似コード: a=ab=answer=0。Aならa++。Bかつa>0ならa--、ab++。Cかつab>0ならab--、answer++。answerを出力。'),
'abc448_d':('根から現在の頂点までに現れる整数の個数を管理します。一つでも個数2以上があれば答えは Yes です。','DFS で入るときにその値を増やし、出るときに戻します。個数が1から2、2から1に変わるときだけ重複値の種類数を更新します。','疑似コード: enter(v): count[A[v]]++、2ならduplicates++、答え=(duplicates>0)。子を処理してexit(v): countが2ならduplicates--、count--。深い木ではenter/exitを明示stackで管理。')}
REFERENCE_SNIPPETS=REFERENCE_CODE

TITLES={'abc443_d': 'Pawn Line', 'abc444_d': 'Many Repunit Sum', 'abc445_d': 'Reconstruct Chocolate', 'abc446_d': 'Max Straight', 'abc447_d': 'Take ABC 2', 'abc448_d': 'Integer-duplicated Path'}
PUBLISHED_SAMPLES={'abc443_d': [{'input': '5\n5\n5 2 1 3 4\n2\n1 1\n3\n1 3 1\n9\n9 9 8 2 4 4 3 5 3\n20\n7 4 6 2 15 5 17 15 1 8 18 1 5 1 12 11 2 7 8 14\n', 'expected': '4\n0\n1\n16\n105\n'}], 'abc444_d': [{'input': '4\n3 3 3 3\n', 'expected': '444\n'}, {'input': '3\n30 10 20\n', 'expected': '111111111122222222223333333333\n'}, {'input': '10\n1 2 3 4 5 6 7 8 9 10\n', 'expected': '1234567900\n'}], 'abc445_d': [{'input': '4 6 6\n2 2\n1 4\n3 1\n1 2\n3 1\n4 2\n', 'expected': '2 2\n4 1\n1 1\n1 2\n1 4\n1 5\n'}, {'input': '100 100 20\n72 7\n4 74\n17 67\n20 67\n96 3\n1 95\n5 81\n87 3\n3 87\n16 67\n95 8\n100 2\n92 1\n3 98\n92 5\n87 3\n1 98\n19 67\n11 74\n87 1\n', 'expected': '7 89\n90 22\n62 22\n7 22\n4 96\n99 1\n94 15\n7 19\n4 9\n27 22\n4 1\n1 99\n7 14\n1 1\n7 9\n7 16\n100 1\n43 22\n79 22\n7 15\n'}], 'abc446_d': [{'input': '7\n3 4 3 5 7 6 2\n', 'expected': '4\n'}, {'input': '5\n5 4 3 2 1\n', 'expected': '1\n'}, {'input': '10\n1 2 3 4 5 6 7 8 9 10\n', 'expected': '10\n'}], 'abc447_d': [{'input': 'ABACBCC\n', 'expected': '2\n'}, {'input': 'CBACBB\n', 'expected': '0\n'}, {'input': 'BBBAAABCBCBAACBBCAAC\n', 'expected': '5\n'}], 'abc448_d': [{'input': '5\n1 3 2 1 2\n1 2\n1 3\n3 4\n3 5\n', 'expected': 'No\nNo\nNo\nYes\nYes\n'}, {'input': '2\n1000000000 1000000000\n2 1\n', 'expected': 'No\nYes\n'}, {'input': '10\n10 7 3 9 1 3 8 5 7 10\n3 6\n8 6\n6 1\n9 7\n7 10\n5 4\n4 2\n10 2\n1 9\n', 'expected': 'No\nYes\nYes\nYes\nYes\nNo\nNo\nNo\nNo\nYes\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
