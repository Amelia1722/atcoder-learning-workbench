"""Statement-checked three-stage hints for ABC287–289 B."""
HINTS_V143 = {
    'abc287_b': (
        '各6桁文字列について、見る必要があるのは末尾3文字だけです。照合先の3桁文字列を素早く調べられる形にしてください。',
        'T_jをsetに入れておき、各S_iの `S_i[-3:]` がsetに含まれるかを数えます。先頭の0を失わないよう、文字列のまま扱うと安全です。',
        '疑似コード:\nread N, M\nread S[1..N]\nT = set(read M strings)\nans = 0\nfor s in S:\n  if last3(s) in T: ans += 1\nprint(ans)',
    ),
    'abc288_b': (
        '出力対象は全N人ではありません。まず順位が上位K人に限定され、そのK人だけを別の順序で並べ直します。',
        '入力順は順位順なので、先頭K個の文字列だけ取り出して辞書順にsortし、1行ずつ出力します。',
        '疑似コード:\nread N, K\nread S[1..N]\nA = S[1..K]\nsort A lexicographically\nfor s in A:\n  print(s)',
    ),
    'abc289_b': (
        '「レ」が連続して置かれている区間では、その区間に含まれる整数を大きい順に読むことになります。区間の切れ目に注目してください。',
        'a_i と a_i+1 がつながっている間は同じ連結成分です。左から見て、つながりが続く区間 `[L,R]` を見つけたら `R,R-1,...,L` の順で答えへ追加します。',
        '疑似コード:\nread N, M, A\nlinked[x] = true for x in A\nL = 1\nwhile L <= N:\n  R = L\n  while R < N and linked[R]:\n    R += 1\n  for x = R down to L:\n    append x to ans\n  L = R + 1\nprint(ans)',
    ),
}
