"""ABC088-092: task-specific validated inputs and independent expected-output checks.

All source statements and official samples are cited in TEST_BANK_V14.md.
References are independently authored, never fetched/executed from the internet.
"""
from __future__ import annotations

from collections import Counter
from itertools import combinations
from random import Random
import re

SAMPLE = {
 'abc088_a': ('2018\n218\n', 'Yes', '1<=N<=10000; 0<=A<=1000; two input lines'),
 'abc088_b': ('2\n3 1\n', '2', '1<=N<=100; 1<=Ai<=100'),
 'abc088_c': ('1 0 1\n2 1 2\n1 0 1\n', 'Yes', '3x3; 0<=Cij<=100'),
 'abc089_a': ('8\n', '2', '1<=N<=1000'),
 'abc089_b': ('6\nG W Y P Y W\n', 'Four', '3<=N<=100; Si in P W G Y; P,W,G all present'),
 'abc089_c': ('5\nMASHIKE\nRUMOI\nOBIRA\nHABORO\nHOROKANAI\n', '2', '1<=N<=100000; distinct uppercase names length 1..10'),
 'abc090_a': ('ant\nobe\nrec\n', 'abc', '3x3 lowercase characters'),
 'abc090_b': ('11009 11332\n', '4', '10000<=A<=B<=99999'),
 'abc091_a': ('50 100 120\n', 'Yes', '1<=A,B<=500; 1<=C<=1000'),
 'abc091_b': ('3\napple\norange\napple\n1\ngrape\n', '2', '1<=N,M<=100; lowercase strings length 1..10'),
 'abc092_a': ('600\n300\n220\n420\n', '520', '1<=A,B,C,D<=1000; four input lines'),
 'abc092_b': ('3\n7 1\n2\n5\n10\n', '8', '1<=N,D,X<=100; 1<=Ai<=100'),
 'abc092_c': ('3\n3 5 -1\n', '12\n8\n10', '2<=N<=100000; -5000<=Ai<=5000'),
}
BATCH7 = {pid: {'sample_input': sin, 'sample_output': sout,
                'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                'constraints': constraints}
          for pid, (sin, sout, constraints) in SAMPLE.items()}


def validate(pid: str, data: str):
    if pid not in BATCH7:
        raise ValueError('未対応の問題ID')
    t = data.split()
    if pid == 'abc090_a':
        if len(t) != 3 or any(re.fullmatch('[a-z]{3}', row) is None for row in t):
            raise ValueError('3行3文字の英小文字が必要です')
        return t
    if pid == 'abc089_b':
        if not t or re.fullmatch('[0-9]+', t[0]) is None:
            raise ValueError('Nが不正')
        n = int(t[0]); a = t[1:]
        if not 3 <= n <= 100 or len(a) != n or any(s not in ('P', 'W', 'G', 'Y') for s in a) or not {'P', 'W', 'G'} <= set(a):
            raise ValueError('N/ひなあられの色/3色の存在条件に違反')
        return a
    if pid == 'abc089_c':
        if not t or re.fullmatch('[0-9]+', t[0]) is None:
            raise ValueError('Nが不正')
        n = int(t[0]); names = t[1:]
        if not 1 <= n <= 100000 or len(names) != n or len(set(names)) != n or any(re.fullmatch('[A-Z]{1,10}', s) is None for s in names):
            raise ValueError('N/人名の長さ/大文字/重複条件に違反')
        return names
    if pid == 'abc091_b':
        if not t or re.fullmatch('[0-9]+', t[0]) is None:
            raise ValueError('Nが不正')
        n = int(t[0])
        if not 1 <= n <= 100 or len(t) < n + 2 or re.fullmatch('[0-9]+', t[n + 1]) is None:
            raise ValueError('青の個数/赤の個数が不正')
        m = int(t[n + 1]); blue = t[1:1 + n]; red = t[n + 2:]
        if not 1 <= m <= 100 or len(red) != m or any(re.fullmatch('[a-z]{1,10}', s) is None for s in blue + red):
            raise ValueError('N/M/カード文字列の制約違反')
        return blue, red
    if not t or any(re.fullmatch(r'-?[0-9]+', x) is None for x in t):
        raise ValueError('整数以外が含まれています')
    z = list(map(int, t))
    if pid == 'abc088_a':
        if len(z) != 2 or not 1 <= z[0] <= 10000 or not 0 <= z[1] <= 1000:
            raise ValueError('N/Aの制約違反')
        return tuple(z)
    if pid == 'abc088_b':
        n = z[0]; a = z[1:]
        if not 1 <= n <= 100 or len(a) != n or any(not 1 <= x <= 100 for x in a):
            raise ValueError('N/カード数の制約違反')
        return a
    if pid == 'abc088_c':
        if len(z) != 9 or any(not 0 <= x <= 100 for x in z):
            raise ValueError('9要素/各値0..100に違反')
        return [z[i:i + 3] for i in (0, 3, 6)]
    if pid == 'abc089_a':
        if len(z) != 1 or not 1 <= z[0] <= 1000: raise ValueError('Nの制約違反')
        return z[0]
    if pid == 'abc090_b':
        if len(z) != 2 or not 10000 <= z[0] <= z[1] <= 99999:
            raise ValueError('A/Bの制約違反')
        return tuple(z)
    if pid == 'abc091_a':
        if len(z) != 3 or not all(1 <= x <= 500 for x in z[:2]) or not 1 <= z[2] <= 1000:
            raise ValueError('A/B/Cの制約違反')
        return tuple(z)
    if pid == 'abc092_a':
        if len(z) != 4 or any(not 1 <= x <= 1000 for x in z):
            raise ValueError('A/B/C/Dの制約違反')
        return tuple(z)
    if pid == 'abc092_b':
        if len(z) < 4: raise ValueError('N/D/X/Aが必要')
        n, d, x = z[:3]; a = z[3:]
        if not 1 <= n <= 100 or not 1 <= d <= 100 or not 1 <= x <= 100 or len(a) != n or any(not 1 <= v <= 100 for v in a):
            raise ValueError('N/D/X/Aの制約違反')
        return d, x, a
    if pid == 'abc092_c':
        n = z[0]; a = z[1:]
        if not 2 <= n <= 100000 or len(a) != n or any(not -5000 <= v <= 5000 for v in a):
            raise ValueError('N/Aの制約違反')
        return a
    raise AssertionError(pid)


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str, str]]:
    if pid not in BATCH7 or not 1 <= count <= 80: raise ValueError('問題ID/件数不正')
    r = Random(seed); cases = []; seen = set()
    def add(kind: str, text: str):
        validate(pid, text)
        if text not in seen:
            seen.add(text); cases.append({'category': kind, 'input': text})
        elif kind == 'constraint_max':
            next(c for c in cases if c['input'] == text)['category'] = kind
    def integers(kind: str, *values: int): add(kind, ' '.join(map(str, values)) + '\n')
    def array(kind: str, values: list[int]):
        add(kind, f'{len(values)}\n' + ' '.join(map(str, values)) + '\n')
    if pid == 'abc088_a':
        for n, a in [(1, 0), (500, 0), (501, 0), (499, 499), (500, 499), (501, 1), (10000, 1000), (9999, 0), (2018, 218), (2763, 0), (37, 514)]: add('boundary', f'{n}\n{a}\n')
        while len(cases) < count: add('random', f'{r.randint(1, 10000)}\n{r.randint(0, 1000)}\n')
        if include_large: add('constraint_max', '10000\n1000\n')
    elif pid == 'abc088_b':
        for a in ([1], [100], [3, 1], [2, 7, 4], [20, 18, 2, 18], [1] * 100, [100] * 100, list(range(1, 101)), [100, 1] * 50): array('boundary', list(a))
        while len(cases) < count: array('random', [r.randint(1, 100) for _ in range(r.randint(1, 100))])
        if include_large: array('constraint_max', [100 if i % 2 else 1 for i in range(100)])
    elif pid == 'abc088_c':
        def grid(kind: str, matrix: list[list[int]]): add(kind, '\n'.join(' '.join(map(str, row)) for row in matrix) + '\n')
        for matrix in ([[1, 0, 1], [2, 1, 2], [1, 0, 1]], [[0] * 3 for _ in range(3)], [[100] * 3 for _ in range(3)], [[0, 8, 8]] * 3, [[2, 2, 2], [2, 1, 2], [2, 2, 2]], [[i + j for j in range(3)] for i in range(3)]): grid('boundary', matrix)
        while len(cases) < count:
            a = [r.randint(0, 50) for _ in range(3)]; b = [r.randint(0, 50) for _ in range(3)]
            matrix = [[a[i] + b[j] for j in range(3)] for i in range(3)]
            if r.randint(0, 1): matrix[r.randrange(3)][r.randrange(3)] = r.randint(0, 100)
            grid('random', matrix)
        if include_large: grid('constraint_max', [[100] * 3 for _ in range(3)])
    elif pid == 'abc089_a':
        for n in (1, 2, 3, 4, 5, 6, 8, 9, 999, 1000): integers('boundary', n)
        while len(cases) < count: integers('random', r.randint(1, 1000))
        if include_large: integers('constraint_max', 1000)
    elif pid == 'abc089_b':
        def colors(kind: str, seq: list[str]): add(kind, f'{len(seq)}\n' + ' '.join(seq) + '\n')
        for seq in (['P', 'W', 'G'], ['Y', 'P', 'W', 'G'], ['G', 'W', 'Y', 'P', 'Y', 'W'], ['P'] * 98 + ['W', 'G'], ['Y'] * 97 + ['P', 'W', 'G']): colors('boundary', seq)
        while len(cases) < count:
            n = r.randint(3, 100); seq = ['P', 'W', 'G'] + [r.choice('PWGY') for _ in range(n - 3)]; r.shuffle(seq); colors('random', seq)
        if include_large: colors('constraint_max', ['P', 'W', 'G', 'Y'] * 25)
    elif pid == 'abc089_c':
        def names(kind: str, seq: list[str]): add(kind, f'{len(seq)}\n' + '\n'.join(seq) + '\n')
        def unique_name(i: int, initial: str) -> str:
            suffix = ''
            for _ in range(4):
                suffix = chr(65 + i % 26) + suffix; i //= 26
            return initial + suffix
        for seq in (['M'], ['Z'], ['M', 'A', 'R'], ['MASHIKE', 'RUMOI', 'OBIRA', 'HABORO', 'HOROKANAI'], ['CHOKUDAI', 'RNG', 'MAKOTO', 'AOKI', 'RINGO'], ['M', 'A', 'R', 'C', 'H'], [unique_name(i, 'Z') for i in range(100)]): names('boundary', seq)
        while len(cases) < count:
            n = r.randint(1, 120)
            names('random', [unique_name(i, r.choice('MARCHZ')) for i in range(n)])
        if include_large: names('constraint_max', [unique_name(i, 'MARCH'[i % 5]) for i in range(100000)])
    elif pid == 'abc090_a':
        def letters(kind: str, seq: list[str]): add(kind, '\n'.join(seq) + '\n')
        for seq in (['ant', 'obe', 'rec'], ['edu', 'cat', 'ion'], ['aaa'] * 3, ['zzz'] * 3, ['abc', 'def', 'ghi']): letters('boundary', seq)
        while len(cases) < count: letters('random', [''.join(r.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(3)) for _ in range(3)])
        if include_large: letters('constraint_max', ['zzz'] * 3)
    elif pid == 'abc090_b':
        for a, b in ((10000, 10000), (10001, 10001), (99999, 99999), (10000, 99999), (11009, 11332), (31415, 92653), (12321, 12321), (12322, 12322), (99990, 99999)): integers('boundary', a, b)
        while len(cases) < count:
            a = r.randint(10000, 99999); integers('random', a, r.randint(a, 99999))
        if include_large: integers('constraint_max', 10000, 99999)
    elif pid == 'abc091_a':
        for a, b, c in ((1, 1, 1), (1, 1, 2), (1, 1, 3), (50, 100, 120), (500, 100, 1000), (19, 123, 143), (19, 123, 142), (500, 500, 1000)): integers('boundary', a, b, c)
        while len(cases) < count: integers('random', r.randint(1, 500), r.randint(1, 500), r.randint(1, 1000))
        if include_large: integers('constraint_max', 500, 500, 1000)
    elif pid == 'abc091_b':
        def cards(kind: str, blue: list[str], red: list[str]):
            add(kind, f'{len(blue)}\n' + '\n'.join(blue) + f'\n{len(red)}\n' + '\n'.join(red) + '\n')
        for blue, red in ((['apple', 'orange', 'apple'], ['grape']), (['x'], ['x']), (['z'], ['a']), (['apple', 'orange', 'apple'], ['apple'] * 5), (['voldemort'], ['voldemort'] * 10), (['a'] * 100, ['a'] * 100), (['a'] * 100, ['b'] * 100)):
            cards('boundary', blue, red)
        words = ('apple', 'banana', 'orange', 'kiwi', 'x', 'z')
        while len(cases) < count:
            cards('random', [r.choice(words) for _ in range(r.randint(1, 100))], [r.choice(words) for _ in range(r.randint(1, 100))])
        if include_large: cards('constraint_max', ['abcdefghij'] * 100, ['zzzzzzzzzz'] * 100)
    elif pid == 'abc092_a':
        for a, b, c, d in ((1, 1, 1, 1), (1000, 1000, 1000, 1000), (600, 300, 220, 420), (555, 555, 400, 200), (549, 817, 715, 603), (1000, 1, 1, 1000)):
            add('boundary', f'{a}\n{b}\n{c}\n{d}\n')
        while len(cases) < count: add('random', '\n'.join(str(r.randint(1, 1000)) for _ in range(4)) + '\n')
        if include_large: add('constraint_max', '1000\n1000\n1000\n1000\n')
    elif pid == 'abc092_b':
        def chocolate(kind: str, d: int, x: int, a: list[int]): add(kind, f'{len(a)}\n{d} {x}\n' + '\n'.join(map(str, a)) + '\n')
        for d, x, a in ((1, 1, [1]), (100, 100, [1]), (7, 1, [2, 5, 10]), (8, 20, [1, 10]), (30, 44, [26, 18, 81, 18, 6]), (100, 100, [100] * 100), (100, 100, [1] * 100)):
            chocolate('boundary', d, x, a)
        while len(cases) < count: chocolate('random', r.randint(1, 100), r.randint(1, 100), [r.randint(1, 100) for _ in range(r.randint(1, 100))])
        if include_large: chocolate('constraint_max', 100, 100, [100] * 100)
    else:  # abc092_c
        for a in ([0, 0], [5000, -5000], [3, 5, -1], [1, 1, 1, 2, 0], [-5000, 5000] * 5, [5000] * 100, [-5000] * 100, list(range(-20, 21))): array('boundary', list(a))
        while len(cases) < count: array('random', [r.randint(-5000, 5000) for _ in range(r.randint(2, 65))])
        if include_large: array('constraint_max', [(-5000 if i % 2 == 0 else 5000) for i in range(100000)])
    if include_large:
        maximum = [c for c in cases if c['category'] == 'constraint_max']
        if not maximum: raise RuntimeError('最大規模ケースがありません')
        last = maximum[-1]
        return [c for c in cases if c['input'] != last['input']][:count] + [last]
    return cases[:count]


def independent_check(pid: str, data: str, expected: str) -> bool:
    v = validate(pid, data)
    text = expected.strip()
    if pid == 'abc088_a':
        n, a = v
        # Enumerate all 500-yen coin counts independently of the remainder solution.
        return text == ('Yes' if any(0 <= n - 500 * k <= a for k in range(n // 500 + 1)) else 'No')
    if pid == 'abc088_b':
        a = list(v); alice = bob = 0
        for i in range(len(a)):
            card = max(a); a.remove(card)
            if i % 2: bob += card
            else: alice += card
        return text == str(alice - bob)
    if pid == 'abc088_c':
        c = v
        # An additive matrix has identical difference between any two rows.
        possible = all(c[i][j] - c[0][j] == c[i][0] - c[0][0] for i in range(1, 3) for j in range(1, 3))
        return text == ('Yes' if possible else 'No')
    if pid == 'abc089_a':
        return text == str(len(range(0, v - 2, 3)))
    if pid == 'abc089_b':
        return text == ('Four' if len(set(v)) == 4 else 'Three')
    if pid == 'abc089_c':
        # DP over 5 initial letters: count selecting 0/1/2/3 distinct initials.
        count = Counter(s[0] for s in v if s[0] in 'MARCH')
        dp = [1, 0, 0, 0]
        for ch in 'MARCH':
            for k in (3, 2, 1): dp[k] += dp[k - 1] * count[ch]
        return text == str(dp[3])
    if pid == 'abc090_a':
        return text == ''.join(row[i] for i, row in enumerate(v))
    if pid == 'abc090_b':
        lo, hi = v
        # Generate every possible 5-digit palindrome instead of traversing [A,B].
        count = 0
        for first in range(1, 10):
            for second in range(10):
                for middle in range(10):
                    p = 10001 * first + 1010 * second + 100 * middle
                    count += lo <= p <= hi
        return text == str(count)
    if pid == 'abc091_a':
        a, b, c = v
        return text == ('Yes' if c - a <= b else 'No')
    if pid == 'abc091_b':
        blue, red = v
        return text == str(max([0] + [blue.count(s) - red.count(s) for s in set(blue)]))
    if pid == 'abc092_a':
        a, b, c, d = v
        return text == str(min(a + c, a + d, b + c, b + d))
    if pid == 'abc092_b':
        d, x, a = v
        total = x
        for day in range(1, d + 1):
            for frequency in a:
                if (day - 1) % frequency == 0: total += 1
        return text == str(total)
    if pid == 'abc092_c':
        a = [0] + v + [0]
        # Prefix/suffix path distances: removing i bridges its two neighbors.
        prefix = [0] * len(a)
        for i in range(1, len(a)):
            prefix[i] = prefix[i - 1] + abs(a[i] - a[i - 1])
        suffix = [0] * len(a)
        for i in range(len(a) - 2, -1, -1):
            suffix[i] = suffix[i + 1] + abs(a[i] - a[i + 1])
        result = [prefix[i - 1] + abs(a[i + 1] - a[i - 1]) + suffix[i + 1]
                  for i in range(1, len(a) - 1)]
        return text == '\n'.join(map(str, result))
    raise AssertionError(pid)
