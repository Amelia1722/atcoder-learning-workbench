"""Reviewed C tasks: Fenwick ranges, lazy OS mass, Gray-code cuts and cancellation."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import Counter
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(425,431))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==425:
        n,q=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=200000 and 1<=q<=200000 and len(rows)==q+2 and all(1<=v<=10**9 for v in a),'shape');qs=[];reported=False
        for row in rows[2:]:
            v=ints(row);require(v[0] in (1,2) and len(v)==(2 if v[0]==1 else 3),'query')
            if v[0]==1:require(1<=v[1]<=n,'rotation')
            else:require(1<=v[1]<=v[2]<=n,'range');reported=True
            qs.append(v)
        require(reported,'query2 guarantee');return a,tuple(qs)
    if number==426:
        n,q=ints(rows[0],2);require(2<=n<=10**6 and 1<=q<=200000 and len(rows)==q+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=x<y<=n for x,y in a),'versions');return n,a
    if number==427:
        n,m=ints(rows[0],2);require(2<=n<=10 and 1<=m<=n*(n-1)//2 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(len(set(a))==m and all(1<=u<v<=n for u,v in a),'simple');return n,a
    if number==428:
        q=ints(rows[0],1)[0];require(1<=q<=800000 and len(rows)==q+1,'shape');length=0;qs=[]
        for row in rows[1:]:
            if row=='2':require(length>0,'delete nonempty');length-=1;qs.append('')
            else:require(row in ('1 (','1 )'),'append');length+=1;qs.append(row[-1])
        return (tuple(qs),)
    if number==429:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(3<=n<=200000 and all(1<=v<=n for v in a),'values');return (a,)
    require(len(rows)==2,'shape');n,a,b=ints(rows[0],3);s=rows[1];require(1<=n<=300000 and 1<=a<=n and 1<=b<=n and len(s)==n and set(s)<=set('ab'),'drive');return a,b,s
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==425:
        a,qs=cast(tuple[tuple[int,...],Queries],data);n=len(a);tree=[0]+list(a)
        for j in range(1,n+1):
            p=j+(j&-j)
            if p<=n:tree[p]+=tree[j]
        def prefix(count:int)->int:
            total=0
            while count:total+=tree[count];count-=count&-count
            return total
        head=0;out=[]
        for v in qs:
            if v[0]==1:head=(head+v[1])%n
            else:
                left=(head+v[1]-1)%n;length=v[2]-v[1]+1;right=left+length;out.append(str(prefix(right)-prefix(left) if right<=n else prefix(n)-prefix(left)+prefix(right-n)))
        return '\n'.join(out)
    if number==426:
        n,qs=cast(tuple[int,tuple[tuple[int,int],...]],data);counts:dict[int,int]={}
        def clear(node:int,left:int,right:int,bound:int)->int:
            value=counts.get(node,right-left+1)
            if not value or left>bound:return 0
            if right<=bound:counts[node]=0;return value
            middle=(left+right)//2;removed=clear(node*2,left,middle,bound)+clear(node*2+1,middle+1,right,bound);counts[node]=value-removed;return removed
        def add(node:int,left:int,right:int,position:int,amount:int)->None:
            value=counts.get(node,right-left+1)
            if left==right:counts[node]=value+amount;return
            middle=(left+right)//2
            if value==0:counts[node*2]=counts[node*2+1]=0
            if position<=middle:add(node*2,left,middle,position,amount)
            else:add(node*2+1,middle+1,right,position,amount)
            counts[node]=value+amount
        out=[]
        for x,y in qs:amount=clear(1,1,n,x);add(1,1,n,y,amount);out.append(str(amount))
        return '\n'.join(out)
    if number==427:
        n,a=cast(tuple[int,tuple[tuple[int,int],...]],data);adj=[[] for _ in range(n)];colors=[0]*n;cross=best=0;previous=0
        for u,v in a:adj[u-1].append(v-1);adj[v-1].append(u-1)
        for j in range(1,1<<n):
            gray=j^(j>>1);v=(gray^previous).bit_length()-1
            for w in adj[v]:cross+=1 if colors[v]==colors[w] else -1
            colors[v]^=1;best=max(best,cross);previous=gray
        return str(len(a)-best)
    if number==428:
        qs=cast(tuple[str,...],data[0]);history=[(0,0)];out=[]
        for c in qs:
            if c:
                opens,closes=history[-1]
                if c=='(':opens+=1
                elif opens:opens-=1
                else:closes+=1
                history.append((opens,closes))
            else:history.pop()
            out.append('Yes' if history[-1]==(0,0) else 'No')
        return '\n'.join(out)
    if number==429:
        a=cast(tuple[int,...],data[0]);counts=Counter(a);n=len(a);alltriples=n*(n-1)*(n-2)//6;same=sum(c*(c-1)*(c-2)//6 for c in counts.values());distinct=one=two=0
        for count in counts.values():distinct+=two*count;two+=one*count;one+=count
        return str(alltriples-same-distinct)
    a,b,s=cast(tuple[int,int,str],data);pa=[0];pb=[0]
    for c in s:pa.append(pa[-1]+(c=='a'));pb.append(pb[-1]+(c=='b'))
    answer=0
    for left in range(len(s)):first=bisect_left(pa,pa[left]+a,left+1);last=bisect_left(pb,pb[left]+b,left+1);answer+=max(0,last-first)
    return str(answer)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc425_c':"n,q=map(int,input().split());a=list(map(int,input().split()));prefix=[0]\nfor v in a+a:prefix.append(prefix[-1]+v)\nhead=0\nfor _ in range(q):\n v=list(map(int,input().split()))\n if v[0]==1:head=(head+v[1])%n\n else:print(prefix[head+v[2]]-prefix[head+v[1]-1])\n",
'abc426_c':"from heapq import heappop,heappush\nn,q=map(int,input().split());heap=list(range(1,n+1));counts=[1]*(n+1)\nfor _ in range(q):\n x,y=map(int,input().split());total=0\n while heap and heap[0]<=x:\n  v=heappop(heap);total+=counts[v];counts[v]=0\n if not counts[y]:heappush(heap,y)\n counts[y]+=total;print(total)\n",
'abc427_c':"n,m=map(int,input().split());a=[tuple(int(v)-1 for v in input().split()) for _ in range(m)];print(min(sum((mask>>u&1)==(mask>>v&1) for u,v in a) for mask in range(1<<n)))\n",
'abc428_c':"q=int(input());history=[(0,0)]\nfor _ in range(q):\n parts=input().split()\n if parts[0]=='2':history.pop()\n else:\n  balance,least=history[-1];balance+=1 if parts[1]=='(' else -1;history.append((balance,min(least,balance)))\n balance,least=history[-1];print('Yes' if balance==0 and least>=0 else 'No')\n",
'abc429_c':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));print(sum(c*(c-1)//2*(n-c) for c in Counter(a).values()))\n",
'abc430_c':"n,a,b=map(int,input().split());s=input();rightA=rightB=0;countA=countB=0;answer=0\nfor left in range(n):\n while rightA<n and countA<a:countA+=s[rightA]=='a';rightA+=1\n while rightB<n and countB<b:countB+=s[rightB]=='b';rightB+=1\n first=rightA if countA>=a else n+1;last=rightB-1 if countB>=b else n;answer+=max(0,last-first+1)\n countA-=s[left]=='a';countB-=s[left]=='b'\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17600+number)
    if number==425:
        def ranges(a:list[int],qs:list[str])->str:return f'{len(a)} {len(qs)}\n'+line(a)+'\n'.join(qs)+'\n'
        raws=[ranges(a,qs) for a,qs in (([1],['2 1 1']),([1],['1 1','2 1 1']),([1,2],['1 1','2 1 1']),([1,2,3],['1 2','2 1 3']))]
        for n in range(3,15):qs=['1 '+str(rng.randint(1,n)) if rng.randrange(2) else '2 '+' '.join(map(str,sorted((rng.randint(1,n),rng.randint(1,n))))) for _ in range(n+5)]+[f'2 1 {n}'];raws.append(ranges([rng.randint(1,100) for _ in range(n)],qs))
        raws.extend([ranges(list(range(1,200001)),['1 199999','2 1 200000']*100000),ranges([10**9]*200000,['2 1 200000']*200000)])
    elif number==426:
        def versions(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{x} {y}\n' for x,y in a)
        raws=[versions(n,a) for n,a in ((2,[(1,2)]),(2,[(1,2),(1,2)]),(3,[(1,2),(2,3)]),(3,[(2,3),(1,2)]))];raws.extend(versions(n,[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(n+5)]) for n in range(3,15));raws.extend([versions(10**6,[(j,10**6) for j in range(1,200000)]+[(999999,10**6)]),versions(10**6,[(999999,10**6)]*200000)])
    elif number==427:
        def graph(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{u} {v}\n' for u,v in a)
        raws=[graph(n,a) for n,a in ((2,[(1,2)]),(3,[(1,2),(2,3),(1,3)]),(3,[(1,2),(2,3)]),(4,[(1,2),(2,3),(3,4),(1,4)]))]
        for j in range(12):n=4+j%7;edges=[(u,v) for u in range(1,n+1) for v in range(u+1,n+1)];raws.append(graph(n,rng.sample(edges,rng.randint(1,len(edges)))))
        raws.extend([graph(10,[(1,j) for j in range(2,11)]),graph(10,[(u,v) for u in range(1,11) for v in range(u+1,11)])])
    elif number==428:
        def brackets(qs:list[str])->str:return f'{len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[brackets(qs) for qs in (['1 ('],['1 )'],['1 (','1 )'],['1 )','2'])]
        for n in range(3,15):
            qs=[];length=0
            for _ in range(n+5):
                if length and rng.randrange(3)==0:qs.append('2');length-=1
                else:qs.append('1 '+rng.choice('()'));length+=1
            raws.append(brackets(qs))
        raws.extend([brackets(['1 (']*400000+['1 )']*400000),brackets(['1 )','2']*400000)])
    elif number==429:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1,1,1],[1,1,2],[1,2,3],[1,1,2,2])];raws.extend(arr([rng.randint(1,n) for _ in range(n)]) for n in range(4,16));raws.extend([arr([1]*100000+[2]*100000),arr([200000]*200000)])
    else:
        def drive(a:int,b:int,s:str)->str:return f'{len(s)} {a} {b}\n{s}\n'
        raws=[drive(a,b,s) for a,b,s in ((1,1,'a'),(1,1,'b'),(1,1,'ab'),(2,2,'aabb'))];raws.extend(drive(rng.randint(1,n),rng.randint(1,n),''.join(rng.choice('ab') for _ in range(n))) for n in range(3,15));raws.extend([drive(1,1,'ab'*150000),drive(300000,300000,'a'*300000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc425_c':('回転は先頭位置の移動だけとして扱えます。','配列を2回連結した累積和を作ると、回転後の区間和も引き算1回で求められます。','疑似コード: A+Aのprefixを作る; head=(head+c)%N; 照会[l,r]はprefix[head+r]-prefix[head+l-1]。'),
'abc426_c':('各OSバージョンを持つPCの数をまとめます。','存在するバージョンを最小heapで管理し、X以下を取り出して個数をYへ移します。','疑似コード: count[v]=1,heap=1..N; heap最小<=Xの間popしcountを集計して0へ; Y未存在ならheap追加; count[Y]+=合計; 合計出力。'),
'abc427_c':('二部グラフに残せる辺は、頂点の2色が異なる辺だけです。','Nは10以下なので全2^N通りの塗り方を調べます。','疑似コード: mask=0..2^N-1; 各辺で端点色が同じものを数える; その最小が削除本数。'),
'abc428_c':('良い括弧列は累積の開き数が負にならず、最後が0です。','末尾追加・削除なので、累積値と最小値の履歴をstackで保存できます。','疑似コード: history=[(0,0)]; 追加でbalanceを±1しminも更新してpush; 削除でpop; 最後balance=0かつmin>=0ならYes。'),
'abc429_c':('等しい2個と異なる1個を選びます。','値vの出現数cなら、同じ2個の選び方c*(c-1)/2と異なるN-cを掛けます。','疑似コード: Counter(A)を作る; 各頻度cでc*(c-1)//2*(N-c)を加算して出力。'),
'abc430_c':('左端を決めると、必要なaに到達する右端と、bの上限を超える右端が決まります。','2つの右端を単調に進め、条件を満たす右端の区間長を合計します。','疑似コード: 左端順にa数>=Aとなる最初の右端firstとb数>=Bとなる最初の右端badを2pointerで更新; first<=r<badの個数を加算; 左端文字を各カウンタから除く。')}

TITLES={'abc425_c': 'Rotate and Sum Query', 'abc426_c': 'Upgrade Required', 'abc427_c': 'Bipartize', 'abc428_c': 'Brackets Stack Query', 'abc429_c': 'Odd One Subsequence', 'abc430_c': 'Truck Driver'}
PUBLISHED_SAMPLES={'abc425_c': [{'input': '4 3\n3 1 4 5\n2 1 3\n1 1\n2 2 3\n', 'expected': '8\n9\n'}, {'input': '5 7\n1 2 4 8 16\n2 1 5\n1 4\n1 5\n2 1 5\n2 2 4\n1 1\n2 3 3\n', 'expected': '31\n31\n7\n4\n'}], 'abc426_c': [{'input': '8 5\n2 6\n3 5\n1 7\n5 7\n7 8\n', 'expected': '2\n1\n0\n3\n7\n'}], 'abc427_c': [{'input': '5 8\n1 2\n1 3\n1 4\n2 3\n2 5\n3 4\n3 5\n4 5\n', 'expected': '2\n'}, {'input': '2 1\n1 2\n', 'expected': '0\n'}, {'input': '10 20\n5 9\n1 4\n3 8\n1 6\n4 10\n5 7\n5 6\n3 7\n3 6\n5 10\n1 3\n3 4\n6 7\n1 2\n4 7\n1 5\n1 9\n9 10\n4 5\n8 9\n', 'expected': '5\n'}], 'abc428_c': [{'input': '8\n1 (\n2\n1 (\n1 )\n2\n1 (\n1 )\n1 )\n', 'expected': 'No\nYes\nNo\nYes\nNo\nNo\nNo\nYes\n'}], 'abc429_c': [{'input': '5\n3 2 5 2 2\n', 'expected': '6\n'}, {'input': '3\n1 1 1\n', 'expected': '0\n'}], 'abc430_c': [{'input': '11 4 2\nabbaaabaaba\n', 'expected': '3\n'}, {'input': '13 1 2\nbbbbbbbbbbbbb\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
