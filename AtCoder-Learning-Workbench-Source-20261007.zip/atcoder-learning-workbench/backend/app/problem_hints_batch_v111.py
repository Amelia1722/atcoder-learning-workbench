"""Statement-checked three-stage hints for ABC191–193 B."""
HINTS_V111={
 'abc191_b':(
  'Xと等しい要素だけを取り除き、それ以外は元の順序を保てばよいです。',
  'Aを左から1回走査し、a != X の要素だけを新しい配列へ追加します。残る要素が0個なら空行を出力します。',
  '疑似コード:\nans = []\nfor a in A:\n  if a != X:\n    ans.append(a)\nprint(ansを空白区切り)',
 ),
 'abc192_b':(
  '1文字目・3文字目…は小文字、2文字目・4文字目…は大文字である必要があります。',
  '0-indexedなら偶数indexが小文字、奇数indexが大文字です。各文字を1回ずつ確認すれば十分です。',
  '疑似コード:\nfor i, c in enumerate(S):\n  if i % 2 == 0 and cが小文字でない: No\n  if i % 2 == 1 and cが大文字でない: No\n最後まで通れば Yes',
 ),
 'abc193_b':(
  '店iへはA_i分後に着きます。その時までに在庫はA_i回減るので、購入可能なのは X_i > A_i の店だけです。',
  '購入可能な店だけに絞り、そのP_iの最小値を取ります。1軒もなければ-1です。X_i = A_i は到着時に在庫0なので不可です。',
  '疑似コード:\nans = INF\nfor (A, P, X) in shops:\n  if X > A:\n    ans = min(ans, P)\nprint(-1 if ans == INF else ans)',
 ),
}
