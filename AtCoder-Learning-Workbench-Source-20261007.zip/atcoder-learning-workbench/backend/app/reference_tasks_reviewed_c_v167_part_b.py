"""Weighted prefixes, circular intervals, leaf pruning and selection DP."""
from __future__ import annotations
from bisect import bisect_right
from collections import deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(267,273))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==269:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(0<=n<2**60 and n.bit_count()<=15,'bits');return (n,)
    if number==267:
        n,m=ints(rows[0],2);require(1<=m<=n<=200000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(-200000<=v<=200000 for v in a),'values');return m,a
    if number==270:
        n,x,y=ints(rows[0],3);require(2<=n<=200000 and 1<=x<=n and 1<=y<=n and x!=y and len(rows)==n,'shape');edges=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);parent=list(range(n))
        def find(j:int)->int:
            while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
            return j
        for u,v in edges:
            require(1<=u<=n and 1<=v<=n and u!=v,'edge');a,b=find(u-1),find(v-1);require(a!=b,'acyclic');parent[a]=b
        return n,x,y,edges
    n=ints(rows[0],1)[0];require(len(rows)==2,'shape');a=ints(rows[1],n)
    if number==268:require(3<=n<=200000 and len(set(a))==n and all(0<=v<n for v in a),'permutation')
    elif number==271:require(1<=n<=300000 and all(1<=v<=10**9 for v in a),'volumes')
    else:require(2<=n<=200000 and len(set(a))==n and all(0<=v<=10**9 for v in a),'distinct values')
    return (a,)
def _circular_intervals(p:tuple[int,...])->int:
    n=len(p);difference=[0]*(n+1)
    for index,dish in enumerate(p):
        start=(dish-index-1)%n;end=start+3;difference[start]+=1
        if end<=n:difference[end]-=1
        else:difference[n]-=1;difference[0]+=1;difference[end-n]-=1
    maximum=current=0
    for change in difference[:-1]:current+=change;maximum=max(maximum,current)
    return maximum
def _pruned_path(n:int,x:int,y:int,edges:tuple[Pair,...])->str:
    graph=[[] for _ in range(n+1)]
    for u,v in edges:graph[u].append(v);graph[v].append(u)
    degree=[len(row) for row in graph];removed=[False]*(n+1);queue=deque(j for j in range(1,n+1) if degree[j]==1 and j not in (x,y))
    while queue:
        vertex=queue.popleft();removed[vertex]=True
        for v in graph[vertex]:
            if removed[v]:continue
            degree[v]-=1
            if degree[v]==1 and v not in (x,y):queue.append(v)
    path=[x];previous=0;current=x
    while current!=y:
        following=next(v for v in graph[current] if v!=previous and not removed[v]);path.append(following);previous,current=current,following
    return ' '.join(map(str,path))
def _two_even(a:tuple[int,...])->int:
    dp:list[list[int|None]]=[[None,None] for _ in range(3)];dp[0][0]=0
    for value in a:
        for chosen in (2,1):
            for parity in (0,1):
                previous=dp[chosen-1][parity]
                if previous is None:continue
                target=parity^(value%2);candidate=previous+value;old=dp[chosen][target]
                if old is None or candidate>old:dp[chosen][target]=candidate
    return -1 if dp[2][0] is None else cast(int,dp[2][0])
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==267:
        m,a=cast(tuple[int,tuple[int,...]],data);sums=[0];weighted=[0]
        for j,value in enumerate(a,1):sums.append(sums[-1]+value);weighted.append(weighted[-1]+j*value)
        return str(max(weighted[j+m]-weighted[j]-j*(sums[j+m]-sums[j]) for j in range(len(a)-m+1)))
    if number==268:return str(_circular_intervals(cast(tuple[int,...],data[0])))
    if number==269:
        n=cast(int,data[0]);values=[0]
        for j in range(60):
            if n>>j&1:values+= [v+(1<<j) for v in values]
        return '\n'.join(map(str,values))
    if number==270:return _pruned_path(*cast(tuple[int,int,int,tuple[Pair,...]],data))
    if number==271:
        a=cast(tuple[int,...],data[0]);unique=sorted(set(a));lo=0;hi=len(a)+1
        while hi-lo>1:
            middle=(hi+lo)//2;owned=bisect_right(unique,middle)
            if len(a)+owned>=2*middle:lo=middle
            else:hi=middle
        return str(lo)
    return str(_two_even(cast(tuple[int,...],data[0])))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError,StopIteration):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc267_c':"n,m=map(int,input().split());a=list(map(int,input().split()));plain=sum(a[:m]);value=sum((j+1)*v for j,v in enumerate(a[:m]));answer=value\nfor j in range(m,n):\n value+=m*a[j]-plain;plain+=a[j]-a[j-m];answer=max(answer,value)\nprint(answer)\n",
'abc268_c':"n=int(input());p=list(map(int,input().split()));count=[0]*n\nfor j,v in enumerate(p):\n for d in (-1,0,1):count[(v-j+d)%n]+=1\nprint(max(count))\n",
'abc269_c':"n=int(input());values=[];value=n\nwhile True:\n values.append(value)\n if value==0:break\n value=(value-1)&n\nprint(*values[::-1],sep='\\n')\n",
'abc270_c':"n,x,y=map(int,input().split());g=[[] for _ in range(n+1)]\nfor _ in range(n-1):\n u,v=map(int,input().split());g[u].append(v);g[v].append(u)\nparent=[-1]*(n+1);parent[x]=0;stack=[x]\nwhile stack:\n u=stack.pop()\n if u==y:break\n for v in g[u]:\n  if parent[v]<0:parent[v]=u;stack.append(v)\npath=[];u=y\nwhile u:path.append(u);u=parent[u]\nprint(*path[::-1])\n",
'abc271_c':"from collections import deque\nn=int(input());a=list(map(int,input().split()));unique=set(a);duplicates=n-len(unique);books=deque(sorted(unique));wanted=1\nwhile True:\n if books and books[0]==wanted:books.popleft();wanted+=1;continue\n if len(books)+duplicates<2:break\n for _ in range(2):\n  if duplicates:duplicates-=1\n  else:books.pop()\n wanted+=1\nprint(wanted-1)\n",
'abc272_c':"n=int(input());a=list(map(int,input().split()));even=sorted((v for v in a if v%2==0),reverse=True);odd=sorted((v for v in a if v%2),reverse=True);answer=-1\nfor group in (even,odd):\n if len(group)>=2:answer=max(answer,group[0]+group[1])\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');n=int(pid[3:6]);rng=random.Random(16700+n)
    if n==267:
        def weighted(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
        raws=[weighted(1,[-200000]),weighted(1,[0]),weighted(1,[200000]),weighted(2,[-1,-2])]
        for size in range(3,15):raws.append(weighted(rng.randint(1,size),[rng.randint(-200000,200000) for _ in range(size)]))
        raws.extend([weighted(100000,[-200000]*100000+[200000]*100000),weighted(200000,[200000]*200000)])
    elif n==268:
        def permutation(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[permutation([0,1,2]),permutation([0,2,1]),permutation([1,2,0]),permutation([2,0,1])]
        for size in range(4,16):a=list(range(size));rng.shuffle(a);raws.append(permutation(a))
        a=list(range(200000));rng.shuffle(a);raws.extend([permutation(a),permutation(list(range(200000)))])
    elif n==269:raws=[f'{v}\n' for v in (0,1,2,3,4,5,7,8,10,15,16,17,255,32767,1<<59,(1<<59)+1,((1<<15)-1)<<44,((1<<15)-1)<<45)]
    elif n==270:
        def tree(n:int,x:int,y:int,e:list[Pair])->str:return f'{n} {x} {y}\n'+''.join(line(edge) for edge in e)
        raws=[tree(2,1,2,[(1,2)]),tree(2,2,1,[(2,1)]),tree(3,2,3,[(1,2),(1,3)]),tree(4,2,4,[(1,2),(2,3),(3,4)])]
        for size in range(5,17):x,y=rng.sample(range(1,size+1),2);raws.append(tree(size,x,y,[(j,rng.randint(1,j-1)) for j in range(2,size+1)]))
        raws.extend([tree(200000,199999,200000,[(1,j) for j in range(2,200001)]),tree(200000,1,200000,[(j,j+1) for j in range(1,200000)])])
    elif n==271:
        def books(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[books([1]),books([2]),books([1,1]),books([2,2])]
        for size in range(3,15):raws.append(books([rng.randint(1,30) for _ in range(size)]))
        raws.extend([books(list(range(1,300001))),books([10**9]*300000)])
    else:
        def values(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[values([0,1]),values([0,2]),values([1,3]),values([2,1])]
        for size in range(3,15):raws.append(values(rng.sample(range(1000),size)))
        raws.extend([values(list(range(200000))),values(list(range(10**9,10**9-200000,-1)))])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc267_c':('隣り合う区間へ移るときの変化を考えます。','現在の区間和をplain、重み付き和をvalueとします。区間を右へずらすと、全要素の重みが1減り、新しい要素にMの重みが付きます。','疑似コード: plain=sum(first M); value=weighted sum(first M); answer=value; for new index j: value+=M*A[j]-plain; plain+=A[j]-A[j-M]; answer=max(answer,value); print(answer)。'),
'abc268_c':('各人が喜ぶ回転回数は3通りだけです。','位置jにある料理pは、pの近くへ届く回転回数p-j-1,p-j,p-j+1で喜ばれます。Nで割った余りごとに人数を加算します。','疑似コード: count=[0]*N; for (j,p): for d in {-1,0,1}: count[(p-j+d)%N]+=1; print(max(count))。'),
'abc269_c':('Nで立っているビットだけを自由に選べます。','submaskをNから降順に列挙する式 (value-1)&N を使い、0まで集めて逆順に出力します。最大でも2^15個です。','疑似コード: value=N; answers=[]; loop: append(value); if value==0: break; value=(value-1)&N; print reversed answers, one per line。'),
'abc270_c':('木ではXからYへの道は一つだけです。','Xから探索し、各頂点へ初めて到達した際の親を記録します。Yから親をたどって戻り、逆順にすれば道になります。','疑似コード: DFS from X recording parent; path=[]; v=Y; while v!=0: append v; v=parent[v]; print(reverse(path))。'),
'abc271_c':('重複した巻は読み進める役に立たず、交換に使えます。','次の必要巻があれば確保します。なければ重複本、続いて最も大きい巻から2冊を売り、必要巻へ交換します。残りが2冊未満なら終了です。','疑似コード: unique=sorted(set(A)); spare=N-len(unique); wanted=1; while next volume exists or at least2 books available: consume existing wanted, otherwise sell2 spare/largest books; wanted+=1; print(wanted-1)。'),
'abc272_c':('和が偶数になるのは、2数の偶奇が同じときです。','偶数と奇数へ分け、それぞれ大きい順の上位2個を足します。候補がなければ-1です。','疑似コード: split A into even and odd; sort descending; candidates=[sum(first2) for group with size>=2]; print(max(candidates) if nonempty else -1)。')}

TITLES={'abc267_c': 'Index × A(Continuous ver.)', 'abc268_c': 'Chinese Restaurant', 'abc269_c': 'Submask', 'abc270_c': 'Simple path', 'abc271_c': 'Manga', 'abc272_c': 'Max Even'}
PUBLISHED_SAMPLES={'abc267_c': [{'input': '4 2\n5 4 -1 8\n', 'expected': '15\n'}, {'input': '10 4\n-3 1 -4 1 -5 9 -2 6 -5 3\n', 'expected': '31\n'}], 'abc268_c': [{'input': '4\n1 2 0 3\n', 'expected': '4\n'}, {'input': '3\n0 1 2\n', 'expected': '3\n'}, {'input': '10\n3 9 6 1 7 2 8 0 5 4\n', 'expected': '5\n'}], 'abc269_c': [{'input': '11\n', 'expected': '0\n1\n2\n3\n8\n9\n10\n11\n'}, {'input': '0\n', 'expected': '0\n'}, {'input': '576461302059761664\n', 'expected': '0\n524288\n549755813888\n549756338176\n576460752303423488\n576460752303947776\n576461302059237376\n576461302059761664\n'}], 'abc270_c': [{'input': '5 2 5\n1 2\n1 3\n3 4\n3 5\n', 'expected': '2 1 3 5\n'}, {'input': '6 1 2\n3 1\n2 5\n1 2\n4 1\n2 6\n', 'expected': '1 2\n'}], 'abc271_c': [{'input': '6\n1 2 4 6 7 271\n', 'expected': '4\n'}, {'input': '10\n1 1 1 1 1 1 1 1 1 1\n', 'expected': '5\n'}, {'input': '1\n5\n', 'expected': '0\n'}], 'abc272_c': [{'input': '3\n2 3 4\n', 'expected': '6\n'}, {'input': '2\n1 0\n', 'expected': '-1\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
