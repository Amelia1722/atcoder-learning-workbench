"""Conservative, read-only hint/AC evidence projection.

Submission time is authoritative; sync time is irrelevant. No historical rows
are rewritten and no hint count is converted into a mastery score.
"""
from __future__ import annotations

from collections import defaultdict
import json
from typing import Any

NEAR_DIFFICULTY_GAP = 200  # Half of the UI's existing 400-point colour band.
DIFFICULTY_RULE = '公開Difficultyが同じ色帯・差200以内（近い難易度の目安）'
EVIDENCE_NOTE = 'この別問題のAC時刻までに、アプリ内ヒントの記録なし。外部の助けの有無は不明です。理解を確かめる材料であり、自力解答・習得の証明ではありません。'
# Broad concepts cannot establish transfer merely by sharing a heading.
BROAD_ANCHORS = {'sec-7-1', 'sec-8-1', 'sec-28-9', 'sec-28-11'}
# Small, code-reviewed fallback map; do not promote links in the user's DB.
# Sources: existing HINTS stage 2/3 in problem_hints.py and each linked task.
# Supporting output sorting in ABC155 C is not its core counting technique.
REVIEWED_HINT_TECHNIQUES = {
    'abc155_a': (('sec-1-3',), '集合による異なる値の個数', 'https://atcoder.jp/contests/abc155/tasks/abc155_a'),
    'abc155_c': (('sec-1-4',), '出現回数を数えて最大頻度を選ぶ', 'https://atcoder.jp/contests/abc155/tasks/abc155_c'),
    'abc231_b': (('sec-1-4',), '出現回数を数えて最大頻度を選ぶ', 'https://atcoder.jp/contests/abc231/tasks/abc231_b'),
}


def _tables(con) -> set[str]:
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def _valid_epoch(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def load_context(con, user_id: str) -> dict:
    """Read this profile only; absent optional legacy tables mean no evidence."""
    result: dict[str, Any] = {'hints': defaultdict(list), 'unknown': set(), 'techniques': {}}
    if not user_id:
        return result
    tables = _tables(con)
    observed_levels = defaultdict(set)
    expected_levels = {}
    first_stage_recorded = set()
    if 'lab_events' in tables:
        for row in con.execute("SELECT id,problem_id,payload_json,recorded_at FROM lab_events WHERE user_id=? AND kind='hint_used' AND problem_id IS NOT NULL ORDER BY recorded_at,id", (user_id,)):
            try:
                body = json.loads(row['payload_json'])
                raw = int(body['level'])
                if not 1 <= raw <= (3 if body.get('code_presented') is True else 5):
                    raise ValueError('Invalid original hint stage')
                level = raw if body.get('code_presented') is True else (1 if raw <= 2 else 2 if raw <= 4 else 3)
                if not 1 <= level <= 3:
                    raise ValueError('Invalid hint stage')
            except (ValueError, TypeError, KeyError):
                result['unknown'].add(row['problem_id'])
                continue
            if _valid_epoch(row['recorded_at']):
                if raw == 1:
                    first_stage_recorded.add(row['problem_id'])
                observed_levels[row['problem_id']].add(level)
                result['hints'][row['problem_id']].append({'id': row['id'], 'at': row['recorded_at']})
            else:
                result['unknown'].add(row['problem_id'])
    if 'problem_hint_progress' in tables:
        for row in con.execute('SELECT problem_id,highest_hint_level FROM problem_hint_progress WHERE user_id=? AND hint_seen=1', (user_id,)):
            expected_levels[row['problem_id']] = row['highest_hint_level']
            if not result['hints'].get(row['problem_id']):
                # updated_at is the last progress update, not first exposure.
                result['unknown'].add(row['problem_id'])
    # A later stage must not erase an older progress-only exposure whose time
    # is unknown. Require the entire recorded stage prefix, including stage 1.
    for pid, levels in observed_levels.items():
        highest = max(expected_levels.get(pid, 0), max(levels))
        if pid not in first_stage_recorded or levels != set(range(1, highest + 1)):
            result['unknown'].add(pid)
    if 'lab_problem_knowledge' in tables:
        links = defaultdict(list)
        mapped_problems = {r[0] for r in con.execute('SELECT DISTINCT problem_id FROM lab_problem_knowledge')}
        for row in con.execute("""SELECT l.problem_id,l.anchor,l.status,l.evidence,k.heading FROM lab_problem_knowledge l
            JOIN knowledge_sections k ON k.anchor=l.anchor
            WHERE l.role='essential' ORDER BY l.anchor"""):
            links[row['problem_id']].append((row['anchor'], row['heading'], row['status'], row['evidence']))
        for pid, values in links.items():
            # Reject the whole signature if any essential link is broad. Do not
            # drop a broad prerequisite and accidentally make unlike tasks equal.
            if all(a.startswith('sec-') and a not in BROAD_ANCHORS
                   and status in {'verified', 'user_reviewed'} and evidence.strip()
                   for a, _, status, evidence in values):
                result['techniques'][pid] = {'signature': tuple(a for a, _, _, _ in values),
                                            'label': ' / '.join(h for _, h, _, _ in values)}
        for pid, (signature, label, source) in REVIEWED_HINT_TECHNIQUES.items():
            # Any explicit mapping, even supporting/candidate, takes precedence.
            if pid not in mapped_problems:
                result['techniques'][pid] = {'signature': signature, 'label': label, 'source': source}
    return result


def near_difficulty(a: dict, b: dict) -> bool:
    x, y = a.get('difficulty'), b.get('difficulty')
    if (not isinstance(x, int) or not isinstance(y, int) or x < 0 or y < 0
            or a.get('is_experimental') or b.get('is_experimental')):
        return False
    # UI red is 2800+, not an unbounded sequence of further colour bands.
    return min(x // 400, 7) == min(y // 400, 7) and abs(x - y) <= NEAR_DIFFICULTY_GAP


def project_reviews(rows: list[dict], submissions: dict[str, list[dict]], context: dict) -> None:
    """Attach deterministic evidence/status/recommendation fields in place."""
    hints, unknown, techniques = context['hints'], context['unknown'], context['techniques']
    first_acs = {}
    acs = {}
    for pid, items in submissions.items():
        values = sorted((s for s in items if s['result'] == 'AC' and _valid_epoch(s['epoch_second'])),
                        key=lambda s: (s['epoch_second'], s['submission_id']))
        if values:
            acs[pid], first_acs[pid] = values, values[0]
    by_id = {p['problem_id']: p for p in rows}
    for p in rows:
        p['transfer_review_reasons'] = []
        p['review_reasons'] = []
        has_hints = bool(hints.get(p['problem_id'])) or p['problem_id'] in unknown
        p['hint_review'] = {'status': 'none', 'note': ('ヒントの記録がありますが、現在のAC時刻までの使用とは判定していません。' if p['is_ac'] and has_hints else 'ヒントの記録があります。AC前後の判定はAC同期後に行います。' if has_hints else ''), 'recommendations': [], 'has_hint_records': has_hints}
        if p['is_ac'] and p['wa_count'] >= 2:
            p['review_reasons'].append(f"ACまでにWA {p['wa_count']}回")
        if (p['is_ac'] and p.get('solve_time_seconds') and p.get('solve_average_minutes')
                and p['solve_time_seconds'] > p['solve_average_minutes'] * 60 * 1.25):
            p['review_reasons'].append('実測Solve Timeが推定の1.25倍超')

    for pid, p in by_id.items():
        review = p['hint_review']
        if not p['is_ac']:
            continue
        if pid in unknown:
            review.update(status='timing_unknown', note='過去のヒント記録はありますが、AC前後の時刻を確定できません。ヒントなしACとは判定していません。',
                          unavailable_reason='ヒント閲覧時刻が不明のため、同技法の再確認は自動判定できません。')
            p['review_reasons'].append('ヒント記録の時刻不明・確認待ち')
            continue
        signature = techniques.get(pid)
        matches = [other for oid, other in by_id.items() if oid != pid and signature
                   and techniques.get(oid, {}).get('signature') == signature['signature']
                   and near_difficulty(p, other)]
        evidence_candidates = []
        for other in matches:
            oid = other['problem_id']
            accepted = first_acs.get(oid)
            if accepted and oid not in unknown and not any(h['at'] <= accepted['epoch_second'] for h in hints.get(oid, [])):
                evidence_candidates.append({'problem_id': oid, 'submission_id': accepted['submission_id'],
                                            'epoch_second': accepted['epoch_second']})
        evidence_candidates.sort(key=lambda e: (e['epoch_second'], e['submission_id'], e['problem_id']))
        resolved_at = 0
        # Multiple stage exposures before the same acceptance/check are one
        # episode. Old hints cannot reopen a fulfilled check on repeated ACs.
        for hint in hints.get(pid, []):
            if hint['at'] <= resolved_at:
                continue
            accepted = next((a for a in acs.get(pid, []) if a['epoch_second'] >= hint['at']), None)
            if not accepted:
                continue  # A hint after the last AC does not relabel that AC.
            source = {'submission_id': accepted['submission_id'], 'epoch_second': accepted['epoch_second']}
            evidence = next((e for e in evidence_candidates if e['epoch_second'] > accepted['epoch_second']), None)
            review.update(status='fulfilled' if evidence else 'pending', source_ac=source,
                          note=EVIDENCE_NOTE if evidence else 'AC時刻までにアプリ内ヒントの記録があります。同技法・近い難易度の別問題で再確認します。',
                          difficulty_rule=DIFFICULTY_RULE)
            if signature:
                review['technique'] = signature['label']
            if evidence:
                review['evidence'] = evidence
                resolved_at = evidence['epoch_second']
            else:
                review.pop('evidence', None)
                break
        if review['status'] != 'pending':
            continue
        p['review_reasons'].append('ヒント記録のあるAC・別問題で再確認待ち')
        candidates = [other for other in matches if not other['is_ac']
                      and other['problem_id'] not in unknown and not hints.get(other['problem_id'])]
        candidates.sort(key=lambda other: (abs(other['difficulty'] - p['difficulty']), other['problem_id']))
        if not signature:
            unavailable = '確認済みの必須技法が未登録です。推測タグだけで別問題を推薦しません。'
        elif p.get('difficulty') is None:
            unavailable = '元問題のDifficultyが不明です。A〜Gを難易度の代わりには使いません。'
        elif p.get('is_experimental'):
            unavailable = '元問題のDifficultyは実験値のため、近い難易度の自動判定を保留します。'
        else:
            unavailable = '同じ確認済み必須技法・同色帯・Difficulty差200以内で、未ACかつアプリ内ヒント未記録の別問題がありません。'
        review['recommendations'] = [{'problem_id': x['problem_id'], 'title': x['title'],
                                      'difficulty': x['difficulty'], 'technique': signature['label']} for x in candidates[:3]]
        if not candidates:
            review['unavailable_reason'] = unavailable
        for other in candidates[:3]:
            other['transfer_review_reasons'].append(f"{pid}: ヒント使用後の再確認・確認済み必須技法「{signature['label']}」・同色帯/差{abs(other['difficulty'] - p['difficulty'])}")
    for p in rows:
        p['review_candidate'] = bool(p['review_reasons'])
