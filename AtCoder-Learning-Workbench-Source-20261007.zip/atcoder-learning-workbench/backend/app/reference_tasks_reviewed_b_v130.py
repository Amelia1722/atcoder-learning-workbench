"""ABC248–250 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc248_b', 'abc249_b', 'abc250_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LETTERS = re.compile(r'[A-Za-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc248_b': [
        {'input': '1 4 2\n', 'expected': '2\n'},
        {'input': '7 7 10\n', 'expected': '0\n'},
        {'input': '31 415926 5\n', 'expected': '6\n'},
    ],
    'abc249_b': [
        {'input': 'AtCoder\n', 'expected': 'Yes\n'},
        {'input': 'Aa\n', 'expected': 'Yes\n'},
        {'input': 'atcoder\n', 'expected': 'No\n'},
        {'input': 'Perfect\n', 'expected': 'No\n'},
    ],
    'abc250_b': [
        {
            'input': '4 3 2\n',
            'expected': '..##..##\n..##..##\n..##..##\n##..##..\n##..##..\n##..##..\n..##..##\n..##..##\n..##..##\n##..##..\n##..##..\n##..##..\n',
        },
        {
            'input': '5 1 5\n',
            'expected': '.....#####.....#####.....\n#####.....#####.....#####\n.....#####.....#####.....\n#####.....#####.....#####\n.....#####.....#####.....\n',
        },
        {
            'input': '4 4 1\n',
            'expected': '.#.#\n.#.#\n.#.#\n.#.#\n#.#.\n#.#.\n#.#.\n#.#.\n.#.#\n.#.#\n.#.#\n.#.#\n#.#.\n#.#.\n#.#.\n#.#.\n',
        },
        {
            'input': '1 4 4\n',
            'expected': '....\n....\n....\n....\n',
        },
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate248(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    a, b, k = _ints(lines[0], 3)
    if not (1 <= a <= b <= 10**9 and 2 <= k <= 10**9):
        raise ValueError('constraints')
    return a, b, k


def _validate249(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1 or LETTERS.fullmatch(lines[0]) is None or not 1 <= len(lines[0]) <= 100:
        raise ValueError('S')
    return lines[0]


def _validate250(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    n, a, b = _ints(lines[0], 3)
    if not (1 <= n <= 10 and 1 <= a <= 10 and 1 <= b <= 10):
        raise ValueError('constraints')
    return n, a, b


def validate(pid: str, raw: str):
    if pid == 'abc248_b':
        return _validate248(raw)
    if pid == 'abc249_b':
        return _validate249(raw)
    if pid == 'abc250_b':
        return _validate250(raw)
    raise ValueError('unknown task')


def _expected248(a: int, b: int, k: int) -> int:
    lo, hi = 0, 64
    while lo < hi:
        mid = (lo + hi) // 2
        if a * pow(k, mid) >= b:
            hi = mid
        else:
            lo = mid + 1
    return lo


def _expected249(s: str) -> str:
    upper = False
    lower = False
    seen = [False] * 128
    unique = True
    for ch in s:
        code = ord(ch)
        if seen[code]:
            unique = False
        seen[code] = True
        if 'A' <= ch <= 'Z':
            upper = True
        if 'a' <= ch <= 'z':
            lower = True
    return 'Yes' if upper and lower and unique else 'No'


def _expected250(n: int, a: int, b: int) -> str:
    rows: list[str] = []
    for tile_i in range(n):
        row = ''.join(('.' if (tile_i + tile_j) % 2 == 0 else '#') * b for tile_j in range(n))
        rows.extend([row] * a)
    return '\n'.join(rows)


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc248_b':
        expected = _expected248(*value)
        return NONNEG.fullmatch(output) is not None and int(output) == expected
    if pid == 'abc249_b':
        return output == _expected249(value)
    n, a, b = value
    return output == _expected250(n, a, b)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc248_b':
        cases = [
            ('equal_one', '1 1 2\n'),
            ('equal_large', '999999999 999999999 2\n'),
            ('one_step_exact', '5 25 5\n'),
            ('one_step_over', '400000000 1000000000 3\n'),
            ('two_steps_exact', '3 27 3\n'),
            ('two_steps_over', '3 20 3\n'),
            ('k2_long', '1 1000000000 2\n'),
            ('power3_exact', '1 59049 3\n'),
            ('power3_plus_one', '1 59050 3\n'),
            ('nonunit_long', '12345 987654321 2\n'),
            ('k10_steps', '9 900000000 10\n'),
            ('huge_k_two_steps', '1 999999999 999999998\n'),
            ('large_a_one_step', '999999999 1000000000 2\n'),
            ('mid_scale', '100 1000000000 10\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '1000000000 1000000000 1000000000\n')

    elif pid == 'abc249_b':
        cases = [
            ('single_upper', 'A\n'),
            ('single_lower', 'a\n'),
            ('all_upper', 'ABCXYZ\n'),
            ('all_lower', 'abcxyz\n'),
            ('two_valid_reverse', 'aA\n'),
            ('duplicate_upper', 'AaA\n'),
            ('duplicate_lower', 'Aaa\n'),
            ('distinct_mixed', 'AbCdEf\n'),
            ('repeat_distant', 'aBCDa\n'),
            ('case_pairs_unique', 'aAbB\n'),
            ('all52_unique', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz\n'),
            ('long_duplicate_53', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzA\n'),
            ('long_mixed_unique', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabc\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', ('A' * 50 + 'a' * 50) + '\n')

    else:
        cases = [
            ('unit', '1 1 1\n'),
            ('n2_unit', '2 1 1\n'),
            ('n3_unit', '3 1 1\n'),
            ('n2_square_tiles', '2 2 2\n'),
            ('vertical_tiles', '3 2 1\n'),
            ('horizontal_tiles', '3 1 2\n'),
            ('n10_unit', '10 1 1\n'),
            ('single_row_wide', '1 1 10\n'),
            ('single_col_tall', '1 10 1\n'),
            ('n2_large_tiles', '2 10 10\n'),
            ('n10_wide', '10 1 10\n'),
            ('n10_tall', '10 10 1\n'),
            ('mixed_7_3_4', '7 3 4\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '10 10 10\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
