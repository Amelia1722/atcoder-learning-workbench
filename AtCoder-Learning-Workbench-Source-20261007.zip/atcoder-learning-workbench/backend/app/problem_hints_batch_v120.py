"""Statement-checked three-stage hints for ABC218–220 B."""
HINTS_V120 = {
    'abc218_b': (
        '各整数 `P_i` はアルファベット順で何番目の文字かを表しています。1ならa、2ならb、…、26ならzです。',
        '`P_i` を0始まりへ直すと `P_i - 1` です。Pythonでは `chr(ord("a") + P_i - 1)` のように文字へ変換できます。',
        '''疑似コード:
answer = empty string
for p in P:
  answer += alphabet[p - 1]
print(answer)''',
    ),
    'abc219_b': (
        '`T` の各文字は、3つの文字列のうちどれを次に付けるかを表しています。',
        '`T` を左から見て、1ならS1、2ならS2、3ならS3を答えへ追加します。最後にまとめて連結すると効率的です。',
        '''疑似コード:
parts = [S1, S2, S3]
answer = empty list
for c in T:
  append parts[int(c) - 1] to answer
print(concatenate(answer))''',
    ),
    'abc220_b': (
        'まずAとBをK進法から10進法の整数へ直し、その2つを掛けます。',
        '左から数字dを読むたびに `value = value * K + d` とすれば、K進表記を10進整数へ変換できます。',
        '''疑似コード:
convert(s):
  value = 0
  for digit in s:
    value = value * K + int(digit)
  return value
a = convert(A)
b = convert(B)
print(a * b)''',
    ),
}
