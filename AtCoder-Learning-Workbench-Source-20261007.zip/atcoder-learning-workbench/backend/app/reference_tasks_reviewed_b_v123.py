"""ABC227–229 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import math
import re

TASKS = ('abc227_b', 'abc228_b', 'abc229_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc227_b': [
        {'input': '3\n10 20 39\n', 'expected': '1\n'},
        {'input': '5\n666 777 888 777 666\n', 'expected': '3\n'},
    ],
    'abc228_b': [
        {'input': '4 2\n3 1 1 2\n', 'expected': '3\n'},
        {'input': '20 12\n7 11 10 1 7 20 14 2 17 3 2 5 19 20 8 14 18 2 10 10\n', 'expected': '7\n'},
    ],
    'abc229_b': [
        {'input': '229 390\n', 'expected': 'Hard\n'},
        {'input': '123456789 9876543210\n', 'expected': 'Easy\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _tokens(line: str) -> list[str]:
    if not line or line.startswith(' ') or line.endswith(' ') or '  ' in line:
        raise ValueError('spacing')
    return line.split(' ')


def _validate227(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N syntax')
    n = int(lines[0])
    vals = _tokens(lines[1])
    if not 1 <= n <= 20 or len(vals) != n or any(POS.fullmatch(x) is None for x in vals):
        raise ValueError('N/list syntax or shape')
    s = tuple(map(int, vals))
    if any(x > 1000 for x in s):
        raise ValueError('S range')
    return n, s


def _validate228(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    head = _tokens(lines[0])
    if len(head) != 2 or any(POS.fullmatch(x) is None for x in head):
        raise ValueError('N/X syntax')
    n, x = map(int, head)
    vals = _tokens(lines[1])
    if not 2 <= n <= 100000 or not 1 <= x <= n or len(vals) != n:
        raise ValueError('N/X/list shape')
    if any(POS.fullmatch(v) is None for v in vals):
        raise ValueError('A syntax')
    a = tuple(map(int, vals))
    if any(not 1 <= v <= n for v in a):
        raise ValueError('A range')
    if any(v == i + 1 for i, v in enumerate(a)):
        raise ValueError('self loop forbidden')
    return n, x, a


def _validate229(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    vals = _tokens(lines[0])
    if len(vals) != 2 or any(POS.fullmatch(x) is None for x in vals):
        raise ValueError('A/B syntax')
    a, b = map(int, vals)
    if a > 10**18 or b > 10**18:
        raise ValueError('A/B range')
    return a, b


def validate(pid: str, raw: str):
    if pid == 'abc227_b':
        return _validate227(raw)
    if pid == 'abc228_b':
        return _validate228(raw)
    if pid == 'abc229_b':
        return _validate229(raw)
    raise ValueError('unknown task')


def _representable_227_by_factorization(s: int) -> bool:
    # (4a+3)(4b+3) = 4s+9, with a,b positive, so each factor is >=7 and 3 mod 4.
    target = 4 * s + 9
    for d in range(1, math.isqrt(target) + 1):
        if target % d:
            continue
        e = target // d
        if d >= 7 and e >= 7 and d % 4 == 3 and e % 4 == 3:
            return True
    return False


def _reachable_count_floyd(n: int, x: int, a: tuple[int, ...]) -> int:
    def nxt(v: int) -> int:
        return a[v - 1]

    tortoise = nxt(x)
    hare = nxt(nxt(x))
    while tortoise != hare:
        tortoise = nxt(tortoise)
        hare = nxt(nxt(hare))

    mu = 0
    tortoise = x
    while tortoise != hare:
        tortoise = nxt(tortoise)
        hare = nxt(hare)
        mu += 1

    lam = 1
    hare = nxt(tortoise)
    while tortoise != hare:
        hare = nxt(hare)
        lam += 1
    return mu + lam


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc227_b':
        if re.fullmatch(r'(?:0|[1-9][0-9]*)', output, re.ASCII) is None:
            return False
        _, s = value
        return int(output) == sum(not _representable_227_by_factorization(v) for v in s)
    if pid == 'abc228_b':
        if re.fullmatch(r'[1-9][0-9]*', output, re.ASCII) is None:
            return False
        n, x, a = value
        return int(output) == _reachable_count_floyd(n, x, a)
    if pid == 'abc229_b':
        if output not in {'Easy', 'Hard'}:
            return False
        a, b = value
        sa, sb = str(a)[::-1], str(b)[::-1]
        carry = any(int(x) + int(y) >= 10 for x, y in zip(sa.ljust(max(len(sa), len(sb)), '0'), sb.ljust(max(len(sa), len(sb)), '0')))
        return (output == 'Hard') == carry
    return False


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc227_b':
        cases = [
            ('single_below_min', '1\n1\n'),
            ('single_min_valid', '1\n10\n'),
            ('single_other_valid', '1\n21\n'),
            ('single_invalid_20', '1\n20\n'),
            ('all_small_invalid', '9\n1 2 3 4 5 6 7 8 9\n'),
            ('mixed_low', '8\n10 11 21 22 36 39 40 55\n'),
            ('duplicates_valid', '6\n10 10 10 39 39 39\n'),
            ('duplicates_invalid', '6\n20 20 20 100 100 100\n'),
            ('near_1000', '6\n995 996 997 998 999 1000\n'),
            ('n20_same_min', '20\n' + ' '.join(['10'] * 20) + '\n'),
            ('n20_same_invalid', '20\n' + ' '.join(['1'] * 20) + '\n'),
            ('assorted_valids', '8\n10 21 36 55 78 105 136 171\n'),
            ('assorted_mixed', '10\n10 12 21 25 39 50 77 100 500 999\n'),
            ('boundary_one_and_max', '2\n1 1000\n'),
            ('n20_alternating', '20\n10 20 21 22 36 37 39 40 55 56 78 79 105 106 136 137 171 172 210 211\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '20\n' + ' '.join(str(981 + i) for i in range(20)) + '\n')
    elif pid == 'abc228_b':
        cases = [
            ('n2_cycle_x1', '2 1\n2 1\n'),
            ('n2_cycle_x2', '2 2\n2 1\n'),
            ('n3_cycle_all', '3 1\n2 3 1\n'),
            ('n3_tail_cycle', '3 1\n2 3 2\n'),
            ('n4_two_cycles_x1', '4 1\n2 1 4 3\n'),
            ('n4_two_cycles_x3', '4 3\n2 1 4 3\n'),
            ('n5_long_tail', '5 1\n2 3 4 5 4\n'),
            ('n5_start_in_cycle', '5 4\n2 3 4 5 4\n'),
            ('n6_branch_irrelevant', '6 1\n2 3 1 3 4 5\n'),
            ('n7_cycle_three', '7 5\n2 3 1 5 6 7 5\n'),
            ('n8_chain_to_two_cycle', '8 1\n2 3 4 5 6 7 8 7\n'),
            ('n10_start_middle', '10 6\n2 3 4 5 1 7 8 9 10 9\n'),
            ('n10_cycle_all', '10 10\n2 3 4 5 6 7 8 9 10 1\n'),
            ('n20_short_cycle', '20 20\n2 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19\n'),
            ('n30_tail_to_cycle', '30 1\n' + ' '.join([str(i + 2) for i in range(28)] + ['30', '29']) + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        n = 100000
        arr = [str(i + 2) for i in range(n - 1)] + ['1']
        add('constraint_max', f'{n} 1\n' + ' '.join(arr) + '\n')
    else:
        cases = [
            ('single_digit_easy', '1 1\n'),
            ('single_digit_hard', '9 1\n'),
            ('ones_easy', '111 222\n'),
            ('ones_hard', '555 555\n'),
            ('different_lengths_easy', '1 999999999999999999\n'),
            ('different_lengths_hard', '9 100000000000000001\n'),
            ('carry_units_only', '100000000000000009 1\n'),
            ('carry_middle_only', '100000000500000000 500000000\n'),
            ('all_nines_hard', '999999999999999999 999999999999999999\n'),
            ('near_max_easy', '1000000000000000000 888888888888888888\n'),
            ('near_max_hard', '999999999999999999 1\n'),
            ('powers_easy', '1000000000 1000000000\n'),
            ('zero_digits_easy', '101010101010101010 202020202020202020\n'),
            ('alternating_hard', '191919191919191919 818181818181818181\n'),
            ('leading_length_gap', '99999999999999999 1000000000000000000\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '1000000000000000000 1000000000000000000\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
