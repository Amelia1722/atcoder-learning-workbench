"""Private ABC138--143 D contracts and independent solvers."""
from __future__ import annotations
from collections import Counter,deque
from math import gcd,isqrt,comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(138,144))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc138_d':
  n,q=ints(r[0],2);require(2<=n<=200000 and 1<=q<=200000 and len(r)==n+q,'shape');edges=tuple(ints(s,2) for s in r[1:n]);queries=tuple(ints(s,2) for s in r[n:]);require(all(1<=u<v<=n for u,v in edges) and all(1<=p<=n and 1<=x<=10000 for p,x in queries),'bounds');adj:list[list[int]]=[[] for _ in range(n)]
  for u,v in edges:adj[u-1].append(v-1);adj[v-1].append(u-1)
  seen={0};stack=[0]
  while stack:
   for v in adj[stack.pop()]:
    if v not in seen:seen.add(v);stack.append(v)
  require(len(seen)==n,'tree');return n,edges,queries
 if pid=='abc139_d':
  require(len(r)==1,'shape');n=ints(r[0],1)[0];require(1<=n<=10**9,'N');return (n,)
 if pid=='abc140_d':
  n,k=ints(r[0],2);require(1<=n<=100000 and 1<=k<=100000 and len(r)==2 and len(r[1])==n and set(r[1])<={'L','R'},'directions');return r[1],k
 if pid=='abc141_d':
  n,m=ints(r[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=v<=10**9 for v in a),'prices');return a,m
 if pid=='abc142_d':
  require(len(r)==1,'shape');a,b=ints(r[0],2);require(1<=min(a,b) and max(a,b)<=10**12,'bounds');return a,b
 n=ints(r[0],1)[0];require(3<=n<=2000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=v<=1000 for v in a),'lengths');return (a,)
def subtree_intervals(n:int,edges:tuple[tuple[int,int],...],queries:tuple[tuple[int,int],...])->list[int]:
 adj:list[list[int]]=[[] for _ in range(n)]
 for u,v in edges:adj[u-1].append(v-1);adj[v-1].append(u-1)
 entry=[0]*n;end=[0]*n;order=[];stack=[(0,-1,False)]
 while stack:
  u,parent,leave=stack.pop()
  if leave:end[u]=len(order);continue
  entry[u]=len(order);order.append(u);stack.append((u,parent,True))
  for v in adj[u]:
   if v!=parent:stack.append((v,u,False))
 diff=[0]*(n+1)
 for p,x in queries:diff[entry[p-1]]+=x;diff[end[p-1]]-=x
 answer=[0]*n;value=0
 for i,u in enumerate(order):value+=diff[i];answer[u]=value
 return answer
def remainder_assignment(n:int)->int:
 if n<=12:
  dp=[-1]*(1<<n);dp[0]=0
  for mask,v in enumerate(dp):
   if v<0:continue
   i=mask.bit_count()+1
   for j in range(n):
    if mask>>j&1==0:target=mask|(1<<j);dp[target]=max(dp[target],v+i%(j+1))
  return dp[-1]
 def cycle_sum(t:int)->int:
  if t<=1:return 0
  m,r=divmod(t,2);return 2*cycle_sum(m)+m*m+2*m*r
 return cycle_sum(n)
def rotate_runs(s:str,k:int)->int:
 runs:deque[int]=deque();last=''
 for c in s:
  if c==last:runs[-1]+=1
  else:runs.append(1);last=c
 while k and len(runs)>=3:
  a,b,c=runs.popleft(),runs.popleft(),runs.popleft();runs.appendleft(a+b+c);k-=1
 if k and len(runs)==2:runs=deque([sum(runs)])
 return sum(v-1 for v in runs)
def discount_threshold(a:tuple[int,...],m:int)->int:
 if sum(v.bit_length() for v in a)<=m:return 0
 lo,hi=1,(max(a)+1)//2
 while lo<hi:
  mid=(lo+hi+1)//2;count=sum((v//(2*mid-1)).bit_length() for v in a)
  if count>=m:lo=mid
  else:hi=mid-1
 threshold=lo;used=0;reduction=0
 for v in a:
  count=(v//(2*threshold+1)).bit_length();used+=count;reduction+=v-(v>>count)
 return sum(a)-reduction-(m-used)*threshold
def common_divisor_selection(a:int,b:int)->int:
 g=gcd(a,b);divisors=[]
 for d in range(1,isqrt(g)+1):
  if g%d==0:
   divisors.append(d)
   if d*d!=g:divisors.append(g//d)
 used=1;count=0
 for d in sorted(divisors):
  if gcd(used,d)==1:used*=d;count+=1
 return count
def triangle_histogram(a:tuple[int,...])->int:
 counts=Counter(a);values=sorted(counts);prefix=[0]*1001
 for v in range(1,1001):prefix[v]=prefix[v-1]+counts[v]
 answer=0
 for i,x in enumerate(values):
  cx=counts[x]
  for y in values[i:]:
   cy=counts[y];pair=comb(cx,2) if x==y else cx*cy;answer+=pair*(prefix[min(1000,x+y-1)]-prefix[y])
   answer+=comb(cx,3) if x==y else cx*comb(cy,2)
 return answer
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc138_d':return line(subtree_intervals(*cast(tuple[int,tuple[tuple[int,int],...],tuple[tuple[int,int],...]],d)))
 if pid=='abc139_d':v=remainder_assignment(cast(int,d[0]))
 elif pid=='abc140_d':v=rotate_runs(*cast(tuple[str,int],d))
 elif pid=='abc141_d':v=discount_threshold(*cast(tuple[tuple[int,...],int],d))
 elif pid=='abc142_d':v=common_divisor_selection(*cast(tuple[int,int],d))
 else:v=triangle_histogram(cast(tuple[int,...],d[0]))
 return f'{v}\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  expected=oracle(pid,raw).split();rows=actual.removesuffix('\n').split(' ');return len(rows)==len(expected) and all(re.fullmatch(r'[0-9]+',s) and int(s)==int(t) for s,t in zip(rows,expected))
 except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc138_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);q=next(it);g=[[] for _ in range(n)]
for _ in range(n-1):u=next(it)-1;v=next(it)-1;g[u].append(v);g[v].append(u)
a=[0]*n
for _ in range(q):p=next(it)-1;a[p]+=next(it)
stack=[(0,-1)]
while stack:
 u,p=stack.pop()
 for v in g[u]:
  if v!=p:a[v]+=a[u];stack.append((v,u))
print(*a)
''',
'abc139_d':'''n=int(input());print(n*(n-1)//2)
''',
'abc140_d':'''n,k=map(int,input().split());s=input();h=sum(a==b for a,b in zip(s,s[1:]));print(min(n-1,h+2*k))
''',
'abc141_d':'''import heapq
n,m=map(int,input().split());h=[-v for v in map(int,input().split())];heapq.heapify(h)
for _ in range(m):v=-heapq.heappop(h);heapq.heappush(h,-(v//2))
print(-sum(h))
''',
'abc142_d':'''from math import gcd
a,b=map(int,input().split());g=gcd(a,b);p=2;ans=1
while p*p<=g:
 if g%p==0:
  ans+=1
  while g%p==0:g//=p
 p+=1
if g>1:ans+=1
print(ans)
''',
'abc143_d':'''n=int(input());a=sorted(map(int,input().split()));answer=0
for k in range(2,n):
 i,j=0,k-1
 while i<j:
  if a[i]+a[j]>a[k]:answer+=j-i;j-=1
  else:i+=1
print(answer)
'''}
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(18600+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc138_d':
  def tree(n:int,e:list[tuple[int,int]],q:list[tuple[int,int]])->str:return f'{n} {len(q)}\n'+''.join(line(v) for v in e+q)
  raws=[tree(2,[(1,2)],[(1,1)]),tree(2,[(1,2)],[(2,10000)]),tree(4,[(1,4),(2,4),(2,3)],[(2,9),(4,7),(1,2)])]
  for n in range(3,16):
   perm=list(range(2,n+1));rng.shuffle(perm);vertices=[1]+perm;e=[tuple(sorted((vertices[rng.randrange(j)],vertices[j]))) for j in range(1,n)];rng.shuffle(e);raws.append(tree(n,e,[(rng.randint(1,n),rng.randint(1,10000)) for _ in range(n+1)]))
  raws+=[tree(200000,[(i,i+1) for i in range(1,200000)],[(i,10000) for i in range(1,200001)]),tree(200000,[(1,i) for i in range(2,200001)],[(1,10000)]*200000)]
 elif pid=='abc139_d':raws=[f'{n}\n' for n in (1,2,3,4,5,6,7,8,9,10,11,12,13,999,100000,536870912,999999999,10**9)]
 elif pid=='abc140_d':
  pairs=[('L',1),('R',1),('LR',1),('RL',1),('LL',1),('RR',1),('LRLRRL',1),('LRRLRLRRLRLLR',3),('LLLLLRRRRR',1),('RRRLRLRLL',2),('LRLRLRLR',1),('RLRLRLRL',2),('LLLRRRLLL',1),('LR'*50,49),('R'*100,100000),('LR'*50000,1),('RL'*50000,49999),('R'*100000,100000)];raws=[f'{len(s)} {k}\n{s}\n' for s,k in pairs]
 elif pid=='abc141_d':
  def prices(a:list[int],m:int)->str:return f'{len(a)} {m}\n'+line(a)
  raws=[prices([1],1),prices([10**9],100000),prices([1,1],1),prices([2,13,8],3),prices([1,9,3,5],4)]
  for n in range(2,13):raws.append(prices([rng.randint(1,10**9) for _ in range(n)],rng.randint(1,100000)))
  raws+=[prices(list(range(1,100001)),100000),prices([10**9]*100000,100000)]
 elif pid=='abc142_d':raws=[f'{a} {b}\n' for a,b in ((1,1),(1,2019),(12,18),(420,660),(2,2),(4,8),(8,27),(6,6),(30,30),(210,210),(30030,30030),(223092870,223092870),(6469693230,6469693230),(999999999989,999999999989),(999983**2,999983**2),(999999999999,10**12),(999999999999,999999999999),(10**12,10**12))]
 else:
  def sticks(a:list[int])->str:return f'{len(a)}\n'+line(a)
  arrays=[[1,1,1],[1,1,2],[1,1000,1],[3,4,2,1],[218,786,704,233,645,728,389],[2,2,3],[1,2,3,4],[999,1000,1000]]
  for n in range(5,13):arrays.append([rng.randint(1,1000) for _ in range(n)])
  arrays+=[list(range(1,1001))*2,[1000]*2000];raws=[sticks(a) for a in arrays]
 require(len(raws)==len(set(raws))==18,'distinct18')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc138_d':('部分木への加算を、その根に一度だけ記録できます。','各操作の値を頂点pへ加算し、根から子へ累積値を渡せば、全祖先の操作が反映されます。','疑似コード: add[p]+=xを全Q操作; 根1からDFS; 子vへadd[v]+=add[parent]; 頂点順にaddを出力。'),
'abc139_d':('iをP_iで割った余りは、必ずP_i-1以下です。','上界は0+1+…+(N-1)です。Pを2,3,…,N,1にすれば余りが1,2,…,N-1,0となり、上界を達成できます。','疑似コード: Nを読む; N*(N-1)/2を整数で計算して出力。'),
'abc140_d':('幸福人数は、隣接する同じ向きの組の個数と一致します。','区間を逆順にして向きも反転すると、内部の等しい組数は変わらず、境界二つで最大2増えます。違う向きの塊をまとめればこの上界を達成できます。','疑似コード: happy=隣接S[i]==S[i+1]の個数; min(N-1,happy+2*K)を出力。'),
'abc141_d':('一枚の割引券で減らせる金額が最大の品物を選びます。','現在価格が最大の品物を半額にする操作をM回繰り返します。最大ヒープなら各回をlogNで行えます。','疑似コード: 全価格の負値をheapify; M回、最大価格vをpopしfloor(v/2)をpush; 最後の価格総和を出力。'),
'abc142_d':('選んだ1以外の公約数どうしは、素因数を共有できません。','gcd(A,B)の異なる素因数を一つずつ選び、さらに1を選ぶのが最大です。','疑似コード: g=gcd(A,B),answer=1; 試し割りでgの各異なる素因数を一度数え、全指数を除去; 残りg>1なら加算; answerを出力。'),
'abc143_d':('長さを昇順にすると、小さい二辺の和が最大辺を超えるかだけ確認します。','最大辺の位置を固定します。左右ポインタの和が最大辺を超えれば、左から右未満まで全て有効です。','疑似コード: Lをsort; 各kについてi=0,j=k-1; 和>L[k]ならanswer+=j-i,j--; 他ならi++; answerを出力。')}

TITLES={'abc138_d': 'Ki', 'abc139_d': 'ModSum', 'abc140_d': 'Face Produces Unhappiness', 'abc141_d': 'Powerful Discount Tickets', 'abc142_d': 'Disjoint Set of Common Divisors', 'abc143_d': 'Triangles'}
PUBLISHED_SAMPLES={'abc138_d': [{'input': '4 3\n1 2\n2 3\n2 4\n2 10\n1 100\n3 1\n', 'expected': '100 110 111 110\n'}, {'input': '6 2\n1 2\n1 3\n2 4\n3 6\n2 5\n1 10\n1 10\n', 'expected': '20 20 20 20 20 20\n'}], 'abc139_d': [{'input': '2\n', 'expected': '1\n'}, {'input': '13\n', 'expected': '78\n'}, {'input': '1\n', 'expected': '0\n'}], 'abc140_d': [{'input': '6 1\nLRLRRL\n', 'expected': '3\n'}, {'input': '13 3\nLRRLRLRRLRLLR\n', 'expected': '9\n'}, {'input': '10 1\nLLLLLRRRRR\n', 'expected': '9\n'}, {'input': '9 2\nRRRLRLRLL\n', 'expected': '7\n'}], 'abc141_d': [{'input': '3 3\n2 13 8\n', 'expected': '9\n'}, {'input': '4 4\n1 9 3 5\n', 'expected': '6\n'}, {'input': '1 100000\n1000000000\n', 'expected': '0\n'}, {'input': '10 1\n1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '9500000000\n'}], 'abc142_d': [{'input': '12 18\n', 'expected': '3\n'}, {'input': '420 660\n', 'expected': '4\n'}, {'input': '1 2019\n', 'expected': '1\n'}], 'abc143_d': [{'input': '4\n3 4 2 1\n', 'expected': '1\n'}, {'input': '3\n1 1000 1\n', 'expected': '0\n'}, {'input': '7\n218 786 704 233 645 728 389\n', 'expected': '23\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
