"""Statement-checked three-stage hints for ABC245–247 B."""
HINTS_V129 = {
    'abc245_b': (
        '求めるのは、配列に一度も現れない最小の0以上の整数です。0から順に「存在するか」を確認すれば十分です。',
        'N≤2000なので、setに全要素を入れて0,1,2,...と順に調べる方法で間に合います。答えは高くてもNです。',
        '疑似コード:\npresent = set(A)\nanswer = 0\nwhile answer in present:\n  answer += 1\nprint(answer)',
    ),
    'abc246_b': (
        '(A,B)と同じ向きで長さ1のベクトルを作ればよいです。元のベクトルの長さで各成分を割ります。',
        '原点から(A,B)までの距離はsqrt(A^2+B^2)です。したがって答えは(A/d, B/d)です。浮動小数点で出力できます。',
        '疑似コード:\nread A, B\nd = sqrt(A*A + B*B)\nx = A / d\ny = B / d\nprint(x, y)',
    ),
    'abc247_b': (
        '各人について、姓か名の少なくとも一方が「他の誰の姓・名にも使われていない」必要があります。',
        '人iごとに候補s_i,t_iを調べ、i以外の全員のs_j,t_jと一致しない候補が1つでもあるか確認します。N≤100なので二重ループで十分です。',
        '疑似コード:\nfor i in 0..N-1:\n  can_use_s = true; can_use_t = true\n  for j in 0..N-1, j != i:\n    if s[i] == s[j] or s[i] == t[j]: can_use_s = false\n    if t[i] == s[j] or t[i] == t[j]: can_use_t = false\n  if not can_use_s and not can_use_t:\n    print(No); stop\nprint(Yes)',
    ),
}
