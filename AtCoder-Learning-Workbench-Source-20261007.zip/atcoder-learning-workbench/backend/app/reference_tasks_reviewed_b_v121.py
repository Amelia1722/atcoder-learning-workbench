"""ABC221–223 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc221_b', 'abc222_b', 'abc223_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER_2_100 = re.compile(r'[a-z]{2,100}', re.ASCII)
LOWER_1_1000 = re.compile(r'[a-z]{1,1000}', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc221_b': [
        {'input': 'abc\nacb\n', 'expected': 'Yes\n'},
        {'input': 'aabb\nbbaa\n', 'expected': 'No\n'},
        {'input': 'abcde\nabcde\n', 'expected': 'Yes\n'},
    ],
    'abc222_b': [
        {'input': '4 50\n80 60 40 0\n', 'expected': '2\n'},
        {'input': '3 90\n89 89 89\n', 'expected': '3\n'},
        {'input': '2 22\n6 37\n', 'expected': '1\n'},
    ],
    'abc223_b': [
        {'input': 'aaba\n', 'expected': 'aaab\nbaaa\n'},
        {'input': 'z\n', 'expected': 'z\nz\n'},
        {'input': 'abracadabra\n', 'expected': 'aabracadabr\nracadabraab\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _validate221(raw: str) -> tuple[str, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    s, t = lines
    if LOWER_2_100.fullmatch(s) is None or LOWER_2_100.fullmatch(t) is None:
        raise ValueError('string syntax/range')
    if len(s) != len(t):
        raise ValueError('length mismatch')
    return s, t


def _validate222(raw: str) -> tuple[int, int, tuple[int, ...]]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    head = lines[0].split(' ')
    vals = lines[1].split(' ')
    if len(head) != 2 or any(POS.fullmatch(x) is None for x in head):
        raise ValueError('N/P syntax')
    n, p = map(int, head)
    if not 1 <= n <= 100000 or not 1 <= p <= 100:
        raise ValueError('N/P range')
    if len(vals) != n or any(NONNEG.fullmatch(x) is None for x in vals):
        raise ValueError('scores shape/syntax')
    scores = tuple(map(int, vals))
    if any(x > 100 for x in scores):
        raise ValueError('score range')
    return n, p, scores


def _validate223(raw: str) -> str:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or LOWER_1_1000.fullmatch(lines[0]) is None:
        raise ValueError('string syntax/range')
    return lines[0]


def validate(pid: str, raw: str):
    if pid == 'abc221_b':
        return _validate221(raw)
    if pid == 'abc222_b':
        return _validate222(raw)
    if pid == 'abc223_b':
        return _validate223(raw)
    raise ValueError('unknown task')


def _possible_one_adjacent_swap(s: str, t: str) -> bool:
    mismatch = [i for i, (a, b) in enumerate(zip(s, t)) if a != b]
    if not mismatch:
        return True
    if len(mismatch) != 2 or mismatch[1] != mismatch[0] + 1:
        return False
    i, j = mismatch
    return s[i] == t[j] and s[j] == t[i]


def _rotation_extremes(s: str) -> tuple[str, str]:
    lo = hi = s
    cur = s
    for _ in range(1, len(s)):
        cur = cur[1:] + cur[0]
        if cur < lo:
            lo = cur
        if cur > hi:
            hi = cur
    return lo, hi


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc221_b':
        if output not in {'Yes', 'No'}:
            return False
        return (output == 'Yes') == _possible_one_adjacent_swap(*value)
    if pid == 'abc222_b':
        if NONNEG.fullmatch(output) is None:
            return False
        _, p, scores = value
        return int(output) == sum(score < p for score in scores)
    if pid == 'abc223_b':
        parts = output.split('\n')
        if len(parts) != 2 or any(LOWER_1_1000.fullmatch(x) is None for x in parts):
            return False
        s = value
        if any(len(x) != len(s) for x in parts):
            return False
        return tuple(parts) == _rotation_extremes(s)
    return False


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc221_b':
        cases = [
            ('len2_same', 'aa\naa\n'),
            ('len2_swap', 'ab\nba\n'),
            ('len2_impossible', 'ab\nac\n'),
            ('left_swap', 'bac\nabc\n'),
            ('middle_swap', 'aabb\nabab\n'),
            ('right_swap', 'abcde\nabced\n'),
            ('nonadjacent_swap', 'abcd\ndbca\n'),
            ('three_cycle', 'abc\nbca\n'),
            ('single_mismatch', 'abc\nabd\n'),
            ('same_repeated', 'aaaaaaaa\naaaaaaaa\n'),
            ('duplicate_swap', 'abccdd\nabcdcd\n'),
            ('anagram_but_far', 'aabbcc\nccbbaa\n'),
            ('long_same', ('ab' * 50) + '\n' + ('ab' * 50) + '\n'),
            ('long_middle_swap', ('a' * 49 + 'bc' + 'd' * 49) + '\n' + ('a' * 49 + 'cb' + 'd' * 49) + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        s = 'abcdefghijklmnopqrstuvwxyz' * 3 + 'abcdefghijklmnopqrstuv'
        t = s[:-2] + s[-1] + s[-2]
        add('constraint_max', s + '\n' + t + '\n')
    elif pid == 'abc222_b':
        cases = [
            ('n1_fail_min', '1 1\n0\n'),
            ('n1_pass_min', '1 1\n1\n'),
            ('n1_fail_maxp', '1 100\n99\n'),
            ('n1_pass_maxp', '1 100\n100\n'),
            ('threshold_mix', '5 50\n49 50 51 0 100\n'),
            ('all_fail', '10 100\n0 1 2 3 4 5 6 7 8 9\n'),
            ('none_fail', '6 1\n1 2 3 50 99 100\n'),
            ('equal_threshold', '5 42\n42 42 42 42 42\n'),
            ('one_fail', '6 42\n42 41 43 100 99 42\n'),
            ('zeros', '8 2\n0 0 0 0 2 2 2 2\n'),
            ('alternating', '12 51\n50 51 50 51 50 51 50 51 50 51 50 51\n'),
            ('p100_edges', '7 100\n0 1 98 99 100 100 50\n'),
            ('p1_edges', '7 1\n0 1 2 3 4 99 100\n'),
            ('n100', '100 50\n' + ' '.join(str(i % 101) for i in range(100)) + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        scores = ['99' if i % 2 == 0 else '100' for i in range(100000)]
        add('constraint_max', '100000 100\n' + ' '.join(scores) + '\n')
    else:
        cases = [
            ('single_a', 'a\n'),
            ('two_ab', 'ab\n'),
            ('two_ba', 'ba\n'),
            ('all_same', 'aaaa\n'),
            ('period2', 'abab\n'),
            ('period3', 'abcabc\n'),
            ('ascending', 'abcdef\n'),
            ('descending', 'fedcba\n'),
            ('palindrome', 'abccba\n'),
            ('banana', 'banana\n'),
            ('ends_extreme', 'zaaa\n'),
            ('all_z', 'zzzzzz\n'),
            ('alphabet', 'abcdefghijklmnopqrstuvwxyz\n'),
            ('reverse_alphabet', 'zyxwvutsrqponmlkjihgfedcba\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', ('abacaba' * 142 + 'abcdef') + '\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
