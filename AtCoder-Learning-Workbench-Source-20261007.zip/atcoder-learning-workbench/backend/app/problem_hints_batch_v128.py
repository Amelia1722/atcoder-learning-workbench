"""Statement-checked three-stage hints for ABC242–244 B."""
HINTS_V128 = {
    'abc242_b': (
        '文字を自由に並び替えて辞書順最小にするには、小さい文字から順に並べればよいです。',
        '英小文字だけなので、そのまま文字列を昇順ソートするか、26文字の出現回数を数えて復元できます。',
        '疑似コード:\nread S\ncharacters = sort characters of S ascending\nprint(concatenate characters)',
    ),
    'abc243_b': (
        'まず同じ位置で同じ値になっている個数を数えます。次に、両方の列に含まれるが位置だけ異なる値を数えます。',
        '各列の要素はそれぞれ重複しません。共通する値の総数を集合などで求め、同位置一致数を引いても2つ目を求められます。',
        '疑似コード:\nread N, A, B\nexact = count i where A[i] == B[i]\ncommon = size(intersection(set(A), set(B)))\nprint(exact)\nprint(common - exact)',
    ),
    'abc244_b': (
        '現在位置だけでなく、今向いている方角も状態として持ちながら命令を左から順に処理します。',
        '方角を東・南・西・北の4状態で管理すると、Rでは次の状態へ進み、Sでは方角に対応する(dx,dy)を座標へ足せます。',
        '疑似コード:\nx = 0; y = 0; dir = east\nfor command in T:\n  if command == R: dir = turn_right(dir)\n  else: (x, y) += vector(dir)\nprint(x, y)',
    ),
}
