"""Reviewed D tasks: buckets, tree elimination, DAG paths and reconstruction."""
from __future__ import annotations
from collections import deque
from heapq import heappush,heappop
from typing import cast
import random,re
TASKS=tuple(f'abc{n:03}_d' for n in range(35,41))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc039_d':'semantic'}
Case=dict[str,str]
Pairs=tuple[tuple[int,int],...]
Triples=tuple[tuple[int,int,int],...]
Data=tuple[object,...]
MOD=1000000007
INF=10**30
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==35:
        n,m,t=ints(rows[0],3);require(2<=n<=100000 and 1<=m<=min(n*(n-1),100000) and 1<=t<=10**9 and len(rows)==m+2,'shape');a=ints(rows[1],n);edges=cast(Triples,tuple(ints(row,3) for row in rows[2:]));require(all(1<=v<=100000 for v in a) and all(1<=u<=n and 1<=v<=n and u!=v and 1<=cost<=100000 for u,v,cost in edges) and len({(u,v) for u,v,c in edges})==m,'domain');return n,t,a,edges
    if number==36:
        n=ints(rows[0],1)[0];require(2<=n<=100000 and len(rows)==n,'shape');edges=cast(Pairs,tuple(ints(row,2) for row in rows[1:]));require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in edges),'vertices');parent=list(range(n))
        def find(j:int)->int:
            while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]
            return j
        for u,v in edges:
            ru,rv=find(u-1),find(v-1);require(ru!=rv,'tree');parent[ru]=rv
        return n,edges
    if number in (37,39):
        h,w=ints(rows[0],2);require(1<=h<=(1000 if number==37 else 100) and 1<=w<=(1000 if number==37 else 100) and len(rows)==h+1,'shape')
        if number==39:require(all(len(row)==w and set(row)<={'.','#'} for row in rows[1:]),'image');return h,w,tuple(rows[1:])
        a=tuple(ints(row,w) for row in rows[1:]);require(all(1<=v<=10**9 for row in a for v in row),'values');return h,w,a
    if number==38:
        n=ints(rows[0],1)[0];require(1<=n<=100000 and len(rows)==n+1,'shape');a=cast(Pairs,tuple(ints(row,2) for row in rows[1:]));require(all(1<=v<=100000 for pair in a for v in pair),'boxes');return (a,)
    n,m=ints(rows[0],2);require(1<=n<=100000 and 0<=m<=200000 and len(rows)>=m+2,'shape');a=cast(Triples,tuple(ints(row,3) for row in rows[1:m+1]));q=ints(rows[m+1],1)[0];require(1<=q<=100000 and len(rows)==m+q+2,'queries');queries=cast(Pairs,tuple(ints(row,2) for row in rows[m+2:]));require(all(1<=u<=n and 1<=v<=n and u!=v and 1<=year<=200000 for u,v,year in a) and all(1<=v<=n and 0<=year<=200000 for v,year in queries),'roads/years');return n,a,queries

def delta_distances(n:int,edges:Triples,reverse:bool)->list[int]:
    graph:list[list[tuple[int,int]]]=[[] for _ in range(n)]
    for u,v,c in edges:graph[(v if reverse else u)-1].append(((u if reverse else v)-1,c))
    delta=256;dist=[INF]*n;dist[0]=0;buckets:dict[int,set[int]]={0:{0}};indices=[0]
    def relax(v:int,value:int)->None:
        if value>=dist[v]:return
        dist[v]=value;index=value//delta
        if index not in buckets:buckets[index]=set();heappush(indices,index)
        buckets[index].add(v)
    while indices:
        index=heappop(indices)
        if index not in buckets:continue
        settled=set()
        while index in buckets:
            current=buckets.pop(index);valid=[v for v in current if dist[v]//delta==index];settled.update(valid)
            for u in valid:
                for v,c in graph[u]:
                    if c<=delta:relax(v,dist[u]+c)
        for u in settled:
            for v,c in graph[u]:
                if c>delta:relax(v,dist[u]+c)
    return dist

def image_masks(rows:tuple[str,...])->list[int]:return [sum((v=='#')<<j for j,v in enumerate(row)) for row in rows]
def dilated(masks:list[int],width:int)->list[int]:
    limit=(1<<width)-1;out=[]
    for j in range(len(masks)):
        bits=0
        for row in masks[max(0,j-1):min(len(masks),j+2)]:bits|=row|(row<<1)|(row>>1)
        out.append(bits&limit)
    return out

def restored_image(rows:tuple[str,...],width:int)->list[int]|None:
    original=image_masks(rows);limit=(1<<width)-1;candidates=[]
    for j in range(len(rows)):
        mask=limit
        for row in original[max(0,j-1):min(len(rows),j+2)]:mask&=row&((row<<1)|1)&((row>>1)|(1<<(width-1)))
        candidates.append(mask&limit)
    return candidates if dilated(candidates,width)==original else None

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==35:
        n,t,a,edges=cast(tuple[int,int,tuple[int,...],Triples],data);outward=delta_distances(n,edges,False);inward=delta_distances(n,edges,True);return str(max(max(0,t-outward[j]-inward[j])*a[j] for j in range(n)))
    if number==36:
        n,edges=cast(tuple[int,Pairs],data);graph=[[] for _ in range(n)];degree=[0]*n
        for u,v in edges:graph[u-1].append(v-1);graph[v-1].append(u-1);degree[u-1]+=1;degree[v-1]+=1
        black=[1]*n;white=[1]*n;alive=[True]*n;leaves=deque(j for j,d in enumerate(degree) if d<=1)
        while leaves:
            u=leaves.popleft()
            if not alive[u]:continue
            alive[u]=False
            if degree[u]==0:return str((black[u]+white[u])%MOD)
            v=next(v for v in graph[u] if alive[v]);white[v]=white[v]*(white[u]+black[u])%MOD;black[v]=black[v]*white[u]%MOD;degree[v]-=1
            if degree[v]<=1:leaves.append(v)
        raise ValueError('tree elimination')
    if number==37:
        h,w,a=cast(tuple[int,int,tuple[tuple[int,...],...]],data);flat=[v for row in a for v in row];n=h*w;degree=bytearray(n);dp=[1]*n
        def neighbors(j:int)->tuple[int,...]:return tuple(v for v in (j-w if j>=w else -1,j+w if j+w<n else -1,j-1 if j%w else -1,j+1 if j%w+1<w else -1) if v>=0)
        for j in range(n):degree[j]=sum(flat[v]>flat[j] for v in neighbors(j))
        ready=deque(j for j,d in enumerate(degree) if d==0);answer=0
        while ready:
            u=ready.popleft();answer=(answer+dp[u])%MOD
            for v in neighbors(u):
                if flat[v]<flat[u]:dp[v]=(dp[v]+dp[u])%MOD;degree[v]-=1
                else:continue
                if degree[v]==0:ready.append(v)
        return str(answer)
    if number==38:
        a=sorted(cast(Pairs,data[0]));tree=[0]*100001;answer=0;j=0
        def prefix(h:int)->int:
            best=0
            while h:best=max(best,tree[h]);h-=h&-h
            return best
        while j<len(a):
            end=j
            while end<len(a) and a[end][0]==a[j][0]:end+=1
            updates=[(h,1+prefix(h-1)) for w,h in a[j:end]]
            for h,value in updates:
                answer=max(answer,value)
                while h<len(tree):tree[h]=max(tree[h],value);h+=h&-h
            j=end
        return str(answer)
    if number==39:
        h,w,rows=cast(tuple[int,int,tuple[str,...]],data);candidates=restored_image(rows,w)
        if candidates is None:return 'impossible'
        return 'possible\n'+'\n'.join(''.join('#' if mask>>j&1 else '.' for j in range(w)) for mask in candidates)
    n,edges,queries=cast(tuple[int,Triples,Pairs],data);capacity=2*n;uf=list(range(capacity));parent=[-1]*capacity;year=[-1]*capacity;size=[1]*capacity;nextnode=n
    def find(j:int)->int:
        while uf[j]!=j:uf[j]=uf[uf[j]];j=uf[j]
        return j
    for u,v,built in sorted(edges,key=lambda e:e[2],reverse=True):
        ru,rv=find(u-1),find(v-1)
        if ru==rv:continue
        node=nextnode;nextnode+=1;uf[ru]=uf[rv]=node;parent[ru]=parent[rv]=node;year[node]=built;size[node]=size[ru]+size[rv]
    up=[parent[:nextnode]]
    for _ in range(nextnode.bit_length()):previous=up[-1];up.append([previous[v] if v>=0 else -1 for v in previous])
    out=[]
    for v,threshold in queries:
        j=v-1
        for level in range(len(up)-1,-1,-1):ancestor=up[level][j];j=ancestor if ancestor>=0 and year[ancestor]>threshold else j
        out.append(str(size[j]))
    return '\n'.join(out)

def semantic_image_valid(raw:str,actual:str)->bool:
    try:
        h,w,rows=cast(tuple[int,int,tuple[str,...]],validate('abc039_d',raw));output=actual.removesuffix('\n').split('\n')
        if output==['impossible']:return restored_image(rows,w) is None
        if len(output)!=h+1 or output[0]!='possible' or any(len(row)!=w or set(row)-{'.','#'} for row in output[1:]):return False
        return dilated(image_masks(tuple(output[1:])),w)==image_masks(rows)
    except (ValueError,IndexError,TypeError):return False

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc039_d':return semantic_image_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc039_d':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc035_d':"from heapq import heappush,heappop\nn,m,t=map(int,input().split());a=list(map(int,input().split()));g=[[] for _ in range(n)];r=[[] for _ in range(n)]\nfor _ in range(m):u,v,c=map(int,input().split());g[u-1].append((v-1,c));r[v-1].append((u-1,c))\ndef distances(graph):\n d=[10**30]*n;d[0]=0;heap=[(0,0)]\n while heap:\n  value,u=heappop(heap)\n  if value!=d[u]:continue\n  for v,c in graph[u]:\n   if value+c<d[v]:d[v]=value+c;heappush(heap,(d[v],v))\n return d\nx=distances(g);y=distances(r);print(max(max(0,t-x[j]-y[j])*a[j] for j in range(n)))\n",
'abc036_d':"n=int(input());g=[[] for _ in range(n)]\nfor _ in range(n-1):u,v=map(int,input().split());g[u-1].append(v-1);g[v-1].append(u-1)\nparent=[-1]*n;order=[0]\nfor u in order:\n for v in g[u]:\n  if v!=parent[u]:parent[v]=u;order.append(v)\nwhite=[1]*n;black=[1]*n;mod=1000000007\nfor u in reversed(order):\n for v in g[u]:\n  if v!=parent[u]:white[u]=white[u]*(white[v]+black[v])%mod;black[u]=black[u]*white[v]%mod\nprint((white[0]+black[0])%mod)\n",
'abc037_d':"h,w=map(int,input().split());a=[v for _ in range(h) for v in map(int,input().split())];dp=[1]*(h*w);mod=1000000007\nfor j in sorted(range(h*w),key=lambda j:a[j]):\n for k in (j-w if j>=w else -1,j+w if j+w<h*w else -1,j-1 if j%w else -1,j+1 if j%w+1<w else -1):\n  if k>=0 and a[k]>a[j]:dp[k]=(dp[k]+dp[j])%mod\nprint(sum(dp)%mod)\n",
'abc038_d':"from bisect import bisect_left\nn=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];tails=[]\nfor w,h in sorted(a,key=lambda v:(v[0],-v[1])):\n j=bisect_left(tails,h)\n if j==len(tails):tails.append(h)\n else:tails[j]=h\nprint(len(tails))\n",
'abc039_d':"h,w=map(int,input().split());s=[input() for _ in range(h)];a=[['.']*w for _ in range(h)]\nfor i in range(h):\n for j in range(w):\n  if all(s[x][y]=='#' for x in range(max(0,i-1),min(h,i+2)) for y in range(max(0,j-1),min(w,j+2))):a[i][j]='#'\nb=[['.']*w for _ in range(h)]\nfor i in range(h):\n for j in range(w):\n  if a[i][j]=='#':\n   for x in range(max(0,i-1),min(h,i+2)):\n    for y in range(max(0,j-1),min(w,j+2)):b[x][y]='#'\nif [''.join(row) for row in b]!=s:print('impossible')\nelse:print('possible');print('\\n'.join(''.join(row) for row in a))\n",
'abc040_d':"n,m=map(int,input().split());edges=[tuple(map(int,input().split())) for _ in range(m)];q=int(input());queries=[(*map(int,input().split()),j) for j in range(q)];parent=list(range(n));size=[1]*n\ndef find(j):\n while parent[j]!=j:parent[j]=parent[parent[j]];j=parent[j]\n return j\nanswer=[0]*q;edges.sort(key=lambda e:e[2],reverse=True);p=0\nfor v,threshold,j in sorted(queries,key=lambda r:r[1],reverse=True):\n while p<m and edges[p][2]>threshold:\n  u,z,y=edges[p];p+=1;ru,rv=find(u-1),find(z-1)\n  if ru!=rv:\n   if size[ru]<size[rv]:ru,rv=rv,ru\n   parent[rv]=ru;size[ru]+=size[rv]\n answer[j]=size[find(v-1)]\nprint('\\n'.join(map(str,answer)))\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18000+int(pid[3:6]));number=int(pid[3:6])
    if number==35:
        def treasure(t:int,a:list[int],edges:list[tuple[int,int,int]])->str:return f'{len(a)} {len(edges)} {t}\n'+line(a)+''.join(line(e) for e in edges)
        raws=[treasure(t,a,e) for t,a,e in ((1,[1,1],[(1,2,1)]),(2,[1,2],[(1,2,1),(2,1,1)]),(3,[1,10],[(1,2,1),(2,1,1)]),(10,[1,100,1000],[(1,2,1),(2,3,1)]))]
        for n in range(3,15):
            pairs=[(u,v) for u in range(1,n+1) for v in range(1,n+1) if u!=v];edges=[(u,v,rng.randint(1,500)) for u,v in rng.sample(pairs,min(len(pairs),3*n))];raws.append(treasure(rng.randint(1,1000),[rng.randint(1,100000) for _ in range(n)],edges))
        raws.extend([treasure(10**9,list(range(1,100001)),[(j,j+1 if j<100000 else 1,1) for j in range(1,100001)]),treasure(10**9,[100000]*100000,[(j,j+1 if j<100000 else 1,100000) for j in range(1,100001)])])
    elif number==36:
        def tree(n:int,edges:list[tuple[int,int]])->str:return f'{n}\n'+''.join(line(e) for e in edges)
        raws=[tree(n,e) for n,e in ((2,[(1,2)]),(3,[(1,2),(2,3)]),(3,[(1,2),(1,3)]),(4,[(1,2),(2,3),(3,4)]))];raws.extend(tree(n,[(j,rng.randint(1,j-1)) for j in range(2,n+1)]) for n in range(5,17));raws.extend([tree(100000,[(j,j+1) for j in range(1,100000)]),tree(100000,[(1,j) for j in range(2,100001)])])
    elif number==37:
        def grid(a:list[list[int]])->str:return f'{len(a)} {len(a[0])}\n'+''.join(line(row) for row in a)
        raws=[grid(a) for a in ([[1]],[[1,1]],[[1,2]],[[3,2],[1,4]])];raws.extend(grid([[rng.randint(1,100) for _ in range(n%5+1)] for _ in range(n)]) for n in range(3,15));raws.extend([grid([[i*1000+j+1 for j in range(1000)] for i in range(1000)]),grid([[10**9]*1000 for _ in range(1000)])])
    elif number==38:
        def boxes(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[boxes(a) for a in ([(1,1)],[(1,1),(1,1)],[(1,1),(2,2)],[(1,2),(1,3),(2,2)])];raws.extend(boxes([(rng.randint(1,100),rng.randint(1,100)) for _ in range(n)]) for n in range(3,15));raws.extend([boxes([(j,j) for j in range(1,100001)]),boxes([(100000,100000)]*100000)])
    elif number==39:
        def image(rows:list[str])->str:return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'
        raws=[image(rows) for rows in (['.'],['#'],['#.'],['##','##'])];raws.extend(image([''.join(rng.choice('.#') for _ in range(n%5+1)) for _ in range(n)]) for n in range(3,15));raws.extend([image(['#'*100 if i%2==0 else '.'*100 for i in range(100)]),image(['#'*100]*100)])
    else:
        def roads(n:int,e:list[tuple[int,int,int]],queries:list[tuple[int,int]])->str:return f'{n} {len(e)}\n'+''.join(line(edge) for edge in e)+f'{len(queries)}\n'+''.join(line(query) for query in queries)
        raws=[roads(n,e,q) for n,e,q in ((1,[],[(1,0)]),(2,[(1,2,1)],[(1,0),(1,1)]),(2,[(1,2,1),(2,1,2)],[(1,1),(1,2)]),(3,[(1,2,10)],[(3,0),(1,10)]))]
        for n in range(3,15):edges=[(*rng.sample(range(1,n+1),2),rng.randint(1,200000)) for _ in range(n*3)];raws.append(roads(n,edges,[(rng.randint(1,n),rng.randint(0,200000)) for _ in range(2*n)]))
        raws.extend([roads(100000,[(j,j+1,j) for j in range(1,100000)],[(j,j-1) for j in range(1,100001)]),roads(100000,[(1,j,200000) for j in range(2,100001)]+[(1,2,1)]*100001,[(100000,200000),(1,0)]*50000)])
    require(len(raws)==len(set(raws))==18,'unique');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc035_d':('最も儲かる町に滞在し、移動に必要な時間を引きます。','町1から各町までと、各町から町1までの最短時間を求めます。帰路は辺を反転して求められます。','疑似コード: Dijkstra(元graph,1),Dijkstra(逆graph,1); 各iでmax(0,T-go[i]-back[i])*A[i]; 最大を出力。'),
'abc036_d':('木の各部分を、頂点が白の場合と黒の場合に分けて数えます。','親が黒なら子は白だけ、親が白なら子は白か黒です。子の塗り方を掛け合わせます。','疑似コード: 木をroot化し逆訪問順でwhite[u]*=white[v]+black[v],black[u]*=white[v]; 全てmod1e9+7; rootの2状態合計を出力。'),
'abc037_d':('値が増える方向だけ進めるので、値の順に計算できます。','各マス単独の経路を1として、小さい値のマスから大きい値の隣接マスへ経路数を足します。','疑似コード: dp全て1; マスを値昇順sort; 各隣接vでA[v]>A[u]ならdp[v]+=dp[u]（mod）; 全dp合計。'),
'abc038_d':('一方の辺で並べ、もう一方の辺の狭義増加列を求めます。','横幅を昇順、同じ横幅では高さを降順に並べると、同じ横幅を複数選ぶことを防げます。','疑似コード: sort(w昇順,h降順); 各hでtailsのlower_bound位置を置換/末尾追加; tails長を出力。'),
'abc039_d':('元の黒い画素の周囲は、観測画像ですべて黒いはずです。','周囲9画素が全て黒い位置だけを元画像の黒候補にします。そこから膨張した画像が入力と一致するか確認します。','疑似コード: candidate[i][j]=inbounds9近傍が全#; candidate黒の9近傍をreproducedで黒にする; reproduced=Sならpossibleとcandidate、他はimpossible。'),
'abc040_d':('新しい道路から順に都市を連結します。','質問も基準年の降順に処理し、基準年より新しい道路だけをDSUへ追加します。同じ年の道路はまだ追加しません。','疑似コード: edgesとqueriesを年降順sort; 各wでedge.year>wの間union; find(v)のcomponent sizeを元の質問順へ保存して出力。')}

TITLES={'abc035_d': 'トレジャーハント', 'abc036_d': '塗り絵', 'abc037_d': '経路', 'abc038_d': 'プレゼント', 'abc039_d': '画像処理高橋君', 'abc040_d': '道路の老朽化対策について'}
PUBLISHED_SAMPLES={'abc035_d': [{'input': '2 2 5\n1 3\n1 2 2\n2 1 1\n', 'expected': '6\n'}, {'input': '2 2 3\n1 3\n1 2 2\n2 1 1\n', 'expected': '3\n'}, {'input': '8 15 120\n1 2 6 16 1 3 11 9\n1 8 1\n7 3 14\n8 2 13\n3 5 4\n5 7 5\n6 4 1\n6 8 17\n7 8 5\n1 4 2\n4 7 1\n6 1 3\n3 1 10\n2 6 5\n2 4 12\n5 1 30\n', 'expected': '1488\n'}], 'abc036_d': [{'input': '5\n2 5\n1 5\n2 4\n3 2\n', 'expected': '14\n'}, {'input': '10\n7 9\n8 1\n9 6\n10 8\n8 6\n10 3\n5 8\n4 8\n2 5\n', 'expected': '192\n'}], 'abc037_d': [{'input': '2 3\n1 4 5\n2 4 9\n', 'expected': '18\n'}, {'input': '6 6\n1 3 4 6 7 5\n1 2 4 8 8 7\n2 7 9 2 7 2\n9 4 2 7 6 5\n2 8 4 6 7 6\n3 7 9 1 2 7\n', 'expected': '170\n'}], 'abc038_d': [{'input': '3\n3 3\n1 1\n2 2\n', 'expected': '3\n'}, {'input': '2\n4 5\n4 3\n', 'expected': '1\n'}, {'input': '4\n2 5\n3 3\n4 5\n6 6\n', 'expected': '3\n'}, {'input': '5\n8 8\n5 3\n2 2\n4 2\n2 1\n', 'expected': '4\n'}], 'abc039_d': [{'input': '4 4\n##..\n##..\n..##\n..##\n', 'expected': 'possible\n#...\n....\n....\n...#\n'}, {'input': '4 4\n###.\n####\n..##\n..##\n', 'expected': 'possible\n##..\n....\n...#\n...#\n'}, {'input': '4 4\n###.\n##.#\n..##\n..##\n', 'expected': 'impossible\n'}], 'abc040_d': [{'input': '5 4\n1 2 2000\n2 3 2004\n3 4 1999\n4 5 2001\n3\n1 2000\n1 1999\n3 1995\n', 'expected': '1\n3\n5\n'}, {'input': '4 5\n1 2 2005\n3 1 2001\n3 4 2002\n1 4 2004\n4 2 2003\n5\n1 2003\n2 2003\n1 2001\n3 2003\n4 2004\n', 'expected': '3\n3\n4\n1\n1\n'}, {'input': '4 5\n1 2 10\n1 2 1000\n2 3 10000\n2 3 100000\n3 1 200000\n4\n1 0\n2 10000\n3 100000\n4 0\n', 'expected': '3\n3\n2\n1\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
