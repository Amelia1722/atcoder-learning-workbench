"""Statement-checked three-stage hints for ABC203–205 B."""
HINTS_V115={
 'abc203_b':(
  'i階j号室の番号は、3桁の整数として100*i+jです。全てのi,jについて足せばよいです。',
  'N,K<=9なので二重ループで全NK室を列挙しても十分小さいです。各部屋で100*i+jを合計します。',
  '''疑似コード:
ans = 0
for i in 1..N:
  for j in 1..K:
    ans += 100 * i + j
print(ans)''',
 ),
 'abc204_b':(
  '木の実が10個以下なら0個、11個以上なら10個を残した分だけ収穫します。',
  '各A_iの寄与はmax(A_i-10, 0)です。これを全て足します。',
  '''疑似コード:
ans = 0
for a in A:
  if a > 10:
    ans += a - 10
print(ans)''',
 ),
 'abc205_b':(
  '1からNまでがそれぞれちょうど1回ずつ現れるかを確認します。',
  'A_iは必ず1..Nなので、重複がなければ長さNの列は自動的に1..Nの順列です。setの要素数を見るか、sortして1..Nと比較できます。',
  '''疑似コード:
seen = empty set
for a in A:
  seen.add(a)
if size(seen) == N: print("Yes")
else: print("No")''',
 ),
}
