"""Independent interval sweep, grouped injections and split subsequence counting."""
from __future__ import annotations
from bisect import bisect_left
from collections import Counter,defaultdict
from math import comb,factorial,isqrt
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in (206,207,208,209,211,213))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
MOD=10**9+7
Data=tuple[object,...]
Case=dict[str,str]
Triple=tuple[int,int,int]
Pair=tuple[int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==211:
        require(len(rows)==1 and re.fullmatch('[a-z]{8,100000}',rows[0]) is not None,'word');return (rows[0],)
    if number==207:
        n=ints(rows[0],1)[0];require(2<=n<=2000 and len(rows)==n+1,'shape');segments=tuple(cast(Triple,ints(row,3)) for row in rows[1:]);require(all(1<=t<=4 and 1<=a<b<=10**9 for t,a,b in segments),'segments');return (segments,)
    if number==213:
        h,w,n=ints(rows[0],3);require(1<=h<=10**9 and 1<=w<=10**9 and 1<=n<=min(100000,h*w) and len(rows)==n+1,'shape');points=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(len(set(points))==n and all(1<=a<=h and 1<=b<=w for a,b in points),'cards');return (points,)
    if number==208:
        n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=10**18 and len(rows)==2,'shape');a=ints(rows[1],n);require(len(set(a))==n and all(1<=v<=10**9 for v in a),'identities');return k,a
    n=ints(rows[0],1)[0];require((2<=n<=300000 if number==206 else 1<=n<=200000) and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'values');return (a,)

def _interval_sweep(segments:tuple[Triple,...])->int:
    starts:dict[int,int]=defaultdict(int);ends:dict[int,int]=defaultdict(int)
    for t,a,b in segments:starts[2*a+int(t in (3,4))]+=1;ends[2*b-int(t in (2,4))]+=1
    active=answer=0
    for point in sorted(starts.keys()|ends.keys()):
        added=starts[point];answer+=active*added+added*(added-1)//2;active+=added;active-=ends[point]
    return answer

def _primes_up_to(limit:int)->tuple[int,...]:
    sieve=bytearray(b'\x01')*(limit+1)
    if limit>=0:sieve[0]=0
    if limit>=1:sieve[1]=0
    for prime in range(2,isqrt(limit)+1):
        if sieve[prime]:
            start=prime*prime;sieve[start:limit+1:prime]=b'\x00'*((limit-start)//prime+1)
    return tuple(j for j in range(2,limit+1) if sieve[j])

def _segmented_factorial_ratio(available:int,count:int,primes:tuple[int,...])->int:
    """Factor available!/(available-count)! without multiplying falling factors."""
    if count<=64:return comb(available,count)%MOD*(factorial(count)%MOD)%MOD
    low=available-count+1;remaining=list(range(low,available+1));exponents:Counter[int]=Counter()
    for prime in primes:
        if prime*prime>available:break
        first=((low+prime-1)//prime)*prime
        for value in range(first,available+1,prime):
            index=value-low;remainder=remaining[index];exponent=0
            while remainder%prime==0:remainder//=prime;exponent+=1
            remaining[index]=remainder;exponents[prime]+=exponent
    # Every remaining factor is prime after division by primes <= sqrt(available).
    exponents.update(value for value in remaining if value>1)
    answer=1
    for prime,exponent in exponents.items():answer=answer*pow(prime,exponent,MOD)%MOD
    return answer

def _group_injections(a:tuple[int,...])->int:
    if len(a)>max(a):return 0
    if len(a)==1:return a[0]%MOD
    if len(a)==2:return (a[0]*a[1]-min(a))%MOD
    if max(a)<=20:
        states={0:1}
        for limit in a:
            following:dict[int,int]=defaultdict(int)
            for used,count in states.items():
                for value in range(limit):
                    bit=1<<value
                    if not used&bit:following[used|bit]=(following[used|bit]+count)%MOD
            states=following
        return sum(states.values())%MOD
    # Group label assignments count as factorial(available)/factorial(available-count).
    # Wilson's theorem computes factorials near MOD from their small complement,
    # without evaluating the reference's falling-factor loop.
    frequencies=Counter(a);used=0;groups=[];arguments:set[int]=set()
    for limit,count in sorted(frequencies.items()):
        available=limit-used
        if available<count:return 0
        groups.append((available,available-count));arguments.update((available,available-count));used+=count
    complements={n:min(n,MOD-1-n) for n in arguments};needed=set(complements.values())
    if max(needed,default=0)>2*len(a)+100:
        primes=_primes_up_to(isqrt(max(before for before,after in groups))) if any(before-after>64 for before,after in groups) else ()
        answer=1
        for before,after in groups:answer=answer*_segmented_factorial_ratio(before,before-after,primes)%MOD
        return answer
    facts={0:1,1:1};value=1
    for j in range(2,max(needed,default=1)+1):
        value=value*j%MOD
        if j in needed:facts[j]=value
    values={n:facts[q] if q==n else ((-1 if (q+1)%2 else 1)*pow(facts[q],MOD-2,MOD))%MOD for n,q in complements.items()}
    answer=1
    for before,after in groups:answer=answer*values[before]%MOD*pow(values[after],MOD-2,MOD)%MOD
    return answer

def _split_subsequence(s:str)->int:
    suffix=[0]*(len(s)+1);right=[0,0,0,1]
    for j in range(len(s)-1,-1,-1):
        for k,char in enumerate('dai'):
            if s[j]==char:right[k]=(right[k]+right[k+1])%MOD
        suffix[j]=right[0]
    left=[1,0,0,0,0];answer=0
    for j,char in enumerate(s):
        if char=='u':answer=(answer+left[4]*suffix[j+1])%MOD
        for k,target in enumerate('chok',1):
            if char==target:left[k]=(left[k]+left[k-1])%MOD
    return answer

def _coordinate_groups(points:tuple[Pair,...])->str:
    compressed=[[0,0] for _ in points]
    for axis in (0,1):
        previous=-1;rank=0
        for j in sorted(range(len(points)),key=lambda j:points[j][axis]):
            value=points[j][axis]
            if value!=previous:rank+=1;previous=value
            compressed[j][axis]=rank
    return '\n'.join(f'{a} {b}' for a,b in compressed)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==206:
        a=sorted(cast(tuple[int,...],data[0]));answer=below=0;j=0
        while j<len(a):
            end=j+1
            while end<len(a) and a[end]==a[j]:end+=1
            answer+=(end-j)*below;below+=end-j;j=end
        return str(answer)
    if number==207:return str(_interval_sweep(cast(tuple[Triple,...],data[0])))
    if number==208:
        k,a=cast(tuple[int,tuple[int,...]],data);ordered=sorted(a);lo=0;hi=k+1
        while hi-lo>1:
            middle=(lo+hi)//2
            if middle*len(a)<=k:lo=middle
            else:hi=middle
        remaining=k-lo*len(a);return '\n'.join(str(lo+int(bisect_left(ordered,v)<remaining)) for v in a)
    if number==209:return str(_group_injections(cast(tuple[int,...],data[0])))
    if number==211:return str(_split_subsequence(cast(str,data[0])))
    return _coordinate_groups(cast(tuple[Pair,...],data[0]))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc206_c':"from collections import Counter\nn=int(input());a=Counter(map(int,input().split()));print(n*(n-1)//2-sum(c*(c-1)//2 for c in a.values()))\n",
'abc207_c':"n=int(input());segments=[tuple(map(int,input().split())) for _ in range(n)];answer=0\nfor i,(t,l,r) in enumerate(segments):\n for u,a,b in segments[i+1:]:\n  low=max(l,a);high=min(r,b)\n  if low<high:answer+=1\n  elif low==high:\n   contains=lambda kind,left,right: (left<low<right) or (low==left and kind in (1,2)) or (low==right and kind in (1,3))\n   answer+=contains(t,l,r) and contains(u,a,b)\nprint(answer)\n",
'abc208_c':"n,k=map(int,input().split());a=list(map(int,input().split()));base,remaining=divmod(k,n);answer=[base]*n\nfor j in sorted(range(n),key=lambda j:a[j])[:remaining]:answer[j]+=1\nprint('\\n'.join(map(str,answer)))\n",
'abc209_c':"n=int(input());a=sorted(map(int,input().split()));answer=1\nfor j,limit in enumerate(a):answer=answer*max(0,limit-j)%1000000007\nprint(answer)\n",
'abc211_c':"s=input();target='chokudai';dp=[1]+[0]*8\nfor char in s:\n for j in range(7,-1,-1):\n  if char==target[j]:dp[j+1]=(dp[j+1]+dp[j])%1000000007\nprint(dp[8])\n",
'abc213_c':"h,w,n=map(int,input().split());points=[tuple(map(int,input().split())) for _ in range(n)];rows={v:j+1 for j,v in enumerate(sorted({a for a,b in points}))};columns={v:j+1 for j,v in enumerate(sorted({b for a,b in points}))}\nfor a,b in points:print(rows[a],columns[b])\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16400+number)
    if number in (206,209):
        def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
        if number==206:raws=[array([1,1]),array([1,2]),array([2,1]),array([1,2,1])]+[array([rng.randrange(1,20) for _ in range(n)]) for n in range(4,16)]+[array([1]*150000+[10**9]*150000),array([10**9]*300000)]
        else:raws=[array([1]),array([10**9]),array([1,1]),array([1,2])]+[array([rng.randrange(1,10) for _ in range(n)]) for n in range(3,15)]+[array([1]*200000),array([10**9]*200000)]
    elif number==207:
        def intervals(segments:list[Triple])->str:return f'{len(segments)}\n'+''.join(line(s) for s in segments)
        raws=[intervals([(1,1,2),(1,1,2)])]
        for t,u in [(a,b) for a in range(1,5) for b in range(1,5)][:15]:raws.append(intervals([(t,1,2),(u,2,3)]))
        raws.extend([intervals([(4,j,j+1) for j in range(1,2001)]),intervals([(4,1,10**9)]*2000)])
    elif number==208:
        def candy(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[candy(1,[1]),candy(1,[1,2]),candy(2,[1,2]),candy(3,[2,1])]+[candy(j*5+1,rng.sample(range(1,1000),j+2)) for j in range(1,13)]+[candy(1,list(range(1,200001))),candy(10**18,list(range(10**9,10**9-200000,-1)))]
    elif number==211:
        raws=['chokudai\n','aaaaaaaa\n','iadukohc\n','chokudaichokudai\n']+[''.join(rng.choice('chokudaix') for _ in range(8+j*7))+'\n' for j in range(1,13)]+['chokudai'*12500+'\n',''.join(char*12500 for char in 'chokudai')+'\n']
    else:
        def cards(h:int,w:int,points:list[Pair])->str:return f'{h} {w} {len(points)}\n'+''.join(line(p) for p in points)
        raws=[cards(1,1,[(1,1)]),cards(10**9,10**9,[(10**9,10**9)]),cards(2,2,[(1,2),(2,1)]),cards(3,3,[(1,1),(1,3),(3,1)])]
        for j in range(1,13):
            points=rng.sample([(r,c) for r in range(1,11) for c in range(1,11)],j+4);raws.append(cards(10,10,points))
        raws.extend([cards(10**9,10**9,[(1,j) for j in range(1,100001)]),cards(10**9,10**9,[(10**9-j,10**9-j) for j in range(100000)])])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc206_c':('値が異なる二つの位置の組を数えます。','全ペア数から、同じ値を持つ各グループのペア数を引きます。','疑似コード: counts=frequencies(A); print(N*(N-1)/2-sum(c*(c-1)/2 for c in counts))。'),
'abc207_c':('端点が開いているか閉じているかで、接する二つの区間の判定が変わります。','各ペアで重なる範囲を調べ、端点一点だけで接するときは両方にその点が含まれるか確認します。','疑似コード: for each interval pair: low=max(lefts); high=min(rights); if low<high or (low==high and both contain low): answer+=1; print(answer)。'),
'abc208_c':('全員に同じ数を配った後、余りを誰へ渡すかを決めます。','各人へK//N個を配り、番号が小さい順の先頭K%N人へ一個ずつ追加します。','疑似コード: answer=[K//N]*N; for index in indices sorted by a, first K%N: answer[index]+=1; print each answer。'),
'abc209_c':('上限が小さい要素から順に値を割り当てます。','Cを昇順に並べると、i番目では以前に使ったi個を除き、C[i]−i通りが残ります。','疑似コード: C=sort(C); answer=1; for i: answer=answer*max(0,C[i]-i) mod(10^9+7); print(answer)。'),
'abc211_c':('chokudaiの何文字目まで選んだかを状態にします。','dp[j]を先頭j文字を選ぶ方法の数とし、同じ文字を重複利用しないよう後ろから更新します。','疑似コード: dp[0]=1; for char in S: for j=7..0: if char==target[j]: dp[j+1]+=dp[j] modulo(10^9+7); print(dp[8])。'),
'abc213_c':('カードのある行と列だけが残るので、元の座標の大小関係を保つ番号へ変換します。','行座標と列座標をそれぞれ重複なしで昇順に並べ、1からの順位に置き換えます。','疑似コード: row_rank=rank(sorted(unique(rows))); col_rank=rank(sorted(unique(cols))); for card: print(row_rank[a],col_rank[b])。')}

TITLES={'abc206_c': 'Swappable', 'abc207_c': 'Many Segments', 'abc208_c': 'Fair Candy Distribution', 'abc209_c': 'Not Equal', 'abc211_c': 'chokudai', 'abc213_c': 'Reorder Cards'}
PUBLISHED_SAMPLES={'abc206_c': [{'input': '3\n1 7 1\n', 'expected': '2\n'}, {'input': '10\n1 10 100 1000 10000 100000 1000000 10000000 100000000 1000000000\n', 'expected': '45\n'}, {'input': '20\n7 8 1 1 4 9 9 6 8 2 4 1 1 9 5 5 5 3 6 4\n', 'expected': '173\n'}], 'abc207_c': [{'input': '3\n1 1 2\n2 2 3\n3 2 4\n', 'expected': '2\n'}, {'input': '19\n4 210068409 221208102\n4 16698200 910945203\n4 76268400 259148323\n4 370943597 566244098\n1 428897569 509621647\n4 250946752 823720939\n1 642505376 868415584\n2 619091266 868230936\n2 306543999 654038915\n4 486033777 715789416\n1 527225177 583184546\n2 885292456 900938599\n3 264004185 486613484\n2 345310564 818091848\n1 152544274 521564293\n4 13819154 555218434\n3 507364086 545932412\n4 797872271 935850549\n2 415488246 685203817\n', 'expected': '102\n'}], 'abc208_c': [{'input': '2 7\n1 8\n', 'expected': '4\n3\n'}, {'input': '1 3\n33\n', 'expected': '3\n'}, {'input': '7 1000000000000\n99 8 2 4 43 5 3\n', 'expected': '142857142857\n142857142857\n142857142858\n142857142857\n142857142857\n142857142857\n142857142857\n'}], 'abc209_c': [{'input': '2\n1 3\n', 'expected': '2\n'}, {'input': '4\n3 3 4 4\n', 'expected': '12\n'}, {'input': '2\n1 1\n', 'expected': '0\n'}, {'input': '10\n999999917 999999914 999999923 999999985 999999907 999999965 999999914 999999908 999999951 999999979\n', 'expected': '405924645\n'}], 'abc211_c': [{'input': 'chchokudai\n', 'expected': '3\n'}, {'input': 'atcoderrr\n', 'expected': '0\n'}, {'input': 'chokudaichokudaichokudai\n', 'expected': '45\n'}], 'abc213_c': [{'input': '4 5 2\n3 2\n2 5\n', 'expected': '2 1\n1 2\n'}, {'input': '1000000000 1000000000 10\n1 1\n10 10\n100 100\n1000 1000\n10000 10000\n100000 100000\n1000000 1000000\n10000000 10000000\n100000000 100000000\n1000000000 1000000000\n', 'expected': '1 1\n2 2\n3 3\n4 4\n5 5\n6 6\n7 7\n8 8\n9 9\n10 10\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
