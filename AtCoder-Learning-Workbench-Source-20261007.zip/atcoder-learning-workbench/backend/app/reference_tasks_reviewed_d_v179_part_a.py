"""Exact-domain legacy D tasks with independent combinatorial and bit-plane oracles."""
from __future__ import annotations
from functools import lru_cache
from typing import cast
import random,re
TASKS=tuple(f'abc{n:03}_4' for n in range(4,10))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==4:
        require(len(rows)==1,'shape');a=ints(rows[0],3);require(all(1<=v<=300 for v in a),'marbles');return a
    if number==5:
        n=ints(rows[0],1)[0];require(1<=n<=50 and len(rows)>=n+3,'shape');a=tuple(ints(row,n) for row in rows[1:n+1]);q=ints(rows[n+1],1)[0];require(1<=q<=n*n and len(rows)==n+q+2,'queries');qs=tuple(ints(row,1)[0] for row in rows[n+2:]);require(all(1<=v<=100 for row in a for v in row) and all(1<=v<=n*n for v in qs),'values');return a,qs
    if number==6:
        n=ints(rows[0],1)[0];require(1<=n<=30000 and len(rows)==n+1,'shape');a=tuple(ints(row,1)[0] for row in rows[1:]);require(all(1<=v<=n for v in a) and len(set(a))==n,'permutation');return (a,)
    if number==7:
        require(len(rows)==1,'shape');a,b=ints(rows[0],2);require(1<=a<=b<=10**18,'range');return a,b
    if number==8:
        w,h=ints(rows[0],2);require(1<=w<=10**6 and 1<=h<=10**6 and len(rows)>=3,'shape');n=ints(rows[1],1)[0];require(1<=n<=30 and len(rows)==n+2,'devices');a=tuple(ints(row,2) for row in rows[2:]);require(all(1<=x<=w and 1<=y<=h for x,y in a) and len({x for x,y in a})==len({y for x,y in a})==n,'coordinates');return w,h,a
    require(len(rows)==3,'shape');k,m=ints(rows[0],2);require(1<=k<=100 and 1<=m<=10**9,'recurrence');a,c=ints(rows[1],k),ints(rows[2],k);require(all(0<=v<2**32 for seq in (a,c) for v in seq),'uint32');return m,a,c

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==4:
        r,g,b=cast(tuple[int,int,int],data);n=r+g+b;centers=[-100]*r+[0]*g+[100]*b;dp=[0]+[10**12]*n
        for position in range(-100-n,101+n):
            for used in range(n,0,-1):dp[used]=min(dp[used],dp[used-1]+abs(position-centers[used-1]))
        return str(dp[-1])
    if number==5:
        a,qs=cast(tuple[tuple[tuple[int,...],...],tuple[int,...]],data);n=len(a);best=[0]*(n*n+1)
        for top in range(n):
            columns=[0]*n
            for bottom in range(top,n):
                for j in range(n):columns[j]+=a[bottom][j]
                for left in range(n):
                    total=0
                    for right in range(left,n):total+=columns[right];area=(bottom-top+1)*(right-left+1);best[area]=max(best[area],total)
        for j in range(1,len(best)):best[j]=max(best[j],best[j-1])
        return '\n'.join(str(best[v]) for v in qs)
    if number==6:
        a=cast(tuple[int,...],data[0]);n=len(a);tree=[0]*(n+1);best=0
        for v in a:
            j=v-1;length=0
            while j:length=max(length,tree[j]);j-=j&-j
            length+=1;best=max(best,length);j=v
            while j<=n:tree[j]=max(tree[j],length);j+=j&-j
        return str(n-best)
    if number==7:
        a,b=cast(tuple[int,int],data)
        def safe(bound:int)->int:
            digits=str(bound);count=0
            for j,ch in enumerate(digits):
                d=int(ch);remaining=len(digits)-j-1;count+=sum(v<d for v in range(10) if v not in (4,9))*8**remaining
                if d in (4,9):return count
            return count+1
        return str(b-a+1-safe(b)+safe(a-1))
    if number==8:
        w,h,a=cast(tuple[int,int,tuple[tuple[int,int],...]],data);n=len(a)
        if n==1:return str(w+h-1)
        if n<=8 and w*h<=6400:
            @lru_cache(None)
            def physical(gold:int,unused:int)->int:
                if not unused:return 0
                best=0
                for j,(x,y) in enumerate(a):
                    if not (unused>>j&1):continue
                    removed=1<<((y-1)*w+x-1)
                    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                        xx,yy=x+dx,y+dy
                        while 1<=xx<=w and 1<=yy<=h:
                            bit=1<<((yy-1)*w+xx-1)
                            if not gold&bit:break
                            removed|=bit;xx+=dx;yy+=dy
                    best=max(best,removed.bit_count()+physical(gold^removed,unused^(1<<j)))
                return best
            return str(physical((1<<(w*h))-1,(1<<n)-1))
        xs=[0]+sorted(x for x,y in a)+[w+1];ys=[0]+sorted(y for x,y in a)+[h+1];xi={v:j for j,v in enumerate(xs)};yi={v:j for j,v in enumerate(ys)};points=[(xi[x],yi[y]) for x,y in a];dp:dict[tuple[int,int,int,int],int]={}
        for dx in range(2,n+2):
            for dy in range(2,n+2):
                for left in range(n+2-dx):
                    right=left+dx
                    for bottom in range(n+2-dy):
                        top=bottom+dy;best=0
                        for x,y in points:
                            if left<x<right and bottom<y<top:
                                value=xs[right]-xs[left]+ys[top]-ys[bottom]-3
                                value+=dp.get((left,x,bottom,y),0)+dp.get((left,x,y,top),0)+dp.get((x,right,bottom,y),0)+dp.get((x,right,y,top),0);best=max(best,value)
                        dp[left,right,bottom,top]=best
        return str(dp[0,n+1,0,n+1])
    m,a,c=cast(tuple[int,tuple[int,...],tuple[int,...]],data);k=len(a)
    if m<=k:return str(a[m-1])
    answer=0
    for bit in range(32):
        rows=[1<<(j+1) for j in range(k-1)]+[sum(1<<j for j in range(k) if c[k-1-j]>>bit&1)];state=sum(1<<j for j,v in enumerate(a) if v>>bit&1);power=m-k
        while power:
            if power&1:state=sum(1<<j for j,row in enumerate(rows) if (row&state).bit_count()%2)
            power//=2
            if not power:break
            squared=[]
            for row in rows:
                value=0
                while row:
                    low=row&-row;value^=rows[low.bit_length()-1];row-=low
                squared.append(value)
            rows=squared
        answer|=(state>>(k-1)&1)<<bit
    return str(answer)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc004_4':"r,g,b=map(int,input().split())\ndef cost(start,n,center):\n end=start+n-1\n if end<center:return n*center-n*(start+end)//2\n if start>center:return n*(start+end)//2-n*center\n left=center-start;right=end-center;return left*(left+1)//2+right*(right+1)//2\nanswer=10**12;total=r+g+b\nfor start in range(-100-total,101+total):\n red=min(-100-(r-1)//2,start-r);blue=max(100-b//2,start+g);answer=min(answer,cost(red,r,-100)+cost(start,g,0)+cost(blue,b,100))\nprint(answer)\n",
'abc005_4':"n=int(input());a=[list(map(int,input().split())) for _ in range(n)];q=int(input());queries=[int(input()) for _ in range(q)];p=[[0]*(n+1) for _ in range(n+1)];best=[0]*(n*n+1)\nfor i in range(n):\n for j in range(n):p[i+1][j+1]=a[i][j]+p[i][j+1]+p[i+1][j]-p[i][j]\nfor top in range(n):\n for bottom in range(top+1,n+1):\n  for left in range(n):\n   for right in range(left+1,n+1):\n    area=(bottom-top)*(right-left);best[area]=max(best[area],p[bottom][right]-p[top][right]-p[bottom][left]+p[top][left])\nfor j in range(1,len(best)):best[j]=max(best[j],best[j-1])\nprint('\\n'.join(str(best[v]) for v in queries))\n",
'abc006_4':"from bisect import bisect_left\nn=int(input());tails=[]\nfor _ in range(n):\n v=int(input());j=bisect_left(tails,v)\n if j==len(tails):tails.append(v)\n else:tails[j]=v\nprint(n-len(tails))\n",
'abc007_4':"a,b=map(int,input().split())\ndef forbidden(bound):\n states={(False,False):1}\n for ch in str(bound):\n  new={};limit=int(ch)\n  for (less,bad),count in states.items():\n   for d in range(10 if less else limit+1):\n    key=(less or d<limit,bad or d in (4,9));new[key]=new.get(key,0)+count\n  states=new\n return sum(count for (less,bad),count in states.items() if bad)\nprint(forbidden(b)-forbidden(a-1))\n",
'abc008_4':"from functools import lru_cache\nw,h=map(int,input().split());n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)]\n@lru_cache(None)\ndef solve(left,right,bottom,top):\n answer=0\n for x,y in points:\n  if left<=x<=right and bottom<=y<=top:\n   value=right-left+top-bottom+1+solve(left,x-1,bottom,y-1)+solve(left,x-1,y+1,top)+solve(x+1,right,bottom,y-1)+solve(x+1,right,y+1,top);answer=max(answer,value)\n return answer\nprint(solve(1,w,1,h))\n",
'abc009_4':"k,m=map(int,input().split());a=list(map(int,input().split()));c=list(map(int,input().split()));unit=2**32-1\ndef multiply(left,right):\n out=[0]*(2*k-1)\n for i,x in enumerate(left):\n  for j,y in enumerate(right):out[i+j]^=x&y\n for degree in range(2*k-2,k-1,-1):\n  for j,v in enumerate(c,1):out[degree-j]^=out[degree]&v\n return out[:k]\nresult=[unit]+[0]*(k-1);base=([0,unit]+[0]*(k-2)) if k>1 else [c[0]];power=m-1\nwhile power:\n if power&1:result=multiply(result,base)\n power//=2\n if power:base=multiply(base,base)\nanswer=0\nfor x,y in zip(result,a):answer^=x&y\nprint(answer)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17900+number)
    if number==4:
        raws=[line(a) for a in ((1,1,1),(1,2,1),(2,1,2),(300,1,300))];raws.extend(line([rng.randint(1,100) for _ in range(3)]) for _ in range(12));raws.extend([line((1,300,1)),line((300,300,300))])
    elif number==5:
        def food(a:list[list[int]],qs:list[int])->str:return f'{len(a)}\n'+''.join(line(row) for row in a)+f'{len(qs)}\n'+''.join(f'{q}\n' for q in qs)
        raws=[food([[1]],[1]),food([[100]],[1]),food([[1,1],[100,100]],[1,2,3,4]),food([[100,1],[1,100]],[2,3])];raws.extend(food([[rng.randint(1,100) for _ in range(n)] for _ in range(n)],[rng.randint(1,n*n) for _ in range(n)]) for n in range(2,14));raws.extend([food([[1]*50 for _ in range(50)],list(range(1,2501))),food([[100]*50 for _ in range(50)],[2500]*2500)])
    elif number==6:
        def cards(a:list[int])->str:return f'{len(a)}\n'+''.join(f'{v}\n' for v in a)
        raws=[cards([1]),cards([2,1]),cards([1,2]),cards([2,3,1])]
        for n in range(3,15):
            a=list(range(1,n+1));rng.shuffle(a);raws.append(cards(a))
        raws.extend([cards(list(range(30000,0,-1))),cards(list(range(1,30001)))])
    elif number==7:
        raws=[line(v) for v in ((1,1),(4,4),(9,9),(39,40))];raws.extend(line((10**n-1,10**n+49)) for n in range(1,13));raws.extend([line((1,10**18)),line((10**18,10**18))])
    elif number==8:
        def gold(w:int,h:int,a:list[tuple[int,int]])->str:return f'{w} {h}\n{len(a)}\n'+''.join(line(v) for v in a)
        raws=[gold(1,1,[(1,1)]),gold(1,10**6,[(1,10**6)]),gold(10**6,1,[(1,1)]),gold(3,3,[(1,1),(2,3),(3,2)])]
        for n in range(2,14):
            xs=list(range(1,n+1));ys=xs.copy();rng.shuffle(xs);rng.shuffle(ys);raws.append(gold(n+1,n+2,list(zip(xs,ys))))
        raws.extend([gold(10**6,10**6,[(j,31-j) for j in range(1,31)]),gold(10**6,10**6,[(10**6-30+j,10**6-30+j) for j in range(1,31)])])
    else:
        def recurrence(m:int,a:list[int],c:list[int])->str:return f'{len(a)} {m}\n'+line(a)+line(c)
        raws=[recurrence(1,[0],[0]),recurrence(10**9,[2**32-1],[0]),recurrence(10**9,[2**32-1],[2**32-1]),recurrence(2,[1,2],[0,0])];raws.extend(recurrence(100+n,[rng.getrandbits(32) for _ in range(n)],[rng.getrandbits(32) for _ in range(n)]) for n in range(2,14));raws.extend([recurrence(10**9,[rng.getrandbits(32) for _ in range(100)],[rng.getrandbits(32) for _ in range(100)]),recurrence(10**9,[2**32-1]*100,[2**32-1]*100)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc004_4':('赤・緑・青の順序を保ち、それぞれを連続区間へ配置できます。','緑の区間の位置を列挙し、赤と青は重ならない範囲で元の位置に最も近くなるよう置きます。','疑似コード: 緑の開始sを列挙; 赤開始=min(中心付近の最適開始,s-R)、青開始=max(中心付近の最適開始,s+G); 3区間の移動距離合計の最小を出力。'),
'abc005_4':('全ての長方形の合計と面積を計算します。','二次元累積和なら長方形の合計が定数時間です。面積以下の最大値を前から累積します。','疑似コード: 2D prefixを作る; 全上下左右境界でsumを求めbest[面積]更新; best[p]=max(best[p],best[p-1]); query Pへbest[P]を出力。'),
'abc006_4':('移動させないカードは、元の順序で増加している必要があります。','最長増加部分列の長さだけは動かさずに済みます。二分探索で各長さの末尾最小値を更新します。','疑似コード: tails=[]; 各cのlower_bound位置をcへ置換または末尾追加; N-len(tails)を出力。'),
'abc007_4':('B以下の禁止数からA未満の禁止数を引きます。','各桁で上限を既に下回ったか、4か9を使ったかを状態として数えます。','疑似コード: count(n)はdigit DP(桁,less,bad); 各0..9を遷移しbadへ4/9判定を追加; count(B)-count(A-1)を出力。'),
'abc008_4':('最初に使う装置が、残りの領域を4つの長方形へ分けます。','長方形の境界を状態にし、中にある装置を最初に使った場合の最大値をメモ化します。','疑似コード: solve(rect)=max装置{幅+高さ-1+4象限のsolve}; 装置なしなら0; 初期W×Hのsolveを出力。'),
'abc009_4':('XORを加算、ANDを乗算とみなすと線形漸化式です。','x^Kを係数Cで低次へ還元し、x^(M-1)を二乗法で求めます。ANDの単位元は全32ビットが1です。','疑似コード: polynomial multiplyをXOR/ANDで行いdegree>=KをCで還元; x^(M-1)をbinary power; 初期AとのANDをXORして出力。')}

TITLES={'abc004_4': 'マーブル', 'abc005_4': 'おいしいたこ焼きの焼き方', 'abc006_4': 'トランプ挿入ソート', 'abc007_4': '禁止された数字', 'abc008_4': '金塊ゲーム', 'abc009_4': '漸化式'}
PUBLISHED_SAMPLES={'abc004_4': [{'input': '2 3 4\n', 'expected': '7\n'}, {'input': '17 2 34\n', 'expected': '362\n'}, {'input': '267 294 165\n', 'expected': '88577\n'}], 'abc005_4': [{'input': '3\n3 2 1\n2 2 1\n1 1 1\n3\n1\n4\n9\n', 'expected': '3\n9\n14\n'}, {'input': '3\n1 1 1\n1 1 1\n9 9 9\n1\n4\n', 'expected': '27\n'}], 'abc006_4': [{'input': '6\n1\n3\n5\n2\n4\n6\n', 'expected': '2\n'}, {'input': '5\n5\n4\n3\n2\n1\n', 'expected': '4\n'}, {'input': '7\n1\n2\n3\n4\n5\n6\n7\n', 'expected': '0\n'}], 'abc007_4': [{'input': '1 9\n', 'expected': '2\n'}, {'input': '40 49\n', 'expected': '10\n'}, {'input': '1 1000\n', 'expected': '488\n'}, {'input': '1 1000000000000000000\n', 'expected': '981985601490518016\n'}], 'abc008_4': [{'input': '6 4\n3\n2 4\n3 1\n4 3\n', 'expected': '19\n'}, {'input': '3 3\n3\n1 1\n2 3\n3 2\n', 'expected': '9\n'}, {'input': '15 10\n8\n7 10\n12 8\n4 4\n5 7\n9 9\n1 6\n6 5\n3 2\n', 'expected': '112\n'}], 'abc009_4': [{'input': '3 5\n10 20 30\n7 19 13\n', 'expected': '16\n'}, {'input': '5 100\n2345678901 1001001001 3333333333 3141592653 1234567890\n2147483648 2147483647 4294967295 4294967294 3434343434\n', 'expected': '1067078691\n'}, {'input': '30 999999999\n11627 5078 8394 6412 10346 3086 3933 668 9879 11739 4501 6108 12336 8771 2768 2438 2153 7047 5476 313 1264 369 12070 10743 10663 747 370 4671 5235 3439\n114 3613 3271 5032 11241 6961 3628 150 12191 2396 7638 3046 11594 8162 11136 786 9878 2356 11660 1070 3649 10882 9746 1415 3307 7077 9319 9981 3437 544\n', 'expected': '2148\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
