"""Private terminal D473..476 plus official ABC476 A/B mixed batch."""
from __future__ import annotations
from bisect import bisect_right
from functools import lru_cache
from typing import cast
import random,re
TASKS=('abc473_d','abc474_d','abc475_d','abc476_d','abc476_a','abc476_b')
CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:p.split('_')[1].upper() for p in TASKS};PROBLEM_INDICES=PROBLEM_INDEXES
OUTPUT_MODES={'abc474_d':'semantic','abc475_d':'semantic'};CHECKER_IDS={p:p for p in OUTPUT_MODES}
Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integer fields');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'field count');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
@lru_cache(maxsize=32)
def coefficient_count(n:int,k:int)->int:
 if k<0:return 0
 if n==1:return 1
 if n==2:return k//2+1
 dp=[0]*(k+1);dp[0]=1
 for coefficient in range(1,n+1):
  for value in range(coefficient,k+1):dp[value]=min(300001,dp[value]+dp[value-coefficient])
 return dp[k]
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc473_d':
  require(len(r)==1,'rows');n,k=ints(r[0],2);require(1<=n<=10 and 1<=k<=200000 and coefficient_count(n,k)<=300000,'N/K/solution count');return n,k
 if pid=='abc474_d':
  require(len(r)==3,'rows');n=ints(r[0],1)[0];a=ints(r[1],n);b=ints(r[2],n);require(1<=n<=100000 and all(1<=v<=10**9 for v in a+b),'N/A/B');return a,b
 if pid=='abc475_d':
  require(len(r)==1 and re.fullmatch('[a-z]{1,7}',r[0]) is not None,'S');return (r[0],)
 if pid=='abc476_a':
  require(len(r)==1 and re.fullmatch('[a-z]{1,10}',r[0]) is not None,'S');return (r[0],)
 if pid=='abc476_b':
  require(len(r)==3,'rows');n=ints(r[0],1)[0];require(1<=n<=100 and re.fullmatch('[a-z]{'+str(n)+'}',r[1]) is not None and re.fullmatch('[a-z*]{'+str(n)+'}',r[2]) is not None,'N/S/T');return r[1],r[2]
 require(len(r)==4,'rows');n,m,k=ints(r[0],3);x,y=ints(r[1],2);a=ints(r[2],n);b=ints(r[3],m);require(1<=n<=200000 and 1<=m<=200000 and 2<=k<=10**9 and 0<=x<=10**15 and 0<=y<=10**9 and all(1<=v<=10**9 for v in a+b),'N/M/K/X/Y/prices');return k,x,y,a,b

def coefficient_partition_successors(n:int,k:int)->str:
 # Descending integer partitions with parts<=N, stored by multiplicity;
 # split the least non-unit part with all unit parts, then lex-sort vectors.
 a=[0]*(n+1);remaining=k
 for i in range(n,0,-1):a[i],remaining=divmod(remaining,i)
 rows=[]
 while True:
  rows.append(tuple(a[1:]));part=next((i for i in range(2,n+1) if a[i]),0)
  if not part:break
  amount=a[1]+part;a[1]=0;a[part]-=1
  for i in range(part-1,0,-1):a[i],amount=divmod(amount,i)
 rows.sort();return ''.join(line(row) for row in rows)

def outweigh_balanced_weights(a:tuple[int,...],b:tuple[int,...])->list[int]|None:
 differences=[x-y for x,y in zip(a,b)];maximum=max(differences)
 if maximum<=0:return None
 index=differences.index(maximum);other=sum(differences)-maximum;weight=max(1,(-other)//maximum+1);answer=[1]*len(a);answer[index]=weight;return answer

def equality_pattern(s:str)->tuple[int,...]:
 assigned:dict[str,int]={};pattern=[]
 for char in s:
  if char not in assigned:assigned[char]=len(assigned)
  pattern.append(assigned[char])
 return tuple(pattern)
@lru_cache(maxsize=1)
def prime_pattern_table()->dict[tuple[int,...],int]:
 # Exhaust all primes in the complete official numeric domain once.
 limit=10000000;prime=bytearray(b'\x01')*limit;prime[0:2]=b'\x00\x00'
 for p in range(2,3163):
  if prime[p]:prime[p*p:limit:p]=b'\x00'*((limit-1-p*p)//p+1)
 table:dict[tuple[int,...],int]={}
 for value in range(2,limit):
  if prime[value]:table.setdefault(equality_pattern(str(value)),value)
 return table
def is_prime_trial(value:int)->bool:
 if value<2:return False
 if value%2==0:return value==2
 divisor=3
 while divisor*divisor<=value:
  if value%divisor==0:return False
  divisor+=2
 return True
def bounded_integer(token:str,digits:int)->int|None:
 if re.fullmatch(r'[+-]?[0-9]+',token) is None:return None
 negative=token.startswith('-');significant=token.lstrip('+-').lstrip('0')
 if len(significant)>digits:return None
 value=int(significant or '0');return -value if negative else value

def automat_convex_split(k:int,x:int,y:int,a:tuple[int,...],b:tuple[int,...])->int:
 aa=sorted(a);bb=sorted(b);pa=[0];pb=[0];notes=[0]
 for value in aa:pa.append(pa[-1]+value)
 for value in bb:pb.append(pb[-1]+value);notes.append(notes[-1]+(value+k-1)//k)
 drink_limit=bisect_right(notes,y)-1;budget=x+k*y;n=len(a);m=len(b)
 def feasible(total:int)->bool:
  low=max(0,total-n);high=min(total,m,drink_limit)
  if low>high:return False
  # C(q)=prefixB[q]+prefixA[total-q] is discrete convex: its forward
  # difference B[q]-A[total-q-1] is nondecreasing on the legal split range.
  while low<high:
   mid=(low+high)//2
   if bb[mid]<aa[total-mid-1]:low=mid+1
   else:high=mid
  return pb[low]+pa[total-low]<=budget
 low=0;high=n+m+1
 while high-low>1:
  mid=(low+high)//2
  if feasible(mid):low=mid
  else:high=mid
 return low

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc473_d':return coefficient_partition_successors(*cast(tuple[int,int],d))
 if pid=='abc474_d':
  answer=outweigh_balanced_weights(*cast(tuple[tuple[int,...],tuple[int,...]],d));return 'No\n' if answer is None else 'Yes\n'+line(answer)
 if pid=='abc475_d':return str(prime_pattern_table().get(equality_pattern(cast(str,d[0])),-1))+'\n'
 if pid=='abc476_a':
  s=cast(str,d[0]);answer=list(s)
  if answer[-1]!='e':answer.append('e')
  answer.append('r');return ''.join(answer)+'\n'
 if pid=='abc476_b':
  s,t=cast(tuple[str,str],d);pattern=t.replace('*','[a-z]');return ('Yes' if re.fullmatch(pattern,s) is not None else 'No')+'\n'
 return str(automat_convex_split(*cast(tuple[int,int,int,tuple[int,...],tuple[int,...]],d)))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw);body=actual.removesuffix('\n')
  if pid=='abc474_d':
   a,b=cast(tuple[tuple[int,...],tuple[int,...]],d)
   if body=='No':return all(x<=y for x,y in zip(a,b))
   rows=body.split('\n')
   if len(rows)!=2 or rows[0]!='Yes':return False
   tokens=rows[1].split(' ')
   if len(tokens)!=len(a):return False
   parsed=[bounded_integer(token,19) for token in tokens]
   if any(v is None or not 1<=v<=10**18 for v in parsed):return False
   return sum((x-y)*cast(int,v) for x,y,v in zip(a,b,parsed))>0
  if pid=='abc475_d':
   value=bounded_integer(body,7)
   if value is None:return False
   s=cast(str,d[0])
   if value==-1:return equality_pattern(s) not in prime_pattern_table()
   return 2<=value<10000000 and equality_pattern(str(value))==equality_pattern(s) and is_prime_trial(value)
  return body==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

def generate(pid:str)->list[Case]:
 rng=random.Random(sum(map(ord,pid)));raws:list[str]=[]
 if pid=='abc473_d':raws=[line(v) for v in [(1,1),(1,2),(2,1),(2,2),(3,1),(3,8),(8,9),(10,1),(2,9),(4,10),(5,15),(6,20),(7,25),(8,30),(3,1894),(1,200000),(2,200000),(10,64)]]
 elif pid=='abc474_d':
  def weights(a:list[int],b:list[int])->str:return str(len(a))+'\n'+line(a)+line(b)
  raws=[weights([1],[1]),weights([1],[2]),weights([2],[1]),weights([10**9],[1]),weights([1],[10**9]),weights([4,7,4],[5,5,5]),weights([2,1],[1,10**9]),weights([1,2],[10**9,1])]
  while len(raws)<16:
   n=rng.randint(1,25);raw=weights([rng.randint(1,30) for _ in range(n)],[rng.randint(1,30) for _ in range(n)])
   if raw not in raws:raws.append(raw)
  raws+=[weights([2]+[1]*99999,[1]+[10**9]*99999),weights([10**9]*100000,[10**9]*100000)]
 elif pid=='abc475_d':raws=[s+'\n' for s in ['a','aa','ab','aaa','abc','aba','abab','byebye','motor','coconut','abcdefg','aaaaaaa','abababa','abccbaa','abcabca','aaabcde','zzzzzyx','zyxwvut']]
 elif pid=='abc476_a':raws=[s+'\n' for s in ['a','e','z','r','ee','ae','ea','live','femur','chimpanzee','abc','xyz','apple','atcoder','eeee','eeeeeeeee','abcdefghie','zzzzzzzzzz']]
 elif pid=='abc476_b':
  def wildcard(s:str,t:str)->str:return str(len(s))+'\n'+s+'\n'+t+'\n'
  raws=[wildcard('a','a'),wildcard('a','*'),wildcard('a','b'),wildcard('z','z'),wildcard('z','*'),wildcard('ab','a*'),wildcard('ab','*a'),wildcard('chokudai','**o*u*ai')]
  while len(raws)<16:
   n=rng.randint(2,40);s=''.join(rng.choice('abc') for _ in range(n));t=''.join(rng.choice('abc*') for _ in range(n));raw=wildcard(s,t)
   if raw not in raws:raws.append(raw)
  raws+=[wildcard('a'*100,'*'*100),wildcard('z'*100,'z'*99+'a')]
 else:
  def machine(k:int,x:int,y:int,a:list[int],b:list[int])->str:return line([len(a),len(b),k])+line([x,y])+line(a)+line(b)
  raws=[machine(2,0,0,[1],[1]),machine(2,1,0,[1],[1]),machine(2,0,1,[1],[1]),machine(3,0,1,[2],[1]),machine(10,0,1,[9],[1]),machine(10,0,1,[1],[9]),machine(10,0,2,[9,9],[1,1]),machine(10,50,6,[22,30],[20,12,24])]
  while len(raws)<16:
   raw=machine(rng.randint(2,20),rng.randint(0,100),rng.randint(0,20),[rng.randint(1,60) for _ in range(rng.randint(1,20))],[rng.randint(1,60) for _ in range(rng.randint(1,20))])
   if raw not in raws:raws.append(raw)
  raws+=[machine(10**9,0,199999,[10**9]*200000,[1]*200000),machine(10**9,10**15,10**9,[10**9]*200000,[10**9]*200000)]
 require(len(raws)==len(set(raws))==18,'18 distinct')
 return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 else 'deterministic_varied' if i<16 else 'large_scale'} for i,raw in enumerate(raws)]

REFERENCE_CODE:dict[str,str]={
'abc473_d':'''import sys
n,k=map(int,input().split());a=[0]*n;out=[]
def visit(index,remaining):
 coefficient=index+1
 if coefficient==n:
  if remaining%n==0:a[index]=remaining//n;out.append(' '.join(map(str,a)))
  return
 for value in range(remaining//coefficient+1):a[index]=value;visit(index+1,remaining-coefficient*value)
visit(0,k)
sys.stdout.write('\\n'.join(out)+'\\n')
''',
'abc474_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a=[next(it) for _ in range(n)];b=list(it);index=next((i for i in range(n) if a[i]>b[i]),-1)
if index<0:print('No')
else:
 answer=[1]*n;answer[index]=10**18;print('Yes');print(*answer)
''',
'abc475_d':'''import sys
from itertools import permutations
s=input();letters=list(dict.fromkeys(s));positions=[letters.index(c) for c in s]
def prime(value):
 if value<2:return False
 if value%2==0:return value==2
 d=3
 while d*d<=value:
  if value%d==0:return False
  d+=2
 return True
answer=-1
for assignment in permutations(range(10),len(letters)):
 if assignment[0]==0:continue
 value=0
 for index in positions:value=value*10+assignment[index]
 if prime(value):answer=value;break
print(answer)
''',
'abc476_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);k=next(it);x=next(it);y=next(it);a=sorted(next(it) for _ in range(n));b=sorted(it);budget=x+k*y;prefix=[0]
for value in a:prefix.append(prefix[-1]+value)
desserts=n
while desserts and prefix[desserts]>budget:desserts-=1
answer=desserts;spent=notes=0
for number,value in enumerate(b,1):
 spent+=value;notes+=(value+k-1)//k
 if notes>y:break
 while desserts and prefix[desserts]+spent>budget:desserts-=1
 answer=max(answer,number+desserts)
print(answer)
''',
'abc476_a':"s=input();print(s+('r' if s[-1]=='e' else 'er'))\n",
'abc476_b':"n=int(input());s=input();t=input();print('Yes' if all(x==y or y=='*' for x,y in zip(s,t)) else 'No')\n"}
HINTS:dict[str,tuple[str,str,str]]={
'abc473_d':('先頭の要素から小さい値を順に選ぶと、辞書順で列挙できます。使った重みをKから引きましょう。','i番目は0から残り//iまでを順に試します。最後の要素は残りがNで割り切れる場合に一意に決まります。','疑似コード: dfs(i,rem)。i==Nならrem%N==0のときA_N=rem//Nとして出力。それ以外はa=0..rem//iの昇順でA_i=a、dfs(i+1,rem-i*a)。dfs(1,K)から開始。'),
'abc474_d':('A_i>B_iとなる種類がなければ、どの正の重みでも高橋君は上回れません。','一つでも多く持つ種類があれば、その種類の重みだけ10^18にして、他を1にします。他の種類の差の総和は絶対値10^14未満です。','疑似コード: A_i>B_iとなる最初のiを探す。なければNo。あればWを全1で初期化しW_i=10^18、YesとWを出力。'),
'abc475_d':('同じ文字には同じ数字、異なる文字には異なる数字を対応させます。使う文字は最大7種類です。','各文字への異なる数字の割り当てを列挙します。先頭0を除外して整数を作り、試し割りで素数か調べます。','疑似コード: letters=登場順の異なる文字。0..9の長さ|letters|の順列を列挙し、先頭文字の数字0なら除外。Sの各位置から整数pを作り、2と奇数sqrt(p)までで割り切れないか検査。素数ならpを出力して終了、見つからなければ-1。'),
'abc476_d':('ドリンクの購入はKドル紙幣を消費し、釣りを1ドル紙幣へ変えます。先にドリンク、後にデザートを買う形で考えられます。','両種類を価格順に並べます。ドリンクを安い順に増やし、ceil(B_j/K)の累計がY以内の範囲で、残る全金額から買えるデザート数を減らします。','疑似コード: A,Bをsort、prefixAを作る、V=X+K*Y。d=Vで買える最大デザート数。Bを順に追加してspent+=B、notes+=ceil(B/K)。notes>Yなら終了。prefixA[d]+spent>Vの間d--。最大(d+追加ドリンク数)を出力。'),
'abc476_a':('末尾の文字を一つ確認しましょう。','末尾がeならr、それ以外ならerをそのまま付けます。','疑似コード: Sを読む。S[-1]==eならS+r、それ以外ならS+erを出力。'),
'abc476_b':('同じ位置の文字を照合しましょう。*は任意の英小文字に置き換えられます。','すべての位置でT_iが*か、S_iと同じ文字ならマッチします。一つでも違う固定文字があれば不一致です。','疑似コード: N,S,Tを読む。ok=true。各iでT_i!=*かつT_i!=S_iならok=false。okならYes、そうでなければNoを出力。')}

TITLES={'abc473_d': 'Coefficient Stair', 'abc474_d': 'Outweigh', 'abc475_d': 'Alphametic Prime', 'abc476_d': 'Automat', 'abc476_a': 'Appender', 'abc476_b': 'Wild Card'}
PUBLISHED_SAMPLES={'abc473_d': [{'input': '3 8\n', 'expected': '0 1 2\n0 4 0\n1 2 1\n2 0 2\n2 3 0\n3 1 1\n4 2 0\n5 0 1\n6 1 0\n8 0 0\n'}, {'input': '1 200000\n', 'expected': '200000\n'}, {'input': '8 9\n', 'expected': '0 0 0 1 1 0 0 0\n0 0 1 0 0 1 0 0\n0 0 3 0 0 0 0 0\n0 1 0 0 0 0 1 0\n0 1 1 1 0 0 0 0\n0 2 0 0 1 0 0 0\n0 3 1 0 0 0 0 0\n1 0 0 0 0 0 0 1\n1 0 0 2 0 0 0 0\n1 0 1 0 1 0 0 0\n1 1 0 0 0 1 0 0\n1 1 2 0 0 0 0 0\n1 2 0 1 0 0 0 0\n1 4 0 0 0 0 0 0\n2 0 0 0 0 0 1 0\n2 0 1 1 0 0 0 0\n2 1 0 0 1 0 0 0\n2 2 1 0 0 0 0 0\n3 0 0 0 0 1 0 0\n3 0 2 0 0 0 0 0\n3 1 0 1 0 0 0 0\n3 3 0 0 0 0 0 0\n4 0 0 0 1 0 0 0\n4 1 1 0 0 0 0 0\n5 0 0 1 0 0 0 0\n5 2 0 0 0 0 0 0\n6 0 1 0 0 0 0 0\n7 1 0 0 0 0 0 0\n9 0 0 0 0 0 0 0\n'}], 'abc474_d': [{'input': '3\n4 7 4\n5 5 5\n', 'expected': 'Yes\n4 7 4\n'}, {'input': '3\n3 3 3\n4 7 4\n', 'expected': 'No\n'}, {'input': '1\n2\n2\n', 'expected': 'No\n'}], 'abc475_d': [{'input': 'motor\n', 'expected': '10607\n'}, {'input': 'byebye\n', 'expected': '-1\n'}, {'input': 'coconut\n', 'expected': '1010237\n'}], 'abc476_d': [{'input': '2 3 10\n50 6\n22 30\n20 12 24\n', 'expected': '4\n'}, {'input': '1 7 67\n677677677766666 0\n777666777\n20 12 24 67 67 67 67\n', 'expected': '1\n'}, {'input': '20 20 30\n605776135 133105105\n97363214 218434035 697895427 109255624 299037330 227873982 195540071 411713803 828357845 244535208 138059186 639510883 39844882 707397687 371274487 696536603 351588202 319490007 47121612 87169661\n32256972 567982330 554885983 299718223 443859449 687952877 264684780 666659381 576335424 941894234 406248934 321334900 423472560 863738035 213143887 384834384 468161291 673106162 164648316 15903323\n', 'expected': '22\n'}], 'abc476_a': [{'input': 'live\n', 'expected': 'liver\n'}, {'input': 'femur\n', 'expected': 'femurer\n'}, {'input': 'chimpanzee\n', 'expected': 'chimpanzeer\n'}], 'abc476_b': [{'input': '8\nchokudai\n**o*u*ai\n', 'expected': 'Yes\n'}, {'input': '5\nsnuke\nsnake\n', 'expected': 'No\n'}, {'input': '5\nyiwiy\n*****\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={p:len(v) for p,v in PUBLISHED_SAMPLES.items()}
