from __future__ import annotations
from collections import Counter,defaultdict
from bisect import bisect_left,bisect_right
from decimal import Decimal,localcontext,DecimalException
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(277,283));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc279_d':'numeric_tolerance_1e-6'};CHECKER_IDS:dict[str,str]={}
Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc277_d':
  n,m=ints(r[0],2);require(1<=n<=200000 and 2<=m<=10**9 and len(r)==2,'shape');a=ints(r[1],n);require(all(0<=x<m for x in a),'Ai');return m,a
 if pid=='abc278_d':
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)>=4,'N');a=ints(r[1],n);require(all(0<=x<=10**9 for x in a),'Ai');q=ints(r[2],1)[0];require(1<=q<=200000 and len(r)==q+3,'Q');queries=tuple(ints(row) for row in r[3:])
  for row in queries:
   require(row[0] in (1,2,3) and len(row)==(3 if row[0]==2 else 2),'query')
   if row[0]==1:require(0<=row[1]<=10**9,'x')
   else:
    require(1<=row[1]<=n,'index')
    if row[0]==2:require(0<=row[2]<=10**9,'x')
  require(any(row[0]==3 for row in queries),'query3 exists');return a,queries
 if pid=='abc279_d':
  require(len(r)==1,'rows');a,b=ints(r[0],2);require(1<=a<=10**18 and 1<=b<=10**18,'A/B');return a,b
 if pid=='abc280_d':
  require(len(r)==1,'rows');k=ints(r[0],1)[0];require(2<=k<=10**12,'K');return (k,)
 if pid=='abc281_d':
  n,k,d=ints(r[0],3);require(1<=k<=n<=100 and 1<=d<=100 and len(r)==2,'shape');a=ints(r[1],n);require(all(0<=v<=10**9 for v in a),'Ai');return k,d,a
 n,m=ints(r[0],2);require(2<=n<=200000 and 0<=m<=min(200000,n*(n-1)//2) and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in edges) and len({tuple(sorted(e)) for e in edges})==m,'simple graph');return n,edges

def cards_components(m:int,a:tuple[int,...])->int:
 counts=Counter(a);parent={x:x for x in counts};weights={x:x*c for x,c in counts.items()}
 def root(x:int)->int:
  while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
  return x
 for x in counts:
  y=(x+1)%m
  if y not in counts:continue
  u,v=root(x),root(y)
  if u!=v:parent[u]=v;weights[v]+=weights[u]
 return sum(a)-max(weights[x] for x in parent if parent[x]==x)

def offline_assign_history(a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 assignments=[(-1,0)];times:dict[int,list[int]]=defaultdict(list);sums:dict[int,list[int]]=defaultdict(lambda:[0]);out=[]
 for t,row in enumerate(queries):
  if row[0]==1:assignments.append((t,row[1]))
  elif row[0]==2:times[row[1]].append(t);sums[row[1]].append(sums[row[1]][-1]+row[2])
  else:
   at,base=assignments[-1];index=row[1];cut=bisect_right(times[index],at);out.append((base if at>=0 else a[index-1])+sums[index][-1]-sums[index][cut])
 return out

def freefall_decimal(a:int,b:int)->Decimal:
 # The continuous derivative changes sign at 4*B^2*g^3=A^2.
 low,high=1,a
 while low<high:
  mid=(low+high)//2
  if 4*b*b*mid**3>=a*a:high=mid
  else:low=mid+1
 with localcontext() as context:
  context.prec=90
  return min(Decimal(b)*(g-1)+Decimal(a)/Decimal(g).sqrt() for g in (max(1,low-1),low))

def factorial_event_threshold(k:int)->int:
 p=2;factors=[]
 while p*p<=k:
  e=0
  while k%p==0:k//=p;e+=1
  if e:factors.append((p,e))
  p+=1 if p==2 else 2
 if k>1:factors.append((k,1))
 answer=1
 for p,e in factors:
  # Visit only successive multiples of p until their factorial valuation suffices.
  multiple=valuation=0
  while valuation<e:
   multiple+=p;x=multiple
   while x%p==0:valuation+=1;x//=p
  answer=max(answer,multiple)
 return answer

def residue_group_selection(k:int,d:int,a:tuple[int,...])->int:
 groups:dict[int,list[int]]=defaultdict(list)
 for value in a:groups[value%d].append(value)
 states={(0,0):0}
 for residue,values in groups.items():
  values.sort(reverse=True);prefix=[0]
  for value in values[:k]:prefix.append(prefix[-1]+value)
  updated={}
  for (selected,rem),score in states.items():
   for count in range(min(len(prefix)-1,k-selected)+1):
    key=(selected+count,(rem+residue*count)%d);updated[key]=max(updated.get(key,-1),score+prefix[count])
  states=updated
 return states.get((k,0),-1)

def parity_components(n:int,edges:tuple[tuple[int,int],...])->int:
 parent=list(range(n));size=[1]*n;parity=[0]*n
 def root(x:int)->tuple[int,int]:
  if parent[x]==x:return x,0
  r,p=root(parent[x]);parity[x]^=p;parent[x]=r;return r,parity[x]
 for u,v in edges:
  x,px=root(u-1);y,py=root(v-1)
  if x==y:
   if px==py:return 0
  else:
   if size[x]>size[y]:x,y=y,x
   parent[x]=y;parity[x]=px^py^1;size[y]+=size[x]
 counts:dict[int,list[int]]=defaultdict(lambda:[0,0])
 for v in range(n):r,p=root(v);counts[r][p]+=1
 return n*(n-1)//2-len(edges)-sum(x*(x-1)//2+y*(y-1)//2 for x,y in counts.values())

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc277_d':return str(cards_components(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc278_d':return ''.join(str(x)+'\n' for x in offline_assign_history(cast(tuple[int,...],d[0]),cast(tuple[tuple[int,...],...],d[1])))
 if pid=='abc279_d':return str(freefall_decimal(cast(int,d[0]),cast(int,d[1])))+'\n'
 if pid=='abc280_d':return str(factorial_event_threshold(cast(int,d[0])))+'\n'
 if pid=='abc281_d':return str(residue_group_selection(cast(int,d[0]),cast(int,d[1]),cast(tuple[int,...],d[2])))+'\n'
 return str(parity_components(cast(int,d[0]),cast(tuple[tuple[int,int],...],d[1])))+'\n'

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  validate(pid,raw);expected=oracle(pid,raw)
  if pid=='abc279_d':
   tokens=actual.split()
   if len(tokens)!=1 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',tokens[0]) is None:return False
   with localcontext() as context:
    context.prec=100;x=Decimal(tokens[0]);want=Decimal(expected.strip());return x.is_finite() and abs(x-want)<=Decimal('1e-6')*max(Decimal(1),abs(want))
  return actual.split()==expected.split() and all(re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s) is not None for s in actual.split())
 except (ValueError,TypeError,IndexError,OverflowError,DecimalException):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc277_d':'''import sys
n,m=map(int,input().split());a=sorted(map(int,input().split()));total=sum(a);runs=[];score=a[0]
for x,y in zip(a,a[1:]):
 if y==x or y==x+1:score+=y
 else:runs.append(score);score=y
runs.append(score)
if len(runs)>1 and a[0]==0 and a[-1]==m-1:runs[0]+=runs.pop()
print(total-max(runs))
''',
'abc278_d':'''import sys
n=int(input());a=list(map(int,input().split()));epoch=0;tag=[0]*n;base=0;out=[]
for _ in range(int(input())):
 row=list(map(int,input().split()))
 if row[0]==1:base=row[1];epoch+=1
 else:
  i=row[1]-1
  if tag[i]!=epoch:a[i]=0;tag[i]=epoch
  if row[0]==2:a[i]+=row[2]
  else:out.append(str(base+a[i]))
print('\\n'.join(out))
''',
'abc279_d':'''import math
a,b=map(int,input().split())
def f(x):return b*x+a/math.sqrt(x+1)
l,r=0,a//b+1
while r-l>8:
 x=l+(r-l)//3;y=r-(r-l)//3
 if f(x)<=f(y):r=y
 else:l=x
print(min(f(x) for x in range(l,r+1)))
''',
'abc280_d':'''k=int(input());factors=[];p=2
while p*p<=k:
 e=0
 while k%p==0:k//=p;e+=1
 if e:factors.append((p,e))
 p+=1
if k>1:factors.append((k,1))
def enough(n):
 for p,e in factors:
  v=0;q=n
  while q:q//=p;v+=q
  if v<e:return False
 return True
l=0;r=max(p*e for p,e in factors)
while r-l>1:
 m=(l+r)//2
 if enough(m):r=m
 else:l=m
print(r)
''',
'abc281_d':'''n,k,d=map(int,input().split());a=list(map(int,input().split()));dp=[[-1]*d for _ in range(k+1)];dp[0][0]=0
for x in a:
 for j in range(k,0,-1):
  for r in range(d):
   if dp[j-1][r]>=0:t=(r+x)%d;dp[j][t]=max(dp[j][t],dp[j-1][r]+x)
print(dp[k][0])
''',
'abc282_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);graph=[[] for _ in range(n)]
for _ in range(m):u=next(it)-1;v=next(it)-1;graph[u].append(v);graph[v].append(u)
color=[-1]*n;answer=n*(n-1)//2-m
for start in range(n):
 if color[start]>=0:continue
 color[start]=0;counts=[1,0];queue=[start]
 for u in queue:
  for v in graph[u]:
   if color[v]<0:color[v]=color[u]^1;counts[color[v]]+=1;queue.append(v)
   elif color[v]==color[u]:print(0);sys.exit()
 answer-=sum(x*(x-1)//2 for x in counts)
print(answer)
'''}

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(194000+int(pid[3:6]));raws=[]
 if pid=='abc277_d':
  def cards(m:int,a:list[int])->str:return line((len(a),m))+line(a)
  raws=[cards(2,[0]),cards(2,[1]),cards(10,[0,9,9,3,4]),cards(4,[0,1,2,3])]
  for j in range(12):m=rng.randrange(2,100);raws.append(cards(m,[rng.randrange(m) for _ in range(j+3)]))
  raws.append(cards(10**9,[0,10**9-1]*100000));raws.append(cards(10**9,[10**9-1]*200000))
 elif pid=='abc278_d':
  def array(a:list[int],q:list[tuple[int,...]])->str:return str(len(a))+'\n'+line(a)+str(len(q))+'\n'+''.join(line(r) for r in q)
  raws=[array([0],[(3,1)]),array([10**9],[(2,1,10**9)]*7+[(3,1)]),array([1,2],[(3,2),(1,0),(2,1,7),(3,1),(3,2)]),array([5],[(1,1),(1,2),(3,1)])]
  for j in range(12):
   n=j+2;q=[]
   for _ in range(3+j*5):
    mode=rng.randrange(1,4);q.append((1,rng.randrange(10**9+1)) if mode==1 else (2,rng.randrange(1,n+1),rng.randrange(10**9+1)) if mode==2 else (3,rng.randrange(1,n+1)))
   q.append((3,n));raws.append(array([rng.randrange(10**9+1) for _ in range(n)],q))
  raws.append(array([10**9]*200000,[(2,200000,10**9)]*199999+[(3,200000)]));raws.append(array([10**9]*200000,[(3,i+1) for i in range(200000)]))
 elif pid=='abc279_d':
  pairs=[(1,1),(10,1),(5,10),(10**18,1),(1,10**18),(10**18,100),(2,1),(3,1)]
  pairs.extend((rng.randrange(1,10**18+1),rng.randrange(1,10**18+1)) for _ in range(8));pairs.extend(((10**18-1,1),(10**18,10**18)));raws=[line(pair) for pair in pairs]
 elif pid=='abc280_d':
  ks=[2,3,4,6,30,280,123456789011,2**39,3**25,999983**2,9999999967]
  ks.extend(rng.randrange(2,10**12+1) for _ in range(5));ks.extend((999999999989,10**12));raws=[str(k)+'\n' for k in ks]
 elif pid=='abc281_d':
  def array(k:int,d:int,a:list[int])->str:return line((len(a),k,d))+line(a)
  raws=[array(1,1,[0]),array(1,2,[1]),array(1,1,[10**9]),array(2,2,[1,2,3,4])]
  for j in range(12):n=j+3;raws.append(array(rng.randrange(1,n+1),rng.randrange(1,101),[rng.randrange(10**9+1) for _ in range(n)]))
  raws.append(array(50,100,[10**9-((j*37)%100) for j in range(100)]));raws.append(array(100,100,[10**9]*100))
 else:
  def graph(n:int,e:list[tuple[int,int]])->str:return line((n,len(e)))+''.join(line(edge) for edge in e)
  raws=[graph(2,[]),graph(2,[(1,2)]),graph(3,[(1,2),(2,3),(3,1)]),graph(4,[(1,2),(3,4)])]
  for j in range(12):n=j+3;edges=[(u,v) for u in range(1,n+1) for v in range(u+1,n+1) if rng.randrange(4)==0];raws.append(graph(n,edges))
  raws.append(graph(200000,[(i,i+1) for i in range(1,200000)]+[(200000,1)]));raws.append(graph(200000,[(1,i) for i in range(2,200001)]+[(2,3)]))
 require(len(raws)==len(set(raws))==18,'18 distinct');cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02d}'})
 return cases

HINTS={
'abc277_d':('同じ数と、その次の数のカードは続けて取り出せます。数の存在する場所に注目しましょう。','ソートすると隣り合う同値または差1の数をまとめられます。0とM-1の両端も、円環の隣接として一つにまとめます。','疑似コード: Aをsortし同値/差1が続く区間のsumを作る。先頭0かつ末尾M-1なら最初と最後の区間sumを加える。全カードsum-max区間sumを出力。'),
'abc278_d':('全要素の代入を、個々の要素へ毎回反映する必要はありません。','全体の基準値と代入世代を保持します。各要素の加算値が古い世代なら、使う時に0へ戻してください。','疑似コード: base=0,epoch=0,tag[i]=0,delta[i]=A[i]。query1はbase=x,epoch++。query2/3はtag[i]!=epochならdelta[i]=0,tag[i]=epoch。query2はdelta[i]+=x、query3はbase+delta[i]。'),
'abc279_d':('操作回数をxとすると、総時間はB*x+A/sqrt(x+1)です。','この関数は下に凸なので、整数の範囲でも三分探索で最小値付近を探せます。何もしないAを超える操作時間の候補は不要です。','疑似コード: f(x)=B*x+A/sqrt(x+1),l=0,r=A//B+1。r-l>8の間、三分点u,vでf(u)<=f(v)ならr=v、そうでなければl=u。最後l..rの全整数で最小fを出力。'),
'abc280_d':('Kの各素因数が、階乗に必要な回数だけ含まれる条件を考えましょう。','素数pのN!内の指数はfloor(N/p)+floor(N/p^2)+…です。この指数が全ての必要数を満たすかはNについて単調です。','疑似コード: Kを素因数分解して(p,e)を集める。enough(N)は各pでq=Nを繰り返しq//=pし指数和>=eを確認。l=0,r=max(p*e)として二分探索し最小のenough(r)を出力。'),
'abc281_d':('選んだ個数と、和をDで割った余りを状態にします。','dp[j][r]をj個選び余りrとなる最大和とします。到達不能は-1とし、各要素で個数を降順に更新します。','疑似コード: dp[0][0]=0,他-1。各xでj=K..1、r=0..D-1を見てdp[j-1][r]>=0ならdp[j][(r+x)%D]=max(既存,dp[j-1][r]+x)。dp[K][0]を出力。'),
'abc282_d':('既存グラフが二部グラフかを確認し、各連結成分の二色の頂点数を数えましょう。','同一成分の同色どうしは辺を追加できません。異なる成分の組なら、片方の成分の色を反転して結べます。既存辺も除きます。','疑似コード: answer=N*(N-1)//2-M。未訪問頂点から二色BFSし同色辺があれば0を出力。成分内各色の数cでanswer-=c*(c-1)//2。全成分後answerを出力。')}

TITLES={'abc277_d': "Takahashi's Solitaire", 'abc278_d': 'All Assign Point Add', 'abc279_d': 'Freefall', 'abc280_d': 'Factorial and Multiple', 'abc281_d': 'Max Multiple', 'abc282_d': 'Make Bipartite 2'}
PUBLISHED_SAMPLES={'abc277_d': [{'input': '9 7\n3 0 2 5 5 3 0 6 3\n', 'expected': '11\n'}, {'input': '1 10\n4\n', 'expected': '0\n'}, {'input': '20 20\n18 16 15 9 8 8 17 1 3 17 11 9 12 11 7 3 2 14 3 12\n', 'expected': '99\n'}], 'abc278_d': [{'input': '5\n3 1 4 1 5\n6\n3 2\n2 3 4\n3 3\n1 1\n2 3 4\n3 3\n', 'expected': '1\n8\n5\n'}, {'input': '1\n1000000000\n8\n2 1 1000000000\n2 1 1000000000\n2 1 1000000000\n2 1 1000000000\n2 1 1000000000\n2 1 1000000000\n2 1 1000000000\n3 1\n', 'expected': '8000000000\n'}, {'input': '10\n1 8 4 15 7 5 7 5 8 0\n20\n2 7 0\n3 7\n3 8\n1 7\n3 3\n2 4 4\n2 4 9\n2 10 5\n1 10\n2 4 2\n1 10\n2 3 1\n2 8 11\n2 3 14\n2 1 9\n3 8\n3 8\n3 1\n2 6 5\n3 7\n', 'expected': '7\n5\n7\n21\n21\n19\n10\n'}], 'abc279_d': [{'input': '10 1\n', 'expected': '7.7735026919\n'}, {'input': '5 10\n', 'expected': '5.0000000000\n'}, {'input': '1000000000000000000 100\n', 'expected': '8772053214538.5976562500\n'}], 'abc280_d': [{'input': '30\n', 'expected': '5\n'}, {'input': '123456789011\n', 'expected': '123456789011\n'}, {'input': '280\n', 'expected': '7\n'}], 'abc281_d': [{'input': '4 2 2\n1 2 3 4\n', 'expected': '6\n'}, {'input': '3 1 2\n1 3 5\n', 'expected': '-1\n'}], 'abc282_d': [{'input': '5 4\n4 2\n3 1\n5 2\n3 2\n', 'expected': '2\n'}, {'input': '4 3\n3 1\n3 2\n1 2\n', 'expected': '0\n'}, {'input': '9 11\n4 9\n9 1\n8 2\n8 3\n9 2\n8 4\n6 7\n4 6\n7 5\n4 5\n7 8\n', 'expected': '9\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
