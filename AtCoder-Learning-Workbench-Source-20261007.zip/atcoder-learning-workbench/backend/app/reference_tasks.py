"""Independently authored, task-specific ABC reference test specifications.

These are NOT inferred from generic tags. Each supported problem has an exact
input validator and a deterministic generator. Source programs live in
backend/data/reference_solutions and are never sent to frontend by test-bank API.
"""
from __future__ import annotations

import random
from math import isqrt
from .reference_tasks_extra import EXTRA, validate as extra_validate, generate as extra_generate, independent_check as extra_independent_check
from .reference_tasks_batch2 import BATCH, validate as batch_validate, generate as batch_generate, independent_check as batch_independent_check
from .reference_tasks_batch3 import BATCH3, validate as batch3_validate, generate as batch3_generate, independent_check as batch3_independent_check
from .reference_tasks_batch4 import BATCH4, validate as batch4_validate, generate as batch4_generate, independent_check as batch4_independent_check
from .reference_tasks_batch5 import BATCH5, validate as batch5_validate, generate as batch5_generate, independent_check as batch5_independent_check
from .reference_tasks_batch6 import BATCH6, validate as batch6_validate, generate as batch6_generate, independent_check as batch6_independent_check
from .reference_tasks_batch7 import BATCH7, validate as batch7_validate, generate as batch7_generate, independent_check as batch7_independent_check
from .reference_tasks_batch8 import BATCH8, validate as batch8_validate, generate as batch8_generate, independent_check as batch8_independent_check
from .reference_tasks_batch9 import BATCH9, validate as batch9_validate, generate as batch9_generate, independent_check as batch9_independent_check
from .reference_tasks_batch10 import BATCH10, validate as batch10_validate, generate as batch10_generate, independent_check as batch10_independent_check
from .reference_tasks_batch11 import BATCH11, validate as batch11_validate, generate as batch11_generate, independent_check as batch11_independent_check
from .reference_tasks_batch12 import BATCH12, validate as batch12_validate, generate as batch12_generate, independent_check as batch12_independent_check
from .reference_tasks_batch13 import BATCH13, validate as batch13_validate, generate as batch13_generate, independent_check as batch13_independent_check
from .reference_tasks_batch14 import BATCH14, validate as batch14_validate, generate as batch14_generate, independent_check as batch14_independent_check
from .reference_tasks_batch15 import BATCH15, validate as batch15_validate, generate as batch15_generate, independent_check as batch15_independent_check
from .reference_tasks_batch16 import BATCH16, validate as batch16_validate, generate as batch16_generate, independent_check as batch16_independent_check
from .reference_tasks_batch17 import BATCH17, validate as batch17_validate, generate as batch17_generate, independent_check as batch17_independent_check
from .reference_tasks_batch18 import BATCH18, validate as batch18_validate, generate as batch18_generate, independent_check as batch18_independent_check
from .reference_tasks_batch19 import BATCH19, validate as batch19_validate, generate as batch19_generate, independent_check as batch19_independent_check

SPECIAL: dict[str, dict] = {
    'abc133_c': {
        'sample_input':'2020 2040\n','sample_output':'2',
        'source_url':'https://atcoder.jp/contests/abc133/tasks/abc133_c',
        'constraints':'0 <= L < R <= 2000000000',
    },
    'abc161_c': {
        'sample_input':'7 4\n','sample_output':'1',
        'source_url':'https://atcoder.jp/contests/abc161/tasks/abc161_c',
        'constraints':'0 <= N <= 10**18; 1 <= K <= 10**18',
    },
    'abc171_c': {
        'sample_input':'27\n','sample_output':'aa',
        'source_url':'https://atcoder.jp/contests/abc171/tasks/abc171_c',
        'constraints':'1 <= N <= 1000000000000001',
    },
    'abc180_c': {
        'sample_input':'6\n','sample_output':'1\n2\n3\n6',
        'source_url':'https://atcoder.jp/contests/abc180/tasks/abc180_c',
        'constraints':'1 <= N <= 10**12',
    },
    'abc210_c': {
        'sample_input':'7 3\n1 2 1 2 3 3 1\n','sample_output':'3',
        'source_url':'https://atcoder.jp/contests/abc210/tasks/abc210_c',
        'constraints':'1 <= K <= N <= 300000; 1 <= c[i] <= 10**9',
    },
}
SPECIAL.update(EXTRA)
SPECIAL.update(BATCH)
SPECIAL.update(BATCH3)
SPECIAL.update(BATCH4)
SPECIAL.update(BATCH5)
SPECIAL.update(BATCH6)
SPECIAL.update(BATCH7)
SPECIAL.update(BATCH8)
SPECIAL.update(BATCH9)
SPECIAL.update(BATCH10)
SPECIAL.update(BATCH11)
SPECIAL.update(BATCH12)
SPECIAL.update(BATCH13)
SPECIAL.update(BATCH14)
SPECIAL.update(BATCH15)
SPECIAL.update(BATCH16)
SPECIAL.update(BATCH17)
SPECIAL.update(BATCH18)
SPECIAL.update(BATCH19)


def validate(pid: str, data: str) -> tuple[int, ...] | list[int]:
    """Fail closed on count, ranges, and every integer's lexical validity."""
    if pid in BATCH19: return batch19_validate(pid, data)
    if pid in BATCH18: return batch18_validate(pid, data)
    if pid in BATCH17: return batch17_validate(pid, data)
    if pid in BATCH16: return batch16_validate(pid, data)
    if pid in BATCH15: return batch15_validate(pid, data)
    if pid in BATCH14: return batch14_validate(pid, data)
    if pid in BATCH13: return batch13_validate(pid, data)
    if pid in BATCH12: return batch12_validate(pid, data)
    if pid in BATCH11: return batch11_validate(pid, data)
    if pid in BATCH10: return batch10_validate(pid, data)
    if pid in BATCH9: return batch9_validate(pid, data)
    if pid in BATCH8: return batch8_validate(pid, data)
    if pid in BATCH7: return batch7_validate(pid, data)
    if pid in BATCH6: return batch6_validate(pid, data)
    if pid in BATCH5: return batch5_validate(pid, data)
    if pid in BATCH4: return batch4_validate(pid, data)
    if pid in BATCH3: return batch3_validate(pid, data)
    if pid in BATCH: return batch_validate(pid, data)
    if pid in EXTRA: return extra_validate(pid, data)
    if pid not in SPECIAL:
        raise ValueError('未対応の問題ID')
    fields = data.split()
    if not fields or any(not s.isascii() or not s.isdecimal() for s in fields):
        raise ValueError('入力は指定された非負整数のみです')
    if pid == 'abc133_c':
        if len(fields) != 2: raise ValueError('L R の2値が必要です')
        l, r = map(int, fields)
        if not 0 <= l < r <= 2_000_000_000: raise ValueError('L R の範囲違反')
        return (l, r)
    if pid == 'abc161_c':
        if len(fields) != 2: raise ValueError('N K の2値が必要です')
        n, k = map(int, fields)
        if not 0 <= n <= 10**18 or not 1 <= k <= 10**18: raise ValueError('N K の範囲違反')
        return (n, k)
    if pid in ('abc171_c', 'abc180_c'):
        if len(fields) != 1: raise ValueError('N の1値が必要です')
        n = int(fields[0])
        limit = 1_000_000_000_000_001 if pid == 'abc171_c' else 10**12
        if not 1 <= n <= limit: raise ValueError('N の範囲違反')
        return (n,)
    if len(fields) < 3: raise ValueError('N K と色列が必要です')
    n, k = map(int, fields[:2])
    if not 1 <= k <= n <= 300000 or len(fields) != n + 2:
        raise ValueError('N K 又は色列の長さが不正')
    a = list(map(int, fields[2:]))
    if any(not 1 <= x <= 10**9 for x in a): raise ValueError('色番号の範囲違反')
    return [n, k, *a]


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str, str]]:
    """Typical/min/max/adjacent/extreme and seeded random valid cases."""
    if pid in BATCH19: return batch19_generate(pid, count, seed, include_large)
    if pid in BATCH18: return batch18_generate(pid, count, seed, include_large)
    if pid in BATCH17: return batch17_generate(pid, count, seed, include_large)
    if pid in BATCH16: return batch16_generate(pid, count, seed, include_large)
    if pid in BATCH15: return batch15_generate(pid, count, seed, include_large)
    if pid in BATCH14: return batch14_generate(pid, count, seed, include_large)
    if pid in BATCH13: return batch13_generate(pid, count, seed, include_large)
    if pid in BATCH12: return batch12_generate(pid, count, seed, include_large)
    if pid in BATCH11: return batch11_generate(pid, count, seed, include_large)
    if pid in BATCH10: return batch10_generate(pid, count, seed, include_large)
    if pid in BATCH9: return batch9_generate(pid, count, seed, include_large)
    if pid in BATCH8: return batch8_generate(pid, count, seed, include_large)
    if pid in BATCH7: return batch7_generate(pid, count, seed, include_large)
    if pid in BATCH6: return batch6_generate(pid, count, seed, include_large)
    if pid in BATCH5: return batch5_generate(pid, count, seed, include_large)
    if pid in BATCH4: return batch4_generate(pid, count, seed, include_large)
    if pid in BATCH3: return batch3_generate(pid, count, seed, include_large)
    if pid in BATCH: return batch_generate(pid, count, seed, include_large)
    if pid in EXTRA: return extra_generate(pid, count, seed, include_large)
    if pid not in SPECIAL or not 1 <= count <= 80:
        raise ValueError('問題ID又はケース数が不正')
    rnd = random.Random(seed)
    cases: list[dict[str, str]] = []
    def add(category: str, content: str) -> None:
        validate(pid, content)
        if content not in {c['input'] for c in cases}:
            cases.append({'category': category, 'input': content})

    if pid == 'abc133_c':
        for name,l,r in [('constraint_min',0,1), ('adjacent',4,5), ('usual',2020,2040),
                         ('mod_boundary',2018,2020), ('zero_window',2019,2020),
                         ('constraint_max',1999999999,2000000000),
                         ('wide_max',0,2000000000), ('large_offset',1999997000,2000000000)]:
            add(name, f'{l} {r}\n')
        while len(cases) < count:
            l = rnd.randrange(2_000_000_000)
            r = min(2_000_000_000,l+rnd.randint(1,4000))
            add('random', f'{l} {r}\n')
        if include_large: add('constraint_max_range','0 2000000000\n')
    elif pid == 'abc161_c':
        for name,n,k in [('constraint_min',0,1),('usual',7,4),('n_below_k',2,6),
                         ('n_equals_k',9,9),('k_one',10**18,1),('constraint_max_both',10**18,10**18),
                         ('n_max_k_near',10**18,10**18-1), ('halfway',5,10)]:
            add(name,f'{n} {k}\n')
        while len(cases) < count:
            n = rnd.randrange(10**18+1);k = rnd.randint(1,10**18)
            add('random', f'{n} {k}\n')
        if include_large: add('constraint_max','1000000000000000000 1\n')
    elif pid == 'abc171_c':
        for name,n in [('constraint_min',1),('end_single',26),('first_double',27),
                       ('end_double',702),('first_triple',703),('usual',123456789),
                       ('constraint_max',1000000000000001)]:
            add(name,f'{n}\n')
        while len(cases) < count:
            add('random',f'{rnd.randint(1,1000000000000001)}\n')
        if include_large: add('constraint_max', '1000000000000001\n')
    elif pid == 'abc180_c':
        for name,n in [('constraint_min',1),('prime',1000000007),('constraint_max_square',10**12),
                       ('usual',720),('small_square',36),('constraint_max',10**12),
                       ('near_max',999999999989)]:
            add(name,f'{n}\n')
        while len(cases) < count:
            add('random',f'{rnd.randint(1,10**12)}\n')
        if include_large: add('constraint_max','1000000000000\n')
    else:
        # abc210_c, including a genuine N=300,000 maximum-scale case.
        def array_case(name: str, n: int, k: int, arr: list[int]):
            add(name, f'{n} {k}\n'+ ' '.join(map(str, arr))+'\n')
        array_case('constraint_min',1,1,[1])
        array_case('usual',7,3,[1,2,1,2,3,3,1])
        array_case('all_same',5,5,[4]*5)
        array_case('one_window',12,12,list(range(1,13)))
        array_case('k_one',12,1,[1,2]*6)
        array_case('colors_max',6,3,[10**9,1,10**9,2,3,1])
        array_case('one_duplicate',9,5,[1,2,3,4,1,2,3,4,5])
        while len(cases) < count:
            n = rnd.randint(2,36); k = rnd.randint(1,n)
            arr=[rnd.randint(1,10**9) if rnd.randrange(4)==0 else rnd.randint(1,n) for _ in range(n)]
            array_case('random',n,k,arr)
        if include_large:
            n=300000; k=150000
            array_case('constraint_max_n',n,k,[1+(i%200003) for i in range(n)])
    return cases[:count] + ([c for c in cases[count:] if c['category'].startswith('constraint_max') or c['category']=='wide_max'] if include_large else [])


def independent_check(pid: str, data: str, expected: str) -> bool:
    """Independent invariant or brute-force check; never a generic 'all correct' claim."""
    if pid in BATCH19: return batch19_independent_check(pid, data, expected)
    if pid in BATCH18: return batch18_independent_check(pid, data, expected)
    if pid in BATCH17: return batch17_independent_check(pid, data, expected)
    if pid in BATCH16: return batch16_independent_check(pid, data, expected)
    if pid in BATCH15: return batch15_independent_check(pid, data, expected)
    if pid in BATCH14: return batch14_independent_check(pid, data, expected)
    if pid in BATCH13: return batch13_independent_check(pid, data, expected)
    if pid in BATCH12: return batch12_independent_check(pid, data, expected)
    if pid in BATCH11: return batch11_independent_check(pid, data, expected)
    if pid in BATCH10: return batch10_independent_check(pid, data, expected)
    if pid in BATCH9: return batch9_independent_check(pid, data, expected)
    if pid in BATCH8: return batch8_independent_check(pid, data, expected)
    if pid in BATCH7: return batch7_independent_check(pid, data, expected)
    if pid in BATCH6: return batch6_independent_check(pid, data, expected)
    if pid in BATCH5: return batch5_independent_check(pid, data, expected)
    if pid in BATCH4: return batch4_independent_check(pid, data, expected)
    if pid in BATCH3: return batch3_independent_check(pid, data, expected)
    if pid in BATCH: return batch_independent_check(pid, data, expected)
    if pid in EXTRA: return extra_independent_check(pid, data, expected)
    values = validate(pid, data)
    answer = expected.strip()
    if pid == 'abc161_c':
        n,k = values
        q = n//k
        return answer == str(min(abs(n-q*k), abs(n-(q+1)*k)))
    if pid == 'abc133_c':
        l,r = values
        if r-l >= 2019: return answer == '0'
        result = min((i*j)%2019 for i in range(l,r) for j in range(i+1,r+1))
        return answer == str(result)
    if pid == 'abc171_c':
        (n,) = values
        if not answer or any(not 'a'<=c<='z' for c in answer): return False
        decoded = 0
        for c in answer: decoded = decoded*26 + (ord(c)-96)
        return decoded == n
    if pid == 'abc180_c':
        (n,) = values
        try: divs = list(map(int, answer.split()))
        except ValueError: return False
        if not divs or divs != sorted(set(divs)) or divs[0]!=1 or divs[-1]!=n:
            return False
        if any(n%d for d in divs): return False
        # Count divisors independently using the square-root bound.
        count = sum(1 if x*x==n else 2 for x in range(1,isqrt(n)+1) if n%x==0)
        return len(divs)==count
    n,k,*a = values
    result = int(answer) if answer.isdecimal() else -1
    if n <= 40:
        return result == max(len(set(a[i:i+k])) for i in range(n-k+1))
    # Separate O(N) Counter-based sliding window for larger cases. Unlike the
    # reference program, this removes keys when their count reaches zero.
    from collections import Counter
    freq=Counter(a[:k]); best=len(freq)
    for i in range(k,n):
        outgoing=a[i-k];freq[outgoing]-=1
        if freq[outgoing]==0: del freq[outgoing]
        freq[a[i]]+=1
        if len(freq)>best:best=len(freq)
    return result==best
