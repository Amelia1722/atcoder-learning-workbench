"""ABC272–274 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP, localcontext
import re

TASKS = ('abc272_b', 'abc273_b', 'abc274_b')
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
POS = re.compile(r'(?:[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc272_b': [
        {'input': '3 3\n2 1 2\n2 2 3\n2 1 3\n', 'expected': 'Yes\n'},
        {'input': '4 2\n3 1 2 4\n3 2 3 4\n', 'expected': 'No\n'},
    ],
    'abc273_b': [
        {'input': '2048 2\n', 'expected': '2100\n'},
        {'input': '1 15\n', 'expected': '0\n'},
        {'input': '999 3\n', 'expected': '1000\n'},
        {'input': '314159265358979 12\n', 'expected': '314000000000000\n'},
    ],
    'abc274_b': [
        {'input': '3 4\n#..#\n.#.#\n.#.#\n', 'expected': '1 2 0 3\n'},
        {'input': '3 7\n.......\n.......\n.......\n', 'expected': '0 0 0 0 0 0 0\n'},
        {'input': '8 3\n.#.\n###\n.#.\n.#.\n.##\n..#\n##.\n.##\n', 'expected': '2 7 4\n'},
        {
            'input': '5 47\n.#..#..#####..#...#..#####..#...#...###...#####\n.#.#...#.......#.#...#......##..#..#...#..#....\n.##....#####....#....#####..#.#.#..#......#####\n.#.#...#........#....#......#..##..#...#..#....\n.#..#..#####....#....#####..#...#...###...#####\n',
            'expected': '0 5 1 2 2 0 0 5 3 3 3 3 0 0 1 1 3 1 1 0 0 5 3 3 3 3 0 0 5 1 1 1 5 0 0 3 2 2 2 2 0 0 5 3 3 3 3\n',
        },
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate272(raw: str) -> tuple[int, list[list[int]]]:
    lines = _canonical_lines(raw)
    head = _ints_line(lines[0]) if lines else []
    if len(head) != 2:
        raise ValueError('header')
    n, m = head
    if not (2 <= n <= 100 and 1 <= m <= 100) or len(lines) != m + 1:
        raise ValueError('constraints')
    parties: list[list[int]] = []
    for line in lines[1:]:
        vals = _ints_line(line)
        if len(vals) < 3:
            raise ValueError('party')
        k, people = vals[0], vals[1:]
        if not (2 <= k <= n) or len(people) != k:
            raise ValueError('party size')
        if people != sorted(people) or len(set(people)) != k or any(not 1 <= x <= n for x in people):
            raise ValueError('people')
        parties.append(people)
    return n, parties


def _validate273(raw: str) -> tuple[int, int]:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    vals = _ints_line(lines[0])
    if len(vals) != 2:
        raise ValueError('shape')
    x, k = vals
    if not (0 <= x < 10**15 and 1 <= k <= 15):
        raise ValueError('constraints')
    return x, k


def _validate274(raw: str) -> list[str]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 2:
        raise ValueError('header')
    h, w = head
    if not (1 <= h <= 1000 and 1 <= w <= 1000) or len(lines) != h + 1:
        raise ValueError('constraints')
    grid = lines[1:]
    if any(len(row) != w or any(ch not in '.#' for ch in row) for row in grid):
        raise ValueError('grid')
    return grid


def validate(pid: str, raw: str):
    if pid == 'abc272_b':
        return _validate272(raw)
    if pid == 'abc273_b':
        return _validate273(raw)
    if pid == 'abc274_b':
        return _validate274(raw)
    raise ValueError('unknown task')


def _oracle272(n: int, parties: list[list[int]]) -> str:
    memberships = [set(p) for p in parties]
    for a in range(1, n + 1):
        for b in range(a + 1, n + 1):
            if not any(a in p and b in p for p in memberships):
                return 'No'
    return 'Yes'


def _oracle273(x: int, k: int) -> int:
    with localcontext() as ctx:
        ctx.prec = 40
        d = Decimal(x)
        for i in range(1, k + 1):
            quantum = Decimal(10) ** i
            d = (d / quantum).quantize(Decimal('1'), rounding=ROUND_HALF_UP) * quantum
        return int(d)


def _oracle274(grid: list[str]) -> list[int]:
    return [col.count('#') for col in zip(*grid)]


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc272_b':
        return output in ('Yes', 'No') and output == _oracle272(*value)
    if pid == 'abc273_b':
        return INT.fullmatch(output) is not None and int(output) == _oracle273(*value)
    grid = value
    parts = output.split(' ')
    if len(parts) != len(grid[0]) or any(INT.fullmatch(x) is None for x in parts):
        return False
    return [int(x) for x in parts] == _oracle274(grid)


def _party_input(n: int, parties: list[list[int]]) -> str:
    lines = [f'{n} {len(parties)}']
    lines.extend(f"{len(p)} {' '.join(map(str, p))}" for p in parties)
    return '\n'.join(lines) + '\n'


def _grid_input(grid: list[str]) -> str:
    return f'{len(grid)} {len(grid[0])}\n' + '\n'.join(grid) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc272_b':
        custom = [
            ('minimum_yes', _party_input(2, [[1, 2]])),
            ('three_one_party', _party_input(3, [[1, 2, 3]])),
            ('three_chain_no', _party_input(3, [[1, 2], [2, 3]])),
            ('four_all_pairs', _party_input(4, [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]])),
            ('four_missing_last_pair', _party_input(4, [[1,2],[1,3],[1,4],[2,3],[2,4]])),
            ('five_one_party', _party_input(5, [[1,2,3,4,5]])),
            ('five_cycle_no', _party_input(5, [[1,2],[2,3],[3,4],[4,5],[1,5]])),
            ('five_pairs_yes', _party_input(5, [[i,j] for i in range(1,6) for j in range(i+1,6)])),
            ('six_two_large_no', _party_input(6, [[1,2,3,4,5],[2,3,4,5,6]])),
            ('six_complements_yes', _party_input(6, [[x for x in range(1,7) if x != miss] for miss in range(1,7)])),
            ('ten_star_no', _party_input(10, [[1,i] for i in range(2,11)])),
            ('ten_single_full_yes', _party_input(10, [list(range(1,11))])),
            ('repeated_full_yes', _party_input(4, [[1,2,3,4]] * 5)),
            ('mixed_yes', _party_input(5, [[1,2,3],[1,4,5],[2,4],[2,5],[3,4],[3,5]])),
            ('mixed_no', _party_input(5, [[1,2,3],[1,4],[2,4],[3,5],[4,5]])),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', _party_input(100, [list(range(1,101)) for _ in range(100)]))
    elif pid == 'abc273_b':
        for category, raw in [
            ('zero', '0 1\n'),
            ('below_half', '4 1\n'),
            ('half_up', '5 1\n'),
            ('fourteen', '14 1\n'),
            ('fifteen', '15 1\n'),
            ('forty_four_two', '44 2\n'),
            ('forty_five_two', '45 2\n'),
            ('forty_nine_two', '49 2\n'),
            ('fifty_two', '50 2\n'),
            ('one_forty_nine', '149 2\n'),
            ('one_fifty', '150 2\n'),
            ('five_hundred_three', '500 3\n'),
            ('large_k14', '999999999999994 14\n'),
        ]:
            add(category, raw)
        add('constraint_max', '999999999999999 15\n')
    else:
        for category, grid in [
            ('single_empty', ['.']),
            ('single_box', ['#']),
            ('one_row_pattern', ['#.#.#']),
            ('one_col_pattern', ['#','.','#','#','.']),
            ('two_diag', ['#.','.#']),
            ('two_by_three_full', ['###','###']),
            ('three_by_two_alt', ['#.','.#','#.']),
            ('four_checker', ['#.#.','.#.#','#.#.','.#.#']),
            ('ten_full', ['#'*10 for _ in range(10)]),
            ('ten_empty', ['.'*10 for _ in range(10)]),
            ('wide_alternating', [''.join('#' if j%2==0 else '.' for j in range(1000))]),
            ('tall_full', ['#' for _ in range(1000)]),
            ('hundred_pattern', [''.join('#' if (i+j)%7==0 else '.' for j in range(100)) for i in range(100)]),
        ]:
            add(category, _grid_input(grid))
        max_grid = [''.join('#' if (i * 17 + j * 31) % 11 < 3 else '.' for j in range(1000)) for i in range(1000)]
        add('constraint_max', _grid_input(max_grid))

    if len(out) != 18:
        raise AssertionError((pid, len(out), [x['category'] for x in out]))
    return out
