"""ABC131–133 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re
from math import isqrt

TASKS = ('abc131_b', 'abc132_b', 'abc133_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)


def _split(line: str, count: int, pattern: re.Pattern[str]) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(token) is None for token in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc131_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        n, l = _split(lines[0], 2, SIGNED)
        if not 2 <= n <= 200 or not -100 <= l <= 100:
            raise ValueError('N/L range')
        return n, l

    if pid == 'abc132_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and permutation row')
        n = int(lines[0])
        if not 3 <= n <= 20:
            raise ValueError('N range')
        p = _split(lines[1], n, POS)
        if sorted(p) != list(range(1, n + 1)):
            raise ValueError('not a permutation')
        return p

    if not lines:
        raise ValueError('expected header')
    n, d = _split(lines[0], 2, POS)
    if not 2 <= n <= 10 or not 1 <= d <= 10 or len(lines) != n + 1:
        raise ValueError('N/D/row count range')
    points: list[tuple[int, ...]] = []
    for line in lines[1:]:
        coords = _split(line, d, SIGNED)
        if any(not -20 <= x <= 20 for x in coords):
            raise ValueError('coordinate range')
        points.append(tuple(coords))
    if len(set(points)) != n:
        raise ValueError('duplicate points')
    return d, points


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if output != '0' and SIGNED.fullmatch(output) is None:
        return False

    if pid == 'abc131_b':
        n, l = value
        flavors = [l + i for i in range(n)]
        total = sum(flavors)
        # Brute-force every possible eaten apple and minimize the absolute
        # difference from the original pie; this avoids relying on min(..., key=abs).
        remaining = [total - x for x in flavors]
        best_gap = min(abs(total - s) for s in remaining)
        expected_values = {s for s in remaining if abs(total - s) == best_gap}
        return len(expected_values) == 1 and output == str(next(iter(expected_values)))

    if pid == 'abc132_b':
        p = value
        expected = 0
        for i in range(1, len(p) - 1):
            triple = sorted((p[i - 1], p[i], p[i + 1]))
            expected += triple[1] == p[i]
        return output == str(expected)

    d, points = value
    # Maximum squared distance is d*40^2 <= 16000. Build the square set
    # independently instead of calling sqrt/isqrt on each pair.
    squares = {k * k for k in range(isqrt(d * 40 * 40) + 1)}
    expected = 0
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            sq = sum((points[i][k] - points[j][k]) ** 2 for k in range(d))
            expected += sq in squares
    return output == str(expected)


def _one(n: int, l: int) -> str:
    return f'{n} {l}\n'


def _perm(p: list[int]) -> str:
    return f'{len(p)}\n' + ' '.join(map(str, p)) + '\n'


def _points(points: list[list[int]]) -> str:
    d = len(points[0])
    return f'{len(points)} {d}\n' + ''.join(' '.join(map(str, row)) + '\n' for row in points)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc131_b':
        fixed = [
            ('sample1',5,2), ('sample2',3,-1), ('sample3',30,-50),
            ('two_positive',2,1), ('two_negative',2,-100), ('contains_zero_left',2,0),
            ('contains_zero_middle',5,-2), ('contains_zero_right',5,-4),
            ('all_positive_small',10,1), ('all_negative_small',10,-20),
            ('cross_zero_even',4,-1), ('cross_zero_odd',7,-3),
            ('l_zero',8,0), ('positive_boundary',2,100), ('negative_boundary_short',3,-100),
            ('long_positive',100,1), ('long_cross_zero',200,-100),
        ]
        for category, n, l in fixed:
            add(category, _one(n, l))
        add('constraint_max', _one(200, 100))

    elif pid == 'abc132_b':
        fixed = [
            ('sample1',[1,3,5,4,2]), ('sample2',[9,6,3,2,5,8,7,4,1]),
            ('minimum_increasing',[1,2,3]), ('minimum_decreasing',[3,2,1]),
            ('minimum_peak',[1,3,2]), ('minimum_valley',[2,1,3]),
            ('four_increasing',[1,2,3,4]), ('four_decreasing',[4,3,2,1]),
            ('zigzag',[1,3,2,5,4]), ('reverse_zigzag',[5,3,4,1,2]),
            ('one_median',[1,3,2,4]), ('no_median',[2,1,4,3]),
            ('alternating_six',[1,6,2,5,3,4]), ('rotated',[3,4,5,6,1,2]),
            ('n10_mixed',[10,1,9,2,8,3,7,4,6,5]),
            ('n12_blocks',[1,2,3,6,5,4,7,8,9,12,11,10]),
            ('n20_reverse',list(range(20,0,-1))),
        ]
        for category, p in fixed:
            add(category, _perm(p))
        add('constraint_max', _perm(list(range(1, 21))))

    else:
        fixed = [
            ('sample1',[[1,2],[5,5],[-2,8]]),
            ('sample2',[[-3,7,8,2],[-12,1,10,2],[-2,8,9,3]]),
            ('sample3',[[1],[2],[3],[4],[5]]),
            ('two_1d_integer',[[0],[20]]), ('two_2d_pythagorean',[[0,0],[3,4]]),
            ('two_2d_noninteger',[[0,0],[1,1]]), ('negative_pythagorean',[[-3,-4],[0,0]]),
            ('three_axis',[[0,0],[3,0],[0,4]]), ('mixed_sign',[[20,-20],[-20,20],[20,20]]),
            ('d3_integer',[[0,0,0],[1,2,2]]), ('d3_noninteger',[[0,0,0],[1,1,1]]),
            ('d4_integer',[[0,0,0,0],[1,1,1,1]]),
            ('duplicates_forbidden_shape',[[0,0],[0,1],[1,0],[1,1]]),
            ('boundary_coords',[[-20,-20],[20,-20],[-20,20],[20,20]]),
            ('five_1d_sparse',[[-20],[-7],[0],[9],[20]]),
            ('six_2d_grid',[[0,0],[3,4],[6,8],[1,1],[4,5],[9,12]]),
            ('n8_d5',[[i, i-4, (i*2)%7-3, (i*3)%9-4, (i*5)%11-5] for i in range(8)]),
        ]
        for category, points in fixed:
            add(category, _points(points))
        max_points = []
        for i in range(10):
            row = [(-20 + ((i * 7 + j * 11) % 41)) for j in range(10)]
            max_points.append(row)
        add('constraint_max', _points(max_points))

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
