"""Backfill only ABC029–031 B, each checked against its public official statement."""
HINTS_BACKFILL_V65 = {
    'abc029_b': (
        '文字が何度現れたかではなく、条件を満たす文字列が何個あるかを数えてください。',
        '12個の文字列それぞれについて文字rの存在判定を行い、真となる文字列の数を足します。rが複数回あっても1回だけ数えます。',
        '疑似コード:\nans=0\n12回繰り返し:\n  s=文字列を読む\n  if "r" in s: ans+=1\nprint(ans)',
    ),
    'abc030_b': (
        '短針も分が進むと少しずつ動きます。12時間で同じ方向に戻ることにも注意してください。',
        '短針は1時間30度・1分0.5度、長針は1分6度です。角度差と360度から引いた角度の小さい方を求めます。',
        '疑似コード:\nhour=(n%12)*30+m*0.5\nminute=m*6\ndiff=abs(hour-minute)\nprint(min(diff,360-diff))',
    ),
    'abc031_b': (
        '適正範囲の下・中・上で、それぞれ出力する値が異なります。境界の等号を整理してください。',
        'AがHより大きいときは-1、Lより小さいときはL-A、それ以外は0を出力します。週ごとに独立して判定します。',
        '疑似コード:\nfor A in 各週の運動時間:\n  if A>H: print(-1)\n  elif A<L: print(L-A)\n  else: print(0)',
    ),
}
