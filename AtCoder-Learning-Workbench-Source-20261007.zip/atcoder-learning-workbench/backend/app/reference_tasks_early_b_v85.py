"""ABC113–115 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc113_b','abc114_b','abc115_b')
INT=re.compile(r'-?(?:0|[1-9][0-9]*)', re.ASCII)
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
DIGITS_1_9=re.compile(r'[1-9]{4,10}', re.ASCII)


def _tokens(line:str, count:int)->list[str]:
    parts=line.split(' ')
    if len(parts)!=count or any(INT.fullmatch(t) is None for t in parts):
        raise ValueError('integer format')
    return parts


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc113_b':
        if len(lines)!=3 or POS.fullmatch(lines[0]) is None:
            raise ValueError('line count/format')
        n=int(lines[0])
        if not 1<=n<=1000: raise ValueError('n range')
        t_a=_tokens(lines[1],2); t,a=map(int,t_a)
        if not (0<=t<=50 and -60<=a<=t): raise ValueError('temperature range')
        hs=list(map(int,_tokens(lines[2],n)))
        if any(h<0 or h>100_000 for h in hs): raise ValueError('height range')
        diffs=[abs((t-a)*1000-6*h) for h in hs]
        best=min(diffs)
        if diffs.count(best)!=1: raise ValueError('solution must be unique')
        return n,t,a,hs
    if pid=='abc114_b':
        if len(lines)!=1 or DIGITS_1_9.fullmatch(lines[0]) is None:
            raise ValueError('string format/range')
        return lines[0]
    if len(lines)<3 or POS.fullmatch(lines[0]) is None:
        raise ValueError('line count/format')
    n=int(lines[0])
    if not 2<=n<=10 or len(lines)!=n+1: raise ValueError('shape/range')
    prices=[]
    for line in lines[1:]:
        if POS.fullmatch(line) is None: raise ValueError('price format')
        p=int(line)
        if not (100<=p<=10_000 and p%2==0): raise ValueError('price range/parity')
        prices.append(p)
    return n,prices


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc113_b':
        if POS.fullmatch(output) is None: return False
        n,t,a,hs=value
        ans=int(output)
        if not 1<=ans<=n: return False
        expected=min(range(n), key=lambda i: abs((t-a)*1000-6*hs[i]))+1
        return ans==expected
    if output!='0' and POS.fullmatch(output) is None: return False
    if pid=='abc114_b':
        s=value
        expected=min(abs(int(s[i:i+3])-753) for i in range(len(s)-2))
        return output==str(expected)
    _,prices=value
    expected=sum(prices)-max(prices)//2
    return output==str(expected)


def _palace(t:int,a:int,hs:list[int])->str:
    return f'{len(hs)}\n{t} {a}\n'+' '.join(map(str,hs))+'\n'


def _prices(ps:list[int])->str:
    return f'{len(ps)}\n'+'\n'.join(map(str,ps))+'\n'


def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc113_b':
        cases=[
          (0,0,[0]),
          (12,5,[1000,2000]),
          (21,-11,[81234,94124,52141]),
          (50,50,[1,0]),
          (50,-60,[0,18333,100000]),
          (0,-60,[9999,10000,10001]),
          (30,20,[1666,1667,1668]),
          (25,0,[4166,4167,4168,50000]),
          (1,-60,[10166,10167,10168]),
          (50,-59,[18165,18166,18167,18168]),
          (10,10,[100000,99999,1,0]),
          (40,15,[1,4000,4166,4167,99999]),
          (7,-3,[1665,1666,1667,1668,1669]),
          (50,0,[8332,8333,8334,0,100000]),
          (0,0,[100000,50000,1,0]),
          (50,-60,[18332,18333,18334,18335,99999]),
          (13,-17,[4998,4999,5000,5001,5002]),
        ]
        for t,a,hs in cases:
            add('boundary' if len(hs)==1 or t in (0,50) or a in (-60,t) or 100000 in hs else 'normal',_palace(t,a,hs))
        hs=[100000,*range(999)]
        add('constraint_max',_palace(50,50,hs))
    elif pid=='abc114_b':
        values=[
          '1111','7531','1753','9999','35753','1234567876','1111111111','7539','9753',
          '1234','8765','7777','7529','7541','17351','97519','444753444',
        ]
        for s in values:
            add('boundary' if len(s)==4 or '753' in s else 'normal',s+'\n')
        add('constraint_max','9999999999\n')
    else:
        cases=[
          [100,100], [10000,100], [10000,10000], [4980,7980,6980], [4320,4320,4320,4320],
          [100,200,300], [200,100,200], [10000,9998,9996], [102,104,106,108,110],
          [1000,2000,3000,4000,5000], [500,500,1000,1000,1500,1500],
          [10000,100,100,100,100,100,100,100,100,100], [200,400,600,800,1000,1200,1400],
          [9998,9998,9998,9998,9998], [2468,1356], [100,10000], [2222,4444,6666,8888],
        ]
        for ps in cases:
            add('boundary' if len(ps)==2 or 100 in ps or 10000 in ps else 'normal',_prices(ps))
        add('constraint_max',_prices([10000]*10))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
