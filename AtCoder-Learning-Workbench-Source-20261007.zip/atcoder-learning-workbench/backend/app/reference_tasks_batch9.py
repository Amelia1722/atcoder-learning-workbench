"""ABC099–103 curated A/B and selected C: validators, generators and cross-checks.

Each statement/source link was checked against the official AtCoder tasks_print
page. No generic inference or downloaded submissions are used.
"""
from __future__ import annotations

from itertools import permutations, product
from math import gcd, lcm
from random import Random
import re

SAMPLES = {
    'abc099_a': ('999\n', 'ABC', '1<=N<=1998'),
    'abc099_b': ('8 13\n', '2', '1<=a<b<499500; adjacent triangular towers, positive snow'),
    'abc100_a': ('5 4\n', 'Yay!', '1<=A,B<=16; A+B<=16'),
    'abc100_b': ('0 5\n', '5', 'D in {0,1,2}; 1<=N<=100'),
    'abc100_c': ('3\n5 2 4\n', '3', '1<=N<=10000; 1<=Ai<=1000000000'),
    'abc101_a': ('+-++\n', '2', 'S has length 4, characters + or -'),
    'abc101_b': ('12\n', 'Yes', '1<=N<=1000000000'),
    'abc101_c': ('4 3\n2 3 1 4\n', '2', '2<=K<=N<=100000; A is a permutation of 1..N'),
    'abc102_a': ('3\n', '6', '1<=N<=1000000000'),
    'abc102_b': ('4\n1 4 6 3\n', '5', '2<=N<=100; 1<=Ai<=1000000000'),
    'abc102_c': ('5\n2 2 3 5 5\n', '2', '1<=N<=200000; 1<=Ai<=1000000000'),
    'abc103_a': ('1 6 3\n', '5', '1<=A1,A2,A3<=100'),
    'abc103_b': ('kyoto\ntokyo\n', 'Yes', '2<=len(S)=len(T)<=100; both lowercase English letters'),
    'abc103_c': ('3\n3 4 6\n', '10', '2<=N<=3000; 2<=Ai<=100000'),
    'abc104_a': ('1199\n', 'ABC', '0<=R<=4208'),
    'abc104_b': ('AtCoder\n', 'AC', '4<=len(S)<=10; English uppercase/lowercase'),
}
# Existing ABC100 A/B/C and ABC102 A/B/C are already published in v14.
# Keep their earlier validated implementations, reference programs and hints.
for _existing in ('abc100_a','abc100_b','abc100_c','abc102_a','abc102_b','abc102_c'):
    SAMPLES.pop(_existing)
BATCH9 = {
    pid: {'sample_input': sin, 'sample_output': sout,
          'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
          'constraints': constraints}
    for pid, (sin, sout, constraints) in SAMPLES.items()
}


def validate(pid: str, data: str):
    if pid not in BATCH9:
        raise ValueError('未対応の問題ID')
    t = data.split()
    if pid == 'abc101_a':
        if len(t) != 1 or re.fullmatch(r'[+\-]{4}', t[0]) is None:
            raise ValueError('4文字の+/-が必要です')
        return t[0]
    if pid == 'abc104_b':
        if len(t)!=1 or re.fullmatch('[A-Za-z]{4,10}',t[0]) is None:
            raise ValueError('4..10文字の英字が必要です')
        return t[0]
    if pid == 'abc103_b':
        if len(t) != 2 or any(re.fullmatch('[a-z]{2,100}', s) is None for s in t) or len(t[0]) != len(t[1]):
            raise ValueError('同じ長さ2..100の英小文字2語が必要です')
        return tuple(t)
    if not t or any(re.fullmatch(r'[0-9]+', s) is None for s in t):
        raise ValueError('非負整数以外を含みます')
    z = list(map(int, t))
    if pid == 'abc104_a':
        if len(z)!=1 or not 0<=z[0]<=4208:raise ValueError('R: 0..4208')
        return z[0]
    if pid == 'abc099_a':
        if len(z) != 1 or not 1 <= z[0] <= 1998: raise ValueError('N: 1..1998')
        return z[0]
    if pid == 'abc099_b':
        if len(z) != 2: raise ValueError('a bが必要です')
        a, b = z
        d = b - a
        if not 1 <= a < b < 499500 or not 2 <= d <= 999 or not a < (d-1)*d//2:
            raise ValueError('隣接する塔・雪深さの条件に一致しません')
        return a, b
    if pid == 'abc100_a':
        if len(z) != 2 or not all(1 <= v <= 16 for v in z) or sum(z) > 16:
            raise ValueError('A,B: 1..16; A+B<=16')
        return tuple(z)
    if pid == 'abc100_b':
        if len(z) != 2 or z[0] not in (0,1,2) or not 1 <= z[1] <= 100:
            raise ValueError('D:0/1/2; N:1..100')
        return tuple(z)
    if pid in ('abc100_c','abc102_b','abc102_c','abc103_c'):
        limits = {'abc100_c':(1,10000,1,10**9), 'abc102_b':(2,100,1,10**9),
                  'abc102_c':(1,200000,1,10**9), 'abc103_c':(2,3000,2,100000)}
        low,high,amin,amax=limits[pid]
        if len(z) < 1: raise ValueError('Nが必要です')
        n=z[0]; a=z[1:]
        if not low<=n<=high or len(a)!=n or any(not amin<=v<=amax for v in a):
            raise ValueError('N/Aiの個数または値域が不正です')
        return a
    if pid in ('abc101_b','abc102_a'):
        if len(z) != 1 or not 1 <= z[0] <= 10**9:
            raise ValueError('N: 1..1000000000')
        return z[0]
    if pid == 'abc101_c':
        if len(z) < 4: raise ValueError('N K Aが必要です')
        n,k=z[:2];a=z[2:]
        if not 2<=k<=n<=100000 or len(a)!=n or len(set(a))!=n or min(a)!=1 or max(a)!=n:
            raise ValueError('N Kまたは1..Nの順列が不正です')
        return n,k,a
    if pid == 'abc103_a':
        if len(z)!=3 or any(not 1<=v<=100 for v in z): raise ValueError('A1 A2 A3: 1..100')
        return tuple(z)
    raise AssertionError(pid)


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str,str]]:
    if pid not in BATCH9 or not 1 <= count <= 80: raise ValueError('問題ID/件数が不正')
    rnd=Random(seed)
    cases=[];seen=set()
    def add(category:str,data:str):
        validate(pid,data)
        if data not in seen:
            seen.add(data);cases.append({'category':category,'input':data})
        elif category == 'constraint_max':
            next(c for c in cases if c['input']==data)['category']=category
    def nums(category:str,*values): add(category,' '.join(map(str,values))+'\n')
    def array_case(category:str,a:list[int]): add(category,f'{len(a)}\n'+' '.join(map(str,a))+'\n')
    if pid=='abc099_a':
        for n in (1,2,998,999,1000,1001,1997,1998,1500,1111,424,777): nums('boundary',n)
        while len(cases)<count: nums('random',rnd.randint(1,1998))
        if include_large: nums('constraint_max',1998)
    elif pid=='abc099_b':
        def tower(category, d, snow):
            west=d*(d-1)//2
            east=d*(d+1)//2
            nums(category,west-snow,east-snow)
        for d,x in ((3,1),(5,2),(11,1),(999,1),(999,498499),(999,498500),(2,1),
                    (500,1),(500,124749),(3,2),(4,5),(998,1)):
            if x<d*(d-1)//2:tower('boundary',d,x)
        while len(cases)<count:
            d=rnd.randint(3,999);tower('random',d,rnd.randint(1,d*(d-1)//2-1))
        if include_large:tower('constraint_max',999,1)
    elif pid=='abc100_a':
        for a,b in ((1,1),(5,4),(8,8),(11,4),(8,7),(7,8),(9,1),(1,9),(1,15),(15,1),(7,7),(8,1)):
            nums('boundary',a,b)
        while len(cases)<count:
            a=rnd.randint(1,15);nums('random',a,rnd.randint(1,16-a))
        if include_large:nums('constraint_max',8,8)
    elif pid=='abc100_b':
        for d,n in product(range(3),(1,2,5,11,85,99,100)):
            nums('boundary',d,n)
        while len(cases)<count:nums('random',rnd.randint(0,2),rnd.randint(1,100))
        if include_large:nums('constraint_max',2,100)
    elif pid=='abc100_c':
        for a in ([1],[2],[5,2,4],[631,577,243,199],[1]*10,[2]*10,[2**29],
                  [10**9]*10,[2**29,2**29,2**29],[1,2,3,4,8,16,32],
                  [2**29]*20,[3]*11):array_case('boundary',a)
        while len(cases)<count:
            n=rnd.randint(1,50);array_case('random',[rnd.randint(1,10**9) for _ in range(n)])
        if include_large:array_case('constraint_max',[2**29]*10000)
    elif pid=='abc101_a':
        for p in product('+-',repeat=4):add('boundary',''.join(p)+'\n')
        if include_large:add('constraint_max','++++\n')
    elif pid in ('abc101_b','abc102_a'):
        base = (1,2,3,9,10,11,12,99,100,101,999,999999999,1000000000,999999998)
        for n in base:nums('boundary',n)
        while len(cases)<count:nums('random',rnd.randint(1,10**9))
        if include_large:nums('constraint_max',10**9)
    elif pid=='abc101_c':
        def perm(category,k,a):add(category,f'{len(a)} {k}\n'+' '.join(map(str,a))+'\n')
        for k,a in ((2,[1,2]),(3,[2,3,1,4]),(3,[1,2,3]),(3,[7,3,1,8,4,6,2,5]),
                    (2,list(range(1,21))),(20,list(range(1,21))),(3,list(range(20,0,-1))),
                    (19,list(range(1,21))),(2,[2,1,3,4,5,6,7,8,9,10])):perm('boundary',k,a)
        while len(cases)<count:
            n=rnd.randint(2,55);a=list(range(1,n+1));rnd.shuffle(a)
            perm('random',rnd.randint(2,n),a)
        if include_large:perm('constraint_max',2,list(range(1,100001)))
    elif pid in ('abc102_b','abc102_c','abc103_c'):
        minv,maxv=(2,100000) if pid=='abc103_c' else (1,10**9)
        def a_case(category,a):array_case(category,a)
        normal = {'abc102_b':[1,4,6,3], 'abc102_c':[2,2,3,5,5], 'abc103_c':[3,4,6]}[pid]
        low=1 if pid=='abc102_c' else 2
        for a in ([minv]*low,[maxv]*low,normal,[minv,maxv],[maxv,minv],
                  [minv]*20,[maxv]*20, [minv,maxv]*10,
                  [minv+i for i in range(20)],[maxv-i for i in range(20)]):
            if len(a)>=low:a_case('boundary',a)
        while len(cases)<count:
            n=rnd.randint(low,55)
            a_case('random',[rnd.randint(minv,maxv) for _ in range(n)])
        if include_large:
            n={'abc102_b':100,'abc102_c':200000,'abc103_c':3000}[pid]
            a_case('constraint_max',[maxv if i%3 else minv for i in range(n)])
    elif pid=='abc104_a':
        for n in (0,1,1198,1199,1200,1201,2798,2799,2800,2801,4207,4208):nums('boundary',n)
        while len(cases)<count:nums('random',rnd.randint(0,4208))
        if include_large:nums('constraint_max',4208)
    elif pid=='abc104_b':
        for word in ('AtCoder','ACoder','AcycliC','AtCoCo','Atcoder','AbCd','ACdd',
                     'AbCdE','aabb','ACaa','AbbC','AbCz','ABcd','AaaCaa','AabcdeCghi',
                     'Aabcdefghi','a'*10,'A'+'a'*9,'A'+'a'*7+'C'+'a'):
            add('boundary',word+'\n')
        while len(cases)<count:
            n=rnd.randint(4,10)
            word=''.join(rnd.choice('abcCDA') for _ in range(n))
            add('random',word+'\n')
        if include_large:add('constraint_max','A'+'a'*7+'C'+'a'+'\n')
    elif pid=='abc103_a':
        for a in ((1,1,1),(100,100,100),(1,6,3),(11,5,5),(1,1,100),
                  (1,100,1),(100,1,1),(1,100,100),(100,100,1),(1,2,3),
                  (3,2,1),(50,51,52)):nums('boundary',*a)
        while len(cases)<count:nums('random',*(rnd.randint(1,100) for _ in range(3)))
        if include_large:nums('constraint_max',1,100,100)
    else:  # abc103_b
        def words(category,s,t):add(category,f'{s}\n{t}\n')
        for s,t in (('kyoto','tokyo'),('abc','arc'),('aa','aa'),('ab','ba'),
                    ('ab','aa'),('aaaaa','aaaaa'),('abcde','eabcd'),
                    ('abcde','abced'),('abcdef','cdefab'),('a'*99+'b','b'+'a'*99)):
            words('boundary',s,t)
        while len(cases)<count:
            n=rnd.randint(2,100);s=''.join(rnd.choice('abcde') for _ in range(n))
            offset=rnd.randrange(n)
            t=s[offset:]+s[:offset] if rnd.randint(0,1) else ''.join(rnd.choice('abcde') for _ in range(n))
            words('random',s,t)
        if include_large:words('constraint_max','a'*99+'b','b'+'a'*99)
    if include_large:
        maximum=next((c for c in reversed(cases) if c['category']=='constraint_max'),None)
        if maximum is None:raise RuntimeError(f'{pid}: 最大規模ケースがありません')
        return [c for c in cases if c['input']!=maximum['input']][:count]+[maximum]
    return cases[:count]


def independent_check(pid: str,data:str,expected:str)->bool:
    v=validate(pid,data)
    s=expected.strip()
    if pid=='abc104_a':return s==('ABC' if v<1200 else 'ARC' if v<2800 else 'AGC')
    if pid=='abc104_b':
        uppercase=[i for i,c in enumerate(v) if c.isupper()]
        ok=v[0]=='A' and len(uppercase)==2 and uppercase[0]==0 and 2<=uppercase[1]<len(v)-1 and v[uppercase[1]]=='C'
        return s==('AC' if ok else 'WA')
    if pid=='abc099_a':return s==('ABC' if v<=999 else 'ABD')
    if pid=='abc099_b':
        a,b=v
        # Find the unique pair by enumerating actual adjacent tower heights.
        h=1
        for i in range(2,1000):
            next_h=i*(i+1)//2
            if next_h-h==b-a and h>a:
                return s==str(h-a) and next_h-b==h-a
            h=next_h
        return False
    if pid=='abc100_a':
        a,b=v
        # The maximum independent set of a cycle on 16 vertices is 8.
        return s==('Yay!' if a<=8 and b<=8 else ':(')
    if pid=='abc100_b':
        d,n=v
        # Count positive integers excluding multiples of 100 from each 100-block.
        base=n+(n-1)//99
        return s==str(base*100**d)
    if pid=='abc100_c':
        # Each iteration must consume at least one factor 2. Odd multiplications
        # cannot introduce new factors of 2.
        return s==str(sum((x & -x).bit_length()-1 for x in v))
    if pid=='abc101_a':return s==str(sum(1 if c=='+' else -1 for c in v))
    if pid=='abc101_b':
        x=v;digit_sum=0
        while x:digit_sum+=x%10;x//=10
        return s==('Yes' if v%digit_sum==0 else 'No')
    if pid=='abc101_c':
        n,k,a=v
        # Every operation can incorporate at most k-1 as-yet-unconverted
        # values into the connected interval containing the global minimum.
        remain=n-1
        moves=0
        while remain>0:moves+=1;remain-=k-1
        return s==str(moves)
    if pid=='abc102_a':
        n=v
        return s==str(2*n//gcd(2,n))
    if pid=='abc102_b':
        return s==str(max(abs(a-b) for a,b in product(v,repeat=2)))
    if pid=='abc102_c':
        # The slope of sum(abs(A[i]-i-b)) changes sign at a median;
        # independently locate its first minimizer by binary searching slope.
        adjusted=[x-i for i,x in enumerate(v,1)]
        lo=min(adjusted)-1;hi=max(adjusted)
        while lo+1<hi:
            mid=(lo+hi)//2
            # Discrete forward derivative F(mid+1)-F(mid).
            below=sum(x<=mid for x in adjusted)
            if 2*below>=len(adjusted):hi=mid
            else:lo=mid
        score=sum(abs(x-hi) for x in adjusted)
        return s==str(score)
    if pid=='abc103_a':
        return s==str(min(sum(abs(p[i]-p[i+1]) for i in range(2)) for p in permutations(v)))
    if pid=='abc103_b':
        a,b=v
        return s==('Yes' if any(a[i:]+a[:i]==b for i in range(len(a))) else 'No')
    if pid=='abc103_c':
        # Every residue is <= ai-1; m=lcm(ai)-1 realizes every upper bound.
        if len(v)<=12 and max(v)<=20:
            m=lcm(*v)-1
            result=sum(m%x for x in v)
        else:result=sum(x-1 for x in v)
        return s==str(result)
    raise AssertionError(pid)
