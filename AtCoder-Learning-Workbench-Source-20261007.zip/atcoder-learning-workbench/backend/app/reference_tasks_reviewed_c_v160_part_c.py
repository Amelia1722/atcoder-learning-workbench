"""Reviewed ABC112--117 C: strict canonical domains and independent oracles."""
from __future__ import annotations
from collections import defaultdict
from functools import lru_cache
from typing import cast
import random
import re

TASKS=tuple(f'abc{n}_c' for n in range(112,118))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Point=tuple[int,int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    result=tuple(map(int,row.split(' ')));require(count is None or len(result)==count,'field count');return result

def pyramid_solutions(points:tuple[Point,...])->list[Point]:
    positive=next(((x,y,h) for x,y,h in points if h>0),None)
    if positive is None:return []
    px,py,ph=positive;answers=[]
    for x in range(101):
        for y in range(101):
            h=ph+abs(x-px)+abs(y-py)
            if all(max(h-abs(x-a)-abs(y-b),0)==c for a,b,c in points):answers.append((x,y,h))
    return answers

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline')
    rows=raw[:-1].split('\n');require(all(rows),'blank line');number=int(pid[3:6])
    if number==112:
        n=ints(rows[0],1)[0];require(1<=n<=100 and len(rows)==n+1,'shape')
        points=tuple(cast(Point,ints(r,3)) for r in rows[1:]);require(all(0<=x<=100 and 0<=y<=100 and 0<=h<=10**9 for x,y,h in points),'observations')
        require(len({(x,y) for x,y,h in points})==n,'distinct coordinates');require(len(pyramid_solutions(points))==1,'unique valid pyramid');return (points,)
    if number==113:
        n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(rows)==m+1,'shape')
        cities=tuple(cast(tuple[int,int],ints(r,2)) for r in rows[1:]);require(all(1<=p<=n and 1<=y<=10**9 for p,y in cities),'cities');require(len({y for p,y in cities})==m,'distinct years');return n,cities
    if number==114:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<10**9,'limit');return (n,)
    if number==115:
        n,k=ints(rows[0],2);require(2<=k<n<=100000 and len(rows)==n+1,'shape');heights=tuple(ints(r,1)[0] for r in rows[1:]);require(all(1<=h<=10**9 for h in heights),'heights');return k,heights
    if number==116:
        n=ints(rows[0],1)[0];require(1<=n<=100 and len(rows)==2,'shape');heights=ints(rows[1],n);require(all(0<=h<=100 for h in heights),'heights');return (heights,)
    n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(rows)==2,'shape');xs=ints(rows[1],m);require(len(set(xs))==m and all(-100000<=x<=100000 for x in xs),'positions');return n,xs

def _pyramid_height_first(points:tuple[Point,...])->Point:
    px,py,ph=max(points,key=lambda p:p[2]);maximum=ph
    for h in range(maximum,maximum+201):
        distance=h-ph
        for dx in range(-distance,distance+1):
            x=px+dx
            if not 0<=x<=100:continue
            dy=distance-abs(dx)
            for y in {py-dy,py+dy}:
                if 0<=y<=100 and all((max(h-abs(x-a)-abs(y-b),0)==c) for a,b,c in points):return x,y,h
    raise ValueError('no pyramid')

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);n=int(pid[3:6])
    if n==112:return ' '.join(map(str,_pyramid_height_first(cast(tuple[Point,...],data[0]))))
    if n==113:
        _,cities=cast(tuple[int,tuple[tuple[int,int],...]],data);counts:dict[int,int]=defaultdict(int);answer=['']*len(cities)
        for year,pref,index in sorted((y,p,j) for j,(p,y) in enumerate(cities)):
            counts[pref]+=1;answer[index]=f'{pref:06}{counts[pref]:06}'
        return '\n'.join(answer)
    if n==114:
        bound=str(data[0])
        @lru_cache(None)
        def dp(pos:int,tight:bool,started:bool,mask:int)->int:
            if pos==len(bound):return int(mask==7)
            limit=int(bound[pos]) if tight else 9;total=0
            if not started:total+=dp(pos+1,tight and limit==0,False,0)
            for digit,bit in ((3,1),(5,2),(7,4)):
                if digit<=limit:total+=dp(pos+1,tight and digit==limit,True,mask|bit)
            return total
        return str(dp(0,True,False,0))
    if n==115:
        k,heights=cast(tuple[int,tuple[int,...]],data);a=sorted(heights)
        def feasible(width:int)->bool:
            left=0
            for right in range(len(a)):
                while a[right]-a[left]>width:left+=1
                if right-left+1>=k:return True
            return False
        lo=-1;hi=a[-1]-a[0]
        while hi-lo>1:
            mid=(lo+hi)//2
            if feasible(mid):hi=mid
            else:lo=mid
        return str(hi)
    if n==116:
        heights=cast(tuple[int,...],data[0]);total=0
        for level in range(1,max(heights,default=0)+1):
            active=False
            for h in heights:
                above=h>=level
                if above and not active:total+=1
                active=above
        return str(total)
    pieces,xs=cast(tuple[int,tuple[int,...]],data)
    if pieces>=len(xs):return '0'
    a=sorted(xs);gaps=[y-x for x,y in zip(a,a[1:])];keep=len(xs)-pieces
    lo=0;hi=200001
    while hi-lo>1:
        mid=(lo+hi)//2
        if sum(g<=mid for g in gaps)>=keep:hi=mid
        else:lo=mid
    below=[g for g in gaps if g<hi];return str(sum(below)+(keep-len(below))*hi)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc112_c':"n=int(input());points=[tuple(map(int,input().split())) for _ in range(n)];px,py,ph=next(p for p in points if p[2]>0)\nfor x in range(101):\n for y in range(101):\n  h=ph+abs(x-px)+abs(y-py)\n  if all(max(h-abs(x-a)-abs(y-b),0)==c for a,b,c in points):print(x,y,h);raise SystemExit\n",
'abc113_c':"from collections import defaultdict\nn,m=map(int,input().split());cities=[tuple(map(int,input().split())) for _ in range(m)];groups=defaultdict(list)\nfor j,(p,y) in enumerate(cities):groups[p].append((y,j))\nanswer=['']*m\nfor p,group in groups.items():\n for rank,(_,j) in enumerate(sorted(group),1):answer[j]=f'{p:06}{rank:06}'\nprint('\\n'.join(answer))\n",
'abc114_c':"n=int(input());answer=0\ndef visit(value,mask):\n global answer\n if value>n:return\n if mask==7:answer+=1\n for digit,bit in ((3,1),(5,2),(7,4)):visit(value*10+digit,mask|bit)\nvisit(0,0);print(answer)\n",
'abc115_c':"n,k=map(int,input().split());h=sorted(int(input()) for _ in range(n));print(min(h[j+k-1]-h[j] for j in range(n-k+1)))\n",
'abc116_c':"n=int(input());h=list(map(int,input().split()));print(sum(max(0,b-a) for a,b in zip([0]+h,h)))\n",
'abc117_c':"n,m=map(int,input().split());x=sorted(map(int,input().split()));gaps=sorted((b-a for a,b in zip(x,x[1:])),reverse=True);print(x[-1]-x[0]-sum(gaps[:n-1]) if n<m else 0)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    number=int(pid[3:6]);rng=random.Random(16000+number);raws:list[str]=[]
    if number==112:
        def pyramid(x:int,y:int,h:int,size:int)->str:
            coords={(0,0),(0,100),(100,0),(100,100),(x,y)} | {(a,b) for a,b in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if 0<=a<=100 and 0<=b<=100}
            while len(coords)<size:coords.add((rng.randrange(101),rng.randrange(101)))
            return f'{len(coords)}\n'+''.join(f'{a} {b} {max(h-abs(a-x)-abs(b-y),0)}\n' for a,b in sorted(coords))
        raws=['2\n0 0 1\n1 1 0\n']+[pyramid(x,y,h,5+j) for j,(x,y,h) in enumerate([(0,0,1),(100,100,1),(0,100,200),(100,0,200),(50,50,1),(50,50,100),(50,50,101),(1,99,2),(99,1,199),(25,75,50),(75,25,201),(1,1,10),(99,99,10),(30,70,99),(70,30,100),(33,66,1000)])]+[pyramid(100,100,10**9,100)]
    elif number==113:
        def cities(n:int,pairs:list[tuple[int,int]])->str:return f'{n} {len(pairs)}\n'+''.join(f'{p} {y}\n' for p,y in pairs)
        raws=[cities(1,[(1,1)]),cities(100000,[(100000,10**9)]),cities(2,[(1,2),(1,1)]),cities(3,[(3,3),(1,1),(3,2)])]
        for m in range(4,17):
            years=list(range(1,m+1));rng.shuffle(years);raws.append(cities(m,[(rng.randrange(1,m+1),y) for y in years]))
        raws.append(cities(100000,[(100000 if j%2 else 1,10**9-j) for j in range(100000)]))
    elif number==114:raws=[f'{v}\n' for v in (1,2,3,357,356,358,375,537,573,735,753,777,3333,35735,99999,100000000,777777777,999999999)]
    elif number==115:
        def trees(k:int,h:list[int])->str:return f'{len(h)} {k}\n'+''.join(f'{v}\n' for v in h)
        raws=[trees(2,[1,1,1]),trees(2,[1,10**9,1]),trees(2,[1,2,3]),trees(3,[10,1,10,1])]+[trees(2+j%3,[rng.randrange(1,1001) for _ in range(j+4)]) for j in range(1,14)]+[trees(99999,[1]+[10**9]*99999)]
    elif number==116:
        def garden(h:list[int])->str:return f'{len(h)}\n'+line(h)
        raws=[garden([0]),garden([1]),garden([100]),garden([100,0,100])]+[garden([rng.randrange(101) for _ in range(n)]) for n in range(2,15)]+[garden([100 if j%2 else 0 for j in range(100)])]
    else:
        def stream(n:int,x:list[int])->str:return f'{n} {len(x)}\n'+line(x)
        raws=[stream(1,[-100000]),stream(1,[-100000,100000]),stream(2,[-100000,100000]),stream(100000,[0])]+[stream(1+j%4,rng.sample(range(-100,101),j+4)) for j in range(1,13)]+[stream(2,[-100000]+list(range(1,99999))+[100000]),stream(100000,[-100000]+list(range(1,99999))+[100000])]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc112_c':('中心座標は101×101通りなので全候補を調べられます。','高さが正の観測点から、候補の中心ごとの頂点高さを求め、全観測と一致するか確認します。','疑似コード: positive=(x,y,h) with h>0; for Cx,Cy in 0..100: H=h+abs(Cx-x)+abs(Cy-y); if all max(H-distance,0)==observed: print(Cx,Cy,H)。'),
'abc113_c':('同じ県の市を誕生年で並べましょう。','県ごとの年順の順位を元の市番号へ戻し、県番号と順位をそれぞれ6桁にします。','疑似コード: group cities by prefecture; sort each group by year; answer[original_index]=pad6(prefecture)+pad6(rank); print answers in input order。'),
'abc114_c':('使える桁は3、5、7だけです。','これまで使った数字を3ビットで記録し、N以下の数を再帰的に生成します。','疑似コード: dfs(value,mask): if value>N: return; if mask==7: answer+=1; for (digit,bit) in [(3,1),(5,2),(7,4)]: dfs(10*value+digit,mask|bit)。'),
'abc115_c':('木を高さ順に並べると比較しやすくなります。','K本を選ぶとき、最小値と最大値の差を最小にする集合は、ソート順で連続するK本から選べます。','疑似コード: H=sort(heights); answer=min(H[i+K-1]-H[i] for i=0..N-K); print(answer)。'),
'abc116_c':('左から順に必要な水やり回数を考えます。','直前より高さが増えた分だけ、新しい区間への水やりを開始します。','疑似コード: previous=0; answer=0; for h in heights: answer+=max(0,h-previous); previous=h; print(answer)。'),
'abc117_c':('座標をソートし、各コマに連続する地点群を割り当てます。','全体の幅から、コマを分けるN−1個の最大の隙間を除きます。地点数以上のコマがあれば移動不要です。','疑似コード: if N>=M: print(0); else: X=sort(X); gaps=sort(adjacent differences,descending); print(X[-1]-X[0]-sum(gaps[:N-1]))。')}

TITLES={'abc112_c': 'Pyramid', 'abc113_c': 'ID', 'abc114_c': '755', 'abc115_c': 'Christmas Eve', 'abc116_c': 'Grand Garden', 'abc117_c': 'Streamline'}
PUBLISHED_SAMPLES={'abc112_c': [{'input': '4\n2 3 5\n2 1 5\n1 2 5\n3 2 5\n', 'expected': '2 2 6\n'}, {'input': '2\n0 0 100\n1 1 98\n', 'expected': '0 0 100\n'}, {'input': '3\n99 1 191\n100 1 192\n99 0 192\n', 'expected': '100 0 193\n'}], 'abc113_c': [{'input': '2 3\n1 32\n2 63\n1 12\n', 'expected': '000001000002\n000002000001\n000001000001\n'}, {'input': '2 3\n2 55\n2 77\n2 99\n', 'expected': '000002000001\n000002000002\n000002000003\n'}], 'abc114_c': [{'input': '575\n', 'expected': '4\n'}, {'input': '3600\n', 'expected': '13\n'}, {'input': '999999999\n', 'expected': '26484\n'}], 'abc115_c': [{'input': '5 3\n10\n15\n11\n14\n12\n', 'expected': '2\n'}, {'input': '5 3\n5\n7\n5\n7\n7\n', 'expected': '0\n'}], 'abc116_c': [{'input': '4\n1 2 2 1\n', 'expected': '2\n'}, {'input': '5\n3 1 2 3 1\n', 'expected': '5\n'}, {'input': '8\n4 23 75 0 23 96 50 100\n', 'expected': '221\n'}], 'abc117_c': [{'input': '2 5\n10 12 1 2 14\n', 'expected': '5\n'}, {'input': '3 7\n-10 -3 0 9 -100 2 17\n', 'expected': '19\n'}, {'input': '100 1\n-100000\n', 'expected': '0\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}


