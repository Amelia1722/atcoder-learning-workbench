"""Independently authored task-specific input generators and checkers (batch 2).

Official statements/samples: https://atcoder.jp/contests/abcNNN/tasks/abcNNN_x
Do not treat sample agreement or finite cross-checks as universal correctness.
"""
from __future__ import annotations

import random
import re
from bisect import bisect_left
from collections import Counter, defaultdict

BATCH = {
    'abc128_c': {'source_url': 'https://atcoder.jp/contests/abc128/tasks/abc128_c',
                 'sample_input': '2 2\n2 1 2\n1 2\n0 1\n', 'sample_output': '1',
                 'constraints': '1<=N,M<=10; 1<=ki<=N; each bulb has distinct switch indices; pi in {0,1}'},
    'abc155_a': {'source_url': 'https://atcoder.jp/contests/abc155/tasks/abc155_a',
                 'sample_input': '5 7 5\n', 'sample_output': 'Yes',
                 'constraints': '1<=A,B,C<=9'},
    'abc155_b': {'source_url': 'https://atcoder.jp/contests/abc155/tasks/abc155_b',
                 'sample_input': '5\n6 7 9 10 31\n', 'sample_output': 'APPROVED',
                 'constraints': '1<=N<=100; 1<=Ai<=1000'},
    'abc155_c': {'source_url': 'https://atcoder.jp/contests/abc155/tasks/abc155_c',
                 'sample_input': '7\nbeat\nvet\nbeet\nbed\nvet\nbet\nbeet\n',
                 'sample_output': 'beet\nvet',
                 'constraints': '1<=N<=200000; Si lowercase English letters length 1..10'},
    'abc212_c': {'source_url': 'https://atcoder.jp/contests/abc212/tasks/abc212_c',
                 'sample_input': '2 2\n1 6\n4 9\n', 'sample_output': '2',
                 'constraints': '1<=N,M<=200000; 1<=Ai,Bi<=1000000000'},
    'abc251_c': {'source_url': 'https://atcoder.jp/contests/abc251/tasks/abc251_c',
                 'sample_input': '3\naaa 10\nbbb 20\naaa 30\n', 'sample_output': '2',
                 'constraints': '1<=N<=100000; Si lowercase length 1..10; 0<=Ti<=1000000000'},
}

LOWER = re.compile(r'[a-z]{1,10}\Z')


def _numbers(fields: list[str]) -> list[int]:
    if any(not s.isascii() or not s.isdecimal() for s in fields):
        raise ValueError('整数は0以上の10進表記で指定してください')
    return [int(x) for x in fields]


def validate(pid: str, data: str):
    if pid not in BATCH:
        raise ValueError('未対応')
    fields = data.split()
    if pid == 'abc155_a':
        if len(fields) != 3: raise ValueError('A B C の3要素が必要')
        a = _numbers(fields)
        if not all(1 <= x <= 9 for x in a): raise ValueError('値域違反')
        return a
    if pid == 'abc155_b':
        if len(fields) < 2: raise ValueError('N と整数列が必要')
        a = _numbers(fields)
        if not 1 <= a[0] <= 100 or len(a) != a[0] + 1 or not all(1 <= x <= 1000 for x in a[1:]):
            raise ValueError('N/値域/個数違反')
        return a
    if pid == 'abc155_c':
        if not fields: raise ValueError('N が必要')
        n = _numbers(fields[:1])[0]
        if not 1 <= n <= 200_000 or len(fields) != n + 1 or not all(LOWER.fullmatch(s) for s in fields[1:]):
            raise ValueError('票数・文字列長・英小文字制約違反')
        return fields[1:]
    if pid == 'abc251_c':
        if not fields: raise ValueError('N が必要')
        n = _numbers(fields[:1])[0]
        if not 1 <= n <= 100_000 or len(fields) != 2*n+1:
            raise ValueError('提出数・入力個数違反')
        pairs = []
        for i in range(n):
            s, t = fields[2*i+1:2*i+3]
            score = _numbers([t])[0]
            if not LOWER.fullmatch(s) or score > 10**9: raise ValueError('文字列・得点制約違反')
            pairs.append((s, score))
        return pairs
    if pid == 'abc212_c':
        if len(fields) < 4: raise ValueError('N M A B が必要')
        a = _numbers(fields)
        n, m = a[:2]
        if not 1 <= n <= 200_000 or not 1 <= m <= 200_000 or len(a) != n+m+2:
            raise ValueError('N M と配列長違反')
        if not all(1 <= x <= 10**9 for x in a[2:]): raise ValueError('要素値域違反')
        return a[2:2+n],a[2+n:]
    if len(fields) < 4: raise ValueError('スイッチ/電球データが必要')
    n, m = _numbers(fields[:2])
    if not 1 <= n <= 10 or not 1 <= m <= 10: raise ValueError('N M 違反')
    pos = 2
    rows = []
    for _ in range(m):
        if pos >= len(fields): raise ValueError('電球の行数不足')
        k = _numbers(fields[pos:pos+1])[0]
        if not 1 <= k <= n or pos+k >= len(fields): raise ValueError('ki違反')
        switches = _numbers(fields[pos+1:pos+1+k])
        if len(switches) != k or len(set(switches)) != k or not all(1 <= x <= n for x in switches):
            raise ValueError('スイッチ番号に重複・値域違反')
        rows.append(switches)
        pos += k+1
    p = _numbers(fields[pos:])
    if len(p) != m or any(x not in (0,1) for x in p): raise ValueError('pの個数・値域違反')
    return n, rows, p


def _base26(i: int) -> str:
    # Zero-based encoding avoids long strings even at the maximum N.
    chars = []
    while True:
        chars.append(chr(97+i%26))
        i //= 26
        if i == 0: return ''.join(reversed(chars))


def generate(pid: str, count: int, seed: int, include_large: bool):
    if pid not in BATCH or not 1 <= count <= 80: raise ValueError('問題ID/ケース数が不正')
    rnd = random.Random(seed)
    cases = []
    seen = set()

    def add(category: str, data: str):
        validate(pid,data)
        if data not in seen:
            cases.append({'category': category, 'input': data})
            seen.add(data)

    def arr(a: list[int]):
        return f'{len(a)}\n'+ ' '.join(map(str,a))+'\n'

    def strings(a: list[str]):
        return f'{len(a)}\n'+'\n'.join(a)+'\n'

    def poems(a: list[tuple[str,int]]):
        return f'{len(a)}\n'+'\n'.join(f'{s} {t}' for s,t in a)+'\n'

    def switches(n: int, bulbs: list[list[int]], parity: list[int]):
        return f'{n} {len(bulbs)}\n' + ''.join(f'{len(row)} '+ ' '.join(map(str,row))+'\n' for row in bulbs) + ' '.join(map(str,parity))+'\n'

    if pid == 'abc155_a':
        for cat,nums in [('constraint_min',(1,1,1)),('two_equal',(1,1,2)),('all_different',(1,2,3)),
                         ('constraint_max',(9,9,9)),('max_two_equal',(9,9,1)),('order',(9,1,9)),
                         ('usual',(5,7,5))]: add(cat,' '.join(map(str,nums))+'\n')
        while len(cases) < count: add('random',' '.join(str(rnd.randint(1,9)) for _ in range(3))+'\n')
        if include_large: add('constraint_max','9 9 1\n')
    elif pid == 'abc155_b':
        for cat,nums in [('constraint_min',[1]),('single_denied',[2]),('all_odd',[1,7,9]),
                         ('all_approved',[6,10,30]),('one_denied',[6,28,10]),
                         ('max_values',[1000]*4),('usual',[6,7,9,10,31])]: add(cat,arr(nums))
        while len(cases) < count:
            a=[rnd.randint(1,1000) for _ in range(rnd.randint(1,35))]
            add('random',arr(a))
        if include_large: add('constraint_max_n',arr([1000]*99+[998]))
    elif pid == 'abc155_c':
        for cat,words in [('constraint_min',['a']),('all_same',['buffalo']*6),
                          ('tied',['z','a','z','a']),('all_unique',['b','c','a']),
                          ('different_frequency',['a','a','b','b','b']),
                          ('usual',['beat','vet','beet','bed','vet','bet','beet']),
                          ('max_word_length',['abcdefghij','abcdefghij','zyxwvutsrq'])]:add(cat,strings(words))
        while len(cases) < count:
            pool=[_base26(i) for i in range(rnd.randint(1,12))]
            add('random',strings([rnd.choice(pool) for _ in range(rnd.randint(1,50))]))
        if include_large: add('constraint_max_n',strings([_base26(i) for i in range(200_000)]))
    elif pid == 'abc251_c':
        for cat,entries in [('constraint_min',[('a',0)]),('same_later_higher',[('aaa',10),('bbb',20),('aaa',30)]),
                 ('tie_earliest',[('aaa',9),('bbb',10),('ccc',10)]),
                 ('zero_scores',[('a',0),('b',0)]),('late_unique',[('a',10),('b',10),('c',11)]),
                 ('duplicate_only',[('z',1),('z',10),('z',10)]),
                 ('score_max',[('a',10**9),('b',10**9-1)]),
                 ('word_max',[('abcdefghij',100),('abcdefghij',10),('zyxwvutsrq',100)])]:add(cat,poems(entries))
        while len(cases) < count:
            pool=[_base26(i) for i in range(rnd.randint(1,12))]
            entries=[(rnd.choice(pool),rnd.choice([0,1,50,10**9,rnd.randint(0,10**9)])) for _ in range(rnd.randint(1,35))]
            add('random',poems(entries))
        if include_large:
            entries=[(_base26(i%50000),i%101) for i in range(99999)]+[('zzzzzzzzzz',10**9)]
            add('constraint_max_n',poems(entries))
    elif pid == 'abc212_c':
        def two(name,a,b):add(name,f'{len(a)} {len(b)}\n'+' '.join(map(str,a))+'\n'+' '.join(map(str,b))+'\n')
        for cat,a,b in [('constraint_min',[1],[1]),('constraint_max_value',[10**9],[1]),
                        ('same_value',[5],[5]),('usual',[1,6],[4,9]),
                        ('unsorted',[90,10,70],[80,20,12]),('equal_in_middle',[1,99],[10,99]),
                        ('one_sided',[1],[3,2,100,200])]:two(cat,a,b)
        while len(cases)<count:
            n,m=rnd.randint(1,40),rnd.randint(1,40)
            a=[rnd.randint(1,200) for _ in range(n)]
            b=[rnd.randint(1,200) for _ in range(m)]
            two('random',a,b)
        if include_large:
            a=[2*i+1 for i in range(200000)]
            b=[2*i+2 for i in range(200000)]
            two('constraint_max_both',a,b)
    else:
        for cat,n,bulbs,p in [('constraint_min',1,[[1]],[0]),('single_on',1,[[1]],[1]),
                 ('usual',2,[[1,2],[2]],[0,1]),
                 ('inconsistent',2,[[1,2],[1],[2]],[0,0,1]),
                 ('all_free',10,[[1,2]],[0]),
                 ('constraint_max',10,[[1+i%10] for i in range(10)],[0]*10),
                 ('all_parity_zero',10,[list(range(1,11))]*10,[0]*10)]:add(cat,switches(n,bulbs,p))
        while len(cases)<count:
            n,m=rnd.randint(1,10),rnd.randint(1,10)
            bulbs=[sorted(rnd.sample(range(1,n+1),rnd.randint(1,n))) for _ in range(m)]
            p=[rnd.randint(0,1) for _ in range(m)]
            add('random',switches(n,bulbs,p))
        if include_large: add('constraint_max',switches(10,[[i] for i in range(1,11)],[1]*10))
    return cases[:count]+([c for c in cases[count:] if c['category'].startswith('constraint_max')] if include_large else [])


def independent_check(pid: str, data: str, expected: str) -> bool:
    args=validate(pid,data)
    actual=expected.strip()
    if pid == 'abc155_a':
        a,b,c=args
        return actual==('Yes' if (a==b!=c or a==c!=b or b==c!=a) else 'No')
    if pid == 'abc155_b':
        return actual==('DENIED' if any(x%2==0 and x%3 and x%5 for x in args[1:]) else 'APPROVED')
    if pid == 'abc155_c':
        count=defaultdict(int)
        for w in args:count[w]+=1
        maxv=max(count.values())
        words=sorted(w for w,number in count.items() if number==maxv)
        return actual== '\n'.join(words)
    if pid == 'abc251_c':
        first={}
        for i,(name,score) in enumerate(args,1):
            first.setdefault(name,(score,i))
        # sort by score desc, index asc independently of reference's linear max.
        return actual==str(sorted(first.values(),key=lambda x:(-x[0],x[1]))[0][1])
    if pid == 'abc212_c':
        a,b=args
        if len(a)*len(b)<=10000:
            value=min(abs(x-y) for x in a for y in b)
        else:
            b.sort()
            value=10**9
            for x in a:
                i=bisect_left(b,x)
                if i<len(b):value=min(value,abs(x-b[i]))
                if i:value=min(value,abs(x-b[i-1]))
        return actual==str(value)
    n,bulbs,p=args
    # Independent GF(2) equation rank: solutions = 2^(N-rank), if consistent.
    equations=[]
    for row,bit in zip(bulbs,p):
        mask=0
        for switch in row:mask^=1<<(switch-1)
        equations.append(mask|(bit<<n))
    rank=0
    for bit in range(n):
        pivot=next((j for j in range(rank,len(equations)) if (equations[j]>>bit)&1),None)
        if pivot is None:continue
        equations[rank],equations[pivot]=equations[pivot],equations[rank]
        for j in range(len(equations)):
            if j!=rank and (equations[j]>>bit)&1: equations[j]^=equations[rank]
        rank+=1
    inconsistent=any((row&((1<<n)-1))==0 and (row>>n)&1 for row in equations)
    return actual==str(0 if inconsistent else 1<<(n-rank))
