"""Reviewed C tasks with threshold search, orientation tries and cycle peeling."""
from __future__ import annotations
from collections import Counter,deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(309,315))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc311_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==309:
        n,k=ints(rows[0],2);require(1<=n<=300000 and 0<=k<=10**9 and len(rows)==n+1,'shape');medicine=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for pair in medicine for v in pair),'prescription');return k,medicine
    if number==310:
        n=ints(rows[0],1)[0];strings=tuple(rows[1:]);require(2<=n<=200000 and len(strings)==n and sum(map(len,strings))<=200000 and all(re.fullmatch('[a-z]+',s) is not None for s in strings),'sticks');return (strings,)
    if number in (311,313):
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require((2<=n<=200000 if number==311 else 1<=n<=200000),'length');a=ints(rows[1],n);require(all(1<=v<=n and v!=j for j,v in enumerate(a,1)) if number==311 else all(1<=v<=10**9 for v in a),'values');return (a,)
    if number==312:
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(1<=n<=200000 and 1<=m<=200000,'length');a=ints(rows[1],n);b=ints(rows[2],m);require(all(1<=v<=10**9 for seq in (a,b) for v in seq),'prices');return a,b
    require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(1<=m<=n<=200000 and re.fullmatch('[a-z]+',rows[1]) is not None and len(rows[1])==n,'string');colors=ints(rows[2],n);require(set(colors)==set(range(1,m+1)),'all colors');return rows[1],colors

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==309:
        k,medicine=cast(tuple[int,tuple[tuple[int,int],...]],data);low=0;high=max(a for a,b in medicine)+1
        while high-low>1:
            middle=(low+high)//2
            if sum(b for a,b in medicine if a>=middle)<=k:high=middle
            else:low=middle
        return str(high)
    if number==310:
        strings=cast(tuple[str,...],data[0]);children:list[dict[str,int]]=[{}];terminal=[False];orientations=palindromes=0
        for s in strings:
            for oriented in (s,s[::-1]):
                node=0
                for ch in oriented:
                    if ch not in children[node]:children[node][ch]=len(children);children.append({});terminal.append(False)
                    node=children[node][ch]
                if not terminal[node]:terminal[node]=True;orientations+=1;palindromes+=oriented==oriented[::-1]
        return str((orientations+palindromes)//2)
    if number==311:
        a=cast(tuple[int,...],data[0]);degree=[0]*len(a)
        for v in a:degree[v-1]+=1
        pending=deque(j for j,d in enumerate(degree) if d==0)
        while pending:
            nxt=a[pending.popleft()]-1;degree[nxt]-=1
            if degree[nxt]==0:pending.append(nxt)
        start=next(j for j,d in enumerate(degree) if d);cycle=[start+1];j=a[start]-1
        while j!=start:cycle.append(j+1);j=a[j]-1
        return str(len(cycle))+'\n'+' '.join(map(str,cycle))
    if number==312:
        a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);events=Counter(a)
        for price in b:events[price+1]+=1
        balance=-len(b)
        for price,delta in sorted(events.items()):
            balance+=delta
            if balance>=0:return str(price)
        raise ValueError('missing threshold')
    if number==313:
        a=cast(tuple[int,...],data[0]);floor=sum(a)//len(a);deficit=sum(max(floor-v,0) for v in a);excess=sum(max(v-floor-1,0) for v in a);return str(max(deficit,excess))
    s,colors=cast(tuple[str,tuple[int,...]],data);last:dict[int,str]={}
    for ch,color in zip(s,colors):last[color]=ch
    out=[]
    for ch,color in zip(s,colors):out.append(last[color]);last[color]=ch
    return ''.join(out)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc311_c':
            a=cast(tuple[int,...],validate(pid,raw)[0]);rows=actual.removesuffix('\n').split('\n');require(len(rows)==2,'cycle rows');m=ints(rows[0],1)[0];require(2<=m<=len(a),'cycle size');cycle=ints(rows[1],m);require(len(set(cycle))==m and all(1<=v<=len(a) for v in cycle),'vertices');return all(a[u-1]==v for u,v in zip(cycle,cycle[1:]+cycle[:1]))
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc311_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc309_c':"n,k=map(int,input().split());medicine=sorted(tuple(map(int,input().split())) for _ in range(n));total=sum(b for a,b in medicine);answer=1\nfor a,b in medicine:\n if total<=k:break\n total-=b;answer=a+1\nprint(answer)\n",
'abc310_c':"n=int(input());unique=set()\nfor _ in range(n):\n s=input();unique.add(min(s,s[::-1]))\nprint(len(unique))\n",
'abc311_c':"n=int(input());a=list(map(int,input().split()));position={};path=[];j=1\nwhile j not in position:position[j]=len(path);path.append(j);j=a[j-1]\ncycle=path[position[j]:];print(len(cycle));print(*cycle)\n",
'abc312_c':"from bisect import bisect_left,bisect_right\nn,m=map(int,input().split());a=sorted(map(int,input().split()));b=sorted(map(int,input().split()));low=0;high=1000000001\nwhile high-low>1:\n middle=(low+high)//2\n if bisect_right(a,middle)>=m-bisect_left(b,middle):high=middle\n else:low=middle\nprint(high)\n",
'abc313_c':"n=int(input());a=sorted(map(int,input().split()));q,r=divmod(sum(a),n);target=[q]*(n-r)+[q+1]*r;print(sum(abs(v-w) for v,w in zip(a,target))//2)\n",
'abc314_c':"n,m=map(int,input().split());s=input();colors=list(map(int,input().split()));positions=[[] for _ in range(m)]\nfor j,c in enumerate(colors):positions[c-1].append(j)\nout=list(s)\nfor group in positions:\n for j,p in enumerate(group):out[p]=s[group[j-1]]\nprint(''.join(out))\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16900+number)
    if number==309:
        def medicine(k:int,pairs:list[tuple[int,int]])->str:return f'{len(pairs)} {k}\n'+''.join(line(pair) for pair in pairs)
        raws=[medicine(0,[(1,1)]),medicine(1,[(1,1)]),medicine(2,[(1,1),(1,2)]),medicine(2,[(1,1),(2,2)])];raws.extend(medicine(rng.randint(0,100),[(rng.randint(1,100),rng.randint(1,20)) for _ in range(n)]) for n in range(3,15));raws.extend([medicine(0,[(j+1,10**9) for j in range(300000)]),medicine(10**9,[(10**9,10**9)]*300000)])
    elif number==310:
        def sticks(s:list[str])->str:return f'{len(s)}\n'+'\n'.join(s)+'\n'
        raws=[sticks(['a','a']),sticks(['a','b']),sticks(['ab','ba']),sticks(['aa','aa','a'])];raws.extend(sticks([''.join(rng.choice('abc') for _ in range(rng.randint(1,10))) for _ in range(n)]) for n in range(3,15));raws.extend([sticks(['a'*99999+'b','b'+'a'*99999]),sticks(['z']*200000)])
    elif number==311:
        def mapping(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[mapping([2,1]),mapping([2,3,1]),mapping([2,1,4,3]),mapping([2,3,2])]
        for n in range(5,17):raws.append(mapping([rng.choice([v for v in range(1,n+1) if v!=j]) for j in range(1,n+1)]))
        raws.extend([mapping(list(range(2,200001))+[199999]),mapping(list(range(2,200001))+[1])])
    elif number==312:
        def market(a:list[int],b:list[int])->str:return f'{len(a)} {len(b)}\n'+line(a)+line(b)
        raws=[market([1],[1]),market([2],[1]),market([1],[2]),market([3,3],[1,2])];raws.extend(market([rng.randint(1,100) for _ in range(n)],[rng.randint(1,100) for _ in range(n+2)]) for n in range(3,15));raws.extend([market([10**9]*200000,[1]*200000),market([10**9]*200000,[10**9]*200000)])
    elif number==313:
        def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[array(a) for a in ([1],[1,1],[1,2],[1,3])];raws.extend(array([rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([array([1]*100000+[10**9]*100000),array([10**9]*200000)])
    else:
        def colored(s:str,colors:list[int])->str:return f'{len(s)} {max(colors)}\n{s}\n'+line(colors)
        raws=[colored('a',[1]),colored('ab',[1,1]),colored('ab',[1,2]),colored('abc',[1,2,1])]
        for n in range(4,16):
            m=rng.randint(1,n);colors=list(range(1,m+1))+[rng.randint(1,m) for _ in range(n-m)];rng.shuffle(colors);raws.append(colored(''.join(rng.choice('abc') for _ in range(n)),colors))
        raws.extend([colored('abcdefghijklmnopqrstuvwxyz'*7692+'abcdefgh',[(j%3)+1 for j in range(200000)]),colored('z'*200000,list(range(1,200001)))])
    require(len(raws)==len(set(raws))==18,'unique cases')
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc309_c':('日が進むと必要な薬の数は増えません。','薬を終了日でソートし、終了した分を総数から引きます。K以下になった翌日が答えです。','疑似コード: total=sum(b); answer=1; (a,b)をa順に走査; total<=Kなら終了; total-=b; answer=a+1; answerを出力。'),
'abc310_c':('文字列とその反転は同じ棒を表します。','文字列と反転の辞書順で小さい方を代表にすると、同じ棒の代表が一致します。','疑似コード: seen=空集合; 各Sでseen.add(min(S,reverse(S))); len(seen)を出力。'),
'abc311_c':('各頂点の出口が1つなので、辺をたどり続けると頂点を再訪します。','頂点の初回訪問位置と訪問列を記録し、再訪した頂点からの区間を切り出します。','疑似コード: v=1; vが未訪問の間、位置を記録してpathに追加しv=A[v]へ進む; cycle=path[position[v]:]; 長さとcycleを出力。'),
'abc312_c':('価格を上げると売り手は増え、買い手は減ります。','ソートした価格列で人数を二分探索し、条件を満たす最小価格も二分探索します。','疑似コード: A,Bをsort; low=0, high=10^9+1; midでcount(A<=mid)>=count(B>=mid)ならhigh=mid、他はlow=mid; highを出力。'),
'abc313_c':('総和は変わらず、最終値は平均の切り捨てか切り上げです。','Aをソートし、余りの個数だけ末尾を平均+1、他を平均にする目標列と比べます。','疑似コード: A=sort(A); q,r=divmod(sum(A),N); target=[q]*(N-r)+[q+1]*r; sum(abs(A[i]-target[i]))/2を出力。'),
'abc314_c':('同じ色の文字位置を左から並べます。','各色の位置列で、直前の位置の元の文字を現在の位置へ移します。先頭は末尾から受け取ります。','疑似コード: 色別にpositionsを作る; out=Sのコピー; 各色でout[positions[j]]=S[positions[j-1]]; outを出力。')}

TITLES={'abc309_c': 'Medicine', 'abc310_c': 'Reversible', 'abc311_c': 'Find it!', 'abc312_c': 'Invisible Hand', 'abc313_c': 'Approximate Equalization 2', 'abc314_c': 'Rotate Colored Subsequence'}
PUBLISHED_SAMPLES={'abc309_c': [{'input': '4 8\n6 3\n2 5\n1 9\n4 2\n', 'expected': '3\n'}, {'input': '4 100\n6 3\n2 5\n1 9\n4 2\n', 'expected': '1\n'}, {'input': '15 158260522\n877914575 2436426\n24979445 61648772\n623690081 33933447\n476190629 62703497\n211047202 71407775\n628894325 31963982\n822804784 50968417\n430302156 82631932\n161735902 80895728\n923078537 7723857\n189330739 10286918\n802329211 4539679\n303238506 17063340\n492686568 73361868\n125660016 50287940\n', 'expected': '492686569\n'}], 'abc310_c': [{'input': '6\na\nabc\nde\ncba\nde\nabc\n', 'expected': '3\n'}], 'abc311_c': [{'input': '7\n6 7 2 1 3 4 5\n', 'expected': '4\n7 5 3 2\n'}, {'input': '2\n2 1\n', 'expected': '2\n1 2\n'}, {'input': '8\n3 7 4 7 3 3 8 2\n', 'expected': '3\n2 7 8\n'}], 'abc312_c': [{'input': '3 4\n110 90 120\n100 80 120 10000\n', 'expected': '110\n'}, {'input': '5 2\n100000 100000 100000 100000 100000\n100 200\n', 'expected': '201\n'}, {'input': '3 2\n100 100 100\n80 120\n', 'expected': '100\n'}], 'abc313_c': [{'input': '4\n4 7 3 7\n', 'expected': '3\n'}, {'input': '1\n313\n', 'expected': '0\n'}, {'input': '10\n999999997 999999999 4 3 2 4 999999990 8 999999991 999999993\n', 'expected': '2499999974\n'}], 'abc314_c': [{'input': '8 3\napzbqrcs\n1 2 3 1 2 2 1 2\n', 'expected': 'cszapqbr\n'}, {'input': '2 1\naa\n1 1\n', 'expected': 'aa\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
