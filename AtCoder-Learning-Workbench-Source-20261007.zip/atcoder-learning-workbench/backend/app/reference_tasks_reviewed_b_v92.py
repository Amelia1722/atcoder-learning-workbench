"""ABC134–136 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc134_b', 'abc135_b', 'abc136_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)


def _split(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(token) is None for token in parts):
        raise ValueError('noncanonical positive integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc134_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        n, d = _split(lines[0], 2)
        if not 1 <= n <= 20 or not 1 <= d <= 20:
            raise ValueError('N/D range')
        return n, d

    if pid == 'abc135_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and permutation row')
        n = int(lines[0])
        if not 2 <= n <= 50:
            raise ValueError('N range')
        p = _split(lines[1], n)
        if sorted(p) != list(range(1, n + 1)):
            raise ValueError('not a permutation')
        return p

    if len(lines) != 1 or POS.fullmatch(lines[0]) is None:
        raise ValueError('expected one positive integer')
    n = int(lines[0])
    if not 1 <= n <= 100_000:
        raise ValueError('N range')
    return n


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc134_b':
        if POS.fullmatch(output) is None:
            return False
        n, d = value
        # Interval-DP over the length of an already-covered prefix.  This is
        # deliberately independent of the closed-form ceil(N/(2D+1)).
        inf = n + 1
        dp = [inf] * (n + 1)
        dp[0] = 0
        for covered in range(n):
            if dp[covered] == inf:
                continue
            target = covered + 1  # first uncovered 1-indexed tree
            for inspector in range(1, n + 1):
                left = max(1, inspector - d)
                right = min(n, inspector + d)
                if left <= target <= right:
                    nxt = max(covered, right)
                    if dp[covered] + 1 < dp[nxt]:
                        dp[nxt] = dp[covered] + 1
        return output == str(dp[n])

    if pid == 'abc135_b':
        if output not in {'YES', 'NO'}:
            return False
        p = value
        mismatch = sum(x != i + 1 for i, x in enumerate(p))
        return output == ('YES' if mismatch in (0, 2) else 'NO')

    if POS.fullmatch(output) is None:
        return False
    n = value
    # Count by decimal-length intervals, independent of a per-number loop.
    expected = 0
    for lo, hi in ((1, 9), (100, 999), (10_000, 99_999)):
        if n >= lo:
            expected += min(n, hi) - lo + 1
    return output == str(expected)


def _nd(n: int, d: int) -> str:
    return f'{n} {d}\n'


def _perm(p: list[int]) -> str:
    return f'{len(p)}\n' + ' '.join(map(str, p)) + '\n'


def _n(n: int) -> str:
    return f'{n}\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc134_b':
        fixed = [
            ('sample1',6,2), ('sample2',14,3), ('sample3',20,4),
            ('minimum',1,1), ('one_tree_large_d',1,20), ('two_one_radius',2,1),
            ('three_one_radius',3,1), ('four_one_radius',4,1), ('five_one_radius',5,1),
            ('exact_one_span',7,3), ('just_over_one_span',8,3), ('exact_two_spans',10,2),
            ('just_over_two_spans',15,3), ('d_equals_n',10,10), ('d_greater_than_n',10,20),
            ('small_d_large_n',20,1), ('medium',19,2),
        ]
        for category, n, d in fixed:
            add(category, _nd(n, d))
        add('constraint_max', _nd(20, 20))

    elif pid == 'abc135_b':
        fixed = [
            ('sample1',[5,2,3,4,1]), ('sample2',[2,4,3,5,1]),
            ('sample3',[1,2,3,4,5,6,7]), ('minimum_sorted',[1,2]),
            ('minimum_swapped',[2,1]), ('n3_one_swap',[1,3,2]), ('n3_cycle',[2,3,1]),
            ('n4_end_swap',[4,2,3,1]), ('n4_two_disjoint_swaps',[2,1,4,3]),
            ('n5_adjacent_swap',[1,3,2,4,5]), ('n5_three_cycle',[2,3,1,4,5]),
            ('n6_middle_swap',[1,2,5,4,3,6]), ('n6_reverse',[6,5,4,3,2,1]),
            ('n8_sorted',list(range(1,9))), ('n8_far_swap',[1,7,3,4,5,6,2,8]),
            ('n10_cycle',[2,3,4,5,1,6,7,8,9,10]),
            ('n20_end_swap',[20,*range(2,20),1]),
        ]
        for category, p in fixed:
            add(category, _perm(list(p)))
        p = list(range(1, 51))
        p[0], p[-1] = p[-1], p[0]
        add('constraint_max', _perm(p))

    else:
        fixed = [
            ('sample1',11), ('sample2',136), ('near_max',99998),
            ('minimum',1), ('one_digit_max',9), ('two_digit_min',10), ('two_digit',42),
            ('two_digit_max',99), ('three_digit_min',100), ('three_digit_next',101),
            ('three_digit_max',999), ('four_digit_min',1000), ('four_digit',1234),
            ('four_digit_max',9999), ('five_digit_min',10000), ('five_digit_mid',54321),
            ('five_digit_max',99999),
        ]
        for category, n in fixed:
            add(category, _n(n))
        add('constraint_max', _n(100000))

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
