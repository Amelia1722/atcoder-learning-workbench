"""Three-stage task-specific hints for the first mixed B/C batch."""
from __future__ import annotations
HINTS_V154: dict[str, tuple[str,str,str]] = {
'abc465_b': ('停めた時間を1時間ずつ調べます。','時刻hがL以上R未満ならX、それ以外ならYです。','疑似コード: ans=0; h=A..B-1で ans+=(L<=h<R ? X : Y); print(ans)。'),
'abc466_b': ('色ごとに最大値を保存します。','未登場を-1で初期化し、ボールごとに更新します。','疑似コード: ans[M]=-1; 各(C,S)で ans[C-1]=max(ans[C-1],S); ansを出力。'),
'abc467_b': ('受け取らなかったお釣りだけが損失です。','keepの店のB-Aを合計します。','疑似コード: ans=0; 各(A,B,S)で S==keepならans+=B-A; print(ans)。'),
'abc468_b': ('各ガードマンが監視する区間を印付けします。','区間を盤面内へ切り詰め、重複しても一度だけ数えます。','疑似コード: watched[M]=false; 各Gの位置iで j=max(0,i-D)..min(M-1,i+D)をtrue; falseの個数を出力。'),
'abc469_b': ('自身と左右の席を確認します。','両端では存在する隣だけを確認します。','疑似コード: ans=0; 各iで S[i]==x かつ (i==0またはS[i-1]==x) かつ (i==N-1またはS[i+1]==x)ならans++; print(ans)。'),
'abc470_b': ('最も多い色へ揃えると変更が最少です。','Nから最大出現回数を引きます。','疑似コード: count=Counter(C); print(N-max(count.values()))。'),
'abc471_b': ('比較前に英字を小文字へ揃えます。','小文字化した回答の頻度を数えます。','疑似コード: count=Counter(lower(S[i]) for i=1..N); print(max(count.values()))。'),
'abc472_b': ('切れ込みの左右の長さを計算します。','全体の和totalと左側の累積和leftを使います。','疑似コード: total=sum(L); left=0; ans=total; i=0..N-2で left+=L[i]; ans=min(ans,abs(total-2*left)); print(ans)。'),
'abc473_b': ('同じ数のカードは2枚ずつ消えます。','出現回数が奇数の数だけ1枚残ります。','疑似コード: count=Counter(A); print(sum(value for value in count if count[value]%2==1))。'),
'abc474_b': ('各退場位置と座席のグループ番号を比較します。','0-indexed退場位置iのグループはi//10、座席pは(p-1)//10です。','疑似コード: 全iで i//10==(P[i]-1)//10 ならYes、それ以外No。'),
'abc475_b': ('購入ごとのお釣りは0〜999円です。','お釣りを100円、10円、1円の順に分解し、各枚数を累積します。','疑似コード: coins=[0,0,0]; 各Aで change=(-A)%1000; coins[2]+=change//100; coins[1]+=change//10%10; coins[0]+=change%10; coinsを出力。'),
'abc001_3': ('風向と風力を別々に求めます。','風速の四捨五入は整数で(dis+3)//6として小数第1位の10倍を求めます。風力0ならCです。','疑似コード: speed=(Dis+3)//6; W=超えた風速上限の数; direction=dirs[((Deg*10+1125)//2250)%16]; print(W==0 ? C : direction,W)。'),
'abc002_3': ('1つの頂点を原点へ平行移動します。','2辺の外積の絶対値を2で割ると面積です。','疑似コード: ux=xb-xa; uy=yb-ya; vx=xc-xa; vy=yc-ya; print(abs(ux*vy-uy*vx)/2)。'),
'abc003_3': ('高いレートの動画を選び、最後ほど高い動画を見ます。','上位K個を選んで昇順に視聴すると最大です。','疑似コード: sort(R); C=0; Rの末尾K個を昇順に取り出し C=(C+r)/2; print(C)。'),
'abc004_3': ('5回の操作で先頭のカードが末尾へ移ります。','6回の循環、つまり30回で元に戻ります。','疑似コード: cards=123456; i=0..N%30-1で j=i%5; swap(cards[j],cards[j+1]); cardsを連結出力。'),
'abc005_3': ('客を到着順に処理し、売れる最古のたこ焼きを使います。','期限切れを飛ばし、残りが未完成ならその客をすぐ捌けません。','疑似コード: i=0; 各Bで while i<N and A[i]+T<B: i++; i==NまたはA[i]>Bならno; それ以外i++; 全員へ売れたらyes。'),
'abc006_3': ('全員を大人とした場合から足の増分を考えます。','extra=M-2*Nです。赤ちゃんは2、老人は1ずつ増やします。0<=extra<=2*Nが必要です。','疑似コード: extra=M-2*N; 範囲外ならprint(-1,-1,-1); それ以外 baby=extra//2; old=extra%2; adult=N-baby-old; print(adult,old,baby)。'),
'abc007_3': ('近いマスから順に最短距離を確定します。','FIFOキューで上下左右の未訪問の空きマスへ距離+1を割り当てます。','疑似コード: dist=-1; dist[start]=0; queue=[start]; while queue非空: v=pop_front(); 各隣uが空きマスかつ未訪問なら dist[u]=dist[v]+1; push(u); print(dist[goal])。'),
}
