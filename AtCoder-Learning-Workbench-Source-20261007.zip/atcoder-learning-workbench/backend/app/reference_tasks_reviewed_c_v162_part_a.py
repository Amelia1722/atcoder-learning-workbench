"""Reviewed ABC157--160,162--163 C with original strict domains."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from fractions import Fraction
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in (157,158,159,160,162,163))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc159_c':'numeric_tolerance_1e-6'}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'field count');return values

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==157:
        n,m=ints(rows[0],2);require(1<=n<=3 and 0<=m<=5 and len(rows)==m+1,'shape');claims=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=p<=n and 0<=c<=9 for p,c in claims),'digits');return n,claims
    if number==158:
        require(len(rows)==1,'shape');a,b=ints(rows[0],2);require(1<=a<=b<=100,'taxes');return a,b
    if number in (159,162):
        require(len(rows)==1,'shape');value=ints(rows[0],1)[0];require(1<=value<=(1000 if number==159 else 200),'size');return (value,)
    if number==160:
        k,n=ints(rows[0],2);require(2<=k<=1000000 and 2<=n<=200000 and len(rows)==2,'shape');a=ints(rows[1],n);require(0<=a[0] and a[-1]<k and all(x<y for x,y in zip(a,a[1:])),'circle positions');return k,a
    n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==2,'shape');bosses=ints(rows[1],n-1);require(all(1<=boss<employee for employee,boss in enumerate(bosses,2)),'supervisor');return (bosses,)

def gcd_divisor_sum(k:int)->int:
    phi=list(range(k+1))
    for prime in range(2,k+1):
        if phi[prime]==prime:
            for value in range(prime,k+1,prime):phi[value]-=phi[value]//prime
    return sum(phi[d]*(k//d)**3 for d in range(1,k+1))

def volume_exact(length:int)->Fraction:return Fraction(length**3,27)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==157:
        n,claims=cast(tuple[int,tuple[Pair,...]],data);digits:list[int|None]=[None]*n
        for p,c in claims:
            if digits[p-1] is not None and digits[p-1]!=c:return '-1'
            digits[p-1]=c
        if n>1 and digits[0]==0:return '-1'
        result=[d if d is not None else (1 if j==0 and n>1 else 0) for j,d in enumerate(digits)];return ''.join(map(str,result))
    if number==158:
        a,b=cast(tuple[int,int],data);lower=max((100*a+7)//8,10*b);upper=min((100*(a+1)-1)//8,10*(b+1)-1);return str(lower if lower<=upper else -1)
    if number==159:return format(float(volume_exact(cast(int,data[0]))),'.17g')
    if number==160:
        k,a=cast(tuple[int,tuple[int,...]],data);n=len(a);doubled=a+tuple(x+k for x in a);return str(min(doubled[j+n-1]-doubled[j] for j in range(n)))
    if number==162:return str(gcd_divisor_sum(cast(int,data[0])))
    bosses=cast(tuple[int,...],data[0]);ordered=sorted(bosses);return '\n'.join(str(bisect_right(ordered,j)-bisect_left(ordered,j)) for j in range(1,len(bosses)+2))

def numeric_volume_valid(raw:str,actual:str)->bool:
    try:
        length=cast(int,validate('abc159_c',raw)[0]);token=actual.removesuffix('\n')
        if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
        exponent=re.search(r'[eE]([+-]?[0-9]+)$',token)
        if exponent and abs(int(exponent[1]))>1000:return False
        expected=volume_exact(length);return abs(Fraction(token)-expected)<=max(Fraction(1),expected)/1000000
    except (ValueError,TypeError,IndexError,OverflowError,ZeroDivisionError):return False

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc159_c':return numeric_volume_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc159_c':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc157_c':"n,m=map(int,input().split());rules=[tuple(map(int,input().split())) for _ in range(m)];answer=-1\nfor value in range(1000):\n text=str(value)\n if len(text)==n and all(int(text[s-1])==c for s,c in rules):answer=value;break\nprint(answer)\n",
'abc158_c':"a,b=map(int,input().split());answer=-1\nfor price in range(1,2001):\n if price*8//100==a and price*10//100==b:answer=price;break\nprint(answer)\n",
'abc159_c':"length=int(input());side=length/3;print(side*side*side)\n",
'abc160_c':"k,n=map(int,input().split());a=list(map(int,input().split()));gaps=[y-x for x,y in zip(a,a[1:])]+[k+a[0]-a[-1]];print(k-max(gaps))\n",
'abc162_c':"from math import gcd\nk=int(input());answer=0\nfor a in range(1,k+1):\n for b in range(1,k+1):\n  d=gcd(a,b)\n  for c in range(1,k+1):answer+=gcd(d,c)\nprint(answer)\n",
'abc163_c':"n=int(input());bosses=list(map(int,input().split()));counts=[0]*n\nfor boss in bosses:counts[boss-1]+=1\nprint('\\n'.join(map(str,counts)))\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16200+number);raws:list[str]=[]
    if number==157:
        def guess(n:int,rules:list[Pair])->str:return f'{n} {len(rules)}\n'+''.join(line(rule) for rule in rules)
        specs=[(1,[]),(2,[]),(3,[]),(1,[(1,0)]),(1,[(1,9)]),(2,[(1,0)]),(3,[(2,0),(3,0)]),(3,[(1,7),(3,2),(1,7)]),(3,[(2,1),(2,3)]),(2,[(2,9)]),(3,[(1,9)]),(1,[(1,1),(1,2)]),(2,[(1,1),(2,0)]),(3,[(3,9),(2,9)]),(3,[(1,1),(1,1),(1,1),(1,1),(1,1)]),(2,[(1,1),(2,1),(1,1),(2,2),(1,1)]),(3,[(1,9),(2,9),(3,9)]),(3,[(1,9),(2,9),(3,9),(1,9),(3,9)])];raws=[guess(n,rules) for n,rules in specs]
    elif number==158:raws=[line(p) for p in ((1,1),(1,2),(2,2),(2,3),(8,10),(19,99),(80,100),(79,99),(99,100),(7,9),(3,4),(4,5),(5,6),(10,10),(32,40),(63,80),(80,99),(100,100))]
    elif number==159:raws=[f'{v}\n' for v in (1,2,3,4,5,6,7,8,9,10,11,30,100,333,334,998,999,1000)]
    elif number==160:
        def circle(k:int,a:list[int])->str:return f'{k} {len(a)}\n'+line(a)
        raws=[circle(2,[0,1]),circle(3,[0,1]),circle(3,[0,2]),circle(4,[0,2])]+[circle(1000,sorted(rng.sample(range(1000),n))) for n in range(3,15)]+[circle(1000000,list(range(0,1000000,5))),circle(1000000,list(range(199999))+[999999])]
    elif number==162:raws=[f'{k}\n' for k in (1,2,3,4,5,6,7,8,9,10,12,20,30,50,100,150,199,200)]
    else:
        def company(bosses:list[int])->str:return f'{len(bosses)+1}\n'+line(bosses)
        raws=[company([1]),company([1,1]),company([1,2]),company([1,1,1])]+[company([rng.randrange(1,j) for j in range(2,n+1)]) for n in range(4,16)]+[company(list(range(1,200000))),company([1]*199999)]
    require(len(raws)==len(set(raws))==18,'18 unique cases')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc157_c':('候補は最大でも0から999までです。','各整数の十進表記がN桁かと、すべての指定された桁が一致するかを調べます。','疑似コード: for value=0..999: if len(str(value))==N and all digits match constraints: print(value); stop; print(-1)。'),
'abc158_c':('税抜き価格は、B円の10%税になる範囲へ絞れます。','小数の誤差を避け、価格×8÷100と価格×10÷100の整数切り捨てで判定します。','疑似コード: for price=1..2000: if price*8//100==A and price*10//100==B: print(price); stop; print(-1)。'),
'abc159_c':('縦・横・高さの合計が一定なら、三つを等しくすると積が最大になります。','相加相乗平均の不等式より、それぞれL/3にすると最大体積です。','疑似コード: side=L/3; print(side*side*side)。'),
'abc160_c':('家と家の間の一区間だけを通らない経路を考えます。','最長の隙間を除くと移動距離が最小になります。最後の家から最初の家への周回区間も含めます。','疑似コード: gaps=adjacent differences+[K+A[0]-A[-1]]; print(K-max(gaps))。'),
'abc162_c':('Kは200以下なので、三つの整数の全組合せを試せます。','二つの最大公約数を先に求め、それと三つ目の整数の最大公約数を足します。','疑似コード: answer=0; for a,b,c in 1..K: answer+=gcd(gcd(a,b),c); print(answer)。'),
'abc163_c':('各社員が誰の直属の部下かを、上司ごとに数えます。','各A_iについて、対応する上司の部下数を一つ増やします。','疑似コード: counts=[0]*N; for boss in A: counts[boss-1]+=1; print each counts value on separate line。')}

TITLES={'abc157_c': 'Guess The Number', 'abc158_c': 'Tax Increase', 'abc159_c': 'Maximum Volume', 'abc160_c': 'Traveling Salesman around Lake', 'abc162_c': 'Sum of gcd of Tuples (Easy)', 'abc163_c': 'management'}
PUBLISHED_SAMPLES={'abc157_c': [{'input': '3 3\n1 7\n3 2\n1 7\n', 'expected': '702\n'}, {'input': '3 2\n2 1\n2 3\n', 'expected': '-1\n'}, {'input': '3 1\n1 0\n', 'expected': '-1\n'}], 'abc158_c': [{'input': '2 2\n', 'expected': '25\n'}, {'input': '8 10\n', 'expected': '100\n'}, {'input': '19 99\n', 'expected': '-1\n'}], 'abc159_c': [{'input': '3\n', 'expected': '1.000000000000\n'}, {'input': '999\n', 'expected': '36926037.000000000000\n'}], 'abc160_c': [{'input': '20 3\n5 10 15\n', 'expected': '10\n'}, {'input': '20 3\n0 5 15\n', 'expected': '10\n'}], 'abc162_c': [{'input': '2\n', 'expected': '9\n'}, {'input': '200\n', 'expected': '10813692\n'}], 'abc163_c': [{'input': '5\n1 1 2 2\n', 'expected': '2\n2\n0\n0\n0\n'}, {'input': '10\n1 1 1 1 1 1 1 1 1\n', 'expected': '9\n0\n0\n0\n0\n0\n0\n0\n0\n0\n'}, {'input': '7\n1 2 3 4 5 6\n', 'expected': '1\n1\n1\n1\n1\n1\n0\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
