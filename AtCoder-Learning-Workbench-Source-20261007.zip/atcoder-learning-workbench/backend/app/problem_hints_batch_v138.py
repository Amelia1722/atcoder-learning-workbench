"""Statement-checked three-stage hints for ABC272–274 B."""
HINTS_V138 = {
 'abc272_b': (
  '必要条件は「人の全ての2人組」について、どこか1回の舞踏会で同席していることです。まず各舞踏会から、その参加者同士の組を記録すると考えてみてください。',
  'N≤100なので、N×Nの真偽表を用意し、各舞踏会の参加者の全2人組をTrueにできます。最後に1≤i<j≤Nを全部確認すれば十分です。',
  '疑似コード:\nmet[N][N] = false\nM回:\n  read participants\n  for each pair (a,b) in participants:\n    met[a][b] = met[b][a] = true\nfor 1<=a<b<=N:\n  if not met[a][b]: print("No"); stop\nprint("Yes")',
 ),
 'abc273_b': (
  'i回目では10^(i+1)の倍数へ四捨五入します。小さい桁から順に丸めるので、毎回その時点のXを更新していけばよいです。',
  '10^(i+1)をpとすると、Xをpで割った余りがp/2以上なら次の倍数へ、それ未満なら直前の倍数へ丸めます。整数演算だけで処理できます。',
  '疑似コード:\nfor i=0..K-1:\n  p = 10^(i+1)\n  q, r = divmod(X, p)\n  if 2*r >= p: q += 1\n  X = q*p\nprint(X)',
 ),
 'abc274_b': (
  '求めるのは各列にある#の数です。行ごとではなく「列jを固定して全行を見る」と考えるとそのまま数えられます。',
  '長さWのcount配列を0で作り、各行の各文字を走査して#なら対応する列のcountを1増やします。H×W≤10^6マスなので全走査で十分です。',
  '疑似コード:\ncount[1..W] = 0\nfor i=1..H:\n  read row\n  for j=1..W:\n    if row[j] == "#": count[j] += 1\nprint(count[1], ..., count[W])',
 ),
}
