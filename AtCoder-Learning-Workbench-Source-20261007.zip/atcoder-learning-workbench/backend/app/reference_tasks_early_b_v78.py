"""ABC092–094 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc092_b','abc093_b','abc094_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc092_b':
        if len(lines)<3 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
        n=int(lines[0]); parts=lines[1].split(' ')
        if len(parts)!=2 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('D X')
        d,x=map(int,parts)
        if not (1<=n<=100 and 1<=d<=100 and 1<=x<=100) or len(lines)!=n+2:
            raise ValueError('range/lines')
        a=[]
        for s in lines[2:]:
            if POS.fullmatch(s) is None: raise ValueError('Ai')
            v=int(s)
            if not 1<=v<=100: raise ValueError('Ai range')
            a.append(v)
        return n,d,x,a
    if pid=='abc093_b':
        if len(lines)!=1: raise ValueError('lines')
        parts=lines[0].split(' ')
        if len(parts)!=3 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('format')
        a,b,k=map(int,parts)
        if not (1<=a<=b<=10**9 and 1<=k<=100): raise ValueError('range')
        return a,b,k
    if len(lines)!=2: raise ValueError('lines')
    first=lines[0].split(' ')
    second=lines[1].split(' ')
    if len(first)!=3 or any(POS.fullmatch(x) is None for x in first): raise ValueError('header')
    n,m,x=map(int,first)
    if not (1<=n<=100 and 1<=m<=100 and 1<=x<=n-1): raise ValueError('range')
    if len(second)!=m or any(POS.fullmatch(s) is None for s in second): raise ValueError('gates')
    gates=list(map(int,second))
    if gates!=sorted(gates) or len(set(gates))!=m: raise ValueError('order/unique')
    if any(not 1<=v<=n-1 or v==x for v in gates): raise ValueError('gate range')
    return n,m,x,gates


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc092_b':
        _,d,x,a=value
        total=x
        for step in a:
            day=1
            while day<=d:
                total+=1; day+=step
        return output==str(total)
    if pid=='abc093_b':
        a,b,k=value
        left=range(a,min(b,a+k-1)+1)
        right=range(max(a,b-k+1),b+1)
        chosen=sorted(set(left)|set(right))
        return output=='\n'.join(map(str,chosen))
    _,_,x,gates=value
    left=sum(v<x for v in gates); right=sum(v>x for v in gates)
    return output==str(min(left,right))


def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc092_b':
        vals=[
            (1,1,1,[1]),(1,100,100,[100]),(1,100,1,[1]),(2,8,20,[1,10]),
            (3,7,1,[2,5,10]),(5,30,44,[26,18,81,18,6]),(4,10,5,[2,2,2,2]),
            (4,10,5,[11,12,13,14]),(6,99,7,[1,2,3,4,5,100]),(10,50,50,[7]*10),
            (25,25,25,list(range(1,26))),(50,2,99,[1 if i%2==0 else 100 for i in range(50)]),
            (75,75,1,[100]*75),(99,100,1,[1]*99),(100,1,100,[1]*100),
            (100,100,1,[100]*100),(100,99,99,[1+(i%100) for i in range(100)]),
        ]
        for n,d,x,a in vals:
            add('boundary' if n in (1,99,100) or d in (1,100) else 'normal',str(n)+'\n'+f'{d} {x}\n'+'\n'.join(map(str,a))+'\n')
        add('constraint_max','100\n100 100\n'+'\n'.join(['1']*100)+'\n')
    elif pid=='abc093_b':
        vals=[
            (1,1,1),(1,2,1),(1,3,1),(1,5,2),(3,8,2),(4,8,3),(2,9,100),
            (10,20,5),(10,20,6),(100,1000,1),(100,1000,100),(999999900,10**9,50),
            (10**9,10**9,100),(1,10**9,1),(2,999999999,100),(123456789,123456999,100),
            (999999999,10**9,1),
        ]
        for a,b,k in vals:
            add('boundary' if a==b or a==1 or b==10**9 or k==100 else 'normal',f'{a} {b} {k}\n')
        add('constraint_max','1 1000000000 100\n')
    else:
        vals=[
            (3,1,1,[2]),(3,1,2,[1]),(4,1,2,[1]),(4,1,2,[3]),(5,3,3,[1,2,4]),
            (7,3,2,[4,5,6]),(10,7,5,[1,2,3,4,6,8,9]),(10,1,5,[1]),
            (10,1,5,[9]),(10,2,5,[1,9]),(20,10,10,[1,2,3,4,5,11,12,13,14,15]),
            (50,25,25,list(range(1,25))+[26]),(100,1,1,[99]),(100,1,99,[1]),
            (100,50,50,list(range(1,50))+[51]),(100,97,50,[v for v in range(1,99) if v!=50]),
            (99,97,49,[v for v in range(1,99) if v!=49]),
        ]
        for n,m,x,gates in vals:
            add('boundary' if n in (3,99,100) or m in (1,98) else 'normal',f'{n} {m} {x}\n'+' '.join(map(str,gates))+'\n')
        gates=[v for v in range(1,100) if v!=50]
        add('constraint_max','100 98 50\n'+' '.join(map(str,gates))+'\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
