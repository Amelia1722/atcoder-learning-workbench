"""ABC176–178 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc176_b', 'abc177_b', 'abc178_b')
NONNEG = re.compile(r'0|[1-9][0-9]*', re.ASCII)
INT = re.compile(r'0|-?[1-9][0-9]*', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc176_b': [
        {'input':'123456789\n','expected':'Yes\n'},
        {'input':'0\n','expected':'Yes\n'},
        {'input':'31415926535897932384626433832795028841971693993751058209749445923078164062862089986280\n','expected':'No\n'},
    ],
    'abc177_b': [
        {'input':'cabacc\nabc\n','expected':'1\n'},
        {'input':'codeforces\natcoder\n','expected':'6\n'},
    ],
    'abc178_b': [
        {'input':'1 2 1 1\n','expected':'2\n'},
        {'input':'3 5 -4 -2\n','expected':'-6\n'},
        {'input':'-1000000000 0 -1000000000 0\n','expected':'1000000000000000000\n'},
    ],
}

def _integer(token: str) -> int:
    if INT.fullmatch(token) is None:
        raise ValueError('noncanonical integer')
    return int(token)

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc176_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        s = lines[0]
        if not s or len(s) > 200_000 or NONNEG.fullmatch(s) is None:
            raise ValueError('N format/range')
        return s
    if pid == 'abc177_b':
        if len(lines) != 2:
            raise ValueError('expected two rows')
        s, t = lines
        if not (1 <= len(s) <= 1000 and 1 <= len(t) <= 1000 and len(t) <= len(s)):
            raise ValueError('length range')
        if LOWER.fullmatch(s) is None or LOWER.fullmatch(t) is None:
            raise ValueError('lowercase only')
        return s, t
    if len(lines) != 1:
        raise ValueError('expected one row')
    parts = lines[0].split(' ')
    if len(parts) != 4:
        raise ValueError('expected four integers')
    a,b,c,d = map(_integer, parts)
    if not (-10**9 <= a <= b <= 10**9 and -10**9 <= c <= d <= 10**9):
        raise ValueError('range/order')
    return a,b,c,d

def _answer_176(s: str) -> str:
    return 'Yes' if sum(ord(ch)-48 for ch in s) % 9 == 0 else 'No'

def _answer_177(s: str, t: str) -> int:
    m=len(t)
    return min(sum(a!=b for a,b in zip(s[i:i+m],t)) for i in range(len(s)-m+1))

def _answer_178(a: int,b: int,c: int,d: int) -> int:
    return max(a*c,a*d,b*c,b*d)

def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value=validate(pid,raw)
    except (ValueError,TypeError,IndexError):
        return False
    if not isinstance(output,str) or not output or output != output.strip():
        return False
    if pid=='abc176_b':
        return output in ('Yes','No') and output == _answer_176(value)
    if re.fullmatch(r'0|-?[1-9][0-9]*',output,re.ASCII) is None:
        return False
    if pid=='abc177_b':
        s,t=value
        return output == str(_answer_177(s,t))
    a,b,c,d=value
    return output == str(_answer_178(a,b,c,d))

def _177(s:str,t:str)->str:
    return s+'\n'+t+'\n'

def _178(a:int,b:int,c:int,d:int)->str:
    return f'{a} {b} {c} {d}\n'

def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category:str, raw:str):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc176_b':
        cases=[
            ('sample1','123456789'),('sample2','0'),
            ('sample3','31415926535897932384626433832795028841971693993751058209749445923078164062862089986280'),
            ('one_digit_yes','9'),('one_digit_no','8'),('two_digit_yes','18'),('two_digit_no','19'),
            ('many_zeros','9000000000000000000000000000000000000000'),
            ('all_nines_100','9'*100),('all_ones_9','1'*9),('all_ones_10','1'*10),
            ('alternating_90','90'*50),('alternating_18','18'*73),
            ('length_999','123456789'*111),('length_10000','1'*9999+'8'),
            ('length_50000','1234567890'*5000),('length_199999','1'*199998+'9'),
        ]
        for cat,s in cases: add(cat,s+'\n')
        add('constraint_max','9'*200000+'\n')
    elif pid=='abc177_b':
        cases=[
            ('sample1','cabacc','abc'),('sample2','codeforces','atcoder'),
            ('same_one','a','a'),('diff_one','a','z'),('equal_same','abc','abc'),('equal_all_diff','abc','xyz'),
            ('match_prefix','abcdef','abc'),('match_suffix','abcdef','def'),('match_middle','zabcx','abc'),
            ('one_change_middle','zzabxzz','abc'),('overlap_choices','aaaaa','aaa'),
            ('t_len_one','abcdefghij','f'),('s_len_20','abcdefghijklmnopqrst','qrst'),
            ('repeated_pattern','abcabcabcabc','bcab'),('all_diff_long','a'*100,'b'*50),
            ('near_max_equal','a'*999,'a'*999),('near_max_shift','a'*999+'b','b'*999),
        ]
        for cat,s,t in cases: add(cat,_177(s,t))
        add('constraint_max',_177('a'*500+'b'*500,'b'*1000))
    else:
        cases=[
            ('sample1',1,2,1,1),('sample2',3,5,-4,-2),('sample3',-10**9,0,-10**9,0),
            ('all_positive',2,7,3,11),('all_negative',-9,-2,-8,-3),('x_negative_y_positive',-10,-1,2,9),
            ('x_cross_y_positive',-5,7,2,3),('x_positive_y_cross',2,3,-5,7),('both_cross',-5,7,-9,11),
            ('single_points',4,4,-3,-3),('zero_x',0,0,-10,10),('zero_y',-10,10,0,0),
            ('unit_ranges',-1,1,-1,1),('large_positive',999999999,10**9,999999998,10**9),
            ('large_negative',-10**9,-999999999,-10**9,-999999998),
            ('mixed_extreme',-10**9,10**9,-1,1),('negative_answer',1,1,-10**9,-999999999),
        ]
        for row in cases: add(row[0],_178(*row[1:]))
        add('constraint_max',_178(-10**9,10**9,-10**9,10**9))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
