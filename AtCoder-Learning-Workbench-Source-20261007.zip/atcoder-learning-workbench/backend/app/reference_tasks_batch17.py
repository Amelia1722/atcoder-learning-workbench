"""Four manually reviewed early ABC A tasks; no unreviewed shared grammar inference.

Sources: https://atcoder.jp/contests/abc002/tasks/abc002_1
         https://atcoder.jp/contests/abc003/tasks/abc003_1
         https://atcoder.jp/contests/abc004/tasks/abc004_1
         https://atcoder.jp/contests/abc005/tasks/abc005_1
The public pages were reviewed using web access; raw official HTML is NOT archived.
"""
from __future__ import annotations
import random
import re

SAMPLES = {
    'abc002_1': ('10 11\n', '11', '0 <= X,Y <= 1000000000; X != Y'),
    'abc003_1': ('6\n', '35000', '4 <= N <= 100; output error <= 1e-6'),
    'abc004_1': ('1000\n', '2000', '0 <= N <= 1000000'),
    'abc005_1': ('4 8\n', '2', '1 <= x,y <= 100'),
}
BATCH17 = {pid: {
    'sample_input': inp, 'sample_output': out,
    'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
    'constraints': constraints,
} for pid, (inp, out, constraints) in SAMPLES.items()}
_CANONICAL_UINT = re.compile(r'(?:0|[1-9][0-9]*)\Z')


def validate(pid: str, data: str) -> tuple[int, ...]:
    if pid not in BATCH17 or not isinstance(data, str):
        raise ValueError('unregistered problem / invalid input')
    # The original statements use a single line with 1 or 2 ASCII integer tokens.
    if not data.endswith('\n') or data.count('\n') != 1:
        raise ValueError('one newline-terminated line required')
    tokens = data[:-1].split(' ')
    if len(tokens) != (1 if pid in ('abc003_1', 'abc004_1') else 2):
        raise ValueError('wrong number of integer tokens')
    if any(not _CANONICAL_UINT.fullmatch(s) for s in tokens):
        raise ValueError('only canonical nonnegative ASCII integers')
    args = tuple(map(int, tokens))
    if pid == 'abc002_1' and (not all(0 <= x <= 10**9 for x in args) or args[0] == args[1]):
        raise ValueError('X,Y must be distinct and in [0,10**9]')
    if pid == 'abc003_1' and not 4 <= args[0] <= 100:
        raise ValueError('N out of [4,100]')
    if pid == 'abc004_1' and not 0 <= args[0] <= 10**6:
        raise ValueError('N out of [0,10**6]')
    if pid == 'abc005_1' and not all(1 <= x <= 100 for x in args):
        raise ValueError('x,y out of [1,100]')
    return args


# Kept separately from the test-bank JSON, which stores only input and expected.
# The categories here are generation intent; not authenticated statement evidence.
_FIXTURES: dict[str, list[tuple[str, tuple[int, ...]]]] = {
    'abc002_1': [
        ('constraint_min', (0, 1)), ('constraint_min', (1, 0)),
        ('typical', (10, 11)), ('typical', (100000000, 10000000)),
        ('boundary', (499999999, 500000000)), ('boundary', (500000000, 499999999)),
        ('boundary', (999999999, 1000000000)), ('boundary', (1000000000, 999999999)),
        ('constraint_max', (0, 1000000000)), ('constraint_max', (1000000000, 0)),
    ],
    'abc003_1': [
        ('constraint_min', (4,)), ('boundary', (5,)), ('typical', (6,)),
        ('boundary', (7,)), ('typical', (50,)), ('boundary', (99,)),
        ('constraint_max', (100,)),
    ],
    'abc004_1': [
        ('constraint_min', (0,)), ('boundary', (1,)), ('typical', (1000,)),
        ('typical', (123456,)), ('boundary', (999999,)),
        ('constraint_max', (1000000,)),
    ],
    'abc005_1': [
        ('constraint_min', (1, 1)), ('boundary', (1, 100)),
        ('boundary', (100, 1)), ('typical', (4, 8)),
        ('typical', (4, 7)), ('boundary', (4, 3)),
        ('boundary', (99, 100)), ('boundary', (100, 99)),
        ('constraint_max', (100, 100)),
    ],
}


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str, str]]:
    if pid not in BATCH17 or not 4 <= count <= 80:
        raise ValueError('invalid task / count')
    rng = random.Random(f'{seed}:{pid}')
    values = list(_FIXTURES[pid])
    seen = set()
    cases: list[dict[str, str]] = []

    def add(category: str, args: tuple[int, ...]) -> None:
        text = ' '.join(map(str, args)) + '\n'
        validate(pid, text)
        if text not in seen:
            cases.append({'category': category, 'input': text})
            seen.add(text)

    # Reserve a maximum-limit case explicitly rather than relying on a slice.
    max_case = next(args for cat, args in values if cat == 'constraint_max')
    for cat, args in values:
        if cat != 'constraint_max':
            add(cat, args)
    tries = 0
    while len(cases) < count and tries < 2000:
        tries += 1
        if pid == 'abc002_1':
            a, b = rng.randrange(10**9 + 1), rng.randrange(10**9 + 1)
            if a == b:
                continue
            args = (a, b)
        elif pid == 'abc003_1':
            args = (rng.randint(4, 100),)
        elif pid == 'abc004_1':
            args = (rng.randint(0, 10**6),)
        else:
            args = (rng.randint(1, 100), rng.randint(1, 100))
        add('random', args)
    # If fixture list exceeds count, preserve ordinary/random diversity and a max case.
    cases = cases[:count]
    if include_large:
        # abc002_1 has two distinct endpoints; at least one max case is included.
        text = ' '.join(map(str, max_case)) + '\n'
        cases = [item for item in cases if item['input'] != text]
        cases.append({'category': 'constraint_max', 'input': text})
    return cases


def independent_check(pid: str, data: str, expected: str) -> bool:
    args = validate(pid, data)
    if pid == 'abc002_1':
        answer = sorted(args)[-1]
    elif pid == 'abc003_1':
        # Sum each equiprobable outcome instead of using the reference's (N+1)/2.
        n, = args
        answer = 10000 * sum(range(1, n+1)) // n
    elif pid == 'abc004_1':
        answer = sum(args * 2)
    else:
        x, y = args
        answer = 0
        while y >= x:
            y -= x
            answer += 1
    return expected == str(answer)
