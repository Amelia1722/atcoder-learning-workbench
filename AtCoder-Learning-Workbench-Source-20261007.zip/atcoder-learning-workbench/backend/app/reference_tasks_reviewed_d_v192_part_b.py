"""Private ABC246--251 D exact inputs and construction semantics."""
from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import Counter
from math import isqrt
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(246,252));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc251_d':'semantic'}
CHECKER_IDS={'abc251_d':'abc251_d'}
Case=dict[str,str]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid in ('abc246_d','abc250_d','abc251_d'):
  require(len(r)==1,'shape');n=ints(r[0],1)[0];require((0 if pid=='abc246_d' else 1)<=n<=(10**6 if pid=='abc251_d' else 10**18),'N/W');return (n,)
 if pid=='abc247_d':
  q=ints(r[0],1)[0];require(1<=q<=200000 and len(r)==q+1,'Q');queries=tuple(ints(s) for s in r[1:]);balls=0
  for row in queries:
   require(row[0] in (1,2) and len(row)==(3 if row[0]==1 else 2),'query shape')
   if row[0]==1:require(0<=row[1]<=10**9 and 1<=row[2]<=10**9,'x/c');balls+=row[2]
   else:require(1<=row[1]<=10**9 and row[1]<=balls,'available balls');balls-=row[1]
  return (queries,)
 n=ints(r[0],1)[0];require(1<=n<=200000,'N');a=ints(r[1],n)
 if pid=='abc249_d':require(len(r)==2 and all(1<=v<=200000 for v in a),'Ai');return (a,)
 require(all(1<=v<=n for v in a) and len(r)>=4,'Ai/shape');q=ints(r[2],1)[0];require(1<=q<=200000 and len(r)==q+3,'Q');queries=tuple(ints(s,3) for s in r[3:]);require(all(1<=l<=rr<=n and 1<=x<=n for l,rr,x in queries),'L/R/X');return a,queries

def cube_root(n:int)->int:
 if n==0:return 0
 x=1<<((n.bit_length()+2)//3)
 while True:
  y=(2*x+n//(x*x))//3
  if y>=x:
   while (x+1)**3<=n:x+=1
   while x**3>n:x-=1
   return x
  x=y

def cubic_sum_discriminant(n:int)->int:
 if n==0:return 0
 lower=cube_root(n);lower+=lower**3<n;answer=lower**3
 # X=(s^3+s*d^2)/2, s=a+b, d=|a-b|, with d and s same parity.
 for s in range(lower,cube_root(2*answer)+2):
  if (s**3+(s&1)*s)//2>answer:break
  required=max(0,(2*n+s-1)//s-s*s);d=isqrt(required);d+=d*d<required
  if (s-d)&1:d+=1
  if d<=s:answer=min(answer,s*(s*s+d*d)//2)
 return answer

def cylinder_prefix(queries:tuple[tuple[int,...],...])->list[int]:
 cumulative_count=[0];cumulative_sum=[0];values=[];removed=previous_sum=0;out=[]
 for row in queries:
  if row[0]==1:
   _,x,c=row;values.append(x);cumulative_count.append(cumulative_count[-1]+c);cumulative_sum.append(cumulative_sum[-1]+x*c)
  else:
   removed+=row[1];j=bisect_left(cumulative_count,removed);total=cumulative_sum[j-1]+(removed-cumulative_count[j-1])*values[j-1];out.append(total-previous_sum);previous_sum=total
 return out

def range_endpoint_sweep(a:tuple[int,...],queries:tuple[tuple[int,int,int],...])->list[int]:
 events=[]
 for j,(left,right,x) in enumerate(queries):events.append((right,j,x,1));events.append((left-1,j,x,-1))
 events.sort();counts=[0]*(len(a)+1);answer=[0]*len(queries);position=0
 for endpoint,j,x,sign in events:
  while position<endpoint:counts[a[position]]+=1;position+=1
  answer[j]+=sign*counts[x]
 return answer

def product_divisors(a:tuple[int,...])->int:
 counts=Counter(a);maximum=max(a);spf=list(range(maximum+1))
 for p in range(2,isqrt(maximum)+1):
  if spf[p]==p:
   for v in range(p*p,maximum+1,p):
    if spf[v]==v:spf[v]=p
 answer=0
 for value,multiplicity in counts.items():
  divisors=[1];x=value
  while x>1:
   p=spf[x];power=1;original=divisors[:]
   while x%p==0:x//=p;power*=p;divisors.extend(v*power for v in original)
  answer+=multiplicity*sum(counts[d]*counts[value//d] for d in divisors)
 return answer

def primes_euler(limit:int)->list[int]:
 least=[0]*(limit+1);primes=[]
 for v in range(2,limit+1):
  if least[v]==0:least[v]=v;primes.append(v)
  for p in primes:
   if p>least[v] or p*v>limit:break
   least[p*v]=p
 return primes

def prime_cubes_by_p(n:int)->int:
 primes=primes_euler(cube_root(n//2));answer=0
 for i,p in enumerate(primes):
  bound=cube_root(n//p);j=bisect_right(primes,bound)
  if j<=i+1:break
  answer+=j-i-1
 return answer

def weights_base101()->list[int]:return list(range(1,101))+[101*i for i in range(1,101)]+[10201*i for i in range(1,99)]

def weights_cover(w:int,weights:tuple[int,...])->bool:
 if not 1<=w<=10**6 or not 1<=len(weights)<=300 or not all(1<=v<=10**6 for v in weights):return False
 mask=(1<<(w+1))-1;one=two=three=0
 for weight in weights:
  # Descending cardinalities prevent reusing this physical index.
  three|=(two<<weight)&mask;two|=(one<<weight)&mask;one|=(1<<weight)&mask
 return ((one|two|three)&mask)==mask-1

def weights_valid(w:int,actual:str)->bool:
 rows=actual.removesuffix('\n').split('\n')
 if len(rows)!=2:return False
 try:
  n=ints(rows[0],1)[0];weights=ints(rows[1],n)
  return weights_cover(w,weights)
 except (ValueError,IndexError,OverflowError):return False

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc246_d':return str(cubic_sum_discriminant(cast(int,d[0])))+'\n'
 if pid=='abc247_d':return ''.join(str(v)+'\n' for v in cylinder_prefix(cast(tuple[tuple[int,...],...],d[0])))
 if pid=='abc248_d':return ''.join(str(v)+'\n' for v in range_endpoint_sweep(cast(tuple[int,...],d[0]),cast(tuple[tuple[int,int,int],...],d[1])))
 if pid=='abc249_d':return str(product_divisors(cast(tuple[int,...],d[0])))+'\n'
 if pid=='abc250_d':return str(prime_cubes_by_p(cast(int,d[0])))+'\n'
 weights=weights_base101();return str(len(weights))+'\n'+line(weights)

def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc251_d':return weights_valid(cast(int,d[0]),actual)
  expected=oracle(pid,raw);tokens=actual.split();return len(tokens)==len(expected.split()) and all(re.fullmatch(r'-?(?:0|[1-9][0-9]*)',s) is not None for s in tokens) and tuple(map(int,tokens))==tuple(map(int,expected.split()))
 except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'abc246_d':'''n=int(input());answer=10**19;b=10**6
for a in range(10**6+1):
 while b>=0:
  value=(a+b)*(a*a+b*b)
  if value<n:break
  answer=min(answer,value);b-=1
print(answer)
''',
'abc247_d':'''import sys
from collections import deque
it=iter(map(int,sys.stdin.buffer.read().split()));q=next(it);queue=deque();out=[]
for _ in range(q):
 kind=next(it)
 if kind==1:queue.append([next(it),next(it)])
 else:
  needed=next(it);answer=0
  while needed:
   x,count=queue[0];taken=min(needed,count);answer+=x*taken;needed-=taken;queue[0][1]-=taken
   if queue[0][1]==0:queue.popleft()
  out.append(str(answer))
sys.stdout.write('\\n'.join(out)+('\\n' if out else ''))
''',
'abc248_d':'''import sys
from bisect import bisect_left,bisect_right
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);positions=[[] for _ in range(n+1)]
for i in range(1,n+1):positions[next(it)].append(i)
q=next(it);out=[]
for _ in range(q):l=next(it);r=next(it);x=next(it);out.append(str(bisect_right(positions[x],r)-bisect_left(positions[x],l)))
print('\\n'.join(out))
''',
'abc249_d':'''import sys
from collections import Counter
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a=[next(it) for _ in range(n)];limit=max(a);counts=[0]*(limit+1)
for x in a:counts[x]+=1
answer=0
for denominator in range(1,limit+1):
 if not counts[denominator]:continue
 for product in range(denominator,limit+1,denominator):answer+=counts[product]*counts[denominator]*counts[product//denominator]
print(answer)
''',
'abc250_d':'''from bisect import bisect_left,bisect_right
n=int(input());limit=1000000;prime=bytearray(b'\\x01')*(limit+1);prime[:2]=b'\\x00\\x00'
for p in range(2,1001):
 if prime[p]:prime[p*p::p]=b'\\x00'*((limit-p*p)//p+1)
primes=[p for p in range(2,limit+1) if prime[p]];answer=0
for i,q in enumerate(primes):
 if 2*q*q*q>n:break
 answer+=min(i,bisect_right(primes,n//(q*q*q)))
print(answer)
''',
'abc251_d':'''w=int(input());a=list(range(1,101))+[100*i for i in range(1,101)]+[10000*i for i in range(1,101)];print(len(a));print(*a)
'''}

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(192000+int(pid[3:6]));raws:list[str]=[]
 if pid=='abc246_d':
  numbers=[0,1,2,9,15,16,10**6,10**9,10**12,10**15,10**18-1,999999999989449206,54,250,999999,123456789012345,10**18-10**9,10**18];raws=[str(n)+'\n' for n in numbers]
 elif pid=='abc247_d':
  def queries(q:list[tuple[int,...]])->str:return str(len(q))+'\n'+''.join(line(row) for row in q)
  raws=[queries([(1,0,1)]),queries([(1,0,1),(2,1)]),queries([(1,10**9,10**9),(2,10**9)]),queries([(1,2,3),(2,2),(1,3,4),(2,3)]),queries([(1,1,1)]*5)]
  for i in range(10):
   q=[];active=0
   for j in range(20+i*10):
    if not active or rng.randrange(3):x=rng.randint(0,10**9);c=rng.randint(1,10**9);q.append((1,x,c));active+=c
    else:c=rng.randint(1,min(active,10**9));q.append((2,c));active-=c
   raws.append(queries(q))
  raws.append(queries([(1,10**9,10**9)]*200000));raws.append(queries([(1,10**9,10**9)]*1981+[(2,10**7)]*198010+[(2,10**8)]*9));raws.append(queries([(1,10**9,10**9),(2,10**9)]*100000))
 elif pid=='abc248_d':
  def array(a:list[int],q:list[tuple[int,int,int]])->str:return str(len(a))+'\n'+line(a)+str(len(q))+'\n'+''.join(line(row) for row in q)
  raws=[array([1],[(1,1,1)]),array([1,1],[(1,2,2)]),array([1,2,1],[(1,3,1),(2,2,1),(2,3,2)]),array([1,2,3],[(1,3,3),(3,3,1)])]
  for i in range(12):
   n=5+i*7;a=[rng.randrange(1,n+1) for _ in range(n)];q=[]
   for j in range(10+i*5):l=rng.randint(1,n);rr=rng.randint(l,n);q.append((l,rr,rng.randint(1,n)))
   raws.append(array(a,q))
  raws.append(array(list(range(1,200001)),[(1,200000,j+1) for j in range(200000)]));raws.append(array([200000]*200000,[(1,200000,200000)]*200000))
 elif pid=='abc249_d':
  def array(a:list[int])->str:return str(len(a))+'\n'+line(a)
  raws=[array([1]),array([2]),array([6,2,3]),array([1,1,1]),array([200000,1,2,100000])]
  for i in range(10):raws.append(array([rng.randint(1,200000) for _ in range(5+i*13)]))
  raws.append(array([1]*200000));raws.append(array(list(range(1,200001))));raws.append(array([200000]*200000))
 elif pid=='abc250_d':
  numbers=[1,53,54,55,249,250,251,16,27,10**6,10**9,10**12,123456789012345,10**15,10**18-1,2*99991**3,3*99991**3,10**18];raws=[str(n)+'\n' for n in numbers]
 else:raws=[str(w)+'\n' for w in [1,2,3,6,12,99,100,101,102,9999,10000,10200,10201,10202,999697,999698,999999,1000000]]
 require(len(raws)==len(set(raws))==18,'18 distinct')
 cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'reviewed_{j:02d}'})
 return cases

TITLES={'abc246_d': '2-variable Function',
 'abc247_d': 'Cylinder',
 'abc248_d': 'Range Count Query',
 'abc249_d': 'Index Trio',
 'abc250_d': '250-like Number',
 'abc251_d': 'At Most 3 (Contestant ver.)'}
PUBLISHED_SAMPLES={'abc246_d': [{'input': '9\n', 'expected': '15\n'},
              {'input': '0\n', 'expected': '0\n'},
              {'input': '999999999989449206\n', 'expected': '1000000000000000000\n'}],
 'abc247_d': [{'input': '4\n1 2 3\n2 2\n1 3 4\n2 3\n', 'expected': '4\n8\n'},
              {'input': '2\n1 1000000000 1000000000\n2 1000000000\n',
               'expected': '1000000000000000000\n'},
              {'input': '5\n1 1 1\n1 1 1\n1 1 1\n1 1 1\n1 1 1\n', 'expected': '\n'}],
 'abc248_d': [{'input': '5\n3 1 4 1 5\n4\n1 5 1\n2 4 3\n1 5 2\n1 3 3\n',
               'expected': '2\n0\n0\n1\n'}],
 'abc249_d': [{'input': '3\n6 2 3\n', 'expected': '2\n'},
              {'input': '1\n2\n', 'expected': '0\n'},
              {'input': '10\n1 3 2 4 6 8 2 2 3 7\n', 'expected': '62\n'}],
 'abc250_d': [{'input': '250\n', 'expected': '2\n'},
              {'input': '1\n', 'expected': '0\n'},
              {'input': '123456789012345\n', 'expected': '226863\n'}],
 'abc251_d': [{'input': '6\n', 'expected': '3\n1 2 3\n'},
              {'input': '12\n', 'expected': '6\n2 5 1 2 5 1\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
HINTS={'abc246_d': ('式は(a+b)(aの二乗+bの二乗)と書けます。非負のa,bを増やすと値も増えます。',
              'aを小さい順に動かし、条件を満たす境界のbを下げていくと、全ての組を二重に列挙する必要がありません。a,bはそれぞれ1000000以下まで見れば十分です。',
              '疑似コード: '
              'b=1000000,answer=INF。a=0..1000000で、b>=0かつf(a,b)>=Nの間answer=min(answer,f(a,b)),b--。fがN未満になったら次のaへ。answerを出力。'),
 'abc247_d': ('同じ数のボールが大量に入るため、一個ずつ保存する必要はありません。',
              '筒の順序を保って、値と個数の組をキューに保存します。取り出すときは先頭の組から必要な個数だけ消費してください。',
              '疑似コード: 追加1 x cならdeque末尾へ(x,c)。取り出し2 '
              'cなら、先頭のcountとcの小さい方takeを選びsum+=x*take、両countからtakeを引く。count0なら先頭を削除。c0まで繰り返しsum出力。取り出しが一度もない入力も合法。'),
 'abc248_d': ('同じ値が現れる位置だけに注目すると、区間内の個数を数えやすくなります。',
              '各値Xについて出現位置を昇順に保存します。区間の右端以下の位置数から、左端未満の位置数を引きます。',
              '疑似コード: '
              'Aを左から読みpositions[A[i]]へiを追加。query(L,R,X)ではbisect_right(positions[X],R)-bisect_left(positions[X],L)を出力。'),
 'abc249_d': ('条件はA_i=A_j*A_kと同じです。i,j,kは互いに異なる必要がありません。',
              '各値の出現回数を集め、分母に当たる値dと、その倍数vを列挙します。積となるvと、相手v/dの出現回数を掛け合わせます。',
              '疑似コード: '
              'freqを作る。各dでfreq[d]>0ならv=d,2d,...,maxAについてanswer+=freq[v]*freq[d]*freq[v/d]。1が多い場合も同じindexの再使用を禁止しない。'),
 'abc250_d': ('素数p<qを選ぶと、p*qの三乗ではなくp*q^3が対象です。',
              '素数をふるいで列挙します。大きい方qを固定すると、pはq未満かつN/q^3以下の素数なので、二分探索で個数を求められます。',
              '疑似コード: '
              'primesを1000000以下まで作る。qを昇順に見て2*q^3>Nなら終了。answer+=min(qのindex,bisect_right(primes,N//q^3))。異なる素数対は素因数分解の一意性で異なる数を表す。'),
 'abc251_d': ('必要なのは重さの種類の数ではなく、おもりの個数です。同じ重さを持つ別のおもりを用意することもできます。',
              '100進数の三つの桁を、それぞれ一個のおもりで表します。1..100、100..10000の100の倍数、10000..1000000の10000の倍数を用意しましょう。',
              '疑似コード: weights=[i for i=1..100]+[100*i for i=1..100]+[10000*i for '
              'i=1..100]、N=300を出力。1..999999は100進数の各非zero桁に対応する異なるindexを最大3個選ぶ。1000000は単独で用意済み。重さがWを超えても1..1000000内なら合法。')}
