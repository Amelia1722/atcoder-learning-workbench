from __future__ import annotations
from collections import deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(335,341));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES={'abc335_d':'semantic'};CHECKER_IDS={'abc335_d':'abc335_d'};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,n:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v

def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc335_d':require(len(r)==1,'rows');n=ints(r[0],1)[0];require(3<=n<=45 and n%2==1,'oddN');return (n,)
 if pid=='abc336_d':
  n=ints(r[0],1)[0];require(1<=n<=200000 and len(r)==2,'N');a=ints(r[1],n);require(all(1<=v<=10**9 for v in a),'Ai');return (a,)
 if pid=='abc337_d':
  h,w,k=ints(r[0],3);require(h>=1 and w>=1 and h*w<=200000 and 1<=k<=max(h,w) and len(r)==h+1 and all(len(s)==w and re.fullmatch(r'[ox.]+',s) is not None for s in r[1:]),'grid');return k,tuple(r[1:])
 if pid=='abc338_d':
  n,m=ints(r[0],2);require(3<=n<=200000 and 2<=m<=200000 and len(r)==2,'N/M');a=ints(r[1],m);require(all(1<=v<=n for v in a) and all(x!=y for x,y in zip(a,a[1:])),'islands');return n,a
 if pid=='abc339_d':
  n=ints(r[0],1)[0];require(2<=n<=60 and len(r)==n+1 and all(len(s)==n and re.fullmatch(r'[P.#]+',s) is not None for s in r[1:]) and sum(s.count('P') for s in r[1:])==2,'grid');return (tuple(r[1:]),)
 n=ints(r[0],1)[0];require(2<=n<=200000 and len(r)==n,'N');stages=tuple(ints(s,3) for s in r[1:]);require(all(1<=a<=10**9 and 1<=b<=10**9 and 1<=x<=n for a,b,x in stages),'stage');return (stages,)

def dragon_layers(n:int)->str:
 board=[['T']*n for _ in range(n)];path=[]
 for low in range(n//2):
  high=n-1-low;path.extend((r,low) for r in range(low,high+1));path.extend((high,c) for c in range(low+1,high+1));path.extend((r,high) for r in range(high-1,low-1,-1));path.extend((low,c) for c in range(high-1,low,-1))
 for value,(r,c) in enumerate(path,1):board[r][c]=str(value)
 return ''.join(' '.join(row)+'\n' for row in board)

def dragon_valid(n:int,actual:str)->bool:
 rows=actual.replace('\r\n','\n').removesuffix('\n').split('\n')
 if len(rows)!=n:return False
 positions=[None]*(n*n)
 for r,row in enumerate(rows):
  fields=row.split()
  if len(fields)!=n:return False
  for c,token in enumerate(fields):
   if (r,c)==(n//2,n//2):
    if token!='T':return False
   else:
    if re.fullmatch(r'[+-]?[0-9]+',token) is None:return False
    value=int(token)
    if not 1<=value<n*n or positions[value] is not None:return False
    positions[value]=(r,c)
 for value in range(2,n*n):
  a=positions[value-1];b=positions[value]
  if a is None or b is None or abs(a[0]-b[0])+abs(a[1]-b[1])!=1:return False
 return True

def pyramid_window_bounds(a:tuple[int,...])->int:
 # For fixed k, every center covers a triangular profile; each too-short element
 # forbids centers with distance < k-ai. Sweep these forbidden center intervals.
 n=len(a);low=1;high=(n+1)//2+1
 def exists(k:int)->bool:
  start,end=k-1,n-k
  diff=[0]*(n+1)
  for i,value in enumerate(a):
   if value<k:
    radius=k-value-1;l=max(start,i-radius);r=min(end,i+radius)
    if l<=r:diff[l]+=1;diff[r+1]-=1
  active=0
  for i in range(n):
   active+=diff[i]
   if start<=i<=end and active==0:return True
  return False
 while high-low>1:
  mid=(low+high)//2
  if exists(mid):low=mid
  else:high=mid
 return low

def segment_prefix_changes(k:int,grid:tuple[str,...])->int:
 h=len(grid);w=len(grid[0]);best=10**9
 for strings in (grid,tuple(''.join(grid[r][c] for r in range(h)) for c in range(w))):
  for s in strings:
   blocked=[0];empty=[0]
   for char in s:blocked.append(blocked[-1]+int(char=='x'));empty.append(empty[-1]+int(char=='.'))
   for end in range(k,len(s)+1):
    if blocked[end]==blocked[end-k]:best=min(best,empty[end]-empty[end-k])
 return -1 if best==10**9 else best

def tour_removed_edge_costs(n:int,a:tuple[int,...])->int:
 # Initially remove edge n: each path is the straight interval length.
 # Moving the removed edge across each interval endpoint replaces route length
 # d with n-d, so interval deltas can be accumulated by sparse endpoint events.
 baseline=0;events={}
 for x,y in zip(a,a[1:]):
  low,high=sorted((x-1,y-1));distance=high-low;baseline+=distance;delta=n-2*distance;events[low]=events.get(low,0)+delta;events[high]=events.get(high,0)-delta
 best=baseline;running=baseline
 for edge in sorted(events):running+=events[edge];best=min(best,running)
 return best

def players_reverse_preimages(grid:tuple[str,...])->int:
 n=len(grid);cells=[(r,c) for r in range(n) for c in range(n) if grid[r][c]!='#'];index={point:i for i,point in enumerate(cells)};m=len(cells);players=[index[(r,c)] for r,c in cells if grid[r][c]=='P'];a,b=sorted(players);target=a*m+b;directions=((1,0),(-1,0),(0,1),(0,-1));preimages=[[[ ] for _ in range(m)] for _ in range(4)]
 for u,(r,c) in enumerate(cells):
  for d,(dr,dc) in enumerate(directions):v=index.get((r+dr,c+dc),u);preimages[d][v].append(u)
 seen=bytearray(m*m);queue=deque()
 for i in range(m):state=i*m+i;seen[state]=1;queue.append(state)
 distance=0
 while queue:
  distance+=1
  for _ in range(len(queue)):
   state=queue.popleft();p,q=divmod(state,m)
   for prior in preimages:
    for x in prior[p]:
     for y in prior[q]:
      state=x*m+y if x<=y else y*m+x
      if seen[state]:continue
      if state==target:return distance
      seen[state]=1;queue.append(state)
 return -1

def stages_reverse_radix(stages:tuple[tuple[int,...],...])->int:
 n=len(stages)+1;reverse:list[list[tuple[int,int]]]=[[] for _ in range(n)]
 for u,(a,b,x) in enumerate(stages):reverse[u+1].append((u,a));reverse[x-1].append((u,b))
 distance=[10**30]*n;distance[-1]=0;buckets:list[list[tuple[int,int]]]=[[] for _ in range(49)];buckets[0].append((0,n-1));last=0;size=1
 while size:
  if not buckets[0]:
   index=1
   while not buckets[index]:index+=1
   last=min(key for key,_ in buckets[index]);entries=buckets[index];buckets[index]=[]
   for key,u in entries:buckets[(key^last).bit_length()].append((key,u))
  key,u=buckets[0].pop();size-=1
  if key!=distance[u]:continue
  if u==0:return key
  for v,weight in reverse[u]:
   candidate=key+weight
   if candidate<distance[v]:distance[v]=candidate;buckets[(candidate^last).bit_length()].append((candidate,v));size+=1
 raise AssertionError('forward chain guarantees reachability')

def queue_adversary_stages(n:int)->list[tuple[int,int,int]]:
 mid=n//2
 return [(10**9,1,mid+1) if i==0 else (1,10**9,1) if i<mid else (10**9 if i==n-2 else 1,2*(n-i),2) for i in range(n-1)]

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc335_d':return dragon_layers(cast(int,d[0]))
 if pid=='abc336_d':return str(pyramid_window_bounds(cast(tuple[int,...],d[0])))+'\n'
 if pid=='abc337_d':return str(segment_prefix_changes(cast(int,d[0]),cast(tuple[str,...],d[1])))+'\n'
 if pid=='abc338_d':return str(tour_removed_edge_costs(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc339_d':return str(players_reverse_preimages(cast(tuple[str,...],d[0])))+'\n'
 return str(stages_reverse_radix(cast(tuple[tuple[int,...],...],d[0])))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:
  d=validate(pid,raw)
  if pid=='abc335_d':return dragon_valid(cast(int,d[0]),actual)
  tokens=actual.split()
  if len(tokens)!=1 or re.fullmatch(r'-?(?:0|[1-9][0-9]*)',tokens[0]) is None:return False
  return tokens==oracle(pid,raw).split()
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc335_d':'''n=int(input());grid=[[0]*n for _ in range(n)];r=c=direction=0;dr=[0,1,0,-1];dc=[1,0,-1,0]
for value in range(1,n*n):
 grid[r][c]=value;rr=r+dr[direction];cc=c+dc[direction]
 if not (0<=rr<n and 0<=cc<n) or grid[rr][cc]:direction=(direction+1)%4;rr=r+dr[direction];cc=c+dc[direction]
 r,c=rr,cc
grid[n//2][n//2]='T'
print('\\n'.join(' '.join(map(str,row)) for row in grid))
''',
'abc336_d':'''n=int(input());a=list(map(int,input().split()));left=[0]*n;right=[0]*n;value=0
for i,x in enumerate(a):value=min(value+1,x);left[i]=value
value=0
for i in range(n-1,-1,-1):value=min(value+1,a[i]);right[i]=value
print(max(min(l,r) for l,r in zip(left,right)))
''',
'abc337_d':'''h,w,k=map(int,input().split());grid=[input() for _ in range(h)];answer=10**9
for lines in (grid,[''.join(grid[r][c] for r in range(h)) for c in range(w)]):
 for s in lines:
  empty=blocked=0
  for i,char in enumerate(s):
   empty+=char=='.';blocked+=char=='x'
   if i>=k:empty-=s[i-k]=='.';blocked-=s[i-k]=='x'
   if i>=k-1 and blocked==0:answer=min(answer,empty)
print(-1 if answer==10**9 else answer)
''',
'abc338_d':'''n,m=map(int,input().split());a=list(map(int,input().split()));base=0;diff=[0]*(n+1)
for x,y in zip(a,a[1:]):
 u,v=sorted((x-1,y-1));d=v-u;base+=min(d,n-d);extra=abs(n-2*d)
 if d<=n-d:diff[u]+=extra;diff[v]-=extra
 else:diff[0]+=extra;diff[u]-=extra;diff[v]+=extra;diff[n]-=extra
running=0;answer=10**30
for i in range(n):running+=diff[i];answer=min(answer,base+running)
print(answer)
''',
'abc339_d':'''from collections import deque
n=int(input());grid=[input() for _ in range(n)];cells=[(r,c) for r in range(n) for c in range(n) if grid[r][c]!='#'];index={point:i for i,point in enumerate(cells)};m=len(cells);players=[index[(r,c)] for r,c in cells if grid[r][c]=='P'];a,b=sorted(players);moves=[]
for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):moves.append([index.get((r+dr,c+dc),i) for i,(r,c) in enumerate(cells)])
start=a*m+b;seen=bytearray(m*m);seen[start]=1;queue=deque([start]);distance=0;answer=-1
while queue and answer<0:
 distance+=1
 for _ in range(len(queue)):
  state=queue.popleft();u,v=divmod(state,m)
  for transition in moves:
   x=transition[u];y=transition[v]
   if x==y:answer=distance;break
   other=x*m+y if x<y else y*m+x
   if not seen[other]:seen[other]=1;queue.append(other)
  if answer>=0:break
print(answer)
''',
'abc340_d':'''import sys,heapq
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);stages=[(next(it),next(it),next(it)-1) for _ in range(n-1)];distance=[10**30]*n;distance[0]=0;heap=[(0,0)]
while heap:
 value,u=heapq.heappop(heap)
 if value!=distance[u]:continue
 if u==n-1:break
 a,b,x=stages[u]
 for v,cost in ((u+1,a),(x,b)):
  candidate=value+cost
  if candidate<distance[v]:distance[v]=candidate;heapq.heappush(heap,(candidate,v))
print(distance[-1])
'''}

def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(197000+int(pid[3:6]));raws=[]
 if pid=='abc335_d':raws=[str(n)+'\n' for n in list(range(3,37,2))+[45]]
 elif pid=='abc336_d':
  def array(a:list[int])->str:return str(len(a))+'\n'+line(a)
  raws=[array([1]),array([10**9]),array([1,2,3,2,1]),array([1,1,1])]
  for j in range(12):raws.append(array([rng.randrange(1,10**9+1) for _ in range(j+3)]))
  raws.append(array([1,10**9]*100000));raws.append(array([10**9]*200000))
 elif pid=='abc337_d':
  def grid(k:int,a:list[str])->str:return line((len(a),len(a[0]),k))+'\n'.join(a)+'\n'
  raws=[grid(1,['.']),grid(1,['x']),grid(1,['o']),grid(2,['o.x','..o'])]
  for j in range(12):h=j+2;w=15-j;raws.append(grid(rng.randrange(1,max(h,w)+1),[''.join(rng.choice('ox.') for _ in range(w)) for _ in range(h)]))
  raws.append(grid(200000,['.'*200000]));raws.append(grid(200000,['x']*200000))
 elif pid=='abc338_d':
  def tour(n:int,a:list[int])->str:return line((n,len(a)))+line(a)
  raws=[tour(3,[1,2]),tour(3,[1,3]),tour(4,[1,3,1]),tour(5,[1,4,2,5])]
  # Each successive visit is required to differ from the previous one.
  for j in range(12):
   n=j+3;a=[rng.randrange(1,n+1)]
   for _ in range(j+4):value=rng.randrange(1,n+1);a.append(value if value!=a[-1] else value%n+1)
   raws.append(tour(n,a))
  a=[rng.randrange(1,200001)]
  for _ in range(199999):value=rng.randrange(1,200001);a.append(value if value!=a[-1] else value%200000+1)
  raws.append(tour(200000,a));raws.append(tour(200000,[1,200000]*100000))
 elif pid=='abc339_d':
  def grid(a:list[str])->str:return str(len(a))+'\n'+'\n'.join(a)+'\n'
  raws=[grid(['PP','..']),grid(['P#','#P']),grid(['P.','.P']),grid(['P#','P#'])]
  for j in range(12):
   n=j+3;board=[[rng.choice('.....#') for _ in range(n)] for _ in range(n)];points=rng.sample([(r,c) for r in range(n) for c in range(n)],2)
   for r,c in points:board[r][c]='P'
   raws.append(grid([''.join(row) for row in board]))
  board=[[rng.choice('.....#') for _ in range(60)] for _ in range(60)];board[0][0]=board[-1][-1]='P';raws.append(grid([''.join(row) for row in board]));raws.append(grid(['P'+'.'*59]+['.'*60]*58+['.'*59+'P']))
 else:
  def stages(a:list[tuple[int,int,int]])->str:return str(len(a)+1)+'\n'+''.join(line(row) for row in a)
  raws=[stages([(1,1,1)]),stages([(10**9,10**9,2)]),stages([(10**9,1,3),(1,1,1)]),stages([(1,10**9,1),(1,1,2),(1,1,1)])]
  for j in range(11):n=j+3;raws.append(stages([(rng.randrange(1,10**9+1),rng.randrange(1,10**9+1),rng.randrange(1,n+1)) for _ in range(n-1)]))
  raws.append(stages(queue_adversary_stages(200000)))
  raws.append(stages([(1+i%1000,1+(i*997)%1000,min(200000,2*i)) for i in range(1,200000)]));raws.append(stages([(10**9,10**9,1)]*199999))
 require(len(raws)==len(set(raws))==18,'18 distinct');cases=[]
 for j,raw in enumerate(raws):validate(pid,raw);cases.append({'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02d}'})
 return cases
HINTS={
'abc335_d':('外側から内側へ、渦巻き状に龍のパーツを並べれば連番が隣接します。','右、下、左、上の順に進み、外にはみ出すか配置済みのマスに当たるときに曲がります。奇数サイズでは最後に中央が残ります。','疑似コード: gridを未配置で初期化、(r,c)=(0,0),方向=右。value=1..N²-1を現在位置へ置く。次位置が盤外/配置済みなら方向を右回転し、次位置へ進む。中央にT、全盤面を出力。'),
'abc336_d':('各位置で、左から増える列と右から増える列の最大高さを求めましょう。','左の高さはmin(A[i],直前の高さ+1)で更新できます。右からも同様に求め、位置ごとの二つの高さの小さい方が、その位置を頂点とする最大サイズです。','疑似コード: h=0。左からh=min(h+1,A[i]),L[i]=h。右からもh=min(h+1,A[i]),R[i]=h。max_i min(L[i],R[i])を出力。'),
'abc337_d':('長さKの横・縦の区間だけを調べます。xを含む区間は使えません。','各列・行で長さKの窓を動かし、xの数と.の数を更新します。xが0なら、必要な変更回数は.の数です。','疑似コード: 全行と全列で、窓へ文字を追加し長さ>Kなら先頭を引く。長さKかつx_count=0ならanswer=min(answer,dot_count)。一つもなければ-1。'),
'abc338_d':('橋を閉じなければ、各移動は円環の二方向のうち短い方を通ります。','短い経路上の橋を閉じると、その移動だけ長い経路へ変わり、差の分だけ増えます。各短い経路の区間へ増分を加え、橋ごとの合計を比べます。','疑似コード: 各連続訪問をu<v,d=v-uへ。base+=min(d,N-d),extra=abs(N-2d)。d<=N-dなら区間[u,v)へextra、他は[0,u)と[v,N)へextraを差分配列で加算。base+累積増分の最小を出力。'),
'abc339_d':('二人の位置を一組にした状態を探索します。一回の操作で同時に動くことに注意しましょう。','各空きマスの四方向の移動先を前計算します。障害物か盤外ならその位置に留まります。位置の組に対して幅優先探索し、最初に一致した距離が答えです。','疑似コード: 空きマスに番号を振りmove[方向][位置]を作る。二人の位置の順序を揃えた組をqueueへ。四方向で同時更新し同じ位置なら距離+1を出力、未訪問組は追加。queue空なら-1。'),
'abc340_d':('遊べるステージを頂点、解放先を辺として最短路を考えましょう。','各iからi+1へ費用A、Xへ費用Bの有向辺があります。費用が正なので、最小距離の頂点から処理するDijkstra法が使えます。','疑似コード: dist[1]=0,他INF、heap=(0,1)。最小距離をpopし古ければskip。二つの辺の到達距離が小さくなるなら更新してheapへ。ステージNの最短距離を出力。')}

TITLES={'abc335_d': 'Loong and Takahashi', 'abc336_d': 'Pyramid', 'abc337_d': 'Cheating Gomoku Narabe', 'abc338_d': 'Island Tour', 'abc339_d': 'Synchronized Players', 'abc340_d': 'Super Takahashi Bros.'}
PUBLISHED_SAMPLES={'abc335_d': [{'input': '5\n', 'expected': '1 2 3 4 5\n16 17 18 19 6\n15 24 T 20 7\n14 23 22 21 8\n13 12 11 10 9\n'}], 'abc336_d': [{'input': '5\n2 2 3 1 1\n', 'expected': '2\n'}, {'input': '5\n1 2 3 4 5\n', 'expected': '3\n'}, {'input': '1\n1000000000\n', 'expected': '1\n'}], 'abc337_d': [{'input': '3 4 3\nxo.x\n..o.\nxx.o\n', 'expected': '2\n'}, {'input': '4 2 3\n.o\n.o\n.o\n.o\n', 'expected': '0\n'}, {'input': '3 3 3\nx..\n..x\n.x.\n', 'expected': '-1\n'}, {'input': '10 12 6\n......xo.o..\nx...x.....o.\nx...........\n..o...x.....\n.....oo.....\no.........x.\nox.oox.xx..x\n....o...oox.\n..o.....x.x.\n...o........\n', 'expected': '3\n'}], 'abc338_d': [{'input': '3 3\n1 3 2\n', 'expected': '2\n'}, {'input': '4 5\n2 4 2 4 2\n', 'expected': '8\n'}, {'input': '163054 10\n62874 19143 77750 111403 29327 56303 6659 18896 64175 26369\n', 'expected': '390009\n'}], 'abc339_d': [{'input': '5\n....#\n#..#.\n.P...\n..P..\n....#\n', 'expected': '3\n'}, {'input': '2\nP#\n#P\n', 'expected': '-1\n'}, {'input': '10\n..........\n..........\n..........\n..........\n....P.....\n.....P....\n..........\n..........\n..........\n..........\n', 'expected': '10\n'}], 'abc340_d': [{'input': '5\n100 200 3\n50 10 1\n100 200 5\n150 1 2\n', 'expected': '350\n'}, {'input': '10\n1000 10 9\n1000 10 10\n1000 10 2\n1000 10 3\n1000 10 4\n1000 10 5\n1000 10 6\n1000 10 7\n1000 10 8\n', 'expected': '90\n'}, {'input': '6\n1000000000 1000000000 1\n1000000000 1000000000 1\n1000000000 1000000000 1\n1000000000 1000000000 1\n1000000000 1000000000 1\n', 'expected': '5000000000\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
