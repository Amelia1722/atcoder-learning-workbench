"""Statement-checked three-stage hints for ABC164–166 B."""
HINTS_V102 = {
    'abc164_b': (
        '高橋君が先攻です。各モンスターが何回攻撃を受けると倒れるかを考えると、ターンを1回ずつシミュレーションしなくても比較できます。',
        '青木君を倒すのに必要な高橋君の攻撃回数は ceil(C/B)、高橋君を倒すのに必要な青木君の攻撃回数は ceil(A/D) です。先攻なので前者が後者以下ならYesです。',
        '''疑似コード:\ntaka = (C + B - 1) // B\naoki = (A + D - 1) // D\nif taka <= aoki:\n  print("Yes")\nelse:\n  print("No")''',
    ),
    'abc165_b': (
        '預金は毎年「現在額の1%の整数部分」だけ増えます。Xは大きいですが、増加は複利なので年数自体は多くありません。',
        'balance=100から始め、balance<X の間 balance += balance//100 を繰り返して年数を数えれば十分高速です。浮動小数は不要です。',
        '''疑似コード:\nbalance = 100\nyears = 0\nwhile balance < X:\n  balance += balance // 100\n  years += 1\nprint(years)''',
    ),
    'abc166_b': (
        'いたずらされないのは「少なくとも1種類のお菓子を持つ人」です。各お菓子の所有者をまとめて、誰が一度でも登場したかを記録してください。',
        '所有者番号をsetへ追加していき、最後に N - len(set) を出せば、お菓子を1つも持たない人数になります。',
        '''疑似コード:\nhas_snack = empty set\nfor each snack:\n  read owners\n  for person in owners:\n    add person to has_snack\nprint(N - size(has_snack))''',
    ),
}
