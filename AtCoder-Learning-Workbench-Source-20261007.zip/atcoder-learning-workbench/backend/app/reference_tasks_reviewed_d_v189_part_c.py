"""Private ABC198..203 D strict domains and independent checks."""
from __future__ import annotations
from collections import Counter
from functools import lru_cache
from typing import cast
import math,random,re
TASKS=tuple(f'abc{n}_d' for n in range(198,204))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc198_d':'semantic','abc200_d':'semantic'}
CHECKER_IDS={p:p for p in OUTPUT_MODES}
Case=dict[str,str]
Data=tuple[object,...]
Edge=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');v=tuple(map(int,row.split(' ')));require(n is None or len(v)==n,'fields');return v
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc198_d':require(len(rows)==3 and all(re.fullmatch('[a-z]{1,10}',s) is not None for s in rows),'words');return tuple(rows)
    if pid=='abc199_d':
        n,m=ints(rows[0],2);require(1<=n<=20 and 0<=m<=n*(n-1)//2 and len(rows)==m+1,'N/M');edges=tuple(cast(Edge,ints(r,2)) for r in rows[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in edges) and len({tuple(sorted(e)) for e in edges})==m,'simple');return n,edges
    if pid=='abc200_d':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=200 and all(1<=v<=10**9 for v in a),'range');return (a,)
    if pid=='abc201_d':
        h,w=ints(rows[0],2);require(1<=h<=2000 and 1<=w<=2000 and len(rows)==h+1,'shape');grid=tuple(rows[1:]);require(all(len(r)==w and set(r)<={'+','-'} for r in grid),'grid');return (grid,)
    if pid=='abc202_d':
        require(len(rows)==1,'shape');a,b,k=ints(rows[0],3);require(1<=a<=30 and 1<=b<=30 and 1<=k<=math.comb(a+b,a),'range');return a,b,k
    n,k=ints(rows[0],2);require(1<=k<=n<=800 and len(rows)==n+1,'shape');grid=tuple(ints(row,n) for row in rows[1:]);require(all(0<=v<=10**9 for row in grid for v in row),'range');return k,grid

@lru_cache(maxsize=128)
def alphametic_linear(words:tuple[str,str,str])->tuple[str,str,str]|None:
    coefficients:Counter[str]=Counter()
    for word,sign in zip(words,(1,1,-1)):
        for j,ch in enumerate(reversed(word)):coefficients[ch]+=sign*10**j
    letters=sorted(set(''.join(words)),key=lambda c:abs(coefficients[c]),reverse=True)
    if len(letters)>10:return None
    leading={s[0] for s in words};mapping:dict[str,int]={}
    def bound(position:int,available:list[int])->tuple[int,int]:
        negative=sorted(coefficients[c] for c in letters[position:] if coefficients[c]<0)
        positive=sorted((coefficients[c] for c in letters[position:] if coefficients[c]>0),reverse=True)
        low=sum(v*d for v,d in zip(negative,reversed(available)))+sum(v*d for v,d in zip(positive,available))
        high=sum(v*d for v,d in zip(negative,available))+sum(v*d for v,d in zip(positive,reversed(available)))
        return low,high
    def search(position:int,used:int,total:int)->bool:
        if position==len(letters):return total==0
        available=[d for d in range(10) if not used>>d&1];low,high=bound(position,available)
        if not low<=-total<=high:return False
        ch=letters[position];coefficient=coefficients[ch]
        for digit in available:
            if digit==0 and ch in leading:continue
            mapping[ch]=digit
            if search(position+1,used|1<<digit,total+coefficient*digit):return True
        mapping.pop(ch,None);return False
    if not search(0,0,0):return None
    return cast(tuple[str,str,str],tuple(''.join(str(mapping[c]) for c in word) for word in words))

def alphametic_valid(words:tuple[str,str,str],actual:str)->bool:
    rows=actual.removesuffix('\n').split('\n')
    if rows==['UNSOLVABLE']:return alphametic_linear(words) is None
    if len(rows)!=3 or any(re.fullmatch('[1-9][0-9]*',r) is None for r in rows):return False
    assignment:dict[str,str]={};inverse:dict[str,str]={}
    for word,value in zip(words,rows):
        if len(word)!=len(value):return False
        for letter,digit in zip(word,value):
            if letter in assignment and assignment[letter]!=digit:return False
            if digit in inverse and inverse[digit]!=letter:return False
            assignment[letter]=digit;inverse[digit]=letter
    return int(rows[0])+int(rows[1])==int(rows[2])

def graph_three_independent(n:int,edges:tuple[Edge,...])->int:
    if not edges:return 3**n
    adjacency=[0]*n
    for u,v in edges:adjacency[u-1]|=1<<(v-1);adjacency[v-1]|=1<<(u-1)
    independent=bytearray(1<<n);independent[0]=1;answer=0;full=(1<<n)-1
    for mask in range(1<<n):
        if mask:
            bit=mask&-mask;j=bit.bit_length()-1;rest=mask^bit;independent[mask]=independent[rest] and not(adjacency[j]&rest)
        if not independent[mask]:continue
        remaining=full^mask;side0=0;side1=0;components=0;valid=True
        while remaining and valid:
            wave=remaining&-remaining;remaining^=wave;side0|=wave;parity=0;components+=1
            while wave and valid:
                neighbors=0;copy=wave
                while copy:bit=copy&-copy;copy^=bit;neighbors|=adjacency[bit.bit_length()-1]
                neighbors&=full^mask
                if neighbors&(side0 if parity==0 else side1):valid=False;break
                wave=neighbors&remaining;remaining^=wave;parity^=1
                if parity==0:side0|=wave
                else:side1|=wave
        if valid:answer+=1<<components
    return answer

def subset_remainder_pair(a:tuple[int,...])->tuple[int,int]|None:
    seen:dict[int,int]={}
    for j,value in enumerate(a):
        additions=[(value%200,1<<j)]+[((r+value)%200,mask|1<<j) for r,mask in seen.items()]
        for remainder,mask in additions:
            if remainder in seen and seen[remainder]!=mask:return seen[remainder],mask
            seen[remainder]=mask
    return None

def subsets_valid(a:tuple[int,...],actual:str)->bool:
    rows=actual.removesuffix('\n').split('\n')
    if len(rows)==1 and rows[0].lower()=='no':return subset_remainder_pair(a) is None
    if len(rows)!=3 or rows[0].lower()!='yes':return False
    subsets=[]
    for row in rows[1:]:
        try:values=ints(row);size=values[0];indices=values[1:]
        except (ValueError,IndexError):return False
        if not 1<=size<=len(a) or len(indices)!=size or any(not 1<=v<=len(a) for v in indices) or any(u>=v for u,v in zip(indices,indices[1:])):return False
        subsets.append(indices)
    return subsets[0]!=subsets[1] and sum(a[j-1] for j in subsets[0])%200==sum(a[j-1] for j in subsets[1])%200

def game_strategy_bits(grid:tuple[str,...])->int:
    # A bit at cumulative score D says whether Takahashi can force final score>=0.
    # Scores outside [-pathlength,pathlength] are deterministically win/loss.
    h=len(grid);w=len(grid[0]);length=h+w-2;width=2*length+1;mask=(1<<width)-1;top=1<<(width-1);terminal=((1<<(length+1))-1)<<length;below=[0]*w
    for r in range(h-1,-1,-1):
        current=[0]*w;row=grid[r];next_row=grid[r+1] if r+1<h else '';taka=(r+w-1)%2==0
        for c in range(w-1,-1,-1):
            if r==h-1 and c==w-1:current[c]=terminal;taka=not taka;continue
            if r+1<h:
                bits=below[c];result=(bits>>1)|top if (next_row[c]=='+')==taka else (bits<<1)&mask
                if c+1<w:
                    bits=current[c+1];other=(bits>>1)|top if (row[c+1]=='+')==taka else (bits<<1)&mask;result=result|other if taka else result&other
            else:
                bits=current[c+1];result=(bits>>1)|top if (row[c+1]=='+')==taka else (bits<<1)&mask
            current[c]=result;taka=not taka
        below=current
    threshold=(below[0]&-below[0]).bit_length()-1-length;return -threshold

def kth_pascal(a:int,b:int,k:int)->str:
    counts=[[1]*(b+1) for _ in range(a+1)]
    for i in range(1,a+1):
        for j in range(1,b+1):counts[i][j]=counts[i-1][j]+counts[i][j-1]
    result=[]
    while a or b:
        if not a:result.append('b'*b);break
        if not b:result.append('a'*a);break
        if k<=counts[a-1][b]:result.append('a');a-=1
        else:k-=counts[a-1][b];result.append('b');b-=1
    return ''.join(result)

def pond_rolling(k:int,grid:tuple[tuple[int,...],...])->int:
    n=len(grid);values=sorted({v for row in grid for v in row});needed=(k*k+1)//2
    def feasible(value:int)->bool:
        column=[sum(grid[r][c]<=value for r in range(k)) for c in range(n)]
        for top_row in range(n-k+1):
            if top_row:
                before=grid[top_row-1];after=grid[top_row+k-1]
                for c in range(n):column[c]+=int(after[c]<=value)-int(before[c]<=value)
            total=sum(column[:k])
            if total>=needed:return True
            for c in range(k,n):
                total+=column[c]-column[c-k]
                if total>=needed:return True
        return False
    low=0;high=len(values)-1
    while low<high:
        middle=(low+high)//2
        if feasible(values[middle]):high=middle
        else:low=middle+1
    return values[low]

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc198_d':
        result=alphametic_linear(cast(tuple[str,str,str],data));return '\n'.join(result) if result else 'UNSOLVABLE'
    if pid=='abc199_d':return str(graph_three_independent(*cast(tuple[int,tuple[Edge,...]],data)))
    if pid=='abc200_d':
        a=cast(tuple[int,...],data[0]);pair=subset_remainder_pair(a)
        if pair is None:return 'No'
        rows=['Yes']
        for mask in pair:indices=[j+1 for j in range(len(a)) if mask>>j&1];rows.append(str(len(indices))+' '+' '.join(map(str,indices)))
        return '\n'.join(rows)
    if pid=='abc201_d':
        value=game_strategy_bits(cast(tuple[str,...],data[0]));return 'Takahashi' if value>0 else 'Aoki' if value<0 else 'Draw'
    if pid=='abc202_d':return kth_pascal(*cast(tuple[int,int,int],data))
    return str(pond_rolling(*cast(tuple[int,tuple[tuple[int,...],...]],data)))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='abc198_d':return alphametic_valid(cast(tuple[str,str,str],data),actual)
        if pid=='abc200_d':return subsets_valid(cast(tuple[int,...],data[0]),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc198_d':"s=[input() for _ in range(3)];letters=set(''.join(s));mapping={};used=set();leading={word[0] for word in s};reverse=[word[::-1] for word in s];length=max(map(len,s))\ndef solve(column,carry):\n if column==length:return carry==0\n chars=[word[column] if column<len(word) else None for word in reverse]\n def assign(position):\n  if position==2:\n   total=carry+sum(mapping[ch] if ch else 0 for ch in chars[:2]);digit=total%10;ch=chars[2]\n   if ch is None:return digit==0 and solve(column+1,total//10)\n   if ch in mapping:return mapping[ch]==digit and solve(column+1,total//10)\n   if digit in used or digit==0 and ch in leading:return False\n   mapping[ch]=digit;used.add(digit)\n   if solve(column+1,total//10):return True\n   del mapping[ch];used.remove(digit);return False\n  ch=chars[position]\n  if ch is None or ch in mapping:return assign(position+1)\n  for digit in range(10):\n   if digit in used or digit==0 and ch in leading:continue\n   mapping[ch]=digit;used.add(digit)\n   if assign(position+1):return True\n   del mapping[ch];used.remove(digit)\n  return False\n return assign(0)\nif len(letters)<=10 and solve(0,0):\n for word in s:print(''.join(str(mapping[ch]) for ch in word))\nelse:print('UNSOLVABLE')\n",
'abc199_d':"n,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):u,v=map(int,input().split());u-=1;v-=1;g[u].append(v);g[v].append(u)\nseen=set();answer=1;colors=[-1]*n\nfor start in range(n):\n if start in seen:continue\n component=[];stack=[start];seen.add(start)\n while stack:\n  u=stack.pop();component.append(u)\n  for v in g[u]:\n   if v not in seen:seen.add(v);stack.append(v)\n component.sort(key=lambda v:len(g[v]),reverse=True);colors[component[0]]=0\n def dfs(position):\n  if position==len(component):return 1\n  u=component[position];forbidden={colors[v] for v in g[u]};count=0\n  for color in range(3):\n   if color not in forbidden:colors[u]=color;count+=dfs(position+1)\n  colors[u]=-1;return count\n answer*=3*dfs(1);colors[component[0]]=-1\nprint(answer)\n",
'abc200_d':"n=int(input());a=list(map(int,input().split()));seen={};answer=None\nfor mask in range(1,1<<min(n,8)):\n total=sum(a[j] for j in range(min(n,8)) if mask>>j&1)%200\n if total in seen:answer=(seen[total],mask);break\n seen[total]=mask\nif answer is None:print('No')\nelse:\n print('Yes')\n for mask in answer:\n  indices=[j+1 for j in range(min(n,8)) if mask>>j&1];print(len(indices),*indices)\n",
'abc201_d':"h,w=map(int,input().split());g=[input() for _ in range(h)];dp=[0]*w\nfor r in range(h-1,-1,-1):\n for c in range(w-1,-1,-1):\n  if r==h-1 and c==w-1:continue\n  best=-100000\n  if r+1<h:best=max(best,(1 if g[r+1][c]=='+' else -1)-dp[c])\n  if c+1<w:best=max(best,(1 if g[r][c+1]=='+' else -1)-dp[c+1])\n  dp[c]=best\nprint('Takahashi' if dp[0]>0 else 'Aoki' if dp[0]<0 else 'Draw')\n",
'abc202_d':"from math import comb\na,b,k=map(int,input().split());answer=''\nwhile a and b:\n count=comb(a+b-1,a-1)\n if k<=count:answer+='a';a-=1\n else:answer+='b';b-=1;k-=count\nprint(answer+'a'*a+'b'*b)\n",
'abc203_d':"n,k=map(int,input().split());g=[list(map(int,input().split())) for _ in range(n)];needed=(k*k+1)//2\ndef feasible(value):\n prefix=[[0]*(n+1) for _ in range(n+1)]\n for r in range(n):\n  row_sum=0;above=prefix[r];current=prefix[r+1]\n  for c in range(n):row_sum+=g[r][c]<=value;current[c+1]=above[c+1]+row_sum\n for r in range(k,n+1):\n  row=prefix[r];above=prefix[r-k]\n  for c in range(k,n+1):\n   if row[c]-above[c]-row[c-k]+above[c-k]>=needed:return True\n return False\nlow=-1;high=10**9\nwhile low+1<high:\n middle=(low+high)//2\n if feasible(middle):high=middle\n else:low=middle\nprint(high)\n"}

TITLES={'abc198_d': 'Send More Money', 'abc199_d': 'RGB Coloring 2', 'abc200_d': 'Happy Birthday! 2', 'abc201_d': 'Game in Momotetsu World', 'abc202_d': 'aab aba baa', 'abc203_d': 'Pond'}
PUBLISHED_SAMPLES={'abc198_d': [{'input': 'a\nb\nc\n', 'expected': '1\n2\n3\n'}, {'input': 'x\nx\ny\n', 'expected': '1\n1\n2\n'}, {'input': 'p\nq\np\n', 'expected': 'UNSOLVABLE\n'}, {'input': 'abcd\nefgh\nijkl\n', 'expected': 'UNSOLVABLE\n'}, {'input': 'send\nmore\nmoney\n', 'expected': '9567\n1085\n10652\n'}], 'abc199_d': [{'input': '3 3\n1 2\n2 3\n3 1\n', 'expected': '6\n'}, {'input': '3 0\n', 'expected': '27\n'}, {'input': '4 6\n1 2\n2 3\n3 4\n2 4\n1 3\n1 4\n', 'expected': '0\n'}, {'input': '20 0\n', 'expected': '3486784401\n'}], 'abc200_d': [{'input': '5\n180 186 189 191 218\n', 'expected': 'Yes\n1 1\n2 3 4\n'}, {'input': '2\n123 523\n', 'expected': 'Yes\n1 1\n1 2\n'}, {'input': '6\n2013 1012 2765 2021 508 6971\n', 'expected': 'No\n'}], 'abc201_d': [{'input': '3 3\n---\n+-+\n+--\n', 'expected': 'Takahashi\n'}, {'input': '2 4\n+++-\n-+-+\n', 'expected': 'Aoki\n'}, {'input': '1 1\n-\n', 'expected': 'Draw\n'}], 'abc202_d': [{'input': '2 2 4\n', 'expected': 'baab\n'}, {'input': '30 30 118264581564861424\n', 'expected': 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n'}], 'abc203_d': [{'input': '3 2\n1 7 0\n5 8 11\n10 4 2\n', 'expected': '4\n'}, {'input': '3 3\n1 2 3\n4 5 6\n7 8 9\n', 'expected': '5\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18900+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc198_d':
        triples=[('a','a','a'),('a','b','c'),('a','a','b'),('a','b','a'),('a','b','ab'),('send','more','money'),('donald','gerald','robert'),('cross','roads','danger'),('a','bc','de'),('abc','de','fgh'),('abc','abc','def'),('a','bc','bc'),('ab','cd','efg'),('abc','def','ghi'),('abcdefghij','abcdefghij','jihgfedcba'),('aaaaaaaaaa','bbbbbbbbbb','cccccccccc'),('abcdefghi','j','abcdefghi'),('abcdefghij','klmnopqrst','uvwxyzabcd')];raws=['\n'.join(v)+'\n' for v in triples]
    elif pid=='abc199_d':
        def graph(n:int,edges:list[Edge])->str:return f'{n} {len(edges)}\n'+''.join(line(e) for e in edges)
        raws=[graph(1,[]),graph(2,[]),graph(2,[(1,2)]),graph(3,[(1,2),(2,3),(1,3)])]
        for n in range(4,16):raws.append(graph(n,[(u,v) for u in range(1,n+1) for v in range(u+1,n+1) if rng.randrange(4)==0]))
        raws += [graph(20,[(j,j+1) for j in range(1,20)]),graph(20,[(u,v) for u in range(1,21) for v in range(u+1,21)])]
    elif pid=='abc200_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([1,1]),seq([1,2]),seq([1,200]),seq([10**9,10**9])]+[seq([rng.randint(1,10**9) for _ in range(n)]) for n in range(3,15)]+[seq(list(range(1,201))),seq([10**9]*200)]
    elif pid=='abc201_d':
        def grid(a:list[str])->str:return f'{len(a)} {len(a[0])}\n'+'\n'.join(a)+'\n'
        raws=[grid(['+']),grid(['-']),grid(['++']),grid(['+-']),grid(['+','-'])]+[grid([''.join(rng.choice('+-') for _ in range(n+1)) for _ in range(n)]) for n in range(2,13)]+[grid([''.join('+' if (r+c)%3 else '-' for c in range(2000)) for r in range(2000)]),grid(['+'*2000]*2000)]
    elif pid=='abc202_d':
        values=[(1,1,1),(1,1,2),(1,30,1),(30,1,31)]+[(j,j+1,rng.randint(1,math.comb(2*j+1,j))) for j in range(2,14)]+[(30,30,1),(30,30,math.comb(60,30))];raws=[line(v) for v in values]
    else:
        def pond(k:int,g:list[list[int]])->str:return f'{len(g)} {k}\n'+''.join(line(row) for row in g)
        raws=[pond(1,[[0]]),pond(1,[[10**9]]),pond(2,[[1,2],[3,4]]),pond(1,[[1,2],[3,4]])]+[pond(rng.randint(1,n),[[rng.randint(0,10**9) for _ in range(n)] for _ in range(n)]) for n in range(3,15)]+[pond(400,[[rng.randint(0,10**9) for _ in range(800)] for _ in range(800)]),pond(800,[[10**9]*800 for _ in range(800)])]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc198_d':('各文字へ異なる数字を割り当てます。全ての先頭文字は0にできません。','右の桁から足し算の繰り上がりを追い、未割当の加数の数字を試します。結果の桁は和から決まり、最後の繰り上がりも0である必要があります。','疑似コード: 各wordをreverse; solve(column,carry)で加数の未割当文字の未使用digitを列挙（leading0禁止）; digit=(carry+加数digit和)%10を結果文字へ割当/整合確認; 次columnへcarry=和//10; 全桁終了でcarry0なら三数出力、全探索失敗ならUNSOLVABLE。'),
'abc199_d':('連結成分ごとに独立して色を決められます。','各成分の一つの頂点を色0に固定し、残り頂点の三色を隣接頂点と矛盾しないよう全探索します。最初の頂点の選択は三倍です。','疑似コード: 各componentのrootを0色; DFSで各vertexに隣接既割当の色を避け0..2を試す; 完成数*3をcomponent答えとする; 全component答えの積を出力。'),
'abc200_d':('和の余りは200種類です。最初の8個だけでも非空部分集合は255個あります。','最初のmin(N,8)個の非空部分集合を全列挙し、同じ余りを持つ二つがあれば出力できます。','疑似コード: mask=1..2^min(N,8)-1; remainder=sum(maskが選ぶA)%200; seen[remainder]があれば異なる二maskのindexを昇順出力; 他はseenへ保存; 全maskでなければNo。'),
'abc201_d':('右下から逆に、手番の人が相手より何点多く取れるかを求めます。','移動先の点数から、その先で相手が得られる点差を引いて最大にします。手番が交代するため符号が反転します。','疑似コード: goal dp=0; cellsを右下から走査; dp[cell]=max(score[next]-dp[next]) over右/下; dp[0][0]>0ならTakahashi,<0ならAoki,他Draw。'),
'abc202_d':('先頭をaにした場合の文字列の個数を求めます。','先頭aの候補は全て先頭bより辞書順で小さいので、その個数とKを比べて先頭を決められます。','疑似コード: A,B>0の間count=comb(A+B-1,A-1); K<=countならaを追加しA--; 他はbを追加しB--,K-=count; 残ったaまたはbを連結して出力。'),
'abc203_d':('中央値がx以下の区画が存在するかを判定し、xを二分探索します。','x以下のマスを1、それ以外を0として二次元累積和を作ります。K^2個中ceil(K^2/2)個以上が1の区画があれば、その中央値はx以下です。','疑似コード: feasible(x): (A<=x)の2Dprefixを計算; 全K×Kのsumが(K*K+1)//2以上ならtrue; 最小trueを[-1,1e9]でbinarysearchして出力。')}
