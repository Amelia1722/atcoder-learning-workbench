"""Turn135 checkpoint: reviewed ABC062--079 C, including two semantic judges."""
from __future__ import annotations
from bisect import bisect_right
from collections import Counter,deque
from fractions import Fraction
from functools import lru_cache
from itertools import combinations,permutations,product,accumulate
from math import factorial,gcd,prod
import random,re
from typing import cast

TASKS=('arc074_a','arc075_a','abc064_c','arc076_a','arc077_a','arc078_a','arc079_a','arc080_a','abc070_c','arc081_a','arc082_a','abc073_c','arc083_a','abc075_c','abc076_c','arc084_a','arc085_a','abc079_c')
NUMBERS=dict(zip(TASKS,range(62,80)))
CONTESTS={p:f'abc{NUMBERS[p]:03}' for p in TASKS}
LANES={chr(65+i):TASKS[i*3:i*3+3] for i in range(6)}
OUTPUT_MODES={'arc083_a':'semantic','abc079_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    a=tuple(map(int,row.split()));require(count is None or len(a)==count,'field count');return a
def connected(n:int,edges:tuple[Pair,...])->bool:
    neighbors=[[] for _ in range(n)]
    for u,v in edges:neighbors[u-1].append(v-1);neighbors[v-1].append(u-1)
    seen={0};queue=[0]
    while queue:
        for v in neighbors[queue.pop()]:
            if v not in seen:seen.add(v);queue.append(v)
    return len(seen)==n
def ticket_answers(s:str)->list[str]:
    a,b,c,d=map(int,s);answers=[]
    for ops in product('+-',repeat=3):
        if a+sum(v if op=='+' else -v for v,op in zip((b,c,d),ops))==7:answers.append(s[0]+''.join(op+digit for op,digit in zip(ops,s[1:]))+'=7')
    return answers
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');i=NUMBERS[pid]
    if i in (62,65,78):
        require(len(rows)==1,'shape');a,b=ints(rows[0],2)
        require(2<=a<=100000 and 2<=b<=100000 if i==62 else 1<=a<=100000 and 1<=b<=100000 if i==65 else 1<=a<=100 and 1<=b<=min(a,5),'two sizes');return a,b
    if i==74:
        require(len(rows)==1,'shape');a,b,c,d,e,f=ints(rows[0],6);require(1<=a<b<=30 and 1<=c<d<=30 and 1<=e<=100 and 100*a<=f<=3000,'ingredients');return a,b,c,d,e,f
    if i==76:
        require(len(rows)==2 and re.fullmatch('[a-z?]{1,50}',rows[0]) is not None and re.fullmatch('[a-z]{1,50}',rows[1]) is not None,'strings');return tuple(rows)
    if i==79:
        require(len(rows)==1 and re.fullmatch('[0-9]{4}',rows[0]) is not None and bool(ticket_answers(rows[0])),'solvable ticket');return (rows[0],)
    if i in (68,75):
        n,m=ints(rows[0],2);edges=tuple(ints(r,2) for r in rows[1:]);require(len(edges)==len(set(edges))==m and all(1<=u<v<=n for u,v in edges),'simple sorted edges')
        if i==68:require(3<=n<=200000 and 1<=m<=200000 and (1,n) not in edges,'no direct boat')
        else:require(2<=n<=50 and n-1<=m<=min(n*(n-1)//2,50) and connected(n,cast(tuple[Pair,...],edges)),'connected bridge graph')
        return n,edges
    if i==77:
        n,=ints(rows[0],1);require(1<=n<=100000 and len(rows)==4,'festival size');arrays=tuple(ints(r,n) for r in rows[1:]);require(all(1<=v<=10**9 for a in arrays for v in a),'festival values');return n,arrays
    n,=ints(rows[0],1)
    if i in (63,70,73):a=tuple(ints(r,1)[0] for r in rows[1:])
    else:require(len(rows)==2,'shape');a=ints(rows[1],n)
    bounds={63:(1,100,1,100),64:(1,100,1,4800),66:(1,200000,0,10**9),67:(2,200000,-10**9,10**9),69:(2,100000,1,10**9),70:(1,100,1,10**18),71:(4,100000,1,10**9),72:(1,100000,0,99999),73:(1,100000,1,10**9)}
    lo,hi,low,high=bounds[i];require(lo<=n<=hi and len(a)==n and all(low<=v<=high for v in a),'array')
    if i==70:
        value=1
        for t in a:value=value//gcd(value,t)*t
        require(value<=10**18,'answer guarantee')
    return n,a

def _chocolate(h:int,w:int)->int:
    if max(h,w)<=10:
        candidates=[]
        for a,b in ((h,w),(w,h)):
            for cut in range(1,a):
                for second in range(1,a-cut):
                    areas=(cut*b,second*b,(a-cut-second)*b);candidates.append(max(areas)-min(areas))
                for second in range(1,b):
                    areas=(cut*b,(a-cut)*second,(a-cut)*(b-second));candidates.append(max(areas)-min(areas))
        return min(candidates)
    # Binary-search a spread bound; derive an integer interval for the second
    # cut, rather than choosing balanced pieces as in the reference.
    def ceil(a:int,b:int)->int:return -((-a)//b)
    def feasible(spread:int)->bool:
        for a,b in ((h,w),(w,h)):
            if a>=3 and spread>=(0 if a%3==0 else b):return True
            for cut in range(1,a):
                first=cut*b;remaining=a-cut
                low=max(1,ceil(first-spread,remaining),b-(first+spread)//remaining,ceil(b*remaining-spread,2*remaining))
                high=min(b-1,(first+spread)//remaining,b-ceil(first-spread,remaining),(b*remaining+spread)//(2*remaining))
                if low<=high:return True
        return False
    low,high=0,max(h,w)
    while low<high:
        middle=(low+high)//2
        if feasible(middle):high=middle
        else:low=middle+1
    return low

def _reachable(amount:int,u:int,v:int)->bool:
    common=gcd(u,v)
    if amount%common:return False
    u//=common;v//=common;amount//=common
    first=(amount*pow(u,-1,v))%v
    return first*u<=amount
@lru_cache(maxsize=64)
def sugar_options(a:int,b:int,c:int,d:int,e:int,f:int)->tuple[tuple[int,int],...]:
    waters=[v for v in range(100,f+1,100) if _reachable(v//100,a,b)];sugars=[v for v in range(f+1) if _reachable(v,c,d)];options=[]
    for water in waters:
        limit=min(f-water,water*e//100);j=bisect_right(sugars,limit)-1
        if j>=0:options.append((water+sugars[j],sugars[j]))
    return tuple(options)
def valid_sugar(raw:str,actual:str)->bool:
    data=cast(tuple[int,int,int,int,int,int],validate('arc083_a',raw));out=actual.removesuffix('\n')
    if re.fullmatch(r'[1-9][0-9]* (?:0|[1-9][0-9]*)',out) is None:return False
    total,sugar=map(int,out.split());a,b,c,d,e,f=data;water=total-sugar
    if not(0<water<=total<=f and 100*sugar<=e*water and water%100==0 and _reachable(water//100,a,b) and _reachable(sugar,c,d)):return False
    return all(sugar*other_total>=other_sugar*total for other_total,other_sugar in sugar_options(*data))
def valid_ticket(raw:str,actual:str)->bool:
    s=cast(str,validate('abc079_c',raw)[0]);out=actual.removesuffix('\n')
    if re.fullmatch(r'[0-9][+-][0-9][+-][0-9][+-][0-9]=7',out) is None:return False
    if ''.join(out[j] for j in (0,2,4,6))!=s:return False
    return int(out[0])+sum(int(out[j+1])*(1 if out[j]=='+' else -1) for j in (1,3,5))==7

@lru_cache(maxsize=512)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);i=NUMBERS[pid]
    if i==62:
        h,w=cast(tuple[int,int],data);return str(_chocolate(h,w))
    if i==65:
        n,m=cast(tuple[int,int],data);patterns=sum(all(row[j]!=row[j+1] for j in range(len(row)-1)) for row in set(permutations('D'*n+'M'*m))) if n+m<=8 else 2 if n==m else 1 if abs(n-m)==1 else 0
        return str(patterns*(factorial(n)%1000000007)*(factorial(m)%1000000007)%1000000007)
    if i==74:
        options=sugar_options(*cast(tuple[int,int,int,int,int,int],data));best=options[0]
        for pair in options[1:]:
            if pair[1]*best[0]>best[1]*pair[0]:best=pair
        return f'{best[0]} {best[1]}'
    if i==76:
        s,t=cast(tuple[str,str],data);candidates=[]
        for j in range(len(s)-len(t)+1):
            if all(a=='?' or a==b for a,b in zip(s[j:j+len(t)],t)):candidates.append((s[:j]+t+s[j+len(t):]).replace('?','a'))
        return min(candidates) if candidates else 'UNRESTORABLE'
    if i==78:
        n,m=cast(tuple[int,int],data);outcomes=list(product((0,1),repeat=m));probability=Fraction(sum(all(row) for row in outcomes),len(outcomes));expected=Fraction(1900*m+100*(n-m),1)/probability;require(expected.denominator==1,'integral expectation');return str(expected.numerator)
    if i==79:return ticket_answers(cast(str,data[0]))[-1]
    if i in (68,75):
        n,edges=cast(tuple[int,tuple[Pair,...]],data);neighbors=[[] for _ in range(n)]
        for u,v in edges:neighbors[u-1].append(v-1);neighbors[v-1].append(u-1)
        if i==68:
            frontier={0}
            for _ in range(2):frontier={v for u in frontier for v in neighbors[u]}
            return 'POSSIBLE' if n-1 in frontier else 'IMPOSSIBLE'
        timer=0;tin=[-1]*n;low=[0]*n;answer=0
        def visit(u:int,parent:int)->None:
            nonlocal timer,answer
            tin[u]=low[u]=timer;timer+=1
            for v in neighbors[u]:
                if v==parent:continue
                if tin[v]>=0:low[u]=min(low[u],tin[v])
                else:
                    visit(v,u);low[u]=min(low[u],low[v]);answer+=low[v]>tin[u]
        visit(0,-1);return str(answer)
    if i==77:
        n,arrays=cast(tuple[int,tuple[tuple[int,...],...]],data);a,b,c=arrays
        if n<=6:return str(sum(x<y<z for x in a for y in b for z in c))
        events=sorted([(v,2) for v in a]+[(v,1) for v in b]+[(v,0) for v in c]);first=pairs=answer=0
        for value,kind in events:
            if kind==2:first+=1
            elif kind==1:pairs+=first
            else:answer+=pairs
        return str(answer)
    n,a=cast(tuple[int,tuple[int,...]],data)
    if i==63:
        possible=1
        for value in a:possible|=possible<<value
        return str(next((v for v in range(sum(a),0,-1) if v%10 and possible>>v&1),0))
    if i==64:
        occupied=[any(400*j<=v<400*(j+1) for v in a) for j in range(8)];fixed=sum(occupied);free=sum(v>=3200 for v in a);return f'{max(1,fixed)} {fixed+free}'
    if i==66:return ' '.join(map(str,a[-1::-2]+a[1 if n%2 else 0::2]))
    if i==67:
        prefixes=list(accumulate(a));suffixes=list(accumulate(reversed(a)));return str(min(abs(prefixes[j]-suffixes[n-j-2]) for j in range(n-1)))
    if i==69:
        if n<=8:return 'Yes' if any(all(row[j]*row[j+1]%4==0 for j in range(n-1)) for row in set(permutations(a))) else 'No'
        odd=[v for v in a if v%2];four=[v for v in a if v%4==0];two=[v for v in a if v%4==2];row=[]
        for j,value in enumerate(odd):
            row.append(value)
            if j<len(odd)-1 or two:
                if not four:return 'No'
                row.append(four.pop())
        row.extend(four);row.extend(two)
        return 'Yes' if all(row[j]*row[j+1]%4==0 for j in range(n-1)) else 'No'
    if i==70:
        remaining=list(a)
        for j in range(n):
            for k in range(j+1,n):remaining[k]//=gcd(remaining[j],remaining[k])
        return str(prod(remaining))
    if i==71:
        if n<=12:
            answer=0
            for row in combinations(a,4):
                ordered=sorted(row)
                if ordered[0]==ordered[1] and ordered[2]==ordered[3]:answer=max(answer,ordered[0]*ordered[2])
            return str(answer)
        pairs=sorted((v for v,count in Counter(a).items() for _ in range(min(2,count//2))),reverse=True);return str(pairs[0]*pairs[1] if len(pairs)>=2 else 0)
    if i==72:
        ordered=sorted(a);left=answer=0
        for right,value in enumerate(ordered):
            while value-ordered[left]>2:left+=1
            answer=max(answer,right-left+1)
        return str(answer)
    return str(sum(count%2 for count in Counter(a).values()))

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='arc083_a':return valid_sugar(raw,actual)
    if pid=='abc079_c':return valid_ticket(raw,actual)
    return actual.removesuffix('\n')==oracle(pid,raw)
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)

REFERENCE_CODE:dict[str,str]={}
def reference(i:int,body:str)->None:
    pid=next(p for p in TASKS if NUMBERS[p]==i);REFERENCE_CODE[pid]='from collections import Counter,deque\nfrom bisect import bisect_left,bisect_right\nfrom itertools import permutations\nfrom math import gcd\n'+body.strip()+'\n'
reference(62,'''
h,w=map(int,input().split());ans=h*w
for a,b in ((h,w),(w,h)):
 if a>=3:ans=min(ans,0 if a%3==0 else b)
 for cut in range(1,a):
  pieces=[cut*b,(a-cut)*(b//2),(a-cut)*(b-b//2)];ans=min(ans,max(pieces)-min(pieces))
print(ans)
''')
reference(63,"n=int(input());a=[int(input()) for _ in range(n)];s=sum(a);candidates=[v for v in a if v%10];print(s if s%10 else s-min(candidates) if candidates else 0)")
reference(64,"n=int(input());a=list(map(int,input().split()));fixed=len(set(v//400 for v in a if v<3200));free=sum(v>=3200 for v in a);print(max(1,fixed),fixed+free)")
reference(65,'''
n,m=map(int,input().split());mod=1000000007;answer=1
if abs(n-m)>1:print(0)
else:
 for j in range(1,n+1):answer=answer*j%mod
 for j in range(1,m+1):answer=answer*j%mod
 print(answer*(2 if n==m else 1)%mod)
''')
reference(66,'''
n=int(input());a=list(map(int,input().split()));q=deque()
for j,v in enumerate(a):
 if j%2:q.append(v)
 else:q.appendleft(v)
if n%2==0:q.reverse()
print(*q)
''')
reference(67,"n=int(input());a=list(map(int,input().split()));total=sum(a);left=0;answer=10**30\nfor v in a[:-1]:left+=v;answer=min(answer,abs(2*left-total))\nprint(answer)")
reference(68,'''
n,m=map(int,input().split());start=set();end=set()
for _ in range(m):
 u,v=map(int,input().split())
 if u==1:start.add(v)
 if v==n:end.add(u)
print('POSSIBLE' if start&end else 'IMPOSSIBLE')
''')
reference(69,"n=int(input());a=list(map(int,input().split()));odd=sum(v%2 for v in a);four=sum(v%4==0 for v in a);two=n-odd-four;print('Yes' if four>=odd-(two==0) else 'No')")
reference(70,"n=int(input());answer=1\nfor _ in range(n):v=int(input());answer=answer//gcd(answer,v)*v\nprint(answer)")
reference(71,'''
n=int(input());a=sorted(map(int,input().split()),reverse=True);pairs=[];j=0
while j+1<n and len(pairs)<2:
 if a[j]==a[j+1]:pairs.append(a[j]);j+=2
 else:j+=1
print(pairs[0]*pairs[1] if len(pairs)==2 else 0)
''')
reference(72,"n=int(input());counts=Counter()\nfor v in map(int,input().split()):\n for target in (v-1,v,v+1):counts[target]+=1\nprint(max(counts.values()))")
reference(73,"n=int(input());seen=set()\nfor _ in range(n):\n v=int(input())\n if v in seen:seen.remove(v)\n else:seen.add(v)\nprint(len(seen))")
reference(74,'''
a,b,c,d,e,f=map(int,input().split());water=[False]*(f+1);sugar=[False]*(f+1);water[0]=sugar[0]=True
for j in range(f+1):
 if water[j]:
  for step in (100*a,100*b):
   if j+step<=f:water[j+step]=True
 if sugar[j]:
  for step in (c,d):
   if j+step<=f:sugar[j+step]=True
best_total=100*a;best_sugar=0
for w in range(1,f+1):
 if not water[w]:continue
 for s in range(min(f-w,e*w//100)+1):
  if sugar[s] and s*best_total>best_sugar*(w+s):best_total=w+s;best_sugar=s
print(best_total,best_sugar)
''')
reference(75,'''
n,m=map(int,input().split());edges=[tuple(map(int,input().split())) for _ in range(m)];answer=0
for excluded in range(m):
 neighbors=[[] for _ in range(n)]
 for j,(u,v) in enumerate(edges):
  if j!=excluded:neighbors[u-1].append(v-1);neighbors[v-1].append(u-1)
 seen={0};queue=[0]
 while queue:
  for v in neighbors[queue.pop()]:
   if v not in seen:seen.add(v);queue.append(v)
 answer+=len(seen)!=n
print(answer)
''')
reference(76,'''
s=input();t=input()
for j in range(len(s)-len(t),-1,-1):
 if all(a=='?' or a==b for a,b in zip(s[j:j+len(t)],t)):
  print((s[:j]+t+s[j+len(t):]).replace('?','a'));break
else:print('UNRESTORABLE')
''')
reference(77,"n=int(input());a=sorted(map(int,input().split()));b=list(map(int,input().split()));c=sorted(map(int,input().split()));print(sum(bisect_left(a,v)*(n-bisect_right(c,v)) for v in b))")
reference(78,"n,m=map(int,input().split());print((1900*m+100*(n-m))*2**m)")
reference(79,'''
s=input();a,b,c,d=map(int,s)
for mask in range(8):
 ops=['+' if mask>>j&1 else '-' for j in range(3)]
 if a+sum(v if op=='+' else -v for v,op in zip((b,c,d),ops))==7:
  print(s[0]+''.join(op+digit for op,digit in zip(ops,s[1:]))+'=7');break
''')

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def column(a:list[int])->str:return ''.join(f'{v}\n' for v in a)
def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
def generate(pid:str)->list[Case]:
    i=NUMBERS[pid];rng=random.Random(15800+i);raws:list[str]=[]
    if i==62:raws=[f'{h} {w}\n' for h,w in ((2,2),(2,3),(3,2),(3,3),(2,100000),(100000,2),(5,5),(7,11),(8,13),(11,17),(97,101),(99999,100000),(100000,99999),(99998,99997),(99997,99998),(99991,99989),(99989,99991),(100000,100000))]
    elif i==63:raws=['1\n1\n','1\n10\n','2\n5\n5\n','3\n10\n20\n30\n']+[f'{n}\n'+column([rng.randrange(1,101) for _ in range(n)]) for n in range(4,17)];raws.append('100\n'+column([100]*100))
    elif i==64:raws=[array([1]),array([3200]),array([3199]),array([399,400]),array([3200]*3)]+[array([rng.randrange(1,4801) for _ in range(n)]) for n in range(4,16)];raws.append(array([4800]*100))
    elif i==65:raws=[line([n,m]) for n,m in ((1,1),(1,2),(2,1),(1,3),(3,1),(2,2),(3,3),(4,5),(5,4),(9,10),(10,9),(10,11),(100,100),(100,101),(99999,100000),(100000,99999),(100000,1),(100000,100000))]
    elif i==66:raws=[array([0]),array([10**9]),array([1,2]),array([1,2,3])]+[array([rng.randrange(100) for _ in range(n)]) for n in range(4,17)];raws.append(array([10**9]*200000))
    elif i==67:raws=[array([-10**9,-10**9]),array([-10**9,10**9]),array([1,1]),array([1,-1,1,-1])]+[array([rng.randrange(-100,101) for _ in range(n)]) for n in range(3,16)];raws.append(array([10**9]*200000))
    elif i==68:
        def graph(n:int,edges:list[Pair])->str:return f'{n} {len(edges)}\n'+''.join(f'{u} {v}\n' for u,v in edges)
        raws=[graph(3,[(1,2)]),graph(3,[(1,2),(2,3)]),graph(4,[(1,2),(2,3),(3,4)]),graph(4,[(1,3),(3,4)])]
        for n in range(5,18):raws.append(graph(n,[(j,j+1) for j in range(1,n)]+([(1,n-1)] if n%2 else [])))
        raws.append(graph(200000,[(1,j) for j in range(2,200000)]+[(2,200000),(3,200000)]))
    elif i==69:raws=[array([1,1]),array([1,4]),array([2,2]),array([1,4,1]),array([1,4,2])]+[array([rng.randrange(1,17) for _ in range(n)]) for n in range(4,16)];raws.append(array([10**9]*100000))
    elif i==70:
        def clocks(a:list[int])->str:return f'{len(a)}\n'+column(a)
        raws=[clocks([1]),clocks([10**18]),clocks([6,10,15]),clocks([2,4,8])]+[clocks([2**j,5**(j//2),10**(j//2)]) for j in range(2,15)];raws.append(clocks([10**18]*100))
    elif i==71:raws=[array([1]*4),array([1,2,3,4]),array([2,2,3,3]),array([2,2,2,3]),array([10**9]*4)]+[array([rng.randrange(1,10) for _ in range(n)]) for n in range(5,17)];raws.append(array([10**9]*100000))
    elif i==72:raws=[array([0]),array([99999]),array([0,1,2]),array([0,3]),array([1,1,1])]+[array([rng.randrange(20) for _ in range(n)]) for n in range(4,16)];raws.append(array([99999]*100000))
    elif i==73:raws=['1\n1\n','2\n1\n1\n','3\n1\n1\n1\n','3\n1\n2\n3\n']+[f'{n}\n'+column([rng.randrange(1,10) for _ in range(n)]) for n in range(4,17)];raws.append('100000\n'+column([10**9]*100000))
    elif i==74:
        raws=['1 2 1 2 1 100\n','1 2 1 2 100 200\n','1 2 29 30 1 1000\n','1 2 1 2 1 101\n']+[f'{1+j%4} {6+j%5} {1+j%5} {7+j%7} {1+j*7} {1000+j*50}\n' for j in range(13)];raws.append('29 30 29 30 100 3000\n')
    elif i==75:
        def graph(n:int,edges:list[Pair])->str:return f'{n} {len(edges)}\n'+''.join(f'{u} {v}\n' for u,v in edges)
        raws=[graph(2,[(1,2)]),graph(3,[(1,2),(2,3),(1,3)]),graph(4,[(1,2),(2,3),(3,4)]),graph(4,[(1,2),(2,3),(1,3),(3,4)])]
        for n in range(5,18):raws.append(graph(n,[(j,j+1) for j in range(1,n)]+([(1,n)] if n%2 else [])))
        raws.append(graph(50,[(j,j+1) for j in range(1,50)]+[(1,50)]))
    elif i==76:raws=['a\na\n','a\nb\n','?\na\n','??\nb\n','ab?\nabc\n']+['?'*n+'\n'+'b'*(1+n%4)+'\n' for n in range(3,15)];raws.append('?'*50+'\n'+'z'*50+'\n')
    elif i==77:
        def festival(a:list[int],b:list[int],c:list[int])->str:return f'{len(a)}\n'+line(a)+line(b)+line(c)
        raws=[festival([1],[1],[1]),festival([1],[2],[3]),festival([3],[2],[1]),festival([1,1],[2,2],[3,3])]+[festival(*[[rng.randrange(1,30) for _ in range(n)] for _ in range(3)]) for n in range(3,16)];raws.append(festival([1]*100000,[500000000]*100000,[10**9]*100000))
    elif i==78:raws=[line([n,m]) for n,m in ((1,1),(2,1),(2,2),(3,1),(3,2),(3,3),(4,1),(4,2),(4,3),(4,4),(5,5),(10,1),(10,5),(50,3),(99,5),(100,1),(100,4),(100,5))]
    else:
        legal=[f'{n:04}' for n in range(10000) if ticket_answers(f'{n:04}')];raws=[legal[0]+'\n','1222\n','0007\n','7000\n'];raws=list(dict.fromkeys(raws))
        while len(raws)<17:
            raw=rng.choice(legal)+'\n'
            if raw not in raws and raw!=legal[-1]+'\n':raws.append(raw)
        raws.append(legal[-1]+'\n')
    require(len(raws)==len(set(raws))==18,'eighteen distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'edge_or_seeded'} for j,raw in enumerate(raws)]

TITLES={'arc074_a': 'Chocolate Bar', 'arc075_a': 'Bugged', 'abc064_c': 'Colorful Leaderboard', 'arc076_a': 'Reconciled?', 'arc077_a': 'pushpush', 'arc078_a': 'Splitting Pile', 'arc079_a': 'Cat Snuke and a Voyage', 'arc080_a': '4-adjacent', 'abc070_c': 'Multiple Clocks', 'arc081_a': 'Make a Rectangle', 'arc082_a': 'Together', 'abc073_c': 'Write and Erase', 'arc083_a': 'Sugar Water', 'abc075_c': 'Bridge', 'abc076_c': 'Dubious Document 2', 'arc084_a': 'Snuke Festival', 'arc085_a': 'HSI', 'abc079_c': 'Train Ticket'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'arc074_a': [{'input': '3 5\n', 'expected': '0\n'}, {'input': '4 5\n', 'expected': '2\n'}, {'input': '5 5\n', 'expected': '4\n'}, {'input': '100000 2\n', 'expected': '1\n'}, {'input': '100000 100000\n', 'expected': '50000\n'}], 'arc075_a': [{'input': '3\n5\n10\n15\n', 'expected': '25\n'}, {'input': '3\n10\n10\n15\n', 'expected': '35\n'}, {'input': '3\n10\n20\n30\n', 'expected': '0\n'}], 'abc064_c': [{'input': '4\n2100 2500 2700 2700\n', 'expected': '2 2\n'}, {'input': '5\n1100 1900 2800 3200 3200\n', 'expected': '3 5\n'}, {'input': '20\n800 810 820 830 840 850 860 870 880 890 900 910 920 930 940 950 960 970 980 990\n', 'expected': '1 1\n'}], 'arc076_a': [{'input': '2 2\n', 'expected': '8\n'}, {'input': '3 2\n', 'expected': '12\n'}, {'input': '1 8\n', 'expected': '0\n'}, {'input': '100000 100000\n', 'expected': '530123477\n'}], 'arc077_a': [{'input': '4\n1 2 3 4\n', 'expected': '4 2 1 3\n'}, {'input': '3\n1 2 3\n', 'expected': '3 1 2\n'}, {'input': '1\n1000000000\n', 'expected': '1000000000\n'}, {'input': '6\n0 6 7 6 7 0\n', 'expected': '0 6 6 0 7 7\n'}], 'arc078_a': [{'input': '6\n1 2 3 4 5 6\n', 'expected': '1\n'}, {'input': '2\n10 -10\n', 'expected': '20\n'}], 'arc079_a': [{'input': '3 2\n1 2\n2 3\n', 'expected': 'POSSIBLE\n'}, {'input': '4 3\n1 2\n2 3\n3 4\n', 'expected': 'IMPOSSIBLE\n'}, {'input': '100000 1\n1 99999\n', 'expected': 'IMPOSSIBLE\n'}, {'input': '5 5\n1 3\n4 5\n2 3\n2 4\n1 4\n', 'expected': 'POSSIBLE\n'}], 'arc080_a': [{'input': '3\n1 10 100\n', 'expected': 'Yes\n'}, {'input': '4\n1 2 3 4\n', 'expected': 'No\n'}, {'input': '3\n1 4 1\n', 'expected': 'Yes\n'}, {'input': '2\n1 1\n', 'expected': 'No\n'}, {'input': '6\n2 7 1 8 2 8\n', 'expected': 'Yes\n'}], 'abc070_c': [{'input': '2\n2\n3\n', 'expected': '6\n'}, {'input': '5\n2\n5\n10\n1000000000000000000\n1000000000000000000\n', 'expected': '1000000000000000000\n'}], 'arc081_a': [{'input': '6\n3 1 2 4 2 1\n', 'expected': '2\n'}, {'input': '4\n1 2 3 4\n', 'expected': '0\n'}, {'input': '10\n3 3 3 3 4 4 4 5 5 5\n', 'expected': '20\n'}], 'arc082_a': [{'input': '7\n3 1 4 1 5 9 2\n', 'expected': '4\n'}, {'input': '10\n0 1 2 3 4 5 6 7 8 9\n', 'expected': '3\n'}, {'input': '1\n99999\n', 'expected': '1\n'}], 'abc073_c': [{'input': '3\n6\n2\n6\n', 'expected': '1\n'}, {'input': '4\n2\n5\n5\n2\n', 'expected': '0\n'}, {'input': '6\n12\n22\n16\n22\n18\n12\n', 'expected': '2\n'}], 'arc083_a': [{'input': '1 2 10 20 15 200\n', 'expected': '110 10\n'}, {'input': '1 2 1 2 100 1000\n', 'expected': '200 100\n'}, {'input': '17 19 22 26 55 2802\n', 'expected': '2634 934\n'}], 'abc075_c': [{'input': '7 7\n1 3\n2 7\n3 4\n4 5\n4 6\n5 6\n6 7\n', 'expected': '4\n'}, {'input': '3 3\n1 2\n1 3\n2 3\n', 'expected': '0\n'}, {'input': '6 5\n1 2\n2 3\n3 4\n4 5\n5 6\n', 'expected': '5\n'}], 'abc076_c': [{'input': '?tc????\ncoder\n', 'expected': 'atcoder\n'}, {'input': '??p??d??\nabc\n', 'expected': 'UNRESTORABLE\n'}], 'arc084_a': [{'input': '2\n1 5\n2 4\n3 6\n', 'expected': '3\n'}, {'input': '3\n1 1 1\n2 2 2\n3 3 3\n', 'expected': '27\n'}, {'input': '6\n3 14 159 2 6 53\n58 9 79 323 84 6\n2643 383 2 79 50 288\n', 'expected': '87\n'}], 'arc085_a': [{'input': '1 1\n', 'expected': '3800\n'}, {'input': '10 2\n', 'expected': '18400\n'}, {'input': '100 5\n', 'expected': '608000\n'}], 'abc079_c': [{'input': '1222\n', 'expected': '1+2+2+2=7\n'}, {'input': '0290\n', 'expected': '0-2+9+0=7\n'}, {'input': '3242\n', 'expected': '3+2+4-2=7\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
