"""ABC278–280 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc278_b', 'abc279_b', 'abc280_b')
INT = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc278_b': [
        {'input': '1 23\n', 'expected': '1 23\n'},
        {'input': '19 57\n', 'expected': '20 0\n'},
        {'input': '20 40\n', 'expected': '21 0\n'},
    ],
    'abc279_b': [
        {'input': 'voltage\ntag\n', 'expected': 'Yes\n'},
        {'input': 'atcoder\nace\n', 'expected': 'No\n'},
        {'input': 'gorilla\ngorillagorillagorilla\n', 'expected': 'No\n'},
        {'input': 'toyotasystems\ntoyotasystems\n', 'expected': 'Yes\n'},
    ],
    'abc280_b': [
        {'input': '3\n3 4 8\n', 'expected': '3 1 4\n'},
        {
            'input': '10\n314159265 358979323 846264338 -327950288 419716939 -937510582 97494459 230781640 628620899 -862803482\n',
            'expected': '314159265 44820058 487285015 -1174214626 747667227 -1357227521 1035005041 133287181 397839259 -1491424381\n',
        },
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate278(raw: str) -> tuple[int, int]:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    vals = _ints_line(lines[0])
    if len(vals) != 2:
        raise ValueError('header')
    h, m = vals
    if not (0 <= h <= 23 and 0 <= m <= 59):
        raise ValueError('constraints')
    return h, m


def _validate279(raw: str) -> tuple[str, str]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    s, t = lines
    if LOWER.fullmatch(s) is None or LOWER.fullmatch(t) is None:
        raise ValueError('syntax')
    if not (1 <= len(s) <= 100 and 1 <= len(t) <= 100):
        raise ValueError('constraints')
    return s, t


def _validate280(raw: str) -> list[int]:
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 1:
        raise ValueError('header')
    n = head[0]
    vals = _ints_line(lines[1])
    if not 1 <= n <= 10 or len(vals) != n or any(not -(10**9) <= x <= 10**9 for x in vals):
        raise ValueError('constraints')
    return vals


def validate(pid: str, raw: str):
    if pid == 'abc278_b':
        return _validate278(raw)
    if pid == 'abc279_b':
        return _validate279(raw)
    if pid == 'abc280_b':
        return _validate280(raw)
    raise ValueError('unknown task')


def _confusing(h: int, m: int) -> bool:
    a, b = divmod(h, 10)
    c, d = divmod(m, 10)
    swapped_h = 10 * a + c
    swapped_m = 10 * b + d
    return 0 <= swapped_h <= 23 and 0 <= swapped_m <= 59


def _oracle278(h: int, m: int) -> tuple[int, int]:
    start = 60 * h + m
    valid = [minute for minute in range(24 * 60) if _confusing(minute // 60, minute % 60)]
    best = min(valid, key=lambda minute: (minute - start) % (24 * 60))
    return best // 60, best % 60


def _oracle279(s: str, t: str) -> str:
    if len(t) > len(s):
        return 'No'
    for i in range(len(s) - len(t) + 1):
        if all(s[i + j] == t[j] for j in range(len(t))):
            return 'Yes'
    return 'No'


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc278_b':
        try:
            vals = _ints_line(output)
        except ValueError:
            return False
        return len(vals) == 2 and tuple(vals) == _oracle278(*value)
    if pid == 'abc279_b':
        return output in ('Yes', 'No') and output == _oracle279(*value)

    try:
        vals = _ints_line(output)
    except ValueError:
        return False
    s = value
    if len(vals) != len(s):
        return False
    total = 0
    for a, target in zip(vals, s):
        total += a
        if total != target:
            return False
    return True


def _prefix_input(vals: list[int]) -> str:
    return f'{len(vals)}\n' + ' '.join(map(str, vals)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc278_b':
        custom = [
            ('midnight', '0 0\n'),
            ('hour_boundary', '0 59\n'),
            ('single_hour_late', '1 59\n'),
            ('early_invalid', '2 30\n'),
            ('five_fiftyfive', '5 55\n'),
            ('ten_zero', '10 0\n'),
            ('repeated_digits', '11 11\n'),
            ('twelve_thirtyfour', '12 34\n'),
            ('fifteen_fifty', '15 50\n'),
            ('nineteen_fiftynine', '19 59\n'),
            ('known_confusing', '20 13\n'),
            ('twentyone_fiftynine', '21 59\n'),
            ('twentytwo_twentytwo', '22 22\n'),
            ('late_hour', '23 0\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', '23 59\n')

    elif pid == 'abc279_b':
        custom = [
            ('single_equal', 'a\na\n'),
            ('single_diff', 'a\nb\n'),
            ('prefix_one', 'abc\na\n'),
            ('suffix_one', 'abc\nc\n'),
            ('suffix_two', 'abc\nbc\n'),
            ('subsequence_not_substring', 'abc\nac\n'),
            ('repeat_yes', 'aaaa\naa\n'),
            ('repeat_no', 'aaaa\nb\n'),
            ('overlap_yes', 'ababab\nbaba\n'),
            ('suffix_word', 'xyzabc\nabc\n'),
            ('prefix_word', 'abcxyz\nabc\n'),
            ('inside_repeat', 'mississippi\nissi\n'),
            ('reverse_no', 'abcdefghij\njih\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', 'a' * 100 + '\n' + ('a' * 99 + 'b') + '\n')

    else:
        custom_vals = [
            ('single_zero', [0]),
            ('single_max', [10**9]),
            ('single_min', [-(10**9)]),
            ('two_zero', [0, 0]),
            ('two_rise_extreme', [-(10**9), 10**9]),
            ('two_fall_extreme', [10**9, -(10**9)]),
            ('three_increasing', [1, 2, 3]),
            ('three_decreasing', [3, 2, 1]),
            ('four_alternating', [0, 1, 0, 1]),
            ('five_all_max', [10**9] * 5),
            ('five_all_min', [-(10**9)] * 5),
            ('six_mixed', [-5, 0, 5, 0, -5, 0]),
            ('ten_small_increasing', list(range(10))),
            ('ten_negative_decreasing', [-i for i in range(1, 11)]),
            ('ten_boundary_mix', [10**9, 0, -(10**9), 10**9, 1, -1, 500000000, -500000000, 999999999, -999999999]),
        ]
        for category, vals in custom_vals:
            add(category, _prefix_input(vals))
        add('constraint_max', _prefix_input([10**9 if i % 2 == 0 else -(10**9) for i in range(10)]))

    if len(out) != 18 or len({row['input'] for row in out}) != 18 or out[-1]['category'] != 'constraint_max':
        raise AssertionError(f'{pid}: expected 18 distinct cases ending in constraint_max, got {len(out)}')
    return out
