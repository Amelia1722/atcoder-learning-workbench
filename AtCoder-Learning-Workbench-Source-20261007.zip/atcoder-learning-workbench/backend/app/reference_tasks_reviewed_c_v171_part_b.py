"""Backward bitsets, finite-difference cubes and max-plus stack folds."""
from __future__ import annotations
from bisect import bisect_right
from collections import Counter
from functools import lru_cache
from itertools import combinations
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in (341,342,343,344,345,352))
CONTESTS={pid:pid.split('_')[0] for pid in TASKS}
OUTPUT_MODES:dict[str,str]={}
Data=tuple[object,...]
Case=dict[str,str]
Grid=tuple[str,...]
Pair=tuple[int,int]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');values=tuple(map(int,row.split(' ')));require(count is None or len(values)==count,'fields');return values

def _backward_positions(path:str,grid:Grid)->int:
    land=[sum(1<<c for c,ch in enumerate(row) if ch=='.') for row in grid];possible=land[:]
    for ch in reversed(path):
        if ch=='R':possible=[bits>>1&allowed for bits,allowed in zip(possible,land)]
        elif ch=='L':possible=[bits<<1&allowed for bits,allowed in zip(possible,land)]
        elif ch=='U':possible=[0]+[bits&allowed for bits,allowed in zip(possible[:-1],land[1:])]
        else:possible=[bits&allowed for bits,allowed in zip(possible[1:],land[:-1])]+[0]
    return sum(bits.bit_count() for bits in possible)

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==341:
        h,w,n=ints(rows[0],3);require(3<=h<=500 and 3<=w<=500 and 1<=n<=500 and len(rows)==h+2,'shape');path=rows[1];grid=tuple(rows[2:]);require(len(path)==n and set(path)<={'RLUD'[i] for i in range(4)} and all(len(row)==w and set(row)<={'#','.'} for row in grid),'map');require(set(grid[0]+grid[-1])=={'#'} and all(row[0]==row[-1]=='#' for row in grid),'sea border');require(_backward_positions(path,grid)>0,'possible destination');return path,grid
    if number==342:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)>=4 and len(rows[1])==n and re.fullmatch('[a-z]+',rows[1]) is not None,'string');q=ints(rows[2],1)[0];require(1<=q<=200000 and len(rows)==q+3,'queries');queries=tuple(tuple(row.split(' ')) for row in rows[3:]);require(all(len(pair)==2 and all(re.fullmatch('[a-z]',ch) is not None for ch in pair) for pair in queries),'letters');return rows[1],queries
    if number==343:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**18,'upper bound');return (n,)
    if number==344:
        require(len(rows)==8,'shape');a,b,c=(ints(rows[i+1],ints(rows[i],1)[0]) for i in (0,2,4));q=ints(rows[6],1)[0];queries=ints(rows[7],q);require(all(1<=len(seq)<=100 and all(0<=v<=10**8 for v in seq) for seq in (a,b,c)) and 1<=q<=200000 and all(0<=v<=3*10**8 for v in queries),'sums');return a,b,c,queries
    if number==345:
        require(len(rows)==1 and 2<=len(rows[0])<=1000000 and re.fullmatch('[a-z]+',rows[0]) is not None,'string');return (rows[0],)
    n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==n+1,'shape');pairs=tuple(ints(row,2) for row in rows[1:]);require(all(1<=a<=b<=10**9 for a,b in pairs),'giants');return (pairs,)

def _numeric_palindrome(value:int)->bool:
    if value%10==0:return False
    reversed_half=0
    while value>reversed_half:reversed_half=reversed_half*10+value%10;value//=10
    return value==reversed_half or value==reversed_half//10

@lru_cache(maxsize=1)
def _palindromic_cubes()->tuple[int,...]:
    # Third finite differences of x^3 are the constant 6.
    cube,first,second=1,7,12;values=[]
    while cube<=10**18:
        if _numeric_palindrome(cube):values.append(cube)
        cube+=first;first+=second;second+=6
    return tuple(values)

def _giant_fold(pairs:tuple[Pair,...])->int:
    total=best=0
    for a,b in pairs:best=max(best+a,total+b);total+=a
    return best

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==341:return str(_backward_positions(*cast(tuple[str,Grid],data)))
    if number==342:
        s,queries=cast(tuple[str,tuple[tuple[str,str],...]],data);mapping={ch:ch for ch in 'abcdefghijklmnopqrstuvwxyz'}
        for source,target in reversed(queries):mapping[source]=mapping[target]
        return ''.join(mapping[ch] for ch in s)
    if number==343:
        cubes=_palindromic_cubes();return str(cubes[bisect_right(cubes,cast(int,data[0]))-1])
    if number==344:
        a,b,c,queries=cast(tuple[tuple[int,...],tuple[int,...],tuple[int,...],tuple[int,...]],data);pairs={u+v for u in a for v in b};third=set(c);memo={x:any(x-v in pairs for v in third) for x in set(queries)};return '\n'.join('Yes' if memo[x] else 'No' for x in queries)
    if number==345:
        counts=tuple(Counter(cast(str,data[0])).values());return str(sum(a*b for a,b in combinations(counts,2))+int(any(v>=2 for v in counts)))
    return str(_giant_fold(cast(tuple[Pair,...],data[0])))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc341_c':"h,w,n=map(int,input().split());t=input();s=[input() for _ in range(h)];x=y=0;offsets={(0,0)}\nfor ch in t:x+=(ch=='D')-(ch=='U');y+=(ch=='R')-(ch=='L');offsets.add((x,y))\nanswer=0\nfor r in range(1,h-1):\n for c in range(1,w-1):\n  answer+=all(0<=r+dr<h and 0<=c+dc<w and s[r+dr][c+dc]=='.' for dr,dc in offsets)\nprint(answer)\n",
'abc342_c':"n=int(input());s=input();q=int(input());mapping=list('abcdefghijklmnopqrstuvwxyz')\nfor _ in range(q):\n c,d=input().split();mapping=[d if ch==c else ch for ch in mapping]\nprint(''.join(mapping[ord(ch)-97] for ch in s))\n",
'abc343_c':"n=int(input());i=1;answer=1\nwhile i*i*i<=n:\n cube=i*i*i;s=str(cube)\n if s==s[::-1]:answer=cube\n i+=1\nprint(answer)\n",
'abc344_c':"n=int(input());a=list(map(int,input().split()));m=int(input());b=list(map(int,input().split()));l=int(input());c=list(map(int,input().split()));q=int(input());x=list(map(int,input().split()));sums={u+v+w for u in a for v in b for w in c};print(*('Yes' if v in sums else 'No' for v in x),sep='\\n')\n",
'abc345_c':"s=input();counts={};answer=0;same=False\nfor i,ch in enumerate(s):\n seen=counts.get(ch,0);answer+=i-seen;same|=seen>0;counts[ch]=seen+1\nprint(answer+same)\n",
'abc352_c':"n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];print(sum(u for u,v in a)+max(v-u for u,v in a))\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17100+number)
    if number==341:
        def travel(path:str,grid:list[str])->str:return f'{len(grid)} {len(grid[0])} {len(path)}\n{path}\n'+'\n'.join(grid)+'\n'
        raws=[travel('R',['####','#..#','####']),travel('L',['####','#..#','####']),travel('D',['###','#.#','#.#','###']),travel('U',['###','#.#','#.#','###'])]
        for n in range(5,17):
            grid=['#'*n]+['#'+'.'*(n-2)+'#' for _ in range(n-2)]+['#'*n];raws.append(travel('RL'*(n//2),grid))
        grid=['#'*500]+['#'+'.'*498+'#' for _ in range(498)]+['#'*500];raws.extend([travel('R'*497+'LLL',grid),travel('RL'*250,grid)])
    elif number==342:
        def replace(s:str,queries:list[tuple[str,str]])->str:return f'{len(s)}\n{s}\n{len(queries)}\n'+''.join(f'{a} {b}\n' for a,b in queries)
        raws=[replace('a',[('a','a')]),replace('a',[('a','b')]),replace('ab',[('a','b'),('b','a')]),replace('a',[('z','b')])]
        for n in range(3,15):raws.append(replace(''.join(rng.choice('abc') for _ in range(n)),[(rng.choice('abc'),rng.choice('abc')) for _ in range(n)]))
        raws.extend([replace('ab'*100000,[('a','b'),('b','a')]*100000),replace('z'*200000,[('z','z')]*200000)])
    elif number==343:raws=[f'{n}\n' for n in (1,2,7,8,9,26,27,28,124,125,342,343,344,1000,10**9,10**12,10**18-1,10**18)]
    elif number==344:
        def sums(a:list[int],b:list[int],c:list[int],q:list[int])->str:return ''.join(f'{len(v)}\n'+line(v) for v in (a,b,c,q))
        raws=[sums([0],[0],[0],[0]),sums([0],[0],[0],[1]),sums([1],[2],[3],[5,6,7]),sums([0,0],[0],[1],[1,2])]
        for n in range(3,15):raws.append(sums([rng.randint(0,30) for _ in range(n)],[rng.randint(0,30) for _ in range(n)],[rng.randint(0,30) for _ in range(n)],[rng.randint(0,90) for _ in range(n+2)]))
        raws.extend([sums([i*1000000 for i in range(100)],[i*10000 for i in range(100)],list(range(100)),[rng.randint(0,3*10**8) for _ in range(200000)]),sums([10**8]*100,[10**8]*100,[10**8]*100,[3*10**8]*200000)])
    elif number==345:
        raws=[s+'\n' for s in ('aa','ab','aba','abc','aabb','abab','aaaa','abcd','abcabc','aabcc','zzxy','abababab','abcdefgh','abbaabba','abcdefghijklmnopqrstuvwxyz','a'*100)]
        raws.extend([('abcdefghijklmnopqrstuvwxyz'*38461+'abcdefghijklmn')+'\n','z'*1000000+'\n'])
    else:
        def giants(a:list[Pair])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[giants(a) for a in ([(1,1),(1,1)],[(1,2),(1,1)],[(1,1),(1,2)],[(2,3),(1,10),(5,5)])]
        for n in range(3,15):raws.append(giants([(rng.randint(1,50),100) for _ in range(n)]))
        raws.extend([giants([(rng.randint(1,10**9),10**9) for _ in range(200000)]),giants([(10**9,10**9)]*200000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<4 or i==16 else 'deterministic_random'} for i,raw in enumerate(raws)]

HINTS={
'abc341_c':('全候補の不時着地点について、経路上が全て陸か確認します。','移動の累積相対座標を先に求め、各候補に足して陸であるか調べます。同じ相対座標は一度調べれば十分です。','疑似コード: offsets={(0,0)}; Tを走査して相対座標追加; 各内部マスで全offset先が範囲内の陸ならanswer++; answerを出力。'),
'abc342_c':('元の26文字が最終的に何になるかだけ管理できます。','各置換で、対応先がcの元文字全ての対応をdへ変えます。','疑似コード: map=26文字のidentity; 各c,dでmapの値cをdへ変更; 元Sの各文字をmapで変換して出力。'),
'abc343_c':('立方根の上限は100万なので全列挙できます。','各xの立方数を文字列にし、逆順と同じなら答えを更新します。','疑似コード: x=1; x³<=Nの間、str(x³)==reverse(str(x³))ならanswer=x³; x++; answerを出力。'),
'abc344_c':('3列の長さは各100以下です。','3列から選ぶ全ての和を集合に登録してから、各クエリの集合所属を調べます。','疑似コード: sums={a+b+c | a∈A,b∈B,c∈C}; 各XについてsumsにあればYes、無ければNo。'),
'abc345_c':('異なる文字の2位置を交換すると、その位置の組ごとに別の文字列になります。','左から見た違う文字の数を足します。同じ文字が重複すれば、元の文字列も一通り加えます。','疑似コード: 各位置iの文字cでanswer+=i-count[c]; count[c]++; 重複があれば最後に1加算; answerを出力。'),
'abc352_c':('一番上の巨人だけ頭までの高さを使います。','全員の肩の高さの合計に、一番上の頭と肩の差を加えます。この差が最大の巨人を選びます。','疑似コード: total=sum(A); extra=max(B-A); total+extraを出力。')}

TITLES={'abc341_c': 'Takahashi Gets Lost', 'abc342_c': 'Many Replacement', 'abc343_c': '343', 'abc344_c': 'A+B+C', 'abc345_c': 'One Time Swap', 'abc352_c': 'Standing On The Shoulders'}
PUBLISHED_SAMPLES={'abc341_c': [{'input': '6 7 5\nLULDR\n#######\n#...#.#\n##...##\n#.#...#\n#...#.#\n#######\n', 'expected': '2\n'}, {'input': '13 16 9\nULURDLURD\n################\n##..##.#..####.#\n###.#..#.....#.#\n#..##..#####.###\n#...#..#......##\n###.##.#..#....#\n##.#####....##.#\n###.###.#.#.#..#\n######.....##..#\n#...#.#.######.#\n##..###..#..#.##\n#...#.#.#...#..#\n################\n', 'expected': '6\n'}], 'abc342_c': [{'input': '7\natcoder\n4\nr a\nt e\nd v\na r\n', 'expected': 'recover\n'}, {'input': '3\nabc\n4\na a\ns k\nn n\nz b\n', 'expected': 'abc\n'}, {'input': '34\nsupercalifragilisticexpialidocious\n20\ng c\nl g\ng m\nc m\nr o\ns e\na a\no f\nf s\ne t\nt l\nd v\np k\nv h\nx i\nh n\nn j\ni r\ns i\nu a\n', 'expected': 'laklimamriiamrmrllrmlrkramrjimrial\n'}], 'abc343_c': [{'input': '345\n', 'expected': '343\n'}, {'input': '6\n', 'expected': '1\n'}, {'input': '123456789012345\n', 'expected': '1334996994331\n'}], 'abc344_c': [{'input': '3\n1 2 3\n2\n2 4\n6\n1 2 4 8 16 32\n4\n1 5 10 50\n', 'expected': 'No\nYes\nYes\nNo\n'}], 'abc345_c': [{'input': 'abc\n', 'expected': '3\n'}, {'input': 'aaaaa\n', 'expected': '1\n'}], 'abc352_c': [{'input': '3\n4 10\n5 8\n2 9\n', 'expected': '18\n'}, {'input': '5\n1 1\n1 1\n1 1\n1 1\n1 1\n', 'expected': '5\n'}, {'input': '10\n690830957 868532399\n741145463 930111470\n612846445 948344128\n540375785 925723427\n723092548 925021315\n928915367 973970164\n563314352 832796216\n562681294 868338948\n923012648 954764623\n691107436 891127278\n', 'expected': '7362669937\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
