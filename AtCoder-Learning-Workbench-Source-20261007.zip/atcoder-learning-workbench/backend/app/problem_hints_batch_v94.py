"""Statement-checked three-stage hints added while reviewing ABC140–142 B."""
HINTS_V94 = {
    'abc140_b': (
        'まず各料理そのものの満足度は必ず得られます。追加点が入るのは、食べる順番の隣り合う2皿がどんな関係のときか確認してください。',
        '基本点は sum(B) と同じです。食べる順番 A を隣接ペアで見て、A[i+1] == A[i] + 1 のときだけ C[A[i]-1] を加えます。',
        '''疑似コード:
ans = sum(B)
for i = 0 .. N-2:
  if A[i+1] == A[i] + 1:
    ans += C[A[i]-1]
print(ans)'''
    ),
    'abc141_b': (
        '文字列の位置を奇数番目と偶数番目に分け、それぞれ置いてはいけない文字が何か整理してください。',
        '1-indexedの奇数位置では L が不可、偶数位置では R が不可です。左から1文字ずつ確認すれば十分です。',
        '''疑似コード:
for i, ch in enumerate(S):
  if i is even and ch == "L": print("No"); stop
  if i is odd and ch == "R": print("No"); stop
print("Yes")'''
    ),
    'abc142_b': (
        '各人を独立に見て、ジェットコースターに乗れる条件を満たす人だけ数えてください。',
        '身長 h_i が K 以上なら1人加算します。ソートなどは不要で、1回の走査で足ります。',
        '''疑似コード:
ans = 0
for h in H:
  if h >= K:
    ans += 1
print(ans)'''
    ),
}
