"""Private ABC383..388 D, source-authoritative strict domain and independent oracles."""
from __future__ import annotations
from typing import cast
from bisect import bisect_left,bisect_right
from collections import deque
from math import isqrt
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(383,389));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None,signed:bool=False)->tuple[int,...]:
 pattern=r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*' if signed else r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*'
 require(re.fullmatch(pattern,s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc383_d':
  require(len(r)==1,'shape');n=ints(r[0],1)[0];require(1<=n<=4*10**12,'N');return (n,)
 if pid=='abc384_d':
  n,s=ints(r[0],2);require(1<=n<=200000 and 1<=s<=10**18 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=x<=10**9 for x in a),'Ai');return s,a
 if pid=='abc385_d':
  n,q,x,y=ints(r[0],4,True);require(1<=n<=200000 and 1<=q<=200000 and -10**9<=x<=10**9 and -10**9<=y<=10**9 and len(r)==1+n+q,'shape');houses=tuple(ints(s,2,True) for s in r[1:n+1]);require(len(set(houses))==n and (x,y) not in houses and all(all(-10**9<=v<=10**9 for v in p) for p in houses),'houses');moves=[]
  for row in r[n+1:]:
   fields=row.split(' ');require(len(fields)==2 and fields[0] in ('U','D','L','R'),'direction');distance=ints(fields[1],1)[0];require(1<=distance<=10**9,'distance');moves.append((fields[0],distance))
  return x,y,houses,tuple(moves)
 if pid=='abc386_d':
  n,m=ints(r[0],2);require(1<=n<=10**9 and 1<=m<=min(n*n,200000) and len(r)==m+1,'shape');points=[]
  for row in r[1:]:
   fields=row.split(' ');require(len(fields)==3 and fields[2] in ('B','W'),'color');x,y=ints(' '.join(fields[:2]),2);require(1<=x<=n and 1<=y<=n,'coordinate');points.append((x,y,fields[2]))
  require(len({(x,y) for x,y,_ in points})==m,'distinct');return n,tuple(points)
 if pid=='abc387_d':
  h,w=ints(r[0],2);require(1<=h<=1000 and 1<=w<=1000 and len(r)==h+1,'shape');grid=tuple(r[1:]);require(all(re.fullmatch('[SG.#]{'+str(w)+'}',s) is not None for s in grid) and sum(row.count('S') for row in grid)==1 and sum(row.count('G') for row in grid)==1,'grid');return (grid,)
 n=ints(r[0],1)[0];require(1<=n<=500000 and len(r)==2,'shape');a=ints(r[1],n);require(all(0<=x<=500000 for x in a),'stones');return (a,)

def prime_list(limit:int)->list[int]:
 sieve=bytearray(b'\1')*(limit+1)
 if limit>=0:sieve[0]=0
 if limit>=1:sieve[1]=0
 for p in range(2,isqrt(limit)+1):
  if sieve[p]:sieve[p*p:limit+1:p]=b'\0'*((limit-p*p)//p+1)
 return [p for p in range(2,limit+1) if sieve[p]]
def nine_divisors_prime_ranks(n:int)->int:
 bound=isqrt(n);primes=prime_list(bound//2);answer=0
 for p in primes:
  if p**8>n:break
  answer+=1
 for i,p in enumerate(primes):
  if p*p>=bound:break
  answer+=max(0,bisect_right(primes,bound//p)-i-1)
 return answer

def periodic_prefix_lookup(s:int,a:tuple[int,...])->bool:
 target=s%sum(a)
 if target==0:return True
 prefix=[0]
 for x in a+a:prefix.append(prefix[-1]+x)
 for i in range(len(a)):
  j=bisect_left(prefix,prefix[i]+target,i+1,i+len(a)+1)
  if j<=i+len(a) and j<len(prefix) and prefix[j]==prefix[i]+target:return True
 return False

def santa_offline_segments(x:int,y:int,houses:tuple[tuple[int,...],...],moves:tuple[tuple[str,int],...])->tuple[int,int,int]:
 horizontal:dict[int,list[tuple[int,int]]]={};vertical:dict[int,list[tuple[int,int]]]={}
 for direction,length in moves:
  nx=x+length*(int(direction=='R')-int(direction=='L'));ny=y+length*(int(direction=='U')-int(direction=='D'))
  if nx!=x:horizontal.setdefault(y,[]).append((min(x,nx),max(x,nx)))
  else:vertical.setdefault(x,[]).append((min(y,ny),max(y,ny)))
  x,y=nx,ny
 def merge(groups:dict[int,list[tuple[int,int]]])->dict[int,tuple[list[int],list[int]]]:
  result={}
  for key,intervals in groups.items():
   starts:list[int]=[];ends:list[int]=[]
   for left,right in sorted(intervals):
    if ends and left<=ends[-1]:ends[-1]=max(ends[-1],right)
    else:starts.append(left);ends.append(right)
   result[key]=(starts,ends)
  return result
 hg,vg=merge(horizontal),merge(vertical)
 def covered(group:dict[int,tuple[list[int],list[int]]],key:int,value:int)->bool:
  if key not in group:return False
  starts,ends=group[key];i=bisect_right(starts,value)-1;return i>=0 and value<=ends[i]
 count=sum(covered(hg,b,a) or covered(vg,a,b) for a,b in houses);return x,y,count

def separation_white_prefix(points:tuple[tuple[int,int,str],...])->bool:
 white=sorted((y,x) for x,y,c in points if c=='W');ys=[];minxs=[];low=10**30
 for y,x in white:ys.append(y);low=min(low,x);minxs.append(low)
 for x,y,c in points:
  if c=='B':
   i=bisect_right(ys,y)-1
   if i>=0 and minxs[i]<=x:return False
 return True

def snaky_bidirectional(grid:tuple[str,...])->int:
 h=len(grid);w=len(grid[0]);n=h*w;start=goal=0
 for r,row in enumerate(grid):
  for c,ch in enumerate(row):
   if ch=='S':start=r*w+c
   elif ch=='G':goal=r*w+c
 forward=[-1]*(2*n);backward=[-1]*(2*n);fq=deque([2*start,2*start+1]);bq=deque([2*goal,2*goal+1]);forward[2*start]=forward[2*start+1]=backward[2*goal]=backward[2*goal+1]=0;best=10**30
 def neighbors(state:int,reverse:bool)->list[int]:
  p,axis=divmod(state,2);r,c=divmod(p,w);movement=1-axis if reverse else axis;out=[]
  for delta in (-1,1):
   nr,nc=(r+delta,c) if movement==0 else (r,c+delta)
   if 0<=nr<h and 0<=nc<w and grid[nr][nc]!='#':out.append(2*(nr*w+nc)+(1-axis))
  return out
 while fq and bq:
  if forward[fq[0]]+backward[bq[0]]>=best:break
  reverse=len(bq)<len(fq);q=bq if reverse else fq;own=backward if reverse else forward;other=forward if reverse else backward;depth=own[q[0]]
  while q and own[q[0]]==depth:
   u=q.popleft()
   if other[u]>=0:best=min(best,depth+other[u])
   for v in neighbors(u,reverse):
    if own[v]<0:own[v]=depth+1;q.append(v)
    if other[v]>=0:best=min(best,own[v]+other[v])
 return -1 if best==10**30 else best

def adulthood_expiry_heap(a:tuple[int,...])->list[int]:
 active:list[int]=[];out=[];n=len(a)
 for i,initial in enumerate(a):
  while active and active[0]<i:heapq.heappop(active)
  stones=initial+len(active);out.append(max(0,stones-(n-i-1)))
  if stones:heapq.heappush(active,i+stones)
 return out

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc383_d':answer=str(nine_divisors_prime_ranks(cast(int,d[0])))
 elif pid=='abc384_d':answer='Yes' if periodic_prefix_lookup(cast(int,d[0]),cast(tuple[int,...],d[1])) else 'No'
 elif pid=='abc385_d':answer=' '.join(map(str,santa_offline_segments(cast(int,d[0]),cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2]),cast(tuple[tuple[str,int],...],d[3]))))
 elif pid=='abc386_d':answer='Yes' if separation_white_prefix(cast(tuple[tuple[int,int,str],...],d[1])) else 'No'
 elif pid=='abc387_d':answer=str(snaky_bidirectional(cast(tuple[str,...],d[0])))
 else:answer=' '.join(map(str,adulthood_expiry_heap(cast(tuple[int,...],d[0]))))
 return answer+'\n'
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,KeyError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc383_d':'''import math
n=int(input());limit=math.isqrt(n);s=bytearray(b'\\1')*(limit+1);s[0]=0
if limit>=1:s[1]=0
for p in range(2,math.isqrt(limit)+1):
 if s[p]:s[p*p:limit+1:p]=b'\\0'*((limit-p*p)//p+1)
p=[i for i in range(2,limit+1) if s[i]];ans=sum(x**8<=n for x in p);j=len(p)-1
for i in range(len(p)):
 while j>i and p[i]*p[j]>limit:j-=1
 if j<=i:break
 ans+=j-i
print(ans)
''',
'abc384_d':'''n,s=map(int,input().split());a=list(map(int,input().split()));s%=sum(a)
if s==0:print('Yes')
else:
 a=a+a;j=0;total=0;found=False
 for i in range(n):
  while j<i+n and total<s:total+=a[j];j+=1
  if total==s:found=True;break
  total-=a[i]
 print('Yes' if found else 'No')
''',
'abc385_d':'''import sys,bisect
it=iter(sys.stdin.buffer.read().split());n=int(next(it));m=int(next(it));x=int(next(it));y=int(next(it));houses=[(int(next(it)),int(next(it))) for _ in range(n)];vert=sorted(houses);horz=sorted((b,a) for a,b in houses);vi={p:i for i,p in enumerate(vert)};hi={(b,a):i for i,(a,b) in enumerate(horz)};pv=list(range(n+1));ph=list(range(n+1));count=0
def find(p,i):
 while p[i]!=i:p[i]=p[p[i]];i=p[i]
 return i
for _ in range(m):
 d=next(it).decode();c=int(next(it));nx=x+c*((d=='R')-(d=='L'));ny=y+c*((d=='U')-(d=='D'))
 if nx==x:items=vert;parent=pv;lo=(x,min(y,ny));upper=(x,max(y,ny))
 else:items=horz;parent=ph;lo=(y,min(x,nx));upper=(y,max(x,nx))
 j=find(parent,bisect.bisect_left(items,lo));end=bisect.bisect_right(items,upper)
 while j<end:
  a,b=items[j]
  if nx!=x:a,b=b,a
  v=vi[(a,b)];h=hi[(a,b)];pv[v]=find(pv,v+1);ph[h]=find(ph,h+1);count+=1;j=find(parent,j)
 x,y=nx,ny
print(x,y,count)
''',
'abc386_d':'''import sys
it=iter(sys.stdin.buffer.read().split());n=int(next(it));m=int(next(it));p=[(int(next(it)),int(next(it)),next(it).decode()) for _ in range(m)];p.sort(key=lambda t:(t[0],0 if t[2]=='W' else 1));low=n+1;ok=True
for x,y,c in p:
 if c=='W':low=min(low,y)
 elif y>=low:ok=False;break
print('Yes' if ok else 'No')
''',
'abc387_d':'''from collections import deque
h,w=map(int,input().split());g=[input() for _ in range(h)];start=goal=0
for r in range(h):
 for c in range(w):
  if g[r][c]=='S':start=r*w+c
  if g[r][c]=='G':goal=r*w+c
n=h*w;dist=[-1]*(2*n);q=deque([2*start,2*start+1]);dist[2*start]=dist[2*start+1]=0;answer=-1
while q:
 u=q.popleft();p,axis=divmod(u,2);r,c=divmod(p,w)
 if p==goal:answer=dist[u];break
 for delta in (-1,1):
  nr,nc=(r+delta,c) if axis==0 else (r,c+delta)
  if 0<=nr<h and 0<=nc<w and g[nr][nc]!='#':
   v=2*(nr*w+nc)+1-axis
   if dist[v]<0:dist[v]=dist[u]+1;q.append(v)
print(answer)
''',
'abc388_d':'''n=int(input());a=list(map(int,input().split()));diff=[0]*(n+2);received=0;out=[]
for i,x in enumerate(a):
 received+=diff[i];x+=received;give=min(x,n-i-1);out.append(x-give)
 if give:diff[i+1]+=1;diff[i+give+1]-=1
print(*out)
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc383_d':
  values=[1,35,36,255,256,257,6560,6561,6562,100,1000,10**6,10**9,10**12,4*10**12-2,4*10**12-1,37**8,4*10**12];raws=[str(n)+'\n' for n in values]
 elif pid=='abc384_d':
  def periodic(s:int,a:list[int])->str:return f'{len(a)} {s}\n'+line(a)
  raws=[periodic(1,[1]),periodic(1,[2]),periodic(10**18,[1]),periodic(3,[2,3,4]),periodic(5,[2,3,4]),periodic(6,[2,3,4]),periodic(17,[2,3,4]),periodic(11,[2,3,4])]
  while len(raws)<16:raws.append(periodic(rng.randint(1,10**18),[rng.randint(1,100) for _ in range(4+len(raws))]))
  raws+=[periodic(10**18-1,[999999937]*200000),periodic(10**18,[10**9]*200000)]
 elif pid=='abc385_d':
  def santa(x:int,y:int,houses:list[tuple[int,int]],moves:list[tuple[str,int]])->str:return f'{len(houses)} {len(moves)} {x} {y}\n'+''.join(line(p) for p in houses)+''.join(f'{d} {c}\n' for d,c in moves)
  raws=[santa(0,0,[(1,0)],[('R',1)]),santa(0,0,[(1,1)],[('R',1)]),santa(0,0,[(1,0),(2,0),(1,1)],[('R',2),('L',2)]),santa(0,0,[(-1,0),(0,-1)],[('L',1),('R',1),('D',1)])]
  while len(raws)<16:
   points=list({(rng.randint(-20,20),rng.randint(-20,20)) for _ in range(10+len(raws))}-{(0,0)});raws.append(santa(0,0,sorted(points),[(rng.choice('UDLR'),rng.randint(1,20)) for _ in range(12+len(raws))]))
  raws+=[santa(0,0,[(i,1) for i in range(1,200001)],[('R',10**9)]*200000),santa(0,0,[(i,0) for i in range(1,200001)],[('R' if i%2==0 else 'L',10**9) for i in range(200000)])]
 elif pid=='abc386_d':
  def shade(n:int,points:list[tuple[int,int,str]])->str:return f'{n} {len(points)}\n'+''.join(f'{x} {y} {c}\n' for x,y,c in points)
  raws=[shade(1,[(1,1,'B')]),shade(1,[(1,1,'W')]),shade(2,[(1,1,'W'),(2,2,'B')]),shade(2,[(1,2,'W'),(2,1,'B')]),shade(3,[(1,3,'W'),(2,2,'B'),(3,1,'B')])]
  while len(raws)<16:
   n=3+len(raws);points=rng.sample([(x,y) for x in range(1,n+1) for y in range(1,n+1)],5+len(raws));raws.append(shade(n,[(x,y,rng.choice('BW')) for x,y in points]))
  raws+=[shade(10**9,[(i+1,10**9-i,'B') for i in range(199999)]+[(1,1,'W')]),shade(10**9,[(10**9-i,10**9,'B') for i in range(200000)])]
 elif pid=='abc387_d':
  def grid(rows:list[str])->str:return f'{len(rows)} {len(rows[0])}\n'+'\n'.join(rows)+'\n'
  raws=[grid(['SG']),grid(['S','G']),grid(['S.G']),grid(['S.','.G']),grid(['S#','#G']),grid(['S..','...','..G'])]
  while len(raws)<16:
   h=3+len(raws)%5;w=3+len(raws)%7;rows=[''.join(rng.choice('...#') for _ in range(w)) for _ in range(h)];rows[0]='S'+rows[0][1:];rows[-1]=rows[-1][:-1]+'G';raws.append(grid(rows))
  blocked=['.'*1000 for _ in range(1000)];blocked[0]='S'+'.'*999;blocked[500]='#'*1000;blocked[-1]='.'*999+'G';openrows=['.'*1000 for _ in range(1000)];openrows[0]='S'+'.'*999;openrows[-1]='.'*999+'G';raws+=[grid(blocked),grid(openrows)]
 else:
  def stones(a:list[int])->str:return str(len(a))+'\n'+line(a)
  raws=[stones([0]),stones([500000]),stones([0,0]),stones([1,0]),stones([0,1]),stones([1,0,0]),stones([1,1,1]),stones([2,1,0,0])]
  while len(raws)<16:raws.append(stones([rng.randint(0,500000) for _ in range(4+len(raws))]))
  raws+=[stones([i%997 for i in range(500000)]),stones([500000]*500000)]
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i==16 else 'random'} for i,raw in enumerate(raws)]
HINTS={
'abc383_d':('約数の個数は、素因数分解の各指数に1を足した数の積です。','約数が9個ならp^8か、相異なる素数p,qのp^2*q^2です。素数を列挙して重複せず数えます。','疑似コード: sqrt(N)までsieveで素数Pを作る。p^8<=Nの個数を加える。iを昇順にし右端jを減らしてP[i]*P[j]<=sqrt(N)を満たす最大jを得る。j>iならj-iを加える。'),
'abc384_d':('一周期分の和を引いても、同じ位置で区切った区間の和になります。','正の要素なので、Sを一周期の和で割った余りに縮められます。余り0は一周期以上で実現できます。','疑似コード: target=S%sum(A)。0ならYes。二重列を用意し各開始位置に対して右端を進めて和をtarget以上にする。一致ならYes、左端の値を引いて継続。N開始で不一致ならNo。'),
'abc385_d':('家を縦の移動・横の移動で検索できるように並べます。','(x,y)順と(y,x)順の二つの配列を持ち、通過した家は両方から削除します。削除済み位置の後続をDSUで検索すると再走査を防げます。','疑似コード: 家を二つの順序でsort、各家の両indexを記録。移動区間の範囲をbisectで求め、successor DSUで残るindexだけ列挙。各家を両配列のDSUから削除しcount++。終点座標とcountを出力。'),
'abc386_d':('白いマスの右下に黒いマスがあると、指定された塗り分けはできません。','行番号順に見ながら、それまでの白いマスの最小列を保持します。同じ行の白を先に処理します。','疑似コード: 点を(x,白優先)でsort。minWhite=N+1。白ならminWhite=min(minWhite,y)。黒でy>=minWhiteならNo。最後まで矛盾しなければYes。'),
'abc387_d':('直前に縦・横のどちらへ動いたかも、探索の状態に含めましょう。','各マスに次の移動方向が縦/横の2状態を持たせます。スタートの両状態からBFSします。','疑似コード: dist[cell,axis]=-1。Sの両axisを距離0でqueueへ。popしたaxis方向の隣接非障害物へ移動しaxisを反転、未訪問なら距離+1。Gを初めてpopした距離を出力、到達なしなら-1。'),
'abc388_d':('成人時に石を受け取った後、将来何人へ贈れるかを決めます。','贈り物をする期間を区間の差分で記録すれば、各年に受け取る石の数を累積で計算できます。','疑似コード: received=0,diff全0。iごとにreceived+=diff[i],stone=A[i]+received,give=min(stone,N-i-1)。答stone-give。give>0ならdiff[i+1]++、diff[i+give+1]--。全答を空白区切りで出力。')}

TITLES={'abc383_d': '9 Divisors', 'abc384_d': 'Repeated Sequence', 'abc385_d': 'Santa Claus 2', 'abc386_d': 'Diagonal Separation', 'abc387_d': 'Snaky Walk', 'abc388_d': 'Coming of Age Celebration'}

PUBLISHED_SAMPLES={'abc383_d': [{'input': '200\n', 'expected': '3\n'}, {'input': '4000000000000\n', 'expected': '407073\n'}], 'abc384_d': [{'input': '3 42\n3 8 4\n', 'expected': 'Yes\n'}, {'input': '3 1\n3 8 4\n', 'expected': 'No\n'}, {'input': '20 83298426\n748 169 586 329 972 529 432 519 408 587 138 249 656 114 632 299 984 755 404 772\n', 'expected': 'Yes\n'}, {'input': '20 85415869\n748 169 586 329 972 529 432 519 408 587 138 249 656 114 632 299 984 755 404 772\n', 'expected': 'No\n'}], 'abc385_d': [{'input': '3 4 3 2\n2 2\n3 3\n2 1\nL 2\nD 1\nR 1\nU 2\n', 'expected': '2 3 2\n'}, {'input': '1 3 0 0\n1 1\nR 1000000000\nR 1000000000\nR 1000000000\n', 'expected': '3000000000 0 0\n'}], 'abc386_d': [{'input': '4 3\n4 1 B\n3 2 W\n1 3 B\n', 'expected': 'Yes\n'}, {'input': '2 2\n1 2 W\n2 2 B\n', 'expected': 'No\n'}, {'input': '1 1\n1 1 W\n', 'expected': 'Yes\n'}, {'input': '2289 10\n1700 1083 W\n528 967 B\n1789 211 W\n518 1708 W\n1036 779 B\n136 657 B\n759 1497 B\n902 1309 B\n1814 712 B\n936 763 B\n', 'expected': 'No\n'}], 'abc387_d': [{'input': '3 5\n.S#.G\n.....\n.#...\n', 'expected': '7\n'}, {'input': '3 5\n..#.G\n.....\nS#...\n', 'expected': '-1\n'}, {'input': '8 63\n...............................................................\n..S...#............................#####..#####..#####..####G..\n..#...#................................#..#...#......#..#......\n..#####..####...####..####..#..#...#####..#...#..#####..#####..\n..#...#..#..#...#..#..#..#..#..#...#......#...#..#..........#..\n..#...#..#####..####..####..####...#####..#####..#####..#####..\n................#.....#........#...............................\n................#.....#........#...............................\n', 'expected': '148\n'}], 'abc388_d': [{'input': '4\n5 0 9 3\n', 'expected': '2 0 10 5\n'}, {'input': '5\n4 6 7 2 5\n', 'expected': '0 4 7 4 9\n'}, {'input': '10\n2 9 1 2 0 4 6 7 1 5\n', 'expected': '0 2 0 0 0 4 7 10 4 10\n'}]}

SAMPLE_COUNTS={'abc383_d': 2, 'abc384_d': 4, 'abc385_d': 2, 'abc386_d': 4, 'abc387_d': 3, 'abc388_d': 3}
