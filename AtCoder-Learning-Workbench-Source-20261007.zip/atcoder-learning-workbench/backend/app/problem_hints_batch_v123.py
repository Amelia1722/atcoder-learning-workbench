"""Statement-checked three-stage hints for ABC227–229 B."""
HINTS_V123 = {
    'abc227_b': (
        '面積としてあり得る値は、a,bが正の整数という条件のもとで `4ab+3a+3b` と表せるものだけです。S_iは最大1000なので、候補のa,bを十分小さい範囲で試せないか考えてください。',
        'a,bを1から順に全探索し、1000以下で作れる面積をsetに入れておきます。各S_iがそのsetに無ければ「確実に誤り」と数えます。',
        '疑似コード:\npossible = empty set\nfor a = 1 .. 100:\n  for b = 1 .. 100:\n    s = 4*a*b + 3*a + 3*b\n    if s <= 1000: add s to possible\nans = count(x not in possible for x in S)\nprint(ans)',
    ),
    'abc228_b': (
        '秘密を知った人から次に伝わる相手は常に1人に決まっています。Xから始めて、その番号を順にたどったとき何が起きるか考えてください。',
        '一度知った友達を集合やbool配列で記録し、現在の友達をA_iへ更新し続けます。すでに記録済みの友達へ戻った時点で、それ以上新しい人は増えません。',
        '疑似コード:\nseen = empty set\ncur = X\nwhile cur not in seen:\n  add cur to seen\n  cur = A[cur]\nprint(size(seen))',
    ),
    'abc229_b': (
        '十進法の加算で繰り上がりが起きるのは、同じ桁にある2つの数字の和がある値以上になるときです。下の桁から比較してください。',
        'A,Bを10で割った余りから各桁を取り出し、どこか1桁でも `(A%10)+(B%10)>=10` ならHardです。確認後は両方を10で整数除算します。',
        '疑似コード:\nwhile A > 0 or B > 0:\n  if A % 10 + B % 10 >= 10:\n    print Hard and stop\n  A //= 10\n  B //= 10\nprint Easy',
    ),
}
