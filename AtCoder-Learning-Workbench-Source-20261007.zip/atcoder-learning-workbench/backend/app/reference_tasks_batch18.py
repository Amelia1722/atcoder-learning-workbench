"""Manually reviewed ABC006–ABC012 A tasks, NOT authenticated HTML archives.

All constraints and published examples are manually transcribed from the
individual public official task pages. No task is inferred from a shared grammar.
"""
from __future__ import annotations
import random
import re

SPECS = {
 'abc006_1': ('世界のFizzBuzz', '1 <= N <= 9', '2\n', 'NO'),
 'abc007_1': ('植木算', '1 <= N <= 10000', '4\n', '3'),
 'abc008_1': ('アルバム', '1 <= S <= T <= 1000', '4 7\n', '4'),
 'abc009_1': ('引越し作業', '1 <= N <= 1000', '2\n', '1'),
 'abc010_1': ('ハンドルネーム', '1 <= len(S) <= 10; lowercase ASCII', 'chokudai\n', 'chokudaipp'),
 'abc011_1': ('来月は何月？', '1 <= N <= 12', '1\n', '2'),
 'abc012_1': ('スワップ', '1 <= A,B <= 100', '1 2\n', '2 1'),
}
BATCH18 = {pid: {'sample_input': example, 'sample_output': answer,
    'constraints': bounds, 'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}'}
    for pid, (_, bounds, example, answer) in SPECS.items()}
UINT = re.compile(r'(?:0|[1-9][0-9]*)\Z', re.ASCII)
WORD = re.compile(r'[a-z]{1,10}\Z', re.ASCII)


def validate(pid: str, data: str) -> tuple[int, ...] | str:
    if pid not in BATCH18 or not isinstance(data, str):
        raise ValueError('unknown task or input type')
    if data.count('\n') != 1 or not data.endswith('\n') or '\r' in data:
        raise ValueError('one newline-terminated line required')
    content = data[:-1]
    if pid == 'abc010_1':
        if not WORD.fullmatch(content):
            raise ValueError('handle must contain 1..10 lowercase ASCII letters')
        return content
    pieces = content.split(' ')
    if len(pieces) != (2 if pid in ('abc008_1', 'abc012_1') else 1) or any(not UINT.fullmatch(s) for s in pieces):
        raise ValueError('noncanonical integer tokens')
    values = tuple(map(int, pieces))
    if pid == 'abc006_1' and not 1 <= values[0] <= 9:
        raise ValueError('N outside 1..9')
    if pid == 'abc007_1' and not 1 <= values[0] <= 10000:
        raise ValueError('N outside 1..10000')
    if pid == 'abc008_1' and not 1 <= values[0] <= values[1] <= 1000:
        raise ValueError('S,T outside ordered 1..1000')
    if pid == 'abc009_1' and not 1 <= values[0] <= 1000:
        raise ValueError('N outside 1..1000')
    if pid == 'abc011_1' and not 1 <= values[0] <= 12:
        raise ValueError('N outside 1..12')
    if pid == 'abc012_1' and any(not 1 <= x <= 100 for x in values):
        raise ValueError('A,B outside 1..100')
    return values


FIXTURES: dict[str, list[tuple[str, str]]] = {
 'abc006_1': [('constraint_min','1'), ('typical','2'), ('boundary','3'), ('boundary','4'),
              ('typical','5'), ('boundary','6'), ('typical','7'), ('boundary','8'), ('constraint_max','9')],
 'abc007_1': [('constraint_min','1'),('boundary','2'),('typical','4'),('typical','100'),
              ('boundary','9999'),('constraint_max','10000')],
 'abc008_1': [('constraint_min','1 1'),('boundary','1 2'),('typical','4 7'),
              ('boundary','999 1000'),('typical','500 500'),('constraint_max','1 1000')],
 'abc009_1': [('constraint_min','1'),('boundary','2'),('boundary','3'),
              ('typical','5'),('boundary','999'),('constraint_max','1000')],
 'abc010_1': [('constraint_min','a'),('boundary','z'),('typical','chokudai'),
              ('typical','sanagi'),('boundary','pp'),('constraint_max','abcdefghij')],
 'abc011_1': [('constraint_min','1'),('typical','2'),('typical','6'),('boundary','11'),('constraint_max','12')],
 'abc012_1': [('constraint_min','1 1'),('boundary','1 100'),('boundary','100 1'),
              ('typical','5 5'),('typical','1 2'),('constraint_max','100 100')],
}


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str, str]]:
    if pid not in BATCH18 or not 4 <= count <= 80:
        raise ValueError('invalid task or count')
    randomizer = random.Random(f'{pid}:{seed}')
    found: set[str] = set()
    result: list[dict[str, str]] = []
    max_value = next(v for cat, v in FIXTURES[pid] if cat == 'constraint_max') + '\n'
    def add(cat: str, raw: str) -> None:
        raw += '\n'
        validate(pid, raw)
        if raw not in found:
            result.append({'category': cat, 'input': raw})
            found.add(raw)
    for cat, raw in FIXTURES[pid]:
        if cat != 'constraint_max':
            add(cat, raw)
    attempts = 0
    while len(result) < count and attempts < 3000:
        attempts += 1
        if pid == 'abc006_1': v = str(randomizer.randint(1, 9))
        elif pid == 'abc007_1': v = str(randomizer.randint(1, 10000))
        elif pid == 'abc008_1':
            a, b = sorted((randomizer.randint(1, 1000),randomizer.randint(1, 1000)))
            v = f'{a} {b}'
        elif pid == 'abc009_1': v = str(randomizer.randint(1, 1000))
        elif pid == 'abc010_1':
            size = randomizer.randint(1,10)
            v = ''.join(randomizer.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(size))
        elif pid == 'abc011_1': v = str(randomizer.randint(1,12))
        else: v = f'{randomizer.randint(1,100)} {randomizer.randint(1,100)}'
        add('random',v)
    result = result[:count]
    if include_large:
        result = [row for row in result if row['input'] != max_value]
        result = result[:count-1]
        result.append({'category':'constraint_max','input':max_value})
    return result


def independent_check(pid: str, data: str, expected: str) -> bool:
    values = validate(pid, data)
    if pid == 'abc006_1':
        number, = values
        result = 'YES' if '3' in str(number) or (number // 3) * 3 == number else 'NO'
    elif pid == 'abc007_1':
        number, = values
        result = str(len(range(1, number)))
    elif pid == 'abc008_1':
        start, end = values
        result = str(sum(1 for _ in range(start, end+1)))
    elif pid == 'abc009_1':
        number, = values
        result = str(len(range(1,number+1,2)))
    elif pid == 'abc010_1':
        result = values + chr(112) * 2
    elif pid == 'abc011_1':
        number, = values
        result = str(1 if number == 12 else number+1)
    else:
        first, second = values
        result = f'{second} {first}'
    return expected == result
