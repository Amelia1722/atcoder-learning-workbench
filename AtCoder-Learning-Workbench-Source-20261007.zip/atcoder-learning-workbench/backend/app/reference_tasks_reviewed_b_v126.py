"""ABC236–238 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc236_b', 'abc237_b', 'abc238_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc236_b': [
        {'input': '3\n1 3 2 3 3 2 2 1 1 1 2\n', 'expected': '3\n'},
        {'input': '1\n1 1 1\n', 'expected': '1\n'},
        {'input': '4\n3 2 1 1 2 4 4 4 4 3 1 3 2 1 3\n', 'expected': '2\n'},
    ],
    'abc237_b': [
        {'input': '4 3\n1 2 3\n4 5 6\n7 8 9\n10 11 12\n',
         'expected': '1 4 7 10\n2 5 8 11\n3 6 9 12\n'},
        {'input': '2 2\n1000000000 1000000000\n1000000000 1000000000\n',
         'expected': '1000000000 1000000000\n1000000000 1000000000\n'},
    ],
    'abc238_b': [
        {'input': '4\n90 180 45 195\n', 'expected': '120\n'},
        {'input': '1\n1\n', 'expected': '359\n'},
        {'input': '10\n215 137 320 339 341 41 44 18 241 149\n', 'expected': '170\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _row(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate236(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 100_000:
        raise ValueError('N')
    a = _row(lines[1], 4 * n - 1)
    counts = [0] * (n + 1)
    for x in a:
        if not 1 <= x <= n:
            raise ValueError('A range')
        counts[x] += 1
        if counts[x] > 4:
            raise ValueError('too many copies')
    if sum(c == 3 for c in counts[1:]) != 1 or any(c != 4 for c in counts[1:] if c != 3):
        raise ValueError('deck semantics')
    return n, tuple(a)


def _validate237(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    hw = _row(lines[0], 2)
    h, w = hw
    if not (1 <= h <= 100_000 and 1 <= w <= 100_000 and h * w <= 100_000):
        raise ValueError('H/W')
    if len(lines) != h + 1:
        raise ValueError('row count')
    matrix = []
    for line in lines[1:]:
        row = _row(line, w)
        if any(not 1 <= x <= 1_000_000_000 for x in row):
            raise ValueError('A range')
        matrix.append(tuple(row))
    return h, w, tuple(matrix)


def _validate238(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 1 <= n <= 359:
        raise ValueError('N')
    a = _row(lines[1], n)
    if any(not 1 <= x <= 359 for x in a):
        raise ValueError('A range')
    seen = {0}
    pos = 0
    for x in a:
        pos = (pos + x) % 360
        if pos in seen:
            raise ValueError('duplicate cut')
        seen.add(pos)
    return tuple(a)


def validate(pid: str, raw: str):
    if pid == 'abc236_b':
        return _validate236(raw)
    if pid == 'abc237_b':
        return _validate237(raw)
    if pid == 'abc238_b':
        return _validate238(raw)
    raise ValueError('unknown task')


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False

    if pid == 'abc236_b':
        n, a = value
        missing = 2 * n * (n + 1) - sum(a)
        return POS.fullmatch(output) is not None and int(output) == missing

    if pid == 'abc237_b':
        h, w, matrix = value
        expected = '\n'.join(' '.join(str(matrix[i][j]) for i in range(h)) for j in range(w))
        return output == expected

    a = value
    cuts = [0]
    pos = 0
    for x in a:
        pos = (pos + x) % 360
        cuts.append(pos)
    cuts.sort()
    best = max(cuts[i + 1] - cuts[i] for i in range(len(cuts) - 1))
    best = max(best, 360 - cuts[-1] + cuts[0])
    return POS.fullmatch(output) is not None and int(output) == best


def _deck(n: int, missing: int, *, reverse: bool = False, rotate: int = 0) -> str:
    vals = []
    for x in range(1, n + 1):
        vals.extend([x] * (3 if x == missing else 4))
    if reverse:
        vals.reverse()
    if vals and rotate:
        k = rotate % len(vals)
        vals = vals[k:] + vals[:k]
    return f'{n}\n' + ' '.join(map(str, vals)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc236_b':
        cases = [
            ('n2_missing_first', _deck(2, 1)),
            ('n2_missing_last', _deck(2, 2, reverse=True)),
            ('n3_missing_middle', _deck(3, 2, rotate=2)),
            ('n4_missing_first', _deck(4, 1, reverse=True)),
            ('n5_missing_middle', _deck(5, 3, rotate=7)),
            ('n8_missing_last', _deck(8, 8, rotate=5)),
            ('n10_missing7', _deck(10, 7, reverse=True, rotate=11)),
            ('n20_missing1', _deck(20, 1, rotate=17)),
            ('n50_missing25', _deck(50, 25, reverse=True)),
            ('n100_missing100', _deck(100, 100, rotate=37)),
            ('n257_missing128', _deck(257, 128, rotate=101)),
            ('n1000_missing501', _deck(1000, 501, reverse=True, rotate=313)),
            ('n4096_missing4096', _deck(4096, 4096, rotate=997)),
            ('n10000_missing4321', _deck(10000, 4321, reverse=True, rotate=2025)),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', _deck(100_000, 99_999, rotate=12_345))

    elif pid == 'abc237_b':
        cases = [
            ('one_by_one', '1 1\n7\n'),
            ('one_by_five', '1 5\n1 2 3 4 5\n'),
            ('five_by_one', '5 1\n1\n2\n3\n4\n5\n'),
            ('two_by_three', '2 3\n1 2 3\n4 5 6\n'),
            ('three_by_two', '3 2\n9 8\n7 6\n5 4\n'),
            ('three_by_four', '3 4\n1 1 2 3\n5 8 13 21\n34 55 89 144\n'),
            ('identity3', '3 3\n1 0 0\n0 1 0\n0 0 1\n'.replace('0', '1')),
            ('all_same', '3 5\n42 42 42 42 42\n42 42 42 42 42\n42 42 42 42 42\n'),
            ('large_values', '2 4\n1000000000 999999999 1 2\n3 4 5 6\n'),
            ('ten_square', '10 10\n' + ''.join(' '.join(str(i*10+j+1) for j in range(10)) + '\n' for i in range(10))),
            ('twenty_by_three', '20 3\n' + ''.join(f'{i+1} {i+101} {i+201}\n' for i in range(20))),
            ('three_by_twenty', '3 20\n' + ''.join(' '.join(str(i*20+j+1) for j in range(20)) + '\n' for i in range(3))),
            ('hundred_by_one', '100 1\n' + ''.join(f'{i+1}\n' for i in range(100))),
            ('one_by_hundred', '1 100\n' + ' '.join(str(i+1) for i in range(100)) + '\n'),
            ('two_fifty_by_four', '250 4\n' + ''.join(f'{i+1} {i+2} {i+3} {i+4}\n' for i in range(250))),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '100000 1\n' + ('1\n' * 100_000))

    else:
        cases = [
            ('single_359', '1\n359\n'),
            ('two_ones', '2\n1 1\n'),
            ('two_halves_minus', '2\n179 180\n'),
            ('quarter_steps', '3\n90 90 90\n'),
            ('four_small', '4\n1 1 1 1\n'),
            ('mixed_five', '5\n30 60 90 45 15\n'),
            ('six_sixties_avoid_zero', '5\n60 60 60 60 60\n'),
            ('seven_varied', '7\n10 20 30 40 50 60 70\n'),
            ('ten_ones', '10\n' + ' '.join(['1'] * 10) + '\n'),
            ('thirty_ones', '30\n' + ' '.join(['1'] * 30) + '\n'),
            ('hundred_ones', '100\n' + ' '.join(['1'] * 100) + '\n'),
            ('n180_ones', '180\n' + ' '.join(['1'] * 180) + '\n'),
            ('n300_ones', '300\n' + ' '.join(['1'] * 300) + '\n'),
            ('n358_ones', '358\n' + ' '.join(['1'] * 358) + '\n'),
        ]
        for category, raw in cases:
            add(category, raw)
        add('constraint_max', '359\n' + ' '.join(['1'] * 359) + '\n')

    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
