"""Reviewed C tasks with meet-in-the-middle path joins and multiplicative divisor counts."""
from __future__ import annotations
from collections import defaultdict
from itertools import accumulate,groupby
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(291,297))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Matrix=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==291:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];s=rows[1];require(1<=n<=200000 and len(s)==n and set(s)<={'R','L','U','D'},'moves');return (s,)
    if number==292:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(2<=n<=200000,'number');return (n,)
    if number==293:
        h,w=ints(rows[0],2);require(2<=h<=10 and 2<=w<=10 and len(rows)==h+1,'shape');a=tuple(ints(row,w) for row in rows[1:]);require(all(1<=v<=10**9 for row in a for v in row),'values');return (a,)
    if number==294:
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=100000,'length');a=ints(rows[1],n);b=ints(rows[2],m);require(all(1<=v<=10**9 for seq in (a,b) for v in seq) and all(x<y for seq in (a,b) for x,y in zip(seq,seq[1:])) and not set(a)&set(b),'distinct increasing');return a,b
    if number==295:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=500000,'length');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'colors');return (a,)
    require(len(rows)==2,'shape');n,x=ints(rows[0],2);require(2<=n<=200000 and -10**9<=x<=10**9,'length gap');a=ints(rows[1],n);require(all(-10**9<=v<=10**9 for v in a),'values');return x,a

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==291:
        s=cast(str,data[0]);x=list(accumulate((1 if c=='R' else -1 if c=='L' else 0 for c in s),initial=0));y=list(accumulate((1 if c=='U' else -1 if c=='D' else 0 for c in s),initial=0));positions=sorted(zip(x,y));return 'Yes' if any(a==b for a,b in zip(positions,positions[1:])) else 'No'
    if number==292:
        n=cast(int,data[0]);spf=list(range(n));spf[1]=1
        for prime in range(2,n):
            if spf[prime]!=prime:continue
            for j in range(prime*prime,n,prime):
                if spf[j]==j:spf[j]=prime
        divisor=[0]*n;divisor[1]=1;exponents=[0]*n
        for j in range(2,n):
            p=spf[j];q=j//p
            if q%p:exponents[j]=1;divisor[j]=2*divisor[q]
            else:exponents[j]=exponents[q]+1;divisor[j]=divisor[q]//(exponents[q]+1)*(exponents[j]+1)
        return str(sum(divisor[j]*divisor[n-j] for j in range(1,n)))
    if number==293:
        a=cast(Matrix,data[0]);h=len(a);w=len(a[0]);ids={value:j for j,value in enumerate(set(v for row in a for v in row))};bits=tuple(tuple(1<<ids[v] for v in row) for row in a);split=(h+w-2)//2;forward:dict[tuple[int,int],list[int]]=defaultdict(list);backward:dict[tuple[int,int],list[int]]=defaultdict(list)
        def walk(r:int,c:int,mask:int,step:int,reverse:bool)->None:
            bit=bits[r][c]
            if mask&bit:return
            mask|=bit
            if r+c==split:(backward if reverse else forward)[r,c].append(mask);return
            dr=-1 if reverse else 1
            if 0<=r+dr<h:walk(r+dr,c,mask,step+1,reverse)
            if 0<=c+dr<w:walk(r,c+dr,mask,step+1,reverse)
        walk(0,0,0,0,False);walk(h-1,w-1,0,0,True);answer=0
        for (r,c),prefixes in forward.items():
            for suffix in backward[r,c]:
                tail=suffix^bits[r][c];answer+=sum(mask&tail==0 for mask in prefixes)
        return str(answer)
    if number==294:
        a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);ia=ib=0;pa=[];pb=[]
        while ia<len(a) or ib<len(b):
            rank=ia+ib+1
            if ib==len(b) or ia<len(a) and a[ia]<b[ib]:pa.append(rank);ia+=1
            else:pb.append(rank);ib+=1
        return ' '.join(map(str,pa))+'\n'+' '.join(map(str,pb))
    if number==295:
        a=cast(tuple[int,...],data[0]);return str(sum(sum(1 for _ in values)//2 for _,values in groupby(sorted(a))))
    x,a=cast(tuple[int,tuple[int,...]],data);ordered=sorted(a);gap=abs(x);right=0
    for left in range(len(ordered)):
        while right<len(ordered) and ordered[right]-ordered[left]<gap:right+=1
        if right<len(ordered) and ordered[right]-ordered[left]==gap:return 'Yes'
    return 'No'
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc291_c':"n=int(input());s=input();x=y=0;seen={(0,0)};answer=False\nfor c in s:\n x+=(c=='R')-(c=='L');y+=(c=='U')-(c=='D');answer|=(x,y) in seen;seen.add((x,y))\nprint('Yes' if answer else 'No')\n",
'abc292_c':"n=int(input());d=[0]*n\nfor a in range(1,n):\n for product in range(a,n,a):d[product]+=1\nprint(sum(d[a]*d[n-a] for a in range(1,n)))\n",
'abc293_c':"h,w=map(int,input().split());a=[list(map(int,input().split())) for _ in range(h)]\ndef dfs(r,c,seen):\n v=a[r][c]\n if v in seen:return 0\n if r==h-1 and c==w-1:return 1\n seen.add(v);answer=0\n if r+1<h:answer+=dfs(r+1,c,seen)\n if c+1<w:answer+=dfs(r,c+1,seen)\n seen.remove(v);return answer\nprint(dfs(0,0,set()))\n",
'abc294_c':"n,m=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));rank={value:i for i,value in enumerate(sorted(a+b),1)};print(*(rank[v] for v in a));print(*(rank[v] for v in b))\n",
'abc295_c':"from collections import Counter\nn=int(input());a=list(map(int,input().split()));print(sum(count//2 for count in Counter(a).values()))\n",
'abc296_c':"n,x=map(int,input().split());a=set(map(int,input().split()));print('Yes' if any(v-x in a for v in a) else 'No')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16800+number)
    if number==291:
        def moves(s:str)->str:return f'{len(s)}\n{s}\n'
        raws=[moves(s) for s in ('R','RL','RU','RULD')]
        raws.extend(moves(''.join(rng.choice('RLUD') for _ in range(n))) for n in range(5,17));raws.extend([moves('RU'*100000),moves('R'*100000+'L'*100000)])
    elif number==292:raws=[f'{n}\n' for n in (2,3,4,5,6,7,8,9,10,12,16,25,49,100,999,10000,199999,200000)]
    elif number==293:
        def matrix(a:list[list[int]])->str:return f'{len(a)} {len(a[0])}\n'+''.join(line(row) for row in a)
        raws=[matrix([[1,1],[1,1]]),matrix([[1,2],[3,4]]),matrix([[1,2],[2,3]]),matrix([[1,2],[3,1]])]
        for j in range(12):
            h=2+j%5;w=2+j//5;raws.append(matrix([[rng.randint(1,10+j) for _ in range(w)] for _ in range(h)]))
        raws.extend([matrix([[r*10+c+1 for c in range(10)] for r in range(10)]),matrix([[10**9-r*10-c for c in range(10)] for r in range(10)])])
    elif number==294:
        def merge(a:list[int],b:list[int])->str:return f'{len(a)} {len(b)}\n'+line(a)+line(b)
        raws=[merge([1],[2]),merge([2],[1]),merge([1,3],[2]),merge([2],[1,3])]
        for n in range(3,15):
            values=sorted(rng.sample(range(1,10000),2*n));indices=set(rng.sample(range(2*n),n));raws.append(merge([v for j,v in enumerate(values) if j in indices],[v for j,v in enumerate(values) if j not in indices]))
        raws.extend([merge(list(range(1,100001)),list(range(100001,200001))),merge(list(range(999800001,1000000000,2)),list(range(999800002,1000000001,2)))])
    elif number==295:
        def socks(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[socks(a) for a in ([1],[1,1],[1,2],[1,1,1])];raws.extend(socks([rng.randint(1,7) for _ in range(n)]) for n in range(5,17));raws.extend([socks(list(range(1,500001))),socks([10**9]*500000)])
    else:
        def gap(a:list[int],x:int)->str:return f'{len(a)} {x}\n'+line(a)
        raws=[gap([0,0],0),gap([1,2],0),gap([-1,1],2),gap([-1,1],-2)];raws.extend(gap([rng.randint(-50,50) for _ in range(n)],rng.randint(-60,60)) for n in range(3,15));raws.extend([gap(list(range(200000)),10**9),gap([-10**9,0]+[10**9]*199998,-10**9)])
    require(len(raws)==len(set(raws))==18,'unique cases')
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc291_c':('始点も含めて訪問した座標を記録します。','座標を更新するたび、その座標が集合に存在するか調べます。','疑似コード: seen={(0,0)}; 各移動でx,yを更新; (x,y)がseenにあればYes; なければ追加; 最後まで重複なしならNo。'),
'abc292_c':('ABの値を固定するとCDの値も決まります。','整数kを2つの正整数の積で表す個数はkの約数の個数です。','疑似コード: dを0で初期化; 各aについてaの正の倍数kでd[k]++; sum(d[k]*d[N-k], k=1..N-1)を出力。'),
'abc293_c':('右か下へ移動する全経路を調べられる大きさです。','現在の経路で使った値を集合にし、値が重複したらその枝を打ち切ります。','疑似コード: DFS(r,c,seen); A[r][c]がseenにあれば0; 終点なら1; 値を追加して右と下のDFSを加算; 値を削除して戻る。'),
'abc294_c':('結合後の順位は値が小さい順に決まります。','AとBをまとめてソートし、各値に1始まりの順位を対応させます。','疑似コード: C=sort(A+B); 各C[i]の順位をi+1として辞書に保存; Aの順位列とBの順位列を別々の行で出力。'),
'abc295_c':('異なる色どうしはペアにできません。','各色の枚数を2で割った商を足します。','疑似コード: count=各色の出現回数; answer=sum(count[color]//2); answerを出力。'),
'abc296_c':('Aiが分かれば必要なAjはAi-Xです。','値の集合を作り、各値からXを引いた値が集合に存在するか調べます。X=0では同じ添字を使えます。','疑似コード: values=set(A); いずれかのvでv-Xがvaluesに存在すればYes、全て存在しなければNo。')}

TITLES={'abc291_c': 'LRUD Instructions 2', 'abc292_c': 'Four Variables', 'abc293_c': 'Make Takahashi Happy', 'abc294_c': 'Merge Sequences', 'abc295_c': 'Socks', 'abc296_c': 'Gap Existence'}
PUBLISHED_SAMPLES={'abc291_c': [{'input': '5\nRLURU\n', 'expected': 'Yes\n'}, {'input': '20\nURDDLLUUURRRDDDDLLLL\n', 'expected': 'No\n'}], 'abc292_c': [{'input': '4\n', 'expected': '8\n'}, {'input': '292\n', 'expected': '10886\n'}, {'input': '19876\n', 'expected': '2219958\n'}], 'abc293_c': [{'input': '3 3\n3 2 2\n2 1 3\n1 5 4\n', 'expected': '3\n'}, {'input': '10 10\n1 2 3 4 5 6 7 8 9 10\n11 12 13 14 15 16 17 18 19 20\n21 22 23 24 25 26 27 28 29 30\n31 32 33 34 35 36 37 38 39 40\n41 42 43 44 45 46 47 48 49 50\n51 52 53 54 55 56 57 58 59 60\n61 62 63 64 65 66 67 68 69 70\n71 72 73 74 75 76 77 78 79 80\n81 82 83 84 85 86 87 88 89 90\n91 92 93 94 95 96 97 98 99 100\n', 'expected': '48620\n'}], 'abc294_c': [{'input': '4 3\n3 14 15 92\n6 53 58\n', 'expected': '1 3 4 7\n2 5 6\n'}, {'input': '4 4\n1 2 3 4\n100 200 300 400\n', 'expected': '1 2 3 4\n5 6 7 8\n'}, {'input': '8 12\n3 4 10 15 17 18 22 30\n5 7 11 13 14 16 19 21 23 24 27 28\n', 'expected': '1 2 5 9 11 12 15 20\n3 4 6 7 8 10 13 14 16 17 18 19\n'}], 'abc295_c': [{'input': '6\n4 1 7 4 1 4\n', 'expected': '2\n'}, {'input': '1\n158260522\n', 'expected': '0\n'}, {'input': '10\n295 2 29 295 29 2 29 295 2 29\n', 'expected': '4\n'}], 'abc296_c': [{'input': '6 5\n3 1 4 1 5 9\n', 'expected': 'Yes\n'}, {'input': '6 -4\n-2 -7 -1 -8 -2 -8\n', 'expected': 'No\n'}, {'input': '2 0\n141421356 17320508\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
