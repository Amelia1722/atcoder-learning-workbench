"""ABC194–196 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc194_b','abc195_b','abc196_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NONNEG=re.compile(r'0|[1-9][0-9]*',re.ASCII)
XDEC=re.compile(r'(0|[1-9][0-9]*)(?:\.([0-9]{1,100}))?',re.ASCII)

PUBLISHED_SAMPLES={
 'abc194_b':[
  {'input':'3\n8 5\n4 4\n7 9\n','expected':'5\n'},
  {'input':'3\n11 7\n3 2\n6 7\n','expected':'5\n'},
 ],
 'abc195_b':[
  {'input':'100 200 2\n','expected':'10 20\n'},
  {'input':'120 150 2\n','expected':'14 16\n'},
  {'input':'300 333 1\n','expected':'UNSATISFIABLE\n'},
 ],
 'abc196_b':[
  {'input':'5.90\n','expected':'5\n'},
  {'input':'0\n','expected':'0\n'},
  {'input':'84939825309432908832902189.9092309409809091329\n','expected':'84939825309432908832902189\n'},
 ],
}

def _ints(line:str,count:int)->list[int]:
    p=line.split(' ')
    if len(p)!=count or any(POS.fullmatch(x) is None for x in p): raise ValueError('noncanonical positive integer row')
    return list(map(int,p))

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc194_b':
        if not lines or POS.fullmatch(lines[0]) is None: raise ValueError('shape/N')
        n=int(lines[0])
        if not 2<=n<=1000 or len(lines)!=n+1: raise ValueError('range/shape')
        rows=[]
        for line in lines[1:]:
            a,b=_ints(line,2)
            if a>10**5 or b>10**5: raise ValueError('time range')
            rows.append((a,b))
        return rows
    if pid=='abc195_b':
        if len(lines)!=1: raise ValueError('shape')
        a,b,w=_ints(lines[0],3)
        if not (1<=a<=b<=1000 and 1<=w<=1000): raise ValueError('range')
        return a,b,w
    if len(lines)!=1: raise ValueError('shape')
    m=XDEC.fullmatch(lines[0])
    if m is None: raise ValueError('decimal syntax')
    ip=m.group(1); frac=m.group(2)
    limit='1'+'0'*100
    if len(ip)>101 or (len(ip)==101 and ip>limit): raise ValueError('X range')
    if ip==limit and frac is not None and any(c!='0' for c in frac): raise ValueError('X range')
    return lines[0]

def _ans194(rows)->int:
    # Independent O(N) formulation: for each A-worker use the best B-worker excluding them.
    n=len(rows)
    b_order=sorted((b,i) for i,(_,b) in enumerate(rows))
    best_same=min(a+b for a,b in rows)
    best_diff=10**30
    for i,(a,_) in enumerate(rows):
        b = b_order[0][0] if b_order[0][1]!=i else b_order[1][0]
        best_diff=min(best_diff,max(a,b))
    return min(best_same,best_diff)

def _ans195(v):
    a,b,w=v; total=1000*w
    lo=(total+b-1)//b
    hi=total//a
    return None if lo>hi else (lo,hi)

def _ans196(x:str)->str:
    # Scan to the decimal separator instead of numeric conversion.
    p=x.find('.')
    return x if p<0 else x[:p]

def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or '\n' in output or output!=output.strip(): return False
    if pid=='abc194_b':
        if POS.fullmatch(output) is None: return False
        return int(output)==_ans194(v)
    if pid=='abc195_b':
        ans=_ans195(v)
        if ans is None: return output=='UNSATISFIABLE'
        if re.fullmatch(r'[1-9][0-9]* [1-9][0-9]*',output,re.ASCII) is None: return False
        x,y=map(int,output.split())
        return (x,y)==ans
    if NONNEG.fullmatch(output) is None: return False
    return output==_ans196(v)

def _194(rows): return f'{len(rows)}\n'+''.join(f'{a} {b}\n' for a,b in rows)

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc194_b':
        cases=[
         ('sample1',[(8,5),(4,4),(7,9)]),('sample2',[(11,7),(3,2),(6,7)]),
         ('n2_same_best',[(1,1),(100,100)]),('n2_diff_best',[(1,100),(100,1)]),
         ('same_tie',[(3,3),(3,3)]),('asymmetric',[(2,100),(3,4),(100,1)]),
         ('a_min',[(1,99999),(2,100000)]),('b_min',[(99999,1),(100000,2)]),
         ('times_max',[(100000,100000),(99999,100000)]),('cross_middle',[(50,1),(2,60),(100,100)]),
         ('same_middle',[(100,100),(9,9),(1,1000)]),('n5_mixed',[(9,30),(20,8),(15,15),(7,40),(100,6)]),
         ('n10_equal',[(10,10)]*10),('n20_gradient',[(i+1,20-i) for i in range(20)]),
         ('n100_cross',[(1,100000)]+[(50000,50000)]*98+[(100000,1)]),
         ('n500_same',[(100000,100000)]*499+[(123,456)]),
         ('n999_pattern',[((i*37)%100000+1,(i*53)%100000+1) for i in range(999)]),
        ]
        for c,rows in cases:add(c,_194(rows))
        add('constraint_max',_194([((i%100000)+1,((1000-i)%100000)+1) for i in range(1000)]))
    elif pid=='abc195_b':
        cases=[
         ('sample1','100 200 2\n'),('sample2','120 150 2\n'),('sample3','300 333 1\n'),
         ('min_all','1 1 1\n'),('equal_exact','500 500 1\n'),('equal_unsat','333 333 1\n'),
         ('wide','1 1000 1\n'),('w_max','1 1000 1000\n'),('a_b_max_exact','1000 1000 999\n'),
         ('single_possible','499 501 1\n'),('narrow_sat','249 251 1\n'),('narrow_unsat','334 335 1\n'),
         ('ceil_boundary','126 250 1\n'),('floor_boundary','200 333 1\n'),('small_w','7 11 1\n'),
         ('large_w_narrow','999 1000 999\n'),('a_eq_b_mid','125 125 125\n'),
        ]
        for c,raw in cases:add(c,raw)
        add('constraint_max','1000 1000 1000\n')
    else:
        huge='84939825309432908832902189.9092309409809091329\n'
        cases=[
         ('sample1','5.90\n'),('sample2','0\n'),('sample3',huge),('zero_decimal','0.0\n'),
         ('zero_many_fraction','0.'+'0'*100+'\n'),('one_decimal','1.1\n'),('integer_one','1\n'),
         ('fraction_ends_zero','123.4500\n'),('fraction_all_nines','999.'+'9'*100+'\n'),
         ('large_integer','9'*100+'\n'),('large_decimal','9'*100+'.1234567890\n'),
         ('power10_50','1'+'0'*50+'.999\n'),('tiny_fraction','0.'+'0'*99+'1\n'),
         ('integer_100_digits','1'+'2'*99+'\n'),('decimal_100_fraction','42.'+'1234567890'*10+'\n'),
         ('max_with_zero_frac','1'+'0'*100+'.0\n'),('near_max','9'*100+'.'+'9'*100+'\n'),
        ]
        for c,raw in cases:add(c,raw)
        add('constraint_max','1'+'0'*100+'\n')
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
