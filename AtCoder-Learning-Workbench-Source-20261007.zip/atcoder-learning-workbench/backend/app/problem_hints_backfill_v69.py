"""Evidence-bound backfill for ABC041–043 B; public statement checked."""
HINTS_BACKFILL_V69 = {
    'abc041_b': (
        '求める量は直方体の体積です。ただし最後に指定された数で割った余りを出す点に注意してください。',
        'A×B×Cを計算し、1000000007で割った余りを出力します。途中で剰余を取っても結果は変わりません。',
        '''疑似コード:
MOD=1000000007
answer=((A*B)%MOD*C)%MOD
print(answer)''',
    ),
    'abc042_b': (
        '全ての文字列は同じ長さです。先頭から辞書順を小さくするには、どの文字列を先に置くべきか考えてください。',
        '文字列を辞書順に昇順ソートし、その順に全て連結すれば辞書順最小になります。',
        '''疑似コード:
S=sort_ascending(S)
print("".join(S))''',
    ),
    'abc043_b': (
        'キーを左から順に実際に反映すればよいです。Bが来たとき、現在の文字列が空の場合もあります。',
        '出力文字列をリストとして持ち、0/1なら末尾へ追加、Bなら空でないときだけ末尾を削除します。',
        '''疑似コード:
buffer=[]
for key in S:
  if key=="0" or key=="1": buffer.append(key)
  else if buffer is not empty: buffer.pop()
print("".join(buffer))''',
    ),
}
