"""ABC122–124 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

from itertools import permutations
import re

TASKS = ('abc122_b', 'abc123_b', 'abc124_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
UPPER = re.compile(r'[A-Z]{1,10}', re.ASCII)


def _single_positive_line(line: str) -> int:
    if POS.fullmatch(line) is None:
        raise ValueError('noncanonical positive integer')
    return int(line)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')

    if pid == 'abc122_b':
        if len(lines) != 1 or UPPER.fullmatch(lines[0]) is None:
            raise ValueError('S must be 1..10 uppercase English letters')
        return lines[0]

    if pid == 'abc123_b':
        if len(lines) != 5:
            raise ValueError('exactly five dish times required')
        values = [_single_positive_line(line) for line in lines]
        if any(not 1 <= x <= 123 for x in values):
            raise ValueError('dish time out of range')
        return tuple(values)

    if len(lines) != 2:
        raise ValueError('N and one height row required')
    n = _single_positive_line(lines[0])
    if not 1 <= n <= 20:
        raise ValueError('N range')
    parts = lines[1].split(' ')
    if len(parts) != n or any(POS.fullmatch(token) is None for token in parts):
        raise ValueError('height count/lexical format')
    heights = list(map(int, parts))
    if any(not 1 <= h <= 100 for h in heights):
        raise ValueError('height range')
    return heights


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or output != output.strip() or not output:
        return False
    if output != '0' and POS.fullmatch(output) is None:
        return False

    if pid == 'abc122_b':
        best = 0
        allowed = set('ACGT')
        for left in range(len(value)):
            for right in range(left + 1, len(value) + 1):
                if all(ch in allowed for ch in value[left:right]):
                    best = max(best, right - left)
        return output == str(best)

    if pid == 'abc123_b':
        # Brute-force all 5! orderings rather than reusing the optimized formula.
        best = 10**9
        for order in permutations(value):
            now = 0
            for duration in order:
                if now % 10:
                    now += 10 - now % 10
                now += duration
            best = min(best, now)
        return output == str(best)

    heights = value
    answer = 0
    for i, h in enumerate(heights):
        if all(heights[j] <= h for j in range(i)):
            answer += 1
    return output == str(answer)


def _heights(values: list[int]) -> str:
    return f'{len(values)}\n' + ' '.join(map(str, values)) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            result.append({'category': category, 'input': raw})

    if pid == 'abc122_b':
        fixed = [
            ('sample1', 'ATCODER'), ('sample2', 'HATAGAYA'), ('sample3', 'SHINJUKU'),
            ('single_allowed', 'A'), ('single_disallowed', 'Z'), ('all_allowed_four', 'ACGT'),
            ('all_disallowed', 'BBBBBBBBBB'), ('allowed_prefix', 'ACGTBBBBBB'),
            ('allowed_suffix', 'BBBBBBACGT'), ('allowed_middle', 'ZZACGTZZZZ'),
            ('two_equal_runs', 'AACZZGGT'), ('one_long_run', 'ZACGTACGTZ'),
            ('alternating_breaks', 'AZCZGZT'), ('only_a', 'AAAAAAAAA'),
            ('near_max_allowed', 'ACGTACGTA'), ('mixed_letters', 'QACGTRACGT'),
            ('multiple_breaks', 'ACXGTYACGT'),
        ]
        for category, s in fixed:
            add(category, s + '\n')
        add('constraint_max', 'ACGTACGTAC\n')

    elif pid == 'abc123_b':
        fixed = [
            ('sample1', (29, 20, 7, 35, 120)),
            ('sample2', (101, 86, 119, 108, 57)),
            ('all_min', (1, 1, 1, 1, 1)),
            ('all_multiples_10', (10, 20, 30, 40, 50)),
            ('one_nonmultiple', (10, 20, 30, 40, 41)),
            ('small_remainders', (1, 2, 3, 4, 5)),
            ('remainder_nine', (9, 19, 29, 39, 49)),
            ('same_remainder', (11, 21, 31, 41, 51)),
            ('one_exact_ten', (10, 11, 12, 13, 14)),
            ('descending', (100, 90, 80, 70, 61)),
            ('near_max', (119, 120, 121, 122, 123)),
            ('mixed_ends', (1, 123, 10, 111, 52)),
            ('best_last_remainder1', (21, 32, 43, 54, 65)),
            ('best_last_remainder9', (29, 38, 47, 56, 65)),
            ('duplicates', (11, 11, 20, 20, 30)),
            ('all_100', (100, 100, 100, 100, 100)),
            ('boundary_mix', (1, 10, 99, 120, 122)),
        ]
        for category, values in fixed:
            add(category, '\n'.join(map(str, values)) + '\n')
        add('constraint_max', '123\n123\n123\n123\n123\n')

    else:
        fixed = [
            ('sample1', [6, 5, 6, 8]), ('sample2', [4, 5, 3, 5, 4]),
            ('sample3', [9, 5, 6, 8, 4]), ('single_min', [1]), ('single_max', [100]),
            ('strict_increasing', [1, 2, 3, 4, 5]), ('strict_decreasing', [5, 4, 3, 2, 1]),
            ('all_equal', [7, 7, 7, 7, 7]), ('equal_to_prefix_max', [4, 4, 3, 4, 2]),
            ('new_records', [1, 100, 2, 99, 3]), ('first_max', [100, 1, 2, 3, 4]),
            ('last_max', [1, 2, 1, 2, 100]), ('zigzag', [3, 1, 4, 2, 5, 1, 6]),
            ('twenty_increasing', list(range(1, 21))),
            ('twenty_decreasing', list(range(20, 0, -1))),
            ('twenty_equal_low', [1] * 20),
            ('twenty_alternating', [1, 100] * 10),
        ]
        for category, values in fixed:
            add(category, _heights(values))
        add('constraint_max', _heights([100] * 20))

    if len(result) != 18 or len(seen) != 18 or result[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
