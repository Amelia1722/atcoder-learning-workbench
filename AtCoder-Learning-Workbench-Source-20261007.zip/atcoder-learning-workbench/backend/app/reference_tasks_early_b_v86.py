"""ABC116–118 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc116_b','abc117_b','abc118_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG=re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)


def _tokens(line:str, count:int)->list[str]:
    parts=line.split(' ')
    if len(parts)!=count or any(POS.fullmatch(t) is None for t in parts):
        raise ValueError('positive integer format')
    return parts


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc116_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None:
            raise ValueError('line count/format')
        s=int(lines[0])
        if not 1<=s<=100: raise ValueError('s range')
        return s
    if pid=='abc117_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('line count/format')
        n=int(lines[0])
        if not 3<=n<=10: raise ValueError('n range')
        sides=list(map(int,_tokens(lines[1],n)))
        if any(x>100 for x in sides): raise ValueError('side range')
        return n,sides
    if len(lines)<2:
        raise ValueError('line count')
    head=lines[0].split(' ')
    if len(head)!=2 or any(POS.fullmatch(t) is None for t in head):
        raise ValueError('header format')
    n,m=map(int,head)
    if not (1<=n<=30 and 1<=m<=30) or len(lines)!=n+1:
        raise ValueError('shape/range')
    foods=[]
    for line in lines[1:]:
        parts=line.split(' ')
        if not parts or POS.fullmatch(parts[0]) is None:
            raise ValueError('row format')
        k=int(parts[0])
        if not 1<=k<=m or len(parts)!=k+1 or any(POS.fullmatch(t) is None for t in parts[1:]):
            raise ValueError('row shape')
        row=list(map(int,parts[1:]))
        if any(x<1 or x>m for x in row) or len(set(row))!=k:
            raise ValueError('food range/distinctness')
        foods.append(row)
    return n,m,foods


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc116_b':
        if POS.fullmatch(output) is None: return False
        s=value; seen={s}; m=1
        while True:
            s=s//2 if s%2==0 else 3*s+1
            m+=1
            if s in seen: break
            seen.add(s)
            if m>1_000_000: return False
        return output==str(m)
    if pid=='abc117_b':
        if output not in ('Yes','No'): return False
        _,sides=value
        expected='Yes' if max(sides)<sum(sides)-max(sides) else 'No'
        return output==expected
    if output!='0' and POS.fullmatch(output) is None: return False
    n,m,foods=value
    counts=[0]*(m+1)
    for row in foods:
        for x in row: counts[x]+=1
    expected=sum(c==n for c in counts[1:])
    return output==str(expected)


def _polygon(sides:list[int])->str:
    return f'{len(sides)}\n'+' '.join(map(str,sides))+'\n'


def _foods(m:int, rows:list[list[int]])->str:
    out=[f'{len(rows)} {m}']
    out.extend(f'{len(row)} '+' '.join(map(str,row)) for row in rows)
    return '\n'.join(out)+'\n'


def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc116_b':
        values=[1,2,3,4,5,6,7,8,9,10,11,19,27,54,73,97,99]
        for s in values:
            add('boundary' if s in (1,2,99) else 'normal',f'{s}\n')
        add('constraint_max','100\n')
    elif pid=='abc117_b':
        cases=[
          [1,1,1], [1,1,2], [1,1,3], [3,4,5], [3,8,5,1], [3,8,4,1],
          [100,100,1], [100,50,50], [100,51,50], [2,2,2,2], [1,2,3,4,5],
          [10,10,10,10,39], [10,10,10,10,40], [10,10,10,10,41],
          [1,8,10,5,8,12,34,100,11,3], [100,1,1,1,1,1,1,1,1,94],
          [100,1,1,1,1,1,1,1,1,95],
        ]
        for sides in cases:
            add('boundary' if len(sides) in (3,10) or 100 in sides else 'normal',_polygon(sides))
        add('constraint_max',_polygon([100]*10))
    else:
        cases=[
          (1,[[1]]),
          (30,[[5,10,30]]),
          (4,[[1,3],[1,2,3],[3,2]]),
          (5,[[2,3,4,5],[1,3,4,5],[1,2,4,5],[1,2,3,5],[1,2,3,4]]),
          (3,[[1],[1],[1]]),
          (3,[[1],[2],[3]]),
          (4,[[1,2,3,4],[4],[2,4],[1,4]]),
          (4,[[4,3,2,1],[1,2,3,4]]),
          (6,[[1,2,3],[2,3,4],[2,3,5],[2,3,6]]),
          (6,[[1,2],[2,3],[3,4],[4,5],[5,6]]),
          (10,[[1,2,3,4,5],[5,4,3,2,1],[1,3,5],[1,2,3,5]]),
          (10,[[10],[10],[10],[10],[10],[10],[10],[10],[10],[10]]),
          (10,[[1,10],[2,10],[3,10],[4,10],[5,10],[6,10],[7,10],[8,10],[9,10],[10]]),
          (2,[[1,2],[2]]),
          (2,[[1],[2]]),
          (30,[list(range(1,31))]),
          (30,[list(range(1,31)),list(range(30,0,-1)),[1,15,30]]),
        ]
        for m,people in cases:
            add('boundary' if len(people)==1 or m in (1,30) else 'normal',_foods(m,people))
        maximum=[list(range(1,31)) for _ in range(30)]
        add('constraint_max',_foods(30,maximum))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
