"""Statement-checked three-stage hints for ABC224–226 B."""
HINTS_V122 = {
    'abc224_b': (
        '条件は「2行と2列を選んだときの4マス」の不等式です。H,Wは最大50なので、まず全ての組をそのまま確認できる計算量か考えてください。',
        '`i1<i2` と `j1<j2` の4重ループでも最大で約625万組です。各組で `A[i1][j1]+A[i2][j2] <= A[i2][j1]+A[i1][j2]` を確認します。',
        '疑似コード:\nfor i1 = 0 .. H-1:\n  for i2 = i1+1 .. H-1:\n    for j1 = 0 .. W-1:\n      for j2 = j1+1 .. W-1:\n        if A[i1][j1] + A[i2][j2] > A[i2][j1] + A[i1][j2]:\n          print No and stop\nprint Yes',
    ),
    'abc225_b': (
        'スターでは、中心となる1頂点だけが他のN-1頂点すべてと直接つながっています。各頂点の次数に注目してください。',
        '全辺を1回見て各頂点の次数を数え、次数がN-1の頂点が存在するか判定すれば十分です。',
        '疑似コード:\ndeg = array of N zeros\nfor each edge (a,b):\n  deg[a] += 1\n  deg[b] += 1\nif max(deg) == N-1:\n  print Yes\nelse:\n  print No',
    ),
    'abc226_b': (
        '同じ数列かどうかは「長さも各要素も全て同じ」場合だけです。Pythonでは数列をtupleにすればsetの要素にできます。',
        '各入力行から長さLを除いた数列部分をtuple化してsetへ追加し、最後にsetの要素数を出せば異なる数列の種類数になります。',
        '疑似コード:\nseen = empty set\nrepeat N times:\n  read L and sequence A\n  add tuple(A) to seen\nprint size(seen)',
    ),
}
