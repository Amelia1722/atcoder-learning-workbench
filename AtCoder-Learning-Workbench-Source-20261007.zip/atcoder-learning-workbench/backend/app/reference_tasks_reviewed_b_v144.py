"""ABC290–301 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import math
import re
from collections import Counter
from itertools import permutations

TASKS = tuple(f"abc{i}_b" for i in range(290, 302))
LANES = {
    "A": ("abc290_b", "abc291_b", "abc292_b"),
    "B": ("abc293_b", "abc294_b", "abc295_b"),
    "C": ("abc296_b", "abc297_b", "abc298_b"),
    "D": ("abc299_b", "abc300_b", "abc301_b"),
}
TITLES = {
    "abc290_b": "Qual B",
    "abc291_b": "Trimmed Mean",
    "abc292_b": "Yellow and Red Card",
    "abc293_b": "Call the ID Number",
    "abc294_b": "ASCII Art",
    "abc295_b": "Bombs",
    "abc296_b": "Chessboard",
    "abc297_b": "chess960",
    "abc298_b": "Coloring Matrix",
    "abc299_b": "Trick Taking",
    "abc300_b": "Same Map in the RPG World",
    "abc301_b": "Fill the Gaps",
}
INT = re.compile(r"(?:0|[1-9][0-9]*)", re.ASCII)
NUM = re.compile(r"[+-]?(?:(?:[0-9]+(?:\.[0-9]*)?)|(?:\.[0-9]+))(?:[eE][+-]?[0-9]+)?", re.ASCII)
OX = re.compile(r"[ox]+", re.ASCII)
DOT_HASH = re.compile(r"[.#]+", re.ASCII)
DOT_STAR = re.compile(r"[.*]+", re.ASCII)
BOMB_ROW = re.compile(r"[.#1-9]+", re.ASCII)

SAMPLE294_4_INPUT = """24 60
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 13 13 14 0 0 0 10 0 0 0 0 0 15 24 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 13 23 7 25 24 13 10 0 10 12 0 0 0 0 19 9 23 0 0 0 0 10 10 14 0 0 0 10 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 9 13 5 0 0 23 11 14 14 0 0 12 9 1 21 19 0 0 9 12 10 25 3 10 6 0 0 9 13 23 24 14 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 13 14 6 0 0 0 10 5 25 13 0 0 25 0 0 0 0 0 0 0 0 0 0 10 16 0 0 13 21 13 13 14 23 14 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 13 8 2 0 0 0 0 0 13 11 13 19 0 0 1 2 5 9 12 12 5 9 9 20 6 0 14 14 14 9 0 0 0 14 14 18 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 10 23 13 13 13 13 13 13 14 14 14 13 14 14 13 7 0 0 0 0 0 0 0 0 0 0 0 0 13 13 13 2 0 0 0 0 13 11 13 16 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 13 1 0 0 0 9 20 9 20 20 20 20 13 20 20 13 20 23 8 8 8 20 8 20 7 8 17 7 10 13 14 13 19 0 0 0 0 0 22 14 25 13 16 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 13 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 20 13 13 7 20 26 13 8 6 14 0 0 0 0 0 0 0 0 0
0 0 0 0 0 5 0 0 0 0 0 0 0 1 2 20 20 23 13 2 7 2 10 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 23 13 0 0 0 0 0 0 0 0 0
0 0 0 0 13 0 0 0 0 0 0 0 0 1 0 0 0 13 12 9 14 13 13 9 9 20 12 0 0 0 0 0 0 0 0 0 0 0 1 9 9 9 9 12 0 0 0 0 0 0 0 20 0 0 0 0 0 0 0 0
0 0 0 2 0 0 0 0 0 0 0 0 0 0 19 0 0 14 13 14 14 13 13 0 0 9 5 16 0 0 0 0 0 0 5 20 20 13 2 2 20 9 13 14 14 20 12 12 0 0 0 0 9 13 0 0 0 0 0 0
0 0 1 9 0 0 0 0 0 0 0 0 0 0 0 13 10 13 13 13 13 2 5 12 10 5 0 0 0 0 0 0 0 0 20 16 0 0 0 13 14 13 13 13 13 0 0 10 8 0 0 0 0 0 20 7 0 0 0 0
0 0 4 2 0 0 0 0 0 0 0 0 0 0 0 0 9 7 14 10 10 14 13 5 0 0 0 0 0 0 0 0 0 0 0 23 13 12 13 13 13 13 13 9 13 0 14 4 0 0 0 0 0 0 0 9 16 0 0 0
0 0 22 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 13 13 13 2 9 14 2 20 14 0 0 0 0 0 0 0 0 0 2 0 0 0
0 0 0 5 13 0 0 0 2 7 13 13 13 13 13 13 13 2 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 9 20 20 9 0 0 0 0 0 0 0 0 0 0 0 0 0 19 0 0 0
0 0 0 0 20 13 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 14 7 2 20 24 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 9 6 0 0 0
0 0 0 0 0 0 9 14 14 0 0 20 20 13 13 20 13 9 0 0 10 0 0 0 0 0 0 9 23 13 9 0 0 0 0 0 0 0 10 6 0 0 7 0 0 9 20 13 13 14 2 0 0 0 0 5 0 0 0 0
0 0 0 0 0 0 0 0 20 13 14 0 0 0 0 0 0 0 0 13 9 0 0 0 0 0 0 0 0 13 11 0 0 0 0 0 0 0 14 9 0 0 0 20 25 14 7 0 0 0 0 9 1 14 7 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 9 13 13 20 0 0 0 0 0 9 12 0 0 0 0 0 0 0 14 13 14 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 9 9 20 14 14 4 14 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 2 9 0 0 0 0 9 9 20 21 7 13 20 0 0 20 23 7 7 2 12 7 6 0 0 0 0 0 0 0 0 0 0 0 0 5 5 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 9 9 20 24 10 12 10 0 0 0 0 0 0 0 0 20 20 0 0 0 0 0 20 7 7 13 22 2 5 9 2 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 9 20 5 20 5 2 5 7 20 5 14 14 5 11 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
"""
SAMPLE294_4_OUTPUT = """................................B...........................
...................MMN...J.....OXN..........................
.................MWGYXMJ.JL....SIW....JJN...JN..............
...............IME..WKNN..LIAUS..ILJYCJF..IMWXN.............
..............MNF...JEYM..Y..........JP..MUMMNWN............
.............MHB.....MKMS..ABEILLEIITF.NNNI...NNR...........
..........JWMMMMMMNNNMNNMG............MMMB....MKMP..........
........MA...ITITTTTMTTMTWHHHTHTGHQGJMNMS.....VNYMP.........
......MI...............................TTTMMGTZMHFN.........
.....E.......ABTTWMBGBJL.......................TTWM.........
....M........A...MLINMMIITL...........AIIIIL.......T........
...B..........S..NMNNMM..IEP......ETTMBBTIMNNTLL....IM......
..AI...........MJMMMMBELJE........TP...MNMMMM..JH.....TG....
..DB............IGNJJNME...........WMLMMMMMIM.ND.......IP...
..VM.................................TMMMBINBTN.........B...
...EM...BGMMMMMMMBI....................ITTI.............S...
....TML..................UNGBTX........................IF...
......INN..TTMMTMI..J......IWMI.......JF..G..ITMMNB....E....
........TMN........MI........MK.......NI...TYNG....IANG.....
..........IMMT.....IL.......NMN.......F........IITNNDN......
..............TBI....IITUGMT..TWGGBLGF............EE........
.................TTIITXJLJ........TT.....TGGMVBEIB..........
.........................ITETEBEGTENNEKEB...................
............................................................
"""

PUBLISHED_SAMPLES = {
    "abc290_b": [
        {"input": "10 3\noxxoxooxox\n", "expected": "oxxoxoxxxx\n"},
    ],
    "abc291_b": [
        {"input": "1\n10 100 20 50 30\n", "expected": "33.333333333333336\n"},
        {"input": "2\n3 3 3 4 5 6 7 8 99 100\n", "expected": "5.500000000000000\n"},
    ],
    "abc292_b": [
        {"input": "3 9\n3 1\n3 2\n1 2\n2 1\n3 1\n3 2\n1 2\n3 2\n3 3\n", "expected": "No\nNo\nYes\nNo\nYes\nNo\n"},
    ],
    "abc293_b": [
        {"input": "5\n3 1 4 5 4\n", "expected": "2\n2 4\n"},
        {"input": "20\n9 7 19 7 10 4 13 9 4 8 10 15 16 3 18 19 12 13 2 12\n", "expected": "10\n1 2 5 6 8 11 14 17 18 20\n"},
    ],
    "abc294_b": [
        {"input": "2 3\n0 1 2\n0 0 3\n", "expected": ".AB\n..C\n"},
        {"input": "3 3\n24 0 0\n0 25 0\n0 0 26\n", "expected": "X..\n.Y.\n..Z\n"},
        {"input": "3 1\n2\n9\n4\n", "expected": "B\nI\nD\n"},
        {"input": SAMPLE294_4_INPUT, "expected": SAMPLE294_4_OUTPUT},
    ],
    "abc295_b": [
        {"input": "4 4\n.1.#\n###.\n.#2.\n#.##\n", "expected": "...#\n#...\n....\n#...\n"},
        {"input": "2 5\n..#.#\n###.#\n", "expected": "..#.#\n###.#\n"},
        {"input": "2 3\n11#\n###\n", "expected": "...\n..#\n"},
        {"input": "4 6\n#.#3#.\n###.#.\n##.###\n#1..#.\n", "expected": "......\n#.....\n#....#\n....#.\n"},
    ],
    "abc296_b": [
        {"input": "........\n........\n........\n........\n........\n........\n........\n*.......\n", "expected": "a1\n"},
        {"input": "........\n........\n........\n........\n........\n.*......\n........\n........\n", "expected": "b3\n"},
    ],
    "abc297_b": [
        {"input": "RNBQKBNR\n", "expected": "Yes\n"},
        {"input": "KRRBBNNQ\n", "expected": "No\n"},
        {"input": "BRKRBQNN\n", "expected": "No\n"},
    ],
    "abc298_b": [
        {"input": "3\n0 1 1\n1 0 0\n0 1 0\n1 1 0\n0 0 1\n1 1 1\n", "expected": "Yes\n"},
        {"input": "2\n0 0\n0 0\n1 1\n1 1\n", "expected": "Yes\n"},
        {"input": "5\n0 0 1 1 0\n1 0 0 1 0\n0 0 1 0 1\n0 1 0 1 0\n0 1 0 0 1\n1 1 0 0 1\n0 1 1 1 0\n0 0 1 1 1\n1 0 1 0 1\n1 1 0 1 0\n", "expected": "No\n"},
    ],
    "abc299_b": [
        {"input": "4 2\n1 2 1 2\n6 3 4 5\n", "expected": "4\n"},
        {"input": "4 2\n1 3 1 4\n6 3 4 5\n", "expected": "1\n"},
        {"input": "2 1000000000\n1000000000 1\n1 1000000000\n", "expected": "1\n"},
    ],
    "abc300_b": [
        {"input": "4 3\n..#\n...\n.#.\n...\n#..\n...\n.#.\n...\n", "expected": "Yes\n"},
        {"input": "3 2\n##\n##\n#.\n..\n#.\n#.\n", "expected": "No\n"},
        {"input": "4 5\n#####\n.#...\n.##..\n..##.\n...##\n#...#\n#####\n...#.\n", "expected": "Yes\n"},
        {"input": "10 30\n..........##########..........\n..........####....###.....##..\n.....##....##......##...#####.\n....####...##..#####...##...##\n...##..##..##......##..##....#\n#.##....##....##...##..##.....\n..##....##.##..#####...##...##\n..###..###..............##.##.\n.#..####..#..............###..\n#..........##.................\n................#..........##.\n######....................####\n....###.....##............####\n.....##...#####......##....##.\n.#####...##...##....####...##.\n.....##..##....#...##..##..##.\n##...##..##.....#.##....##....\n.#####...##...##..##....##.##.\n..........##.##...###..###....\n...........###...#..####..#...\n", "expected": "Yes\n"},
    ],
    "abc301_b": [
        {"input": "4\n2 5 1 2\n", "expected": "2 3 4 5 4 3 2 1 2\n"},
        {"input": "6\n3 4 5 6 5 4\n", "expected": "3 4 5 6 5 4\n"},
    ],
}
SAMPLE_COUNTS = {pid: len(rows) for pid, rows in PUBLISHED_SAMPLES.items()}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith("\n") or "\r" in raw:
        raise ValueError("noncanonical")
    body = raw[:-1]
    if body.endswith("\n"):
        raise ValueError("extra blank line")
    return body.split("\n")


def _ints_line(line: str) -> list[int]:
    parts = line.split(" ")
    if not parts or any(INT.fullmatch(x) is None for x in parts) or " ".join(parts) != line:
        raise ValueError("integer line")
    return [int(x) for x in parts]


def _validate290(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 2:
        raise ValueError("shape")
    n, k = h
    s = lines[1]
    if not 1 <= k <= n <= 100 or len(s) != n or OX.fullmatch(s) is None or s.count("o") < k:
        raise ValueError("constraints")
    return n, k, s


def _validate291(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 1 or not 1 <= h[0] <= 100:
        raise ValueError("N")
    n = h[0]
    xs = _ints_line(lines[1])
    if len(xs) != 5 * n or any(not 0 <= x <= 100 for x in xs):
        raise ValueError("X")
    return n, tuple(xs)


def _validate292(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 2:
        raise ValueError("shape")
    n, q = h
    if not 1 <= n <= 100 or not 1 <= q <= 100 or len(lines) != q + 1:
        raise ValueError("constraints")
    events = []
    yellow = [0] * (n + 1)
    removed = [False] * (n + 1)
    queries = 0
    for line in lines[1:]:
        e = _ints_line(line)
        if len(e) != 2:
            raise ValueError("event")
        c, x = e
        if c not in (1, 2, 3) or not 1 <= x <= n:
            raise ValueError("event")
        if c in (1, 2) and removed[x]:
            raise ValueError("card after removal")
        if c == 1:
            yellow[x] += 1
            if yellow[x] == 2:
                removed[x] = True
        elif c == 2:
            removed[x] = True
        else:
            queries += 1
        events.append((c, x))
    if queries == 0:
        raise ValueError("query required")
    return n, tuple(events)


def _validate293(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 1 or not 2 <= h[0] <= 200_000:
        raise ValueError("N")
    n = h[0]
    a = tuple(_ints_line(lines[1]))
    if len(a) != n or any(not 1 <= x <= n for x in a) or any(x == i + 1 for i, x in enumerate(a)):
        raise ValueError("A")
    return n, a


def _validate294(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 2:
        raise ValueError("shape")
    H, W = h
    if not 1 <= H <= 100 or not 1 <= W <= 100 or len(lines) != H + 1:
        raise ValueError("constraints")
    a = []
    for line in lines[1:]:
        row = _ints_line(line)
        if len(row) != W or any(not 0 <= x <= 26 for x in row):
            raise ValueError("A")
        a.append(tuple(row))
    return H, W, tuple(a)


def _validate295(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 2:
        raise ValueError("shape")
    R, C = h
    if not 1 <= R <= 20 or not 1 <= C <= 20 or len(lines) != R + 1:
        raise ValueError("constraints")
    g = tuple(lines[1:])
    if any(len(row) != C or BOMB_ROW.fullmatch(row) is None for row in g):
        raise ValueError("board")
    return R, C, g


def _validate296(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 8 or any(len(row) != 8 or DOT_STAR.fullmatch(row) is None for row in lines):
        raise ValueError("board")
    if sum(row.count("*") for row in lines) != 1:
        raise ValueError("star")
    return (tuple(lines),)


def _validate297(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1 or len(lines[0]) != 8:
        raise ValueError("shape")
    s = lines[0]
    if Counter(s) != Counter({"K": 1, "Q": 1, "R": 2, "B": 2, "N": 2}):
        raise ValueError("pieces")
    return (s,)


def _matrix_rows(lines: list[str], n: int):
    out = []
    for line in lines:
        row = _ints_line(line)
        if len(row) != n or any(x not in (0, 1) for x in row):
            raise ValueError("matrix")
        out.append(tuple(row))
    return tuple(out)


def _validate298(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 1 or not 1 <= h[0] <= 100:
        raise ValueError("N")
    n = h[0]
    if len(lines) != 1 + 2 * n:
        raise ValueError("shape")
    return n, _matrix_rows(lines[1:1+n], n), _matrix_rows(lines[1+n:], n)


def _validate299(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 3:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 2:
        raise ValueError("shape")
    n, t = h
    if not 2 <= n <= 200_000 or not 1 <= t <= 10**9:
        raise ValueError("constraints")
    c = tuple(_ints_line(lines[1])); r = tuple(_ints_line(lines[2]))
    if len(c) != n or len(r) != n or any(not 1 <= x <= 10**9 for x in c + r) or len(set(r)) != n:
        raise ValueError("arrays")
    return n, t, c, r


def _validate300(raw: str):
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 2:
        raise ValueError("shape")
    H, W = h
    if not 2 <= H <= 30 or not 2 <= W <= 30 or len(lines) != 1 + 2 * H:
        raise ValueError("constraints")
    a = tuple(lines[1:1+H]); b = tuple(lines[1+H:])
    if any(len(row) != W or DOT_HASH.fullmatch(row) is None for row in a + b):
        raise ValueError("grid")
    return H, W, a, b


def _validate301(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2:
        raise ValueError("shape")
    h = _ints_line(lines[0])
    if len(h) != 1 or not 2 <= h[0] <= 100:
        raise ValueError("N")
    n = h[0]
    a = tuple(_ints_line(lines[1]))
    if len(a) != n or any(not 1 <= x <= 100 for x in a) or any(a[i] == a[i+1] for i in range(n-1)):
        raise ValueError("A")
    return n, a


def validate(pid: str, raw: str):
    fn = globals().get(f"_validate{pid[3:6]}")
    if pid not in TASKS or fn is None:
        raise ValueError("unknown task")
    return fn(raw)


def _output_single_line(output: str) -> str | None:
    if not isinstance(output, str) or not output or output != output.strip() or "\n" in output or "\r" in output:
        return None
    return output


def _oracle290(n: int, k: int, s: str) -> str:
    wanted = set(i for i, ch in enumerate(s) if ch == "o")
    keep = set(sorted(wanted)[:k])
    return "".join("o" if i in keep else "x" for i in range(n))


def _oracle291(n: int, xs: tuple[int, ...]) -> tuple[int, int]:
    cnt = [0] * 101
    for x in xs:
        cnt[x] += 1
    lo = n
    hi = n
    keep = cnt[:]
    for v in range(101):
        take = min(lo, keep[v]); keep[v] -= take; lo -= take
        if lo == 0: break
    for v in range(100, -1, -1):
        take = min(hi, keep[v]); keep[v] -= take; hi -= take
        if hi == 0: break
    num = sum(v * keep[v] for v in range(101))
    return num, 3 * n


def _oracle292(n: int, events: tuple[tuple[int, int], ...]) -> list[str]:
    yellow_once: set[int] = set()
    removed: set[int] = set()
    ans = []
    for c, x in events:
        if c == 1:
            if x in yellow_once:
                yellow_once.remove(x); removed.add(x)
            else:
                yellow_once.add(x)
        elif c == 2:
            yellow_once.discard(x); removed.add(x)
        else:
            ans.append("Yes" if x in removed else "No")
    return ans


def _oracle293(n: int, a: tuple[int, ...]) -> list[int]:
    untouched = set(range(1, n + 1))
    for i, target in enumerate(a, 1):
        if i in untouched:
            untouched.discard(target)
    return sorted(untouched)


def _oracle294(H: int, W: int, a: tuple[tuple[int, ...], ...]) -> list[str]:
    chars = ".ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return ["".join(chars[x] for x in row) for row in a]


def _oracle295(R: int, C: int, g: tuple[str, ...]) -> list[str]:
    board = [list(row) for row in g]
    bombs = [(i, j, int(g[i][j])) for i in range(R) for j in range(C) if g[i][j].isdigit()]
    for br, bc, p in bombs:
        for dr in range(-p, p + 1):
            rem = p - abs(dr)
            rr = br + dr
            if not 0 <= rr < R:
                continue
            for cc in range(max(0, bc-rem), min(C, bc+rem+1)):
                board[rr][cc] = "."
    return ["".join(row) for row in board]


def _oracle296(g: tuple[str, ...]) -> str:
    labels = {(r, c): f"{'abcdefgh'[c]}{r+1}" for r in range(8) for c in range(8)}
    for top in range(8):
        for c, ch in enumerate(g[top]):
            if ch == "*":
                return labels[(7-top, c)]
    raise AssertionError


def _oracle297(s: str) -> bool:
    bishop_positions = [i for i, ch in enumerate(s) if ch == "B"]
    bishops_ok = {p % 2 for p in bishop_positions} == {0, 1}
    rk = [ch for ch in s if ch in "RK"]
    return bishops_ok and rk == ["R", "K", "R"]


def _oracle298(n: int, a: tuple[tuple[int, ...], ...], b: tuple[tuple[int, ...], ...]) -> bool:
    ones = [(i, j) for i in range(n) for j in range(n) if a[i][j]]
    for rot in range(4):
        ok = True
        for i, j in ones:
            if rot == 0: x, y = i, j
            elif rot == 1: x, y = j, n - 1 - i
            elif rot == 2: x, y = n - 1 - i, n - 1 - j
            else: x, y = n - 1 - j, i
            if b[x][y] != 1:
                ok = False; break
        if ok:
            return True
    return False


def _oracle299(n: int, t: int, c: tuple[int, ...], r: tuple[int, ...]) -> int:
    desired = t if t in set(c) else c[0]
    for idx in sorted(range(n), key=lambda i: r[i], reverse=True):
        if c[idx] == desired:
            return idx + 1
    raise AssertionError


def _oracle300(H: int, W: int, a: tuple[str, ...], b: tuple[str, ...]) -> bool:
    pa = {(i, j) for i in range(H) for j in range(W) if a[i][j] == "#"}
    pb = {(i, j) for i in range(H) for j in range(W) if b[i][j] == "#"}
    if len(pa) != len(pb):
        return False
    for s in range(H):
        for t in range(W):
            shifted = {((i - s) % H, (j - t) % W) for i, j in pa}
            if shifted == pb:
                return True
    return False


def _oracle301(n: int, a: tuple[int, ...]) -> list[int]:
    arr = list(a)
    i = 0
    while i + 1 < len(arr):
        x, y = arr[i], arr[i+1]
        if abs(x-y) == 1:
            i += 1
            continue
        arr.insert(i+1, x + (1 if y > x else -1))
    return arr


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip() or "\r" in output:
        return False
    if pid == "abc290_b":
        return len(output) == value[0] and OX.fullmatch(output) is not None and output == _oracle290(*value)
    if pid == "abc291_b":
        if "\n" in output or NUM.fullmatch(output) is None:
            return False
        try: actual = float(output)
        except ValueError: return False
        if not math.isfinite(actual): return False
        num, den = _oracle291(*value); expected = num / den
        return abs(actual - expected) <= 1e-5 * max(1.0, abs(expected))
    if pid == "abc292_b":
        parts = output.split("\n")
        return parts == _oracle292(*value)
    if pid == "abc293_b":
        parts = output.split("\n")
        if len(parts) != 2 or INT.fullmatch(parts[0]) is None:
            return False
        xs = [] if parts[1] == "" else parts[1].split(" ")
        if any(INT.fullmatch(x) is None for x in xs): return False
        vals = [int(x) for x in xs]
        oracle = _oracle293(*value)
        return int(parts[0]) == len(oracle) and vals == oracle
    if pid == "abc294_b":
        return output.split("\n") == _oracle294(*value)
    if pid == "abc295_b":
        return output.split("\n") == _oracle295(*value)
    if pid == "abc296_b":
        return _output_single_line(output) == _oracle296(*value)
    if pid == "abc297_b":
        return _output_single_line(output) == ("Yes" if _oracle297(*value) else "No")
    if pid == "abc298_b":
        return _output_single_line(output) == ("Yes" if _oracle298(*value) else "No")
    if pid == "abc299_b":
        return INT.fullmatch(output) is not None and int(output) == _oracle299(*value)
    if pid == "abc300_b":
        return _output_single_line(output) == ("Yes" if _oracle300(*value) else "No")
    if pid == "abc301_b":
        parts = output.split(" ")
        return all(INT.fullmatch(x) is not None for x in parts) and [int(x) for x in parts] == _oracle301(*value)
    return False


def official_expected_matches_reference(pid: str, raw: str, expected: str, actual_with_newline: str) -> bool:
    if not actual_with_newline.endswith("\n"):
        return False
    actual = actual_with_newline[:-1]
    exp = expected.removesuffix("\n")
    if pid == "abc291_b":
        return independent_check(pid, raw, actual) and independent_check(pid, raw, exp)
    return actual_with_newline == expected


def _add(out: list[dict[str, str]], seen: set[str], pid: str, category: str, raw: str) -> None:
    validate(pid, raw)
    if raw not in seen:
        seen.add(raw); out.append({"category": category, "input": raw})


def _grid_input(mat: list[list[int]]) -> str:
    n = len(mat)
    return str(n) + "\n" + "\n".join(" ".join(map(str, row)) for row in mat + [[0]])  # unused helper guard


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError("unknown task")
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        _add(out, seen, pid, f"sample{i}", row["input"])

    custom: list[tuple[str, str]] = []
    max_case = ""
    if pid == "abc290_b":
        custom = [
            ("minimum", "1 1\no\n"), ("all_o_k1", "5 1\nooooo\n"), ("all_o_k4", "5 4\nooooo\n"),
            ("exact_k", "5 3\noxoxo\n"), ("late_o", "6 2\nxxxxoo\n"), ("many_x", "8 3\nxoxxoxoo\n"),
            ("k_n_all_o", "6 6\noooooo\n"), ("first_k", "7 2\noooxooo\n"), ("last_cut", "7 3\noxoxoxo\n"),
            ("single_x_gap", "4 3\nooxo\n"), ("alternating", "10 5\noxoxoxoxoo\n"), ("prefix_x", "9 4\nxxoooooxo\n"),
            ("suffix_x", "9 4\noooooxxxx\n"), ("k2", "2 1\nxo\n"), ("dense", "12 6\nooxoooxoxoxo\n"), ("k_mid", "10 4\nooxoxooxoo\n"),
        ]
        max_case = "100 100\n" + "o" * 100 + "\n"
    elif pid == "abc291_b":
        custom = [
            ("all_equal", "1\n50 50 50 50 50\n"), ("zeros", "1\n0 0 0 0 0\n"), ("hundreds", "1\n100 100 100 100 100\n"),
            ("ordered", "2\n0 1 2 3 4 5 6 7 8 9\n"), ("reverse", "2\n9 8 7 6 5 4 3 2 1 0\n"),
            ("ties_edges", "2\n0 0 0 10 10 10 20 20 100 100\n"), ("integer_mean", "1\n0 10 20 30 40\n"),
            ("repeating", "3\n0 100 50 50 50 1 99 2 98 3 97 4 96 5 95\n"),
            ("low_cluster", "4\n" + " ".join(map(str,[0]*6+[1]*6+[50]*4+[100]*4)) + "\n"),
            ("high_cluster", "4\n" + " ".join(map(str,[0]*4+[50]*4+[99]*6+[100]*6)) + "\n"),
            ("n10", "10\n" + " ".join(str((i*37)%101) for i in range(50)) + "\n"),
            ("n20", "20\n" + " ".join(str((i*i+7*i)%101) for i in range(100)) + "\n"),
            ("saw", "5\n" + " ".join(str(x) for x in ([0,100,25,75,50]*5)) + "\n"),
            ("binary", "5\n" + " ".join(str(x) for x in ([0]*12+[100]*13)) + "\n"),
            ("n3", "3\n" + " ".join(map(str,[3,3,3,3,4,4,4,5,5,5,6,6,7,8,9])) + "\n"),
        ]
        max_case = "100\n" + " ".join(str((i*73+19)%101) for i in range(500)) + "\n"
    elif pid == "abc292_b":
        custom = [
            ("minimum_query", "1 1\n3 1\n"), ("yellow_once", "1 2\n1 1\n3 1\n"), ("two_yellow", "1 3\n1 1\n1 1\n3 1\n"),
            ("red", "1 2\n2 1\n3 1\n"), ("mixed_players", "3 6\n1 1\n1 2\n3 1\n2 3\n3 3\n3 2\n"),
            ("query_repeat", "2 4\n3 1\n3 1\n3 2\n3 2\n"), ("remove_then_queries", "2 5\n1 1\n1 1\n3 1\n3 1\n3 2\n"),
            ("red_vs_yellow", "2 5\n1 1\n2 2\n3 1\n3 2\n1 1\n"), ("n100_one", "100 3\n1 100\n3 100\n3 1\n"),
            ("all_queries", "5 5\n3 1\n3 2\n3 3\n3 4\n3 5\n"), ("cards_and_queries", "4 8\n1 1\n1 2\n3 1\n1 1\n3 1\n2 3\n3 3\n3 4\n"),
            ("two_red", "3 5\n2 1\n2 2\n3 1\n3 2\n3 3\n"), ("late_remove", "2 6\n3 1\n1 1\n3 1\n1 1\n3 1\n3 2\n"),
            ("yellow_each", "4 8\n1 1\n1 2\n1 3\n1 4\n3 1\n3 2\n3 3\n3 4\n"), ("n2", "2 3\n2 2\n3 1\n3 2\n"), ("red_first", "3 4\n2 3\n3 3\n1 1\n3 1\n"),
        ]
        ev=[]
        removed=set()
        for i in range(1,34):
            ev += [(1,i),(1,i),(3,i)]; removed.add(i)
        ev.append((3,100))
        max_case = "100 100\n" + "\n".join(f"{c} {x}" for c,x in ev) + "\n"
    elif pid == "abc293_b":
        custom = [
            ("n2_cycle", "2\n2 1\n"), ("pairs", "6\n2 1 4 3 6 5\n"), ("chain_like", "6\n2 3 4 5 6 1\n"),
            ("all_to1_except1", "5\n2 1 1 1 1\n"), ("alternating_targets", "8\n2 1 4 3 6 5 8 7\n"),
            ("skip_called", "5\n2 3 4 5 1\n"), ("n10", "10\n2 1 2 3 4 5 6 7 8 9\n"),
            ("reverse_targets", "7\n7 7 7 7 7 7 1\n"), ("two_hubs", "8\n2 1 2 2 6 5 6 6\n"),
            ("odd_even", "9\n2 1 4 3 6 5 8 7 1\n"), ("last_calls_first", "6\n6 1 2 3 4 1\n"),
            ("first_calls_last", "6\n6 1 2 3 4 5\n"), ("n20_pairs", "20\n" + " ".join(str(i+1 if i%2 else i-1) for i in range(1,21)) + "\n"),
            ("n30_cycle", "30\n" + " ".join(str(i%30+1) for i in range(1,31)) + "\n"), ("many_same", "12\n2 1 1 1 1 1 1 1 1 1 1 1\n"),
        ]
        n=200_000; a=[i+2 for i in range(n-1)]+[1]
        max_case = f"{n}\n" + " ".join(map(str,a)) + "\n"
    elif pid == "abc294_b":
        custom = [
            ("minimum_zero", "1 1\n0\n"), ("minimum_a", "1 1\n1\n"), ("minimum_z", "1 1\n26\n"),
            ("all_letters", "1 26\n" + " ".join(map(str,range(1,27))) + "\n"), ("all_zero", "2 2\n0 0\n0 0\n"),
            ("corners", "2 3\n1 0 26\n26 0 1\n"), ("mixed", "3 4\n0 1 13 26\n2 0 14 25\n3 4 0 24\n"),
            ("row", "1 5\n0 5 0 6 0\n"), ("column", "5 1\n1\n0\n2\n0\n3\n"),
            ("checker", "4 4\n1 0 1 0\n0 26 0 26\n1 0 1 0\n0 26 0 26\n"),
            ("alphabet_wrap", "2 13\n" + " ".join(map(str,range(1,14))) + "\n" + " ".join(map(str,range(14,27))) + "\n"),
            ("h10w10", "10 10\n" + "\n".join(" ".join(str((i*10+j)%27) for j in range(10)) for i in range(10)) + "\n"),
            ("zeros_border", "3 5\n0 0 0 0 0\n0 1 2 3 0\n0 0 0 0 0\n"),
        ]
        mat = [[(i*100+j)%27 for j in range(100)] for i in range(100)]
        max_case = "100 100\n" + "\n".join(" ".join(map(str,row)) for row in mat) + "\n"
    elif pid == "abc295_b":
        custom = [
            ("minimum_empty", "1 1\n.\n"), ("minimum_wall", "1 1\n#\n"), ("minimum_bomb", "1 1\n1\n"),
            ("center1", "3 3\n###\n#1#\n###\n"), ("corner2", "4 4\n2###\n####\n####\n####\n"),
            ("power9", "3 5\n#####\n##9##\n#####\n"), ("overlap", "3 5\n1###1\n#####\n#####\n"),
            ("digits_survive_no", "2 4\n1..2\n####\n"), ("bombs_only", "2 3\n123\n456\n"),
            ("sparse", "5 5\n#...#\n..1..\n#...#\n.....\n#...#\n"), ("rectangle", "2 20\n1###################\n####################\n"),
            ("r20c1", "20 1\n" + "\n".join(["#"]*9+["9"]+["#"]*10) + "\n"), ("mixed_powers", "5 7\n#1#####\n#######\n###2###\n#######\n#####3#\n"),
        ]
        rows=[]
        for i in range(20):
            row=[]
            for j in range(20):
                if (i,j) in {(0,0),(19,19),(10,10)}: row.append("9")
                else: row.append("#" if (i+j)%3 else ".")
            rows.append("".join(row))
        max_case = "20 20\n" + "\n".join(rows) + "\n"
    elif pid == "abc296_b":
        positions=[(0,0),(0,7),(7,0),(7,7),(3,3),(4,4),(1,6),(6,1),(2,5),(5,2),(0,3),(7,4),(3,0),(4,7),(2,2),(5,5)]
        for idx,(r,c) in enumerate(positions):
            g=[list("........") for _ in range(8)]; g[r][c]="*"
            custom.append((f"pos{idx+1}", "\n".join("".join(x) for x in g)+"\n"))
        g=[list("........") for _ in range(8)]; g[1][1]="*"; max_case="\n".join("".join(x) for x in g)+"\n"
    elif pid == "abc297_b":
        base="KQRRBBNN"
        vals=[]
        for p in permutations(base):
            s="".join(p)
            if s not in vals:
                vals.append(s)
            if len(vals)>=25: break
        for i,s in enumerate(vals): custom.append((f"perm{i+1}",s+"\n"))
        max_case="RBNQKNBR\n"
    elif pid == "abc298_b":
        custom = [
            ("n1_zero", "1\n0\n0\n"), ("n1_one_yes", "1\n1\n1\n"), ("n1_one_no", "1\n1\n0\n"),
            ("rotate90", "2\n1 0\n0 0\n0 1\n0 0\n"), ("rotate180", "2\n1 0\n0 0\n0 0\n0 1\n"),
            ("b_superset", "2\n1 0\n0 0\n1 1\n1 1\n"), ("a_all_zero", "3\n0 0 0\n0 0 0\n0 0 0\n0 0 0\n0 0 0\n0 0 0\n"),
            ("a_all_one_b_one", "2\n1 1\n1 1\n1 1\n1 1\n"), ("impossible_count", "2\n1 1\n1 0\n1 0\n0 0\n"),
            ("n3_diag", "3\n1 0 0\n0 1 0\n0 0 1\n0 0 1\n0 1 0\n1 0 0\n"),
            ("n4_sparse", "4\n1 0 0 0\n0 0 1 0\n0 0 0 0\n0 0 0 1\n1 1 1 1\n1 1 1 1\n1 1 1 1\n1 1 1 1\n"),
            ("n5_fail", "5\n1 0 0 0 0\n0 1 0 0 0\n0 0 1 0 0\n0 0 0 1 0\n0 0 0 0 1\n1 0 0 0 0\n0 0 0 0 0\n0 0 0 0 0\n0 0 0 0 0\n0 0 0 0 0\n"),
            ("n6", "6\n" + "\n".join(" ".join("1" if i==j else "0" for j in range(6)) for i in range(6)) + "\n" + "\n".join(" ".join("1" for _ in range(6)) for _ in range(6)) + "\n"),
            ("subset_after270", "3\n0 0 1\n0 0 0\n1 0 0\n1 0 1\n0 0 0\n0 0 0\n"),
        ]
        A=[[1 if (i*17+j*11)%19==0 else 0 for j in range(100)] for i in range(100)]
        B=[[1 for _ in range(100)] for _ in range(100)]
        max_case="100\n"+"\n".join(" ".join(map(str,row)) for row in A+B)+"\n"
    elif pid == "abc299_b":
        custom = [
            ("n2_target_present", "2 1\n1 2\n1 2\n"), ("n2_target_absent", "2 3\n1 1\n1 2\n"),
            ("target_first", "5 7\n7 1 7 2 7\n1 100 3 99 2\n"), ("fallback_first_color", "5 9\n4 5 4 5 4\n10 99 30 98 50\n"),
            ("largest_last", "4 2\n2 2 2 2\n1 2 3 100\n"), ("negative_not_allowed_bounds", "3 1\n1 2 1\n999999998 999999999 1000000000\n"),
            ("colors_large", "3 1000000000\n1000000000 5 1000000000\n10 20 30\n"), ("fallback_large", "3 999999999\n1000000000 5 1000000000\n10 20 30\n"),
            ("n10", "10 3\n1 2 3 4 3 2 1 3 4 3\n10 20 30 40 50 60 70 80 90 100\n"),
            ("target_one", "6 8\n1 2 3 8 4 5\n60 50 40 1 30 20\n"), ("fallback_tie_impossible", "4 9\n2 2 3 4\n4 3 2 1\n"),
            ("first_color_many", "7 99\n5 1 5 2 5 3 5\n1 100 3 99 5 98 7\n"), ("target_many", "7 3\n5 3 5 3 5 3 5\n7 1 6 2 5 100 4\n"),
            ("rank_max_first", "3 1\n1 1 1\n1000000000 1 2\n"),
        ]
        n=200_000; c=[1 if i%2==0 else 2 for i in range(n)]; r=list(range(1,n+1))
        max_case=f"{n} 2\n"+" ".join(map(str,c))+"\n"+" ".join(map(str,r))+"\n"
    elif pid == "abc300_b":
        custom = [
            ("min_yes", "2 2\n#.\n..\n#.\n..\n"), ("min_shift", "2 2\n#.\n..\n.#\n..\n"), ("min_no", "2 2\n#.\n..\n##\n..\n"),
            ("all_empty", "3 4\n....\n....\n....\n....\n....\n....\n"), ("all_hash", "2 3\n###\n###\n###\n###\n"),
            ("vertical_only", "3 3\n#..\n.#.\n..#\n.#.\n..#\n#..\n"), ("horizontal_only", "3 3\n#..\n.#.\n..#\n.#.\n..#\n#..\n"),
            ("wrap", "3 4\n#...\n....\n...#\n...#\n#...\n....\n"), ("same", "2 4\n#.#.\n.##.\n#.#.\n.##.\n"),
            ("count_mismatch", "3 3\n#..\n...\n...\n##.\n...\n...\n"),
            ("periodic", "4 4\n#.#.\n.#.#\n#.#.\n.#.#\n.#.#\n#.#.\n.#.#\n#.#.\n"),
            ("single_hash", "5 5\n#....\n.....\n.....\n.....\n.....\n.....\n.....\n..#..\n.....\n.....\n"),
            ("stripe", "5 6\n######\n......\n######\n......\n######\n......\n######\n......\n######\n######\n"),
            ("near_no", "3 3\n#..\n.#.\n...\n#..\n..#\n...\n"),
        ]
        A=["".join("#" if (i*7+j*5)%11<3 else "." for j in range(30)) for i in range(30)]
        s,t=17,23; B=["".join(A[(i+s)%30][(j+t)%30] for j in range(30)) for i in range(30)]
        max_case="30 30\n"+"\n".join(A+B)+"\n"
    else:
        custom = [
            ("minimum_up", "2\n1 2\n"), ("minimum_down", "2\n2 1\n"), ("gap_up", "2\n1 5\n"), ("gap_down", "2\n5 1\n"),
            ("ends", "2\n1 100\n"), ("ends_down", "2\n100 1\n"), ("zigzag", "4\n1 4 2 5\n"),
            ("already", "5\n1 2 3 4 5\n"), ("descending", "5\n5 4 3 2 1\n"), ("mixed", "5\n10 7 9 2 3\n"),
            ("high", "3\n98 100 97\n"), ("low", "3\n1 3 2\n"), ("repeat_nonadjacent", "4\n1 5 1 5\n"),
            ("n10", "10\n1 10 2 9 3 8 4 7 5 6\n"), ("big_gaps", "5\n1 100 1 100 1\n"),
        ]
        a=[1 if i%2==0 else 100 for i in range(100)]
        max_case="100\n"+" ".join(map(str,a))+"\n"

    for c, raw in custom:
        if len(out) >= 17:
            break
        _add(out, seen, pid, c, raw)
    # Fill deterministic variants if published+custom still did not reach 17.
    if pid == "abc297_b":
        for p in permutations("KQRRBBNN"):
            if len(out) >= 17: break
            _add(out, seen, pid, "perm_fill", "".join(p)+"\n")
    if pid == "abc296_b":
        for r in range(8):
            for c in range(8):
                if len(out) >= 17: break
                g=[list("........") for _ in range(8)]; g[r][c]="*"
                _add(out,seen,pid,"pos_fill","\n".join("".join(x) for x in g)+"\n")
            if len(out) >= 17: break
    _add(out, seen, pid, "constraint_max", max_case)
    if len(out) != 18 or len({r["input"] for r in out}) != 18 or out[-1]["category"] != "constraint_max":
        raise AssertionError(f"{pid}: expected 18 distinct cases ending in constraint_max, got {len(out)}")
    return out


REFERENCE_CODE = {
"abc290_b": '''import sys\nn,k=sys.stdin.readline().split(); n=int(n); k=int(k)\ns=sys.stdin.readline().strip()\nans=[]; used=0\nfor ch in s:\n    if ch=="o" and used<k:\n        ans.append("o"); used+=1\n    else:\n        ans.append("x")\nprint("".join(ans))\n''',
"abc291_b": '''import sys\nn=int(sys.stdin.readline())\nx=list(map(int,sys.stdin.readline().split()))\nx.sort()\nmid=x[n:4*n]\nprint(sum(mid)/(3*n))\n''',
"abc292_b": '''import sys\nit=iter(map(int,sys.stdin.read().split()))\nn=next(it); q=next(it); score=[0]*(n+1); ans=[]\nfor _ in range(q):\n    c=next(it); x=next(it)\n    if c==1: score[x]+=1\n    elif c==2: score[x]=2\n    else: ans.append("Yes" if score[x]>=2 else "No")\nprint("\\n".join(ans))\n''',
"abc293_b": '''import sys\ndata=list(map(int,sys.stdin.read().split())); n=data[0]; a=data[1:]\ncalled=[False]*n\nfor i,x in enumerate(a):\n    if not called[i]: called[x-1]=True\nans=[i+1 for i,v in enumerate(called) if not v]\nprint(len(ans)); print(*ans)\n''',
"abc294_b": '''import sys\nit=iter(map(int,sys.stdin.read().split())); h=next(it); w=next(it)\nfor _ in range(h):\n    row=[]\n    for _ in range(w):\n        x=next(it); row.append("." if x==0 else chr(ord("A")+x-1))\n    print("".join(row))\n''',
"abc295_b": '''import sys\ninput=sys.stdin.readline\nr,c=map(int,input().split()); g=[input().strip() for _ in range(r)]\nbombs=[]\nfor i in range(r):\n    for j,ch in enumerate(g[i]):\n        if ch.isdigit(): bombs.append((i,j,int(ch)))\nout=[]\nfor i in range(r):\n    row=[]\n    for j in range(c):\n        if any(abs(i-x)+abs(j-y)<=p for x,y,p in bombs): row.append(".")\n        else: row.append(g[i][j])\n    out.append("".join(row))\nprint("\\n".join(out))\n''',
"abc296_b": '''import sys\ng=[sys.stdin.readline().strip() for _ in range(8)]\nfor i,row in enumerate(g):\n    j=row.find("*")\n    if j!=-1:\n        print(chr(ord("a")+j)+str(8-i)); break\n''',
"abc297_b": '''import sys\ns=sys.stdin.readline().strip()\nb=[i for i,ch in enumerate(s) if ch=="B"]; r=[i for i,ch in enumerate(s) if ch=="R"]; k=s.index("K")\nprint("Yes" if b[0]%2!=b[1]%2 and r[0]<k<r[1] else "No")\n''',
"abc298_b": '''import sys\ninput=sys.stdin.readline\nn=int(input()); a=[list(map(int,input().split())) for _ in range(n)]; b=[list(map(int,input().split())) for _ in range(n)]\nfor _ in range(4):\n    if all(not a[i][j] or b[i][j] for i in range(n) for j in range(n)):\n        print("Yes"); break\n    a=[list(row) for row in zip(*a[::-1])]\nelse: print("No")\n''',
"abc299_b": '''import sys\ninput=sys.stdin.readline\nn,t=map(int,input().split()); c=list(map(int,input().split())); r=list(map(int,input().split()))\ncolor=t if t in c else c[0]\nbest=-1; ans=-1\nfor i in range(n):\n    if c[i]==color and r[i]>best: best=r[i]; ans=i+1\nprint(ans)\n''',
"abc300_b": '''import sys\ninput=sys.stdin.readline\nh,w=map(int,input().split()); a=[input().strip() for _ in range(h)]; b=[input().strip() for _ in range(h)]\nfor s in range(h):\n    for t in range(w):\n        ok=True\n        for i in range(h):\n            for j in range(w):\n                if a[(i+s)%h][(j+t)%w]!=b[i][j]: ok=False; break\n            if not ok: break\n        if ok: print("Yes"); raise SystemExit\nprint("No")\n''',
"abc301_b": '''import sys\ndata=list(map(int,sys.stdin.read().split())); n=data[0]; a=data[1:]; ans=[]\nfor x,y in zip(a,a[1:]):\n    ans.append(x)\n    step=1 if x<y else -1\n    ans.extend(range(x+step,y,step))\nans.append(a[-1]); print(*ans)\n''',
}
