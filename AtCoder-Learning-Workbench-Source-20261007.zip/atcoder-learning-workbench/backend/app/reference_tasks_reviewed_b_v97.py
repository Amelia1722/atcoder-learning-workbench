"""ABC149–151 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc149_b', 'abc150_b', 'abc151_b')
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
SIGNED_SMALL = re.compile(r'-1|(?:0|[1-9][0-9]*)', re.ASCII)
UPPER = re.compile(r'[A-Z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc149_b': [
        {'input':'2 3 3\n','expected':'0 2\n'},
        {'input':'500000000000 500000000000 1000000000000\n','expected':'0 0\n'},
    ],
    'abc150_b': [
        {'input':'10\nZABCDBABCQ\n','expected':'2\n'},
        {'input':'19\nTHREEONEFOURONEFIVE\n','expected':'0\n'},
        {'input':'33\nABCCABCBABCCABACBCBBABCBCBCBCABCB\n','expected':'5\n'},
    ],
    'abc151_b': [
        {'input':'5 10 7\n8 10 3 6\n','expected':'8\n'},
        {'input':'4 100 60\n100 100 100\n','expected':'0\n'},
        {'input':'4 100 60\n0 0 0\n','expected':'-1\n'},
    ],
}

def _parts_exact(line: str, count: int, pattern=NONNEG) -> list[str]:
    parts=line.split(' ')
    if len(parts)!=count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return parts

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc149_b':
        if len(lines)!=1: raise ValueError('expected one row')
        p=_parts_exact(lines[0],3)
        a,b,k=map(int,p)
        if not (0<=a<=10**12 and 0<=b<=10**12 and 0<=k<=10**12):
            raise ValueError('range')
        return a,b,k
    if pid=='abc150_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None or UPPER.fullmatch(lines[1]) is None:
            raise ValueError('expected N and uppercase S')
        n=int(lines[0]); s=lines[1]
        if not 3<=n<=50 or len(s)!=n:
            raise ValueError('N/S shape')
        return n,s
    if len(lines)!=2:
        raise ValueError('expected two rows')
    p=_parts_exact(lines[0],3)
    n,k,m=map(int,p)
    if not (2<=n<=100 and 1<=k<=100 and 1<=m<=k):
        raise ValueError('N/K/M range')
    q=lines[1].split(' ')
    if len(q)!=n-1 or any(NONNEG.fullmatch(x) is None for x in q):
        raise ValueError('score row shape')
    a=list(map(int,q))
    if any(x>k for x in a): raise ValueError('score range')
    return n,k,m,a

def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or output!=output.strip() or not output:
        return False
    if pid=='abc149_b':
        parts=output.split(' ')
        if len(parts)!=2 or any(NONNEG.fullmatch(x) is None for x in parts): return False
        a,b,k=value
        take=min(a,k); a-=take; k-=take; b-=min(b,k)
        return output==f'{a} {b}'
    if pid=='abc150_b':
        if NONNEG.fullmatch(output) is None: return False
        n,s=value
        return output==str(sum(s[i:i+3]=='ABC' for i in range(n-2)))
    if SIGNED_SMALL.fullmatch(output) is None: return False
    n,k,m,a=value
    need=n*m-sum(a)
    expected=0 if need<=0 else (-1 if need>k else need)
    return output==str(expected)

def _149(a:int,b:int,k:int)->str: return f'{a} {b} {k}\n'
def _150(s:str)->str: return f'{len(s)}\n{s}\n'
def _151(n:int,k:int,m:int,a:list[int])->str: return f'{n} {k} {m}\n{" ".join(map(str,a))}\n'

def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc149_b':
        vals=[
            ('sample1',2,3,3),('sample2',500000000000,500000000000,1000000000000),
            ('all_zero',0,0,0),('k_zero',7,9,0),('a_only_exact',5,8,5),('a_only_partial',10,20,4),
            ('cross_to_b',3,10,7),('eat_all',3,4,7),('k_exceeds_total',3,4,100),('a_zero',0,9,4),
            ('b_zero',9,0,4),('a_zero_k_big',0,9,20),('both_zero_k_max',0,0,10**12),
            ('a_max_k1',10**12,1,1),('b_max_cross',1,10**12,10**12),('large_partial',10**12,10**12,999999999999),
            ('large_cross',999999999999,10**12,10**12),
        ]
        for cat,a,b,k in vals: add(cat,_149(a,b,k))
        add('constraint_max',_149(10**12,10**12,10**12))
    elif pid=='abc150_b':
        vals=[
            ('sample1','ZABCDBABCQ'),('sample2','THREEONEFOURONEFIVE'),('sample3','ABCCABCBABCCABACBCBBABCBCBCBCABCB'),
            ('min_hit','ABC'),('min_miss','ABD'),('all_a','AAAAAA'),('two_hits','ABCABC'),('touching_noise','AABCBC'),
            ('prefix_hit','ABCZZZZ'),('suffix_hit','ZZZZABC'),('middle_hit','ZZABCZZ'),('many_hits','ABCXABCYABC'),
            ('near_miss','ABABCBCA'),('repeated_ab','ABABABABAB'),('len49_none','Z'*49),
            ('len49_many',('ABC'*16)+'Z'),('len50_one','Z'*23+'ABC'+'Z'*24),
        ]
        for cat,s in vals: add(cat,_150(s))
        add('constraint_max',_150(('ABC'*16)+'AB'))
    else:
        vals=[
            ('sample1',5,10,7,[8,10,3,6]),('sample2',4,100,60,[100,100,100]),('sample3',4,100,60,[0,0,0]),
            ('min_exact',2,1,1,[1]),('min_impossible',2,1,1,[0]),('already_met',3,10,3,[9,9]),
            ('need_one',3,10,7,[10,10]),('need_k',3,10,10,[10,10]),('just_impossible',3,10,10,[10,9]),
            ('zeros_low_target',5,100,1,[0,0,0,0]),('mixed',6,20,10,[5,10,15,20,0]),
            ('all_k',10,100,100,[100]*9),('all_zero_mid',10,100,50,[0]*9),
            ('n100_zero_target1',100,100,1,[0]*99),('n100_almost',100,100,99,[100]*98+[0]),
            ('n99_mixed',99,73,37,[37]*98),('k1_many',100,1,1,[1]*99),
        ]
        for cat,n,k,m,a in vals: add(cat,_151(n,k,m,a))
        add('constraint_max',_151(100,100,100,[100]*99))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
