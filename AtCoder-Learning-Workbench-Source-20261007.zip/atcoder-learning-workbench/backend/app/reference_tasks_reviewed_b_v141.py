"""ABC281–283 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re

TASKS = ('abc281_b', 'abc282_b', 'abc283_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
UPPER_DIGIT = re.compile(r'[A-Z0-9]+', re.ASCII)
OX = re.compile(r'[ox]+', re.ASCII)
SANDWICH = re.compile(r'[A-Z][1-9][0-9]{5}[A-Z]', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc281_b': [
        {'input': 'Q142857Z\n', 'expected': 'Yes\n'},
        {'input': 'AB912278C\n', 'expected': 'No\n'},
        {'input': 'X900000\n', 'expected': 'No\n'},
        {'input': 'K012345K\n', 'expected': 'No\n'},
    ],
    'abc282_b': [
        {'input': '5 5\nooooo\noooxx\nxxooo\noxoxo\nxxxxx\n', 'expected': '5\n'},
        {'input': '3 2\nox\nxo\nxx\n', 'expected': '1\n'},
        {'input': '2 4\nxxxx\noxox\n', 'expected': '0\n'},
    ],
    'abc283_b': [
        {
            'input': '3\n1 3 5\n7\n2 2\n2 3\n1 3 0\n2 3\n1 2 8\n2 2\n2 1\n',
            'expected': '3\n5\n0\n8\n1\n',
        },
        {
            'input': '5\n22 2 16 7 30\n10\n1 4 0\n1 5 0\n2 2\n2 3\n2 4\n2 5\n1 4 100\n1 5 100\n2 3\n2 4\n',
            'expected': '2\n16\n0\n0\n16\n100\n',
        },
        {
            'input': '7\n478 369 466 343 541 42 165\n20\n2 1\n1 7 729\n1 6 61\n1 6 838\n1 3 319\n1 4 317\n2 4\n1 1 673\n1 3 176\n1 5 250\n1 1 468\n2 6\n1 7 478\n1 5 595\n2 6\n1 6 599\n1 6 505\n2 3\n2 5\n2 1\n',
            'expected': '478\n317\n838\n838\n176\n595\n468\n',
        },
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints_line(line: str) -> list[int]:
    parts = line.split(' ')
    if not parts or any(INT.fullmatch(x) is None for x in parts) or ' '.join(parts) != line:
        raise ValueError('integer line')
    return [int(x) for x in parts]


def _validate281(raw: str) -> str:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    s = lines[0]
    if not (1 <= len(s) <= 10) or UPPER_DIGIT.fullmatch(s) is None:
        raise ValueError('constraints')
    return s


def _validate282(raw: str) -> tuple[int, int, list[str]]:
    lines = _canonical_lines(raw)
    if not lines:
        raise ValueError('shape')
    head = _ints_line(lines[0])
    if len(head) != 2:
        raise ValueError('header')
    n, m = head
    if not (2 <= n <= 30 and 1 <= m <= 30) or len(lines) != n + 1:
        raise ValueError('constraints')
    rows = lines[1:]
    if any(len(s) != m or OX.fullmatch(s) is None for s in rows):
        raise ValueError('rows')
    return n, m, rows


def _validate283(raw: str) -> tuple[int, tuple[int, ...], tuple[tuple[int, ...], ...]]:
    lines = _canonical_lines(raw)
    if len(lines) < 4:
        raise ValueError('shape')
    first = _ints_line(lines[0])
    if len(first) != 1:
        raise ValueError('n')
    n = first[0]
    if not 1 <= n <= 100_000:
        raise ValueError('n constraints')
    a = _ints_line(lines[1])
    if len(a) != n or any(not 0 <= x <= 10**9 for x in a):
        raise ValueError('array')
    qline = _ints_line(lines[2])
    if len(qline) != 1:
        raise ValueError('q')
    q = qline[0]
    if not 1 <= q <= 100_000 or len(lines) != q + 3:
        raise ValueError('q constraints')
    queries: list[tuple[int, ...]] = []
    has_read = False
    for line in lines[3:]:
        vals = _ints_line(line)
        if len(vals) == 3 and vals[0] == 1:
            _, k, x = vals
            if not 1 <= k <= n or not 0 <= x <= 10**9:
                raise ValueError('update')
        elif len(vals) == 2 and vals[0] == 2:
            _, k = vals
            if not 1 <= k <= n:
                raise ValueError('read')
            has_read = True
        else:
            raise ValueError('query shape')
        queries.append(tuple(vals))
    if not has_read:
        raise ValueError('must contain read')
    return n, tuple(a), tuple(queries)


def validate(pid: str, raw: str):
    if pid == 'abc281_b':
        return _validate281(raw)
    if pid == 'abc282_b':
        return _validate282(raw)
    if pid == 'abc283_b':
        return _validate283(raw)
    raise ValueError('unknown task')


def _oracle281(s: str) -> str:
    return 'Yes' if SANDWICH.fullmatch(s) is not None else 'No'


def _oracle282(n: int, m: int, rows: list[str]) -> int:
    full = (1 << m) - 1
    masks = []
    for s in rows:
        mask = 0
        for j, ch in enumerate(s):
            if ch == 'o':
                mask |= 1 << j
        masks.append(mask)
    return sum((masks[i] | masks[j]) == full for i in range(n) for j in range(i + 1, n))


def _oracle283(n: int, original: tuple[int, ...], queries: tuple[tuple[int, ...], ...]) -> list[int]:
    updates: dict[int, int] = {}
    out: list[int] = []
    for query in queries:
        if query[0] == 1:
            _, k, x = query
            updates[k] = x
        else:
            _, k = query
            out.append(updates[k] if k in updates else original[k - 1])
    return out


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc281_b':
        return output in ('Yes', 'No') and output == _oracle281(value)
    if pid == 'abc282_b':
        if INT.fullmatch(output) is None:
            return False
        return int(output) == _oracle282(*value)

    lines = output.split('\n')
    if any(INT.fullmatch(line) is None for line in lines):
        return False
    actual = [int(line) for line in lines]
    return actual == _oracle283(*value)


def _query_input(a: list[int], queries: list[tuple[int, ...]]) -> str:
    lines = [str(len(a)), ' '.join(map(str, a)), str(len(queries))]
    lines += [' '.join(map(str, q)) for q in queries]
    return '\n'.join(lines) + '\n'


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc281_b':
        custom = [
            ('valid_lower', 'A100000Z\n'),
            ('valid_upper', 'Z999999A\n'),
            ('valid_same_letters', 'A100001A\n'),
            ('leading_zero', 'A000000Z\n'),
            ('too_short_digits', 'A99999Z\n'),
            ('two_leading_letters', 'AA000000Z\n'),
            ('two_trailing_letters', 'A100000ZZ\n'),
            ('starts_digit', '1100000A\n'),
            ('ends_digit', 'A1234567\n'),
            ('letter_inside_number', 'A12B456Z\n'),
            ('seven_digits', 'A9999999Z\n'),
            ('all_digits_eight', '12345678\n'),
            ('valid_middle', 'Q654321Z\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', 'ZZZZZZZZZZ\n')

    elif pid == 'abc282_b':
        custom = [
            ('single_problem_cover', '2 1\no\nx\n'),
            ('single_problem_none', '2 1\nx\nx\n'),
            ('single_problem_both', '2 1\no\no\n'),
            ('two_complementary', '2 2\nox\nxo\n'),
            ('one_all', '2 2\noo\nxx\n'),
            ('three_one_solver', '3 1\nx\nx\no\n'),
            ('three_no_pair', '3 3\noxx\nxox\nxxo\n'),
            ('three_all_solver', '3 3\nooo\nxxx\nxxx\n'),
            ('four_complements', '4 4\nooxx\nxxoo\noxox\nxoxo\n'),
            ('duplicate_capabilities', '4 3\noox\noox\nxxo\nxxx\n'),
            ('all_can_all', '5 5\nooooo\nooooo\nooooo\nooooo\nooooo\n'),
            ('all_can_none', '5 5\nxxxxx\nxxxxx\nxxxxx\nxxxxx\nxxxxx\n'),
            ('mixed_six', '6 6\nooxxxx\nxxooxx\nxxxxoo\noxoxox\nxoxoxo\noooooo\n'),
            ('wide_two', '2 30\n' + 'o' * 15 + 'x' * 15 + '\n' + 'x' * 15 + 'o' * 15 + '\n'),
        ]
        for category, raw in custom:
            add(category, raw)
        rows = [''.join('o' if ((i * 7 + j * 11) % 5) else 'x' for j in range(30)) for i in range(30)]
        add('constraint_max', '30 30\n' + '\n'.join(rows) + '\n')

    else:
        custom = [
            ('single_read_zero', _query_input([0], [(2, 1)])),
            ('single_read_max', _query_input([10**9], [(2, 1)])),
            ('single_update_read', _query_input([5], [(1, 1, 7), (2, 1)])),
            ('single_repeat_update', _query_input([5], [(1, 1, 7), (1, 1, 9), (2, 1)])),
            ('read_before_after', _query_input([1, 2], [(2, 2), (1, 2, 8), (2, 2)])),
            ('edge_indices', _query_input([10, 20, 30, 40], [(2, 1), (2, 4), (1, 1, 0), (1, 4, 10**9), (2, 1), (2, 4)])),
            ('zero_update', _query_input([9, 8, 7], [(1, 2, 0), (2, 2), (2, 1)])),
            ('untouched_after_other_update', _query_input([3, 4, 5], [(1, 1, 99), (2, 3)])),
            ('all_reads', _query_input([1, 2, 3, 4], [(2, 1), (2, 2), (2, 3), (2, 4)])),
            ('all_updates_then_read', _query_input([0, 0, 0], [(1, 1, 10), (1, 2, 20), (1, 3, 30), (2, 1), (2, 2), (2, 3)])),
            ('same_value_update', _query_input([42, 24], [(1, 1, 42), (2, 1), (2, 2)])),
            ('alternating_two', _query_input([5, 6], [(1, 1, 7), (2, 1), (1, 2, 8), (2, 2), (1, 1, 9), (2, 1)])),
            ('ten_positions', _query_input(list(range(10)), [(1, 10, 10**9), (2, 10), (2, 1), (1, 1, 10**9), (2, 1)])),
            ('many_small_queries', _query_input([1, 1, 1, 1, 1], [(1, 3, i) if i % 2 else (2, 3) for i in range(1, 21)] + [(2, 5)])),
        ]
        for category, raw in custom:
            add(category, raw)
        n = 100_000
        a = [0] * n
        queries = [(1, (i % n) + 1, i) for i in range(99_999)] + [(2, n)]
        add('constraint_max', _query_input(a, queries))

    if len(out) != 18 or len({row['input'] for row in out}) != 18 or out[-1]['category'] != 'constraint_max':
        raise AssertionError(f'{pid}: expected 18 distinct cases ending in constraint_max, got {len(out)}')
    return out
