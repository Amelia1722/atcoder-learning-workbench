"""ABC021–025 A: manually reviewed public statements, not authenticated HTML.

ABC021 A is multi-answer. A canonical example MUST NOT be used for exact-match
judging; only validate_constructive_output can decide its correctness.
"""
from __future__ import annotations
import random
import re
from itertools import product

SPECS = {
    'abc021_a': ('足し算', '1 <= N <= 10; any valid combination of 1,2,4,8', '5\n', '3\n1\n2\n2\n'),
    'abc022_a': ('Best Body', '2 <= N <= 1000; 1 <= S <= T <= 100000; 1 <= W <= 100000; -100000 <= Ai <= 100000; all daily weights > 0', '5 60 70\n50\n10\n10\n10\n10\n', '2\n'),
    'abc023_a': ('加算王', '10 <= X <= 99', '23\n', '5\n'),
    'abc024_a': ('動物園', '0 <= C <= A <= B <= 1000; 0 <= K,S,T <= 100', '100 200 50 20\n40 10\n', '3500\n'),
    'abc025_a': ('25個の文字列', 'S is 5 strictly increasing distinct lowercase ASCII characters; 1 <= N <= 25', 'abcde\n8\n', 'bc\n'),
}
BATCH21 = {pid: {'title': title, 'constraints': limits, 'sample_input': inp,
                 'sample_output': out, 'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                 'output_validation': 'semantic_required_not_integrated' if pid == 'abc021_a' else 'exact'}
           for pid, (title,limits,inp,out) in SPECS.items()}
_INT = re.compile(r'(?:0|[1-9][0-9]*)\Z', re.ASCII)
_SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)\Z', re.ASCII)
_LOWER = re.compile(r'[a-z]{5}\Z', re.ASCII)


def validate(pid: str, text: str):
    if pid not in BATCH21 or not isinstance(text,str) or not text.endswith('\n') or '\r' in text or len(text)>16000:
        raise ValueError('unknown task or invalid input bytes')
    lines=text[:-1].split('\n')
    if pid == 'abc025_a':
        if len(lines)!=2 or not _LOWER.fullmatch(lines[0]) or not all(lines[0][i]<lines[0][i+1] for i in range(4)) or not _INT.fullmatch(lines[1]):
            raise ValueError('invalid S or N')
        n=int(lines[1])
        if not 1<=n<=25: raise ValueError('N out of bounds')
        return lines[0], n
    lengths={'abc021_a':(1,),'abc022_a':(3,1),'abc023_a':(1,), 'abc024_a':(4,2)}[pid]
    if pid=='abc022_a':
        if len(lines)<3: raise ValueError('missing weight changes')
        first=lines[0].split(' ')
        if len(first)!=3 or any(not _INT.fullmatch(x) for x in first): raise ValueError('invalid header')
        n,s,t=map(int,first)
        if len(lines)!=n+1 or not 2<=n<=1000 or not 1<=s<=t<=100000: raise ValueError('invalid N/S/T')
        if any(not _SIGNED.fullmatch(line) for line in lines[1:]): raise ValueError('invalid daily weight')
        w=int(lines[1]); changes=tuple(int(x) for x in lines[2:])
        if not 1<=w<=100000 or any(abs(d)>100000 for d in changes): raise ValueError('weight bounds')
        total=w
        for d in changes:
            total+=d
            if total<=0: raise ValueError('nonpositive daily weight')
        return n,s,t,w,changes
    if len(lines)!=len(lengths): raise ValueError('invalid line count')
    groups=[line.split(' ') for line in lines]
    if any(len(group)!=lengths[i] or any(not _INT.fullmatch(x) for x in group) for i,group in enumerate(groups)):
        raise ValueError('noncanonical fields')
    vals=tuple(int(x) for group in groups for x in group)
    if pid=='abc021_a' and not 1<=vals[0]<=10: raise ValueError('N out of bounds')
    if pid=='abc023_a' and not 10<=vals[0]<=99: raise ValueError('X out of bounds')
    if pid=='abc024_a':
        a,b,c,k,s,t=vals
        if not (0<=c<=a<=b<=1000 and 0<=k<=100 and 0<=s<=100 and 0<=t<=100):
            raise ValueError('zoo bounds')
    return vals


def validate_constructive_output(data: str, output: str) -> bool:
    """Strict semantic checker; valid alternative answer must never become WA."""
    try:
        n=validate('abc021_a',data)[0]
        if not isinstance(output,str) or not output.endswith('\n') or '\r' in output or len(output)>100:
            return False
        rows=output[:-1].split('\n')
        if not rows or not _INT.fullmatch(rows[0]): return False
        count=int(rows[0])
        if count<1 or count>n or len(rows)!=count+1: return False
        if any(not _INT.fullmatch(x) for x in rows[1:]): return False
        values=[int(x) for x in rows[1:]]
        return all(x in (1,2,4,8) for x in values) and sum(values)==n
    except (ValueError,TypeError,IndexError):
        return False


FIXTURES = {
 'abc021_a': [('constraint_min','1'),('typical','5'),('boundary','8'),('constraint_max','10')],
 'abc022_a': [
    ('constraint_min','2 1 1\n1\n0'),('typical','5 60 70\n50\n10\n10\n10\n10'),
    ('boundary','3 10 10\n9\n1\n-1'),('boundary','2 1 100000\n100000\n-99999'),
    ('constraint_max','1000 1 100000\n100000\n'+'\n'.join(['0']*999))],
 'abc023_a': [('constraint_min','10'),('boundary','90'),('typical','23'),('boundary','70'),('constraint_max','99')],
 'abc024_a': [('constraint_min','0 0 0 0\n0 0'),('boundary','400 1000 400 21\n10 10'),
              ('boundary','400 1000 400 20\n10 10'),('typical','100 200 50 20\n40 10'),
              ('constraint_max','1000 1000 1000 100\n100 100')],
 'abc025_a': [('constraint_min','abcde\n1'),('typical','abcde\n8'),('boundary','aeiou\n22'),
              ('boundary','vwxyz\n25'),('constraint_max','vwxyz\n25')],
}


def generate(pid: str, count: int=13, seed: int=42, include_large: bool=True) -> list[dict[str,str]]:
    if pid not in BATCH21 or not 4<=count<=80: raise ValueError('invalid task or count')
    rng=random.Random(f'batch21:{pid}:{seed}')
    cases=[];seen=set()
    def add(cat,raw):
        raw+='\n';validate(pid,raw)
        if raw not in seen:
            seen.add(raw);cases.append({'category':cat,'input':raw})
    for cat,raw in FIXTURES[pid]:
        if cat!='constraint_max': add(cat,raw)
    tries=0
    while len(cases)<count and tries<3000:
        tries+=1
        if pid=='abc021_a': raw=str(rng.randint(1,10))
        elif pid=='abc023_a': raw=str(rng.randint(10,99))
        elif pid=='abc025_a': raw=''.join(sorted(rng.sample('abcdefghijklmnopqrstuvwxyz',5)))+'\n'+str(rng.randint(1,25))
        elif pid=='abc024_a':
            b=rng.randint(0,1000);a=rng.randint(0,b);c=rng.randint(0,a)
            raw=f'{a} {b} {c} {rng.randint(0,100)}\n{rng.randint(0,100)} {rng.randint(0,100)}'
        else:
            n=rng.randint(2,1000);s=rng.randint(1,100000);t=rng.randint(s,100000)
            w=rng.randint(1,100000);changes=[]
            for _ in range(n-1):
                nxt=rng.randint(max(1,w-100000),min(100000,w+100000))
                changes.append(nxt-w);w=nxt
            raw=f'{n} {s} {t}\n{w-sum(changes)}\n'+'\n'.join(map(str,changes))
        add('random',raw)
    cases=cases[:count]
    if include_large:
        maximum=next(raw+'\n' for cat,raw in FIXTURES[pid] if cat=='constraint_max')
        cases=[c for c in cases if c['input']!=maximum][:count-1]
        cases.append({'category':'constraint_max','input':maximum})
    return cases


def independent_check(pid: str, data: str, expected: str) -> bool:
    vals=validate(pid,data)
    if pid=='abc021_a': return validate_constructive_output(data,expected+'\n')
    if pid=='abc022_a':
        _,s,t,w,changes=vals
        weights=[w]
        for d in changes: weights.append(weights[-1]+d)
        answer=str(len([v for v in weights if s<=v<=t]))
    elif pid=='abc023_a': answer=str(sum(map(int,str(vals[0]))))
    elif pid=='abc024_a':
        a,b,c,k,s,t=vals
        answer=str(sum([a]*(s)+[b]*(t))-sum([c]*(s+t) if s+t>=k else []))
    else:
        letters,n=vals
        answer=sorted(''.join(pair) for pair in product(letters, repeat=2))[n-1]
    return expected==answer
