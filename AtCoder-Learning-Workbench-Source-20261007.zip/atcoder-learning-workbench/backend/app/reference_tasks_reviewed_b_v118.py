"""ABC212–214 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc212_b', 'abc213_b', 'abc214_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
PIN = re.compile(r'[0-9]{4}', re.ASCII)
PUBLISHED_SAMPLES = {
    'abc212_b': [
        {'input': '7777\n', 'expected': 'Weak\n'},
        {'input': '0112\n', 'expected': 'Strong\n'},
        {'input': '9012\n', 'expected': 'Weak\n'},
    ],
    'abc213_b': [
        {'input': '6\n1 123 12345 12 1234 123456\n', 'expected': '3\n'},
        {'input': '5\n3 1 4 15 9\n', 'expected': '5\n'},
    ],
    'abc214_b': [
        {'input': '1 0\n', 'expected': '4\n'},
        {'input': '2 5\n', 'expected': '10\n'},
        {'input': '10 10\n', 'expected': '213\n'},
        {'input': '30 100\n', 'expected': '2471\n'},
    ],
}

def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    return raw[:-1].split('\n')

def _validate212(raw: str) -> str:
    lines = _canonical_lines(raw)
    if len(lines) != 1 or PIN.fullmatch(lines[0]) is None:
        raise ValueError('pin')
    return lines[0]

def _validate213(raw: str) -> tuple[int, tuple[int, ...]]:
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape/N')
    n = int(lines[0])
    if not 2 <= n <= 200000:
        raise ValueError('N range')
    parts = lines[1].split(' ')
    if len(parts) != n or any(POS.fullmatch(x) is None for x in parts):
        raise ValueError('score row')
    a = tuple(map(int, parts))
    if any(x > 10**9 for x in a) or len(set(a)) != n:
        raise ValueError('score constraints')
    return n, a

def _validate214(raw: str) -> tuple[int, int]:
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    parts = lines[0].split(' ')
    if len(parts) != 2 or any(NONNEG.fullmatch(x) is None for x in parts):
        raise ValueError('syntax')
    s, t = map(int, parts)
    if not (0 <= s <= 100 and 0 <= t <= 10000):
        raise ValueError('range')
    return s, t

def validate(pid: str, raw: str):
    if pid == 'abc212_b':
        return _validate212(raw)
    if pid == 'abc213_b':
        return _validate213(raw)
    if pid == 'abc214_b':
        return _validate214(raw)
    raise ValueError('unknown task')

def _ans212(pin: str) -> str:
    repeated = len(set(pin)) == 1
    sequential = pin in {''.join(str((start + i) % 10) for i in range(4)) for start in range(10)}
    return 'Weak' if repeated or sequential else 'Strong'

def _ans213(v: tuple[int, tuple[int, ...]]) -> int:
    _, a = v
    largest = max(a)
    second = max(x for x in a if x != largest)
    return a.index(second) + 1

def _ans214(v: tuple[int, int]) -> int:
    s, t = v
    total = 0
    for a in range(s + 1):
        for b in range(s - a + 1):
            sum_limit = s - a - b
            if a == 0 or b == 0:
                cmax = sum_limit
            else:
                cmax = min(sum_limit, t // (a * b))
            total += cmax + 1
    return total

def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or '\n' in output or output != output.strip():
        return False
    if pid == 'abc212_b':
        return output in {'Weak', 'Strong'} and output == _ans212(value)
    if POS.fullmatch(output) is None:
        return False
    if pid == 'abc213_b':
        return int(output) == _ans213(value)
    if pid == 'abc214_b':
        return int(output) == _ans214(value)
    return False

def _case213(a: list[int]) -> str:
    return f'{len(a)}\n' + ' '.join(map(str, a)) + '\n'

def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})
    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])
    if pid == 'abc212_b':
        vals = [
            ('all_zero', '0000\n'), ('all_one', '1111\n'), ('seq_zero', '0123\n'), ('seq_one', '1234\n'),
            ('seq_wrap1', '7890\n'), ('seq_wrap2', '8901\n'), ('descending', '9876\n'), ('near_repeat', '0111\n'),
            ('near_seq1', '0012\n'), ('near_seq2', '9013\n'), ('alternating', '8080\n'), ('odds', '1357\n'),
            ('leading_zero_strong', '0999\n'), ('high_strong', '9987\n'),
        ]
        for c, raw in vals:
            add(c, raw)
        add('constraint_max', '9999\n')
    elif pid == 'abc213_b':
        cases = [
            ('n2_up', [1, 2]), ('n2_down', [2, 1]), ('second_first', [9, 10, 1]), ('second_middle', [10, 9, 1]),
            ('second_last', [10, 1, 9]), ('score_bounds', [1, 10**9, 10**9 - 1]), ('four_shuffled', [4, 1, 3, 2]),
            ('five_shuffled', [20, 50, 10, 40, 30]), ('n10_ascending', list(range(1, 11))), ('n10_descending', list(range(10, 0, -1))),
            ('n20_zigzag', list(range(1, 20, 2)) + list(range(2, 21, 2))),
            ('n50_second_first', [999999999, 1000000000] + list(range(1, 49))),
            ('n100_second_last', list(range(1, 99)) + [1000000000, 999999999]),
            ('n1000_ascending', list(range(1, 1001))), ('n5000_descending', list(range(5000, 0, -1))),
        ]
        for c, a in cases:
            add(c, _case213(a))
        a = list(range(1, 199999)) + [999999999, 1000000000]
        add('constraint_max', _case213(a))
    else:
        vals = [
            ('zero_zero', '0 0\n'), ('zero_tmax', '0 10000\n'), ('one_one', '1 1\n'), ('two_zero', '2 0\n'),
            ('three_zero', '3 0\n'), ('five_one', '5 1\n'), ('ten_zero', '10 0\n'), ('ten_tmax', '10 10000\n'),
            ('twenty_ten', '20 10\n'), ('fifty_hundred', '50 100\n'), ('smax_zero', '100 0\n'),
            ('smax_one', '100 1\n'), ('near_tmax', '100 9999\n'),
        ]
        for c, raw in vals:
            add(c, raw)
        add('constraint_max', '100 10000\n')
    if len(out) != 18 or len(seen) != 18 or out[-1]['category'] != 'constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
