"""ABC113–116 A/B: manually curated against official AtCoder task statements.

All input generators enforce task-specific conditions; independent checks use
an implementation distinct from the reference-solution subprocesses.
"""
from __future__ import annotations

import math
import random
import re

SAMPLES = {
 'abc113_a': ('81 58\n', '110', '1<=X,Y<=100; Y even'),
 'abc113_b': ('2\n12 5\n1000 2000\n', '1', '1<=N<=1000; 0<=T<=50; -60<=A<=T; 0<=Hi<=100000; answer unique'),
 'abc114_a': ('5\n', 'YES', '1<=X<=9'),
 'abc114_b': ('1234567876\n', '34', '4<=len(S)<=10; each character 1..9'),
 'abc115_a': ('25\n', 'Christmas', '22<=D<=25'),
 'abc115_b': ('3\n4980\n7980\n6980\n', '15950', '2<=N<=10; 100<=pi<=10000; pi even'),
 'abc116_a': ('3 4 5\n', '6', '1<=AB,BC,CA<=100; right triangle at B; integer area'),
 'abc116_b': ('8\n', '5', '1<=s<=100; all sequence values and first repetition index <=1000000'),
}
BATCH11 = {pid: {'sample_input': inp, 'sample_output': out,
                    'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                    'constraints': cons} for pid, (inp, out, cons) in SAMPLES.items()}


def validate(pid: str, data: str):
    if pid not in BATCH11: raise ValueError('unknown task')
    tokens = data.split()
    if pid == 'abc114_b':
        if len(tokens)!=1 or re.fullmatch(r'[1-9]{4,10}', tokens[0]) is None:
            raise ValueError('S must have 4..10 digits 1..9')
        return tokens[0]
    if not tokens or any(re.fullmatch(r'-?\d+', x) is None for x in tokens):
        raise ValueError('invalid integer tokens')
    z = list(map(int, tokens))
    if pid == 'abc113_a':
        if len(z)!=2 or not all(1<=v<=100 for v in z) or z[1]%2:
            raise ValueError('X Y bounds and Y even')
        return tuple(z)
    if pid == 'abc113_b':
        if len(z)<4: raise ValueError('N T A H required')
        n,t,a=z[:3]; heights=z[3:]
        if not (1<=n<=1000 and 0<=t<=50 and -60<=a<=t and len(heights)==n and
                all(0<=h<=100000 for h in heights)):
            raise ValueError('Palace bounds/count')
        # All computations use exact integer scaling by 1000.
        distances=[abs(1000*(t-a)-6*h) for h in heights]
        minimum=min(distances)
        if distances.count(minimum)!=1: raise ValueError('Palace best index must be unique')
        return n,t,a,heights
    if pid == 'abc114_a':
        if len(z)!=1 or not 1<=z[0]<=9: raise ValueError('X out of bounds')
        return z[0]
    if pid == 'abc115_a':
        if len(z)!=1 or not 22<=z[0]<=25: raise ValueError('D out of bounds')
        return z[0]
    if pid == 'abc115_b':
        if len(z)<3 or not 2<=z[0]<=10 or len(z)!=z[0]+1 or any(not 100<=v<=10000 or v%2 for v in z[1:]):
            raise ValueError('N/p bounds or parity')
        return z[0],z[1:]
    if pid == 'abc116_a':
        if len(z)!=3 or any(not 1<=v<=100 for v in z):
            raise ValueError('three positive sides <=100 required')
        ab,bc,ca=z
        if ab*ab+bc*bc!=ca*ca or (ab*bc)%2:
            raise ValueError('right angle must be at B and area integral')
        return ab,bc,ca
    if len(z)!=1 or not 1<=z[0]<=100: raise ValueError('s out of bounds')
    return z[0]


def generate(pid: str, count: int, seed: int, include_large: bool):
    if pid not in BATCH11 or not 1<=count<=80: raise ValueError('id/count invalid')
    rnd=random.Random(seed);cases=[]; seen=set()
    def add(category, data):
        validate(pid, data)
        if data not in seen:
            seen.add(data);cases.append({'category':category,'input':data})
    def nums(cat,*args): add(cat,' '.join(map(str,args))+'\n')
    def palace(cat,t,a,h): add(cat,f'{len(h)}\n{t} {a}\n'+' '.join(map(str,h))+'\n')
    def prices(cat,values): add(cat,f'{len(values)}\n'+'\n'.join(map(str,values))+'\n')
    if pid=='abc113_a':
        for x,y in ((1,2),(100,100),(1,100),(100,2),(81,58),(4,54),(99,98),(42,52),(7,10),(2,2),(100,98),(49,50)):
            nums('boundary',x,y)
        while len(cases)<count: nums('random',rnd.randint(1,100),2*rnd.randint(1,50))
        large=('100 100\n')
    elif pid=='abc113_b':
        palace('constraint_min',0,0,[0]);palace('sample',12,5,[1000,2000])
        palace('negative_target',21,-11,[81234,94124,52141]);palace('exact',0,0,[100000,0,99999])
        palace('elevation_max',50,-60,[100000,0,50000]);palace('one_site',50,-60,[100000])
        palace('temperature_min',0,-60,[1,99999]);palace('temperature_max',50,50,[0,100000])
        while len(cases)<count:
            n=rnd.randint(1,36);t=rnd.randint(0,50);a=rnd.randint(-60,t)
            h=rnd.sample(range(100001),n) if n>1 else [rnd.randint(0,100000)]
            try: palace('random',t,a,h)
            except ValueError: continue  # exclude tied optimum
        # Both N and height attain official maximum; optimum is unique.
        large='1000\n50 50\n'+' '.join(['0']+['100000']*999)+'\n'
    elif pid=='abc114_a':
        for x in (1,2,3,4,5,6,7,8):nums('exhaustive',x)
        large='9\n'
    elif pid=='abc114_b':
        for s in ('1111','7537','35753','1234567876','1111111111','9999999999','7537537537','1234','9876','7531','111753999'):
            add('boundary',s+'\n')
        while len(cases)<count:
            n=rnd.randint(4,10)
            add('random',''.join(str(rnd.randint(1,9)) for _ in range(n))+'\n')
        large='9876543219\n'
    elif pid=='abc115_a':
        for x in (22,23,24):nums('exhaustive',x)
        large='25\n'
    elif pid=='abc115_b':
        for values in ([100,100],[10000,10000],[4980,7980,6980],[4320]*4,[100]*10,[10000]*10,
                       [100]*9+[10000],[10000]+[100]*9,[100,102],[9998,10000],list(range(100,120,2))):
            prices('boundary',values)
        while len(cases)<count:
            prices('random',[2*rnd.randint(50,5000) for _ in range(rnd.randint(2,10))])
        large='10\n'+'\n'.join(['10000']*10)+'\n'
    elif pid=='abc116_a':
        triples=[(3,4,5),(5,12,13),(45,28,53),(60,80,100),(4,3,5),(12,5,13),
                 (28,45,53),(6,8,10),(9,12,15),(8,15,17),(7,24,25),(20,21,29),(33,56,65)]
        for triple in triples:nums('boundary',*triple)
        while len(cases)<count:
            a,b,c=rnd.choice(triples);k=rnd.randint(1,100//c)
            nums('random',a*k,b*k,c*k)
        large='60 80 100\n'
    else:
        for s in (1,2,3,4,5,6,7,8,9,10,27,54,63,73,97,99):nums('boundary',s)
        while len(cases)<count:nums('random',rnd.randint(1,100))
        large='100\n'
    # The full-scale case must ALWAYS be last and explicitly validated.
    if include_large:
        validate(pid,large)
        cases=[c for c in cases if c['input']!=large][:count]
        cases.append({'category':'constraint_max','input':large})
    else:
        cases=cases[:count]
    return cases


def independent_check(pid: str, data: str, expected: str) -> bool:
    values=validate(pid,data)
    if pid=='abc113_a':
        x,y=values; answer=(2*x+y)//2
    elif pid=='abc113_b':
        n,t,a,h=values
        # Independent minimum search via pair sorting, using exact scaled values.
        order=sorted((abs((t-a)*500-3*height),idx) for idx,height in enumerate(h,1))
        answer=order[0][1]
    elif pid=='abc114_a':
        answer='YES' if values==3 or values==5 or values==7 else 'NO'
    elif pid=='abc114_b':
        s=values
        # Three-digit rolling arithmetic, rather than slicing to integers.
        window=100*int(s[0])+10*int(s[1])+int(s[2]); best=abs(window-753)
        for c in s[3:]:
            window=(window%100)*10+int(c)
            best=min(best,abs(window-753))
        answer=best
    elif pid=='abc115_a':
        answer='Christmas'+' Eve'*(25-values)
    elif pid=='abc115_b':
        _,p=values
        p=sorted(p)
        answer=sum(p[:-1])+p[-1]//2
    elif pid=='abc116_a':
        ab,bc,_=values;answer=ab*bc//2
    else:
        s=values
        # Floyd's cycle detection independently derives the first repeat index.
        def f(v): return v//2 if v%2==0 else 3*v+1
        tortoise=f(s);hare=f(f(s))
        for _ in range(1_000_001):
            if tortoise==hare: break
            tortoise=f(tortoise);hare=f(f(hare))
        else: return False
        mu=0;tortoise=s
        while tortoise!=hare:
            tortoise=f(tortoise);hare=f(hare);mu+=1
        lam=1;hare=f(tortoise)
        while tortoise!=hare:
            hare=f(hare);lam+=1
        answer=mu+lam+1
    return expected.strip()==str(answer)
