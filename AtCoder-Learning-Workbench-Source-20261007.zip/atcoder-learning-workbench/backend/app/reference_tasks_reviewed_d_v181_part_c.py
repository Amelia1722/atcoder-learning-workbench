"""Private shared ABC/ARC canonical D tasks with semantic animal/average outputs."""
from __future__ import annotations
from decimal import Decimal,localcontext
from fractions import Fraction
from math import gcd
from typing import cast
import random,re
TASKS=('abc054_d','arc069_b','arc070_b','abc057_d','arc071_b','arc072_b')
CONTESTS=dict(zip(TASKS,('abc054','abc055','abc056','abc057','abc058','abc059')))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'arc069_b':'semantic','abc057_d':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
MOD=1000000007
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc054_d':
        n,ma,mb=ints(rows[0],3);require(1<=n<=40 and 1<=ma<=10 and 1<=mb<=10 and gcd(ma,mb)==1 and len(rows)==n+1,'shape/ratio');a=tuple(ints(row,3) for row in rows[1:]);require(all(1<=x<=10 and 1<=y<=10 and 1<=c<=100 for x,y,c in a),'ingredients');return ma,mb,a
    if pid=='arc069_b':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(3<=n<=100000 and len(rows[1])==n and set(rows[1])<={'o','x'},'statements');return (rows[1],)
    if pid=='arc070_b':
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=5000 and 1<=k<=5000 and all(1<=v<=10**9 for v in a),'cards');return k,a
    if pid=='abc057_d':
        require(len(rows)==2,'shape');n,a,b=ints(rows[0],3);v=ints(rows[1],n);require(1<=a<=b<=n<=50 and all(1<=x<=10**15 for x in v),'items');return a,b,v
    if pid=='arc071_b':
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);x,y=ints(rows[1],n),ints(rows[2],m);require(2<=n<=100000 and 2<=m<=100000 and all(-10**9<=v<=10**9 for a in (x,y) for v in a) and all(l<r for a in (x,y) for l,r in zip(a,a[1:])),'lines');return x,y
    require(len(rows)==1,'shape');x,y=ints(rows[0],2);require(0<=x<=10**18 and 0<=y<=10**18,'piles');return x,y

def animal_solution(s:str)->str|None:
    n=len(s);mask=[1,2];constant=[0,0]
    for j in range(1,n-1):mask.append(mask[-2]^mask[-1]);constant.append(constant[-2]^constant[-1]^(s[j]=='x'))
    equations=((mask[-1]^mask[0]^mask[1],constant[-1]^constant[0]^constant[1]^(s[0]=='x')),(mask[-2]^mask[-1]^mask[0],constant[-2]^constant[-1]^constant[0]^(s[-1]=='x')))
    for variables in range(4):
        if all((m&variables).bit_count()%2==rhs for m,rhs in equations):return ''.join('W' if ((m&variables).bit_count()%2)^c else 'S' for m,c in zip(mask,constant))
    return None

def average_exact(a:int,b:int,v:tuple[int,...])->tuple[Fraction,int]:
    best=[-1]*(len(v)+1);count=[0]*(len(v)+1);best[0]=0;count[0]=1;done=0
    for value in v:
        done+=1
        for j in range(done,0,-1):
            candidate=best[j-1]+value
            if best[j-1]<0:continue
            if candidate>best[j]:best[j]=candidate;count[j]=count[j-1]
            elif candidate==best[j]:count[j]+=count[j-1]
    maximum=max(Fraction(best[j],j) for j in range(a,b+1));return maximum,sum(count[j] for j in range(a,b+1) if Fraction(best[j],j)==maximum)

def window_or(bits:int,width:int)->int:
    result=shift=0;length=1
    while width:
        if width&1:result|=bits>>shift;shift+=length
        width//=2;bits|=bits>>length;length*=2
    return result

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc054_d':
        ma,mb,a=cast(tuple[int,int,tuple[tuple[int,int,int],...]],data);dp:dict[int,int]={}
        for x,y,c in a:
            balance=x*mb-y*ma;new=dict(dp);new[balance]=min(new.get(balance,10**9),c)
            for old,cost in dp.items():new[old+balance]=min(new.get(old+balance,10**9),cost+c)
            dp=new
        return str(dp.get(0,-1))
    if pid=='arc069_b':return animal_solution(cast(str,data[0])) or '-1'
    if pid=='arc070_b':
        k,a=cast(tuple[int,tuple[int,...]],data);n=len(a);limit=(1<<k)-1;prefix=[1];suffix=[1]*(n+1)
        for v in a:prefix.append((prefix[-1]|prefix[-1]<<v)&limit if v<k else prefix[-1])
        for j in range(n-1,-1,-1):v=a[j];suffix[j]=(suffix[j+1]|suffix[j+1]<<v)&limit if v<k else suffix[j+1]
        unnecessary=0
        for j,v in enumerate(a):
            if v>=k:continue
            reverse=int(f'{suffix[j+1]:0{k}b}'[::-1],2);eligible=window_or(reverse,v);unnecessary+=not bool(prefix[j]&eligible)
        return str(unnecessary)
    if pid=='abc057_d':
        a,b,v=cast(tuple[int,int,tuple[int,...]],data);mean,count=average_exact(a,b,v)
        with localcontext() as context:context.prec=80;return str(Decimal(mean.numerator)/Decimal(mean.denominator))+'\n'+str(count)
    if pid=='arc071_b':
        x,y=cast(tuple[tuple[int,...],tuple[int,...]],data)
        def total(a:tuple[int,...])->int:return sum((r-l)*(j+1)*(len(a)-j-1) for j,(l,r) in enumerate(zip(a,a[1:])))%MOD
        return str(total(x)*total(y)%MOD)
    x,y=cast(tuple[int,int],data)
    for source,target in ((x,y),(y,x)):
        for difference in (-1,0,1):
            delta=source-target-difference
            if delta%3==0 and 1<=delta//3<=source//2:return 'Alice'
    return 'Brown'

def decimal_token(token:str)->Fraction|None:
    if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return None
    exponent=re.search(r'[eE]([+-]?[0-9]+)$',token)
    if exponent and abs(int(exponent[1]))>1000:return None
    return Fraction(token)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='arc069_b':
            s=cast(str,validate(pid,raw)[0]);token=actual.removesuffix('\n')
            if token=='-1':return animal_solution(s) is None
            if len(token)!=len(s) or set(token)-{'S','W'}:return False
            return all(((token[j-1]!=token[(j+1)%len(s)])^(token[j]=='W'))==(s[j]=='x') for j in range(len(s)))
        if pid=='abc057_d':
            a,b,v=cast(tuple[int,int,tuple[int,...]],validate(pid,raw));rows=actual.removesuffix('\n').split('\n')
            if len(rows)!=2:return False
            value=decimal_token(rows[0]);mean,count=average_exact(a,b,v)
            return value is not None and abs(value-mean)<=max(Fraction(1),abs(mean))/10**6 and ints(rows[1],1)==(count,)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError,ZeroDivisionError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid in OUTPUT_MODES:return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc054_d':"n,ma,mb=map(int,input().split());items=[tuple(map(int,input().split())) for _ in range(n)];dp={(0,0):0}\nfor a,b,c in items:\n new=dict(dp)\n for (x,y),cost in dp.items():new[(x+a,y+b)]=min(new.get((x+a,y+b),10**9),cost+c)\n dp=new\nprint(min([cost for (x,y),cost in dp.items() if x and x*mb==y*ma] or [-1]))\n",
'arc069_b':"from itertools import product\nn=int(input());s=input()\nfor first,second in product((0,1),repeat=2):\n a=[first,second]\n for j in range(1,n-1):a.append(a[j-1]^a[j]^(s[j]=='x'))\n if all((a[j-1]^a[j]^a[(j+1)%n])==(s[j]=='x') for j in range(n)):print(''.join('W' if v else 'S' for v in a));break\nelse:print(-1)\n",
'arc070_b':"n,k=map(int,input().split());a=sorted(map(int,input().split()));mask=(1<<k)-1\ndef needed(index):\n if a[index]>=k:return True\n bits=1\n for j,v in enumerate(a):\n  if j!=index and v<k:bits=(bits|bits<<v)&mask\n return bool(bits>>max(0,k-a[index]))\nlo,hi=0,n\nwhile lo<hi:\n mid=(lo+hi)//2\n if needed(mid):hi=mid\n else:lo=mid+1\nprint(lo)\n",
'abc057_d':"from math import comb\nn,a,b=map(int,input().split());v=sorted(map(int,input().split()),reverse=True);cut=v[a-1];total=v.count(cut);chosen=v[:a].count(cut)\nprint(sum(v[:a])/a)\nprint(sum(comb(total,j) for j in range(a,min(b,total)+1)) if v[0]==cut else comb(total,chosen))\n",
'arc071_b':"n,m=map(int,input().split());x=list(map(int,input().split()));y=list(map(int,input().split()));mod=1000000007\ndef width(a):return sum((2*j-len(a)+1)*v for j,v in enumerate(a))%mod\nprint(width(x)*width(y)%mod)\n",
'arc072_b':"x,y=map(int,input().split());print('Brown' if abs(x-y)<=1 else 'Alice')\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18100+TASKS.index(pid))
    if pid=='abc054_d':
        def chemical(ma:int,mb:int,a:list[tuple[int,int,int]])->str:return f'{len(a)} {ma} {mb}\n'+''.join(line(v) for v in a)
        raws=[chemical(ma,mb,a) for ma,mb,a in ((1,1,[(1,1,1)]),(1,2,[(1,1,1)]),(1,1,[(1,2,3),(2,1,4)]),(10,9,[(10,9,100)]))]
        for n in range(3,15):ma,mb=rng.choice([(x,y) for x in range(1,11) for y in range(1,11) if gcd(x,y)==1]);raws.append(chemical(ma,mb,[(rng.randint(1,10),rng.randint(1,10),rng.randint(1,100)) for _ in range(n)]))
        raws.extend([chemical(9,10,[(rng.randint(1,10),rng.randint(1,10),rng.randint(1,100)) for _ in range(40)]),chemical(10,9,[(10,10,100)]*40)])
    elif pid=='arc069_b':
        raws=[f'{len(s)}\n{s}\n' for s in ('ooo','xxx','oox','oxox')];raws.extend(f'{n}\n'+''.join(rng.choice('ox') for _ in range(n))+'\n' for n in range(5,17));raws.extend(['100000\n'+'ox'*50000+'\n','100000\n'+'x'*100000+'\n'])
    elif pid=='arc070_b':
        def cards(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[cards(k,a) for k,a in ((1,[1]),(2,[1]),(2,[1,1]),(3,[1,2,4]))];raws.extend(cards(rng.randint(1,100),[rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([cards(5000,[1]*5000),cards(5000,[10**9]*5000)])
    elif pid=='abc057_d':
        def average(a:int,b:int,v:list[int])->str:return f'{len(v)} {a} {b}\n'+line(v)
        raws=[average(a,b,v) for a,b,v in ((1,1,[1]),(1,2,[1,1]),(1,2,[1,2]),(2,3,[2,2,1]))]
        for n in range(3,15):a=rng.randint(1,n);raws.append(average(a,rng.randint(a,n),[rng.randint(1,100) for _ in range(n)]))
        raws.extend([average(1,50,[10**15]*50),average(50,50,[10**15]*50)])
    elif pid=='arc071_b':
        def rectangles(x:list[int],y:list[int])->str:return f'{len(x)} {len(y)}\n'+line(x)+line(y)
        raws=[rectangles(x,y) for x,y in (([0,1],[0,1]),([-1,0],[-1,0]),([0,2],[0,3]),([-10**9,10**9],[-10**9,10**9]))];raws.extend(rectangles(sorted(rng.sample(range(-10000,10001),n)),sorted(rng.sample(range(-10000,10001),n+1))) for n in range(3,15));coordinates=[-10**9+j*20000 for j in range(99999)]+[10**9];raws.extend([rectangles(list(range(100000)),[-10**9,10**9]),rectangles(coordinates,coordinates)])
    else:
        pairs=[(0,0),(0,1),(0,2),(1,1)]+[(rng.randint(0,1000),rng.randint(0,1000)) for _ in range(12)]+[(10**18,0),(10**18,10**18)];raws=[line(pair) for pair in pairs]
    require(len(raws)==len(set(raws))==18,'unique');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc054_d':('薬品を使うかどうかで、2種類の物質量と費用が変わります。','合計A量・B量を状態にし、各薬品を一度ずつ追加する最小費用DPを行います。','疑似コード: dp[(0,0)]=0; 各薬品でdpのコピーへdp[(A+a,B+b)]=min(既存,cost+c); 最後A>0かつA*Mb=B*Maの最小費用、なければ-1。'),
'arc069_b':('最初の2匹を決めると、残りの種別は発言から順に決まります。','羊を0、狼を1とすると、隣3匹のxorが、発言xなら1、oなら0になります。最初の4通りを試します。','疑似コード: a0,a1全4通り; i=1..N-2でa[i+1]=a[i-1] xor a[i] xor (s[i]=x); 円環の全式を確認し合法ならS/W列、全失敗なら-1。'),
'arc070_b':('カードを抜いた残りで、K-a[i]以上K未満を作れると必要です。','小さいカードほど不必要になりやすいのでsort後に境目を二分探索します。各判定はbitset部分和DPです。','疑似コード: needed(i)はi以外をbitsetで0..K-1の到達和へ追加し、K-a[i]以上のbitがあるか; sorted Aの最初のneededを二分探索し、その添字を出力。'),
'abc057_d':('最大平均は価値の大きい順にA個選ぶと得られます。','A番目の値と同じ品物を何個選ぶか数えます。A番目が最大値ならA〜B個を選ぶ場合も考えます。','疑似コード: V降順sort; mean=sum(V[:A])/A; cut=V[A-1]; total=count(cut),chosen=count(V[:A],cut); cut=maxならsum(C(total,j),j=A..min(B,total))、他はC(total,chosen); meanと個数を2行出力。'),
'arc071_b':('面積の合計は、横幅の合計と縦幅の合計の積へ分解できます。','各座標が正側・負側として現れる回数を差し引き、全ペア差の和を求めます。','疑似コード: width(X)=sum((2*i-len(X)+1)*X[i]); 同じくY; width(X)*width(Y)%1000000007を出力。'),
'arc072_b':('石の個数の差が小さい状態は不利です。','差が0または1ならBrown、それ以外ならAliceが勝ちます。','疑似コード: abs(X-Y)<=1ならBrownを出力、他はAliceを出力。')}

TITLES={'abc054_d': 'Mixing Experiment', 'arc069_b': 'Menagerie', 'arc070_b': 'No Need', 'abc057_d': 'Maximum Average Sets', 'arc071_b': '井井井', 'arc072_b': 'Alice&Brown'}
PUBLISHED_SAMPLES={'abc054_d': [{'input': '3 1 1\n1 2 1\n2 1 2\n3 3 10\n', 'expected': '3\n'}, {'input': '1 1 10\n10 10 10\n', 'expected': '-1\n'}], 'arc069_b': [{'input': '6\nooxoox\n', 'expected': 'SSSWWS\n'}, {'input': '3\noox\n', 'expected': '-1\n'}, {'input': '10\noxooxoxoox\n', 'expected': 'SSWWSSSWWS\n'}], 'arc070_b': [{'input': '3 6\n1 4 3\n', 'expected': '1\n'}, {'input': '5 400\n3 1 4 1 5\n', 'expected': '5\n'}, {'input': '6 20\n10 4 3 10 25 2\n', 'expected': '3\n'}], 'abc057_d': [{'input': '5 2 2\n1 2 3 4 5\n', 'expected': '4.500000\n1\n'}, {'input': '4 2 3\n10 20 10 10\n', 'expected': '15.000000\n3\n'}, {'input': '5 1 5\n1000000000000000 999999999999999 999999999999998 999999999999997 999999999999996\n', 'expected': '1000000000000000.000000\n1\n'}, {'input': '50 1 50\n1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1\n', 'expected': '1.000000\n1125899906842623\n'}], 'arc071_b': [{'input': '3 3\n1 3 4\n1 3 6\n', 'expected': '60\n'}, {'input': '6 5\n-790013317 -192321079 95834122 418379342 586260100 802780784\n-253230108 193944314 363756450 712662868 735867677\n', 'expected': '835067060\n'}], 'arc072_b': [{'input': '2 1\n', 'expected': 'Brown\n'}, {'input': '5 0\n', 'expected': 'Alice\n'}, {'input': '0 0\n', 'expected': 'Brown\n'}, {'input': '4 8\n', 'expected': 'Alice\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
