"""ABC121–124 A/B: official input contracts, deterministic cases, independent checks.

Original reference programs are stored separately in data/reference_solutions.
"""
from __future__ import annotations

from itertools import permutations, product
from random import Random
import re

SAMPLES = {
    'abc121_a': ('3 2\n2 1\n', '1', '1<=H,W<=20; 1<=h<=H; 1<=w<=W'),
    'abc121_b': ('2 3 -10\n1 2 3\n3 2 1\n1 2 2\n', '1', '1<=N,M<=20; -100<=Aij,Bj,C<=100'),
    'abc122_a': ('A\n', 'T', 'b in A,C,G,T'),
    'abc122_b': ('ATCODER\n', '3', '1<=len(S)<=10; S uppercase A-Z'),
    'abc123_a': ('1\n2\n4\n8\n9\n15\n', 'Yay!', '0<=a<b<c<d<e<=123; 0<=k<=123'),
    'abc123_b': ('29\n20\n7\n35\n120\n', '215', '1<=A,B,C,D,E<=123'),
    'abc124_a': ('5 3\n', '9', '3<=A,B<=20'),
    'abc124_b': ('4\n6 5 6 8\n', '3', '1<=N<=20; 1<=Hi<=100'),
}
BATCH13 = {pid: {'sample_input': inp, 'sample_output': output,
                 'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
                 'constraints': constraints}
           for pid, (inp, output, constraints) in SAMPLES.items()}
_INT = re.compile(r'-?(?:0|[1-9][0-9]*)\Z')


def _int_tokens(text: str, count: int | None = None) -> list[int]:
    tokens = text.split()
    if not tokens or (count is not None and len(tokens) != count) or any(_INT.fullmatch(s) is None for s in tokens):
        raise ValueError('integer token count/format mismatch')
    return list(map(int, tokens))


def validate(pid: str, data: str):
    if pid not in BATCH13:
        raise ValueError('unknown task')
    if pid == 'abc122_a':
        t = data.split()
        if len(t) != 1 or t[0] not in ('A', 'C', 'G', 'T'):
            raise ValueError('base must be exactly A/C/G/T')
        return t[0]
    if pid == 'abc122_b':
        t = data.split()
        if len(t) != 1 or re.fullmatch('[A-Z]{1,10}', t[0]) is None:
            raise ValueError('1..10 uppercase English characters required')
        return t[0]
    if pid == 'abc121_b':
        lines = data.strip().splitlines()
        if not lines:
            raise ValueError('missing header')
        n, m, c = _int_tokens(lines[0], 3)
        if not 1 <= n <= 20 or not 1 <= m <= 20 or not -100 <= c <= 100 or len(lines) != n + 2:
            raise ValueError('N/M/C or row count invalid')
        b = _int_tokens(lines[1], m)
        rows = [_int_tokens(line, m) for line in lines[2:]]
        if any(not -100 <= x <= 100 for x in b) or any(not -100 <= x <= 100 for row in rows for x in row):
            raise ValueError('weights/features out of range')
        return n, m, c, b, rows
    if pid == 'abc124_b':
        lines = data.strip().splitlines()
        if len(lines) != 2:
            raise ValueError('N and exactly one heights row required')
        n = _int_tokens(lines[0], 1)[0]
        heights = _int_tokens(lines[1])
        if not 1 <= n <= 20 or len(heights) != n or any(not 1 <= h <= 100 for h in heights):
            raise ValueError('heights count/range invalid')
        return heights
    vals = _int_tokens(data, {'abc121_a': 4, 'abc123_a': 6,
                              'abc123_b': 5, 'abc124_a': 2}[pid])
    if pid == 'abc121_a':
        h_total, w_total, h_painted, w_painted = vals
        if not (1 <= h_total <= 20 and 1 <= w_total <= 20 and
                1 <= h_painted <= h_total and 1 <= w_painted <= w_total):
            raise ValueError('H/W/h/w bounds invalid')
    elif pid == 'abc123_a':
        if not (0 <= vals[0] < vals[1] < vals[2] < vals[3] < vals[4] <= 123 and 0 <= vals[5] <= 123):
            raise ValueError('antenna coordinates/order/range invalid')
    elif pid == 'abc123_b':
        if any(not 1 <= x <= 123 for x in vals):
            raise ValueError('dish times out of range')
    elif any(not 3 <= x <= 20 for x in vals):
        raise ValueError('button sizes out of range')
    return tuple(vals)


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str, str]]:
    if pid not in BATCH13 or not 1 <= count <= 80:
        raise ValueError('unknown task / invalid count')
    rnd = Random(seed)
    cases: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, text: str):
        validate(pid, text)
        if text not in seen:
            seen.add(text)
            cases.append({'category': category, 'input': text})

    def nums(kind, *values):
        add(kind, ' '.join(map(str, values)) + '\n')

    if pid == 'abc121_a':
        for ht, wt, h, w in ((1,1,1,1),(20,20,1,1),(20,20,20,20),(20,20,1,20),
                            (20,20,20,1),(3,2,2,1),(5,5,2,3),(1,20,1,1),
                            (20,1,1,1),(19,20,18,19),(2,2,1,1),(20,20,19,19)):
            add('boundary', f'{ht} {wt}\n{h} {w}\n')
        while len(cases) < count:
            ht=rnd.randint(1,20);wt=rnd.randint(1,20)
            add('random',f'{ht} {wt}\n{rnd.randint(1,ht)} {rnd.randint(1,wt)}\n')
        largest='20 20\n20 20\n'
    elif pid == 'abc121_b':
        def matrix(kind, m, c, b, rows):
            add(kind, f'{len(rows)} {m} {c}\n'+' '.join(map(str,b))+'\n'+
                '\n'.join(' '.join(map(str,row)) for row in rows)+'\n')
        matrix('sample',3,-10,[1,2,3],[[3,2,1],[1,2,2]])
        matrix('constraint_min',1,0,[0],[[0]])
        matrix('strict_zero',1,-100,[100],[[1]])
        matrix('strict_positive',1,-99,[100],[[1]])
        matrix('all_negative',2,-100,[-100,-100],[[100,100]]*3)
        matrix('all_positive',2,100,[100,100],[[100,100]]*3)
        matrix('negative_times_negative',2,0,[-100,-100],[[-100,-100],[100,100]])
        matrix('all_zero',3,0,[0,0,0],[[0,0,0]]*20)
        matrix('maximum_values',20,100,[100]*20,[[100]*20]*20)
        matrix('minimum_values',20,-100,[-100]*20,[[100]*20]*20)
        while len(cases) < count:
            n=rnd.randint(1,20);m=rnd.randint(1,20)
            matrix('random',m,rnd.randint(-100,100),[rnd.randint(-100,100) for _ in range(m)],
                   [[rnd.randint(-100,100) for _ in range(m)] for _ in range(n)])
        largest=f'20 20 100\n'+('100 '*19+'100\n')*21
    elif pid == 'abc122_a':
        for s in ('A','C','G','T'):
            add('exhaustive',s+'\n')
        largest='T\n'
    elif pid == 'abc122_b':
        for s in ('ATCODER','HATAGAYA','SHINJUKU','A','Z','ACGTACGTAC',
                  'ZZZZZZZZZZ','ACGTZZZZZZ','ZZZZZZACGT','ZACGTZACGT',
                  'AAAAAZAAAA','ACGTTTTTTT'):
            add('boundary',s+'\n')
        while len(cases)<count:
            add('random',''.join(rnd.choice('ACGT' if rnd.randrange(3) else 'BCDFHIJKLXYZ')
                                 for _ in range(rnd.randint(1,10)))+'\n')
        largest='ACGTACGTAC\n'
    elif pid == 'abc123_a':
        def antenna(kind, values, k):
            add(kind,'\n'.join(map(str,[*values,k]))+'\n')
        for values,k in (([0,1,2,3,4],0),([0,1,2,3,4],4),([0,1,2,3,4],3),
                         ([0,1,2,3,123],123),([0,1,2,3,123],122),
                         ([119,120,121,122,123],4),([119,120,121,122,123],3),
                         ([1,2,4,8,9],15),([15,18,26,35,36],18),
                         ([0,30,60,90,123],123),([0,30,60,90,123],0),
                         ([0,1,2,3,4],123)):
            antenna('boundary',values,k)
        while len(cases)<count:
            antenna('random',sorted(rnd.sample(range(124),5)),rnd.randint(0,123))
        largest='0\n30\n60\n90\n123\n123\n'
    elif pid == 'abc123_b':
        def dishes(kind, values):
            add(kind,'\n'.join(map(str,values))+'\n')
        for a in ((1,)*5,(123,)*5,(10,)*5,(20,30,40,50,60),(29,20,7,35,120),
                  (101,86,119,108,57),(1,2,3,4,5),(9,19,29,39,49),
                  (10,10,10,10,1),(11,21,31,41,51),(123,122,121,120,119),
                  (100,101,102,103,104)):
            dishes('boundary',a)
        while len(cases)<count:
            dishes('random',[rnd.randint(1,123) for _ in range(5)])
        largest='123\n123\n123\n123\n123\n'
    elif pid == 'abc124_a':
        for a,b in ((3,3),(20,20),(3,20),(20,3),(5,3),(3,4),(6,6),
                    (20,19),(19,20),(19,19),(4,3),(3,5)):
            nums('boundary',a,b)
        while len(cases)<count:nums('random',rnd.randint(3,20),rnd.randint(3,20))
        largest='20 20\n'
    else:
        def heights(kind,arr):
            add(kind,f'{len(arr)}\n'+' '.join(map(str,arr))+'\n')
        for arr in ([1],[100],[6,5,6,8],[4,5,3,5,4],[9,5,6,8,4],
                    [1]*20,[100]*20,list(range(1,21)),list(range(20,0,-1)),
                    [100]+[1]*19,[1]*19+[100],[1,100]*10):
            heights('boundary',arr)
        while len(cases)<count:
            heights('random',[rnd.randint(1,100) for _ in range(rnd.randint(1,20))])
        largest='20\n'+' '.join(['100']*20)+'\n'

    if include_large:
        # Keep exactly one final maximum-scale case, even if already among base cases.
        cases=[c for c in cases if c['input'] != largest]
        seen.discard(largest)
        add('constraint_max',largest)
    return cases[:count] + ([c for c in cases[count:] if c['category']=='constraint_max'] if include_large else [])


def independent_check(pid: str, data: str, expected: str) -> bool:
    args=validate(pid,data)
    if pid == 'abc121_a':
        ht,wt,h,w=args
        return expected.strip()==str(sum(i>=h and j>=w for i in range(ht) for j in range(wt)))
    if pid == 'abc121_b':
        n,m,c,b,rows=args
        result=0
        for row in rows:
            score=c
            for j in range(m):score+=row[j]*b[j]
            result+=score>0
        return expected.strip()==str(result)
    if pid == 'abc122_a':
        return expected.strip()==dict(zip('ACGT','TGCA'))[args]
    if pid == 'abc122_b':
        return expected.strip()==str(max((j-i for i in range(len(args)+1)
                        for j in range(i,len(args)+1)
                        if set(args[i:j]) <= set('ACGT')),default=0))
    if pid == 'abc123_a':
        coords=args[:5]; k=args[5]
        return expected.strip()==(':(' if any(coords[j]-coords[i]>k for i in range(5) for j in range(i+1,5)) else 'Yay!')
    if pid == 'abc123_b':
        best=10**9
        for order in permutations(args):
            time=0
            for duration in order:
                time=((time+9)//10)*10+duration
            best=min(best,time)
        return expected.strip()==str(best)
    if pid == 'abc124_a':
        a,b=args
        return expected.strip()==str(max(a+b,2*a-1,2*b-1))
    return expected.strip()==str(sum(all(args[j]<=args[i] for j in range(i)) for i in range(len(args))))
