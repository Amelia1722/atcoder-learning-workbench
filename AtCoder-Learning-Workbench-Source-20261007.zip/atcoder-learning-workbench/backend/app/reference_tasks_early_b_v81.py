"""ABC101–103 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc101_b','abc102_b','abc103_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER=re.compile(r'[a-z]+', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc101_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
        n=int(lines[0])
        if not 1<=n<=10**9: raise ValueError('range')
        return n
    if pid=='abc102_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None: raise ValueError('format')
        n=int(lines[0])
        if not 2<=n<=100: raise ValueError('n range')
        vals=lines[1].split(' ')
        if len(vals)!=n or any(POS.fullmatch(x) is None for x in vals): raise ValueError('array format')
        a=list(map(int,vals))
        if any(not 1<=x<=10**9 for x in a): raise ValueError('value range')
        return n,a
    if len(lines)!=2 or LOWER.fullmatch(lines[0]) is None or LOWER.fullmatch(lines[1]) is None:
        raise ValueError('format')
    s,t=lines
    if not 2<=len(s)<=100 or len(t)!=len(s): raise ValueError('length')
    return s,t

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc101_b':
        if output not in ('Yes','No'): return False
        n=value; digit_sum=0
        for c in str(n): digit_sum += ord(c)-48
        return output==('Yes' if n%digit_sum==0 else 'No')
    if pid=='abc102_b':
        if re.fullmatch(r'(?:0|[1-9][0-9]*)',output,re.ASCII) is None: return False
        _,a=value
        lo=a[0]; hi=a[0]
        for x in a[1:]:
            if x<lo: lo=x
            if x>hi: hi=x
        return int(output)==hi-lo
    if output not in ('Yes','No'): return False
    s,t=value
    # Independent from the common (t in s+s) formulation: enumerate right rotations.
    cur=s
    ok=False
    for _ in range(len(s)):
        if cur==t:
            ok=True; break
        cur=cur[-1]+cur[:-1]
    return output==('Yes' if ok else 'No')

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc101_b':
        vals=[1,2,9,10,11,12,18,19,99,100,101,111,1729,9999,100000000,99999999,999999999]
        for n in vals:
            add('boundary' if n in (1,10,10**9) else 'normal',f'{n}\n')
        add('constraint_max','1000000000\n')
    elif pid=='abc102_b':
        arrays=[
            [1,1],[1,2],[10,1],[5,5,5],[1,4,6,3],[10**9,1],
            [3,8,2,9,4],[100,1,50,99],[7,7,8,7],[1,10**9,500000000],
            list(range(1,11)),list(range(100,90,-1)),[2,100,2,100,50],
            [999999999,1000000000],[1]*20+[2],[10**9-i for i in range(50)],
            [1 if i%2==0 else 10**9 for i in range(99)],
        ]
        for a in arrays:
            add('boundary' if len(a) in (2,100) or min(a)==1 or max(a)==10**9 else 'normal',
                f'{len(a)}\n'+ ' '.join(map(str,a))+'\n')
        a=[1]+[500000000]*98+[10**9]
        add('constraint_max','100\n'+' '.join(map(str,a))+'\n')
    else:
        pairs=[
            ('aa','aa'),('ab','ba'),('ab','ab'),('abc','bca'),('abc','cab'),('abc','acb'),
            ('kyoto','tokyo'),('aaaaab','baaaaa'),('aaaaab','aaaaab'),('abcdef','fabcde'),
            ('abcdef','defabc'),('abab','baba'),('abab','abba'),('zzxy','xyzz'),
            ('atcoder','oderatc'),('abcdefghijklmnopqrst','klmnopqrstabcdefghij'),
            ('a'*99+'b','b'+'a'*99),
        ]
        for s,t in pairs:
            add('boundary' if len(s) in (2,100) else 'normal',f'{s}\n{t}\n')
        s='abcdefghijklmnopqrstuvwxyz'*3+'abcdefghijklmnopqrstuv'
        s=s[:100]; t=s[37:]+s[:37]
        add('constraint_max',f'{s}\n{t}\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
