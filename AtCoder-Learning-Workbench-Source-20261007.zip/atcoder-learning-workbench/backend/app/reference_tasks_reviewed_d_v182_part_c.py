"""Private ABC072--077 D tasks, preserving official ARC canonical identities."""
from __future__ import annotations
from fractions import Fraction
from itertools import permutations
from typing import cast
import heapq,random,re
TASKS=('arc082_b','abc073_d','arc083_b','abc075_d','abc076_d','arc084_b')
CONTESTS=dict(zip(TASKS,('abc072','abc073','abc074','abc075','abc076','abc077')))
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc076_d':'numeric_absolute_1e-3'}
Case=dict[str,str]
Edge=tuple[int,int,int]
Data=tuple[object,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='arc082_b':
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(2<=n<=100000 and set(a)==set(range(1,n+1)),'permutation');return (a,)
    if pid=='abc073_d':
        n,m,r=ints(rows[0],3);require(2<=n<=200 and n-1<=m<=n*(n-1)//2 and 2<=r<=min(8,n) and len(rows)==m+2,'shape');towns=ints(rows[1],r);require(len(set(towns))==r and all(1<=x<=n for x in towns),'towns');edges=tuple(ints(row,3) for row in rows[2:]);seen:set[tuple[int,int]]=set();graph:list[list[int]]=[[] for _ in range(n)]
        for a,b,c in edges:
            require(1<=a<=n and 1<=b<=n and a!=b and 1<=c<=100000,'road');pair=min(a,b),max(a,b);require(pair not in seen,'duplicate');seen.add(pair);graph[a-1].append(b-1);graph[b-1].append(a-1)
        visited={0};stack=[0]
        while stack:
            for j in graph[stack.pop()]:
                if j not in visited:visited.add(j);stack.append(j)
        require(len(visited)==n,'connected');return n,towns,edges
    if pid=='arc083_b':
        n=ints(rows[0],1)[0];require(1<=n<=300 and len(rows)==n+1,'shape');a=tuple(ints(row,n) for row in rows[1:]);require(all(a[i][i]==0 for i in range(n)) and all(1<=a[i][j]<=10**9 and a[i][j]==a[j][i] for i in range(n) for j in range(i)),'symmetric distances');return (a,)
    if pid=='abc075_d':
        n,k=ints(rows[0],2);require(2<=k<=n<=50 and len(rows)==n+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(-10**9<=v<=10**9 for p in a for v in p) and len({x for x,y in a})==n and len({y for x,y in a})==n,'distinct coordinates');return k,a
    if pid=='abc076_d':
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];t,v=ints(rows[1],n),ints(rows[2],n);require(1<=n<=100 and all(1<=x<=200 for x in t) and all(1<=x<=100 for x in v),'speed');return t,v
    require(len(rows)==1,'shape');k=ints(rows[0],1)[0];require(2<=k<=100000,'modulus');return (k,)

def edge_cover(a:tuple[int,...])->int:
    # Select adjacent edges covering every fixed position: two-state path DP.
    no,yes=0,10**9
    for j in range(len(a)-1):
        needed=a[j]==j+1;no,yes=min(yes,no if not needed else 10**9),min(no,yes)+1
    return min(yes,no if a[-1]!=len(a) else 10**9)

def visit_dp(n:int,towns:tuple[int,...],edges:tuple[Edge,...])->int:
    graph:list[list[tuple[int,int]]]=[[] for _ in range(n)]
    for a,b,c in edges:graph[a-1].append((b-1,c));graph[b-1].append((a-1,c))
    distances:list[list[int]]=[]
    for town in towns:
        d=[10**20]*n;d[town-1]=0;queue=[(0,town-1)]
        while queue:
            value,i=heapq.heappop(queue)
            if value!=d[i]:continue
            for j,c in graph[i]:
                if value+c<d[j]:d[j]=value+c;heapq.heappush(queue,(d[j],j))
        distances.append([d[x-1] for x in towns])
    r=len(towns);dp=[[10**20]*r for _ in range(1<<r)]
    for j in range(r):dp[1<<j][j]=0
    for mask in range(1,1<<r):
        for j in range(r):
            if not mask>>j&1:continue
            for k in range(r):
                if not mask>>k&1:dp[mask|1<<k][k]=min(dp[mask|1<<k][k],dp[mask][j]+distances[j][k])
    return min(dp[-1])

def reconstruct(a:tuple[tuple[int,...],...])->int:
    # Insert roads shortest first. A bounded Dijkstra checks whether the next
    # distance already exists, contradicts a shorter path, or requires a road.
    n=len(a);graph:list[list[tuple[int,int]]]=[[] for _ in range(n)];answer=0
    for cost,i,j in sorted((a[i][j],i,j) for i in range(n) for j in range(i)):
        d=[cost+1]*n;d[i]=0;queue=[(0,i)];found=cost+1
        while queue:
            value,node=heapq.heappop(queue)
            if value!=d[node]:continue
            if node==j:found=value;break
            if value>=cost:break
            for nxt,c in graph[node]:
                candidate=value+c
                if candidate<=cost and candidate<d[nxt]:d[nxt]=candidate;heapq.heappush(queue,(candidate,nxt))
        if found<cost:return -1
        if found>cost:graph[i].append((j,cost));graph[j].append((i,cost));answer+=cost
    return answer

def rectangle_masks(k:int,points:tuple[tuple[int,int],...])->int:
    # Independent x/y slabs represented as bit masks; coverage is intersection.
    xs=sorted(x for x,y in points);ys=sorted(y for x,y in points);xrank={x:j for j,x in enumerate(xs)};yrank={y:j for j,y in enumerate(ys)}
    def slabs(coords:list[int],ranks:dict[int,int],axis:int)->list[tuple[int,int]]:
        byrank=[0]*len(coords)
        for j,p in enumerate(points):byrank[ranks[p[axis]]]=1<<j
        result=[]
        for lo in range(len(coords)):
            mask=0
            for hi in range(lo,len(coords)):
                mask|=byrank[hi]
                if hi-lo+1>=k:result.append((coords[hi]-coords[lo],mask))
        return result
    xslabs=slabs(xs,xrank,0);yslabs=slabs(ys,yrank,1);answer=4*10**18
    for width,xmask in xslabs:
        for height,ymask in yslabs:
            if width*height<answer and (xmask&ymask).bit_count()>=k:answer=width*height
    return answer

def speed_area(t:tuple[int,...],v:tuple[int,...])->Fraction:
    # Boundary speeds are maximal feasible caps. Integrate each segment's
    # three-line lower envelope analytically, without a half-second grid.
    bounds=[0]+[min(v[j-1],v[j]) for j in range(1,len(t))]+[0]
    for j,duration in enumerate(t):bounds[j+1]=min(bounds[j+1],bounds[j]+duration)
    for j in range(len(t)-1,-1,-1):bounds[j]=min(bounds[j],bounds[j+1]+t[j])
    area=Fraction(0)
    for j,duration in enumerate(t):
        a,b=bounds[j],bounds[j+1];peak=min(Fraction(v[j]),Fraction(a+b+duration,2));up=peak-a;down=peak-b;flat=duration-up-down
        area+=(a+peak)*up/2+peak*flat+(b+peak)*down/2
    return area

def digit_dijkstra(k:int)->int:
    # Append actual decimal digits; each edge costs that digit. Leading zero
    # is excluded by initialising all nonzero one-digit numbers.
    d=[10**9]*k;queue:list[tuple[int,int]]=[]
    for digit in range(1,10):
        r=digit%k
        if digit<d[r]:d[r]=digit;heapq.heappush(queue,(digit,r))
    while queue:
        cost,r=heapq.heappop(queue)
        if cost!=d[r]:continue
        if r==0:return cost
        for digit in range(10):
            nxt=(r*10+digit)%k
            if cost+digit<d[nxt]:d[nxt]=cost+digit;heapq.heappush(queue,(cost+digit,nxt))
    raise ValueError('unreachable')

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='arc082_b':return str(edge_cover(cast(tuple[int,...],data[0])))
    if pid=='abc073_d':return str(visit_dp(cast(int,data[0]),cast(tuple[int,...],data[1]),cast(tuple[Edge,...],data[2])))
    if pid=='arc083_b':return str(reconstruct(cast(tuple[tuple[int,...],...],data[0])))
    if pid=='abc075_d':return str(rectangle_masks(cast(int,data[0]),cast(tuple[tuple[int,int],...],data[1])))
    if pid=='abc076_d':
        area=speed_area(cast(tuple[int,...],data[0]),cast(tuple[int,...],data[1]));return f'{area.numerator//area.denominator}.{(area.numerator%area.denominator)*1000000//area.denominator:06}'
    return str(digit_dijkstra(cast(int,data[0])))

def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
    try:
        require(mode is None or mode==OUTPUT_MODES.get(pid,'exact'),'mode');expected=oracle(pid,raw);value=actual.removesuffix('\n')
        if pid=='abc076_d':
            require(re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',value) is not None,'finite number');return abs(Fraction(value)-Fraction(expected))<=Fraction(1,1000)
        return value==expected
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE={
'arc082_b':"n=int(input());p=list(map(int,input().split()));ans=0\nfor i in range(n):\n if p[i]==i+1:\n  j=i+1 if i+1<n else i-1;p[i],p[j]=p[j],p[i];ans+=1\nprint(ans)\n",
'abc073_d':"from itertools import permutations\nn,m,r=map(int,input().split());towns=[x-1 for x in map(int,input().split())];d=[[10**20]*n for _ in range(n)]\nfor i in range(n):d[i][i]=0\nfor _ in range(m):\n a,b,c=map(int,input().split());d[a-1][b-1]=d[b-1][a-1]=c\nfor k in range(n):\n for i in range(n):\n  di=d[i];dk=d[k];v=di[k]\n  for j in range(n):\n   if v+dk[j]<di[j]:di[j]=v+dk[j]\nprint(min(sum(d[a][b] for a,b in zip(p,p[1:])) for p in permutations(towns)))\n",
'arc083_b':"import sys\nn=int(input());a=[list(map(int,input().split())) for _ in range(n)];answer=0\nfor i in range(n):\n for j in range(i):\n  necessary=True\n  for k in range(n):\n   if k==i or k==j:continue\n   route=a[i][k]+a[k][j]\n   if route<a[i][j]:print(-1);sys.exit()\n   if route==a[i][j]:necessary=False\n  if necessary:answer+=a[i][j]\nprint(answer)\n",
'abc075_d':"n,k=map(int,input().split());p=[tuple(map(int,input().split())) for _ in range(n)];p.sort();answer=4*10**18\nfor lo in range(n):\n ys=[]\n for hi in range(lo,n):\n  ys.append(p[hi][1])\n  if len(ys)<k:continue\n  a=sorted(ys)\n  answer=min(answer,(p[hi][0]-p[lo][0])*min(a[j+k-1]-a[j] for j in range(len(a)-k+1)))\nprint(answer)\n",
'abc076_d':"n=int(input());t=list(map(int,input().split()));v=list(map(int,input().split()));caps=[10**9]*(2*sum(t)+1);s=0\nfor duration,limit in zip(t,v):\n for j in range(s,s+2*duration+1):caps[j]=min(caps[j],2*limit)\n s+=2*duration\ncaps[0]=caps[-1]=0\nfor j in range(1,len(caps)):caps[j]=min(caps[j],caps[j-1]+1)\nfor j in range(len(caps)-2,-1,-1):caps[j]=min(caps[j],caps[j+1]+1)\nprint(sum(a+b for a,b in zip(caps,caps[1:]))/8)\n",
'arc084_b':"from collections import deque\nk=int(input());d=[10**9]*k;d[1]=1;q=deque([1])\nwhile q:\n r=q.popleft();a=r*10%k;b=(r+1)%k\n if d[r]<d[a]:d[a]=d[r];q.appendleft(a)\n if d[r]+1<d[b]:d[b]=d[r]+1;q.append(b)\nprint(d[0])\n"}

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18200+TASKS.index(pid));raws:list[str]=[]
    if pid=='arc082_b':
        def perm(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[perm([1,2]),perm([2,1]),perm([1,3,2]),perm([2,1,3]),perm([1,2,3]),perm([1,2,4,3]),perm([2,1,3,4]),perm([2,1,3,5,4])]
        for n in range(6,14):a=list(range(1,n+1));rng.shuffle(a);raws.append(perm(a))
        raws+=[perm(list(range(2,100001))+[1]),perm(list(range(1,100001)))]
    elif pid=='abc073_d':
        def graph(n:int,towns:list[int],edges:list[Edge])->str:return f'{n} {len(edges)} {len(towns)}\n'+line(towns)+''.join(line(e) for e in edges)
        raws=[graph(2,[1,2],[(1,2,1)]),graph(2,[2,1],[(2,1,100000)]),graph(3,[1,3],[(1,2,1),(2,3,1),(1,3,3)]),graph(3,[1,2,3],[(1,2,1),(2,3,1),(1,3,2)])]
        for n in range(4,16):
            edges=[(j,j+1,rng.randint(1,100000)) for j in range(1,n)]+[(a,b,rng.randint(1,100000)) for a in range(1,n+1) for b in range(a+2,n+1) if rng.randrange(3)==0];raws.append(graph(n,rng.sample(range(1,n+1),min(n,8)),edges))
        raws+=[graph(200,list(range(1,9)),[(j,j+1,100000) for j in range(1,200)]),graph(200,[1,2,3,4,197,198,199,200],[(a,b,100000) for a in range(1,201) for b in range(a+1,201)])]
    elif pid=='arc083_b':
        def matrix(a:list[list[int]])->str:return f'{len(a)}\n'+''.join(line(row) for row in a)
        raws=[matrix([[0]]),matrix([[0,1],[1,0]]),matrix([[0,10**9],[10**9,0]]),matrix([[0,1,3],[1,0,1],[3,1,0]])]
        for n in range(3,15):
            coords=[0]
            for _ in range(n-1):coords.append(coords[-1]+rng.randint(1,10000))
            a=[[abs(x-y) for y in coords] for x in coords]
            if n%3==0:a[0][-1]+=1;a[-1][0]+=1
            raws.append(matrix(a))
        raws+=[matrix([[abs(i-j)*3000000 for j in range(300)] for i in range(300)]),matrix([[0 if i==j else 10**9 for j in range(300)] for i in range(300)])]
    elif pid=='abc075_d':
        def points(k:int,a:list[tuple[int,int]])->str:return f'{len(a)} {k}\n'+''.join(line(p) for p in a)
        raws=[points(2,[(0,0),(1,1)]),points(2,[(-10**9,-10**9),(10**9,10**9)]),points(2,[(0,2),(1,0),(2,1)]),points(3,[(0,2),(1,0),(2,1)])]
        for n in range(4,16):raws.append(points(rng.randint(2,n),list(zip(rng.sample(range(-1000,1001),n),rng.sample(range(-1000,1001),n)))))
        a=list(zip([-10**9+j*40000000 for j in range(49)]+[10**9],[10**9-j*40000000 for j in range(49)]+[-10**9]));raws+=[points(2,a),points(50,a)]
    elif pid=='abc076_d':
        def speed(t:list[int],v:list[int])->str:return f'{len(t)}\n'+line(t)+line(v)
        raws=[speed([1],[1]),speed([1],[100]),speed([2],[1]),speed([9],[100]),speed([200],[100]),speed([1,1],[1,100]),speed([200,1,200],[100,1,100])]
        for n in range(2,11):raws.append(speed([rng.randint(1,200) for _ in range(n)],[rng.randint(1,100) for _ in range(n)]))
        raws+=[speed([200]*100,[1 if j%2 else 100 for j in range(100)]),speed([200]*100,[100]*100)]
    else:raws=[f'{k}\n' for k in (2,3,4,5,6,7,9,10,11,41,99,999,9999,79992,99989,99991,99999,100000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'arc082_b':('固定点p[i]=iの位置に注目します。','固定点を左から見て隣と交換すると、連続する固定点を一度に二つ消せます。末尾だけ残ったら左隣と交換します。','疑似コード: ans=0; i=0..N-1についてp[i]==i+1ならj=i+1（末尾ならi-1）を選ぶ; swap(p[i],p[j]); ans++; ansを出力。'),
'abc073_d':('目的地同士の移動には最短経路を使えます。','Floyd-Warshallで全都市間の距離を求めます。訪問する都市は最大8個なので全順列を列挙できます。','疑似コード: dを道路長で初期化; k,i,jについてd[i][j]=min(d[i][j],d[i][k]+d[k][j]); 各訪問順列pで隣接都市間dの合計を求め、最小値を出力。'),
'arc083_b':('直接道路が必要な都市対と、他都市経由で同じ距離になる都市対を区別します。','A[i][j]>A[i][k]+A[k][j]なら最短距離表として矛盾します。等しい場合、その直接道路は省略できます。','疑似コード: 各i>jについて必要=true; kが両端以外ならroute=A[i][k]+A[k][j]; route<A[i][j]なら-1で終了; 等しければ必要=false; 必要な都市対のA[i][j]を合計して出力。'),
'abc075_d':('最小長方形の左右の辺は、含む点のx座標に合わせられます。','x座標で並べた点の連続区間を左右の辺として固定します。その区間のy座標を整列し、連続K個の高さの最小値を調べます。','疑似コード: 点をx昇順に並べる; lo,hiを全列挙; 区間のyを整列; K個以上ならheight=min(y[j+K-1]-y[j]); width=x[hi]-x[lo]; width*heightの最小値を出力。'),
'abc076_d':('時刻ごとの速度上限と、前後の時刻からの加減速制限を同時に満たす速度を求めます。','半秒間隔の速度を2倍した整数で持ちます。各区間の上限を設定し、前後から隣との差が1以内になるよう更新します。','疑似コード: cap[0..2*sum(t)]に区間ごとの2*v上限を設定; 両端cap=0; 左からcap[j]=min(cap[j],cap[j-1]+1); 右から同様; 各隣接capの和を合計し8で割って距離を出力。'),
'arc084_b':('整数そのものではなく、Kで割った余りを状態にします。','1から始め、10倍をコスト0、1を加える操作をコスト1として余りのグラフを作れます。0-1 BFSで余り0に到達する最小コストを求めます。','疑似コード: dist[1]=1; deque=[1]; 取り出したrから10*r%Kへコスト0なら先頭へ追加、(r+1)%Kへコスト1なら末尾へ追加; 改善した距離だけ更新; dist[0]を出力。')}

TITLES={'arc082_b': 'Derangement', 'abc073_d': "joisino's travel", 'arc083_b': 'Restoring Road Network', 'abc075_d': 'Axis-Parallel Rectangle', 'abc076_d': 'AtCoder Express', 'arc084_b': 'Small Multiple'}
PUBLISHED_SAMPLES={'arc082_b': [{'input': '5\n1 4 3 5 2\n', 'expected': '2\n'}, {'input': '2\n1 2\n', 'expected': '1\n'}, {'input': '2\n2 1\n', 'expected': '0\n'}, {'input': '9\n1 2 4 9 5 8 7 3 6\n', 'expected': '3\n'}], 'abc073_d': [{'input': '3 3 3\n1 2 3\n1 2 1\n2 3 1\n3 1 4\n', 'expected': '2\n'}, {'input': '3 3 2\n1 3\n2 3 2\n1 3 6\n1 2 2\n', 'expected': '4\n'}, {'input': '4 6 3\n2 3 4\n1 2 4\n2 3 3\n4 3 1\n1 4 1\n4 2 2\n3 1 6\n', 'expected': '3\n'}], 'arc083_b': [{'input': '3\n0 1 3\n1 0 2\n3 2 0\n', 'expected': '3\n'}, {'input': '3\n0 1 3\n1 0 1\n3 1 0\n', 'expected': '-1\n'}, {'input': '5\n0 21 18 11 28\n21 0 13 10 26\n18 13 0 23 13\n11 10 23 0 17\n28 26 13 17 0\n', 'expected': '82\n'}, {'input': '3\n0 1000000000 1000000000\n1000000000 0 1000000000\n1000000000 1000000000 0\n', 'expected': '3000000000\n'}], 'abc075_d': [{'input': '4 4\n1 4\n3 3\n6 2\n8 1\n', 'expected': '21\n'}, {'input': '4 2\n0 0\n1 1\n2 2\n3 3\n', 'expected': '1\n'}, {'input': '4 3\n-1000000000 -1000000000\n1000000000 1000000000\n-999999999 999999999\n999999999 -999999999\n', 'expected': '3999999996000000001\n'}], 'abc076_d': [{'input': '1\n100\n30\n', 'expected': '2100.000000000000000\n'}, {'input': '2\n60 50\n34 38\n', 'expected': '2632.000000000000000\n'}, {'input': '3\n12 14 2\n6 2 7\n', 'expected': '76.000000000000000\n'}, {'input': '1\n9\n10\n', 'expected': '20.250000000000000000\n'}, {'input': '10\n64 55 27 35 76 119 7 18 49 100\n29 19 31 39 27 48 41 87 55 70\n', 'expected': '20291.000000000000\n'}], 'arc084_b': [{'input': '6\n', 'expected': '3\n'}, {'input': '41\n', 'expected': '5\n'}, {'input': '79992\n', 'expected': '36\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
