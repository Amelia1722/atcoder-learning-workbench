"""Private ABC407..412 D strict domains and independently structured oracles."""
from __future__ import annotations
from bisect import bisect_right
from collections import deque
from functools import lru_cache
from itertools import combinations,permutations
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(407,413));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]

def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integer fields');v=tuple(map(int,row.split()));require(count is None or len(v)==count,'field count');return v
def line(v:list[int]|tuple[int,...])->str:return ' '.join(map(str,v))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc407_d':
  h,w=ints(r[0],2);require(h>=1 and w>=1 and h*w<=20 and len(r)==h+1,'grid shape');a=tuple(v for row in r[1:] for v in ints(row,w));require(all(0<=v<1<<60 for v in a),'Ai');return h,w,a
 if pid in ('abc408_d','abc409_d'):
  t=ints(r[0],1)[0];cap=200000 if pid=='abc408_d' else 100000;require(1<=t<=(20000 if pid=='abc408_d' else 100000) and len(r)==1+2*t,'T/rows');strings=[];total=0
  for i in range(t):
   n=ints(r[1+2*i],1)[0];s=r[2+2*i];require(1<=n<=cap and len(s)==n and re.fullmatch('[01]+' if pid=='abc408_d' else '[a-z]+',s) is not None,'N/S');total+=n;strings.append(s)
  require(total<=cap,'sum N');return (tuple(strings),)
 if pid in ('abc410_d','abc412_d'):
  n,m=ints(r[0],2);require((2<=n<=1000 and 0<=m<=1000) if pid=='abc410_d' else (3<=n<=8 and 0<=m<=n*(n-1)//2),'N/M');require(len(r)==m+1,'edges rows');edges=tuple(ints(row,3 if pid=='abc410_d' else 2) for row in r[1:]);require(all(1<=v[0]<=n and 1<=v[1]<=n for v in edges),'endpoints')
  if pid=='abc410_d':require(all(0<=v[2]<1024 for v in edges),'weights')
  else:require(all(a!=b for a,b in edges) and len({tuple(sorted(e)) for e in edges})==m,'simple graph')
  return n,edges
 n,q=ints(r[0],2);require(1<=n<=200000 and 1<=q<=200000 and len(r)==q+1,'N/Q');queries=[];total=0
 for row in r[1:]:
  fields=row.split(' ');require(len(fields)>=2,'query fields');kind,p=ints(' '.join(fields[:2]),2);require(kind in (1,2,3) and 1<=p<=n and len(fields)==(3 if kind==2 else 2),'query')
  if kind==2:require(re.fullmatch('[a-z]+',fields[2]) is not None,'append');total+=len(fields[2]);queries.append((kind,p,fields[2]))
  else:queries.append((kind,p,''))
 require(total<=1000000,'sum append');return n,tuple(queries)

@lru_cache(maxsize=32)
def domino_covered_matching(h:int,w:int,a:tuple[int,...])->int:
 n=h*w;limit=1<<n;adj=[0]*n
 for i in range(n):
  for j in (i-w,i+w,i-1,i+1):
   if 0<=j<n and (abs(j-i)==w or j//w==i//w) and (j!=i):adj[i]|=1<<j
 # Width one needs only vertical adjacency; the row test prevents wraparound otherwise.
 possible=bytearray(limit);possible[0]=1;xs=[0]*limit;total=0
 for value in a:total^=value
 best=total
 for mask in range(1,limit):
  bit=mask&-mask;i=bit.bit_length()-1;rest=mask^bit;xs[mask]=xs[rest]^a[i]
  if mask.bit_count()%2:continue
  candidates=adj[i]&rest
  while candidates:
   neighbor=candidates&-candidates;candidates^=neighbor
   if possible[rest^neighbor]:possible[mask]=1;best=max(best,total^xs[mask]);break
 return best

def binary_three_phase(s:str)->int:
 before=0;inside=len(s)+1;after=len(s)+1
 for char in s:
  zero=char=='1';one=char=='0';before,inside,after=before+zero,min(before,inside)+one,min(before,inside,after)+zero
 return min(before,inside,after)

def rotation_letter_index(s:str)->str:
 left=next((i for i in range(len(s)-1) if s[i]>s[i+1]),None)
 if left is None:return s
 positions=[[] for _ in range(26)]
 for i,char in enumerate(s):positions[ord(char)-97].append(i)
 boundary=len(s)
 for letter in range(ord(s[left])-96,26):
  row=positions[letter];at=bisect_right(row,left)
  if at<len(row):boundary=min(boundary,row[at])
 return s[:left]+s[left+1:boundary]+s[left]+s[boundary:]

def xor_walk_reverse(n:int,edges:tuple[tuple[int,...],...])->int:
 incoming=[[] for _ in range(n)]
 for a,b,w in edges:incoming[b-1].append((a-1,w))
 seen=[bytearray(1024) for _ in range(n)];seen[n-1][0]=1;queue=deque([(n-1,0)])
 while queue:
  vertex,value=queue.popleft()
  for previous,weight in incoming[vertex]:
   other=value^weight
   if not seen[previous][other]:seen[previous][other]=1;queue.append((previous,other))
 return next((i for i,ok in enumerate(seen[0]) if ok),-1)

def append_persistent_forward(n:int,queries:tuple[tuple[int,int,str],...])->str:
 heads=[0]*(n+1);parents=[-1];pieces=['']
 for kind,p,s in queries:
  if kind==1:heads[p]=heads[0]
  elif kind==3:heads[0]=heads[p]
  else:parents.append(heads[p]);pieces.append(s);heads[p]=len(pieces)-1
 result=[];at=heads[0]
 while at:result.append(pieces[at]);at=parents[at]
 return ''.join(reversed(result))

@lru_cache(maxsize=128)
def regular_cycle_partition(n:int,edges:tuple[tuple[int,...],...])->int:
 existing={tuple(sorted((a-1,b-1))) for a,b in edges};cost={};limit=1<<n
 for mask in range(1,limit):
  vertices=[i for i in range(n) if mask>>i&1]
  if len(vertices)<3:continue
  first=vertices[0];best=n+1
  for order in permutations(vertices[1:]):
   if order[0]>order[-1]:continue
   cycle=(first,)+order;missing=sum(tuple(sorted((cycle[i-1],cycle[i]))) not in existing for i in range(len(cycle)));best=min(best,missing)
  cost[mask]=best
 @lru_cache(maxsize=None)
 def partition(mask:int)->int:
  if mask==0:return 0
  first=mask&-mask;best=n+1;subset=mask
  while subset:
   if subset&first and subset in cost:best=min(best,cost[subset]+partition(mask^subset))
   subset=(subset-1)&mask
  return best
 # Final 2-regular graph always has N edges: deletions M-kept plus additions N-kept.
 missing=partition(limit-1);return len(edges)-n+2*missing

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc407_d':return str(domino_covered_matching(*cast(tuple[int,int,tuple[int,...]],d)))+'\n'
 if pid=='abc408_d':return ''.join(str(binary_three_phase(s))+'\n' for s in cast(tuple[str,...],d[0]))
 if pid=='abc409_d':return ''.join(rotation_letter_index(s)+'\n' for s in cast(tuple[str,...],d[0]))
 if pid=='abc410_d':return str(xor_walk_reverse(*cast(tuple[int,tuple[tuple[int,...],...]],d)))+'\n'
 if pid=='abc411_d':return append_persistent_forward(*cast(tuple[int,tuple[tuple[int,int,str],...]],d))+'\n'
 return str(regular_cycle_partition(*cast(tuple[int,tuple[tuple[int,...],...]],d)))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));rows:list[str]=[]
 if pid=='abc407_d':
  def board(h:int,w:int,values:list[int])->str:return line([h,w])+''.join(line(values[i*w:(i+1)*w]) for i in range(h))
  rows=[board(1,1,[0]),board(1,1,[(1<<60)-1]),board(1,2,[1,2]),board(2,1,[3,3]),board(2,2,[1,2,4,8])]
  for h,w in ((1,3),(3,1),(2,3),(3,2),(3,3),(1,20),(20,1),(4,3),(3,4),(4,4)):rows.append(board(h,w,[rng.randrange(1<<30) for _ in range(h*w)]))
  rows+=[board(4,5,[1<<i for i in range(20)]),board(5,4,[rng.randrange(1<<60) for _ in range(20)]),board(4,5,[(1<<60)-1]*20)]
 elif pid in ('abc408_d','abc409_d'):
  def pack(strings:list[str])->str:return str(len(strings))+'\n'+''.join(str(len(s))+'\n'+s+'\n' for s in strings)
  if pid=='abc408_d':
   strings=['0','1','01','10','101','010','10101','111000111','0011100','000000','111111','110101001'];rows=[pack([s]) for s in strings];rows.append(pack([''.join(rng.choice('01') for _ in range(i)) for i in range(1,51)]));rows.append(pack(['0','1']*10000));rows.append(pack(['1010101010']*20000));rows.append(pack(['0'*200000]));rows.append(pack(['1'*200000]));rows.append(pack(['10'*100000]))
  else:
   strings=['a','z','ab','ba','aaa','cba','baab','bbab','abacaba','zzza','azzz','dcba','cbacb'];rows=[pack([s]) for s in strings];rows.append(pack([''.join(rng.choice('abcde') for _ in range(i)) for i in range(1,51)]));rows.append(pack(['a']*100000));rows.append(pack(['a'*100000]));rows.append(pack(['z'+'a'*99998+'z']));rows.append(pack(['zy'*50000]))
 elif pid=='abc410_d':
  def graph(n:int,e:list[tuple[int,int,int]])->str:return line([n,len(e)])+''.join(line(v) for v in e)
  rows=[graph(2,[]),graph(2,[(1,2,0)]),graph(2,[(1,2,1023)]),graph(2,[(2,1,1)]),graph(2,[(1,1,7),(1,2,15)]),graph(3,[(1,2,1),(2,1,2),(2,3,7)]),graph(2,[(1,2,1),(1,2,2)]),graph(3,[(1,2,5),(2,2,6),(2,3,7)])]
  for n in range(3,10):rows.append(graph(n,[(rng.randrange(1,n+1),rng.randrange(1,n+1),rng.randrange(1024)) for _ in range(2*n)]))
  rows[14]=graph(1000,[(i,i+1,1023) for i in range(1,979)]+[(979,1000,0),(1000,1,0)]+[(v,v,1<<bit) for v in (1,1000) for bit in range(10)])
  rows+=[graph(1000,[(i,i+1,1023) for i in range(1,1000)]),graph(1000,[(1,1,1<<i) for i in range(10)]+[(i,i+1,rng.randrange(1024)) for i in range(1,990)]+[(990,1000,1023)]),graph(1000,[(i,i+1,1023) for i in range(1,1000)]+[(1000,1,1)])]
 elif pid=='abc411_d':
  def query(n:int,ops:list[tuple[int,int,str]])->str:return line([n,len(ops)])+''.join(f'{k} {p}'+(f' {s}' if k==2 else '')+'\n' for k,p,s in ops)
  rows=[query(1,[(1,1,'')]),query(1,[(3,1,'')]),query(1,[(2,1,'a')]),query(1,[(2,1,'a'),(3,1,'')]),query(2,[(2,1,'ab'),(3,1,''),(1,2,''),(2,1,'x'),(2,2,'y'),(3,2,'')])]
  for count in range(6,16):rows.append(query(4,[(k:=rng.randrange(1,4),rng.randrange(1,5),rng.choice(['a','bc','xyz']) if k==2 else '') for _ in range(count)]))
  rows.append(query(200000,[(2,200000,'z'*1000000)]+[(1,1,'')]*199998+[(3,200000,'')]))
  rows.append(query(200000,[(2,1,'abcde')]*199999+[(3,1,'')]))
  rows.append(query(200000,[(2,1,'a'*1000000),(3,1,'')]+[(1,200000,'') if i%2==0 else (3,200000,'') for i in range(199998)]))
 else:
  def graph(n:int,e:list[tuple[int,int]])->str:return line([n,len(e)])+''.join(line(v) for v in e)
  rows=[graph(3,[]),graph(3,[(1,2)]),graph(3,[(1,2),(2,3)]),graph(3,[(1,2),(2,3),(3,1)]),graph(4,[(1,2),(2,3),(3,4),(4,1)]),graph(6,[(1,2),(2,3),(3,1),(4,5),(5,6),(6,4)])]
  for n in range(4,8):
   all_edges=list(combinations(range(1,n+1),2))
   for density in (0.2,0.5):rows.append(graph(n,[e for e in all_edges if rng.random()<density]))
  rows+=[graph(8,[]),graph(8,[(1,i) for i in range(2,9)]),graph(8,[(i,i+1) for i in range(1,8)]+[(8,1)]),graph(8,list(combinations(range(1,9),2)))]
 require(len(rows)==len(set(rows))==18,'18 distinct');return [{'input':s,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i>=15 else 'varied'} for i,s in enumerate(rows)]

REFERENCE_CODE={
 'abc407_d':'''import sys
h,w,*a=map(int,sys.stdin.buffer.read().split());n=h*w;answer=0
def dfs(i,used,value):
 global answer
 while i<n and used>>i&1:i+=1
 if i==n:answer=max(answer,value);return
 dfs(i+1,used,value^a[i])
 if i%w+1<w and not used>>(i+1)&1:dfs(i+1,used|1<<(i+1),value)
 if i+w<n and not used>>(i+w)&1:dfs(i+1,used|1<<(i+w),value)
dfs(0,0,0);print(answer)
''',
 'abc408_d':'''import sys
it=iter(sys.stdin.buffer.read().split());t=int(next(it));out=[]
for _ in range(t):
 n=int(next(it));s=next(it);prefix=0;low=0;gain=0
 for c in s:
  prefix+=1 if c==49 else -1;gain=max(gain,prefix-low);low=min(low,prefix)
 out.append(str(s.count(49)-gain))
print('\\n'.join(out))
''',
 'abc409_d':'''import sys
it=iter(sys.stdin.buffer.read().split());t=int(next(it));out=[]
for _ in range(t):
 n=int(next(it));s=next(it).decode();left=0
 while left+1<n and s[left]<=s[left+1]:left+=1
 if left+1==n:out.append(s);continue
 right=left+1
 while right+1<n and s[right+1]<=s[left]:right+=1
 out.append(s[:left]+s[left+1:right+1]+s[left]+s[right+1:])
print('\\n'.join(out))
''',
 'abc410_d':'''import sys
n,m,*data=map(int,sys.stdin.buffer.read().split());adj=[[] for _ in range(n)]
for i in range(m):a,b,w=data[3*i:3*i+3];adj[a-1].append((b-1,w))
seen=bytearray(n*1024);seen[0]=1;stack=[0]
while stack:
 state=stack.pop();v=state>>10;x=state&1023
 for u,w in adj[v]:
  nxt=(u<<10)|(x^w)
  if not seen[nxt]:seen[nxt]=1;stack.append(nxt)
print(next((x for x in range(1024) if seen[(n-1)*1024+x]),-1))
''',
 'abc411_d':'''import sys
rows=sys.stdin.buffer.read().splitlines();n,q=map(int,rows[0].split());current=0;pieces=[]
for row in reversed(rows[1:]):
 fields=row.split();k=int(fields[0]);p=int(fields[1])
 if k==3 and current==0:current=p
 elif k==1 and current==p:current=0
 elif k==2 and current==p:pieces.append(fields[2])
print(b''.join(reversed(pieces)).decode())
''',
 'abc412_d':'''import sys,itertools
n,m,*data=map(int,sys.stdin.buffer.read().split());old={tuple(sorted((data[2*i]-1,data[2*i+1]-1))) for i in range(m)};degree=[0]*n;answer=10**9
def build(vertex,chosen):
 global answer
 if vertex==n:
  if all(d==2 for d in degree):answer=min(answer,m+n-2*chosen)
  return
 needed=2-degree[vertex]
 available=[u for u in range(vertex+1,n) if degree[u]<2]
 for targets in itertools.combinations(available,needed):
  degree[vertex]=2
  for u in targets:degree[u]+=1
  build(vertex+1,chosen+sum((vertex,u) in old for u in targets))
  for u in targets:degree[u]-=1
 degree[vertex]=2-needed
build(0,0);print(answer)
'''}
_HINT_ROWS:dict[str,list[str]]={
 'abc407_d':['最初の未処理マスに注目し、残す・右と覆う・下と覆うの候補を試します。','覆ったマスをビット集合で管理します。残す場合だけその値をスコアの XOR に加えます。','dfs(i, used, xor): 使用済みの位置を飛ばす。末尾なら最大値を更新。残す分岐、空いている右・下とドミノを置く分岐を再帰する。'],
 'abc408_d':['1 にする区間の内側と外側で、変更する文字を数えます。空区間も許されます。','区間を 1 にすると、元の 1 は変更を一回節約し、元の 0 は一回余分に変更します。この利得の最大連続区間を求めます。','prefix=low=gain=0。各文字で prefix += (1なら1、0なら-1)、gain=max(gain,prefix-low)、low=min(low,prefix)。答えは元の1の個数-gain。'],
 'abc409_d':['初めて左の文字が右の文字より大きくなる場所を探します。降順の隣接がなければ文字列は変わりません。','最初の降順位置の文字を右へ動かします。その文字以下の文字を越えて進み、それより大きい文字の直前で止めます。','left=最初の S[left]>S[left+1]。なければ S。right=left+1 から S[right+1]<=S[left] の間延ばす。S[:left]+S[left+1:right+1]+S[left]+S[right+1:] を出力。'],
 'abc410_d':['同じ頂点でも、そこまでの XOR が違う状態を区別します。頂点の再訪も必要です。','重みが 1024 未満なので XOR も 0〜1023 です。頂点と XOR の組を一度ずつ探索できます。','seen[1,0]=true、stack=[(1,0)]。辺(v,u,w)で(u,x xor w)が未訪問なら追加。全探索後、seen[N,x]が真となる最小x、なければ-1。'],
 'abc411_d':['最後のサーバー文字列が、どの PC のどの時点の文字列に由来するかを逆向きにたどります。','逆順に処理し、追跡中の PC に対する追加文字だけ保存します。サーバーへの代入と PC への代入は追跡先を切り替えます。','current=サーバー、pieces=[]。逆順の3 pはcurrentがサーバーならpへ、1 pはcurrentがpならサーバーへ、2 p sはcurrentがpならsを保存。piecesを逆順に連結。'],
 'abc412_d':['最終グラフでは、すべての頂点にちょうど二本の辺が必要です。N が小さいので候補を列挙できます。','頂点を順に確定し、その頂点の不足次数だけ後ろの頂点へ辺を張ります。既存の辺を何本残せるか数えます。','build(v, kept): vの次数不足分だけ、次数2未満のu>vから組合せを選ぶ。次数を増やして再帰し戻す。全次数2なら操作数=M+N-2*keptを最小化。']}
REFERENCE_SNIPPETS=REFERENCE_CODE
HINTS:dict[str,tuple[str,str,str]]={pid:(rows[0],rows[1],'疑似コード: '+rows[2]) for pid,rows in _HINT_ROWS.items()}

TITLES={'abc407_d': 'Domino Covering XOR', 'abc408_d': 'Flip to Gather', 'abc409_d': 'String Rotation', 'abc410_d': 'XOR Shortest Walk', 'abc411_d': 'Conflict 2', 'abc412_d': 'Make 2-Regular Graph'}
PUBLISHED_SAMPLES={'abc407_d': [{'input': '3 4\n1 2 3 8\n4 0 7 10\n5 2 4 2\n', 'expected': '15\n'}, {'input': '1 11\n1 2 4 8 16 32 64 128 256 512 1024\n', 'expected': '2047\n'}, {'input': '4 5\n74832 16944 58683 32965 97236\n52995 43262 51959 40883 58715\n13846 24919 65627 11492 63264\n29966 98452 75577 40415 77202\n', 'expected': '131067\n'}], 'abc408_d': [{'input': '3\n5\n10011\n10\n1111111111\n7\n0000000\n', 'expected': '1\n0\n0\n'}, {'input': '5\n2\n01\n10\n1000010011\n12\n111100010011\n3\n111\n8\n00010101\n', 'expected': '0\n2\n3\n0\n2\n'}], 'abc409_d': [{'input': '3\n7\natcoder\n1\nx\n5\nsnuke\n', 'expected': 'acodert\nx\nnsuke\n'}], 'abc410_d': [{'input': '3 3\n1 2 4\n2 3 5\n1 3 2\n', 'expected': '1\n'}, {'input': '4 4\n1 4 7\n4 2 2\n2 3 4\n3 4 1\n', 'expected': '0\n'}, {'input': '999 4\n1 2 9\n2 1 8\n1 2 7\n1 1 6\n', 'expected': '-1\n'}], 'abc411_d': [{'input': '2 6\n2 1 at\n3 1\n2 2 on\n1 2\n2 2 coder\n3 2\n', 'expected': 'atcoder\n'}, {'input': '100000 3\n1 100\n2 300 abc\n3 200\n', 'expected': '\n'}, {'input': '10 10\n2 7 ladxf\n2 7 zz\n2 7 kfm\n3 7\n1 5\n2 5 irur\n3 5\n1 6\n2 6 ptilun\n3 6\n', 'expected': 'ladxfzzkfmirurptilun\n'}], 'abc412_d': [{'input': '5 4\n1 2\n1 5\n2 4\n4 5\n', 'expected': '3\n'}, {'input': '3 0\n', 'expected': '3\n'}, {'input': '6 8\n1 4\n1 5\n2 3\n2 6\n3 4\n3 6\n4 5\n4 6\n', 'expected': '2\n'}, {'input': '8 21\n1 4\n5 7\n8 4\n3 4\n2 5\n8 1\n5 1\n2 8\n2 1\n2 4\n3 1\n6 7\n5 8\n2 7\n6 8\n5 4\n3 8\n7 3\n7 8\n5 3\n7 4\n', 'expected': '13\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
