"""Private ABC419..424 D primary reviewed tasks, no shared writes."""
from __future__ import annotations
from typing import cast
from collections import Counter
from functools import lru_cache
import heapq,random,re
TASKS=tuple(f'abc{n}_d' for n in range(419,425));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES={'abc422_d':'semantic'};CHECKER_IDS={'abc422_d':'abc422_d'};Case=dict[str,str];Data=tuple[object,...]
MOVES={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None,signed:bool=False)->tuple[int,...]:
 pat=r'(?:0|-?[1-9][0-9]*)' if signed else r'(?:0|[1-9][0-9]*)';require(re.fullmatch(pat+r'(?: '+pat+r')*',s) is not None,'integers');a=tuple(map(int,s.split()));require(n is None or len(a)==n,'fields');return a
def line(a:tuple[int,...]|list[int])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc419_d':
  n,m=ints(rows[0],2);require(1<=n<=500000 and 1<=m<=200000 and len(rows)==m+3,'shape');s,t=rows[1:3];require(all(re.fullmatch('[a-z]{'+str(n)+'}',v) is not None for v in (s,t)),'letters');qs=tuple(ints(row,2) for row in rows[3:]);require(all(1<=l<=r<=n for l,r in qs),'ranges');return s,t,qs
 if pid=='abc420_d':
  h,w=ints(rows[0],2);grid=tuple(rows[1:]);require(1<=h<=500 and 1<=w<=500 and len(grid)==h and all(re.fullmatch('[.#SGox?]{'+str(w)+'}',r) is not None for r in grid),'grid');joined=''.join(grid);require(joined.count('S')==joined.count('G')==1,'endpoints');return (grid,)
 if pid=='abc421_d':
  pos=ints(rows[0],4,True);n,m,l=ints(rows[1],3);require(all(-10**9<=v<=10**9 for v in pos) and 1<=n<=10**14 and 1<=m<=100000 and 1<=l<=100000 and len(rows)==2+m+l,'shape');runs=[]
  for row in rows[2:]:
   parts=row.split(' ');require(len(parts)==2 and parts[0] in MOVES,'run direction');size=ints(parts[1],1)[0];require(1<=size<=10**9,'run size');runs.append((parts[0],size))
  a=tuple(runs[:m]);b=tuple(runs[m:]);require(sum(v for _,v in a)==sum(v for _,v in b)==n,'run totals');return pos,n,a,b
 if pid=='abc422_d':
  require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=n<=20 and 0<=k<=10**9,'domain');return n,k
 if pid=='abc423_d':
  n,k=ints(rows[0],2);require(1<=n<=300000 and 1<=k<=10**7 and len(rows)==n+1,'shape');parties=tuple(ints(row,3) for row in rows[1:]);require(all(1<=a<=10**7 and 1<=b<=10**7 and 1<=c<=k for a,b,c in parties),'parties');require(all(parties[i][0]<parties[i+1][0] for i in range(n-1)),'strict arrival');return k,parties
 t=ints(rows[0],1)[0];require(1<=t<=100,'testcases');cases=[];i=1
 for _ in range(t):
  require(i<len(rows),'header');h,w=ints(rows[i],2);require(2<=h<=7 and 2<=w<=7 and i+h<len(rows),'shape');grid=tuple(rows[i+1:i+h+1]);require(all(re.fullmatch('[.#]{'+str(w)+'}',r) is not None for r in grid),'grid');cases.append(grid);i+=h+1
 require(i==len(rows),'extra');return (tuple(cases),)

def swaps_event_sort(s:str,t:str,qs:tuple[tuple[int,...],...])->str:
 events=sorted([x for l,r in qs for x in (l-1,r)]);result=[];prev=0;parity=0
 for x in events:
  result.append((t if parity else s)[prev:x]);parity^=1;prev=x
 result.append((t if parity else s)[prev:]);return ''.join(result)

def maze_reverse_dijkstra(grid:tuple[str,...])->int:
 h=len(grid);w=len(grid[0]);flat=''.join(grid);start=flat.index('S');goal=flat.index('G');inf=10**9;dist=[inf]*(2*h*w);heap=[]
 for p in (0,1):dist[2*goal+p]=0;heap.append((0,2*goal+p))
 while heap:
  d,state=heapq.heappop(heap)
  if d!=dist[state]:continue
  cell,p=divmod(state,2)
  if cell==start and p==0:return d
  ch=flat[cell];prior=p^(ch=='?')
  if ch=='#' or (ch=='o' and prior==1) or (ch=='x' and prior==0):continue
  r,c=divmod(cell,w)
  for rr,cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
   if not(0<=rr<h and 0<=cc<w):continue
   q=rr*w+cc;source=flat[q]
   if source=='#' or (source=='o' and prior==1) or (source=='x' and prior==0):continue
   prev=2*q+prior
   if d+1<dist[prev]:dist[prev]=d+1;heapq.heappush(heap,(d+1,prev))
 return -1

def meetings_events(pos:tuple[int,...],n:int,a:tuple[tuple[str,int],...],b:tuple[tuple[str,int],...])->int:
 events:dict[int,list[int]]={}
 for sign,runs in ((1,a),(-1,b)):
  time=0
  for direction,size in runs:
   dr,dc=MOVES[direction];e=events.setdefault(time,[0,0]);e[0]+=sign*dr;e[1]+=sign*dc;time+=size;e=events.setdefault(time,[0,0]);e[0]-=sign*dr;e[1]-=sign*dc
 times=sorted(events);vr=vc=0;br=pos[0]-pos[2];bc=pos[1]-pos[3];answer=0
 for i,t0 in enumerate(times[:-1]):
  dr,dc=events[t0];vr+=dr;vc+=dc;br-=dr*t0;bc-=dc*t0;t1=times[i+1]
  if vr==vc==0:
   if br==bc==0:answer+=t1-t0
  else:
   speed,intercept=(vr,br) if vr else (vc,bc)
   if (-intercept)%speed==0:
    time=(-intercept)//speed
    if t0<time<=t1 and vr*time+br==vc*time+bc==0:answer+=1
 return answer

def binomial_balance_bit_reversal(n:int,k:int)->tuple[int,list[int]]:
 count=1<<n;base,extra=divmod(k,count);a=[base]*count
 rev=0
 for i in range(extra):
  a[rev]+=1;bit=count>>1
  while bit and rev&bit:rev^=bit;bit>>=1
  rev^=bit
 return int(extra!=0),a

def verify_balanced(n:int,k:int,actual:str)->bool:
 body=actual.removesuffix('\n')
 if '\r' in body or body.endswith('\n'):return False
 rows=body.split('\n')
 if len(rows)!=2 or re.fullmatch(r'[+-]?[0-9]+',rows[0]) is None:return False
 values=rows[1].split(' ')
 if len(values)!=(1<<n) or any(re.fullmatch(r'[+-]?[0-9]+',v) is None or len(v.lstrip('+-').lstrip('0'))>10 for v in values):return False
 a=[(-1 if v.startswith('-') else 1)*int(v.lstrip('+-').lstrip('0') or '0') for v in values];u_text=rows[0].lstrip('+-').lstrip('0');
 if len(u_text)>1:return False
 u=(-1 if rows[0].startswith('-') else 1)*int(u_text or '0');want=int(k%(1<<n)!=0)
 if u!=want or any(v<0 for v in a) or sum(a)!=k:return False
 for _ in range(n):
  if max(a)-min(a)>u:return False
  a=[a[i]+a[i+1] for i in range(0,len(a),2)]
 return True

class DepartureNode:
 __slots__=('key','weight','total','height','left','right')
 def __init__(self,key:int,weight:int)->None:
  self.key=key;self.weight=weight;self.total=weight;self.height=1;self.left:DepartureNode|None=None;self.right:DepartureNode|None=None
 def update(self)->None:
  self.total=self.weight+(self.left.total if self.left else 0)+(self.right.total if self.right else 0);self.height=1+max(self.left.height if self.left else 0,self.right.height if self.right else 0)
def departure_rotate_left(root:DepartureNode)->DepartureNode:
 child=root.right;assert child is not None;root.right=child.left;child.left=root;root.update();child.update();return child
def departure_rotate_right(root:DepartureNode)->DepartureNode:
 child=root.left;assert child is not None;root.left=child.right;child.right=root;root.update();child.update();return child
def departure_insert(root:DepartureNode|None,key:int,weight:int)->DepartureNode:
 if root is None:return DepartureNode(key,weight)
 if key==root.key:root.weight+=weight
 elif key<root.key:root.left=departure_insert(root.left,key,weight)
 else:root.right=departure_insert(root.right,key,weight)
 root.update();balance=(root.left.height if root.left else 0)-(root.right.height if root.right else 0)
 if balance>1:
  assert root.left is not None
  if key>root.left.key:root.left=departure_rotate_left(root.left)
  return departure_rotate_right(root)
 if balance< -1:
  assert root.right is not None
  if key<root.right.key:root.right=departure_rotate_right(root.right)
  return departure_rotate_left(root)
 return root

def waiting_weighted_order(k:int,parties:tuple[tuple[int,...],...])->list[int]:
 root:DepartureNode|None=None;total=0;last=0;out=[]
 for arrival,duration,people in parties:
  time=max(arrival,last);node=root;departed=0
  while node:
   if node.key<=time:departed+=node.weight+(node.left.total if node.left else 0);node=node.right
   else:node=node.left
  threshold=total-(k-people)
  if departed<threshold:
   node=root;rank=threshold
   while node:
    left=node.left.total if node.left else 0
    if rank<=left:node=node.left
    elif rank<=left+node.weight:time=max(time,node.key);break
    else:rank-=left+node.weight;node=node.right
  out.append(time);last=time;root=departure_insert(root,time+duration,people);total+=people
 return out

def erasing_hitting_cover(grid:tuple[str,...])->int:
 h=len(grid);w=len(grid[0]);edges=[]
 for r in range(h-1):
  for c in range(w-1):
   cells=(r*w+c,r*w+c+1,(r+1)*w+c,(r+1)*w+c+1)
   if all(grid[p//w][p%w]=='#' for p in cells):edges.append(cells)
 if not edges:return 0
 covers=[0]*(h*w)
 for i,edge in enumerate(edges):
  for v in edge:covers[v]|=1<<i
 def lower(mask:int)->int:
  used=0;bound=0
  while mask:
   bit=mask&-mask;mask-=bit;cells=edges[bit.bit_length()-1];cellmask=sum(1<<v for v in cells)
   if not used&cellmask:used|=cellmask;bound+=1
  return bound
 @lru_cache(None)
 def solve(mask:int)->int:
  if not mask:return 0
  low=lower(mask);remaining=mask;high=0
  while remaining:
   choice=max(covers,key=lambda c:(c&remaining).bit_count());remaining&=~choice;high+=1
  if high==low:return low
  bit=mask&-mask;edge=edges[bit.bit_length()-1]
  for v in sorted(edge,key=lambda v:-(covers[v]&mask).bit_count()):
   nxt=mask&~covers[v]
   if 1+lower(nxt)>=high:continue
   high=min(high,1+solve(nxt))
   if high==low:break
  return high
 return solve((1<<len(edges))-1)

def oracle(pid:str,raw:str)->str:
 data=validate(pid,raw)
 if pid=='abc419_d':return swaps_event_sort(cast(str,data[0]),cast(str,data[1]),cast(tuple[tuple[int,...],...],data[2]))+'\n'
 if pid=='abc420_d':return str(maze_reverse_dijkstra(cast(tuple[str,...],data[0])))+'\n'
 if pid=='abc421_d':return str(meetings_events(cast(tuple[int,...],data[0]),cast(int,data[1]),cast(tuple[tuple[str,int],...],data[2]),cast(tuple[tuple[str,int],...],data[3])))+'\n'
 if pid=='abc422_d':
  u,a=binomial_balance_bit_reversal(cast(int,data[0]),cast(int,data[1]));return str(u)+'\n'+line(a)
 if pid=='abc423_d':return ''.join(str(v)+'\n' for v in waiting_weighted_order(cast(int,data[0]),cast(tuple[tuple[int,...],...],data[1])))
 return ''.join(str(erasing_hitting_cover(g))+'\n' for g in cast(tuple[tuple[str,...],...],data[0]))
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:
  data=validate(pid,raw)
  if mode not in (None,OUTPUT_MODES.get(pid,'exact')):return False
  if pid=='abc422_d':return verify_balanced(cast(int,data[0]),cast(int,data[1]),actual)
  return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError,RecursionError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc419_d':'''import sys
r=sys.stdin.buffer; n,m=map(int,r.readline().split());s=r.readline().strip().decode();t=r.readline().strip().decode();diff=bytearray(n+1)
for _ in range(m):
 l,h=map(int,r.readline().split());diff[l-1]^=1;diff[h]^=1
p=0;out=[]
for i in range(n):p^=diff[i];out.append(t[i] if p else s[i])
print(''.join(out))
''',
'abc420_d':'''import sys
from collections import deque
r=sys.stdin.buffer;h,w=map(int,r.readline().split());a=''.join(r.readline().strip().decode() for _ in range(h));s=a.index('S');g=a.index('G');d=[-1]*(2*h*w);d[2*s]=0;q=deque([2*s]);answer=-1
while q:
 z=q.popleft();v,p=divmod(z,2)
 if v==g:answer=d[z];break
 row,col=divmod(v,w)
 for rr,cc in ((row-1,col),(row+1,col),(row,col-1),(row,col+1)):
  if not(0<=rr<h and 0<=cc<w):continue
  u=rr*w+cc;ch=a[u]
  if ch=='#' or (ch=='o' and p) or (ch=='x' and not p):continue
  np=p^(ch=='?');nxt=2*u+np
  if d[nxt]<0:d[nxt]=d[z]+1;q.append(nxt)
print(answer)
''',
'abc421_d':'''import sys
r=sys.stdin.buffer;rt,ct,ra,ca=map(int,r.readline().split());n,m,l=map(int,r.readline().split());a=[r.readline().split() for _ in range(m)];b=[r.readline().split() for _ in range(l)];a=[(d.decode(),int(v)) for d,v in a];b=[(d.decode(),int(v)) for d,v in b];moves={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)};i=j=0;left=a[0][1];right=b[0][1];dr=rt-ra;dc=ct-ca;answer=0
while i<m and j<l:
 size=min(left,right);ar,ac=moves[a[i][0]];br,bc=moves[b[j][0]];vr=ar-br;vc=ac-bc
 if vr==vc==0:
  if dr==dc==0:answer+=size
 else:
  speed,diff=(vr,dr) if vr else (vc,dc)
  if (-diff)%speed==0:
   step=(-diff)//speed
   if 1<=step<=size and dr+vr*step==dc+vc*step==0:answer+=1
 dr+=vr*size;dc+=vc*size;left-=size;right-=size
 if left==0:
  i+=1
  if i<m:left=a[i][1]
 if right==0:
  j+=1
  if j<l:right=b[j][1]
print(answer)
''',
'abc422_d':'''import sys
n,k=map(int,sys.stdin.buffer.read().split());u=int(k%(1<<n)!=0);values=[k]
for _ in range(n):values=[part for v in values for part in (v//2,v-v//2)]
print(u);print(*values)
''',
'abc423_d':'''import sys,heapq
r=sys.stdin.buffer;n,k=map(int,r.readline().split());heap=[];inside=0;time=0;out=[]
for _ in range(n):
 a,b,c=map(int,r.readline().split());time=max(time,a)
 while heap and heap[0][0]<=time:
  departure,people=heapq.heappop(heap);inside-=people
 while inside+c>k:
  time=heap[0][0]
  while heap and heap[0][0]<=time:
   departure,people=heapq.heappop(heap);inside-=people
 heapq.heappush(heap,(time+b,c));inside+=c;out.append(str(time))
print('\\n'.join(out))
''',
'abc424_d':'''import sys
r=sys.stdin.buffer;t=int(r.readline());out=[]
for _ in range(t):
 h,w=map(int,r.readline().split());grid=[r.readline().strip().decode() for _ in range(h)];rows=[sum(1<<i for i,c in enumerate(row) if c=='#') for row in grid];limit=1<<w;adj=[v&(v>>1) for v in range(limit)];dp={0:0}
 for row in rows:
  choices=[];v=row
  while True:
   choices.append((v,row.bit_count()-v.bit_count()))
   if v==0:break
   v=(v-1)&row
  nxt={}
  for cur,cost in choices:
   best=1000
   for prev,old in dp.items():
    if not adj[cur]&adj[prev]:best=min(best,old+cost)
   nxt[cur]=best
  dp=nxt
 out.append(str(min(dp.values())))
print('\\n'.join(out))
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc419_d':
  def build(s:str,t:str,qs:list[tuple[int,int]])->str:return f'{len(s)} {len(qs)}\n{s}\n{t}\n'+''.join(line(q) for q in qs)
  raws=[build('a','b',[(1,1)]),build('a','a',[(1,1)]),build('a','b',[(1,1)]*2),build('abcd','wxyz',[(1,4),(2,3),(1,1)])]
  while len(raws)<16:
   n=len(raws)+2;qs=[tuple(sorted((rng.randint(1,n),rng.randint(1,n)))) for _ in range(2*len(raws))];raws.append(build(''.join(rng.choice('abc') for _ in range(n)),''.join(rng.choice('xyz') for _ in range(n)),qs))
  raws+=[build('a'*500000,'z'*500000,[(i,i+300000) for i in range(1,200001)]),build('a'*500000,'z'*500000,[(1,500000)]*200000)]
 elif pid=='abc420_d':
  def build(g:list[str])->str:return f'{len(g)} {len(g[0])}\n'+'\n'.join(g)+'\n'
  raws=[build(['SG']),build(['S#G']),build(['SxG']),build(['SoG']),build(['S?xG']),build(['S?oG']),build(['S?o','.#G']),build(['S?x','o?G'])]
  while len(raws)<16:
   h=3+len(raws)%4;w=4+len(raws)%5;g=[''.join(rng.choice('..#ox?') for _ in range(w)) for _ in range(h)];g[0]='S'+g[0][1:];g[-1]=g[-1][:-1]+'G';raws.append(build(g))
  g=['?'*500 for _ in range(500)];g[0]='S'+g[0][1:];g[-1]=g[-1][:-1]+'G';plain=['.'*500 for _ in range(500)];plain[0]='S'+plain[0][1:];plain[-1]=plain[-1][:-1]+'G';raws+=[build(g),build(plain)]
 elif pid=='abc421_d':
  def build(pos:tuple[int,int,int,int],a:list[tuple[str,int]],b:list[tuple[str,int]])->str:return line(pos)+f'{sum(v for _,v in a)} {len(a)} {len(b)}\n'+''.join(f'{d} {v}\n' for d,v in a+b)
  raws=[build((0,0,0,0),[('U',1)],[('U',1)]),build((0,0,0,0),[('U',1)],[('D',1)]),build((2,0,0,0),[('U',1)],[('D',1)]),build((1,0,0,0),[('U',1)],[('D',1)]),build((-10**9,-10**9,10**9,10**9),[('D',10**9),('R',10**9)],[('U',10**9),('L',10**9)])]
  while len(raws)<16:
   n=5+len(raws);pos=tuple(rng.randint(-4,4) for _ in range(4));a=[(rng.choice('UDLR'),1) for _ in range(n)];b=[(rng.choice('UDLR'),1) for _ in range(n)];raws.append(build(cast(tuple[int,int,int,int],pos),a,b))
  raws+=[build((0,0,0,0),[('R',10**9)]*100000,[('R',10**9)]*100000),build((-10**9,-10**9,10**9,10**9),[('U' if i%2 else 'R',10**9) for i in range(100000)],[('D' if i%2 else 'L',10**9) for i in range(100000)])]
 elif pid=='abc422_d':
  raws=[f'{n} {k}\n' for n,k in [(1,0),(1,1),(1,2),(1,10**9),(2,3),(2,4),(2,5),(3,7),(3,8),(3,9),(4,15),(4,16),(4,17),(10,999),(10,1024),(20,0),(20,(1<<20)-1),(20,10**9)]]
 elif pid=='abc423_d':
  def build(k:int,p:list[tuple[int,int,int]])->str:return f'{len(p)} {k}\n'+''.join(line(row) for row in p)
  raws=[build(1,[(1,1,1)]),build(1,[(1,10**7,1)]),build(2,[(1,5,1),(2,1,1),(3,2,1)]),build(1,[(1,2,1),(3,2,1),(5,2,1)]),build(3,[(1,9,2),(2,2,2),(3,1,1),(4,1,1)])]
  while len(raws)<16:
   k=2+len(raws);n=3+len(raws);raws.append(build(k,[(2*i+1,rng.randint(1,20),rng.randint(1,k)) for i in range(n)]))
  raws+=[build(10**7,[(i+1,10**7-i%101,1) for i in range(300000)]),build(10**7,[(10**7-299999+i,10**7,10**7) for i in range(300000)])]
 else:
  def build(cases:list[list[str]])->str:return str(len(cases))+'\n'+''.join(f'{len(g)} {len(g[0])}\n'+'\n'.join(g)+'\n' for g in cases)
  raws=[build([['..','..']]),build([['##','##']]),build([['.#','##']]),build([['###','###']]),build([['####','####','####','####']])]
  while len(raws)<16:
   h=2+len(raws)%6;w=2+(len(raws)*3)%6;g=[''.join('#' if rng.randrange(5) else '.' for _ in range(w)) for _ in range(h)];candidate=build([g])
   if candidate not in raws:raws.append(candidate)
  raws+=[build([[''.join('#' if (r+c+i)%9 else '.' for c in range(7)) for r in range(7)] for i in range(100)]),build([['#'*7]*7 for _ in range(100)])]
 require(len(raws)==len(set(raws))==18,'18 distinct');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i==16 else 'random'} for i,raw in enumerate(raws)]
HINTS={
'abc419_d':('各位置が入れ替わる回数の偶奇だけを考えます。','区間の開始と終了直後に差分の偶奇を記録し、左から累積します。','疑似コード: diff[L-1]^=1,diff[R]^=1。parity=0。各iでparity^=diff[i]。parityが1ならT[i]、0ならS[i]を出力へ追加。'),
'abc420_d':('ドアの状態は、スイッチを踏んだ回数の偶奇で決まります。','位置と偶奇を組にした2HW状態をBFSします。移動先のドアを現在の偶奇で確認し、?に入った場合だけ偶奇を反転します。','疑似コード: dist[S,0]=0、queueへ。隣が壁または現在閉じたドアなら無視。nextParity=parity xor (隣が?)。未訪問状態へ距離+1で追加。Gを初めて取り出した距離、未到達なら-1。'),
'abc421_d':('二人の移動方向が変わらない時間区間をまとめます。','両方の残りrun長の最小値だけ進め、相対位置がゼロになる整数時刻を調べます。初期時刻は数えません。','疑似コード: len=min(残りS,残りT)、相対速度v=moveS-moveT。v==0なら相対位置0でlen加算。それ以外はdiff+t*v=0を両座標で満たす整数1<=t<=lenを1加算。相対位置をlen*v進め、尽きたrunへ移る。'),
'abc422_d':('各段階の部分和をできるだけ均等にすればよいです。','和Kをfloor(K/2)とceil(K/2)へ分ける操作をN段繰り返します。全層の値の差は高々1です。Kが2^Nで割り切れる場合だけ最適値は0です。','疑似コード: values=[K]。N回、各vを[v//2,v-v//2]へ置換。U=(K mod 2^N !=0)。Uとvaluesを出力。最初の層で全値が等しくできない場合、アンバランスさは少なくとも1。'),
'abc423_d':('団体を来訪順に処理し、入店時刻は前の団体より早くなりません。','退店時刻をmin-heapに保存し、満員なら最も早い退店まで時刻を進めます。同時刻の退店を全て先に反映します。','疑似コード: time=max(time,A)。heapから退店<=timeの人数を減らす。inside+C>Kならtime=最小退店とし同時退店を全て除く。time+Bをheapへ入れinside+=C、timeを出力。'),
'abc424_d':('幅が7以下なので、各行で黒のまま残すマスをbitmaskで表せます。','上下の行に共通して隣接する2bitが立つ場合だけ黒2x2ができます。行ごとの削除数を足してDPします。','疑似コード: dp[0]=0。各rowの黒maskの全submask curを列挙。adj(cur)=cur&(cur>>1)。adj(cur)&adj(prev)==0のprevだけから、消したbit数を加え最小化。最後のdp最小値を出力。')}

TITLES={'abc419_d': 'Substr Swap', 'abc420_d': 'Toggle Maze', 'abc421_d': 'RLE Moving', 'abc422_d': 'Least Unbalanced', 'abc423_d': 'Long Waiting', 'abc424_d': '2x2 Erasing 2'}
PUBLISHED_SAMPLES={'abc419_d': [{'input': '5 3\napple\nlemon\n2 4\n1 5\n5 5\n', 'expected': 'lpple\n'}, {'input': '10 5\nlemwrbogje\nomsjbfggme\n5 8\n4 8\n1 3\n6 6\n1 4\n', 'expected': 'lemwrfogje\n'}], 'abc420_d': [{'input': '2 4\nS.xG\n#?o.\n', 'expected': '5\n'}, {'input': '1 5\nSo?oG\n', 'expected': '-1\n'}, {'input': '5 5\nSx?x?\no#o#x\n?o?o?\nx#x#o\n?x?oG\n', 'expected': '10\n'}], 'abc421_d': [{'input': '0 0 4 2\n3 2 1\nR 2\nD 1\nU 3\n', 'expected': '1\n'}, {'input': '1000000000 1000000000 -1000000000 -1000000000\n3000000000 3 3\nL 1000000000\nU 1000000000\nU 1000000000\nD 1000000000\nR 1000000000\nU 1000000000\n', 'expected': '1000000001\n'}, {'input': '3 3 3 2\n1 1 1\nL 1\nR 1\n', 'expected': '0\n'}, {'input': '0 0 0 0\n1 1 1\nL 1\nR 1\n', 'expected': '0\n'}], 'abc422_d': [{'input': '1 11\n', 'expected': '1\n5 6\n'}, {'input': '3 56\n', 'expected': '0\n7 7 7 7 7 7 7 7\n'}], 'abc423_d': [{'input': '4 10\n30 300 3\n60 45 4\n90 45 5\n120 45 2\n', 'expected': '30\n60\n105\n120\n'}, {'input': '4 10\n30 300 10\n60 45 2\n90 45 3\n120 45 4\n', 'expected': '30\n330\n330\n330\n'}, {'input': '10 24\n279290 9485601 1\n1094410 8022270 4\n1314176 7214745 5\n1897674 5924694 10\n1921802 5769841 4\n2506394 2765234 2\n2558629 2727489 9\n2681289 4061363 5\n3022540 2291905 3\n4407692 1313036 8\n', 'expected': '279290\n1094410\n1314176\n1897674\n1921802\n7691643\n7822368\n8528921\n8528921\n10549857\n'}], 'abc424_d': [{'input': '2\n5 5\n####.\n##.##\n#####\n.####\n##.#.\n2 2\n..\n..\n', 'expected': '3\n0\n'}]}
SAMPLE_COUNTS={'abc419_d': 2, 'abc420_d': 3, 'abc421_d': 4, 'abc422_d': 2, 'abc423_d': 3, 'abc424_d': 1}
