"""ABC062–064 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS=('abc062_b','abc063_b','abc064_b')
INT=re.compile(r'(?:0|[1-9][0-9]*)',re.ASCII)
LOWER=re.compile(r'[a-z]+',re.ASCII)

def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc062_b':
        if not lines: raise ValueError('missing header')
        h=lines[0].split(' ')
        if len(h)!=2 or any(INT.fullmatch(x) is None for x in h): raise ValueError('header')
        H,W=map(int,h)
        if not (1<=H<=100 and 1<=W<=100) or len(lines)!=H+1: raise ValueError('shape')
        grid=lines[1:]
        if any(len(s)!=W or LOWER.fullmatch(s) is None for s in grid): raise ValueError('grid')
        return H,W,grid
    if pid=='abc063_b':
        if len(lines)!=1 or not (2<=len(lines[0])<=26) or LOWER.fullmatch(lines[0]) is None:
            raise ValueError('string')
        return lines[0]
    if len(lines)!=2 or INT.fullmatch(lines[0]) is None: raise ValueError('line count/header')
    n=int(lines[0]); t=lines[1].split(' ')
    if not (1<=n<=100) or len(t)!=n or any(INT.fullmatch(x) is None for x in t): raise ValueError('positions')
    a=list(map(int,t))
    if any(not 0<=x<=1000 for x in a): raise ValueError('range')
    return n,a

def independent_check(pid:str,raw:str,output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc062_b':
        H,W,g=value
        exp=['#'*(W+2),*('#'+s+'#' for s in g),'#'*(W+2)]
        return output=='\n'.join(exp)
    if pid=='abc063_b':
        s=value
        # Independent pairwise duplicate scan rather than set-size equality.
        varied=all(s[i]!=s[j] for i in range(len(s)) for j in range(i+1,len(s)))
        return output==('yes' if varied else 'no')
    n,a=value
    # Any route visiting every point on a line must span the extreme coordinates.
    return output==str(max(a)-min(a))

def generate(pid:str,seed:int=68)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v68:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc062_b':
        def fmt(g): return f'{len(g)} {len(g[0])}\n'+'\n'.join(g)+'\n'
        fixtures=[['a'],['abc'],['a','b'],['abc','arc'],['zz','aa'],['abcdef'],['a','b','c','d'],['abcde','fghij'],['x'*10],['a'*10,'z'*10],['az','by','cx'],['qwerty','asdfgh','zxcvbn']]
        for g in fixtures: add('boundary' if len(g)==1 or len(g[0])==1 else 'normal',fmt(g))
        while len(rows)<17:
            H=rng.randint(1,8); W=rng.randint(1,12)
            g=[''.join(chr(97+rng.randrange(26)) for _ in range(W)) for _ in range(H)]
            add('random',fmt(g))
        g=[''.join(chr(97+(i+j)%26) for j in range(100)) for i in range(100)]
        add('constraint_max',fmt(g))
    elif pid=='abc063_b':
        fixtures=['aa','ab','aba','abc','abcdefghijklmnopqrstuvwxyz','abcdefghijklmnopqrstuvwxyy','zz','no','different','uncopyrightable','qwertyuiop','abcdefghijklmnopqrstuvwxya']
        for s in fixtures: add('boundary' if len(s) in (2,26) else 'normal',s+'\n')
        while len(rows)<17:
            L=rng.randint(2,26); s=''.join(chr(97+rng.randrange(26)) for _ in range(L)); add('random',s+'\n')
        add('constraint_max','zyxwvutsrqponmlkjihgfedcba\n')
    else:
        def fmt(a): return f'{len(a)}\n'+' '.join(map(str,a))+'\n'
        fixtures=[[0],[1000],[5],[0,1000],[1,1],[2,3,7,9],[3,1,4,1,5,9,2,6],[10,0,10],[500,500,500],[0,1,2,3,4],[999,1000],[100,900,100,900]]
        for a in fixtures: add('boundary' if len(a)==1 or 0 in a or 1000 in a else 'normal',fmt(a))
        while len(rows)<17:
            n=rng.randint(1,30); a=[rng.randint(0,1000) for _ in range(n)]; add('random',fmt(a))
        a=[0,1000]+[(i*37)%1001 for i in range(98)]
        add('constraint_max',fmt(a))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
