"""Hints based on the public official statements of ABC059–061 B."""
HINTS_V67 = {
    'abc059_b': (
        '値が通常の整数型に収まるとは限りません。10進表記そのものから大小を判断できないか考えてください。',
        '正の整数で先頭0がないので、まず桁数を比較します。桁数が同じなら文字列の辞書順比較が数値の大小と一致します。',
        '疑似コード:\na,b=入力文字列\nif len(a)!=len(b): 桁数が大きい方を出力\nelif a==b: EQUAL\nelif a>b: GREATER\nelse: LESS',
    ),
    'abc060_b': (
        '選ぶ整数はすべてAの倍数です。合計として作れる値全体を、Bで割った余りだけに注目して考えてください。',
        '合計は正のAの倍数なので、A,2A,3A,... のBでの余りを調べれば十分です。余りは高々B種類で周期になります。',
        '疑似コード:\ncur=0\nfor i in 1..B:\n  cur=(cur+A)%B\n  if cur==C: print("YES"); stop\nprint("NO")',
    ),
    'abc061_b': (
        '各道路は、接続している二つの都市の答えにそれぞれ1本ずつ寄与します。',
        '長さNの次数配列を0で初期化し、道路(a,b)を読むたびdeg[a-1]とdeg[b-1]を1増やします。多重辺も1本ずつ数えます。',
        '疑似コード:\ndeg=[0]*N\nfor a,b in roads:\n  deg[a-1]+=1\n  deg[b-1]+=1\nfor x in deg: print(x)',
    ),
}
