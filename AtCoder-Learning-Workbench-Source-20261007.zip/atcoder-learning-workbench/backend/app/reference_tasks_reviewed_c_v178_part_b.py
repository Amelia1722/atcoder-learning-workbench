"""Parity DP, factorial ranks, prefix counts and lazy height histograms."""
from __future__ import annotations
from bisect import bisect_left
from math import factorial
from collections import Counter
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(467,473))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');k=int(pid[3:6])
    if k==467:
        require(len(rows)==3,'shape');n,m=ints(rows[0],2);require(2<=n<=200000 and m==2,'size/modulus');a,b=ints(rows[1],n),ints(rows[2],n-1);require(all(v in (0,1) for seq in (a,b) for v in seq),'bits');return a,b
    if k==468:
        require(len(rows)==3,'shape');n=ints(rows[0],1)[0];p,q=ints(rows[1],n),ints(rows[2],n);require(1<=n<=10 and set(p)==set(q)==set(range(1,n+1)),'permutations');return p,q
    if k==469:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require(1<=n<=800000 and len(rows[1])==n and set(rows[1])<={'o','x'},'bags');return (rows[1],)
    if k==470:
        n,q=ints(rows[0],2);require(1<=n<=500000 and 1<=q<=500000 and len(rows)==q+1,'size');queries=[]
        for row in rows[1:]:
            v=ints(row);require(v==(2,) or (len(v)==2 and v[0]==1 and 1<=v[1]<=n),'query');queries.append(v)
        return n,tuple(queries)
    if k==471:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=300000 and len(set(a))==n and all(-10**9<=v<=10**9 and v!=0 for v in a),'coordinates');return (a,)
    require(len(rows)==2,'shape');n,m,limit=ints(rows[0],3);a=ints(rows[1],n);require(1<=m<=n<=200000 and 1<=limit<=10**15 and all(1<=v<=10**9 for v in a),'snacks');return m,limit,a

def _rank(p:tuple[int,...])->int:
    available=list(range(1,len(p)+1));rank=0
    for j,v in enumerate(p):index=available.index(v);rank+=index*factorial(len(p)-j-1);available.pop(index)
    return rank

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);k=int(pid[3:6])
    if k==467:
        a,b=cast(tuple[tuple[int,...],tuple[int,...]],data);dp=[int(a[0]!=0),int(a[0]!=1)]
        for j,edge in enumerate(b,1):dp=[dp[edge]+int(a[j]!=0),dp[edge^1]+int(a[j]!=1)]
        return str(min(dp))
    if k==468:
        p,q=cast(tuple[tuple[int,...],tuple[int,...]],data);return str(max(0,_rank(q)-_rank(p)-1))
    if k==469:
        s=cast(str,data[0]);prefix=[0]
        for c in s:prefix.append(prefix[-1]+int(c=='x'))
        return '\n'.join(str(min(len(s),bisect_left(prefix,j))) for j in range(1,len(s)+1))
    if k==470:
        n,queries=cast(tuple[int,tuple[tuple[int,...],...]],data);base=[0]*n;hist:dict[int,int]={};offset=answer=0;out=[]
        def change(v:int,delta:int)->None:
            hist[v]=hist.get(v,0)+delta
            if hist[v]==0:del hist[v]
        for query in queries:
            if query[0]==1:
                x=query[1]-1;old=max(0,base[x]-offset);answer^=old^(old+1)
                if old:change(base[x],-1)
                base[x]=offset+old+1;change(base[x],1)
            else:
                offset+=1;answer=0;hist.pop(offset,None)
                for value,count in hist.items():
                    if count%2:answer^=value-offset
            out.append(str(answer))
        return '\n'.join(out)
    if k==471:
        values=sorted((*cast(tuple[int,...],data[0]),0));n=len(values);pivot=values.index(0);previous=[j-1 for j in range(n)];following=[j+1 for j in range(n)];left,right=previous[pivot],following[pivot];position=answer=0
        for _ in range(n-1):
            if left>=0 and (right==n or position-values[left]<=values[right]-position):j=left
            else:j=right
            answer+=abs(values[j]-position);position=values[j]
            a,b=previous[j],following[j]
            if a>=0:following[a]=b
            if b<n:previous[b]=a
            if j==left:left=a
            else:right=b
        return str(answer)
    m,limit,a=cast(tuple[int,int,tuple[int,...]],data);prefix=[0];out=[]
    for j,v in enumerate(a):
        accept=prefix[-1]-prefix[max(0,j-m+1)]+v<=limit;out.append('Yes' if accept else 'No');prefix.append(prefix[-1]+(v if accept else 0))
    return '\n'.join(out)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc467_c':"n,m=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));best=n\nfor first in (0,1):\n value=first;cost=value!=a[0]\n for j in range(1,n):value^=b[j-1];cost+=value!=a[j]\n best=min(best,cost)\nprint(best)\n",
'abc468_c':"from itertools import permutations\nn=int(input());p=tuple(map(int,input().split()));q=tuple(map(int,input().split()));print(sum(p<r<q for r in permutations(range(1,n+1))))\n",
'abc469_c':"n=int(input());s=input();ends=[j+1 for j,c in enumerate(s) if c=='x'];print('\\n'.join(str(ends[k-1] if k<=len(ends) else n) for k in range(1,n+1)))\n",
'abc470_c':"import sys\nv=iter(map(int,sys.stdin.buffer.read().split()));n=next(v);q=next(v);a=[0]*n;active=[];present=[False]*n;answer=0;out=[]\nfor _ in range(q):\n t=next(v)\n if t==1:\n  j=next(v)-1;answer^=a[j];a[j]+=1;answer^=a[j]\n  if not present[j]:present[j]=True;active.append(j)\n else:\n  i=0\n  while i<len(active):\n   j=active[i];answer^=a[j];a[j]-=1;answer^=a[j]\n   if a[j]==0:present[j]=False;active[i]=active[-1];active.pop()\n   else:i+=1\n out.append(str(answer))\nprint('\\n'.join(out))\n",
'abc471_c':"n=int(input());a=list(map(int,input().split()));left=sorted((v for v in a if v<0),reverse=True);right=sorted(v for v in a if v>0);i=j=x=answer=0\nwhile i<len(left) or j<len(right):\n if i<len(left) and (j==len(right) or x-left[i]<=right[j]-x):y=left[i];i+=1\n else:y=right[j];j+=1\n answer+=abs(y-x);x=y\nprint(answer)\n",
'abc472_c':"n,m,k=map(int,input().split());a=list(map(int,input().split()));eaten=[0]*n;total=0;out=[]\nfor j,v in enumerate(a):\n if j>=m:total-=eaten[j-m]\n if total+v<=k:eaten[j]=v;total+=v;out.append('Yes')\n else:out.append('No')\nprint('\\n'.join(out))\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');k=int(pid[3:6]);rng=random.Random(17800+k);raws:list[str]=[]
    if k==467:
        def adjacent(a:list[int],b:list[int])->str:return f'{len(a)} 2\n'+line(a)+line(b)
        raws=[adjacent([0,0],[0]),adjacent([0,0],[1]),adjacent([1,1],[0]),adjacent([0,1],[0])]+[adjacent([rng.randrange(2) for _ in range(n)],[rng.randrange(2) for _ in range(n-1)]) for n in range(3,16)]+[adjacent([1]*200000,[1]*199999)]
    elif k==468:
        def perm(p:list[int],q:list[int])->str:return f'{len(p)}\n'+line(p)+line(q)
        raws=[perm([1],[1]),perm([1,2],[2,1]),perm([2,1],[1,2]),perm([1,2],[1,2])]
        for j in range(13):
            n=3+j%5;p=list(range(1,n+1));q=p[:];rng.shuffle(p);rng.shuffle(q);raws.append(perm(p,q))
        raws.append(perm(list(range(1,11)),list(range(10,0,-1))))
    elif k==469:raws=[f'{len(s)}\n{s}\n' for s in ('o','x','ox','xo')]+[f'{n}\n'+''.join(rng.choice('ox') for _ in range(n))+'\n' for n in range(3,15)]+['800000\n'+'o'*800000+'\n','800000\n'+'ox'*400000+'\n']
    elif k==470:
        def queries(n:int,q:list[tuple[int,...]])->str:return f'{n} {len(q)}\n'+''.join(line(v) for v in q)
        raws=[queries(1,[(1,1)]),queries(1,[(2,)]),queries(2,[(1,1),(1,2),(2,)]),queries(1,[(1,1)]*8+[(2,)]*8)]
        for n in range(3,15):raws.append(queries(n,[(2,) if rng.randrange(3)==0 else (1,rng.randint(1,n)) for _ in range(3*n)]))
        raws.append(queries(1,[(1,1)]*500000))
        raws.append(queries(500000,[(1,j) for j in range(1,250001)]+[(2,)]*249999+[(1,500000)]))
    elif k==471:
        def cookies(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[cookies([1]),cookies([-1]),cookies([-1,1]),cookies([-1,-4,2,-11]),cookies([-10**9]),cookies([10**9])]+[cookies(rng.sample([v for v in range(-100,101) if v],n)) for n in range(5,16)]+[cookies(list(range(-150000,0))+list(range(999850001,1000000001)))]
    else:
        def snacks(a:list[int],m:int,limit:int)->str:return f'{len(a)} {m} {limit}\n'+line(a)
        raws=[snacks([1],1,1),snacks([2],1,1),snacks([1,1],1,1),snacks([1,1,1],2,1)]+[snacks([rng.randint(1,30) for _ in range(n)],1+n%3,10+n) for n in range(4,17)]+[snacks([10**9]*200000,200000,10**15)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]

HINTS={
'abc467_c':('M=2なので各要素で重要なのは偶奇です。','先頭の偶奇を決めると、隣接和の条件から残りは全て決まります。','疑似コード: first=0,1それぞれでtarget=first; cost=(target!=A[0]); j=1..N-1でtarget^=B[j-1],cost+=(target!=A[j]); 小さいcostを出力。'),
'abc468_c':('Nが10以下なので全ての順列を調べられます。','順列を列挙し、辞書順でPより大きくQより小さいものを数えます。','疑似コード: answer=0; permutations(1..N)の各RでP<R<Qならanswer++; answerを出力。'),
'abc469_c':('当たり袋を交換すると、はずれ袋を受け取った時だけ当たり袋の数が減ります。','最初のk袋を受け取ることは、先頭からk番目のはずれまで受け取ることと対応します。','疑似コード: xの1-based位置をendsへ; k=1..Nでk<=len(ends)ならends[k-1]、他はNを出力。'),
'abc470_c':('0より大きい要素だけを管理します。','追加では1要素のXORだけ更新し、減算では正の要素を更新します。減算回数の合計は追加回数以下です。','疑似コード: active配列と在籍フラグとAとxorを管理; 追加/減算の各変更でxor^=old^new; new=0なら末尾との交換でactiveから除く; 各query後xorを出力。'),
'abc471_c':('残ったクッキーのうち、左右それぞれで一番近いものだけを比較します。','負座標を降順、正座標を昇順に並べ、同距離なら負側を選びます。','疑似コード: current=0; 左右の未回収先頭の距離を比較し、同距離なら小さい座標を回収; 距離を加算して先頭を進める。'),
'abc472_c':('食べなかったおやつは合計に含めません。','直近M日の食べたカロリーの合計を保ち、古い日の分を先に引きます。','疑似コード: j>=Mならtotal-=eaten[j-M]; total+A[j]<=KならYes,eaten[j]=A[j],total+=A[j]; 他はNo。')}

TITLES={'abc467_c': 'Adjacent Sums (easy)', 'abc468_c': 'Between P and Q', 'abc469_c': 'Cantrip', 'abc470_c': 'Inc, Dec, Xor', 'abc471_c': 'Cookies and Greedy Takahashi', 'abc472_c': 'On a Diet'}
PUBLISHED_SAMPLES={'abc467_c': [{'input': '3 2\n1 1 1\n1 1\n', 'expected': '1\n'}, {'input': '2 2\n1 1\n0\n', 'expected': '0\n'}, {'input': '10 2\n0 0 0 1 1 0 1 0 1 0\n0 1 0 1 0 1 0 1 0\n', 'expected': '4\n'}], 'abc468_c': [{'input': '3\n1 3 2\n3 1 2\n', 'expected': '2\n'}, {'input': '5\n5 4 2 1 3\n5 1 2 3 4\n', 'expected': '0\n'}, {'input': '7\n3 6 5 2 7 1 4\n4 1 5 7 2 3 6\n', 'expected': '223\n'}], 'abc469_c': [{'input': '5\noxoxo\n', 'expected': '2\n4\n5\n5\n5\n'}, {'input': '3\nooo\n', 'expected': '3\n3\n3\n'}, {'input': '1\nx\n', 'expected': '1\n'}], 'abc470_c': [{'input': '2 5\n1 2\n1 2\n1 1\n2\n2\n', 'expected': '1\n2\n3\n1\n0\n'}, {'input': '3 8\n1 2\n1 3\n1 1\n1 2\n1 1\n2\n1 3\n1 1\n', 'expected': '1\n0\n1\n2\n1\n0\n1\n2\n'}], 'abc471_c': [{'input': '4\n-1 -4 2 -11\n', 'expected': '23\n'}, {'input': '10\n1 2 3 4 5 -1 -2 -3 -4 -6\n', 'expected': '17\n'}], 'abc472_c': [{'input': '5 3 83\n48 73 59 90 21\n', 'expected': 'Yes\nNo\nNo\nNo\nYes\n'}, {'input': '7 4 728\n187 816 349 609 255 308 175\n', 'expected': 'Yes\nNo\nYes\nNo\nYes\nNo\nYes\n'}, {'input': '10 3 1368290936\n216519459 804733999 297250023 775422599 287963235 999315644 354987425 974810607 653940822 117157941\n', 'expected': 'Yes\nYes\nYes\nNo\nYes\nYes\nNo\nNo\nYes\nYes\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
