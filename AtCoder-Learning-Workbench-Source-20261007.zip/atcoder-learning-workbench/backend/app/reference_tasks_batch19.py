"""Task-specific early ABC A specs manually read from official public pages.

No official HTML originals have been downloaded/authenticated in this batch.
The finite two-input task abc020_a cannot supply four distinct category cases.
"""
from __future__ import annotations
import random
import re

SPECS = {
    'abc013_1': ('A', 'X in A..E', 'A\n', '1'),
    'abc014_1': ('けんしょう先生のお菓子配り', '1 <= a,b <= 100; two lines', '7\n3\n', '2'),
    'abc015_1': ('高橋くんの研修', '1 <= len(A),len(B) <= 50; lowercase; unequal lengths', 'isuruu\nisleapyear\n', 'isleapyear'),
    'abc016_1': ('12月6日', 'M,D form calendar date; February 29 is included in published sample', '1 1\n', 'YES'),
    'abc017_1': ('プロコン', 'three lines: s multiple of 10 in [10,990], e in [1,10]', '50 7\n40 8\n30 9\n', '94'),
    'abc018_1': ('豆まき', 'three distinct scores each in [1,100]', '12\n18\n11\n', '2\n1\n3'),
    'abc019_1': ('高橋くんと年齢', 'three integers each in [1,100], ties permitted', '2 3 4\n', '3'),
    'abc020_a': ('クイズ', 'Q is exactly 1 or 2', '1\n', 'ABC'),
}
BATCH19 = {pid: {'sample_input': example, 'sample_output': answer,
    'constraints': bounds, 'source_url': f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}'}
    for pid, (_, bounds, example, answer) in SPECS.items()}
UINT = re.compile(r'(?:0|[1-9][0-9]*)\Z', re.ASCII)
LOWER = re.compile(r'[a-z]{1,50}\Z', re.ASCII)


def _calendar_day_limit(m: int) -> int:
    return 29 if m == 2 else (30 if m in (4, 6, 9, 11) else 31)


def validate(pid: str, data: str) -> tuple[int, ...] | tuple[str, str] | str:
    if pid not in BATCH19 or not isinstance(data, str) or '\r' in data or not data.endswith('\n'):
        raise ValueError('unknown task or malformed input')
    if pid == 'abc013_1':
        if data not in tuple(f'{x}\n' for x in 'ABCDE'):
            raise ValueError('X must be A..E')
        return data[:-1]
    if pid == 'abc015_1':
        lines = data[:-1].split('\n')
        if len(lines) != 2 or any(not LOWER.fullmatch(s) for s in lines) or len(lines[0]) == len(lines[1]):
            raise ValueError('two different-length lowercase strings required')
        return tuple(lines)
    lines = data[:-1].split('\n')
    if pid in ('abc014_1', 'abc018_1', 'abc017_1'):
        nlines = 2 if pid == 'abc014_1' else 3
        fields_per_line = 2 if pid == 'abc017_1' else 1
    else:
        nlines, fields_per_line = 1, (2 if pid == 'abc016_1' else (3 if pid == 'abc019_1' else 1))
    if len(lines) != nlines:
        raise ValueError('unexpected line count')
    tokens = [line.split(' ') for line in lines]
    if any(len(t) != fields_per_line or any(not UINT.fullmatch(s) for s in t) for t in tokens):
        raise ValueError('noncanonical integer fields')
    vals = tuple(int(x) for row in tokens for x in row)
    if pid == 'abc014_1' and not all(1 <= n <= 100 for n in vals):
        raise ValueError('out of bounds')
    if pid == 'abc016_1':
        m, d = vals
        if not 1 <= m <= 12 or not 1 <= d <= _calendar_day_limit(m):
            raise ValueError('invalid calendar day')
    if pid == 'abc017_1' and any(not (10 <= vals[i] <= 990 and vals[i]%10==0 and 1 <= vals[i+1] <= 10) for i in (0,2,4)):
        raise ValueError('out of bounds or not multiple of ten')
    if pid == 'abc018_1' and (not all(1<=n<=100 for n in vals) or len(set(vals))!=3):
        raise ValueError('three distinct scores required')
    if pid == 'abc019_1' and not all(1<=n<=100 for n in vals):
        raise ValueError('out of bounds')
    if pid == 'abc020_a' and vals not in ((1,), (2,)):
        raise ValueError('Q must be 1 or 2')
    return vals


FIXTURES = {
    'abc013_1': [('constraint_min','A'),('typical','B'),('typical','C'),('boundary','D'),('constraint_max','E')],
    'abc014_1': [('constraint_min','1\n1'),('boundary','1\n100'),('boundary','100\n1'),('typical','7\n3'),('typical','5\n5'),('constraint_max','100\n100')],
    'abc015_1': [('constraint_min','a\nbb'),('boundary','a\n'+'b'*50),('boundary','a'*49+'\n'+'b'*50),('typical','isuruu\nisleapyear'),('constraint_max','a'*50+'\nb')],
    'abc016_1': [('constraint_min','1 1'),('boundary','2 29'),('boundary','12 6'),('typical','6 5'),('constraint_max','12 31')],
    'abc017_1': [('constraint_min','10 1\n10 1\n10 1'),('boundary','990 1\n990 1\n990 1'),('typical','50 7\n40 8\n30 9'),('boundary','990 10\n10 1\n990 10'),('constraint_max','990 10\n990 10\n990 10')],
    'abc018_1': [('constraint_min','1\n2\n3'),('boundary','3\n1\n2'),('typical','12\n18\n11'),('boundary','100\n1\n99'),('constraint_max','98\n99\n100')],
    'abc019_1': [('constraint_min','1 1 1'),('boundary','1 100 1'),('typical','2 3 4'),('boundary','100 100 1'),('constraint_max','100 100 100')],
    'abc020_a': [('constraint_min','1'),('constraint_max','2')],
}


def generate(pid: str, count: int, seed: int, include_large: bool) -> list[dict[str,str]]:
    if pid not in BATCH19 or not 4 <= count <= 80:
        raise ValueError('invalid task or count')
    rng = random.Random(f'batch19:{pid}:{seed}')
    seen: set[str] = set()
    cases: list[dict[str,str]] = []
    def add(cat: str, raw: str) -> None:
        text = raw+'\n'
        validate(pid,text)
        if text not in seen:
            seen.add(text)
            cases.append({'category':cat,'input':text})
    for cat, raw in FIXTURES[pid]:
        if cat != 'constraint_max':
            add(cat, raw)
    attempts = 0
    while len(cases) < count and attempts < 2500:
        attempts += 1
        if pid == 'abc013_1': raw = rng.choice('ABCDE')
        elif pid == 'abc014_1': raw = f'{rng.randint(1,100)}\n{rng.randint(1,100)}'
        elif pid == 'abc015_1':
            a,b = rng.sample(range(1,51),2)
            raw = ''.join(rng.choices('abcxyz',k=a))+'\n'+''.join(rng.choices('abcxyz',k=b))
        elif pid == 'abc016_1':
            m=rng.randint(1,12)
            raw=f'{m} {rng.randint(1,_calendar_day_limit(m))}'
        elif pid == 'abc017_1': raw='\n'.join(f'{10*rng.randint(1,99)} {rng.randint(1,10)}' for _ in range(3))
        elif pid == 'abc018_1': raw='\n'.join(map(str,rng.sample(range(1,101),3)))
        elif pid == 'abc019_1': raw=' '.join(str(rng.randint(1,100)) for _ in range(3))
        else: raw=str(rng.choice((1,2)))
        add('random',raw)
    cases=cases[:count]
    if include_large:
        maximum=next(raw+'\n' for cat, raw in FIXTURES[pid] if cat=='constraint_max')
        cases=[case for case in cases if case['input']!=maximum][:count-1]
        cases.append({'category':'constraint_max','input':maximum})
    return cases


def independent_check(pid: str, data: str, expected: str) -> bool:
    vals=validate(pid,data)
    if pid=='abc013_1': answer=str('ABCDE'.index(vals)+1)
    elif pid=='abc014_1':
        a,b=vals
        answer=str(next(k for k in range(b) if (a+k)//b*b==a+k))
    elif pid=='abc015_1': answer=sorted(vals,key=len)[-1]
    elif pid=='abc016_1':
        m,d=vals
        answer='YES' if m//d*d==m else 'NO'
    elif pid=='abc017_1': answer=str(sum(vals[i]//10*vals[i+1] for i in (0,2,4)))
    elif pid=='abc018_1': answer='\n'.join(str(1+sum(other>n for other in vals)) for n in vals)
    elif pid=='abc019_1': answer=str(sum(vals)-min(vals)-max(vals))
    else: answer=('ABC','chokudai')[vals[0]-1]
    return expected==answer
