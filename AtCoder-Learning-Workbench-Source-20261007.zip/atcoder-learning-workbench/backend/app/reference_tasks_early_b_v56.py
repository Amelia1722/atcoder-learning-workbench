"""Reviewed ABC026–028 B generators and structurally independent checkers.

Sources: public AtCoder task pages inspected 2026-09-23; no HTML original authenticated.
"""
from __future__ import annotations
import math
import random
import re

TASKS = ('abc026_b', 'abc027_b', 'abc028_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
NUMERIC = re.compile(r'(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?', re.ASCII)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('invalid task or input framing')
    lines = raw[:-1].split('\n')
    if pid == 'abc028_b':
        if len(lines) != 1 or not 1 <= len(lines[0]) <= 100 or any(c not in 'ABCDEF' for c in lines[0]):
            raise ValueError('invalid alphabet or length')
        return lines[0]
    if pid == 'abc026_b':
        if not POS.fullmatch(lines[0]):
            raise ValueError('invalid count')
        n = int(lines[0])
        if not 1 <= n <= 1000 or len(lines) != n + 1:
            raise ValueError('invalid radius count')
        if any(not POS.fullmatch(s) for s in lines[1:]):
            raise ValueError('invalid radius integer')
        radii = [int(s) for s in lines[1:]]
        if any(r > 1000 for r in radii) or len(set(radii)) != n:
            raise ValueError('radius range or uniqueness')
        return radii
    if len(lines) != 2 or not POS.fullmatch(lines[0]):
        raise ValueError('expected two lines')
    n = int(lines[0])
    if not 2 <= n <= 100:
        raise ValueError('invalid island count')
    tokens = lines[1].split(' ')
    if len(tokens) != n or any(not NONNEG.fullmatch(s) for s in tokens):
        raise ValueError('invalid population tokens')
    populations = [int(s) for s in tokens]
    if any(a > 100 for a in populations):
        raise ValueError('population range')
    return populations


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        data = validate(pid, raw)
    except (TypeError, ValueError):
        return False
    if not isinstance(output, str):
        return False
    if pid == 'abc026_b':
        if not NUMERIC.fullmatch(output) or len(output) > 80:
            return False
        try:
            actual = float(output)
        except (OverflowError, ValueError):
            return False
        if not math.isfinite(actual):
            return False
        radii = sorted(data)
        # Compute areas of annuli, counting only those with red outer-to-inner parity.
        squared = [0] + [r*r for r in radii]
        coefficient = sum(squared[i+1] - squared[i]
                          for i in range(len(radii)) if (len(radii)-1-i) % 2 == 0)
        expected = coefficient * math.pi
        return math.isclose(actual, expected, rel_tol=1e-6, abs_tol=1e-6)
    if pid == 'abc028_b':
        # Six separate scans, unlike reference Counter.
        expected = ' '.join(str(sum(c == letter for c in data)) for letter in 'ABCDEF')
        return output == expected
    total = sum(data)
    if total % len(data):
        return output == '-1'
    mean = total // len(data)
    # Independent quadratic partition DP: each connected block must balance.
    n = len(data)
    best = [n+1] * (n+1)
    best[0] = 0
    for end in range(1, n+1):
        balance = 0
        for begin in range(end-1, -1, -1):
            balance += data[begin] - mean
            if balance == 0:
                best[end] = min(best[end], best[begin] + end - begin - 1)
    return output == str(best[n])


def generate(pid: str, seed: int = 56) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unsupported task')
    rng = random.Random(f'abc-v56:{pid}:{seed}')
    cases: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(kind: str, raw: str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            cases.append({'category': kind, 'input': raw})
    if pid == 'abc026_b':
        def fmt(r): return f'{len(r)}\n' + ''.join(f'{v}\n' for v in r)
        presets = [[1],[1000],[1,1000],[1000,1],[1,2,3],[3,2,1],
                   [15,2,3,7,6,9], [1,2,3,4], [4,3,2,1],
                   [999,1000],[1000,999,998],list(range(1,101)),
                   list(range(100,0,-1)),[1,999,1000]]
        for r in presets: add('boundary' if len(r) <= 3 else 'normal', fmt(r))
        while len(cases) < 17:
            n = rng.randint(1, 999)
            add('random', fmt(rng.sample(range(1,1001),n)))
        add('constraint_max',fmt(list(range(1000,0,-1))))
    elif pid == 'abc027_b':
        def fmt(a): return f'{len(a)}\n' + ' '.join(map(str,a)) + '\n'
        presets = [[0,0],[0,100],[100,100],[1,2,3],[2,0,0,0,3],
                   [0,99],[0,0,0,0],[0,100,0,100],[1,3,1,3],
                   [3,1,2,2],[100]*100,[0]*100,[0]*99+[100],
                   [100]*50+[0]*50]
        for a in presets: add('boundary' if len(a) <= 3 else 'normal',fmt(a))
        while len(cases) < 17:
            a=[rng.randint(0,100) for _ in range(rng.randint(2,100))]
            add('random',fmt(a))
        add('constraint_max',fmt([100 if i%2==0 else 0 for i in range(100)]))
    else:
        presets = ['A','F','ABCDEF','FEDCBA','AAAAAA','FFFFFF',
                   'BEAF','DECADE','ABBCCCDDDDEEEEEFFFFFF',
                   'AF'*50,'A'*100,'F'*100,'ABCDEF'*16+'ABCD',
                   'FEDCBA'*16+'FEDC']
        for s in presets: add('boundary' if len(s) == 1 else 'normal',s+'\n')
        while len(cases) < 17:
            n=rng.randint(1,99)
            add('random',''.join(rng.choices('ABCDEF',k=n))+'\n')
        add('constraint_max','AB'*50+'\n')
    if len(cases) != 18 or cases[-1]['category'] != 'constraint_max':
        raise ValueError(f'case count / max category failed: {pid} {len(cases)}')
    return cases
