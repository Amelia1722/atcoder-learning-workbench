"""Private ABC347..352 D with official multi-solution347 and unique exact349."""
from __future__ import annotations
from typing import cast
from collections import deque
import heapq,re,random
TASKS=tuple(f'abc{n}_d' for n in range(347,353));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES={'abc347_d':'semantic'};CHECKER_IDS={'abc347_d':'abc347_d'};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(s:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',s) is not None,'integers');v=tuple(map(int,s.split()));require(n is None or len(v)==n,'fields');return v
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
    if pid=='abc347_d':require(len(r)==1,'rows');a,b,c=ints(r[0],3);require(0<=a<=60 and 0<=b<=60 and 0<=c<1<<60,'popcount domain');return a,b,c
    if pid=='abc348_d':
        h,w=ints(r[0],2);require(1<=h<=200 and 1<=w<=200 and len(r)>=h+2,'shape');grid=tuple(r[1:h+1]);require(all(re.fullmatch('[.#ST]{'+str(w)+'}',row) for row in grid) and sum(row.count('S') for row in grid)==sum(row.count('T') for row in grid)==1,'grid');n=ints(r[h+1],1)[0];require(1<=n<=300 and len(r)==h+n+2,'N');medicines=tuple(ints(s,3) for s in r[h+2:]);require(all(1<=i<=h and 1<=j<=w and 1<=e<=h*w and grid[i-1][j-1]!='#' for i,j,e in medicines) and len({(i,j) for i,j,e in medicines})==n,'medicine');return grid,medicines
    if pid=='abc349_d':require(len(r)==1,'rows');l,rr=ints(r[0],2);require(0<=l<rr<=1<<60,'interval');return l,rr
    if pid=='abc350_d':
        n,m=ints(r[0],2);require(2<=n<=200000 and 0<=m<=200000 and len(r)==m+1,'shape');edges=tuple(ints(s,2) for s in r[1:]);require(all(1<=u<v<=n for u,v in edges) and len(set(edges))==m,'simple ordered edges');return n,edges
    if pid=='abc351_d':
        h,w=ints(r[0],2);grid=tuple(r[1:]);require(1<=h<=1000 and 1<=w<=1000 and len(grid)==h and all(re.fullmatch('[.#]{'+str(w)+'}',s) for s in grid) and any('.' in s for s in grid),'magnet grid');return (grid,)
    n,k=ints(r[0],2);require(1<=k<=n<=200000 and len(r)==2,'shape');p=ints(r[1],n);require(set(p)==set(range(1,n+1)),'permutation');return k,p

def popcount_exists(a:int,b:int,c:int)->bool:
    ones=c.bit_count();common=a+b-ones
    return common>=0 and common%2==0 and 0<=a-common//2<=ones and 0<=b-common//2<=ones and common//2<=60-ones

def popcount_bit_dp(a:int,b:int,c:int)->tuple[int,int]|None:
    mask=(1<<(b+1))-1;states=[0]*(a+1);states[0]=1;history=[states]
    for bit in range(60):
        nxt=[0]*(a+1)
        for used in range(a+1):
            if c>>bit&1:nxt[used]=((states[used]<<1)|(states[used-1] if used else 0))&mask
            else:nxt[used]=(states[used]|((states[used-1]<<1) if used else 0))&mask
        states=nxt;history.append(states)
    if not states[a]>>b&1:return None
    x=y=0;aa,bb=a,b
    for bit in range(59,-1,-1):
        choices=((1,0),(0,1)) if c>>bit&1 else ((1,1),(0,0))
        for dx,dy in choices:
            if aa>=dx and bb>=dy and history[bit][aa-dx]>>(bb-dy)&1:
                x|=dx<<bit;y|=dy<<bit;aa-=dx;bb-=dy;break
        else:raise AssertionError('DP backtrack')
    return x,y

def medicine_distance_graph(grid:tuple[str,...],medicines:tuple[tuple[int,...],...])->bool:
    h,w=len(grid),len(grid[0]);start=next((i,j) for i,row in enumerate(grid) for j,c in enumerate(row) if c=='S');goal=next((i,j) for i,row in enumerate(grid) for j,c in enumerate(row) if c=='T');index={(i-1,j-1):k for k,(i,j,e) in enumerate(medicines)}
    if start not in index:return False
    seen={index[start]};pending=deque([index[start]])
    while pending:
        k=pending.popleft();row,col,energy=medicines[k];distance=[-1]*(h*w);at=(row-1)*w+col-1;distance[at]=0;queue=deque([at])
        while queue:
            point=queue.popleft();i,j=divmod(point,w)
            if (i,j)==goal:return True
            if (i,j) in index:
                nxt=index[i,j]
                if nxt not in seen:seen.add(nxt);pending.append(nxt)
            if distance[point]==energy:continue
            for ii,jj in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
                if 0<=ii<h and 0<=jj<w and grid[ii][jj]!='#' and distance[ii*w+jj]<0:distance[ii*w+jj]=distance[point]+1;queue.append(ii*w+jj)
        # Such a medicine covers its complete physical component (simple path <= HW-1).
        if energy>=h*w-1:return False
    return False

def dyadic_tree(l:int,r:int)->list[tuple[int,int]]:
    answer=[];stack=[(0,1<<60)]
    while stack:
        lo,hi=stack.pop()
        if hi<=l or r<=lo:continue
        if l<=lo and hi<=r:answer.append((lo,hi));continue
        mid=(lo+hi)//2;stack.extend([(mid,hi),(lo,mid)])
    return answer

def friendships_components(n:int,edges:tuple[tuple[int,...],...])->int:
    graph=[[] for _ in range(n)]
    for u,v in edges:graph[u-1].append(v-1);graph[v-1].append(u-1)
    seen=bytearray(n);answer=-len(edges)
    for start in range(n):
        if seen[start]:continue
        seen[start]=1;queue=[start]
        for u in queue:
            for v in graph[u]:
                if not seen[v]:seen[v]=1;queue.append(v)
        answer+=len(queue)*(len(queue)-1)//2
    return answer

def magnet_union(grid:tuple[str,...])->int:
    h,w=len(grid),len(grid[0]);n=h*w;blocked=bytearray(n);safe=bytearray(n)
    for i,row in enumerate(grid):
        for j,c in enumerate(row):blocked[i*w+j]=c=='#'
    def neighbors(point:int)->list[int]:
        i,j=divmod(point,w);return [ii*w+jj for ii,jj in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)) if 0<=ii<h and 0<=jj<w]
    for p in range(n):safe[p]=not blocked[p] and not any(blocked[q] for q in neighbors(p))
    parent=list(range(n));size=[1]*n
    def root(p:int)->int:
        while parent[p]!=p:parent[p]=parent[parent[p]];p=parent[p]
        return p
    for p in range(n):
        if not safe[p]:continue
        for q in ((p+1,) if p%w<w-1 else ()) + ((p+w,) if p+w<n else ()):
            if safe[q]:
                a,b=root(p),root(q)
                if a!=b:
                    if size[a]<size[b]:a,b=b,a
                    parent[b]=a;size[a]+=size[b]
    border:dict[int,int]={};best=1
    for p in range(n):
        if blocked[p] or safe[p]:continue
        for component in {root(q) for q in neighbors(p) if safe[q]}:border[component]=border.get(component,0)+1
    for p in range(n):
        if safe[p] and parent[p]==p:best=max(best,size[p]+border.get(p,0))
    return best

def permutation_segment_ranges(k:int,p:tuple[int,...])->int:
    n=len(p);position=[0]*n
    for index,value in enumerate(p):position[value-1]=index
    length=1
    while length<n:length*=2
    minimum=[n]*(2*length);maximum=[-1]*(2*length)
    for j,value in enumerate(position):minimum[length+j]=maximum[length+j]=value
    for node in range(length-1,0,-1):minimum[node]=min(minimum[2*node],minimum[2*node+1]);maximum[node]=max(maximum[2*node],maximum[2*node+1])
    best=n
    for start in range(n-k+1):
        left,right=start+length,start+k+length;lo,hi=n,-1
        while left<right:
            if left&1:lo=min(lo,minimum[left]);hi=max(hi,maximum[left]);left+=1
            if right&1:right-=1;lo=min(lo,minimum[right]);hi=max(hi,maximum[right])
            left//=2;right//=2
        best=min(best,hi-lo)
    return best

def oracle(pid:str,raw:str)->str:
    d=validate(pid,raw)
    if pid=='abc347_d':answer=popcount_bit_dp(cast(int,d[0]),cast(int,d[1]),cast(int,d[2]));return '-1' if answer is None else line(answer).strip()
    if pid=='abc348_d':return 'Yes' if medicine_distance_graph(cast(tuple[str,...],d[0]),cast(tuple[tuple[int,...],...],d[1])) else 'No'
    if pid=='abc349_d':answer=dyadic_tree(cast(int,d[0]),cast(int,d[1]));return str(len(answer))+'\n'+''.join(line(pair) for pair in answer).removesuffix('\n')
    if pid=='abc350_d':return str(friendships_components(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))
    if pid=='abc351_d':return str(magnet_union(cast(tuple[str,...],d[0])))
    return str(permutation_segment_ranges(cast(int,d[0]),cast(tuple[int,...],d[1])))
def independent_check(pid:str,raw:str,actual:str,output_mode:str|None=None)->bool:
    try:
        d=validate(pid,raw);mode=OUTPUT_MODES.get(pid,'exact')
        if output_mode not in (None,mode):return False
        if pid!='abc347_d':return actual.removesuffix('\n')==oracle(pid,raw)
        a,b,c=cast(tuple[int,int,int],d);tokens=actual.split()
        if tokens==['-1']:return not popcount_exists(a,b,c)
        if len(tokens)!=2 or any(re.fullmatch(r'0|[1-9][0-9]*',s) is None for s in tokens):return False
        x,y=map(int,tokens);return 0<=x<1<<60 and 0<=y<1<<60 and x.bit_count()==a and y.bit_count()==b and x^y==c
    except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

REFERENCE_CODE:dict[str,str]={'abc347_d': 'a,b,c=map(int,input().split());ones=c.bit_count();common=a+b-ones\nif common<0 or common%2 or common//2>60-ones or a<common//2 or b<common//2:print(-1)\nelse:\n common//=2;need=a-common;x=y=0\n for bit in range(60):\n  if c>>bit&1:\n   if need:x|=1<<bit;need-=1\n   else:y|=1<<bit\n  elif common:x|=1<<bit;y|=1<<bit;common-=1\n print(x,y)\n', 'abc348_d': "import sys,heapq\nh,w=map(int,input().split());g=[input() for _ in range(h)];med={}\nfor _ in range(int(input())):r,c,e=map(int,input().split());med[(r-1)*w+c-1]=e\nstart=next(i*w+j for i,row in enumerate(g) for j,c in enumerate(row) if c=='S');target=next(i*w+j for i,row in enumerate(g) for j,c in enumerate(row) if c=='T');best=[-1]*(h*w);best[start]=med.get(start,0);heap=[(-best[start],start)]\nwhile heap:\n neg,p=heapq.heappop(heap);energy=-neg\n if best[p]!=energy:continue\n if p==target:print('Yes');sys.exit()\n if energy==0:continue\n i,j=divmod(p,w)\n for ii,jj in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):\n  if 0<=ii<h and 0<=jj<w and g[ii][jj]!='#':\n   q=ii*w+jj;value=max(energy-1,med.get(q,0))\n   if value>best[q]:best[q]=value;heapq.heappush(heap,(-value,q))\nprint('No')\n", 'abc349_d': 'l,r=map(int,input().split());out=[]\nwhile l<r:\n width=(l&-l) if l else 1<<(r-l).bit_length()-1\n while width>r-l:width//=2\n out.append((l,l+width));l+=width\nprint(len(out))\nfor row in out:print(*row)\n', 'abc350_d': 'n,m=map(int,input().split());parent=list(range(n));size=[1]*n\ndef root(x):\n while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]\n return x\nfor _ in range(m):\n u,v=map(int,input().split());a,b=root(u-1),root(v-1)\n if a!=b:\n  if size[a]<size[b]:a,b=b,a\n  parent[b]=a;size[a]+=size[b]\nprint(sum(size[i]*(size[i]-1)//2 for i in range(n) if parent[i]==i)-m)\n', 'abc351_d': "h,w=map(int,input().split());g=[input() for _ in range(h)];bad=set()\nfor i in range(h):\n for j in range(w):\n  if g[i][j]=='#':\n   for ii,jj in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):\n    if 0<=ii<h and 0<=jj<w and g[ii][jj]=='.':bad.add(ii*w+jj)\nseen=set();answer=1\nfor i in range(h):\n for j in range(w):\n  start=i*w+j\n  if g[i][j]!='.' or start in bad or start in seen:continue\n  queue=[start];seen.add(start);boundary=set()\n  for p in queue:\n   x,y=divmod(p,w)\n   for xx,yy in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):\n    if 0<=xx<h and 0<=yy<w and g[xx][yy]=='.':\n     q=xx*w+yy\n     if q in bad:boundary.add(q)\n     elif q not in seen:seen.add(q);queue.append(q)\n  answer=max(answer,len(queue)+len(boundary))\nprint(answer)\n", 'abc352_d': 'from collections import deque\nn,k=map(int,input().split());p=list(map(int,input().split()));position=[0]*n\nfor j,x in enumerate(p):position[x-1]=j\nminimum=deque();maximum=deque();answer=n\nfor j,x in enumerate(position):\n while minimum and position[minimum[-1]]>=x:minimum.pop()\n while maximum and position[maximum[-1]]<=x:maximum.pop()\n minimum.append(j);maximum.append(j)\n while minimum[0]<=j-k:minimum.popleft()\n while maximum[0]<=j-k:maximum.popleft()\n if j>=k-1:answer=min(answer,position[maximum[0]]-position[minimum[0]])\nprint(answer)\n'}
TITLES:dict[str,str]={'abc347_d': 'Popcount and XOR', 'abc348_d': 'Medicines on Grid', 'abc349_d': 'Divide Interval', 'abc350_d': 'New Friends', 'abc351_d': 'Grid and Magnet', 'abc352_d': 'Permutation Subsequence'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'abc347_d': [{'input': '3 4 7\n', 'expected': '28 27\n'}, {'input': '34 56 998244353\n', 'expected': '-1\n'}, {'input': '39 47 530423800524412070\n', 'expected': '540431255696862041 10008854347644927\n'}], 'abc348_d': [{'input': '4 4\nS...\n#..#\n#...\n..#T\n4\n1 1 3\n1 3 5\n3 2 1\n2 3 1\n', 'expected': 'Yes\n'}, {'input': '2 2\nS.\nT.\n1\n1 2 4\n', 'expected': 'No\n'}, {'input': '4 5\n..#..\n.S##.\n.##T.\n.....\n3\n3 1 5\n1 2 3\n2 2 1\n', 'expected': 'Yes\n'}], 'abc349_d': [{'input': '3 19\n', 'expected': '5\n3 4\n4 8\n8 16\n16 18\n18 19\n'}, {'input': '0 1024\n', 'expected': '1\n0 1024\n'}, {'input': '3940649673945088 11549545024454656\n', 'expected': '8\n3940649673945088 3940649673949184\n3940649673949184 4503599627370496\n4503599627370496 9007199254740992\n9007199254740992 11258999068426240\n11258999068426240 11540474045136896\n11540474045136896 11549270138159104\n11549270138159104 11549545016066048\n11549545016066048 11549545024454656\n'}], 'abc350_d': [{'input': '4 3\n1 2\n2 3\n1 4\n', 'expected': '3\n'}, {'input': '3 0\n', 'expected': '0\n'}, {'input': '10 8\n1 2\n2 3\n3 4\n4 5\n6 7\n7 8\n8 9\n9 10\n', 'expected': '12\n'}], 'abc351_d': [{'input': '3 5\n.#...\n.....\n.#..#\n', 'expected': '9\n'}, {'input': '3 3\n..#\n#..\n..#\n', 'expected': '1\n'}], 'abc352_d': [{'input': '4 2\n2 3 1 4\n', 'expected': '1\n'}, {'input': '4 1\n2 3 1 4\n', 'expected': '0\n'}, {'input': '10 5\n10 1 6 8 7 2 5 9 3 4\n', 'expected': '5\n'}]}
SAMPLE_COUNTS={pid:len(cases) for pid,cases in PUBLISHED_SAMPLES.items()}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(int(pid[3:6]));raws:list[str]=[]
    if pid=='abc347_d':
        triples=[(0,0,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(2,2,3),(60,60,0),(60,0,(1<<60)-1),(0,60,(1<<60)-1),(59,59,3),(30,30,(1<<60)-1),(1,1,1)]
        triples.extend((rng.randint(0,60),rng.randint(0,60),rng.randrange(1<<60)) for _ in range(4));triples.extend([(60,59,1),(60,60,(1<<60)-1)]);raws=[line(row) for row in triples]
    elif pid=='abc348_d':
        def pack(grid:list[str],med:list[tuple[int,int,int]])->str:return line((len(grid),len(grid[0])))+'\n'.join(grid)+f'\n{len(med)}\n'+''.join(line(row) for row in med)
        raws=[pack(['ST'],[(1,1,1)]),pack(['ST'],[(1,2,1)]),pack(['S.','.T'],[(1,1,1)]),pack(['S..T'],[(1,1,1),(1,2,2)])]
        for j in range(12):
            h=j+3;w=j+4;grid=[''.join('#' if rng.randrange(5)==0 else '.' for _ in range(w)) for _ in range(h)];grid[0]='S'+grid[0][1:];grid[-1]=grid[-1][:-1]+'T';openings=[(i+1,c+1) for i,row in enumerate(grid) for c,value in enumerate(row) if value!='#'];chosen=rng.sample(openings,min(j+1,len(openings)));med=[(i,c,rng.randint(1,h*w)) for i,c in chosen];raws.append(pack(grid,med))
        unreachable=['S'+'.'*199]+['.'*200]*198+['.'*198+'#T'];unreachable[-2]='.'*199+'#';med=[(j//200+1,j%200+1,40000) for j in range(300)];raws.extend([pack(unreachable,med),pack(['S'+'.'*199]+['.'*200]*198+['.'*199+'T'],med)])
    elif pid=='abc349_d':
        pairs=[(0,1),(1,2),(0,2),(1,3),(3,17),(0,1<<59)]
        for j in range(10):
            left=rng.randrange(1<<60);right=rng.randrange(left+1,(1<<60)+1);pairs.append((left,right))
        pairs.extend([(1,(1<<60)-1),(0,1<<60)]);raws=[line(row) for row in pairs]
    elif pid=='abc350_d':
        def pack(n:int,e:list[tuple[int,int]])->str:return line((n,len(e)))+''.join(line(pair) for pair in e)
        raws=[pack(2,[]),pack(2,[(1,2)]),pack(3,[(1,2),(2,3)]),pack(4,[(1,2),(3,4)])]
        for j in range(12):
            n=j+5;edges=[(u,v) for u in range(1,n+1) for v in range(u+1,n+1) if rng.randrange(4)==0];raws.append(pack(n,edges))
        raws.extend([pack(200000,[(1,j) for j in range(2,200001)]),pack(200000,[(j,j+1) for j in range(1,200000)]+[(1,200000)])])
    elif pid=='abc351_d':
        def pack(grid:list[str])->str:return line((len(grid),len(grid[0])))+'\n'.join(grid)+'\n'
        raws=[pack(['.']),pack(['.#']),pack(['...','.#.','...']),pack(['.#.','...','.#.'])]
        for j in range(12):
            h=j+3;w=j+4;grid=[''.join('#' if rng.randrange(5)==0 else '.' for _ in range(w)) for _ in range(h)];grid[0]='.'+grid[0][1:];raws.append(pack(grid))
        raws.extend([pack([''.join('#' if (i+j)%2 else '.' for j in range(1000)) for i in range(1000)]),pack(['.'*1000]*1000)])
    else:
        def pack(k:int,p:list[int])->str:return line((len(p),k))+line(p)
        raws=[pack(1,[1]),pack(1,[2,1]),pack(2,[2,1]),pack(2,[3,1,4,2])]
        for j in range(12):
            n=j+5;p=list(range(1,n+1));rng.shuffle(p);raws.append(pack(rng.randint(1,n),p))
        p=list(range(1,200001));rng.shuffle(p);raws.extend([pack(100000,p),pack(200000,list(range(200000,0,-1)))])
    require(len(raws)==len(set(raws))==18,'18 distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'random'} for j,raw in enumerate(raws)]
HINTS:dict[str,tuple[str,str,str]]={
'abc347_d':('Cの1のビットではX,Yの片方だけ、0のビットでは両方0か両方1です。','Cの1の個数をcとすると、両方1のビット数は(a+b-c)/2です。整数か、0のビットに収まるか、片方だけ1の必要数が負にならないか調べます。','疑似コード: common=a+b-popcount(C)。common<0、奇数、common/2>60-popcount(C)、a/b<common/2なら-1。残りは低位からCの1をX専用必要数だけXへ、他をYへ。Cの0はcommon/2個だけ両方へ立て、X,Yを出力。'),
'abc348_d':('同じマスでは、より多くのエネルギーを持って到達した状態が有利です。','マスごとの最大エネルギーを管理し、大きいものから探索します。薬はエネルギーを減らすなら使わず、移動後の値と薬の値の最大値を選びます。','疑似コード: startの薬の値または0をbestへ入れmaxheapへ。取り出した値がbestと同じなら、energy>0のとき四近傍空きマスへnext=max(energy-1,薬の値)。bestが増えた場合だけ更新してheap追加。Tへ到達ならYes、探索終了ならNo。'),
'abc349_d':('左端から、収まる最大の良い数列を順に取り出します。','L>0ならLの最下位の1が表す2冪が、Lを左端にできる最大幅です。残りの長さを超える間は幅を半分にします。L=0では残り以下の最大2冪を使います。','疑似コード: L<Rの間、幅=L&-L（L=0ならR-L以下の最大2冪）。幅>R-Lの間半分にし、(L,L+幅)を保存してL+=幅。個数と保存した区間を順に出力。'),
'abc350_d':('友達関係の連結成分の中では、最終的に全員どうしを友達にできます。','連結成分の人数sなら全ペア数はs*(s-1)/2です。元から存在する辺数を引くと追加操作の総数です。','疑似コード: 全友達辺をDSUで併合し、各根の人数sを得る。Σs*(s-1)//2-Mを出力。'),
'abc351_d':('磁石に隣接する空きマスは到達できても、そこから先へ進めません。','隣接しない安全マスの連結成分を探索し、その成分の安全マス数と、接する危険マスの異なる個数を足します。','疑似コード: 各磁石の近傍空きマスをdangerにする。未訪問safeマスからBFSしてsafe成分を集め、その四近傍dangerをsetへ追加。成分サイズ+dangerの個数の最大を求め、初期値1との最大を出力。'),
'abc352_d':('値が連続するK個の整数について、現れる位置の最大と最小を考えます。','各値の位置を配列にします。値の順の長さKの窓で、位置の最大・最小を単調dequeで管理すると全候補を速く調べられます。','疑似コード: pos[P[i]-1]=i。値順jでpos[j]をmin/max dequeへ単調性を保って追加。窓より古いindexを先頭から除く。j>=K-1なら最大位置-最小位置で答えを最小化し出力。')}
