"""Evidence-bound backfill for ABC004 B / ABC005 A-B; public statements checked."""
HINTS_BACKFILL_V75 = {
    'abc004_2': (
        '180度回転では、盤面の左上と右下のように、行方向と列方向の両方が逆になります。',
        '4行の順序を逆にし、各行の4要素の順序も逆にして出力します。',
        '''疑似コード:\ngrid = read 4x4 tokens\nfor row in reversed(grid):\n  print(reversed(row), separated by spaces)''',
    ),
    'abc005_1': (
        'たこ焼き1個にxグラム必要です。手元のyグラムから、完全に作れる個数だけを数えます。',
        '余りは使えないので、yをxで整数除算します。',
        '''疑似コード:\nx, y = read integers\nprint(y // x)''',
    ),
    'abc005_2': (
        '「一番できたて」は、何秒前にできたかという値が最も小さいたこ焼きです。',
        'N個のT_iの最小値を取れば、そのたこ焼きが何秒前にできたか分かります。',
        '''疑似コード:\nT = read N integers\nprint(min(T))''',
    ),
}
