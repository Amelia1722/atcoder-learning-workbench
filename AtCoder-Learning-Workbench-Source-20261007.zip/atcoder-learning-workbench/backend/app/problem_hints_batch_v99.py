"""Statement-checked three-stage hints for ABC155–157 B."""
HINTS_V99 = {
    'abc155_b': (
        '全ての数に同じ条件を課すのではありません。まず、確認対象になる数だけを見分けてください。',
        '偶数だけを調べ、3でも5でも割り切れない偶数が1つでもあればDENIEDです。奇数は無条件で問題ありません。',
        '''疑似コード:\nfor x in A:\n  if x % 2 == 0 and x % 3 != 0 and x % 5 != 0:\n    print("DENIED")\n    stop\nprint("APPROVED")''',
    ),
    'abc156_b': (
        'K進数の各桁を実際の文字列へ変換しなくても、桁を1つずつ取り除く操作を考えられます。',
        'NをKで整数除算するたびにK進表記の末尾1桁を取り除けます。Nが0になるまでの回数が桁数です。',
        '''疑似コード:\ndigits = 0\nwhile N > 0:\n  digits += 1\n  N //= K\nprint(digits)''',
    ),
    'abc157_b': (
        '呼ばれた数に印を付けたあと、ビンゴになり得る列が全部で何本あるか整理してください。',
        '3行・3列・2本の対角線の計8本について、3マス全てが呼ばれた集合に含まれるか確認します。',
        '''疑似コード:\ncalled = set(b)\nmark[i][j] = (A[i][j] in called)\nfor each of 3 rows, 3 columns, 2 diagonals:\n  if all 3 cells are marked:\n    print("Yes")\n    stop\nprint("No")''',
    ),
}
