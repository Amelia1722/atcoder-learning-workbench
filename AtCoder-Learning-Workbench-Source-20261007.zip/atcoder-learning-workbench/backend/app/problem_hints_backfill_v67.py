"""Evidence-bound backfill for ABC035–037 B; public statement checked."""
HINTS_BACKFILL_V67 = {
    'abc035_b': (
        'まず?以外の命令だけを実行した位置と、?の個数を分けて考えてください。',
        '確定部分のマンハッタン距離をd、?の個数をqとします。最大はd+q。最小はd>=qならd-q、d<qなら余った手数の偶奇(q-d)%2です。',
        '疑似コード:\nx=y=q=0\nfor ch in S: L/R/U/Dなら座標更新、?ならq+=1\nd=abs(x)+abs(y)\nif T==1: print(d+q)\nelif d>=q: print(d-q)\nelse: print((q-d)%2)',
    ),
    'abc036_b': (
        '時計回り90度回転した後、元の(i,j)がどこへ移るかを小さい盤面で追ってください。',
        '0-indexedなら元の(i,j)は回転後の(j, N-1-i)へ移ります。この対応で新しいN×N盤面を埋めます。',
        '疑似コード:\nans=N×Nの空盤面\nfor i in 0..N-1:\n  for j in 0..N-1:\n    ans[j][N-1-i]=S[i][j]\n各行を出力',
    ),
    'abc037_b': (
        '操作は入力順で実行され、後の操作は前の値を上書きします。制約から素直な更新回数を見積もってください。',
        'N,Qはいずれも100以下なので、各操作ごとにL-1からR-1まで直接Tを書き込んでも十分高速です。',
        '疑似コード:\na=[0]*N\nfor L,R,T in operations:\n  for i in L-1..R-1: a[i]=T\nfor x in a: print(x)',
    ),
}
