"""Three-stage hints for ABC105–112 A/B additions."""
HINTS_V16 = {
'abc105_a':('全員に同じ枚数を配れる場合と、そうでない場合に分けて考えてください。','NがKで割り切れるかだけ判定すればよいです。','疑似コード:\nif N % K == 0: print(0)\nelse: print(1)'),
'abc105_b':('使える金額は4の倍数と7の倍数の足し合わせです。小さい制約を利用できます。','4ドルの個数を全探索し、残りが7で割り切れるか確認します。','疑似コード:\nfor a = 0 .. N//4:\n  if (N-4*a) >= 0 and (N-4*a) % 7 == 0: print("Yes"); stop\nprint("No")'),
'abc106_a':('道を除いた後に残る縦と横の長さをそれぞれ考えてください。','縦横それぞれ1ずつ失われるので、残る長方形の面積を求めます。','疑似コード:\nprint((A-1)*(B-1))'),
'abc106_b':('Nが200以下なので、候補となる数を一つずつ調べても十分間に合います。','奇数だけを列挙し、各数の正の約数の個数を数えます。','疑似コード:\nans=0\nfor x in 1..N step 2:\n  divisors=0\n  for d in 1..x:\n    if x%d==0: divisors+=1\n  if divisors==8: ans+=1\nprint(ans)'),
'abc107_a':('前からの位置と後ろからの位置を足した値を、小さい例で確認してください。','N両の列車では前からi番目は後ろからN-i+1番目です。','疑似コード:\nprint(N - i + 1)'),
'abc107_b':('最終的に必要なのは、黒マスを一つでも含む行と列だけです。','#を含む行番号と、#を含む列番号を先に求め、その交点だけを出力します。','疑似コード:\nrows = [i where row i contains #]\ncols = [j where some grid[i][j] is #]\nfor i in rows:\n  print(grid[i][j] for j in cols)'),
'abc108_a':('1..Kの中に偶数と奇数がそれぞれ何個あるか数えてください。','偶数の個数と奇数の個数の積が組の総数です。','疑似コード:\neven = K//2\nodd = (K+1)//2\nprint(even*odd)'),
'abc108_b':('1点目から2点目へのベクトルを90度回転すると、次の辺が得られます。','(dx,dy)を反時計回りに90度回すと(-dy,dx)です。これを2点目と1点目へ足します。','疑似コード:\ndx=x2-x1; dy=y2-y1\nx3=x2-dy; y3=y2+dx\nx4=x1-dy; y4=y1+dx\nprint(x3,y3,x4,y4)'),
'abc109_a':('積を奇数にするには、掛ける各整数がどのような偶奇である必要があるか考えてください。','AとBがともに奇数なら、C=1などを選んで積を奇数にできます。','疑似コード:\nif A%2==1 and B%2==1: print("Yes")\nelse: print("No")'),
'abc109_b':('各単語について「以前に出ていないこと」と「前の単語とのつながり」の2条件があります。','setで重複を確認し、隣接する単語の末尾と先頭を順に比較します。','疑似コード:\nif len(set(W)) != N: print("No")\nelse if any(W[i][-1] != W[i+1][0]): print("No")\nelse: print("Yes")'),
'abc110_a':('3枚のうち、どの数字を十の位として使うと値が最大になるか考えてください。','最大の数字を10倍し、残り2つをそのまま足します。','疑似コード:\nA = sort([A,B,C])\nprint(10*A[2] + A[1] + A[0])'),
'abc110_b':('条件を満たすZが存在できる範囲の左端と右端をまとめて考えてください。','Zはmax(X, x_i全て)より大きく、min(Y, y_i全て)以下である必要があります。','疑似コード:\nleft=max(X,max(xs))\nright=min(Y,min(ys))\nif left < right: print("No War")\nelse: print("War")'),
'abc111_a':('各桁は1か9のどちらかだけです。それぞれを反対の数字へ置き換えます。','文字列として受け取り、1→9、9→1を各文字に適用します。','疑似コード:\nans=""\nfor c in S:\n  ans += "9" if c=="1" else "1"\nprint(ans)'),
'abc111_b':('条件を満たす3桁の数は種類が非常に少ないです。','111,222,...,999を小さい順に見て、N以上の最初の値を選びます。','疑似コード:\nfor d in 1..9:\n  x=111*d\n  if x>=N: print(x); break'),
'abc112_a':('最初のNによって、その後に読む入力と出力内容が変わります。','N=1なら固定文字列、N=2なら追加でA,Bを読み和を出します。','疑似コード:\nN=read()\nif N==1: print("Hello World")\nelse:\n  A=read(); B=read(); print(A+B)'),
'abc112_b':('時間制限を満たさない経路は、コストが安くても候補から外れます。','t_i<=Tの経路だけを絞り、その中の最小c_iを求めます。候補がなければTLEです。','疑似コード:\nvalid=[]\nfor c,t in routes:\n  if t<=T: valid.append(c)\nif valid: print(min(valid))\nelse: print("TLE")'),
}
