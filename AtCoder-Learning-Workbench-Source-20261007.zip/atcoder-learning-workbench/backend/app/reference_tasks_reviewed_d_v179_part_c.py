"""Reviewed legacy D: exact geometry, suffix DP and modular number theory."""
from __future__ import annotations
from bisect import bisect_right
from decimal import Decimal,localcontext
from fractions import Fraction
from functools import cmp_to_key
from itertools import combinations
from math import gcd,isqrt
from typing import cast
import random,re
TASKS=('abc016_4','abc017_4','abc018_4','abc020_d','abc021_d','abc022_d')
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc022_d':'numeric_tolerance_1e-6'}
OUTPUT_TOLERANCES={'abc022_d':{'absolute':'0.000001','relative':'0.000001','operator':'or'}}
Case=dict[str,str]
Point=tuple[int,int]
Points=tuple[Point,...]
Data=tuple[object,...]
MOD=1000000007
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def cross(a:Point,b:Point,c:Point)->int:return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def on_segment(a:Point,b:Point,p:Point)->bool:return cross(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def intersects(a:Point,b:Point,c:Point,d:Point)->bool:
    ac,ad,ca,cb=cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)
    return (ac*ad<0 and ca*cb<0) or on_segment(a,b,c) or on_segment(a,b,d) or on_segment(c,d,a) or on_segment(c,d,b)
def separated(p:Point,a:Point,b:Point)->bool:
    dx,dy=b[0]-a[0],b[1]-a[1];norm=dx*dx+dy*dy;projection=(p[0]-a[0])*dx+(p[1]-a[1])*dy
    if norm==0 or projection<=0:return 100*((p[0]-a[0])**2+(p[1]-a[1])**2)>=1
    if projection>=norm:return 100*((p[0]-b[0])**2+(p[1]-b[1])**2)>=1
    return 100*cross(a,b,p)**2>=norm

def outside(p:Point,polygon:Points)->bool:
    winding=0
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        if on_segment(a,b,p):return False
        if a[1]<=p[1]<b[1] and cross(a,b,p)>0:winding+=1
        if b[1]<=p[1]<a[1] and cross(a,b,p)<0:winding-=1
    return winding==0

def energy(a:Points)->int:
    n=len(a);sx=sum(x for x,y in a);sy=sum(y for x,y in a);return n*sum(x*x+y*y for x,y in a)-sx*sx-sy*sy

def similarity(a:Points,b:Points)->bool:
    n=len(a);ea,eb=energy(a),energy(b)
    if ea<=0 or eb<ea:return False
    def vectors(points:Points)->list[Point]:
        sx=sum(x for x,y in points);sy=sum(y for x,y in points);return [(n*x-sx,n*y-sy) for x,y in points if (n*x-sx,n*y-sy)!=(0,0)]
    va,vb=vectors(a),vectors(b)
    if len(va)!=len(vb):return False
    def compare(u:Point,v:Point)->int:
        hu=int(u[1]<0 or (u[1]==0 and u[0]<0));hv=int(v[1]<0 or (v[1]==0 and v[0]<0))
        if hu!=hv:return hu-hv
        c=u[0]*v[1]-u[1]*v[0]
        if c:return -1 if c>0 else 1
        nu=u[0]*u[0]+u[1]*u[1];nv=v[0]*v[0]+v[1]*v[1];return (nu>nv)-(nu<nv)
    va.sort(key=cmp_to_key(compare));vb.sort(key=cmp_to_key(compare))
    def features(v:list[Point],multiplier:int)->list[tuple[int,int,int]]:
        return [((x*x+y*y)*multiplier,(x*v[(j+1)%len(v)][0]+y*v[(j+1)%len(v)][1])*multiplier,(x*v[(j+1)%len(v)][1]-y*v[(j+1)%len(v)][0])*multiplier) for j,(x,y) in enumerate(v)]
    pattern,text=features(va,eb),features(vb,ea);failure=[0]*len(pattern);matched=0
    for j in range(1,len(pattern)):
        while matched and pattern[j]!=pattern[matched]:matched=failure[matched-1]
        if pattern[j]==pattern[matched]:matched+=1
        failure[j]=matched
    matched=0
    for j in range(2*len(text)-1):
        value=text[j%len(text)]
        while matched and value!=pattern[matched]:matched=failure[matched-1]
        if value==pattern[matched]:matched+=1
        if matched==len(pattern):return True
    return False

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc016_4':
        ax,ay,bx,by=ints(rows[0],4);n=ints(rows[1],1)[0];require(3<=n<=100 and len(rows)==n+2,'shape');a=(ax,ay);b=(bx,by);polygon=cast(Points,tuple(ints(row,2) for row in rows[2:]));require(all(-1000<=v<=1000 for pair in (a,b)+polygon for v in pair) and len(set(polygon))==n,'coordinates');require(sum(u[0]*v[1]-u[1]*v[0] for u,v in zip(polygon,polygon[1:]+polygon[:1]))>0,'CCW');require(all(cross(polygon[j-1],polygon[j],polygon[(j+1)%n])!=0 for j in range(n)),'noncollinear triples')
        for j in range(n):
            for k in range(j+1,n):
                if k==j+1 or (j==0 and k==n-1):continue
                require(not intersects(polygon[j],polygon[(j+1)%n],polygon[k],polygon[(k+1)%n]),'simple polygon')
        require(all(separated(p,a,b) for p in polygon) and all(separated(p,polygon[j],polygon[(j+1)%n]) for p in (a,b) for j in range(n)) and outside(a,polygon) and outside(b,polygon),'separation/exterior');return a,b,polygon
    if pid=='abc017_4':
        n,m=ints(rows[0],2);require(1<=n<=100000 and 1<=m<=100000 and len(rows)==n+1,'shape');a=tuple(ints(row,1)[0] for row in rows[1:]);require(all(1<=v<=m for v in a),'flavours');return m,a
    if pid=='abc018_4':
        n,m,p,q,r=ints(rows[0],5);require(1<=p<=n<=18 and 1<=q<=m<=18 and 1<=r<=n*m and len(rows)==r+1,'shape');a=tuple(ints(row,3) for row in rows[1:]);require(all(1<=x<=n and 1<=y<=m and 1<=z<=10000 for x,y,z in a) and len({(x,y) for x,y,z in a})==r,'chocolates');return n,m,p,q,a
    if pid=='abc020_d':
        require(len(rows)==1,'shape');n,k=ints(rows[0],2);require(1<=n<=10**9 and 1<=k<=10**9,'domain');return n,k
    if pid=='abc021_d':
        require(len(rows)==2,'shape');n,k=ints(rows[0],1)[0],ints(rows[1],1)[0];require(1<=n<=100000 and 1<=k<=100000,'domain');return n,k
    n=ints(rows[0],1)[0];require(2<=n<=100000 and len(rows)==2*n+1,'shape');a=cast(Points,tuple(ints(row,2) for row in rows[1:n+1]));b=cast(Points,tuple(ints(row,2) for row in rows[n+1:]));require(len(set(a))==len(set(b))==n and all(-15000<=v<=15000 for point in a for v in point) and all(-10**9<=v<=10**9 for point in b for v in point),'coordinates');require(similarity(a,b),'direct similarity P>=1');return a,b
class Fenwick:
    def __init__(self,n:int)->None:self.tree=[0]*(n+1)
    def add(self,j:int,v:int)->None:
        while j<len(self.tree):self.tree[j]=(self.tree[j]+v)%MOD;j+=j&-j
    def prefix(self,j:int)->int:
        total=0
        while j:total+=self.tree[j];j-=j&-j
        return total%MOD

def prime_factors(k:int)->list[tuple[int,int]]:
    result=[];p=2
    while p*p<=k:
        count=0
        while k%p==0:k//=p;count+=1
        if count:result.append((p,count))
        p+=1
    if k>1:result.append((k,1))
    return result

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc016_4':
        a,b,polygon=cast(tuple[Point,Point,Points],data);dx,dy=b[0]-a[0],b[1]-a[1];norm=dx*dx+dy*dy
        if norm==0:return '1'
        cuts=[]
        for u,v in zip(polygon,polygon[1:]+polygon[:1]):
            du,dv=cross(a,b,u),cross(a,b,v)
            if du*dv>=0:continue
            # Interpolate the normal zero crossing, then project along AB.
            x=Fraction(u[0]*dv-v[0]*du,dv-du);y=Fraction(u[1]*dv-v[1]*du,dv-du);parameter=((x-a[0])*dx+(y-a[1])*dy)/norm
            if 0<parameter<1:cuts.append(parameter)
        require(len(cuts)%2==0,'paired cuts');return str(len(cuts)//2+1)
    if pid=='abc017_4':
        m,a=cast(tuple[int,tuple[int,...]],data);n=len(a);right=[0]*n;seen=set();r=0
        for l in range(n):
            while r<n and a[r] not in seen:seen.add(a[r]);r+=1
            right[l]=r;seen.remove(a[l])
        tree=Fenwick(n+1);tree.add(n+1,1);answer=1
        for j in range(n-1,-1,-1):answer=(tree.prefix(right[j]+1)-tree.prefix(j+1))%MOD;tree.add(j+1,answer)
        return str(answer)
    if pid=='abc018_4':
        n,m,p,q,a=cast(tuple[int,int,int,int,tuple[tuple[int,int,int],...]],data);columns=[[0]*n for _ in range(m)]
        for x,y,z in a:columns[y-1][x-1]=z
        totals=[0]*n;previous=0;best=0
        for index in range(1,1<<m):
            mask=index^(index>>1);flip=mask^previous;column=flip.bit_length()-1;sign=1 if mask&flip else -1
            for row,value in enumerate(columns[column]):totals[row]+=sign*value
            if mask.bit_count()==q:best=max(best,sum(sorted(totals,reverse=True)[:p]))
            previous=mask
        return str(best)
    if pid=='abc020_d':
        n,k=cast(tuple[int,int],data);factors=prime_factors(k);divisors=[1]
        for prime,count in factors:divisors=[d*prime**power for d in divisors for power in range(count+1)]
        answer=0
        for divisor in divisors:
            remaining=k//divisor;terms=[(1,1)]
            for prime,count in factors:
                if remaining%prime==0:terms+=[(product*prime,-sign) for product,sign in terms]
            bound=n//divisor;coprime=0
            for product,sign in terms:t=bound//product;coprime+=sign*product*t*(t+1)//2
            answer=(answer+k*coprime)%MOD
        return str(answer)
    if pid=='abc021_d':
        n,k=cast(tuple[int,int],data);upper=n+k-1;sieve=bytearray(b'\1')*(upper+1);sieve[:2]=b'\0\0'
        for prime in range(2,isqrt(upper)+1):
            if sieve[prime]:sieve[prime*prime:upper+1:prime]=b'\0'*((upper-prime*prime)//prime+1)
        answer=1
        for prime in range(2,upper+1):
            if not sieve[prime]:continue
            exponent=0;power=prime
            while power<=upper:exponent+=upper//power-k//power-(n-1)//power;power*=prime
            answer=answer*pow(prime,exponent,MOD)%MOD
        return str(answer)
    a,b=cast(tuple[Points,Points],data)
    with localcontext() as context:context.prec=80;return str((Decimal(energy(b))/Decimal(energy(a))).sqrt())

def numeric_valid(raw:str,actual:str)->bool:
    try:
        a,b=cast(tuple[Points,Points],validate('abc022_d',raw));token=actual.removesuffix('\n')
        if len(token)>1000 or re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None:return False
        exponent=re.search(r'[eE]([+-]?[0-9]+)$',token)
        if exponent and abs(int(exponent[1]))>1000:return False
        value=Fraction(token)
        if value<=0:return False
        ratio=Fraction(energy(b),energy(a));epsilon=Fraction(1,10**6)
        # P>=1 means relative tolerance contains absolute tolerance; square
        # positive bounds to compare the irrational square root exactly.
        return ratio*(1-epsilon)**2<=value*value<=ratio*(1+epsilon)**2
    except (ValueError,TypeError,IndexError,OverflowError,ZeroDivisionError):return False

def independent_check(pid:str,raw:str,actual:str)->bool:
    if pid=='abc022_d':return numeric_valid(raw,actual)
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    if pid=='abc022_d':return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)
    return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc016_4':"ax,ay,bx,by=map(int,input().split());n=int(input());p=[tuple(map(int,input().split())) for _ in range(n)];a=(ax,ay);b=(bx,by)\ndef cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])\ncount=sum(cross(a,b,p[j])*cross(a,b,p[(j+1)%n])<0 and cross(p[j],p[(j+1)%n],a)*cross(p[j],p[(j+1)%n],b)<0 for j in range(n));print(count//2+1)\n",
'abc017_4':"n,m=map(int,input().split());a=[int(input()) for _ in range(n)];mod=1000000007;last={};prefix=[0,1];left=0\nfor j,v in enumerate(a):\n left=max(left,last.get(v,-1)+1);dp=(prefix[-1]-prefix[left])%mod;prefix.append((prefix[-1]+dp)%mod);last[v]=j\nprint(dp)\n",
'abc018_4':"from itertools import combinations\nn,m,p,q,r=map(int,input().split());a=[[0]*m for _ in range(n)]\nfor _ in range(r):x,y,z=map(int,input().split());a[x-1][y-1]=z\nbest=0\nfor girls in combinations(range(n),p):\n scores=[sum(a[x][y] for x in girls) for y in range(m)];best=max(best,sum(sorted(scores,reverse=True)[:q]))\nprint(best)\n",
'abc020_d':"from math import isqrt\nn,k=map(int,input().split());mod=1000000007;divisors=sorted({d for i in range(1,isqrt(k)+1) if k%i==0 for d in (i,k//i)},reverse=True);sums={};answer=0\nfor d in divisors:\n t=n//d;value=d*t*(t+1)//2\n for larger,subtotal in sums.items():\n  if larger%d==0:value-=subtotal\n value%=mod;sums[d]=value;answer=(answer+(k//d)*value)%mod\nprint(answer)\n",
'abc021_d':"n=int(input());k=int(input());mod=1000000007;num=den=1\nfor j in range(1,k+1):num=num*(n+j-1)%mod;den=den*j%mod\nprint(num*pow(den,mod-2,mod)%mod)\n",
'abc022_d':"from math import sqrt\nn=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];b=[tuple(map(int,input().split())) for _ in range(n)]\ndef radius(points):\n x=sum(v[0] for v in points)/n;y=sum(v[1] for v in points)/n\n return max((vx-x)**2+(vy-y)**2 for vx,vy in points)\nprint(sqrt(radius(b)/radius(a)))\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(17900+int(pid[3:6]))
    if pid=='abc016_4':
        def chop(a:Point,b:Point,p:list[Point])->str:return line(a+b)+f'{len(p)}\n'+''.join(line(v) for v in p)
        triangle=[(0,0),(1,0),(0,1)];square=[(-1,-1),(1,-1),(1,1),(-1,1)];concave=[(2,2),(1,2),(1,0),(-1,0),(-1,2),(-2,2),(-2,-1),(2,-1)]
        raws=[chop((-1,-1),(2,-1),triangle),chop((-1,-1),(-1,-1),triangle),chop((-2,0),(2,0),square),chop((-3,1),(3,1),concave)]
        for w in range(3,15):h=w+1;raws.append(chop((-w-1,0),(w+1,0),[(-w,-h),(w,-h),(w,h),(-w,h)]))
        polygon=[(x,x*x-900) for x in range(-25,25)]+[(x,900-x*x) for x in range(24,-26,-1)];raws.extend([chop((-1000,1000),(1000,1000),polygon),chop((-1000,0),(1000,0),polygon)])
    elif pid=='abc017_4':
        def supplements(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+''.join(f'{v}\n' for v in a)
        raws=[supplements(m,a) for m,a in ((1,[1]),(1,[1,1]),(2,[1,2]),(2,[1,2,1]))];raws.extend(supplements(n,[rng.randint(1,n) for _ in range(n)]) for n in range(3,15));raws.extend([supplements(100000,[100000]*100000),supplements(100000,list(range(1,100001)))])
    elif pid=='abc018_4':
        def group(n:int,m:int,p:int,q:int,a:list[tuple[int,int,int]])->str:return f'{n} {m} {p} {q} {len(a)}\n'+''.join(line(v) for v in a)
        raws=[group(n,m,p,q,a) for n,m,p,q,a in ((1,1,1,1,[(1,1,1)]),(2,1,1,1,[(1,1,2)]),(1,2,1,1,[(1,2,2)]),(2,2,1,1,[(1,1,2),(2,2,3)]))]
        for n in range(3,15):a=[(x,y,rng.randint(1,10000)) for x in range(1,n+1) for y in range(1,n+1) if rng.randrange(3)==0];raws.append(group(n,n,rng.randint(1,n),rng.randint(1,n),a or [(1,1,1)]))
        raws.extend([group(18,18,9,9,[(x,y,(x*37+y*71)%10000+1) for x in range(1,19) for y in range(1,19)]),group(18,18,18,18,[(x,y,10000) for x in range(1,19) for y in range(1,19)])])
    elif pid=='abc020_d':
        pairs=[(1,1),(1,10**9),(10**9,1),(4,2)]+[(rng.randint(2,100000),rng.randint(2,100000)) for _ in range(12)]+[(10**9,73513440),(10**9,10**9)];raws=[line(pair) for pair in pairs]
    elif pid=='abc021_d':
        pairs=[(1,1),(1,100000),(100000,1),(2,2)]+[(rng.randint(2,100000),rng.randint(2,100000)) for _ in range(12)]+[(99999,100000),(100000,100000)];raws=[f'{n}\n{k}\n' for n,k in pairs]
    else:
        def stars(a:list[Point],b:list[Point])->str:return f'{len(a)}\n'+''.join(line(v) for v in a+b)
        raws=[stars(a,b) for a,b in (([(0,0),(1,0)],[(0,0),(1,0)]),([(0,0),(1,0)],[(0,0),(1,1)]),([(0,0),(1,0)],[(10,10),(12,10)]),([(0,0),(1,0),(0,1)],[(0,0),(0,2),(-2,0)]))]
        for n in range(3,15):
            a=[(j,j*j) for j in range(n)];scale=n;b=[(-y*scale+100,x*scale-100) for x,y in a];rng.shuffle(b);raws.append(stars(a,b))
        raws.append(stars([(0,0),(1,0)],[(-10**9,-10**9),(10**9,10**9)]));a=[(j%400-200,j//400-125) for j in range(100000)];a[0]=(-15000,-15000);a[1]=(15000,15000);b=[(-y*60000+10**8,x*60000+10**8) for x,y in reversed(a)];raws.append(stars(a,b))
    require(len(raws)==len(set(raws))==18,'unique');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc016_4':('切断線分が板へ入って出るたび、切断された部分が1つ増えます。','頂点や端点が境界にない保証から、各辺との真の交差を外積の符号で判定できます。','疑似コード: 各辺CDでcross(AB,C)*cross(AB,D)<0かつcross(CD,A)*cross(CD,B)<0ならcount++; count//2+1を出力。'),
'abc017_4':('最後の日に食べる連続区間が、同じ味を2回含まない必要があります。','味の最後の出現位置から左端下限を更新します。prefix DPで有効な左端すべての和を求めます。','疑似コード: dp[0]=1,prefixを保持; 各jでleft=max(left,last[f]+1); dp[j+1]=sum(dp[left..j])をprefix差で計算; last[f]=j; 最終dpを1e9+7で出力。'),
'abc018_4':('女子の選び方を固定すると、各男子の幸福度を足せます。','女子P人の全組合せを列挙し、男子ごとの得点の上位Q人を選びます。','疑似コード: combinations(女子,P)ごとにscore[男子]=選んだ女子からの幸福度合計; score降順の先頭Q個を足しbest更新。'),
'abc020_d':('LCM(i,K)=i*K/gcd(i,K)です。gcdの値はKの約数です。','Kの約数dについて、gcd(i,K)=dのiの和を大きい約数から引いて求めます。','疑似コード: dを降順; total[d]=d*tri(N//d)-sum(total[e] for e>dかつe%d=0); answer+=K//d*total[d]; 1e9+7剰余。'),
'abc021_d':('非減少列は、n種類からk個を重複ありで選ぶことと同じです。','仕切りを置く方法を数えると、答えはC(n+k-1,k)です。','疑似コード: num=積(n..n+k-1),den=積(1..k)をmod計算; num*pow(den,mod-2,mod)%modを出力。'),
'abc022_d':('点の対応が不明でも、重心は同じ変換を受けます。','重心から最も遠い点の距離は、拡大によってP倍になります。各集合の最大二乗距離の比を使います。','疑似コード: A,Bそれぞれ重心を求め、max((x-cx)^2+(y-cy)^2)を計算; sqrt(maxB/maxA)を出力。')}

TITLES={'abc016_4': '一刀両断', 'abc017_4': 'サプリメント', 'abc018_4': 'バレンタインデー', 'abc020_d': 'LCM Rush', 'abc021_d': '多重ループ', 'abc022_d': 'Big Bang'}
PUBLISHED_SAMPLES={'abc016_4': [{'input': '-2 0 2 0\n4\n1 1\n-1 1\n-1 -1\n1 -1\n', 'expected': '2\n'}, {'input': '-3 1 3 1\n8\n2 2\n1 2\n1 0\n-1 0\n-1 2\n-2 2\n-2 -1\n2 -1\n', 'expected': '3\n'}], 'abc017_4': [{'input': '5 2\n1\n2\n1\n2\n2\n', 'expected': '5\n'}, {'input': '6 6\n1\n2\n3\n4\n5\n6\n', 'expected': '32\n'}], 'abc018_4': [{'input': '3 4 2 3 7\n1 1 9\n1 2 7\n1 3 15\n1 4 6\n2 2 3\n2 4 6\n3 3 6\n', 'expected': '37\n'}, {'input': '4 5 3 2 9\n2 3 5\n3 1 4\n2 2 2\n4 1 9\n3 5 3\n3 3 8\n1 4 5\n1 5 7\n2 4 8\n', 'expected': '26\n'}], 'abc020_d': [{'input': '4 2\n', 'expected': '14\n'}, {'input': '10000 100\n', 'expected': '865504986\n'}, {'input': '1000000000 90\n', 'expected': '50001213\n'}, {'input': '1000000000 999999900\n', 'expected': '231285006\n'}], 'abc021_d': [{'input': '10\n2\n', 'expected': '55\n'}, {'input': '10\n3\n', 'expected': '220\n'}, {'input': '10\n4\n', 'expected': '715\n'}, {'input': '400\n296\n', 'expected': '546898535\n'}, {'input': '100000\n100000\n', 'expected': '939733670\n'}], 'abc022_d': [{'input': '4\n0 0\n0 1\n1 0\n1 1\n0 2\n2 0\n-2 0\n0 -2\n', 'expected': '2.8284271247\n'}, {'input': '6\n3 4\n1 3\n4 3\n2 2\n0 1\n2 0\n5 5\n-1 2\n-1 -3\n2 1\n2 6\n4 -3\n', 'expected': '2.2360679775\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
