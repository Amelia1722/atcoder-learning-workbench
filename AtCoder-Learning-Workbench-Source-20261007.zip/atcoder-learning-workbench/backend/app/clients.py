from __future__ import annotations

import asyncio
import html
import json
import re
import time
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote_plus

import httpx
from bs4 import BeautifulSoup

KENKOOO = "https://kenkoooo.com/atcoder"
ATCODER = "https://atcoder.jp"
TAGGED = "https://atcoder-tagged-backend.onrender.com"
UA = "AtCoderLearningWorkbench/1.0 (personal local app)"


class RemoteError(RuntimeError):
    pass


class AccessDenied(RemoteError):
    """An upstream denial must not trigger alternate-source requests."""
    pass


async def fetch_json(url: str, *, timeout: float = 30.0) -> Any:
    async with httpx.AsyncClient(headers={"User-Agent": UA}, follow_redirects=True, timeout=timeout) as client:
        r = await client.get(url)
        if r.status_code in (401, 403):
            raise AccessDenied(f"Public source denied access (HTTP {r.status_code}); no alternate source was attempted")
        r.raise_for_status()
        return r.json()


async def fetch_text(url: str, *, timeout: float = 30.0) -> str:
    async with httpx.AsyncClient(headers={"User-Agent": UA}, follow_redirects=True, timeout=timeout) as client:
        r = await client.get(url)
        if r.status_code in (401, 403):
            raise AccessDenied(f"Public source denied access (HTTP {r.status_code}); no alternate source was attempted")
        r.raise_for_status()
        return r.text


async def kenkoooo_resources() -> tuple[list[dict], list[dict], list[dict], dict]:
    # Kenkoooo asks clients to avoid frequent requests. Fetch sequentially and
    # leave >1 second between resource requests; local SQLite is the cache.
    urls = [
        f"{KENKOOO}/resources/problems.json",
        f"{KENKOOO}/resources/contests.json",
        f"{KENKOOO}/resources/contest-problem.json",
        f"{KENKOOO}/resources/problem-models.json",
    ]
    out = []
    for i, url in enumerate(urls):
        out.append(await fetch_json(url))
        if i + 1 < len(urls):
            await asyncio.sleep(1.05)
    p, c, cp, models = out
    return p, c, cp, models


async def user_submissions(user_id: str, from_second: int) -> list[dict]:
    rows: dict[int, dict] = {}
    cursor = max(0, int(from_second))
    for _ in range(200):
        url = f"{KENKOOO}/atcoder-api/v3/user/submissions?user={quote_plus(user_id)}&from_second={cursor}"
        batch = await fetch_json(url)
        if not isinstance(batch, list):
            raise RemoteError("Submission API returned an invalid page")
        if not batch:
            return list(rows.values())
        try:
            epochs = [int(row["epoch_second"]) for row in batch]
            for row in batch:
                rows[int(row["id"])] = row
        except (KeyError, TypeError, ValueError) as error:
            raise RemoteError("Submission API returned an invalid row") from error
        if len(batch) < 500:
            return list(rows.values())
        # Re-read the boundary second: +1 can lose submissions split across pages.
        newest = max(epochs)
        if newest <= cursor:
            raise RemoteError("Submission pagination stalled at a full timestamp; history is incomplete")
        cursor = newest
        await asyncio.sleep(1.05)
    raise RemoteError("Submission pagination limit reached; history is incomplete")


async def submissions_from_time(from_second: int, *, max_pages: int = 6) -> list[dict]:
    """Fetch the public time-ordered submission stream.

    This is an independent fallback from the user-specific endpoint.  The API
    may cap one response, so advance by the newest epoch for a small number of
    pages.  Callers should keep this fallback rate-limited.
    """
    cursor = max(0, int(from_second))
    all_rows: dict[int, dict] = {}
    for page in range(max(1, int(max_pages))):
        data = await fetch_json(f"{KENKOOO}/atcoder-api/v3/from/{cursor}")
        if not isinstance(data, list) or not data:
            break
        newest = cursor
        for x in data:
            try:
                sid = int(x["id"])
                epoch = int(x.get("epoch_second", 0) or 0)
            except Exception:
                continue
            all_rows[sid] = x
            newest = max(newest, epoch)
        if newest <= cursor:
            break
        cursor = newest + 1
        if page + 1 < max_pages:
            await asyncio.sleep(1.05)
    return list(all_rows.values())

async def recent_submissions() -> list[dict]:
    """Fetch the small rolling window used by AtCoder Problems itself for recent activity."""
    data = await fetch_json(f"{KENKOOO}/atcoder-api/v3/recent")
    return data if isinstance(data, list) else []


def _parse_atcoder_time(raw: str) -> int | None:
    raw = raw.strip()
    if not raw:
        return None
    candidates = [raw, raw.replace(" ", "T", 1)]
    for value in candidates:
        try:
            dt = datetime.fromisoformat(value)
            if dt.tzinfo is None:
                # AtCoder renders submission times in JST when no offset is embedded.
                from datetime import timedelta
                dt = dt.replace(tzinfo=timezone(timedelta(hours=9)))
            return int(dt.timestamp())
        except Exception:
            pass
    return None


async def atcoder_contest_submissions(contest_id: str, user_id: str, from_second: int = 0) -> list[dict]:
    """Scrape the public AtCoder contest submission list for one user.

    This is a narrow fallback for active solve sessions only, so a temporary
    AtCoder Problems crawler delay does not keep the local timer/status stale.
    """
    url = f"{ATCODER}/contests/{quote_plus(contest_id)}/submissions?f.User={quote_plus(user_id)}&lang=en"
    text = await fetch_text(url, timeout=30)
    soup = BeautifulSoup(text, "html.parser")
    table = soup.find("table")
    if table is None:
        return []
    headers = [th.get_text(" ", strip=True) for th in table.find_all("th")]
    hmap = {name: i for i, name in enumerate(headers)}
    out: list[dict] = []
    for tr in table.find_all("tr"):
        cells = tr.find_all("td")
        if not cells:
            continue
        detail = tr.find("a", href=re.compile(r"/submissions/\d+$"))
        task = tr.find("a", href=re.compile(r"/tasks/[^/]+$"))
        if detail is None or task is None:
            continue
        m_sid = re.search(r"/submissions/(\d+)$", detail.get("href", ""))
        m_pid = re.search(r"/tasks/([^/]+)$", task.get("href", ""))
        if not m_sid or not m_pid:
            continue
        time_node = tr.find("time")
        raw_time = ""
        if time_node is not None:
            raw_time = time_node.get("datetime") or time_node.get_text(" ", strip=True)
        epoch = _parse_atcoder_time(raw_time)
        if epoch is None or epoch < int(from_second):
            continue
        def cell(name: str) -> str:
            i = hmap.get(name)
            return cells[i].get_text(" ", strip=True) if i is not None and i < len(cells) else ""
        result = cell("Status")
        language = cell("Language") or None
        score = cell("Score")
        code_size = cell("Code Size")
        exec_time = cell("Exec Time")
        def first_int(x: str) -> int | None:
            m = re.search(r"-?\d+", x.replace(",", ""))
            return int(m.group()) if m else None
        out.append({
            "id": int(m_sid.group(1)),
            "epoch_second": epoch,
            "problem_id": m_pid.group(1),
            "contest_id": contest_id,
            "user_id": user_id,
            "language": language,
            "point": first_int(score),
            "length": first_int(code_size),
            "result": result,
            "execution_time": first_int(exec_time),
        })
    return out


async def fetch_user_rating(user_id: str) -> int | None:
    text = await fetch_text(f"{ATCODER}/users/{user_id}?lang=en")
    soup = BeautifulSoup(text, "html.parser")
    # Current AtCoder user pages contain a th/td pair for Rating.
    for th in soup.find_all("th"):
        if th.get_text(" ", strip=True).lower() == "rating":
            td = th.find_next_sibling("td")
            if td:
                m = re.search(r"-?\d+", td.get_text(" ", strip=True).replace(",", ""))
                if m:
                    return int(m.group())
    # Fallback for layout changes.
    plain = soup.get_text(" ", strip=True)
    m = re.search(r"Rating\s*(\d+)", plain, re.I)
    return int(m.group(1)) if m else None


async def fetch_submission_source(contest_id: str, submission_id: int) -> str | None:
    text = await fetch_text(f"{ATCODER}/contests/{contest_id}/submissions/{submission_id}")
    soup = BeautifulSoup(text, "html.parser")
    node = soup.find("pre", id="submission-code")
    if node is None:
        return None
    return html.unescape(node.get_text())


async def fetch_ai_tags() -> list[dict]:
    """Optional enrichment source. Failure is non-fatal; local tags remain available."""
    data = await fetch_json(f"{TAGGED}/problems/all", timeout=90)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("problems", "data", "items"):
            if isinstance(data.get(key), list):
                return data[key]
    return []
