"""Problem-specific three-stage hints from manually reviewed public ABC047–049 B tasks."""
HINTS_V63 = {
    'abc047_b': (
        '黒く塗った領域を一つずつ保存する代わりに、白く残り得る場所の端を考えてください。',
        '白い長方形の左・右・下・上の境界をそれぞれ更新し、幅と高さが正なら面積を求めます。',
        '疑似コード:\nleft=bottom=0; right=W; top=H\n各操作 (x,y,a) について aに応じて境界を max/min で更新\nprint(max(0,right-left)*max(0,top-bottom))',
    ),
    'abc048_b': (
        '区間を端から一つずつ調べる代わりに、ある値以下の倍数の個数を考えてください。',
        '0もXの倍数です。B以下の倍数個数からA未満の倍数個数を引きます。',
        '疑似コード:\na,b,xを読む\nans=b//x - (a-1)//x\nprint(ans)',
    ),
    'abc049_b': (
        '画像の横幅を変える必要はありません。縦方向の行数だけに注目してください。',
        '入力の各行を読んだ直後に同じ行をもう一度出力します。',
        '疑似コード:\nH,Wを読む\nH回繰り返す:\n  rowを読む\n  print(row)\n  print(row)',
    ),
}
