"""Reviewed C tasks with four-run reductions, square representation counts and phases."""
from __future__ import annotations
from array import array
from bisect import bisect_right
from collections import defaultdict,deque
from functools import cache,lru_cache
from heapq import heappush,heappop
from itertools import groupby
from math import isqrt,comb
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(437,443))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pairs=tuple[tuple[int,int],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==437:
        t=ints(rows[0],1)[0];require(1<=t<=100000,'cases');p=1;cases=[];total=0
        for _ in range(t):
            require(p<len(rows),'case');n=ints(rows[p],1)[0];p+=1;require(1<=n<=300000 and p+n<=len(rows),'length');a=tuple(ints(row,2) for row in rows[p:p+n]);p+=n;require(all(1<=v<=10**9 for pair in a for v in pair),'reindeer');cases.append(a);total+=n
        require(total<=300000 and p==len(rows),'total');return (tuple(cases),)
    if number==438:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=200000 and all(1<=v<=n for v in a),'values');return (a,)
    if number==439:
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=10**7,'bound');return (n,)
    if number==440:
        t=ints(rows[0],1)[0];require(1<=t<=200000 and len(rows)==1+2*t,'cases');totaln=totalw=0;cases=[]
        for j in range(t):n,w=ints(rows[1+2*j],2);a=ints(rows[2+2*j],n);require(1<=n<=200000 and 1<=w<=200000 and all(1<=v<=10**9 for v in a),'paint');cases.append((w,a));totaln+=n;totalw+=w
        require(totaln<=200000 and totalw<=200000,'total');return (tuple(cases),)
    if number==441:
        require(len(rows)==2,'shape');n,k,x=ints(rows[0],3);a=ints(rows[1],n);require(1<=k<=n<=300000 and 1<=x<=3*10**14 and all(1<=v<=10**9 for v in a),'cups');return k,x,a
    n,m=ints(rows[0],2);require(1<=n<=200000 and 0<=m<=200000 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=u<=n and 1<=v<=n and u!=v for u,v in a) and len({tuple(sorted(pair)) for pair in a})==m,'conflicts');return n,a
@cache
def square_unique_numbers()->array:
    limit=10**7;spf=array('I',[0])*(limit+1)
    for prime in range(2,isqrt(limit)+1):
        if spf[prime]:continue
        for n in range(prime*prime,limit+1,prime):
            if not spf[n]:spf[n]=prime
    rest=array('I',[0])*(limit+1);exponent=bytearray(limit+1);bad=bytearray(limit+1);ways=bytearray(limit+1);ways[1]=1;good=array('I')
    for n in range(2,limit+1):
        prime=spf[n] or n;quotient=n//prime
        if quotient>1 and (spf[quotient] or quotient)==prime:exponent[n]=exponent[quotient]+1;rest[n]=rest[quotient]
        else:exponent[n]=1;rest[n]=quotient
        core=rest[n];bad[n]=bad[core]+(exponent[n]%2 if prime%4==3 else 0);ways[n]=min(4,ways[core]*(exponent[n]+1)) if prime%4==1 else ways[core]
        # r2=4*product(e+1); remove 4 axis/diagonal representations.
        # Exactly one positive unequal pair iff the product is 2 or 3.
        if not bad[n] and ways[n] in (2,3):good.append(n)
    return good
@lru_cache(maxsize=32)
def good_output(n:int)->str:
    values=square_unique_numbers();count=bisect_right(values,n);return str(count)+'\n'+' '.join(map(str,values[:count]))
def choose(n:int,k:int)->int:return comb(n,k) if 0<=k<=n else 0
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==437:
        out=[]
        for a in cast(tuple[Pairs,...],data[0]):
            budget=sum(p for w,p in a);heap=[];spent=0
            for w,p in a:
                spent+=w+p;heappush(heap,-w-p)
                if spent>budget:spent+=heappop(heap)
            out.append(str(len(heap)))
        return '\n'.join(out)
    if number==438:
        a=cast(tuple[int,...],data[0]);runs=[(v,len(list(seq))%4) for v,seq in groupby(a)];n=len(runs);values=[v for v,c in runs];counts=[c for v,c in runs];before=[j-1 for j in range(n)];after=[j+1 if j+1<n else -1 for j in range(n)];alive=[True]*n;pending=deque(j for j,c in enumerate(counts) if c==0)
        while pending:
            v=pending.popleft()
            if not alive[v] or counts[v]:continue
            left,right=before[v],after[v];alive[v]=False
            if left>=0:after[left]=right
            if right>=0:before[right]=left
            if left>=0 and right>=0 and values[left]==values[right]:
                counts[left]=(counts[left]+counts[right])%4;alive[right]=False;nextv=after[right];after[left]=nextv
                if nextv>=0:before[nextv]=left
                if counts[left]==0:pending.append(left)
        return str(sum(c for c,live in zip(counts,alive) if live))
    if number==439:return good_output(cast(int,data[0]))
    if number==440:
        out=[]
        for w,a in cast(tuple[tuple[int,tuple[int,...]],...],data[0]):
            period=2*w;events:dict[int,int]=defaultdict(int);events[0]+=0;events[period]+=0
            for j,c in enumerate(a,1):
                start=(-j)%period;end=start+w-1
                if end<period:events[start]+=c;events[end+1]-=c
                else:events[start]+=c;events[period]-=c;events[0]+=c;events[end-period+1]-=c
            current=0;best=sum(a)
            for phase in sorted(events):
                current+=events[phase]
                if phase<period:best=min(best,current)
            out.append(str(best))
        return '\n'.join(out)
    if number==441:
        k,x,a=cast(tuple[int,int,tuple[int,...]],data);ordered=sorted(a);prefix=[0]
        for v in ordered:prefix.append(prefix[-1]+v)
        n=len(a);low=n-k;high=n+1
        while high-low>1:
            count=(low+high)//2;guaranteed=prefix[k]-prefix[n-count]
            if guaranteed>=x:high=count
            else:low=count
        return str(high if high<=n else -1)
    n,a=cast(tuple[int,Pairs],data);degree=[0]*n
    for u,v in a:degree[u-1]+=1;degree[v-1]+=1
    return ' '.join(str(sum((-1)**j*choose(d+1,j)*choose(n-j,3-j) for j in range(4))) for d in degree)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        expected=oracle(pid,raw)
        return actual in (expected,expected+'\n') if pid=='abc439_c' else actual.removesuffix('\n')==expected
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc437_c':"t=int(input())\nfor _ in range(t):\n n=int(input());a=[tuple(map(int,input().split())) for _ in range(n)];budget=sum(p for w,p in a);spent=0;answer=0\n for cost in sorted(w+p for w,p in a):\n  if spent+cost>budget:break\n  spent+=cost;answer+=1\n print(answer)\n",
'abc438_c':"n=int(input());a=list(map(int,input().split()));stack=[]\nfor v in a:\n if stack and stack[-1][0]==v:stack[-1][1]+=1\n else:stack.append([v,1])\n if stack[-1][1]==4:stack.pop()\nprint(sum(c for v,c in stack))\n",
'abc439_c':"from math import isqrt\nn=int(input());counts=bytearray(n+1)\nfor x in range(1,isqrt(n//2)+1):\n for y in range(x+1,isqrt(n-x*x)+1):\n  value=x*x+y*y\n  if counts[value]<2:counts[value]+=1\ngood=[j for j in range(n+1) if counts[j]==1];print(len(good));print(*good)\n",
'abc440_c':"t=int(input())\nfor _ in range(t):\n n,w=map(int,input().split());a=list(map(int,input().split()));bucket=[0]*(2*w)\n for j,v in enumerate(a,1):bucket[j%(2*w)]+=v\n prefix=[0]\n for v in bucket+bucket:prefix.append(prefix[-1]+v)\n print(min(prefix[j+w]-prefix[j] for j in range(2*w)))\n",
'abc441_c':"n,k,x=map(int,input().split());a=sorted(map(int,input().split()),reverse=True);total=0;answer=-1\nfor j in range(n-k,n):\n total+=a[j]\n if total>=x:answer=j+1;break\nprint(answer)\n",
'abc442_c':"n,m=map(int,input().split());degree=[0]*n\nfor _ in range(m):u,v=map(int,input().split());degree[u-1]+=1;degree[v-1]+=1\nprint(*(max(0,n-1-d)*max(0,n-2-d)*max(0,n-3-d)//6 for d in degree))\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17600+number)
    if number==437:
        def reindeer(cases:list[list[tuple[int,int]]])->str:return f'{len(cases)}\n'+''.join(f'{len(a)}\n'+''.join(f'{w} {p}\n' for w,p in a) for a in cases)
        raws=[reindeer(cases) for cases in ([[(1,1)]],[[(1,2),(1,2)]],[[(5,1),(1,5)]],[[(1,1)],[(2,1),(1,2)]] )];raws.extend(reindeer([[(rng.randint(1,100),rng.randint(1,100)) for _ in range(n)]]) for n in range(3,15));raws.extend([reindeer([[(1,10**9)]*300000]),reindeer([[(10**9,10**9)]*3]*100000)])
    elif number==438:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[1,1,1,1],[1,2,2,2,2,1],[1,1,2,2,2,2,1,1])];raws.extend(arr([rng.randint(1,min(n,4)) for _ in range(n)]) for n in range(3,15));raws.extend([arr([1]*99998+[2]*4+[1]*99998),arr([200000]*200000)])
    elif number==439:raws=[f'{n}\n' for n in (1,4,5,10,13,25,50,100,200,500,1000,10000,100000,1000000,5000000,9999990,9999999,10000000)]
    elif number==440:
        def paint(cases:list[tuple[int,list[int]]])->str:return f'{len(cases)}\n'+''.join(f'{len(a)} {w}\n'+line(a) for w,a in cases)
        raws=[paint(a) for a in ([(1,[1])],[(1,[1,2])],[(2,[1,2,3])],[(5,[1,2,3])])];raws.extend(paint([(rng.randint(1,n+3),[rng.randint(1,100) for _ in range(n)])]) for n in range(3,15));raws[15]=paint([(200000,[10**9]*200000)]);raws.extend([paint([(100000,[10**9]*200000)]),paint([(1,[10**9])]*200000)])
    elif number==441:
        def cups(k:int,x:int,a:list[int])->str:return f'{len(a)} {k} {x}\n'+line(a)
        raws=[cups(k,x,a) for k,x,a in ((1,1,[1]),(1,2,[1]),(1,1,[1,1]),(2,3,[1,2,3]))];raws.extend(cups(rng.randint(1,n),rng.randint(1,500),[rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([cups(1,10**9,[10**9]*300000),cups(300000,3*10**14,[10**9]*300000)])
    else:
        def reviewers(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{u} {v}\n' for u,v in a)
        raws=[reviewers(n,a) for n,a in ((1,[]),(4,[]),(4,[(1,2)]),(4,[(2,1),(2,3)]))];raws.extend(reviewers(n,rng.sample([(u,v) for u in range(1,n+1) for v in range(u+1,n+1)],n)) for n in range(5,17));raws.extend([reviewers(200000,[]),reviewers(200000,[(1,j) for j in range(2,200001)]+[(2,3)])])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc437_c':('乗せるトナカイは、自分の力を引く側から失わせます。','乗せる選択の費用はW+Pで、全員の力の合計が予算です。費用の小さい順に選びます。','疑似コード: budget=sum(P); costs=sort(W+P); spent+cost<=budgetの間順に選び、選んだ数を出力。'),
'abc438_c':('同じ値の連続数をstackで持つと、4個揃ったときに消せます。','末尾へ追加し、最後の連続数が4になったらその塊を取り除きます。','疑似コード: 各Aをstack末尾の同値runへ足すか新run追加; count=4ならpop; 最後のcount合計を出力。'),
'abc439_c':('xとyはどちらもsqrt(N)以下です。','x<yかつx²+y²<=Nの全組を列挙し、各和の登場回数を2で打ち切って数えます。','疑似コード: x=1..isqrt(N/2); y=x+1..isqrt(N-x²); count[x²+y²]=min(2,count+1); count=1の整数を昇順抽出; 個数と列を2行で出力（0件なら空2行目）。'),
'abc440_c':('位相を2W通り試せば、すべての縞模様を網羅できます。','添字を2Wで割った余りごとに費用を足し、円環上の長さWの区間和の最小を求めます。','疑似コード: bucket[i%(2W)]+=C[i]; bucketを2回連結してprefix; 全start=0..2W-1のprefix[start+W]-prefix[start]の最小。'),
'abc441_c':('選ぶカップは大きいものから選ぶと保証量が最大です。','選んだm個のうちN-K個までは水かもしれません。残る小さい方の液量が保証されます。','疑似コード: A降順sort; j=N-K..N-1でA[j]を累積; X以上になる最初のj+1が答え、最後まで不足なら-1。'),
'abc442_c':('著者と利害関係者を除いた人はすべて査読候補です。','各著者の候補数はN-1-degreeで、そこから3人選びます。','疑似コード: 各辺の両端degree++; 各iでm=N-1-degree[i]; m>=3ならm*(m-1)*(m-2)//6、他は0を出力。')}

TITLES={'abc437_c': 'Reindeer and Sleigh 2', 'abc438_c': '1D puyopuyo', 'abc439_c': '2026', 'abc440_c': 'Striped Horse', 'abc441_c': 'Sake or Water', 'abc442_c': 'Peer Review'}
PUBLISHED_SAMPLES={'abc437_c': [{'input': '3\n3\n3 1\n4 1\n5 9\n5\n1000000000 1\n1000000000 1\n1000000000 1\n1000000000 1\n1000000000 1\n10\n133180711 458704923\n531424946 225863856\n141986070 637075158\n500770732 289806469\n502866767 408857335\n559714289 569084545\n287444582 992432993\n559747907 753133304\n432846188 949871298\n727072164 756020367\n', 'expected': '2\n0\n6\n'}], 'abc438_c': [{'input': '10\n1 1 1 4 4 4 4 1 2 3\n', 'expected': '2\n'}, {'input': '3\n2 1 3\n', 'expected': '3\n'}, {'input': '13\n1 1 4 4 4 1 1 1 1 4 1 4 1\n', 'expected': '5\n'}], 'abc439_c': [{'input': '10\n', 'expected': '2\n5 10\n'}, {'input': '1\n', 'expected': '0\n\n'}, {'input': '50\n', 'expected': '14\n5 10 13 17 20 25 26 29 34 37 40 41 45 50\n'}], 'abc440_c': [{'input': '4\n8 2\n1 10 10 1 1 10 10 1\n8 3\n1 10 10 1 1 10 10 1\n8 4\n1 10 10 1 1 10 10 1\n4 100\n100000 100000 100000 100000\n', 'expected': '4\n12\n22\n0\n'}], 'abc441_c': [{'input': '3 2 5\n10 6 8\n', 'expected': '2\n'}, {'input': '2 1 8\n6 10\n', 'expected': '-1\n'}, {'input': '5 3 3000000000\n1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '5\n'}], 'abc442_c': [{'input': '6 5\n1 2\n1 4\n2 3\n5 3\n3 1\n', 'expected': '0 1 0 4 4 10\n'}, {'input': '7 3\n1 2\n3 4\n5 6\n', 'expected': '10 10 10 10 10 10 20\n'}, {'input': '6 9\n3 6\n2 5\n2 3\n4 3\n1 5\n6 2\n3 1\n5 3\n2 4\n', 'expected': '1 0 0 1 0 1\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
