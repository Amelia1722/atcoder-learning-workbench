"""ABC077–079 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS=('abc077_b','abc078_b','abc079_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)


def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc077_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('N')
        n=int(lines[0])
        if not 1<=n<=10**9: raise ValueError('range')
        return n
    if pid=='abc078_b':
        if len(lines)!=1: raise ValueError('line count')
        parts=lines[0].split(' ')
        if len(parts)!=3 or any(POS.fullmatch(x) is None for x in parts): raise ValueError('X/Y/Z')
        x,y,z=map(int,parts)
        if not (1<=x<=10**5 and 1<=y<=10**5 and 1<=z<=10**5 and y+2*z<=x):
            raise ValueError('range')
        return x,y,z
    if len(lines)!=1 or POS.fullmatch(lines[0]) is None: raise ValueError('N')
    n=int(lines[0])
    if not 1<=n<=86: raise ValueError('range')
    return n


def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str): return False
    if pid=='abc077_b':
        n=value
        lo,hi=0,31624
        while hi-lo>1:
            mid=(lo+hi)//2
            if mid*mid<=n: lo=mid
            else: hi=mid
        return output==str(lo*lo)
    if pid=='abc078_b':
        x,y,z=value
        # Structurally independent from the closed-form reference: greedily add
        # one occupied block plus one following gap while preserving both edges.
        used=z
        people=0
        while used+y+z<=x:
            used += y+z
            people += 1
        return output==str(people)
    n=value
    # Lucas(n) = Fibonacci(n-1) + Fibonacci(n+1), for n>=1.
    f0,f1=0,1
    fib=[f0,f1]
    for _ in range(2,n+2):
        fib.append(fib[-1]+fib[-2])
    return output==str(fib[n-1]+fib[n+1])


def generate(pid:str, seed:int=73)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rng=random.Random(f'abc-v73:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc077_b':
        vals=[1,2,3,4,8,9,10,15,16,17,24,25,26,99,100,101,999950884]
        for n in vals:
            add('boundary' if n<=4 or int(n**0.5)**2==n else 'normal',f'{n}\n')
        add('constraint_max','1000000000\n')
    elif pid=='abc078_b':
        vals=[
            (3,1,1),(4,1,1),(5,1,1),(7,2,1),(8,2,1),(9,2,1),
            (13,3,1),(12,3,1),(20,4,2),(21,4,2),(100,10,5),(101,10,5),
            (30,1,10),(1000,333,1),(99999,1,1),(99999,99997,1),(50000,1,24999)
        ]
        for x,y,z in vals:
            add('boundary' if y+2*z==x or x>=99999 else 'normal',f'{x} {y} {z}\n')
        add('constraint_max','100000 1 1\n')
    else:
        vals=[1,2,3,4,5,6,7,8,10,15,20,30,40,50,60,70,85]
        for n in vals:
            add('boundary' if n in (1,85) else 'normal',f'{n}\n')
        add('constraint_max','86\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
