"""ABC059–061 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import random
import re

TASKS = ('abc059_b','abc060_b','abc061_b')
INT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
POS = re.compile(r'[1-9][0-9]*', re.ASCII)


def _le_10_pow_100(s: str) -> bool:
    if POS.fullmatch(s) is None:
        return False
    if len(s) <= 100:
        return True
    return len(s) == 101 and s == '1' + '0'*100


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc059_b':
        if len(lines) != 2 or not all(_le_10_pow_100(s) for s in lines):
            raise ValueError('positive integer bounds')
        return lines[0], lines[1]
    if pid == 'abc060_b':
        if len(lines) != 1:
            raise ValueError('line count')
        t = lines[0].split(' ')
        if len(t) != 3 or any(INT.fullmatch(x) is None for x in t):
            raise ValueError('integer tokens')
        a,b,c = map(int,t)
        if not (1 <= a <= 100 and 1 <= b <= 100 and 0 <= c < b):
            raise ValueError('value range')
        return a,b,c
    if not lines:
        raise ValueError('missing header')
    h = lines[0].split(' ')
    if len(h) != 2 or any(INT.fullmatch(x) is None for x in h):
        raise ValueError('header')
    n,m = map(int,h)
    if not (2 <= n <= 50 and 2 <= m <= 50) or len(lines) != m + 1:
        raise ValueError('counts')
    edges=[]
    for line in lines[1:]:
        t=line.split(' ')
        if len(t)!=2 or any(INT.fullmatch(x) is None for x in t):
            raise ValueError('edge tokens')
        a,b=map(int,t)
        if not (1 <= a <= n and 1 <= b <= n and a != b):
            raise ValueError('edge range')
        edges.append((a,b))
    return n,edges


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value=validate(pid,raw)
    except (ValueError,TypeError,IndexError):
        return False
    if not isinstance(output,str):
        return False
    if pid == 'abc059_b':
        a,b=value
        if len(a)!=len(b):
            expected='GREATER' if len(a)>len(b) else 'LESS'
        elif a==b:
            expected='EQUAL'
        else:
            expected='GREATER' if a>b else 'LESS'
        return output==expected
    if pid == 'abc060_b':
        a,b,c=value
        # Independent finite reachability check over the residue cycle.
        reachable=set()
        cur=0
        for _ in range(b):
            cur=(cur+a)%b
            reachable.add(cur)
        return output==('YES' if c in reachable else 'NO')
    n,edges=value
    # Independent incidence scan per city (rather than updating degree while reading).
    expected=[]
    for city in range(1,n+1):
        expected.append(str(sum(1 for a,b in edges if a==city or b==city)))
    return output=='\n'.join(expected)


def generate(pid: str, seed: int=67) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    rng=random.Random(f'abc-v67:{pid}:{seed}')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid == 'abc059_b':
        fixtures=[
            ('1','1'),('1','2'),('2','1'),('9','10'),('10','9'),('99','100'),
            ('100','99'),('123456789','123456789'),('99999999999999999999','100000000000000000000'),
            ('1'+'0'*99,'9'*100),('9'*100,'1'+'0'*99),('1'+'0'*100,'9'*100),
            ('9'*100,'1'+'0'*100),('12345678901234567890','12345678901234567891')]
        for a,b in fixtures:
            add('boundary' if len(a)!=len(b) or len(a)>=100 else 'normal',f'{a}\n{b}\n')
        while len(rows)<17:
            la=rng.randint(1,100); lb=rng.randint(1,100)
            a=str(rng.randint(1,9))+''.join(str(rng.randint(0,9)) for _ in range(la-1))
            b=str(rng.randint(1,9))+''.join(str(rng.randint(0,9)) for _ in range(lb-1))
            add('random',f'{a}\n{b}\n')
        add('constraint_max',f'{"1"+"0"*100}\n{"1"+"0"*100}\n')
    elif pid == 'abc060_b':
        fixtures=[(1,1,0),(1,100,0),(1,100,99),(100,100,0),(100,100,1),(2,4,2),(2,4,1),
                  (6,8,4),(6,8,2),(7,5,1),(40,98,58),(77,42,36),(99,100,1),(100,99,98)]
        for a,b,c in fixtures:
            add('boundary' if c in (0,b-1) or a==100 or b==100 else 'normal',f'{a} {b} {c}\n')
        while len(rows)<17:
            a=rng.randint(1,100); b=rng.randint(1,100); c=rng.randint(0,b-1)
            add('random',f'{a} {b} {c}\n')
        add('constraint_max','100 100 99\n')
    else:
        def fmt(n,edges):
            return f'{n} {len(edges)}\n'+''.join(f'{a} {b}\n' for a,b in edges)
        fixtures=[
            (2,[(1,2),(1,2)]),(2,[(1,2)]*5),(3,[(1,2),(2,3)]),(3,[(1,2),(1,3),(2,3)]),
            (4,[(1,2),(2,3),(1,4)]),(4,[(1,2),(2,1),(1,2),(3,4)]),
            (5,[(1,5),(2,5),(3,5),(4,5)]),(5,[(1,2),(1,2),(1,2),(3,4),(3,4)]),
            (6,[(1,2),(2,3),(3,4),(4,5),(5,6),(6,1)]),
            (10,[(1,2),(3,4)]),(10,[(1,10),(1,10),(2,9),(2,9),(5,6)]),
            (50,[(1,50),(25,26)]),(3,[(1,2),(1,2),(1,2),(1,2),(1,2)])]
        for n,e in fixtures:
            if len(e)>=2: add('boundary' if n in (2,50) else 'normal',fmt(n,e))
        while len(rows)<17:
            n=rng.randint(2,20); m=rng.randint(2,50); e=[]
            for _ in range(m):
                a=rng.randint(1,n); b=rng.randint(1,n-1)
                if b>=a: b+=1
                e.append((a,b))
            add('random',fmt(n,e))
        e=[]
        for i in range(50):
            a=i%50+1; b=(i*7+13)%50+1
            if b==a: b=b%50+1
            e.append((a,b))
        add('constraint_max',fmt(50,e))
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
