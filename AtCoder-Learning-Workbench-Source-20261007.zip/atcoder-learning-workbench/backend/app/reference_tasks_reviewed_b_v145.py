"""18 real B tasks for the turn-122 expansion pilot.

Public AtCoder statements were manually reviewed. Official HTML is not archived/authenticated.
ABC316 was never held, so the original handoff target abc316_b is replaced by abc320_b.
"""
from __future__ import annotations

import re
from itertools import combinations

TASKS = (
    "abc302_b","abc303_b","abc304_b","abc305_b","abc306_b","abc307_b",
    "abc308_b","abc309_b","abc310_b","abc311_b","abc312_b","abc313_b",
    "abc314_b","abc315_b","abc317_b","abc318_b","abc319_b","abc320_b",
)
LANES = {
    "A": ("abc302_b","abc303_b","abc304_b"),
    "B": ("abc305_b","abc306_b","abc307_b"),
    "C": ("abc308_b","abc309_b","abc310_b"),
    "D": ("abc311_b","abc312_b","abc313_b"),
    "E": ("abc314_b","abc315_b","abc317_b"),
    "F": ("abc318_b","abc319_b","abc320_b"),
}
TITLES = {
    "abc302_b":"Find snuke", "abc303_b":"Discord", "abc304_b":"Subscribers",
    "abc305_b":"ABCDEFG", "abc306_b":"Base 2", "abc307_b":"racecar",
    "abc308_b":"Default Price", "abc309_b":"Rotate", "abc310_b":"Strictly Superior",
    "abc311_b":"Vacation Together", "abc312_b":"TaK Code", "abc313_b":"Who is Saikyo?",
    "abc314_b":"Roulette", "abc315_b":"The Middle Day", "abc317_b":"MissingNo.",
    "abc318_b":"Overlapping sheets", "abc319_b":"Measure", "abc320_b":"Longest Palindrome",
}
INT = re.compile(r"(?:0|[1-9][0-9]*)", re.ASCII)
LOWER = re.compile(r"[a-z]+", re.ASCII)
UPPER = re.compile(r"[A-Z]+", re.ASCII)
OX = re.compile(r"[ox]+", re.ASCII)
DOT_HASH = re.compile(r"[.#]+", re.ASCII)
BINROW = re.compile(r"[01]+", re.ASCII)

PUBLISHED_SAMPLES = {
"abc302_b":[
{"input":"6 6\nvgxgpu\namkxks\nzhkbpp\nhykink\nesnuke\nzplvfj\n","expected":"5 2\n5 3\n5 4\n5 5\n5 6\n"},
{"input":"5 5\nezzzz\nzkzzz\nezuzs\nzzznz\nzzzzs\n","expected":"5 5\n4 4\n3 3\n2 2\n1 1\n"},
{"input":"10 10\nkseeusenuk\nusesenesnn\nkskekeeses\nnesnusnkkn\nsnenuuenke\nkukknkeuss\nneunnennue\nsknuessuku\nnksneekknk\nneeeuknenk\n","expected":"9 3\n8 3\n7 3\n6 3\n5 3\n"},
],
"abc303_b":[
{"input":"4 2\n1 2 3 4\n4 3 1 2\n","expected":"2\n"},
{"input":"3 3\n1 2 3\n3 1 2\n1 2 3\n","expected":"0\n"},
],
"abc304_b":[
{"input":"20230603\n","expected":"20200000\n"},
{"input":"0\n","expected":"0\n"},
{"input":"304\n","expected":"304\n"},
{"input":"500600\n","expected":"500000\n"},
],
"abc305_b":[
{"input":"A C\n","expected":"4\n"},
{"input":"G B\n","expected":"20\n"},
{"input":"C F\n","expected":"10\n"},
],
"abc306_b":[
{"input":"1 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n","expected":"13\n"},
],
"abc307_b":[
{"input":"5\nab\nccef\nda\na\nfe\n","expected":"Yes\n"},
{"input":"3\na\nb\naba\n","expected":"No\n"},
{"input":"2\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n","expected":"Yes\n"},
],
"abc308_b":[
{"input":"3 2\nred green blue\nblue red\n800 1600 2800\n","expected":"5200\n"},
{"input":"3 2\ncode queen atcoder\nking queen\n10 1 1\n","expected":"21\n"},
],
"abc309_b":[
{"input":"4\n0101\n1101\n1111\n0000\n","expected":"1010\n1101\n0111\n0001\n"},
{"input":"2\n11\n11\n","expected":"11\n11\n"},
{"input":"5\n01010\n01001\n10110\n00110\n01010\n","expected":"00101\n11000\n00111\n00110\n10100\n"},
],
"abc310_b":[
{"input":"5 6\n10000 2 1 3\n15000 3 1 2 4\n30000 3 1 3 5\n35000 2 1 5\n100000 6 1 2 3 4 5 6\n","expected":"Yes\n"},
{"input":"4 4\n3 1 1\n3 1 2\n3 1 2\n4 2 2 3\n","expected":"No\n"},
],
"abc311_b":[
{"input":"3 5\nxooox\noooxx\noooxo\n","expected":"2\n"},
{"input":"3 3\noxo\noxo\noxo\n","expected":"1\n"},
{"input":"3 3\noox\noxo\nxoo\n","expected":"0\n"},
{"input":"1 7\nooooooo\n","expected":"7\n"},
],
"abc312_b":[
{"input":"19 18\n###......###......\n###......###......\n###..#...###..#...\n..............#...\n..................\n..................\n......###......###\n......###......###\n......###......###\n.###..............\n.###......##......\n.###..............\n............###...\n...##.......###...\n...##.......###...\n.......###........\n.......###........\n.......###........\n........#.........\n","expected":"1 1\n1 10\n7 7\n10 2\n"},
{"input":"9 21\n###.#...........#.###\n###.#...........#.###\n###.#...........#.###\n....#...........#....\n#########...#########\n....#...........#....\n....#.###...###.#....\n....#.###...###.#....\n....#.###...###.#....\n","expected":"1 1\n"},
{"input":"18 18\n######............\n######............\n######............\n######............\n######............\n######............\n..................\n..................\n..................\n..................\n..................\n..................\n............######\n............######\n............######\n............######\n............######\n............######\n","expected":"\n"},
],
"abc313_b":[
{"input":"3 2\n1 2\n2 3\n","expected":"1\n"},
{"input":"3 2\n1 3\n2 3\n","expected":"-1\n"},
{"input":"6 6\n1 6\n6 5\n6 2\n2 3\n4 3\n4 2\n","expected":"-1\n"},
],
"abc314_b":[
{"input":"4\n3\n7 19 20\n4\n4 19 24 0\n2\n26 10\n3\n19 31 24\n19\n","expected":"2\n1 4\n"},
{"input":"3\n1\n1\n1\n2\n1\n3\n0\n","expected":"0\n"},
],
"abc315_b":[
{"input":"12\n31 28 31 30 31 30 31 31 30 31 30 31\n","expected":"7 2\n"},
{"input":"1\n1\n","expected":"1 1\n"},
{"input":"6\n3 1 4 1 5 9\n","expected":"5 3\n"},
],
"abc317_b":[
{"input":"3\n2 3 5\n","expected":"4\n"},
{"input":"8\n3 1 4 5 9 2 6 8\n","expected":"7\n"},
{"input":"16\n152 153 154 147 148 149 158 159 160 155 156 157 144 145 146 150\n","expected":"151\n"},
],
"abc318_b":[
{"input":"3\n0 5 1 3\n1 4 0 5\n2 5 2 4\n","expected":"20\n"},
{"input":"2\n0 100 0 100\n0 100 0 100\n","expected":"10000\n"},
{"input":"3\n0 1 0 1\n0 3 0 5\n5 10 0 10\n","expected":"65\n"},
],
"abc319_b":[
{"input":"12\n","expected":"1-643-2-346-1\n"},
{"input":"7\n","expected":"17777771\n"},
{"input":"1\n","expected":"11\n"},
],
"abc320_b":[
{"input":"TOYOTA\n","expected":"5\n"},
{"input":"ABCDEFG\n","expected":"1\n"},
{"input":"AAAAAAAAAA\n","expected":"10\n"},
],
}
SAMPLE_COUNTS = {p: len(v) for p,v in PUBLISHED_SAMPLES.items()}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw,str) or not raw.endswith("\n") or "\r" in raw:
        raise ValueError("noncanonical")
    body=raw[:-1]
    if body.endswith("\n"): raise ValueError("extra blank")
    return body.split("\n")


def _ints(line: str) -> list[int]:
    parts=line.split(" ")
    if not parts or any(INT.fullmatch(x) is None for x in parts) or " ".join(parts)!=line:
        raise ValueError("integer line")
    return [int(x) for x in parts]


def _find_snuke(g: tuple[str,...]) -> list[tuple[tuple[int,int],...]]:
    h,w=len(g),len(g[0]); word="snuke"; found=[]
    for r in range(h):
        for c in range(w):
            for dr in (-1,0,1):
                for dc in (-1,0,1):
                    if dr==dc==0: continue
                    pts=tuple((r+dr*k,c+dc*k) for k in range(5))
                    if all(0<=x<h and 0<=y<w for x,y in pts) and "".join(g[x][y] for x,y in pts)==word:
                        found.append(pts)
    return found


def _validate302(raw):
    lines=_canonical_lines(raw); hw=_ints(lines[0]) if lines else []
    if len(hw)!=2: raise ValueError("shape")
    h,w=hw
    if not (5<=h<=100 and 5<=w<=100) or len(lines)!=h+1: raise ValueError("constraints")
    g=tuple(lines[1:])
    if any(len(x)!=w or LOWER.fullmatch(x) is None for x in g): raise ValueError("grid")
    if len(_find_snuke(g))!=1: raise ValueError("unique snuke")
    return h,w,g


def _validate303(raw):
    lines=_canonical_lines(raw); nm=_ints(lines[0]) if lines else []
    if len(nm)!=2: raise ValueError("shape")
    n,m=nm
    if not (2<=n<=50 and 1<=m<=50) or len(lines)!=m+1: raise ValueError("constraints")
    rows=[]
    target=list(range(1,n+1))
    for line in lines[1:]:
        a=_ints(line)
        if len(a)!=n or sorted(a)!=target: raise ValueError("permutation")
        rows.append(tuple(a))
    return n,m,tuple(rows)


def _validate304(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1: raise ValueError("shape")
    a=_ints(lines[0])
    if len(a)!=1 or not 0<=a[0]<=10**9-1: raise ValueError("N")
    return (a[0],)


def _validate305(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1: raise ValueError("shape")
    p=lines[0].split(" ")
    if len(p)!=2 or any(len(x)!=1 or x not in "ABCDEFG" for x in p) or p[0]==p[1] or " ".join(p)!=lines[0]: raise ValueError("letters")
    return p[0],p[1]


def _validate306(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1: raise ValueError("shape")
    a=_ints(lines[0])
    if len(a)!=64 or any(x not in (0,1) for x in a): raise ValueError("bits")
    return (tuple(a),)


def _validate307(raw):
    lines=_canonical_lines(raw); h=_ints(lines[0]) if lines else []
    if len(h)!=1 or not 2<=h[0]<=100 or len(lines)!=h[0]+1: raise ValueError("N")
    s=tuple(lines[1:])
    if len(set(s))!=len(s) or any(not 1<=len(x)<=50 or LOWER.fullmatch(x) is None for x in s): raise ValueError("strings")
    return h[0],s


def _validate308(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=4: raise ValueError("shape")
    nm=_ints(lines[0])
    if len(nm)!=2: raise ValueError("shape")
    n,m=nm
    if not (1<=n<=100 and 1<=m<=100): raise ValueError("constraints")
    c=lines[1].split(" "); d=lines[2].split(" "); p=_ints(lines[3])
    if len(c)!=n or len(d)!=m or len(p)!=m+1 or len(set(d))!=m: raise ValueError("counts")
    if any(not 1<=len(x)<=20 or LOWER.fullmatch(x) is None for x in c+d): raise ValueError("colors")
    if any(not 1<=x<=10000 for x in p): raise ValueError("prices")
    if " ".join(c)!=lines[1] or " ".join(d)!=lines[2]: raise ValueError("spacing")
    return n,m,tuple(c),tuple(d),tuple(p)


def _validate309(raw):
    lines=_canonical_lines(raw); h=_ints(lines[0]) if lines else []
    if len(h)!=1 or not 2<=h[0]<=100 or len(lines)!=h[0]+1: raise ValueError("N")
    n=h[0]; g=tuple(lines[1:])
    if any(len(x)!=n or BINROW.fullmatch(x) is None for x in g): raise ValueError("grid")
    return n,g


def _validate310(raw):
    lines=_canonical_lines(raw); nm=_ints(lines[0]) if lines else []
    if len(nm)!=2: raise ValueError("shape")
    n,m=nm
    if not (2<=n<=100 and 1<=m<=100) or len(lines)!=n+1: raise ValueError("constraints")
    products=[]
    for line in lines[1:]:
        a=_ints(line)
        if len(a)<3: raise ValueError("product")
        price,c=a[0],a[1]; f=a[2:]
        if not 1<=price<=100000 or not 1<=c<=m or len(f)!=c or any(not 1<=x<=m for x in f) or any(f[i]>=f[i+1] for i in range(c-1)):
            raise ValueError("product")
        products.append((price,tuple(f)))
    return n,m,tuple(products)


def _validate311(raw):
    lines=_canonical_lines(raw); nd=_ints(lines[0]) if lines else []
    if len(nd)!=2: raise ValueError("shape")
    n,d=nd
    if not (1<=n<=100 and 1<=d<=100) or len(lines)!=n+1: raise ValueError("constraints")
    s=tuple(lines[1:])
    if any(len(x)!=d or OX.fullmatch(x) is None for x in s): raise ValueError("schedule")
    return n,d,s


def _tak_positions():
    black=set(); white=set()
    for r in range(3):
        for c in range(3): black.add((r,c)); black.add((r+6,c+6))
    for c in range(4): white.add((3,c)); white.add((5,c+5))
    for r in range(3): white.add((r,3)); white.add((r+6,5))
    return black,white
TAK_BLACK,TAK_WHITE=_tak_positions()


def _validate312(raw):
    lines=_canonical_lines(raw); nm=_ints(lines[0]) if lines else []
    if len(nm)!=2: raise ValueError("shape")
    n,m=nm
    if not (9<=n<=100 and 9<=m<=100) or len(lines)!=n+1: raise ValueError("constraints")
    g=tuple(lines[1:])
    if any(len(x)!=m or DOT_HASH.fullmatch(x) is None for x in g): raise ValueError("grid")
    return n,m,g


def _validate313(raw):
    lines=_canonical_lines(raw); nm=_ints(lines[0]) if lines else []
    if len(nm)!=2: raise ValueError("shape")
    n,m=nm
    if not (2<=n<=50 and 0<=m<=n*(n-1)//2) or len(lines)!=m+1: raise ValueError("constraints")
    edges=[]; seen=set(); graph=[[] for _ in range(n)]; indeg=[0]*n
    for line in lines[1:]:
        a=_ints(line)
        if len(a)!=2 or not all(1<=x<=n for x in a) or a[0]==a[1] or tuple(a) in seen: raise ValueError("edge")
        seen.add(tuple(a)); u,v=a[0]-1,a[1]-1; graph[u].append(v); indeg[v]+=1; edges.append((a[0],a[1]))
    # Given information must be extendable to a strict total order => DAG.
    q=[i for i,x in enumerate(indeg) if x==0]; k=0; deg=indeg[:]
    while q:
        v=q.pop(); k+=1
        for nv in graph[v]:
            deg[nv]-=1
            if deg[nv]==0:q.append(nv)
    if k!=n: raise ValueError("inconsistent superiority")
    return n,m,tuple(edges)


def _validate314(raw):
    lines=_canonical_lines(raw); h=_ints(lines[0]) if lines else []
    if len(h)!=1 or not 1<=h[0]<=100: raise ValueError("N")
    n=h[0]
    if len(lines)!=2*n+2: raise ValueError("shape")
    bets=[]
    for i in range(n):
        c=_ints(lines[1+2*i]); a=_ints(lines[2+2*i])
        if len(c)!=1 or not 1<=c[0]<=37 or len(a)!=c[0] or len(set(a))!=len(a) or any(not 0<=x<=36 for x in a): raise ValueError("bets")
        bets.append(tuple(a))
    x=_ints(lines[-1])
    if len(x)!=1 or not 0<=x[0]<=36: raise ValueError("X")
    return n,tuple(bets),x[0]


def _validate315(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=2: raise ValueError("shape")
    h=_ints(lines[0]); d=_ints(lines[1])
    if len(h)!=1 or not 1<=h[0]<=100 or len(d)!=h[0] or any(not 1<=x<=100 for x in d) or sum(d)%2!=1: raise ValueError("calendar")
    return h[0],tuple(d)


def _validate317(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=2: raise ValueError("shape")
    h=_ints(lines[0]); a=_ints(lines[1])
    if len(h)!=1 or not 2<=h[0]<=100 or len(a)!=h[0] or len(set(a))!=len(a) or any(not 1<=x<=1000 for x in a): raise ValueError("A")
    s=sorted(a)
    gaps=[x for x in range(s[0]+1,s[-1]) if x not in set(a)]
    if len(gaps)!=1 or s[-1]-s[0]!=h[0]: raise ValueError("lost not unique")
    return h[0],tuple(a)


def _validate318(raw):
    lines=_canonical_lines(raw); h=_ints(lines[0]) if lines else []
    if len(h)!=1 or not 2<=h[0]<=100 or len(lines)!=h[0]+1: raise ValueError("N")
    rect=[]
    for line in lines[1:]:
        a=_ints(line)
        if len(a)!=4: raise ValueError("rect")
        A,B,C,D=a
        if not (0<=A<B<=100 and 0<=C<D<=100): raise ValueError("rect")
        rect.append(tuple(a))
    return h[0],tuple(rect)


def _validate319(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1: raise ValueError("shape")
    a=_ints(lines[0])
    if len(a)!=1 or not 1<=a[0]<=1000: raise ValueError("N")
    return (a[0],)


def _validate320(raw):
    lines=_canonical_lines(raw)
    if len(lines)!=1 or not 2<=len(lines[0])<=100 or UPPER.fullmatch(lines[0]) is None: raise ValueError("S")
    return (lines[0],)


def validate(pid: str, raw: str):
    if pid not in TASKS: raise ValueError("unknown task")
    return globals()[f"_validate{pid[3:6]}"](raw)


def _oracle302(h,w,g):
    return [(r+1,c+1) for r,c in _find_snuke(g)[0]]

def _oracle303(n,m,rows):
    seen=set()
    for row in rows:
        for a,b in zip(row,row[1:]): seen.add(tuple(sorted((a,b))))
    return n*(n-1)//2-len(seen)

def _oracle304(n):
    if n<1000:return n
    p=10
    while n>=p*1000:p*=10
    return n//p*p

def _oracle305(p,q):
    pos=dict(zip("ABCDEFG",(0,3,4,8,9,14,23)))
    return abs(pos[p]-pos[q])

def _oracle306(a):
    return sum(v*(1<<i) for i,v in enumerate(a))

def _oracle307(n,s):
    for i,j in combinations(range(n),2):
        for a,b in ((s[i],s[j]),(s[j],s[i])):
            if all(a[k] if False else True for k in []):
                t=a+b
                if all(t[k]==t[-1-k] for k in range(len(t)//2)): return True
    return False

def _oracle308(n,m,c,d,p):
    price={d[i]:p[i+1] for i in range(m)}
    return sum(price.get(x,p[0]) for x in c)

def _oracle309(n,g):
    a=[list(x) for x in g]; coords=[]
    for c in range(n):coords.append((0,c))
    for r in range(1,n):coords.append((r,n-1))
    for c in range(n-2,-1,-1):coords.append((n-1,c))
    for r in range(n-2,0,-1):coords.append((r,0))
    vals=[a[r][c] for r,c in coords]; vals=vals[-1:]+vals[:-1]
    for (r,c),v in zip(coords,vals):a[r][c]=v
    return ["".join(x) for x in a]

def _oracle310(n,m,products):
    for i,(pi,fi) in enumerate(products):
        si=set(fi)
        for j,(pj,fj) in enumerate(products):
            if i==j:continue
            sj=set(fj)
            if pi>=pj and si<=sj and (pi>pj or si<sj):return True
    return False

def _oracle311(n,d,s):
    good=[all(row[j]=='o' for row in s) for j in range(d)]
    best=cur=0
    for x in good:
        cur=cur+1 if x else 0; best=max(best,cur)
    return best

def _oracle312(n,m,g):
    ans=[]
    for r in range(n-8):
        for c in range(m-8):
            if all(g[r+dr][c+dc]=='#' for dr,dc in TAK_BLACK) and all(g[r+dr][c+dc]=='.' for dr,dc in TAK_WHITE): ans.append((r+1,c+1))
    return ans

def _oracle313(n,m,edges):
    incoming={b for _,b in edges}; candidates=[x for x in range(1,n+1) if x not in incoming]
    return candidates[0] if len(candidates)==1 else -1

def _oracle314(n,bets,x):
    winners=[(len(a),i+1) for i,a in enumerate(bets) if x in a]
    if not winners:return []
    k=min(z[0] for z in winners)
    return [i for c,i in winners if c==k]

def _oracle315(m,d):
    target=(sum(d)+1)//2; acc=0
    for i,x in enumerate(d,1):
        if acc+x>=target:return i,target-acc
        acc+=x
    raise AssertionError

def _oracle317(n,a):
    s=set(a)
    for x in range(min(a),max(a)+1):
        if x not in s:return x
    raise AssertionError

def _oracle318(n,rect):
    cells=set()
    for A,B,C,D in rect:
        cells.update((x,y) for x in range(A,B) for y in range(C,D))
    return len(cells)

def _oracle319(n):
    out=[]
    divisors=[j for j in range(1,10) if n%j==0]
    for i in range(n+1):
        z='-'
        for j in divisors:
            if i%(n//j)==0:z=str(j);break
        out.append(z)
    return ''.join(out)

def _oracle320(s):
    best=1
    for l in range(len(s)):
        for r in range(l+1,len(s)+1):
            t=s[l:r]
            if list(t)==list(reversed(t)):best=max(best,len(t))
    return best


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError):return False
    if not isinstance(output,str) or '\r' in output:return False
    try:
        if pid=='abc302_b':
            lines=output.split('\n'); pts=[]
            if len(lines)!=5:return False
            for line in lines:
                a=line.split(' ')
                if len(a)!=2 or any(INT.fullmatch(x) is None for x in a):return False
                pts.append(tuple(map(int,a)))
            return pts==_oracle302(*v)
        if pid in {'abc303_b','abc304_b','abc305_b','abc306_b','abc311_b','abc313_b','abc317_b','abc318_b','abc320_b'}:
            if '\n' in output or re.fullmatch(r'-?[0-9]+',output) is None:return False
            return int(output)==globals()[f'_oracle{pid[3:6]}'](*v)
        if pid=='abc307_b' or pid=='abc310_b':
            return output in ('Yes','No') and (output=='Yes')==globals()[f'_oracle{pid[3:6]}'](*v)
        if pid=='abc308_b':
            return INT.fullmatch(output) is not None and int(output)==_oracle308(*v)
        if pid=='abc309_b':return output.split('\n')==_oracle309(*v)
        if pid=='abc312_b':
            exp=_oracle312(*v)
            if output=='':return exp==[]
            pts=[]
            for line in output.split('\n'):
                a=line.split(' ')
                if len(a)!=2 or any(INT.fullmatch(x) is None for x in a):return False
                pts.append(tuple(map(int,a)))
            return pts==exp
        if pid=='abc314_b':
            ans=_oracle314(*v); lines=output.split('\n')
            if not lines or INT.fullmatch(lines[0]) is None or int(lines[0])!=len(ans):return False
            if ans:
                return len(lines)==2 and lines[1]==' '.join(map(str,ans))
            return len(lines)==1
        if pid=='abc315_b':return output==' '.join(map(str,_oracle315(*v)))
        if pid=='abc319_b':return output==_oracle319(*v)
    except Exception:return False
    return False


def official_expected_matches_reference(pid: str, raw: str, expected: str, actual: str) -> bool:
    # Published examples are exact-output tasks. A sample with no coordinates is represented by one newline.
    return actual==expected and independent_check(pid,raw,actual[:-1] if actual.endswith('\n') else actual)


def _add(out,seen,pid,category,raw):
    validate(pid,raw)
    if raw not in seen:
        seen.add(raw); out.append({'category':category,'input':raw})


def _make_snuke(h,w,r,c,dr,dc):
    g=[['a']*w for _ in range(h)]
    for k,ch in enumerate('snuke'):g[r+dr*k][c+dc*k]=ch
    return f'{h} {w}\n'+'\n'.join(''.join(x) for x in g)+'\n'

def _tak_grid(n,m,starts):
    g=[['.']*m for _ in range(n)]
    for r,c in starts:
        for dr,dc in TAK_BLACK:g[r+dr][c+dc]='#'
    return f'{n} {m}\n'+'\n'.join(''.join(x) for x in g)+'\n'

def _bin64(bits):return ' '.join(map(str,bits))+'\n'

def _rect_input(rect):return str(len(rect))+'\n'+'\n'.join(' '.join(map(str,x)) for x in rect)+'\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:raise ValueError('unknown task')
    out=[];seen=set()
    for i,row in enumerate(PUBLISHED_SAMPLES[pid],1):_add(out,seen,pid,f'sample{i}',row['input'])
    custom=[]; max_case=''
    if pid=='abc302_b':
        dirs=[(0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)]
        for i,(dr,dc) in enumerate(dirs):
            r=0 if dr>=0 else 4; c=0 if dc>=0 else 4
            custom.append((f'direction_{i}',_make_snuke(5,5,r,c,dr,dc)))
        custom += [('wide',_make_snuke(5,10,2,1,0,1)),('tall',_make_snuke(10,5,1,3,1,0)),('middle_diag',_make_snuke(9,9,2,2,1,1)),('edge_diag',_make_snuke(9,9,8,0,-1,1)),('row_bottom',_make_snuke(6,7,5,1,0,1)),('col_right',_make_snuke(7,6,1,5,1,0))]
        max_case=_make_snuke(100,100,95,95,1,1)
    elif pid=='abc303_b':
        custom=[('minimum','2 1\n1 2\n'),('extra_perm','7 1\n1 3 5 7 2 4 6\n'),('reverse','4 1\n4 3 2 1\n'),('no_adjacency_missing','5 2\n1 2 3 4 5\n1 3 5 2 4\n'),('many_photos','3 5\n1 2 3\n1 3 2\n2 1 3\n2 3 1\n3 1 2\n'),('n6','6 3\n1 2 3 4 5 6\n6 5 4 3 2 1\n1 3 5 2 4 6\n')]
        for shift in range(1,10):
            n=10; row=list(range(1,n+1)); rows=[]
            for k in range(3): rows.append(row[(shift+k)%n:]+row[:(shift+k)%n])
            custom.append((f'shift{shift}',f'{n} 3\n'+'\n'.join(' '.join(map(str,x)) for x in rows)+'\n'))
        rows=[]
        for k in range(50):rows.append(tuple(((i+k)%50)+1 for i in range(50)))
        max_case='50 50\n'+'\n'.join(' '.join(map(str,x)) for x in rows)+'\n'
    elif pid=='abc304_b':
        vals=[1,9,99,999,1000,1001,9999,10000,99999,100000,999999,1000000,9999999,10000000,99999999,100000000,999999999]
        custom=[(f'boundary_{x}',f'{x}\n') for x in vals]
        max_case='999999999\n'
    elif pid=='abc305_b':
        pairs=[('A','B'),('B','C'),('C','D'),('D','E'),('E','F'),('F','G'),('A','G'),('G','A'),('B','F'),('D','A'),('E','B'),('F','C'),('G','D'),('A','F'),('B','G')]
        custom=[(f'pair_{a}{b}',f'{a} {b}\n') for a,b in pairs]
        max_case='D G\n'
    elif pid=='abc306_b':
        custom=[('all_zero',_bin64([0]*64)),('all_one',_bin64([1]*64)),('lsb',_bin64([1]+[0]*63)),('msb',_bin64([0]*63+[1])),('ends',_bin64([1]+[0]*62+[1]))]
        for k in range(1,12):custom.append((f'bit{k}',_bin64([1 if i in {k,63-k} else 0 for i in range(64)])))
        max_case=_bin64([i%2 for i in range(64)])
    elif pid=='abc307_b':
        custom=[('two_yes','2\na\naa\n'),('two_no','2\nab\ncd\n'),('order_matters','3\nab\na\nxyz\n'),('self_not_allowed','2\naba\nc\n'),('even_pal','2\nab\nba\n'),('long_no','2\n'+'a'*50+'\n'+'b'*50+'\n')]
        for k in range(2,12):
            ss=[chr(97+i)*k for i in range(min(k,20))]
            if len(ss)<2:ss+=['b']
            custom.append((f'len{k}',str(len(ss))+'\n'+'\n'.join(ss)+'\n'))
        ss=[('a'*49+chr(98+i%25)) for i in range(100)]
        # ensure distinct and lowercase length 50
        ss=[('a'*48+chr(97+i//26)+chr(97+i%26)) for i in range(100)]
        max_case='100\n'+'\n'.join(ss)+'\n'
    elif pid=='abc308_b':
        custom=[('minimum','1 1\na\nb\n1 2\n'),('listed','1 1\na\na\n5 7\n'),('duplicates_c','4 2\na a b c\na c\n10 20 30\n'),('all_default','3 2\nx y z\na b\n100 1 2\n'),('all_listed','3 3\na b c\na b c\n9 1 2 3\n')]
        for k in range(1,11):
            c=' '.join(['a','b','c','d'][:(k%4)+1]); n=(k%4)+1
            custom.append((f'mix{k}',f'{n} 4\n{c}\na b c d\n{k} 1 2 3 4\n'))
        colors=[f"c{chr(97+i//26)}{chr(97+i%26)}" for i in range(100)]; d=[f"d{chr(97+i//26)}{chr(97+i%26)}" for i in range(100)]
        max_case='100 100\n'+' '.join(colors)+'\n'+' '.join(d)+'\n'+' '.join(['10000']*101)+'\n'
    elif pid=='abc309_b':
        custom=[]
        for n in range(2,9):
            g=[''.join(str((i*n+j+n)%2) for j in range(n)) for i in range(n)]
            custom.append((f'n{n}',str(n)+'\n'+'\n'.join(g)+'\n'))
        custom += [('corners','3\n100\n000\n001\n'),('border','4\n1111\n1001\n1001\n1111\n'),('inside','5\n00000\n01010\n00100\n01010\n00000\n')]
        for k in range(7):
            n=10+k;g=[''.join(str((i*7+j*3+k)%2) for j in range(n)) for i in range(n)];custom.append((f'pattern{k}',str(n)+'\n'+'\n'.join(g)+'\n'))
        n=100;g=[''.join(str((i+j)%2) for j in range(n)) for i in range(n)];max_case=str(n)+'\n'+'\n'.join(g)+'\n'
    elif pid=='abc310_b':
        custom=[('price_strict','2 2\n10 1 1\n9 1 1\n'),('feature_strict','2 2\n10 1 1\n10 2 1 2\n'),('same_no','2 2\n10 1 1\n10 1 1\n'),('wrong_price','2 2\n9 1 1\n10 2 1 2\n'),('subset_no','2 3\n10 2 1 3\n9 2 1 2\n')]
        for k in range(1,11):
            custom.append((f'case{k}',f'3 5\n{10+k} 2 1 3\n{10+k} 3 1 3 5\n{20+k} 1 2\n'))
        rows=[]
        for i in range(100):rows.append(f'{100000-i} 100 '+' '.join(map(str,range(1,101))))
        max_case='100 100\n'+'\n'.join(rows)+'\n'
    elif pid=='abc311_b':
        custom=[('minimum_o','1 1\no\n'),('minimum_x','1 1\nx\n'),('all_o','2 5\nooooo\nooooo\n'),('one_break','2 5\nooxoo\nooooo\n'),('alternating','1 8\noxoxoxox\n'),('late','3 6\nxxxooo\noxxooo\nxxxooo\n')]
        for k in range(1,10):
            n=4;d=10; rows=[''.join('x' if (i+j+k)%7==0 else 'o' for j in range(d)) for i in range(n)]
            custom.append((f'pattern{k}',f'{n} {d}\n'+'\n'.join(rows)+'\n'))
        max_case='100 100\n'+'\n'.join(['o'*100 for _ in range(100)])+'\n'
    elif pid=='abc312_b':
        custom=[('minimum_yes',_tak_grid(9,9,[(0,0)])),('minimum_no','9 9\n'+'\n'.join(['.'*9 for _ in range(9)])+'\n'),('two_horizontal',_tak_grid(9,18,[(0,0),(0,9)])),('two_vertical',_tak_grid(18,9,[(0,0),(9,0)]))]
        for k in range(1,15):
            n=m=20; starts=[(k%12,k%12)]
            custom.append((f'grid{k}',_tak_grid(n,m,starts)))
        max_case=_tak_grid(100,100,[(0,0),(91,91)])
    elif pid=='abc313_b':
        custom=[('minimum_none','2 0\n'),('two_roots_extra','5 2\n1 4\n2 5\n'),('minimum_known','2 1\n1 2\n'),('chain4','4 3\n1 2\n2 3\n3 4\n'),('two_roots','4 2\n1 3\n2 4\n'),('star','5 4\n1 2\n1 3\n1 4\n1 5\n')]
        for k in range(3,13):
            edges='\n'.join(f'{i} {i+1}' for i in range(1,k))
            custom.append((f'chain{k}',f'{k} {k-1}\n{edges}\n'))
        edges='\n'.join(f'{i} {j}' for i in range(1,51) for j in range(i+1,51))
        max_case=f'50 {50*49//2}\n{edges}\n'
    elif pid=='abc314_b':
        custom=[('one_hit','1\n1\n0\n0\n'),('two_miss','2\n1\n1\n1\n2\n36\n'),('one_miss','1\n1\n1\n0\n'),('tie','3\n2\n1 2\n2\n2 3\n3\n1 2 3\n2\n'),('unique_min','3\n3\n1 2 3\n1\n2\n2\n2 4\n2\n')]
        for k in range(1,11):
            custom.append((f'case{k}',f'2\n2\n0 {k%37}\n3\n0 1 2\n0\n'))
        lines=['100']
        for i in range(100):
            lines+=['37',' '.join(map(str,range(37)))]
        lines+=['36'];max_case='\n'.join(lines)+'\n'
    elif pid=='abc315_b':
        custom=[('single3','1\n3\n'),('two','2\n1 2\n'),('three','3\n1 1 3\n'),('edge_month','3\n3 1 1\n')]
        for k in range(1,11):
            d=[1]*(2*k+1);custom.append((f'odd{k}',f'{len(d)}\n'+' '.join(map(str,d))+'\n'))
        d=[100]*99+[99];max_case='100\n'+' '.join(map(str,d))+'\n'
    elif pid=='abc317_b':
        custom=[]
        for missing in range(2,17):
            arr=[x for x in range(1,18) if x!=missing]
            custom.append((f'miss{missing}',f'{len(arr)}\n'+' '.join(map(str,arr[::-1]))+'\n'))
        arr=[x for x in range(900,1001) if x!=950];max_case='100\n'+' '.join(map(str,arr))+'\n'
    elif pid=='abc318_b':
        custom=[('minimum','2\n0 1 0 1\n1 2 1 2\n'),('disjoint','2\n0 10 0 10\n20 30 20 30\n'),('nested','2\n0 100 0 100\n20 30 20 30\n'),('touch_edges','2\n0 10 0 10\n10 20 0 10\n')]
        for k in range(1,11):
            rect=[(0,k,0,k),(k//2,k+2,k//2,k+3)];custom.append((f'overlap{k}',_rect_input(rect)))
        rect=[(0,100,0,100) for _ in range(100)];max_case=_rect_input(rect)
    elif pid=='abc319_b':
        vals=[2,3,4,5,6,8,9,10,18,36,72,97,360,999]
        custom=[(f'n{x}',f'{x}\n') for x in vals]
        max_case='1000\n'
    elif pid=='abc320_b':
        vals=['AA','AB','ABA','ABBA','ABCBA','ABCDCX','AABCAA','XYZYXQ','BANANA','ABACABA','ABCDEFGHIJKLMNOP','ZZYZZ','QWERTYYTREWQ','ABCCBAZ']
        custom=[(f's{i}',s+'\n') for i,s in enumerate(vals)]
        max_case='A'*100+'\n'
    for cat,raw in custom:
        if len(out)>=17:break
        _add(out,seen,pid,cat,raw)
    _add(out,seen,pid,'constraint_max',max_case)
    if len(out)!=18 or len({x['input'] for x in out})!=18 or out[-1]['category']!='constraint_max':
        raise AssertionError(f'{pid}: expected 18 distinct cases ending max, got {len(out)}')
    return out

REFERENCE_CODE = {
'abc302_b':'''import sys\ninput=sys.stdin.readline\nh,w=map(int,input().split());g=[input().strip() for _ in range(h)]\nfor r in range(h):\n for c in range(w):\n  for dr in (-1,0,1):\n   for dc in (-1,0,1):\n    if dr==0 and dc==0: continue\n    pts=[(r+dr*k,c+dc*k) for k in range(5)]\n    if all(0<=x<h and 0<=y<w for x,y in pts) and ''.join(g[x][y] for x,y in pts)=='snuke':\n     for x,y in pts: print(x+1,y+1)\n     raise SystemExit\n''',
'abc303_b':'''import sys\nit=iter(map(int,sys.stdin.read().split()));n=next(it);m=next(it);bad=[[True]*n for _ in range(n)]\nfor i in range(n):bad[i][i]=False\nfor _ in range(m):\n row=[next(it)-1 for _ in range(n)]\n for a,b in zip(row,row[1:]):bad[a][b]=bad[b][a]=False\nprint(sum(bad[i][j] for i in range(n) for j in range(i+1,n)))\n''',
'abc304_b':'''n=int(input())\nif n<1000: print(n)\nelse:\n k=len(str(n))-3\n p=10**k\n print(n//p*p)\n''',
'abc305_b':'''p,q=input().split();s='ABCDEFG';d=[3,1,4,1,5,9];i=s.index(p);j=s.index(q)\nif i>j:i,j=j,i\nprint(sum(d[i:j]))\n''',
'abc306_b':'''a=list(map(int,input().split()));x=0\nfor i,v in enumerate(a):x|=v<<i\nprint(x)\n''',
'abc307_b':'''n=int(input());s=[input().strip() for _ in range(n)]\nfor i in range(n):\n for j in range(n):\n  if i!=j and s[i]+s[j]==(s[i]+s[j])[::-1]:print('Yes');raise SystemExit\nprint('No')\n''',
'abc308_b':'''n,m=map(int,input().split());c=input().split();d=input().split();p=list(map(int,input().split()));mp=dict(zip(d,p[1:]));print(sum(mp.get(x,p[0]) for x in c))\n''',
'abc309_b':'''n=int(input());a=[list(input().strip()) for _ in range(n)];b=[r[:] for r in a]\nfor j in range(1,n):b[0][j]=a[0][j-1]\nfor i in range(1,n):b[i][n-1]=a[i-1][n-1]\nfor j in range(n-1):b[n-1][j]=a[n-1][j+1]\nfor i in range(n-1):b[i][0]=a[i+1][0]\nprint(*map(''.join,b),sep='\\n')\n''',
'abc310_b':'''n,m=map(int,input().split());p=[]\nfor _ in range(n):\n x=list(map(int,input().split()));p.append((x[0],set(x[2:])))\nfor i in range(n):\n for j in range(n):\n  if i!=j and p[i][0]>=p[j][0] and p[i][1]<=p[j][1] and (p[i][0]>p[j][0] or p[i][1]<p[j][1]):print('Yes');raise SystemExit\nprint('No')\n''',
'abc311_b':'''n,d=map(int,input().split());s=[input().strip() for _ in range(n)];ans=cur=0\nfor j in range(d):\n if all(s[i][j]=='o' for i in range(n)):cur+=1;ans=max(ans,cur)\n else:cur=0\nprint(ans)\n''',
'abc312_b':'''n,m=map(int,input().split());g=[input().strip() for _ in range(n)]\nB={(r,c) for r in range(3) for c in range(3)}|{(r+6,c+6) for r in range(3) for c in range(3)}\nW={(3,c) for c in range(4)}|{(r,3) for r in range(3)}|{(5,c) for c in range(5,9)}|{(r,5) for r in range(6,9)}\nans=[]\nfor i in range(n-8):\n for j in range(m-8):\n  if all(g[i+r][j+c]=='#' for r,c in B) and all(g[i+r][j+c]=='.' for r,c in W):ans.append((i+1,j+1))\nprint('\\n'.join(f'{i} {j}' for i,j in ans))\n''',
'abc313_b':'''n,m=map(int,input().split());lost=[False]*n\nfor _ in range(m):a,b=map(int,input().split());lost[b-1]=True\na=[i+1 for i,x in enumerate(lost) if not x]\nprint(a[0] if len(a)==1 else -1)\n''',
'abc314_b':'''n=int(input());a=[]\nfor _ in range(n):c=int(input());a.append(list(map(int,input().split())))\nx=int(input());cand=[(len(v),i+1) for i,v in enumerate(a) if x in v]\nif not cand:print(0)\nelse:\n k=min(c for c,_ in cand);ans=[i for c,i in cand if c==k];print(len(ans));print(*ans)\n''',
'abc315_b':'''m=int(input());d=list(map(int,input().split()));t=(sum(d)+1)//2\nfor i,x in enumerate(d,1):\n if t<=x:print(i,t);break\n t-=x\n''',
'abc317_b':'''n=int(input());a=sorted(map(int,input().split()))\nfor x,y in zip(a,a[1:]):\n if y-x==2:print(x+1);break\n''',
'abc318_b':'''n=int(input());g=[[0]*100 for _ in range(100)]\nfor _ in range(n):\n a,b,c,d=map(int,input().split())\n for x in range(a,b):\n  for y in range(c,d):g[x][y]=1\nprint(sum(map(sum,g)))\n''',
'abc319_b':'''n=int(input());ans=[]\nfor i in range(n+1):\n ch='-'\n for j in range(1,10):\n  if n%j==0 and i%(n//j)==0:ch=str(j);break\n ans.append(ch)\nprint(''.join(ans))\n''',
'abc320_b':'''s=input().strip();ans=1\nfor l in range(len(s)):\n for r in range(l+1,len(s)+1):\n  t=s[l:r]\n  if t==t[::-1]:ans=max(ans,len(t))\nprint(ans)\n''',
}
