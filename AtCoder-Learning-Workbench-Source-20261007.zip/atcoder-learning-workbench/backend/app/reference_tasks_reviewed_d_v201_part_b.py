from __future__ import annotations
from bisect import bisect_left,bisect_right
from collections import Counter
from math import gcd
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{i}_d' for i in range(413,419));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'canonical');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc413_d':
  t=ints(r[0],1)[0];require(1<=t<=100000 and len(r)==1+2*t,'shape');cases=[];total=0
  for i in range(t):
   n=ints(r[1+2*i],1)[0];a=ints(r[2+2*i],n);require(2<=n<=200000 and all(0<abs(x)<=10**9 for x in a),'case');cases.append(a);total+=n
  require(total<=200000,'totalN');return (tuple(cases),)
 if pid=='abc414_d':
  n,m=ints(r[0],2);require(1<=m<=n<=500000 and len(r)==2,'shape');a=ints(r[1],n);require(all(1<=x<=10**12 for x in a),'Xi');return m,a
 if pid=='abc415_d':
  n,m=ints(r[0],2);require(1<=n<=10**18 and 1<=m<=200000 and len(r)==m+1,'shape');rules=tuple(ints(row,2) for row in r[1:]);require(all(1<=b<a<=10**18 for a,b in rules),'rule');return n,rules
 if pid=='abc416_d':
  t=ints(r[0],1)[0];require(1<=t<=100000 and len(r)==1+3*t,'shape');cases=[];total=0
  for i in range(t):
   n,m=ints(r[1+3*i],2);a=ints(r[2+3*i],n);b=ints(r[3+3*i],n);require(1<=n<=300000 and 1<=m<=10**9 and all(0<=v<m for v in a+b),'case');cases.append((m,a,b));total+=n
  require(total<=300000,'totalN');return (tuple(cases),)
 if pid=='abc417_d':
  n=ints(r[0],1)[0];require(1<=n<=10000 and len(r)>=n+3,'N');gifts=tuple(ints(row,3) for row in r[1:n+1]);q=ints(r[n+1],1)[0];require(1<=q<=500000 and len(r)==n+q+2 and all(all(1<=v<=500 for v in g) for g in gifts),'shape');queries=tuple(ints(row,1)[0] for row in r[n+2:]);require(all(0<=v<=10**9 for v in queries),'Xi');return gifts,queries
 require(len(r)==2,'shape');n=ints(r[0],1)[0];require(1<=n<=200000 and re.fullmatch('[01]{'+str(n)+'}',r[1]) is not None,'string');return (r[1],)
def geometric_construct(a:tuple[int,...])->bool:
 magnitudes={abs(v) for v in a}
 if len(magnitudes)==1:
  positives=sum(v>0 for v in a);return positives in (0,len(a)) or abs(2*positives-len(a))<=1
 if len(magnitudes)!=len(a):return False
 first=min(a,key=abs);second=min((v for v in a if abs(v)>abs(first)),key=abs);g=gcd(first,second);p,q=second//g,first//g;remaining=Counter(a);value=first
 for _ in a:
  if remaining[value]==0:return False
  remaining[value]-=1
  product=value*p
  if product%q:return sum(remaining.values())==0
  value=product//q
 return True
def transmission_kruskal(m:int,a:tuple[int,...])->int:
 ordered=sorted(a);n=len(a);edges=[(ordered[i+1]-ordered[i],i,i+1) for i in range(n-1)];heapq.heapify(edges);parent=list(range(n));answer=0
 def root(v:int)->int:
  while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
  return v
 for _ in range(n-m):
  cost,u,v=heapq.heappop(edges);ru,rv=root(u),root(v);require(ru!=rv,'path edge cycle');parent[ru]=rv;answer+=cost
 return answer
def sticker_thresholds(n:int,rules:tuple[tuple[int,...],...])->int:
 thresholds=[];costs=[];best=10**18
 for a,b in sorted(rules):
  cost=a-b
  if cost<best:thresholds.append(a);costs.append(cost);best=cost
 total=0
 while n>=thresholds[0]:
  i=bisect_right(thresholds,n)-1;times=(n-thresholds[i])//costs[i]+1;total+=times;n-=times*costs[i]
 return total
def modular_hall(m:int,a:tuple[int,...],b:tuple[int,...])->int:
 aa=sorted(a);bb=sorted(b);n=len(a);deficiency=0
 for i,value in enumerate(aa):
  if i+1==n or aa[i+1]!=value:deficiency=max(deficiency,i+1-(n-bisect_left(bb,m-value)))
 return sum(a)+sum(b)-m*(n-deficiency)
def gifts_block_transducers(gifts:tuple[tuple[int,...],...],queries:tuple[int,...])->list[int]:
 size=128;blocks=[gifts[i:i+size] for i in range(0,len(gifts),size)];prefix=[0];tables=[]
 for block in blocks:
  prefix.append(prefix[-1]+sum(g[2] for g in block));table=list(range(1001))
  for p,a,b in block:table=[value+a if value<=p else max(0,value-b) for value in table]
  tables.append(table)
 memo:dict[int,int]={};out=[]
 for initial in queries:
  if initial in memo:out.append(memo[initial]);continue
  value=initial
  if value-prefix[-1]>500:answer=value-prefix[-1]
  else:
   start=0
   if value>1000:
    start=max(0,bisect_left(prefix,value-500)-1);value-=prefix[start]
   for i in range(start,len(blocks)):
    if value<=1000:value=tables[i][value]
    elif value-(prefix[i+1]-prefix[i])>500:value-=prefix[i+1]-prefix[i]
    else:
     for p,a,b in blocks[i]:value=value+a if value<=p else max(0,value-b)
   answer=value
  memo[initial]=answer;out.append(answer)
 return out
def xnor_prefix_pairs(s:str)->int:
 counts=[1,0];parity=0
 for c in s:parity^=c=='0';counts[parity]+=1
 return sum(n*(n-1)//2 for n in counts)
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc413_d':return ''.join(('Yes' if geometric_construct(a) else 'No')+'\n' for a in cast(tuple[tuple[int,...],...],d[0]))
 if pid=='abc414_d':return str(transmission_kruskal(cast(int,d[0]),cast(tuple[int,...],d[1])))+'\n'
 if pid=='abc415_d':return str(sticker_thresholds(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))+'\n'
 if pid=='abc416_d':return ''.join(str(modular_hall(*c))+'\n' for c in cast(tuple[tuple[int,tuple[int,...],tuple[int,...]],...],d[0]))
 if pid=='abc417_d':return ''.join(str(v)+'\n' for v in gifts_block_transducers(cast(tuple[tuple[int,...],...],d[0]),cast(tuple[int,...],d[1])))
 return str(xnor_prefix_pairs(cast(str,d[0])))+'\n'
def independent_check(pid:str,raw:str,actual:str,mode:str|None=None)->bool:
 try:return mode in (None,'exact') and actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,KeyError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc413_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);out=[]
for _ in range(t):
 n=next(it);a=[next(it) for i in range(n)];a.sort(key=abs)
 if abs(a[0])==abs(a[-1]):
  p=sum(v>0 for v in a);ok=p==0 or p==n or abs(2*p-n)<=1
 else:ok=all(a[i]*a[0]==a[i-1]*a[1] for i in range(2,n))
 out.append('Yes' if ok else 'No')
print('\\n'.join(out))
''',
'abc414_d':'''n,m=map(int,input().split());a=sorted(map(int,input().split()));gaps=sorted((a[i+1]-a[i] for i in range(n-1)),reverse=True);print(a[-1]-a[0]-sum(gaps[:m-1]))
''',
'abc415_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);rules=sorted((a-b,a) for a,b in [(next(it),next(it)) for _ in range(m)]);answer=0
for cost,a in rules:
 if n>=a:k=(n-a)//cost+1;answer+=k;n-=k*cost
print(answer)
''',
'abc416_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);out=[]
for _ in range(t):
 n=next(it);m=next(it);a=sorted(next(it) for i in range(n));b=sorted((next(it) for i in range(n)),reverse=True);j=0;wrap=0
 for value in b:
  while j<n and a[j]+value<m:j+=1
  if j==n:break
  wrap+=1;j+=1
 out.append(str(sum(a)+sum(b)-m*wrap))
print('\\n'.join(out))
''',
'abc417_d':'''import sys,bisect
from array import array
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);gifts=[(next(it),next(it),next(it)) for _ in range(n)];prefix=[0]
for p,a,b in gifts:prefix.append(prefix[-1]+b)
tables=[array('H') for _ in range(n+1)];tables[n]=array('H',range(1001))
for i in range(n-1,-1,-1):
 p,a,b=gifts[i];after=tables[i+1];tables[i]=array('H',(after[x+a] if x<=p else after[max(0,x-b)] for x in range(1001)))
q=next(it);out=[]
for _ in range(q):
 x=next(it)
 if x<=1000:answer=tables[0][x]
 elif x-prefix[-1]>1000:answer=x-prefix[-1]
 else:
  j=bisect.bisect_left(prefix,x-1000);x=max(0,x-prefix[j]);answer=tables[j][x]
 out.append(str(answer))
print('\\n'.join(out))
''',
'abc418_d':'''n=int(input());s=input();zero=one=answer=0
for char in s:
 if char=='1':one+=1
 else:zero,one=one+1,zero
 answer+=one
print(answer)
'''}
def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));raws:list[str]=[]
 if pid=='abc413_d':
  def geometric(arrays:list[list[int]])->str:return str(len(arrays))+'\n'+''.join(str(len(a))+'\n'+line(a) for a in arrays)
  values=[[1,1],[1,-1],[1,2],[1,1,-1],[1,1,1,-1],[-1,-1,-1],[2,-6,18,-54],[8,4,2,1],[3,9,27,80],[1,2,2],[10**9,-10**9]*4,[729,-2430,8100,-27000,90000,-300000,1000000]]
  raws=[geometric([a]) for a in values]
  while len(raws)<16:raws.append(geometric([[rng.choice((-1,1))*rng.randint(1,10**9) for _ in range(20+len(raws))]]))
  raws += [geometric([[1,-1]]*100000),geometric([[10**9]*100000+[-10**9]*100000])]
 elif pid=='abc414_d':
  def transmit(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
  raws=[transmit(1,[1]),transmit(1,[10**12]),transmit(1,[1,10**12]),transmit(2,[1,10**12]),transmit(2,[1,1,2,2,3]),transmit(1,[5,10,15,20,8,14,15]),transmit(7,[5,10,15,20,8,14,15]),transmit(3,[5,10,15,20,8,14,15])]
  while len(raws)<16:
   n=10+len(raws);raws.append(transmit(rng.randint(1,n),[rng.randint(1,10**12) for _ in range(n)]))
  raws += [transmit(250000,[rng.randint(1,10**12) for _ in range(500000)]),transmit(500000,[10**12]*500000)]
 elif pid=='abc415_d':
  def stickers(n:int,rules:list[tuple[int,int]])->str:return f'{n} {len(rules)}\n'+''.join(line(r) for r in rules)
  raws=[stickers(1,[(2,1)]),stickers(2,[(2,1)]),stickers(10**18,[(2,1)]),stickers(10**18,[(10**18,1)]),stickers(5,[(5,1),(4,3),(3,1)]),stickers(3,[(5,1),(5,1),(4,2)]),stickers(9,[(9,8),(5,3),(2,1)]),stickers(100,[(100,99),(10,9),(2,1)])]
  while len(raws)<16:
   rules=[]
   for _ in range(10+len(raws)):
    a=rng.randint(2,10000);rules.append((a,rng.randint(1,a-1)))
   raws.append(stickers(rng.randint(1,10**18),rules))
  raws += [stickers(10**18-1,[(10**18-i,10**18-i-1) for i in range(200000)]),stickers(10**18,[(10**18,10**18-1)]*200000)]
 elif pid=='abc416_d':
  def modular(cases:list[tuple[int,list[int],list[int]]])->str:return str(len(cases))+'\n'+''.join(f'{len(a)} {m}\n'+line(a)+line(b) for m,a,b in cases)
  values=[(1,[0],[0]),(10**9,[10**9-1],[10**9-1]),(3,[0,0],[2,2]),(3,[1,1],[2,2]),(6,[3,1,4],[2,0,1]),(4,[0,3,1,1],[3,1,2,0]),(2,[0,0,1,1],[0,1,0,1]),(10,[0,2,9],[0,8,9])];raws=[modular([c]) for c in values]
  while len(raws)<16:
   n=10+len(raws);m=rng.randint(1,10**9);raws.append(modular([(m,[rng.randrange(m) for _ in range(n)],[rng.randrange(m) for _ in range(n)])]))
  raws += [modular([(10**9,[rng.randrange(10**9) for _ in range(300000)],[rng.randrange(10**9) for _ in range(300000)])]),modular([(10**9,[10**9-1]*3,[10**9-1]*3)]*100000)]
 elif pid=='abc417_d':
  def gifts(g:list[tuple[int,int,int]],queries:list[int])->str:return str(len(g))+'\n'+''.join(line(v) for v in g)+str(len(queries))+'\n'+''.join(str(x)+'\n' for x in queries)
  raws=[gifts([(1,1,1)],[0]),gifts([(1,1,1)],[1,2,3]),gifts([(500,500,500)],[0,499,500,501,1000,1001,10**9]),gifts([(1,500,500),(500,500,1)],[0,1,2,500,501,1000,1001]),gifts([(500,500,500)]*3,[10**9]),gifts([(1,1,500)]*5,[499,500,501,1000,1001]),gifts([(500,500,1)]*10,[0,500,501,1000,1001,1009,1010,1011]),gifts([(1,500,1),(500,1,500)]*65,list(range(1200)))]
  while len(raws)<16:raws.append(gifts([tuple(rng.randint(1,500) for _ in range(3)) for _ in range(3+len(raws))],[rng.randint(0,30000) for _ in range(20+len(raws))]))
  raws += [gifts([tuple(rng.randint(1,500) for _ in range(3)) for _ in range(10000)],[i*5 for i in range(500000)]),gifts([(500,500,500)]*10000,[10**9]*500000)]
 else:
  values=['0','1','00','01','10','11','0000','110','10101','00001','1'*31,'0'*32]
  while len(values)<16:values.append(''.join(rng.choice('01') for _ in range(50+len(values))))
  values += ['01'*100000,'1'*200000];raws=[str(len(s))+'\n'+s+'\n' for s in values]
 require(len(raws)==len(set(raws))==18,'distinct18');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<8 or i==16 else 'random'} for i,raw in enumerate(raws)]
HINTS={
'abc413_d':('絶対値を使うと等比数列の並び方を絞れます。','公比の絶対値が1なら符号の個数、それ以外なら絶対値順の隣接比を調べます。比は整数の積で比較できます。','疑似コード: Aを絶対値順にsort。全絶対値同じなら同符号のみ、または正負個数差<=1を確認。それ以外は全i>=2でA[i]*A[0]==A[i-1]*A[1]を確認しYes/No。'),
'abc414_d':('一つの基地局で連続する家を覆う費用は、最右端と最左端の座標差です。','座標を整列しM個の連続区間に分けます。区切った隙間の距離だけ費用を減らせます。','疑似コード: Xをsort、隣接差gapsを降順sort。答え=X[-1]-X[0]-sum(gapsの先頭M-1個)。'),
'abc415_d':('交換して飲み終えると空き瓶はAi-Bi本減り、シールを1枚得ます。','実行できる中で消費が最小の交換を優先します。同じ交換の連続回数は割り算で求められます。','疑似コード: (Ai-Bi,Ai)をsort。各(cost,A)でN>=Aならk=(N-A)//cost+1、answer+=k、N-=k*cost。answerを出力。'),
'abc416_d':('剰余を取る前の総和は並べ替えで変わりません。','Ai+Bi>=Mとなるペアを最大化すると、総和からMをより多く引けます。','疑似コード: A昇順、B降順。各bについてAの未使用左端をA[j]+b>=Mまで進める。存在すればペアを作りj++、wrap++。sum(A)+sum(B)-M*wrapを出力。'),
'abc417_d':('テンションが大きい間は必ず下がり、1000以下に入ると以後1000を超えません。','0..1000の各テンションから残りのプレゼントを受け取る結果を、末尾からDPします。大きい初期値は下げ度の累積和で低い領域へ入る位置を探します。','疑似コード: dp[N][x]=x。後ろからdp[i][x]=dp[i+1][x<=P[i]ならx+A[i]、それ以外max(0,x-B[i])]。X<=1000はdp[0][X]。それ以外は累積BでX-1000以上となる最初のprefixをbisectし、減らした値のdpを返す。最後まで1000超ならX-sum(B)。'),
'abc418_d':('二つのビットの操作を、0と1を反転した値のXORとして考えます。','美しい部分文字列は0の個数が偶数です。末尾を固定して、結果が0・1となる部分文字列数を更新します。','疑似コード: zero=one=answer=0。各文字cで、1ならone++、0なら(zero,one)=(one+1,zero)。answer+=one。answerを出力。')}

TITLES={'abc413_d': 'Make Geometric Sequence', 'abc414_d': 'Transmission Mission', 'abc415_d': 'Get Many Stickers', 'abc416_d': 'Match, Mod, Minimize 2', 'abc417_d': "Takahashi's Expectation", 'abc418_d': 'XNOR Operation'}
PUBLISHED_SAMPLES={'abc413_d': [{'input': '3\n5\n1 8 2 4 16\n5\n-16 24 54 81 -36\n7\n90000 8100 -27000 729 -300000 -2430 1000000\n', 'expected': 'Yes\nNo\nYes\n'}], 'abc414_d': [{'input': '7 3\n5 10 15 20 8 14 15\n', 'expected': '6\n'}, {'input': '7 7\n5 10 15 20 8 14 15\n', 'expected': '0\n'}, {'input': '7 1\n5 10 15 20 8 14 15\n', 'expected': '15\n'}], 'abc415_d': [{'input': '5 3\n5 1\n4 3\n3 1\n', 'expected': '3\n'}, {'input': '3 3\n5 1\n5 1\n4 2\n', 'expected': '0\n'}, {'input': '415 8\n327 299\n413 396\n99 67\n108 51\n195 98\n262 180\n250 175\n234 187\n', 'expected': '11\n'}], 'abc416_d': [{'input': '3\n3 6\n3 1 4\n2 0 1\n1 1000000000\n999999999\n999999999\n10 201\n144 150 176 154 110 187 38 136 111 46\n96 109 73 63 85 1 156 7 13 171\n', 'expected': '5\n999999998\n619\n'}], 'abc417_d': [{'input': '4\n3 1 4\n1 5 9\n2 6 5\n3 5 8\n11\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n', 'expected': '6\n0\n0\n0\n5\n6\n0\n0\n0\n0\n0\n'}, {'input': '3\n500 500 500\n500 500 500\n500 500 500\n1\n1000000000\n', 'expected': '999998500\n'}, {'input': '20\n124 370 105\n280 200 420\n425 204 302\n435 141 334\n212 287 231\n262 410 481\n227 388 466\n222 314 366\n307 205 401\n226 460 452\n336 291 119\n302 104 432\n478 348 292\n246 337 403\n102 404 371\n368 399 417\n291 416 351\n236 263 231\n170 415 482\n101 339 184\n20\n1162\n1394\n1695\n2501\n3008\n3298\n4053\n4093\n4330\n5199\n5302\n5869\n5875\n6332\n6567\n7483\n7562\n7725\n9723\n9845\n', 'expected': '339\n339\n339\n339\n339\n339\n339\n339\n339\n339\n339\n339\n339\n389\n339\n643\n722\n885\n2883\n3005\n'}], 'abc418_d': [{'input': '3\n110\n', 'expected': '3\n'}, {'input': '4\n0000\n', 'expected': '4\n'}, {'input': '30\n011011100101110111100010011010\n', 'expected': '225\n'}]}
SAMPLE_COUNTS={'abc413_d': 1, 'abc414_d': 3, 'abc415_d': 3, 'abc416_d': 1, 'abc417_d': 3, 'abc418_d': 3}
