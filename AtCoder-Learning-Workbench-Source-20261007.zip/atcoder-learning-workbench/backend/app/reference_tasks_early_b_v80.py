"""ABC098–100 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS=('abc098_b','abc099_b','abc100_b')
POS=re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER=re.compile(r'[a-z]+', re.ASCII)
NONNEG=re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

def validate(pid:str, raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc098_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None or LOWER.fullmatch(lines[1]) is None:
            raise ValueError('format')
        n=int(lines[0]); s=lines[1]
        if not 2<=n<=100 or len(s)!=n: raise ValueError('range/length')
        return n,s
    if pid=='abc099_b':
        if len(lines)!=1: raise ValueError('lines')
        p=lines[0].split(' ')
        if len(p)!=2 or any(POS.fullmatch(x) is None for x in p): raise ValueError('format')
        a,b=map(int,p)
        if not (1<=a<b<499500): raise ValueError('range')
        d=b-a
        if not 3<=d<=999: raise ValueError('not adjacent valid towers')
        west=d*(d-1)//2
        snow=west-a
        if snow<1: raise ValueError('assumption violated')
        return a,b
    if len(lines)!=1:
        raise ValueError('lines')
    p=lines[0].split(' ')
    if len(p)!=2 or any(NONNEG.fullmatch(x) is None for x in p): raise ValueError('format')
    d,n=map(int,p)
    if d not in (0,1,2) or not 1<=n<=100: raise ValueError('range')
    return d,n

def independent_check(pid:str, raw:str, output:str)->bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or re.fullmatch(r'(?:0|[1-9][0-9]*)',output,re.ASCII) is None:
        return False
    actual=int(output)
    if pid=='abc098_b':
        n,s=value
        best=0
        for cut in range(1,n):
            left=[False]*26; right=[False]*26
            for c in s[:cut]: left[ord(c)-97]=True
            for c in s[cut:]: right[ord(c)-97]=True
            common=sum(1 for i in range(26) if left[i] and right[i])
            if common>best: best=common
        return actual==best
    if pid=='abc099_b':
        a,b=value
        d=b-a
        west=sum(range(1,d))
        snow=west-a
        return actual==snow and snow>=1
    d,n=value
    count=0; k=0
    scale=100**d
    while count<n:
        k+=1
        x=k*scale
        y=x
        times=0
        while y%100==0:
            y//=100; times+=1
        if times==d:
            count+=1
    return actual==x

def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    rows=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); rows.append({'category':category,'input':raw})
    if pid=='abc098_b':
        vals=[
          'aa','ab','aaa','abc','aba','aabbca','abcdef','abcabc','abacabadabacaba',
          'aaaaaaaaaa','abcdefghijklmnopqrstuvwxzy',
          'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz',
          'zzxyzzxyzzxy','mississippi','atcoderbeginnercontest',
          'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyza',
          'abcde'*19,
        ]
        for s in vals:
            add('boundary' if len(s) in (2,100) else 'normal',f'{len(s)}\n{s}\n')
        s=('abcdefghijklmnopqrstuvwxyz'*4)[:100]
        add('constraint_max',f'100\n{s}\n')
    elif pid=='abc099_b':
        # Build valid inputs from adjacent triangular towers and a positive snow depth.
        specs=[(3,1),(4,1),(5,2),(6,3),(10,1),(10,20),(14,2),(20,50),(50,100),
               (100,1000),(200,5000),(333,10000),(500,50000),(700,100000),(900,200000),
               (998,1),(999,1000)]
        for d,snow in specs:
            west=d*(d-1)//2
            if snow>=west: snow=west-1
            a=west-snow; b=a+d
            add('boundary' if d in (3,998,999) or snow==1 else 'normal',f'{a} {b}\n')
        d=999; snow=1; west=d*(d-1)//2
        add('constraint_max',f'{west-snow} {west-snow+d}\n')
    else:
        vals=[(0,1),(0,2),(0,5),(0,11),(0,99),(0,100),
              (1,1),(1,2),(1,11),(1,99),(1,100),
              (2,1),(2,2),(2,10),(2,85),(2,99),(2,50)]
        for d,n in vals:
            add('boundary' if n in (1,99,100) or d in (0,2) else 'normal',f'{d} {n}\n')
        add('constraint_max','2 100\n')
    if len(rows)!=18 or len(seen)!=18 or rows[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: not 18 distinct cases ending in max: {len(rows)}')
    return rows
