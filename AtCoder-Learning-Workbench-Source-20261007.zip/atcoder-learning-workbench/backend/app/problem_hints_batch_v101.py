"""Statement-checked three-stage hints for ABC161–163 B."""
HINTS_V101 = {
    'abc161_b': (
        '必要なのは上位M個が条件を満たせるかです。まず「選べる票数」の境界を、総投票数との比較に直してください。',
        '商品iが選べる条件は Ai >= sum(A)/(4M) です。浮動小数を使わず、4*M*Ai >= sum(A) と比較できます。条件を満たす商品がM個以上ならYesです。',
        '''疑似コード:\ntotal = sum(A)\neligible = 0\nfor votes in A:\n  if 4 * M * votes >= total:\n    eligible += 1\nif eligible >= M:\n  print("Yes")\nelse:\n  print("No")''',
    ),
    'abc162_b': (
        'FizzやBuzzにならず、数値のまま残る項だけを足します。つまり3でも5でも割り切れない整数を対象にしてください。',
        '1からNまで走査して、i%3!=0 かつ i%5!=0 のときだけ加算すれば制約内です。包除原理で総和から3の倍数・5の倍数を引く方法でも構いません。',
        '''疑似コード:\nanswer = 0\nfor i = 1 .. N:\n  if i % 3 != 0 and i % 5 != 0:\n    answer += i\nprint(answer)''',
    ),
    'abc163_b': (
        '宿題に使う日数の合計だけを考えると、遊べる日数が直接求まります。宿題を終えられない場合も分けてください。',
        'used=sum(A) とします。used>N なら休暇中に終えられないので-1、そうでなければ N-used 日遊べます。',
        '''疑似コード:\nused = sum(A)\nif used > N:\n  print(-1)\nelse:\n  print(N - used)''',
    ),
}
