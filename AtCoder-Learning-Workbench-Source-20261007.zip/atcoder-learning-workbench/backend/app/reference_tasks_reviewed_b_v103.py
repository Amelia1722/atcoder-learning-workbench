"""ABC167–169 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc167_b', 'abc168_b', 'abc169_b')
NAT = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)
LIMIT = 10**18

PUBLISHED_SAMPLES = {
    'abc167_b': [
        {'input':'2 1 1 3\n','expected':'2\n'},
        {'input':'1 2 3 4\n','expected':'0\n'},
        {'input':'2000000000 0 0 2000000000\n','expected':'2000000000\n'},
    ],
    'abc168_b': [
        {'input':'7\nnikoandsolstice\n','expected':'nikoand...\n'},
        {'input':'40\nferelibenterhominesidquodvoluntcredunt\n','expected':'ferelibenterhominesidquodvoluntcredunt\n'},
    ],
    'abc169_b': [
        {'input':'2\n1000000000 1000000000\n','expected':'1000000000000000000\n'},
        {'input':'3\n101 9901 999999000001\n','expected':'-1\n'},
        {'input':'31\n4 1 5 9 2 6 5 3 5 8 9 7 9 3 2 3 8 4 6 2 6 4 3 3 8 3 2 7 9 5 0\n','expected':'0\n'},
    ],
}


def _canon_nat_row(line: str, count: int) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(NAT.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc167_b':
        if len(lines) != 1:
            raise ValueError('expected one row')
        a,b,c,k = _canon_nat_row(lines[0], 4)
        if not (0 <= a <= 2_000_000_000 and 0 <= b <= 2_000_000_000 and 0 <= c <= 2_000_000_000):
            raise ValueError('card range')
        total = a+b+c
        if not (1 <= k <= total <= 2_000_000_000):
            raise ValueError('K/total range')
        return a,b,c,k
    if pid == 'abc168_b':
        if len(lines) != 2 or POS.fullmatch(lines[0]) is None or LOWER.fullmatch(lines[1]) is None:
            raise ValueError('expected K and lowercase S')
        k = int(lines[0]); s = lines[1]
        if not (1 <= k <= 100 and 1 <= len(s) <= 100):
            raise ValueError('range')
        return k,s
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('expected N and A row')
    n = int(lines[0])
    if not 2 <= n <= 100_000:
        raise ValueError('N range')
    arr = _canon_nat_row(lines[1], n)
    if any(x > LIMIT for x in arr):
        raise ValueError('Ai range')
    return n,arr


def _expected_169(arr: list[int]) -> int:
    if 0 in arr:
        return 0
    p = 1
    for x in arr:
        if p > LIMIT // x:
            return -1
        p *= x
    return p


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc167_b':
        if not re.fullmatch(r'-?(?:0|[1-9][0-9]*)', output, re.ASCII):
            return False
        a,b,_,k = value
        take_one = min(a,k)
        rem = k - take_one
        rem -= min(b,rem)
        return output == str(take_one-rem)
    if pid == 'abc168_b':
        k,s = value
        expected = s if len(s) <= k else s[:k]+'...'
        return output == expected
    if not re.fullmatch(r'-1|0|[1-9][0-9]*', output, re.ASCII):
        return False
    _,arr = value
    return output == str(_expected_169(arr))


def _167(a:int,b:int,c:int,k:int)->str:
    return f'{a} {b} {c} {k}\n'

def _168(k:int,s:str)->str:
    return f'{k}\n{s}\n'

def _169(arr:list[int])->str:
    return f'{len(arr)}\n'+' '.join(map(str,arr))+'\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category:str, raw:str):
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid == 'abc167_b':
        vals=[
            ('sample1',2,1,1,3),('sample2',1,2,3,4),('only_ones',5,0,0,3),
            ('all_ones',5,0,0,5),('ones_then_zeros',3,4,5,5),('exact_ones_zeros',3,4,5,7),
            ('needs_one_minus',3,4,5,8),('needs_all_minus',0,0,5,5),('only_zeros',0,5,0,3),
            ('zero_then_minus',0,5,5,7),('k_one',0,0,5,1),('balanced_small',2,2,2,6),
            ('large_k_with_minus',10,20,30,55),('large_ones',1000000000,1,1,999999999),
            ('sum_limit_mix',1000000000,500000000,500000000,1750000000),
            ('near_total',999999999,999999999,2,1999999999),('large_negative_result',1,1,1999999998,2000000000),
        ]
        for row in vals: add(row[0],_167(*row[1:]))
        add('constraint_max',_167(2_000_000_000,0,0,2_000_000_000))
    elif pid == 'abc168_b':
        vals=[
            ('sample1',7,'nikoandsolstice'),('sample2',40,'ferelibenterhominesidquodvoluntcredunt'),
            ('min_exact',1,'a'),('min_truncate',1,'ab'),('equal_short',3,'abc'),('just_over',3,'abcd'),
            ('k_larger',10,'abc'),('all_same',5,'aaaaaaaaaa'),('alphabet_cut',13,'abcdefghijklmnopqrstuvwxyz'),
            ('k99_len100',99,'a'*100),('k100_len99',100,'b'*99),('single_z',100,'z'),
            ('len100_cut1',1,'c'*100),('len100_cut50',50,'d'*100),('pattern',6,'abcabcabcabc'),
            ('k2_len3',2,'xyz'),('k98_len100',98,'q'*100),
        ]
        for cat,k,s in vals: add(cat,_168(k,s))
        add('constraint_max',_168(100,'z'*100))
    else:
        vals=[
            ('sample1',[10**9,10**9]),('sample2',[101,9901,999999000001]),
            ('sample3_prefix',[4,1,5,9,2,6,5,3,5,8,9,7,9,3,2,3,8,4,6,2,6,4,3,3,8,3,2,7,9,5,0]),
            ('min_zero',[0,0]),('zero_after_overflow',[10**18,10**18,0]),('zero_first',[0,10**18,10**18]),
            ('ones',[1,1]),('limit_exact',[10**18,1]),('limit_exact_split',[10**6,10**6,10**6]),
            ('limit_plus_one',[10**18,2]),('small_product',[2,3,5,7]),('many_twos',[2]*59),
            ('overflow_twos',[2]*60),('mixed_ones',[1,1,10**18,1,1]),('near_limit_safe',[999999999999999999,1]),
            ('near_limit_over',[999999999999999999,2]),('large_n_safe',[1]*99999+[10**18]),
        ]
        for cat,arr in vals: add(cat,_169(arr))
        add('constraint_max',_169([10**18]*100000))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
