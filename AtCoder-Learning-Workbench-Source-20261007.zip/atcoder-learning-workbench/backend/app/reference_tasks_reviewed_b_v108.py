"""ABC182–184 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
from decimal import Decimal, InvalidOperation, localcontext
import re

TASKS = ('abc182_b', 'abc183_b', 'abc184_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
SIGNED = re.compile(r'(?:0|-?[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc182_b': [
        {'input':'3\n3 12 7\n','expected':'3\n'},
        {'input':'5\n8 9 18 90 72\n','expected':'9\n'},
        {'input':'5\n1000 1000 1000 1000 1000\n','expected':'1000\n'},
    ],
    'abc183_b': [
        {'input':'1 1 7 2\n','expected':'3.0000000000\n'},
        {'input':'1 1 3 2\n','expected':'1.6666666667\n'},
        {'input':'-9 99 -999 9999\n','expected':'-18.7058823529\n'},
    ],
    'abc184_b': [
        {'input':'3 0\nxox\n','expected':'0\n'},
        {'input':'20 199999\noooooooooxoooooooooo\n','expected':'200017\n'},
        {'input':'20 10\nxxxxxxxxxxxxxxxxxxxx\n','expected':'0\n'},
    ],
}

def _row(line: str, count: int, pattern: re.Pattern[str]) -> list[int]:
    parts=line.split(' ')
    if len(parts)!=count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int,parts))

def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc182_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected N and A row')
        n=int(lines[0])
        if not 1<=n<=100:
            raise ValueError('N range')
        a=_row(lines[1],n,POS)
        if any(not 2<=x<=1000 for x in a):
            raise ValueError('A range')
        return a
    if pid=='abc183_b':
        if len(lines)!=1:
            raise ValueError('single row required')
        sx,sy,gx,gy=_row(lines[0],4,SIGNED)
        if not (-1_000_000<=sx<=1_000_000 and -1_000_000<=gx<=1_000_000):
            raise ValueError('x range')
        if not (1<=sy<=1_000_000 and 1<=gy<=1_000_000):
            raise ValueError('y range')
        if sx==gx:
            raise ValueError('Sx != Gx required')
        return sx,sy,gx,gy
    if len(lines)!=2:
        raise ValueError('expected header and S')
    n,x=_row(lines[0],2,NONNEG)
    if not 1<=n<=200_000 or not 0<=x<=200_000:
        raise ValueError('N/X range')
    s=lines[1]
    if len(s)!=n or any(c not in 'ox' for c in s):
        raise ValueError('S shape/alphabet')
    return x,s

def _best_degree(a: list[int]) -> int:
    return max(sum(x%k==0 for x in a) for k in range(2,1001))

def _answer_183(v: tuple[int,int,int,int]) -> Decimal:
    sx,sy,gx,gy=v
    with localcontext() as ctx:
        ctx.prec=80
        return (Decimal(sx)*Decimal(gy)+Decimal(gx)*Decimal(sy))/Decimal(sy+gy)

def _answer_184(v: tuple[int,str]) -> int:
    score,s=v
    for c in s:
        if c=='o': score+=1
        elif score>0: score-=1
    return score

def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or output!=output.strip() or '\n' in output:
        return False
    if pid=='abc182_b':
        if POS.fullmatch(output) is None: return False
        k=int(output)
        if not 2<=k<=1000: return False
        return sum(x%k==0 for x in value)==_best_degree(value)
    if pid=='abc183_b':
        try: actual=Decimal(output)
        except InvalidOperation: return False
        if not actual.is_finite(): return False
        truth=_answer_183(value)
        diff=abs(actual-truth); tol=Decimal('1e-6')
        return diff<=tol or diff<=abs(truth)*tol
    if NONNEG.fullmatch(output) is None: return False
    return int(output)==_answer_184(value)

def _182(a): return f'{len(a)}\n'+' '.join(map(str,a))+'\n'
def _183(sx,sy,gx,gy): return f'{sx} {sy} {gx} {gy}\n'
def _184(x,s): return f'{len(s)} {x}\n{s}\n'

def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc182_b':
        cases=[
          ('sample1',[3,12,7]),('sample2',[8,9,18,90,72]),('sample3',[1000]*5),
          ('single_min',[2]),('single_prime',[997]),('three_way_tie',[6,10,15]),
          ('all_even',[2,4,6,8,10]),('all_three',[3,6,9,12,15]),('all_seven',[7,14,21,28,35]),
          ('small_primes',[2,3,5,7,11]),('mixed_6',[12,18,24,30,42]),('same_30',[30]*10),
          ('n20_pattern',[6,10,15,21,22]*4),('n40_even_odd',[2 if i%2==0 else 9 for i in range(40)]),
          ('n50_sixes',[6*(i%10+1) for i in range(50)]),('n75_mixed',[2+(i*37)%999 for i in range(75)]),
          ('n99_999',[999]*99),
        ]
        for c,a in cases:add(c,_182(a))
        add('constraint_max',_182([1000]*100))
    elif pid=='abc183_b':
        cases=[
          ('sample1',(1,1,7,2)),('sample2',(1,1,3,2)),('sample3',(-9,99,-999,9999)),
          ('symmetric',(-10,5,10,5)),('left_to_right',(-100,1,100,1)),('right_to_left',(100,1,-100,1)),
          ('unequal_y',(0,1,10,9)),('large_sy',(0,1000000,1,1)),('large_gy',(0,1,1,1000000)),
          ('negative_both',(-100,3,-1,7)),('positive_both',(1,7,100,3)),('cross_zero',(-999999,2,999999,3)),
          ('near_x_min',(-1000000,999999,-999999,1000000)),('near_x_max',(999999,1000000,1000000,999999)),
          ('unit_gap_neg',(-1,123456,0,654321)),('fractional',(2,3,11,17)),('large_mixed',(-765432,234567,876543,987654)),
        ]
        for c,v in cases:add(c,_183(*v))
        add('constraint_max',_183(-1000000,1000000,1000000,1000000))
    else:
        cases=[
          ('sample1',(0,'xox')),('sample2',(199999,'oooooooooxoooooooooo')),('sample3',(10,'x'*20)),
          ('one_o',(0,'o')),('one_x_zero',(0,'x')),('one_x_positive',(1,'x')),
          ('floor_after_gain',(0,'oxx')),('never_below_zero',(0,'xxxxoxxx')),('all_o',(5,'o'*10)),
          ('all_x_exact',(10,'x'*10)),('alternating',(3,'ox'*10)),('alternating_start_x',(3,'xo'*10)),
          ('x_then_many_o',(0,'x'*20+'o'*30)),('many_o_then_x',(0,'o'*30+'x'*20)),
          ('n1000_zero',(0,'x'*500+'o'*500)),('n10000_mid',(5000,'x'*7000+'o'*3000)),
          ('n199999_pattern',(12345,('oxxoo'*40000)[:199999])),
        ]
        for c,(x,s) in cases:add(c,_184(x,s))
        add('constraint_max',_184(200000,'o'*200000))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
