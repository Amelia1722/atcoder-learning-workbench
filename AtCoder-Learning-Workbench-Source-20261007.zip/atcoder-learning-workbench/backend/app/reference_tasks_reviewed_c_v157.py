"""Turn134: sixteen ordinary tasks and two authorized exhaustive finite domains."""
from __future__ import annotations
from collections import Counter,deque
from functools import lru_cache
from itertools import combinations,permutations,product
from math import factorial,gcd,isqrt
import random,re
from typing import cast

TASKS=('abc029_c','abc039_c','arc062_a','arc063_a','arc064_a','arc065_a','arc066_a','abc051_c','arc067_a','arc068_a','abc054_c','arc069_a','arc070_a','abc057_c','arc071_a','arc072_a','arc073_a','abc061_c')
NUMBERS=dict(zip(TASKS,(29,39,*range(46,62))))
CONTESTS={p:f'abc{NUMBERS[p]:03}' for p in TASKS}
CASE_COUNTS={p:8 if p=='abc029_c' else 7 if p=='abc039_c' else 18 for p in TASKS}
LANES={chr(65+i):TASKS[i*3:i*3+3] for i in range(6)}
OUTPUT_MODES={'abc051_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
PERIOD='WBWBWWBWBWBW'
WHITE=(0,2,4,5,7,9,11)
NAMES=('Do','Re','Mi','Fa','So','La','Si')
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'canonical integers')
    a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');i=NUMBERS[pid]
    if i in (29,52,53,56,57):
        require(len(rows)==1,'shape');n,=ints(rows[0],1);limits={29:8,52:1000,53:10**15,56:10**9,57:10**10};require(1<=n<=limits[i],'scalar');return (n,)
    if i==39:
        require(len(rows)==1 and rows[0] in tuple((PERIOD*3)[j:j+20] for j in WHITE),'valid white-key piano window');return (rows[0],)
    if i in (47,49):
        s=rows[0];require(len(rows)==1 and 1<=len(s)<=100000 and re.fullmatch('[BW]+' if i==47 else '[a-z]+',s) is not None,'string');return (s,)
    if i==46:
        n,=ints(rows[0],1);pairs=tuple(ints(r,2) for r in rows[1:]);require(1<=n<=1000 and len(pairs)==n and all(1<=t<=1000 and 1<=a<=1000 and gcd(t,a)==1 for t,a in pairs),'coprime vote ratios')
        t=a=1
        for x,y in pairs:factor=max((t+x-1)//x,(a+y-1)//y);t=x*factor;a=y*factor
        require(t+a<=10**18,'guaranteed answer bound');return n,pairs
    if i==51:
        require(len(rows)==1,'shape');sx,sy,tx,ty=ints(rows[0],4);require(-1000<=sx<tx<=1000 and -1000<=sy<ty<=1000,'route endpoints');return sx,sy,tx,ty
    if i==54:
        n,m=ints(rows[0],2);edges=tuple(ints(r,2) for r in rows[1:]);require(2<=n<=8 and 0<=m<=n*(n-1)//2 and len(edges)==len(set(edges))==m and all(1<=a<b<=n for a,b in edges),'simple graph');return n,edges
    if i==55:
        require(len(rows)==1,'shape');n,m=ints(rows[0],2);require(1<=n<=10**12 and 1<=m<=10**12,'pieces');return n,m
    if i==58:
        n,=ints(rows[0],1);strings=tuple(rows[1:]);require(1<=n<=50 and len(strings)==n and all(re.fullmatch('[a-z]{1,50}',s) is not None for s in strings),'documents');return n,strings
    if i==61:
        n,k=ints(rows[0],2);pairs=tuple(ints(r,2) for r in rows[1:]);require(1<=n<=100000 and len(pairs)==n and all(1<=a<=100000 and 1<=b<=100000 for a,b in pairs) and 1<=k<=sum(b for a,b in pairs),'big array rank');return n,k,pairs
    require(len(rows)==2,'shape')
    if i in (48,60):n,k=ints(rows[0],2)
    else:n,=ints(rows[0],1);k=0
    a=ints(rows[1],n)
    if i==48:require(2<=n<=100000 and 0<=k<=10**9 and all(0<=v<=10**9 for v in a),'candies')
    elif i==50:require(1<=n<=100000 and all(0<=v<n for v in a),'reports')
    elif i==59:require(2<=n<=100000 and all(abs(v)<=10**9 for v in a),'signed sequence')
    else:require(1<=n<=200000 and 1<=k<=10**9 and a[0]==0 and a[-1]<=10**9 and all(a[j]<a[j+1] for j in range(n-1)),'shower times')
    return (n,k,a) if i in (48,60) else (n,a)

def route_length(sx:int,sy:int,tx:int,ty:int)->int:return 4*(tx-sx+ty-sy)+8
def valid_route(raw:str,actual:str)->bool:
    sx,sy,tx,ty=cast(tuple[int,int,int,int],validate('abc051_c',raw));path=actual.removesuffix('\n')
    if len(path)!=route_length(sx,sy,tx,ty) or re.fullmatch('[UDLR]+',path) is None:return False
    x,y=sx,sy;seen:set[Pair]=set();arrivals=[]
    directions={'U':(0,1),'D':(0,-1),'L':(-1,0),'R':(1,0)}
    for ch in path:
        dx,dy=directions[ch];x+=dx;y+=dy;point=(x,y)
        if point in ((sx,sy),(tx,ty)):arrivals.append(point)
        elif point in seen:return False
        else:seen.add(point)
    return (x,y)==(sx,sy) and arrivals==[(tx,ty),(sx,sy),(tx,ty),(sx,sy)]

def _candy_oracle(a:tuple[int,...],x:int)->int:
    if x<=20 and len(a)<=12:
        # Maximize retained candy by dynamic programming over the last count.
        dp={v:v for v in range(min(a[0],x)+1)}
        for value in a[1:]:dp={v:v+max(score for previous,score in dp.items() if previous+v<=x) for v in range(min(value,x)+1)}
        return sum(a)-max(dp.values())
    remaining=list(reversed(a));removed=max(0,remaining[0]-x);remaining[0]=min(remaining[0],x)
    for j in range(1,len(a)):
        retained=min(remaining[j],x-remaining[j-1]);removed+=remaining[j]-retained;remaining[j]=retained
    return removed

def _reversi_small(s:str)->int:
    start=''.join(ch for j,ch in enumerate(s) if not j or ch!=s[j-1]);queue=deque([(start,0)]);seen={start}
    while queue:
        state,cost=queue.popleft()
        if len(state)==1:return cost
        # Place the color of the second run at either endpoint, enclosing and
        # recoloring the first run. Each move is simulated on run colors.
        for reverse in (False,True):
            row=state[::-1] if reverse else state;nxt=row[1:]
            if reverse:nxt=nxt[::-1]
            if nxt not in seen:seen.add(nxt);queue.append((nxt,cost+1))
    raise AssertionError('finite reversi')

def _sequence_oracle(a:tuple[int,...])->int:
    # Exact min-plus DP for small values, independently of greedy adjustment.
    if len(a)<=8 and sum(map(abs,a))<=40:
        bound=2*sum(map(abs,a))+2*len(a)+1;results=[]
        for first in (1,-1):
            costs={0:0}
            for j,v in enumerate(a):
                sign=first*(-1 if j%2 else 1);states=range(1,bound+1) if sign>0 else range(-bound,0)
                costs={s:min(c+abs(s-t-v) for t,c in costs.items()) for s in states}
            results.append(min(costs.values()))
        return min(results)
    # Total variation of corrections z_i=adjusted_prefix_i-original_prefix_i,
    # projected onto alternating half-lines z_i >= 1-P_i / <= -1-P_i.
    answers=[]
    for first in (1,-1):
        prefix=correction=cost=0
        for j,v in enumerate(a):
            prefix+=v;boundary=first*(-1 if j%2 else 1)-prefix
            if (j%2==0)==(first==1):nxt=max(correction,boundary)
            else:nxt=min(correction,boundary)
            cost+=abs(nxt-correction);correction=nxt
        answers.append(cost)
    return min(answers)

@lru_cache(maxsize=512)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);i=NUMBERS[pid]
    if i==29:
        n=cast(int,data[0]);words=[]
        for value in range(3**n):
            digits=['a']*n
            for j in range(n-1,-1,-1):digits[j]='abc'[value%3];value//=3
            words.append(''.join(digits))
        return '\n'.join(words)
    if i==39:
        s=cast(str,data[0]);black={1,3,6,8,10}
        return next(name for shift,name in zip(WHITE,NAMES) if all((ch=='B')==((j+shift)%12 in black) for j,ch in enumerate(s)))
    if i==46:
        n,pairs=cast(tuple[int,tuple[Pair,...]],data);t=a=1
        for x,y in pairs:
            low,high=1,max(t,a)
            while low<high:
                middle=(low+high)//2
                if middle*x>=t and middle*y>=a:high=middle
                else:low=middle+1
            t,a=low*x,low*y
        return str(t+a)
    if i==47:
        s=cast(str,data[0]);return str(_reversi_small(s) if len(s)<=20 else len(re.findall(r'B+|W+',s))-1)
    if i==48:
        n,x,a=cast(tuple[int,int,tuple[int,...]],data);return str(_candy_oracle(a,x))
    if i==49:
        s=cast(str,data[0]);reachable=[False]*(len(s)+1);reachable[0]=True
        for j in range(len(s)):
            if reachable[j]:
                for word in ('dream','dreamer','erase','eraser'):
                    if s.startswith(word,j):reachable[j+len(word)]=True
        return 'YES' if reachable[-1] else 'NO'
    if i==50:
        n,a=cast(tuple[int,tuple[int,...]],data);positions=Counter(abs(j-(n-1-j)) for j in range(n))
        if Counter(a)!=positions:return '0'
        answer=1
        for multiplicity in positions.values():answer=answer*factorial(multiplicity)%1000000007
        return str(answer)
    if i==51:
        sx,sy,tx,ty=cast(tuple[int,int,int,int],data);x,y=tx-sx,ty-sy
        return 'R'*x+'U'*y+'L'*x+'D'*y+'D'+'R'*(x+1)+'U'*(y+1)+'L'+'U'+'L'*(x+1)+'D'*(y+1)+'R'
    if i==52:
        n=cast(int,data[0]);answer=1
        for prime in range(2,n+1):
            if all(prime%d for d in range(2,isqrt(prime)+1)):
                power=prime;exponent=0
                while power<=n:exponent+=n//power;power*=prime
                answer=answer*(exponent+1)%1000000007
        return str(answer)
    if i==53:
        x=cast(int,data[0])
        if x<=100:
            scores={face:face for face in range(1,7)};rolls=1
            while max(scores.values())<x:
                scores={face:face+max(total for previous,total in scores.items() if previous!=face and previous+face!=7) for face in range(1,7)};rolls+=1
            return str(rolls)
        low,high=1,x
        while low<high:
            middle=(low+high)//2
            if 6*((middle+1)//2)+5*(middle//2)>=x:high=middle
            else:low=middle+1
        return str(low)
    if i==54:
        n,edges=cast(tuple[int,tuple[Pair,...]],data);neighbors=[[] for _ in range(n)]
        for u,v in edges:neighbors[u-1].append(v-1);neighbors[v-1].append(u-1)
        dp={(1,0):1}
        for count in range(1,n):
            nxt={}
            for (mask,last),ways in dp.items():
                for v in neighbors[last]:
                    if not(mask>>v&1):key=(mask|1<<v,v);nxt[key]=nxt.get(key,0)+ways
            dp=nxt
        return str(sum(dp.values()))
    if i==55:
        n,m=cast(tuple[int,int],data);low,high=0,n+m
        while low<high:
            middle=(low+high+1)//2;required=2*middle+2*max(0,middle-n)
            if required<=m:low=middle
            else:high=middle-1
        return str(low)
    if i==56:
        x=cast(int,data[0])
        if x<=30:
            positions={0};time=0
            while x not in positions:
                time+=1;positions={p+d for p in positions for d in (-time,0,time)}
            return str(time)
        time=(isqrt(8*x+1)-1)//2
        return str(time if time*(time+1)//2>=x else time+1)
    if i==57:
        n=cast(int,data[0]);remaining=n;divisors=[1];p=2
        while p*p<=remaining:
            factor=1;base=divisors.copy()
            while remaining%p==0:
                remaining//=p;factor*=p;divisors.extend(d*factor for d in base)
            p+=1
        if remaining>1:divisors.extend(d*remaining for d in divisors.copy())
        return str(min(max(len(str(d)),len(str(n//d))) for d in divisors))
    if i==58:
        n,strings=cast(tuple[int,tuple[str,...]],data);answer=''
        for ch in 'abcdefghijklmnopqrstuvwxyz':answer+=ch*min(s.count(ch) for s in strings)
        return answer
    if i==59:
        n,a=cast(tuple[int,tuple[int,...]],data);return str(_sequence_oracle(a))
    if i==60:
        n,t,a=cast(tuple[int,int,tuple[int,...]],data);left=right=a[0];answer=0
        for start in a:
            end=start+t
            if start>right:answer+=right-left;left=start
            right=max(right,end)
        return str(answer+right-left)
    n,k,pairs=cast(tuple[int,int,tuple[Pair,...]],data);low,high=1,100000
    while low<high:
        middle=(low+high)//2
        if sum(b for a,b in pairs if a<=middle)>=k:high=middle
        else:low=middle+1
    return str(low)

def independent_check(pid:str,raw:str,actual:str)->bool:
    return valid_route(raw,actual) if pid=='abc051_c' else actual.removesuffix('\n')==oracle(pid,raw)
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout)

REFERENCE_CODE:dict[str,str]={}
def reference(i:int,body:str)->None:
    pid=next(p for p in TASKS if NUMBERS[p]==i);REFERENCE_CODE[pid]='from collections import Counter\nfrom itertools import permutations\nfrom math import isqrt\n'+body.strip()+'\n'
reference(29,'''
n=int(input());words=['']
for _ in range(n):words=[prefix+ch for prefix in words for ch in 'abc']
print('\n'.join(words))
'''.replace("'\n'","'\\n'"))
reference(39,"s=input();period='WBWBWWBWBWBW'*3;names={0:'Do',2:'Re',4:'Mi',5:'Fa',7:'So',9:'La',11:'Si'};print(next(name for j,name in names.items() if period[j:j+20]==s))")
reference(46,'''
n=int(input());t=a=1
for _ in range(n):
 x,y=map(int,input().split());mult=max((t+x-1)//x,(a+y-1)//y);t=mult*x;a=mult*y
print(t+a)
''')
reference(47,"s=input();print(sum(s[i]!=s[i-1] for i in range(1,len(s))))")
reference(48,'''
n,x=map(int,input().split());a=list(map(int,input().split()));answer=max(0,a[0]-x);a[0]=min(a[0],x)
for j in range(1,n):removed=max(0,a[j-1]+a[j]-x);a[j]-=removed;answer+=removed
print(answer)
''')
reference(49,'''
s=input()[::-1];words=[s[::-1] for s in ('dream','dreamer','erase','eraser')];j=0
while j<len(s):
 for word in words:
  if s.startswith(word,j):j+=len(word);break
 else:print('NO');break
else:print('YES')
''')
reference(50,"n=int(input());a=sorted(map(int,input().split()));expected=sorted(abs(2*i-n+1) for i in range(n));print(pow(2,n//2,1000000007) if a==expected else 0)")
reference(51,"sx,sy,tx,ty=map(int,input().split());x=tx-sx;y=ty-sy;print('U'*y+'R'*x+'D'*y+'L'*x+'L'+'U'*(y+1)+'R'*(x+1)+'D'+'R'+'D'*(y+1)+'L'*(x+1)+'U')")
reference(52,'''
n=int(input());counts=Counter()
for value in range(2,n+1):
 p=2
 while p*p<=value:
  while value%p==0:counts[p]+=1;value//=p
  p+=1
 if value>1:counts[value]+=1
answer=1
for exponent in counts.values():answer=answer*(exponent+1)%1000000007
print(answer)
''')
reference(53,"x=int(input());q,r=divmod(x,11);print(2*q+(0 if r==0 else 1 if r<=6 else 2))")
reference(54,'''
n,m=map(int,input().split());edges=set()
for _ in range(m):
 a,b=map(int,input().split());edges.add((a,b));edges.add((b,a))
answer=0
for order in permutations(range(2,n+1)):
 path=(1,)+order
 if all((path[i],path[i+1]) in edges for i in range(n-1)):answer+=1
print(answer)
''')
reference(55,"n,m=map(int,input().split());base=min(n,m//2);print(base+(m-2*base)//4)")
reference(56,"x=int(input());time=total=0\nwhile total<x:time+=1;total+=time\nprint(time)")
reference(57,"n=int(input());answer=len(str(n))\nfor d in range(1,isqrt(n)+1):\n if n%d==0:answer=min(answer,len(str(n//d)))\nprint(answer)")
reference(58,"n=int(input());counts=Counter(input())\nfor _ in range(n-1):counts&=Counter(input())\nprint(''.join(ch*counts[ch] for ch in sorted(counts)))")
reference(59,'''
n=int(input());a=list(map(int,input().split()));answers=[]
for first in (1,-1):
 total=cost=0;sign=first
 for value in a:
  total+=value
  if total*sign<=0:cost+=abs(sign-total);total=sign
  sign=-sign
 answers.append(cost)
print(min(answers))
''')
reference(60,"n,t=map(int,input().split());a=list(map(int,input().split()));print(t+sum(min(t,a[j]-a[j-1]) for j in range(1,n)))")
reference(61,'''
n,k=map(int,input().split());pairs=sorted(tuple(map(int,input().split())) for _ in range(n))
for value,count in pairs:
 k-=count
 if k<=0:print(value);break
''')

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def array(a:list[int])->str:return f'{len(a)}\n'+line(a)
def generate(pid:str)->list[Case]:
    i=NUMBERS[pid];rng=random.Random(15700+i);raws:list[str]=[]
    if i==29:raws=[f'{n}\n' for n in range(1,9)]
    elif i==39:raws=[(PERIOD*3)[j:j+20]+'\n' for j in WHITE]
    elif i==46:
        def votes(pairs:list[Pair])->str:return f'{len(pairs)}\n'+''.join(f'{t} {a}\n' for t,a in pairs)
        raws=[votes([(1,1)]),votes([(1000,999)]),votes([(1,2),(2,1)]),votes([(1,1000),(1000,1)]*2)]
        choices=[(1,1),(1,2),(2,1),(2,3),(3,2),(7,11)]
        raws += [votes([rng.choice(choices) for _ in range(n)]) for n in range(2,15)];raws.append(votes([(999,1000)]*1000))
    elif i==47:
        raws=['B\n','W\n','BW\n','BWB\n','BBBWWWBBB\n']+[''.join(rng.choice('BW') for _ in range(n))+'\n' for n in range(4,16)];raws.append('BW'*50000+'\n')
    elif i==48:
        def candies(a:list[int],x:int)->str:return f'{len(a)} {x}\n'+line(a)
        raws=[candies([0,0],0),candies([10**9]*2,0),candies([10**9]*2,10**9),candies([0,10,0],5),candies([4,4,4],5)]+[candies([rng.randrange(21) for _ in range(n)],rng.randrange(21)) for n in range(4,16)];raws.append(candies([10**9]*100000,10**9))
    elif i==49:
        raws=['a\n','dream\n','dreamer\n','erase\n','eraser\n','dreamerase\n','dreameraser\n','dreamerer\n']+['dream'*n+'eraser\n' for n in range(2,11)];raws.append('dream'*20000+'\n')
    elif i==50:
        raws=[array([0]),array([1,1]),array([0,0]),array([0,2,2])]
        for n in range(4,17):
            a=[abs(2*j-n+1) for j in range(n)];rng.shuffle(a)
            if n%3==0:a[0]=0
            raws.append(array(a))
        raws.append(array([abs(2*j-99999) for j in range(100000)]))
    elif i==51:
        raws=['0 0 1 1\n','-1000 -1000 -999 -999\n','0 0 1 1000\n','0 0 1000 1\n']+[f'{-j} {-j-1} {j+1} {j+3}\n' for j in range(1,14)];raws.append('-1000 -1000 1000 1000\n')
    elif i==52:raws=[f'{n}\n' for n in (1,2,3,4,5,6,7,10,11,16,25,49,97,100,101,500,999,1000)]
    elif i==53:raws=[f'{n}\n' for n in (1,5,6,7,10,11,12,16,17,18,21,22,23,99,100,10**14,10**15-1,10**15)]
    elif i==54:
        def graph(n:int,edges:list[Pair])->str:return f'{n} {len(edges)}\n'+''.join(f'{a} {b}\n' for a,b in edges)
        raws=[graph(2,[]),graph(2,[(1,2)]),graph(3,[(1,2),(1,3)]),graph(4,[(2,3),(3,4)])]
        while len(raws)<17:
            n=rng.randrange(3,9);raw=graph(n,[edge for edge in combinations(range(1,n+1),2) if rng.randrange(2)])
            if raw not in raws:raws.append(raw)
        raws.append(graph(8,list(combinations(range(1,9),2))))
    elif i==55:raws=[line([n,m]) for n,m in ((1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(2,7),(2,8),(10,1),(10,20),(10,21),(10,22),(10,23),(10,24),(10**12,1),(1,10**12),(10**12-1,10**12),(10**12,10**12))]
    elif i==56:raws=[f'{n}\n' for n in (1,2,3,4,5,6,7,9,10,11,15,16,21,22,9999,10**8,10**9-1,10**9)]
    elif i==57:raws=[f'{n}\n' for n in (1,2,3,4,9,10,99,100,101,999,1000,9999,10000,99991,9999999967,9999800001,10**10-1,10**10)]
    elif i==58:
        def documents(strings:list[str])->str:return f'{len(strings)}\n'+'\n'.join(strings)+'\n'
        raws=[documents(['a']),documents(['a','b']),documents(['aa','a']),documents(['abc','cba']),documents(['z'*50])]+[documents([''.join(rng.choice('abcdef') for _ in range(j+1)) for _ in range(j%5+1)]) for j in range(2,14)];raws.append(documents(['z'*50]*50))
    elif i==59:
        raws=[array([0,0]),array([1,-1]),array([-1,1]),array([10**9]*2),array([-10**9]*2)]+[array([rng.randrange(-3,4) for _ in range(n)]) for n in range(3,15)];raws.append(array([10**9]*100000))
    elif i==60:
        def shower(a:list[int],t:int)->str:return f'{len(a)} {t}\n'+line(a)
        raws=[shower([0],1),shower([0],10**9),shower([0,1],1),shower([0,1],2),shower([0,3],2)]+[shower([0]+sorted(rng.sample(range(1,1000),n-1)),rng.randrange(1,100)) for n in range(3,15)];raws.append(shower([0]+list(range(999800002,1000000001)),10**9))
    else:
        def big(pairs:list[Pair],k:int)->str:return f'{len(pairs)} {k}\n'+''.join(f'{a} {b}\n' for a,b in pairs)
        raws=[big([(1,1)],1),big([(100000,100000)],100000),big([(1,2),(1,3)],5),big([(2,1),(1,1)],1)]+[big([(rng.randrange(1,100001),rng.randrange(1,10)) for _ in range(n)],1+n%3) for n in range(3,16)];raws.append(big([(100000,100000)]*100000,10**10))
    require(len(raws)==len(set(raws))==CASE_COUNTS[pid],'distinct count')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==len(raws)-1 else 'finite_domain' if CASE_COUNTS[pid]<18 else 'edge_or_seeded'} for j,raw in enumerate(raws)]

TITLES={'abc029_c': 'Brute-force Attack', 'abc039_c': 'ピアニスト高橋君', 'arc062_a': 'AtCoDeerくんと選挙速報', 'arc063_a': '一次元リバーシ', 'arc064_a': 'Boxes and Candies', 'arc065_a': '白昼夢', 'arc066_a': 'Lining Up', 'abc051_c': 'Back and Forth', 'arc067_a': 'Factors of Factorial', 'arc068_a': 'X: Yet Another Die Game', 'abc054_c': 'One-stroke Path', 'arc069_a': 'Scc Puzzle', 'arc070_a': 'Go Home', 'abc057_c': 'Digits in Multiplication', 'arc071_a': '怪文書', 'arc072_a': 'Sequence', 'arc073_a': 'Sentou', 'abc061_c': 'Big Array'}
PUBLISHED_SAMPLES:dict[str,list[Case]]={'abc029_c': [{'input': '1\n', 'expected': 'a\nb\nc\n'}, {'input': '2\n', 'expected': 'aa\nab\nac\nba\nbb\nbc\nca\ncb\ncc\n'}], 'abc039_c': [{'input': 'WBWBWWBWBWBWWBWBWWBW\n', 'expected': 'Do\n'}], 'arc062_a': [{'input': '3\n2 3\n1 1\n3 2\n', 'expected': '10\n'}, {'input': '4\n1 1\n1 1\n1 5\n1 100\n', 'expected': '101\n'}, {'input': '5\n3 10\n48 17\n31 199\n231 23\n3 2\n', 'expected': '6930\n'}], 'arc063_a': [{'input': 'BBBWW\n', 'expected': '1\n'}, {'input': 'WWWWWW\n', 'expected': '0\n'}, {'input': 'WBWBWBWBWB\n', 'expected': '9\n'}], 'arc064_a': [{'input': '3 3\n2 2 2\n', 'expected': '1\n'}, {'input': '6 1\n1 6 1 2 0 4\n', 'expected': '11\n'}, {'input': '5 9\n3 1 4 1 5\n', 'expected': '0\n'}, {'input': '2 0\n5 5\n', 'expected': '10\n'}], 'arc065_a': [{'input': 'erasedream\n', 'expected': 'YES\n'}, {'input': 'dreameraser\n', 'expected': 'YES\n'}, {'input': 'dreamerer\n', 'expected': 'NO\n'}], 'arc066_a': [{'input': '5\n2 4 4 0 2\n', 'expected': '4\n'}, {'input': '7\n6 4 0 2 4 0 2\n', 'expected': '0\n'}, {'input': '8\n7 5 1 1 7 3 5 3\n', 'expected': '16\n'}], 'abc051_c': [{'input': '0 0 1 2\n', 'expected': 'UURDDLLUUURRDRDDDLLU\n'}, {'input': '-2 -2 1 1\n', 'expected': 'UURRURRDDDLLDLLULUUURRURRDDDLLDL\n'}], 'arc067_a': [{'input': '3\n', 'expected': '4\n'}, {'input': '6\n', 'expected': '30\n'}, {'input': '1000\n', 'expected': '972926972\n'}], 'arc068_a': [{'input': '7\n', 'expected': '2\n'}, {'input': '149696127901\n', 'expected': '27217477801\n'}], 'abc054_c': [{'input': '3 3\n1 2\n1 3\n2 3\n', 'expected': '2\n'}, {'input': '7 7\n1 3\n2 7\n3 4\n4 5\n4 6\n5 6\n6 7\n', 'expected': '1\n'}], 'arc069_a': [{'input': '1 6\n', 'expected': '2\n'}, {'input': '12345 678901\n', 'expected': '175897\n'}], 'arc070_a': [{'input': '6\n', 'expected': '3\n'}, {'input': '2\n', 'expected': '2\n'}, {'input': '11\n', 'expected': '5\n'}], 'abc057_c': [{'input': '10000\n', 'expected': '3\n'}, {'input': '1000003\n', 'expected': '7\n'}, {'input': '9876543210\n', 'expected': '6\n'}], 'arc071_a': [{'input': '3\ncbaa\ndaacc\nacacac\n', 'expected': 'aac\n'}, {'input': '3\na\naa\nb\n', 'expected': '\n'}], 'arc072_a': [{'input': '4\n1 -3 1 0\n', 'expected': '4\n'}, {'input': '5\n3 -6 4 -5 7\n', 'expected': '0\n'}, {'input': '6\n-1 4 3 2 -5 4\n', 'expected': '8\n'}], 'arc073_a': [{'input': '2 4\n0 3\n', 'expected': '7\n'}, {'input': '2 4\n0 5\n', 'expected': '8\n'}, {'input': '4 1000000000\n0 1000 1000000 1000000000\n', 'expected': '2000000000\n'}, {'input': '1 1\n0\n', 'expected': '1\n'}, {'input': '9 10\n0 3 5 7 100 110 200 300 311\n', 'expected': '67\n'}], 'abc061_c': [{'input': '3 4\n1 1\n2 2\n3 3\n', 'expected': '3\n'}, {'input': '10 500000\n1 100000\n1 100000\n1 100000\n1 100000\n1 100000\n100000 100000\n100000 100000\n100000 100000\n100000 100000\n100000 100000\n', 'expected': '1\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
