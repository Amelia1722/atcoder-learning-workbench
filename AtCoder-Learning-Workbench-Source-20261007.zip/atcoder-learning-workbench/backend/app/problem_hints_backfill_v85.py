"""Evidence-bound hint backfill for ready IDs ABC015 B / ABC016 B / ABC017 B."""
HINTS_BACKFILL_V85={
'abc015_2':(
 '平均の母数には、バグ数が0のソフトを含めません。まず0より大きい値だけ数えます。',
 '正のバグ数の合計を正の要素数で割り、切り上げます。整数だけなら (合計+個数-1)//個数 で計算できます。',
 '疑似コード:\npositive = [x for x in A if x > 0]\ntotal = sum(positive)\ncnt = len(positive)\nprint((total + cnt - 1) // cnt)'),
'abc016_2':(
 'CがA+Bと一致するか、A-Bと一致するかを別々の真偽値で調べます。',
 '両方一致なら?、和だけなら+、差だけなら-、どちらも不一致なら!です。',
 '疑似コード:\nplus = (A + B == C)\nminus = (A - B == C)\nif plus and minus: print("?")\nelif plus: print("+")\nelif minus: print("-")\nelse: print("!")'),
'abc017_2':(
 '使える部品は "ch", "o", "k", "u" だけです。左から順にこれらへ分解できるかを確認します。',
 '現在位置が"ch"なら2文字進め、それ以外はo/k/uのどれかなら1文字進めます。どれにも当てはまらなければNOです。',
 '疑似コード:\ni = 0\nwhile i < len(X):\n  if X[i:i+2] == "ch": i += 2\n  elif X[i] in "oku": i += 1\n  else: print("NO"); stop\nprint("YES")')
}
