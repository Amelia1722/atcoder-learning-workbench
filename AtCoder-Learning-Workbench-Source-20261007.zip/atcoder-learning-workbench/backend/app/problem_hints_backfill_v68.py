"""Evidence-bound backfill for ABC038–040 B; public statement checked."""
HINTS_BACKFILL_V68 = {
    'abc038_b': (
        '各ディスプレイは90度回転できるので、高さとして選べる長さをそれぞれ整理してください。',
        '1台目の高さ候補はH1,W1、2台目はH2,W2です。この二つの集合に共通する長さがあればYESです。',
        '''疑似コード:
if H1==H2 or H1==W2 or W1==H2 or W1==W2: print("YES")
else: print("NO")''',
    ),
    'abc039_b': (
        'Xは必ずある正整数の4乗です。制約から元の整数が取り得る範囲を見積もってください。',
        '1から増やしながらn^4とXを比較しても十分小さい範囲です。整数演算だけで一致するnを探せます。',
        '''疑似コード:
for n=1..:
  if n**4==X: print(n); stop''',
    ),
    'abc040_b': (
        '長方形の縦と横を決めると、使うタイル数と余りが決まります。縦横の候補数を制約から見積もってください。',
        '縦h、横wでh*w<=Nとなる組を調べ、abs(h-w)+(N-h*w)の最小値を更新します。平方根付近まで整理して探索できます。',
        '''疑似コード:
ans=INF
for h=1..floor(sqrt(N)):
  w=N//h
  ans=min(ans, abs(h-w)+N-h*w)
print(ans)''',
    ),
}
