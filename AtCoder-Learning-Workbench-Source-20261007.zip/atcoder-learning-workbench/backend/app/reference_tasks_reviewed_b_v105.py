"""ABC173–175 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re
from collections import Counter

TASKS = ('abc173_b', 'abc174_b', 'abc175_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'0|[1-9][0-9]*', re.ASCII)
INT = re.compile(r'0|-?[1-9][0-9]*', re.ASCII)
VERDICTS = ('AC', 'WA', 'TLE', 'RE')

PUBLISHED_SAMPLES = {
    'abc173_b': [
        {'input':'6\nAC\nTLE\nAC\nAC\nWA\nTLE\n','expected':'AC x 3\nWA x 1\nTLE x 2\nRE x 0\n'},
        {'input':'10\nAC\nAC\nAC\nAC\nAC\nAC\nAC\nAC\nAC\nAC\n','expected':'AC x 10\nWA x 0\nTLE x 0\nRE x 0\n'},
    ],
    'abc174_b': [
        {'input':'4 5\n0 5\n-2 4\n3 4\n4 -4\n','expected':'3\n'},
        {'input':'12 3\n1 1\n1 1\n1 1\n1 1\n1 2\n1 3\n2 1\n2 2\n2 3\n3 1\n3 2\n3 3\n','expected':'7\n'},
        {'input':'20 100000\n14309 -32939\n-56855 100340\n151364 25430\n103789 -113141\n147404 -136977\n-37006 -30929\n188810 -49557\n13419 70401\n-88280 165170\n-196399 137941\n-176527 -61904\n46659 115261\n-153551 114185\n98784 -6820\n94111 -86268\n-30401 61477\n-55056 7872\n5901 -163796\n138819 -185986\n-69848 -96669\n','expected':'6\n'},
    ],
    'abc175_b': [
        {'input':'5\n4 4 9 7 5\n','expected':'5\n'},
        {'input':'6\n4 5 4 3 3 5\n','expected':'8\n'},
        {'input':'10\n9 4 6 1 9 6 10 6 6 8\n','expected':'39\n'},
        {'input':'2\n1 1\n','expected':'0\n'},
    ],
}


def _pos(token: str) -> int:
    if POS.fullmatch(token) is None:
        raise ValueError('noncanonical positive integer')
    return int(token)


def _nonneg(token: str) -> int:
    if NONNEG.fullmatch(token) is None:
        raise ValueError('noncanonical nonnegative integer')
    return int(token)


def _integer(token: str) -> int:
    if INT.fullmatch(token) is None:
        raise ValueError('noncanonical integer')
    return int(token)


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines = raw[:-1].split('\n')
    if pid == 'abc173_b':
        if not lines:
            raise ValueError('missing input')
        n = _pos(lines[0])
        if not 1 <= n <= 100_000 or len(lines) != n + 1:
            raise ValueError('N/row count')
        verdicts = lines[1:]
        if any(s not in VERDICTS for s in verdicts):
            raise ValueError('invalid verdict')
        return n, verdicts
    if pid == 'abc174_b':
        if len(lines) < 2:
            raise ValueError('missing points')
        head = lines[0].split(' ')
        if len(head) != 2:
            raise ValueError('head shape')
        n, d = _pos(head[0]), _nonneg(head[1])
        if not (1 <= n <= 200_000 and 0 <= d <= 200_000) or len(lines) != n + 1:
            raise ValueError('N/D/row count')
        points=[]
        for line in lines[1:]:
            parts=line.split(' ')
            if len(parts)!=2:
                raise ValueError('point shape')
            x,y=_integer(parts[0]),_integer(parts[1])
            if not (-200_000 <= x <= 200_000 and -200_000 <= y <= 200_000):
                raise ValueError('coordinate range')
            points.append((x,y))
        return n,d,points
    if len(lines) != 2:
        raise ValueError('expected two rows')
    n = _pos(lines[0])
    if not 1 <= n <= 100:
        raise ValueError('N range')
    parts = lines[1].split(' ')
    if len(parts) != n:
        raise ValueError('length count')
    lengths = [_pos(x) for x in parts]
    if any(x > 10**9 for x in lengths):
        raise ValueError('length range')
    return n,lengths


def _answer_173(verdicts: list[str]) -> str:
    c=Counter(verdicts)
    return '\n'.join(f'{v} x {c[v]}' for v in VERDICTS)


def _answer_174(d: int, points: list[tuple[int,int]]) -> int:
    dd=d*d
    return sum(x*x+y*y <= dd for x,y in points)


def _answer_175(lengths: list[int]) -> int:
    n=len(lengths); ans=0
    for i in range(n):
        for j in range(i+1,n):
            for k in range(j+1,n):
                a,b,c=lengths[i],lengths[j],lengths[k]
                if len({a,b,c}) < 3:
                    continue
                x,y,z=sorted((a,b,c))
                if x+y>z:
                    ans+=1
    return ans


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value=validate(pid,raw)
    except (ValueError,TypeError,IndexError):
        return False
    if not isinstance(output,str) or not output or output != output.strip():
        return False
    if pid=='abc173_b':
        _, verdicts=value
        return output == _answer_173(verdicts)
    if re.fullmatch(r'0|[1-9][0-9]*',output,re.ASCII) is None:
        return False
    if pid=='abc174_b':
        _,d,points=value
        return output == str(_answer_174(d,points))
    _,lengths=value
    return output == str(_answer_175(lengths))


def _173(vals:list[str])->str:
    return str(len(vals))+'\n'+'\n'.join(vals)+'\n'

def _174(d:int, points:list[tuple[int,int]])->str:
    return f'{len(points)} {d}\n'+'\n'.join(f'{x} {y}' for x,y in points)+'\n'

def _175(vals:list[int])->str:
    return str(len(vals))+'\n'+' '.join(map(str,vals))+'\n'


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category:str, raw:str):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc173_b':
        cases=[
            ('sample1',['AC','TLE','AC','AC','WA','TLE']),
            ('sample2',['AC']*10),
            ('single_ac',['AC']),('single_wa',['WA']),('single_tle',['TLE']),('single_re',['RE']),
            ('one_each',['AC','WA','TLE','RE']),
            ('balanced8',['AC','WA','TLE','RE']*2),
            ('no_ac',['WA','TLE','RE','WA','RE']),
            ('no_re',['AC','WA','TLE','AC','WA']),
            ('mostly_wa',['WA']*20+['AC']),
            ('alternating',['AC','RE']*25),
            ('n99_pattern',[VERDICTS[i%4] for i in range(99)]),
            ('n1000_all_re',['RE']*1000),
            ('n9999_pattern',[VERDICTS[(i*3)%4] for i in range(9999)]),
            ('n50000_half',['AC']*25000+['WA']*25000),
            ('n99999_cycle',[VERDICTS[i%4] for i in range(99999)]),
        ]
        for cat,vals in cases: add(cat,_173(vals))
        add('constraint_max',_173(['AC','WA','TLE','RE']*25000))
    elif pid=='abc174_b':
        s3=[(14309,-32939),(-56855,100340),(151364,25430),(103789,-113141),(147404,-136977),(-37006,-30929),(188810,-49557),(13419,70401),(-88280,165170),(-196399,137941),(-176527,-61904),(46659,115261),(-153551,114185),(98784,-6820),(94111,-86268),(-30401,61477),(-55056,7872),(5901,-163796),(138819,-185986),(-69848,-96669)]
        cases=[
            ('sample1',5,[(0,5),(-2,4),(3,4),(4,-4)]),
            ('sample2',3,[(1,1)]*4+[(1,2),(1,3),(2,1),(2,2),(2,3),(3,1),(3,2),(3,3)]),
            ('sample3',100000,s3),
            ('origin_d0',0,[(0,0)]),('d0_nonorigin',0,[(1,0),(0,-1)]),
            ('boundary_axis',5,[(5,0),(-5,0),(0,5),(0,-5),(6,0)]),
            ('pythagorean',5,[(3,4),(4,3),(-3,4),(3,-4),(4,4)]),
            ('all_inside',10,[(0,0),(1,1),(6,8),(-6,-8)]),
            ('all_outside',1,[(2,0),(0,-2),(2,2)]),
            ('duplicate_points',2,[(1,1)]*20),
            ('large_coord_small_d',1,[(200000,200000),(-200000,0),(0,0)]),
            ('large_d_boundary',200000,[(200000,0),(0,-200000),(199999,1),(-200000,-1)]),
            ('n100_pattern',100,[(i-50,(i*7)%101-50) for i in range(100)]),
            ('n1000_origin',0,[(0,0)]*1000),
            ('n10000_mix',1000,[(0,0)]*5000+[(2000,0)]*5000),
            ('n50000_boundary',200000,[(200000,0)]*25000+[(200000,1)]*25000),
            ('n199999_zero',0,[(0,0)]*199999),
        ]
        for cat,d,pts in cases: add(cat,_174(d,pts))
        add('constraint_max',_174(200000,[(200000,0)]*100000+[(200000,1)]*100000))
    else:
        cases=[
            ('sample1',[4,4,9,7,5]),('sample2',[4,5,4,3,3,5]),
            ('sample3',[9,4,6,1,9,6,10,6,6,8]),('sample4',[1,1]),
            ('n1',[1]),('three_triangle',[3,4,5]),('three_not_triangle',[1,2,3]),
            ('three_equal',[5,5,5]),('two_equal',[3,3,4]),
            ('all_distinct_many',[2,3,4,5,6]),('powers_of_two',[1,2,4,8,16,32]),
            ('duplicates_multiply',[3,3,4,4,5,5]),
            ('strict_boundary',[2,3,5,4]),
            ('large_values',[10**9,10**9-1,10**9-2,1]),
            ('n30_cycle',[3+(i%7) for i in range(30)]),
            ('n50_unique',list(range(1,51))),
            ('n99_mixed',[1+(i*37)%1000 for i in range(99)]),
        ]
        for cat,vals in cases: add(cat,_175(vals))
        add('constraint_max',_175(list(range(999_999_901,1_000_000_001))))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
