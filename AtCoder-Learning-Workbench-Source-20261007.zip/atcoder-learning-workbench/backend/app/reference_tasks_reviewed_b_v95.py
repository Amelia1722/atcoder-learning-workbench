"""ABC143–145 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re

TASKS = ('abc143_b', 'abc144_b', 'abc145_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)
LOWER = re.compile(r'[a-z]+', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc143_b': [
        {'input':'3\n3 1 2\n','expected':'11\n'},
        {'input':'7\n5 0 7 8 3 3 2\n','expected':'312\n'},
    ],
    'abc144_b': [
        {'input':'10\n','expected':'Yes\n'},
        {'input':'50\n','expected':'No\n'},
        {'input':'81\n','expected':'Yes\n'},
    ],
    'abc145_b': [
        {'input':'6\nabcabc\n','expected':'Yes\n'},
        {'input':'6\nabcadc\n','expected':'No\n'},
        {'input':'1\nz\n','expected':'No\n'},
    ],
}


def _ints(line: str, count: int, pattern=POS) -> list[int]:
    parts=line.split(' ')
    if len(parts)!=count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int,parts))


def validate(pid: str, raw: str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc143_b':
        if len(lines)!=2 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected two rows')
        n=int(lines[0])
        if not 2<=n<=50: raise ValueError('N range')
        d=_ints(lines[1],n,NONNEG)
        if any(not 0<=x<=100 for x in d): raise ValueError('d range')
        return n,d
    if pid=='abc144_b':
        if len(lines)!=1 or POS.fullmatch(lines[0]) is None:
            raise ValueError('expected one canonical integer')
        n=int(lines[0])
        if not 1<=n<=100: raise ValueError('N range')
        return n
    if len(lines)!=2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('expected N and S rows')
    n=int(lines[0]); s=lines[1]
    if not 1<=n<=100 or len(s)!=n or LOWER.fullmatch(s) is None:
        raise ValueError('N/S shape or range')
    return n,s


def independent_check(pid: str, raw: str, output: str) -> bool:
    try: value=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or output!=output.strip() or not output: return False
    if pid=='abc143_b':
        if NONNEG.fullmatch(output) is None: return False
        _,d=value
        ans=sum(d[i]*d[j] for i in range(len(d)) for j in range(i+1,len(d)))
        return output==str(ans)
    if pid=='abc144_b':
        n=value
        ok=any(i*j==n for i in range(1,10) for j in range(1,10))
        return output==('Yes' if ok else 'No')
    n,s=value
    ok=n%2==0 and s[:n//2]==s[n//2:]
    return output==('Yes' if ok else 'No')


def _abc143(d):
    return f"{len(d)}\n"+' '.join(map(str,d))+'\n'

def _abc145(s):
    return f"{len(s)}\n{s}\n"


def generate(pid: str) -> list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    result=[]; seen=set()
    def add(category,raw):
        validate(pid,raw)
        if raw not in seen:
            seen.add(raw); result.append({'category':category,'input':raw})
    if pid=='abc143_b':
        vals=[
          ('sample1',[3,1,2]),('sample2',[5,0,7,8,3,3,2]),
          ('minimum_zero',[0,0]),('minimum_max',[100,100]),('minimum_mixed',[0,100]),
          ('three_ones',[1,1,1]),('zeros_and_max',[0,100,0,100]),('ascending5',[0,1,2,3,4]),
          ('descending5',[100,75,50,25,0]),('equal10',[10]*10),
          ('mixed10',[1,100,50,0,99,2,98,3,97,4]),('alternating20',[0,100]*10),
          ('ascending25',list(range(25))),('n49_ones',[1]*49),('n50_zeros',[0]*50),
          ('n50_sequence',list(range(50))),('n49_max',[100]*49),
        ]
        for cat,d in vals: add(cat,_abc143(d))
        add('constraint_max',_abc143([100]*50))
    elif pid=='abc144_b':
        vals=[('sample1',10),('sample2',50),('sample3',81),
              ('one',1),('two',2),('seven',7),('nine',9),('sixteen',16),('twentyfive',25),
              ('thirtysix',36),('fortynine',49),('sixtythree',63),('sixtyfour',64),
              ('seventytwo',72),('eighty',80),('eightytwo',82),('ninetynine',99)]
        for cat,n in vals: add(cat,f'{n}\n')
        add('constraint_max','100\n')
    else:
        vals=[
          ('sample1','abcabc'),('sample2','abcadc'),('sample3','z'),
          ('minimum_yes','aa'),('minimum_no','ab'),('odd_three','aaa'),('even_repeat','abab'),
          ('all_same_even','aaaa'),('even_not_repeat','abba'),('odd_five','abcab'),
          ('repeat4','abcdabcd'),('near_repeat4','abcdaabc'),('repeat5','abcdeabcde'),
          ('near_repeat5','abcdeabcdf'),('n98_repeat','a'*98),('n98_near','a'*97+'b'),
          ('n99_odd','a'*99),
        ]
        for cat,s in vals: add(cat,_abc145(s))
        add('constraint_max',_abc145('z'*100))
    if len(result)!=18 or len(seen)!=18 or result[-1]['category']!='constraint_max':
        raise ValueError(f'{pid}: expected 18 distinct cases ending with constraint_max, got {len(result)}')
    return result
