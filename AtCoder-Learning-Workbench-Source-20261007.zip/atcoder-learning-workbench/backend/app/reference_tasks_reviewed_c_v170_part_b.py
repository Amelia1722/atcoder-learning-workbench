"""Combinatorial unranking, banded edit distance and row-run connectivity."""
from __future__ import annotations
from collections import Counter
from math import comb
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(321,327))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Data=tuple[object,...]
Case=dict[str,str]
Grid=tuple[str,...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==321:
        require(len(rows)==1,'shape');k=ints(rows[0],1)[0];require(1<=k<=1022,'finite decreasing digits');return (k,)
    if number==322:
        require(len(rows)==2,'shape');n,m=ints(rows[0],2);a=ints(rows[1],m);require(1<=m<=n<=200000 and a[-1]==n and all(1<=v<=n for v in a) and all(x<y for x,y in zip(a,a[1:])),'fireworks');return n,a
    if number==323:
        n,m=ints(rows[0],2);require(2<=n<=100 and 1<=m<=100 and len(rows)==n+2,'shape');a=ints(rows[1],m);strings=tuple(rows[2:]);require(all(500<=v<=2500 and v%100==0 for v in a) and all(len(s)==m and set(s)<={'o','x'} and 'x' in s for s in strings),'contest');return a,strings
    if number==324:
        header=rows[0].split(' ');require(len(header)==2,'header');n=ints(header[0],1)[0];t=header[1];strings=tuple(rows[1:]);require(1<=n<=500000 and len(strings)==n and all(re.fullmatch('[a-z]+',s) is not None for s in (t,*strings)) and len(t)<=500000 and sum(map(len,strings))<=500000,'strings');return t,strings
    if number==325:
        h,w=ints(rows[0],2);require(1<=h<=1000 and 1<=w<=1000 and len(rows)==h+1 and all(len(s)==w and set(s)<={'#','.'} for s in rows[1:]),'grid');return (tuple(rows[1:]),)
    require(len(rows)==2,'shape');n,m=ints(rows[0],2);require(1<=n<=300000 and 1<=m<=10**9,'bounds');a=ints(rows[1],n);require(all(0<=v<=10**9 for v in a),'coordinates');return m,a

def _decreasing_rank(k:int)->int:
    if k<=9:return k
    k-=9;length=2
    while k>comb(10,length):k-=comb(10,length);length+=1
    rank=k-1;upper=10;value=0
    for remaining in range(length-1,-1,-1):
        for digit in range(remaining,upper):
            count=comb(digit,remaining)
            if rank>=count:rank-=count;continue
            value=value*10+digit;upper=digit;break
    return value

def _one_edit(source:str,target:str)->bool:
    if abs(len(source)-len(target))>1:return False
    previous={j:j for j in range(min(len(target),1)+1)}
    for i,ch in enumerate(source,1):
        current:dict[int,int]={}
        for j in range(max(0,i-1),min(len(target),i+1)+1):
            cost=min(previous.get(j,2)+1,current.get(j-1,2)+1,previous.get(j-1,2)+(ch!=target[j-1]) if j else 2)
            if cost<=1:current[j]=cost
        if not current:return False
        previous=current
    return previous.get(len(target),2)<=1

def _run_components(grid:Grid)->int:
    parent:list[int]=[];size:list[int]=[];previous:list[tuple[int,int,int]]=[];answer=0
    def root(v:int)->int:
        while parent[v]!=v:parent[v]=parent[parent[v]];v=parent[v]
        return v
    for row in grid:
        current=[]
        for match in re.finditer('#+',row):
            identifier=len(parent);parent.append(identifier);size.append(1);answer+=1;current.append((match.start(),match.end()-1,identifier))
        start=0
        for low,high,identifier in current:
            while start<len(previous) and previous[start][1]<low-1:start+=1
            j=start
            while j<len(previous) and previous[j][0]<=high+1:
                a,b=root(identifier),root(previous[j][2])
                if a!=b:
                    if size[a]<size[b]:a,b=b,a
                    parent[b]=a;size[a]+=size[b];answer-=1
                j+=1
        previous=current
    return answer

def _window_sweep(m:int,a:tuple[int,...])->int:
    events:Counter[int]=Counter()
    for v in a:events[v-m+1]+=1;events[v+1]-=1
    active=answer=0
    for _,delta in sorted(events.items()):active+=delta;answer=max(answer,active)
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==321:return str(_decreasing_rank(cast(int,data[0])))
    if number==322:
        n,a=cast(tuple[int,tuple[int,...]],data);out=[];last=0
        for day in a:out.extend(map(str,range(day-last-1,-1,-1)));last=day
        return '\n'.join(out)
    if number==323:
        a,strings=cast(tuple[tuple[int,...],tuple[str,...]],data);scores=[i+sum(v for v,ch in zip(a,s) if ch=='o') for i,s in enumerate(strings,1)];out=[]
        for i,s in enumerate(strings):
            target=max(v for j,v in enumerate(scores) if i!=j)-scores[i];best=[0]
            for value,ch in zip(a,s):
                if ch!='x':continue
                best.append(-10**9)
                for count in range(len(best)-1,0,-1):best[count]=max(best[count],best[count-1]+value)
            out.append(str(next(count for count,gain in enumerate(best) if gain>target)))
        return '\n'.join(out)
    if number==324:
        t,strings=cast(tuple[str,tuple[str,...]],data);chosen=[str(i) for i,s in enumerate(strings,1) if _one_edit(s,t)]
        return str(len(chosen))+('\n'+' '.join(chosen) if chosen else '')
    if number==325:return str(_run_components(cast(Grid,data[0])))
    return str(_window_sweep(*cast(tuple[int,tuple[int,...]],data)))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc321_c':"k=int(input());values=[]\nfor mask in range(1,1024):\n value=int(''.join(str(d) for d in range(9,-1,-1) if mask>>d&1))\n if value:values.append(value)\nprint(sorted(values)[k-1])\n",
'abc322_c':"from bisect import bisect_left\nn,m=map(int,input().split());a=list(map(int,input().split()));print(*(a[bisect_left(a,d)]-d for d in range(1,n+1)),sep='\\n')\n",
'abc323_c':"n,m=map(int,input().split());a=list(map(int,input().split()));s=[input() for _ in range(n)];scores=[i+sum(v for v,ch in zip(a,row) if ch=='o') for i,row in enumerate(s,1)]\nfor i,row in enumerate(s):\n goal=max(v for j,v in enumerate(scores) if j!=i);current=scores[i];answer=0\n for value in sorted((v for v,ch in zip(a,row) if ch=='x'),reverse=True):\n  if current>goal:break\n  current+=value;answer+=1\n print(answer)\n",
'abc324_c':"n,t=input().split();answer=[]\nfor i in range(1,int(n)+1):\n s=input()\n if abs(len(s)-len(t))>1:continue\n if len(s)==len(t):ok=sum(x!=y for x,y in zip(s,t))<=1\n else:\n  short,long=(s,t) if len(s)<len(t) else (t,s);j=0\n  while j<len(short) and short[j]==long[j]:j+=1\n  ok=short[j:]==long[j+1:]\n if ok:answer.append(i)\nprint(len(answer))\nif answer:print(*answer)\n",
'abc325_c':"h,w=map(int,input().split());s=[input() for _ in range(h)];seen=[bytearray(w) for _ in range(h)];answer=0\nfor r in range(h):\n for c in range(w):\n  if s[r][c]!='#' or seen[r][c]:continue\n  answer+=1;seen[r][c]=1;todo=[(r,c)]\n  while todo:\n   x,y=todo.pop()\n   for dr in (-1,0,1):\n    for dc in (-1,0,1):\n     u,v=x+dr,y+dc\n     if 0<=u<h and 0<=v<w and s[u][v]=='#' and not seen[u][v]:seen[u][v]=1;todo.append((u,v))\nprint(answer)\n",
'abc326_c':"n,m=map(int,input().split());a=sorted(map(int,input().split()));j=answer=0\nfor i in range(n):\n while j<n and a[j]-a[i]<m:j+=1\n answer=max(answer,j-i)\nprint(answer)\n"}

def line(values:list[int]|tuple[int,...])->str:return ' '.join(map(str,values))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17000+number)
    if number==321:raws=[f'{k}\n' for k in (1,2,9,10,11,15,30,45,100,255,321,511,512,777,1000,1020,1021,1022)]
    elif number==322:
        def fireworks(n:int,a:list[int])->str:return f'{n} {len(a)}\n'+line(a)
        raws=[fireworks(1,[1]),fireworks(2,[2]),fireworks(2,[1,2]),fireworks(3,[1,3])]
        for n in range(4,16):raws.append(fireworks(n,[i for i in range(1,n) if rng.random()<.4]+[n]))
        raws.extend([fireworks(200000,[200000]),fireworks(200000,list(range(1,200001)))])
    elif number==323:
        def contest(a:list[int],s:list[str])->str:return f'{len(s)} {len(a)}\n'+line(a)+'\n'.join(s)+'\n'
        raws=[contest([500],['x','x']),contest([2500],['x','x']),contest([500,2500],['ox','xx']),contest([2500,500],['xo','ox'])]
        for n in range(3,15):
            a=[100*rng.randint(5,25) for _ in range(n)];s=[''.join(rng.choice('ox') for _ in range(n-1))+'x' for _ in range(n)];raws.append(contest(a,s))
        raws.extend([contest([500]*100,['o'*i+'x'*(100-i) for i in range(100)]),contest([2500]*100,['x'*100]*100)])
    elif number==324:
        def candidates(t:str,strings:list[str])->str:return f'{len(strings)} {t}\n'+'\n'.join(strings)+'\n'
        raws=[candidates('a',['a']),candidates('a',['b']),candidates('a',['aa']),candidates('a',['bc'])]
        for n in range(3,15):
            t=''.join(rng.choice('abc') for _ in range(n));raws.append(candidates(t,[t,t[1:],t+'z',t[:-1]+'z',t[::-1]]))
        raws.extend([candidates('a'*499999+'b',['a'*500000]),candidates('z'*500000,['a']*500000)])
    elif number==325:
        def grid(s:list[str])->str:return f'{len(s)} {len(s[0])}\n'+'\n'.join(s)+'\n'
        raws=[grid(['.']),grid(['#']),grid(['#.#']),grid(['#.','.#'])]
        for n in range(3,15):raws.append(grid([''.join(rng.choice('.#') for _ in range(n)) for _ in range(n)]))
        raws.extend([grid(['#.'*500 if i%2==0 else '.'*1000 for i in range(1000)]),grid(['#'*1000]*1000)])
    else:
        def gifts(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
        raws=[gifts(1,[0]),gifts(1,[0,1]),gifts(2,[0,1]),gifts(1,[1,1])]
        for n in range(3,15):raws.append(gifts(rng.randint(1,20),[rng.randint(0,50) for _ in range(n)]))
        raws.extend([gifts(1,list(range(300000))),gifts(10**9,[10**9]*300000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i<4 or i==16 else 'deterministic_random'} for i,raw in enumerate(raws)]

HINTS={
'abc321_c':('使う数字の集合を決めると、降順の並びが一意に決まります。','0〜9の非空部分集合から数を作ります。0だけの集合を除き、値をソートします。','疑似コード: mask=1..1023で選んだ数字を9から0の順に連結; 正数ならvaluesへ; sort(values); values[K-1]を出力。'),
'abc322_c':('各日について、その日以降の最初の花火の日を探します。','花火の日は昇順なのでlower_boundで求められます。最終日は必ず花火が上がります。','疑似コード: day=1..N; j=lower_bound(A,day); A[j]-dayを1行ずつ出力。'),
'abc323_c':('現在の得点と、他のプレイヤーの最大得点を求めます。','未解答問題を得点の高い順に解くと、最小の問題数で追い越せます。','疑似コード: score=bonus+解答済み得点合計; othermaxを求める; 未解答を降順に追加してscore>othermaxとなるまで数える; 数を出力。'),
'abc324_c':('長さの差が2以上なら候補にはなりません。','同じ長さなら不一致が1個以下かを確認します。1文字違いなら最初の不一致を長い側で飛ばします。','疑似コード: 各Sで長さ差を確認; 同長なら不一致数<=1; 差1なら共通prefix後の長い側1文字をskipしてsuffix一致を確認; 受理した添字を昇順出力。'),
'abc325_c':('上下左右と斜めに接続した#は同じグループです。','未訪問の#からDFSまたはBFSし、そのたびにグループ数を1増やします。','疑似コード: 各未訪問#でanswer++; stackへ入れvisited=true; 取り出したセルの8近傍の未訪問#を追加; answerを出力。'),
'abc326_c':('左端をプレゼントの座標に合わせて考えられます。','座標をソートし、右端との差がM未満である最大区間をtwo pointersで求めます。','疑似コード: sort(A); 各leftでA[right]-A[left]<Mの間rightを進める; answer=max(answer,right-left); answerを出力。')}

TITLES={'abc321_c': '321-like Searcher', 'abc322_c': 'Festival', 'abc323_c': 'World Tour Finals', 'abc324_c': 'Error Correction', 'abc325_c': 'Sensors', 'abc326_c': 'Peak'}
PUBLISHED_SAMPLES={'abc321_c': [{'input': '15\n', 'expected': '32\n'}, {'input': '321\n', 'expected': '9610\n'}, {'input': '777\n', 'expected': '983210\n'}], 'abc322_c': [{'input': '3 2\n2 3\n', 'expected': '1\n0\n0\n'}, {'input': '8 5\n1 3 4 7 8\n', 'expected': '0\n1\n0\n0\n2\n1\n0\n0\n'}], 'abc323_c': [{'input': '3 4\n1000 500 700 2000\nxxxo\nooxx\noxox\n', 'expected': '0\n1\n1\n'}, {'input': '5 5\n1000 1500 2000 2000 2500\nxxxxx\noxxxx\nxxxxx\noxxxx\noxxxx\n', 'expected': '1\n1\n1\n1\n0\n'}, {'input': '7 8\n500 500 500 500 500 500 500 500\nxxxxxxxx\noxxxxxxx\nooxxxxxx\noooxxxxx\nooooxxxx\noooooxxx\nooooooxx\n', 'expected': '7\n6\n5\n4\n3\n2\n0\n'}], 'abc324_c': [{'input': '5 ababc\nababc\nbabc\nabacbc\nabdbc\nabbac\n', 'expected': '4\n1 2 3 4\n'}, {'input': '1 aoki\ntakahashi\n', 'expected': '0\n'}, {'input': '9 atcoder\natoder\natcode\nathqcoder\natcoder\ntacoder\njttcoder\natoder\natceoder\natcoer\n', 'expected': '6\n1 2 4 7 8 9\n'}], 'abc325_c': [{'input': '5 6\n.##...\n...#..\n....##\n#.#...\n..#...\n', 'expected': '3\n'}, {'input': '3 3\n#.#\n.#.\n#.#\n', 'expected': '1\n'}, {'input': '4 2\n..\n..\n..\n..\n', 'expected': '0\n'}, {'input': '5 47\n.#..#..#####..#...#..#####..#...#...###...#####\n.#.#...#.......#.#...#......##..#..#...#..#....\n.##....#####....#....#####..#.#.#..#......#####\n.#.#...#........#....#......#..##..#...#..#....\n.#..#..#####....#....#####..#...#...###...#####\n', 'expected': '7\n'}], 'abc326_c': [{'input': '8 6\n2 3 5 7 11 13 17 19\n', 'expected': '4\n'}, {'input': '10 1\n3 1 4 1 5 9 2 6 5 3\n', 'expected': '2\n'}, {'input': '10 998244353\n100000007 0 1755647 998244353 495 1000000000 1755648 503 1755649 998244853\n', 'expected': '7\n'}]}
SAMPLE_COUNTS={pid:len(rows) for pid,rows in PUBLISHED_SAMPLES.items()}
