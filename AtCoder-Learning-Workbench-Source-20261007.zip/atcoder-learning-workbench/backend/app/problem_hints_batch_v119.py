"""Statement-checked three-stage hints for ABC215–217 B."""
HINTS_V119 = {
    'abc215_b': (
        '求めるのは `2^k <= N` を満たす最大のkです。Nを2倍していくのではなく、2の冪がNを超える直前を探します。',
        'k=0から始め、`2^(k+1) <= N` の間だけkを1増やせば、ループ終了時のkが答えです。Pythonなら整数のbit長を使う方法もあります。',
        '''疑似コード:
k = 0
while 2^(k+1) <= N:
  k += 1
print(k)''',
    ),
    'abc216_b': (
        '同姓同名とは、姓だけ・名だけではなく `(姓, 名)` の組が完全一致することです。',
        '各人を `(S_i, T_i)` という1つの組として扱い、同じ組が2回現れるかをsetで確認できます。',
        '''疑似コード:
seen = empty set
for each person:
  pair = (family_name, given_name)
  if pair is already in seen:
    print("Yes")
    stop
  add pair to seen
print("No")''',
    ),
    'abc217_b': (
        '候補は ABC, ARC, AGC, AHC の4種類に固定されています。入力された3種類以外を探します。',
        '4種類の集合から、入力された3種類の集合を引けば残りは1要素だけです。',
        '''疑似コード:
all = {ABC, ARC, AGC, AHC}
given = set of the 3 input strings
remaining = all - given
print(the only element in remaining)''',
    ),
}
