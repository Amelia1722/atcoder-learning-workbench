"""Hints re-reviewed against public official statements of ABC089–091 B."""
HINTS_V77 = {
    'abc089_b': (
        'P・W・Gは必ず登場します。3種類か4種類かを分けるのは、残り1色があるかどうかです。',
        '色Yが1つでも含まれていればFour、含まれていなければThreeです。setを作って種類数を数えても構いません。',
        '''疑似コード:\ncolors = read_colors()\nif "Y" in colors: print("Four")\nelse: print("Three")''',
    ),
    'abc090_b': (
        'AからBまでの候補数は最大9万個なので、1つずつ確認しても十分間に合います。',
        '各整数を文字列へ変換し、元の文字列と逆順文字列が等しければ回文数として数えます。',
        '''疑似コード:\nans = 0\nfor x = A .. B:\n  s = str(x)\n  if s == reverse(s): ans += 1\nprint(ans)''',
    ),
    'abc091_b': (
        '宣言する文字列を1つ決めたときの得点は、青での出現回数から赤での出現回数を引いた値です。',
        '文字列ごとの出現回数を数え、blue_count[s] - red_count[s] の最大値を求めます。何も得しない文字列も宣言できるので0未満にはなりません。',
        '''疑似コード:\nblue = Counter(blue_strings)\nred = Counter(red_strings)\nans = 0\nfor s in all_strings:\n  ans = max(ans, blue[s] - red[s])\nprint(ans)''',
    ),
}
