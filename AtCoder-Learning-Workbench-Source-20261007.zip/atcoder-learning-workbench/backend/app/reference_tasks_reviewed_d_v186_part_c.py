"""Private reviewed ABC144..149 D: numeric, semantic, and exact contracts."""
from __future__ import annotations
from bisect import bisect_right
from decimal import Decimal,localcontext
from functools import lru_cache
from typing import cast
import math,random,re
TASKS=tuple(f'abc{n}_d' for n in range(144,150))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES={'abc144_d':'numeric_tolerance_1e-6','abc146_d':'semantic'}
CHECKER_IDS={'abc146_d':'abc146_d'}
MOD=10**9+7
Case=dict[str,str]
Data=tuple[object,...]
Edge=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,n:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(n is None or len(a)==n,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
    if pid=='abc144_d':
        require(len(rows)==1,'shape');a,b,x=ints(rows[0],3);require(1<=a<=100 and 1<=b<=100 and 1<=x<=a*a*b,'range');return a,b,x
    if pid=='abc145_d':
        require(len(rows)==1,'shape');x,y=ints(rows[0],2);require(1<=x<=10**6 and 1<=y<=10**6,'range');return x,y
    if pid=='abc146_d':
        n=ints(rows[0],1)[0];require(2<=n<=100000 and len(rows)==n,'shape');edges=tuple(cast(Edge,ints(r,2)) for r in rows[1:]);parent=list(range(n))
        def root(x:int)->int:
            while x!=parent[x]:parent[x]=parent[parent[x]];x=parent[x]
            return x
        for u,v in edges:
            require(1<=u<v<=n,'edge');a,b=root(u-1),root(v-1);require(a!=b,'cycle');parent[a]=b
        return n,edges
    if pid in ('abc147_d','abc148_d'):
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n)
        if pid=='abc147_d':require(2<=n<=300000 and all(0<=v<2**60 for v in a),'range')
        else:require(1<=n<=200000 and all(1<=v<=n for v in a),'range')
        return (a,)
    require(len(rows)==3,'shape');n,k=ints(rows[0],2);r,s,p=ints(rows[1],3);t=rows[2];require(2<=n<=100000 and 1<=k<n and all(1<=v<=10000 for v in (r,s,p)) and len(t)==n and re.fullmatch('[rsp]+',t) is not None,'range');return k,r,s,p,t

def atan_series(z:Decimal)->Decimal:
    # Range reduction atan(z)=2 atan(z/(1+sqrt(1+z²))).
    scale=1
    while z>Decimal('0.08'):z=z/(1+(1+z*z).sqrt());scale*=2
    square=z*z;term=z;total=z;j=1
    while True:
        term=-term*square;addition=term/(2*j+1);total+=addition
        if abs(addition)<Decimal('1e-65'):break
        j+=1
    return total*scale
@lru_cache(maxsize=128)
def bottle_angle(a:int,b:int,x:int)->Decimal:
    with localcontext() as ctx:
        ctx.prec=70
        pi=16*atan_series(Decimal(1)/5)-4*atan_series(Decimal(1)/239)
        tangent=Decimal(a*b*b)/Decimal(2*x) if 2*x<=a*a*b else Decimal(2*(a*a*b-x))/Decimal(a*a*a)
        return +(atan_series(tangent)*180/pi)
def numeric_valid(target:Decimal,actual:str)->bool:
    token=actual.removesuffix('\n')
    if re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is None or len(token)>1000:return False
    try:
        with localcontext() as ctx:
            ctx.prec=90;value=Decimal(token);difference=abs(value-target);return value.is_finite() and (difference<=Decimal('0.000001') or difference<=abs(target)*Decimal('0.000001'))
    except ArithmeticError:return False

def knight_prime(x:int,y:int)->int:
    # Solve total moves first, then factor the binomial via prime valuations.
    if (x+y)%3:return 0
    n=(x+y)//3;k=x-n
    if not 0<=k<=n:return 0
    sieve=bytearray(b'\1')*(n+1);sieve[:2]=b'\0\0'
    for p in range(2,math.isqrt(n)+1):
        if sieve[p]:sieve[p*p:n+1:p]=b'\0'*((n-p*p)//p+1)
    answer=1
    for p in range(2,n+1):
        if not sieve[p]:continue
        exponent=0;q=p
        while q<=n:exponent+=n//q-k//q-(n-k)//q;q*=p
        answer=answer*pow(p,exponent,MOD)%MOD
    return answer

def edge_coloring(n:int,edges:tuple[Edge,...])->str:
    # Peel tree leaves, reverse insertion gives an independent construction.
    graph:list[list[tuple[int,int]]]=[[] for _ in range(n)];degree=[0]*n
    for j,(u,v) in enumerate(edges):u-=1;v-=1;graph[u].append((v,j));graph[v].append((u,j));degree[u]+=1;degree[v]+=1
    maximum=max(degree);queue=[u for u,d in enumerate(degree) if d==1];removed=[False]*n;order:list[tuple[int,int,int]]=[]
    for u in queue:
        if removed[u]:continue
        removed[u]=True
        for v,j in graph[u]:
            if not removed[v]:order.append((u,v,j));degree[v]-=1
            if degree[v]==1 and not removed[v]:queue.append(v)
    used:list[set[int]]=[set() for _ in range(n)];next_free=[1]*n;colors=[0]*len(edges)
    for u,v,j in reversed(order):
        color=next_free[v]
        while color in used[v]:color+=1
        colors[j]=color;used[u].add(color);used[v].add(color)
        while next_free[v] in used[v]:next_free[v]+=1
        while next_free[u] in used[u]:next_free[u]+=1
    return str(maximum)+'\n'+'\n'.join(map(str,colors))

def colors_valid(n:int,edges:tuple[Edge,...],actual:str)->bool:
    rows=actual.removesuffix('\n').split('\n')
    if len(rows)!=n or any(re.fullmatch('[1-9][0-9]*',r) is None for r in rows):return False
    degree=[0]*n;incident:list[set[int]]=[set() for _ in range(n)];k=int(rows[0])
    for (u,v),row in zip(edges,rows[1:]):
        color=int(row)
        if not 1<=color<=k or color in incident[u-1] or color in incident[v-1]:return False
        incident[u-1].add(color);incident[v-1].add(color);degree[u-1]+=1;degree[v-1]+=1
    return k==max(degree)

def xor_merge(a:tuple[int,...])->int:
    # Block-pair merge: count within blocks literally, then cross all preceding
    # blocks by one/zero populations. No global ones*(N-ones) reduction.
    prior=[0]*60;size=0;answer=0
    for start in range(0,len(a),64):
        block=a[start:start+64];ones=[0]*60
        for v in block:
            for bit in range(60):ones[bit]+=(v>>bit)&1
        answer+=sum(a^b for j,a in enumerate(block) for b in block[j+1:])
        answer+=sum((ones[bit]*(size-prior[bit])+(len(block)-ones[bit])*prior[bit])*(1<<bit) for bit in range(60))
        for bit in range(60):prior[bit]+=ones[bit]
        size+=len(block)
    return answer%MOD

def brick_positions(a:tuple[int,...])->int:
    positions:dict[int,list[int]]={}
    for j,v in enumerate(a):positions.setdefault(v,[]).append(j)
    last=-1;target=1
    while target in positions:
        indexes=positions[target];j=bisect_right(indexes,last)
        if j==len(indexes):break
        last=indexes[j];target+=1
    return len(a)-target+1 if target>1 else -1

def rps_runs(k:int,r:int,s:int,p:int,t:str)->int:
    score={'r':p,'s':r,'p':s};answer=0
    for residue in range(k):
        sequence=t[residue::k];start=0
        while start<len(sequence):
            end=start+1
            while end<len(sequence) and sequence[end]==sequence[start]:end+=1
            answer+=((end-start+1)//2)*score[sequence[start]];start=end
    return answer

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw)
    if pid=='abc144_d':return str(bottle_angle(*cast(tuple[int,int,int],data)))
    if pid=='abc145_d':return str(knight_prime(*cast(tuple[int,int],data)))
    if pid=='abc146_d':return edge_coloring(*cast(tuple[int,tuple[Edge,...]],data))
    if pid=='abc147_d':return str(xor_merge(cast(tuple[int,...],data[0])))
    if pid=='abc148_d':return str(brick_positions(cast(tuple[int,...],data[0])))
    return str(rps_runs(*cast(tuple[int,int,int,int,str],data)))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        data=validate(pid,raw)
        if pid=='abc144_d':return numeric_valid(bottle_angle(*cast(tuple[int,int,int],data)),actual)
        if pid=='abc146_d':return colors_valid(*cast(tuple[int,tuple[Edge,...]],data),actual)
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,TypeError,IndexError,OverflowError,ArithmeticError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc144_d':"import math\na,b,x=map(int,input().split());low=0.;high=math.pi/2\nfor _ in range(100):\n angle=(low+high)/2;t=math.tan(angle);volume=a*(a*b-a*a*t/2) if a*t<=b else a*b*b/(2*t)\n if volume>=x:low=angle\n else:high=angle\nprint(format(low*180/math.pi,'.15f'))\n",
'abc145_d':"MOD=10**9+7\nx,y=map(int,input().split());a=2*y-x;b=2*x-y\nif min(a,b)<0 or a%3 or b%3:print(0)\nelse:\n a//=3;b//=3;n=a+b;factorial=[1]*(n+1)\n for j in range(1,n+1):factorial[j]=factorial[j-1]*j%MOD\n print(factorial[n]*pow(factorial[a]*factorial[b]%MOD,MOD-2,MOD)%MOD)\n",
'abc146_d':"from collections import deque\nn=int(input());g=[[] for _ in range(n)]\nfor j in range(n-1):\n u,v=map(int,input().split());u-=1;v-=1;g[u].append((v,j));g[v].append((u,j))\nk=max(map(len,g));seen=[False]*n;seen[0]=True;q=deque([(0,0)]);colors=[0]*(n-1)\nwhile q:\n u,parent_color=q.popleft();color=1\n for v,j in g[u]:\n  if seen[v]:continue\n  if color==parent_color:color+=1\n  seen[v]=True;colors[j]=color;q.append((v,color));color+=1\nprint(k);print(*colors,sep='\\n')\n",
'abc147_d':"MOD=10**9+7\nn=int(input());a=list(map(int,input().split()));answer=0\nfor bit in range(60):\n ones=sum((v>>bit)&1 for v in a);answer=(answer+ones*(n-ones)*(1<<bit))%MOD\nprint(answer)\n",
'abc148_d':"n=int(input());a=list(map(int,input().split()));target=1\nfor v in a:\n if v==target:target+=1\nprint(n-target+1 if target>1 else -1)\n",
'abc149_d':"n,k=map(int,input().split());r,s,p=map(int,input().split());t=input();reward={'r':(0,0,p),'s':(r,0,0),'p':(0,s,0)};answer=0\nfor offset in range(k):\n dp=[0,0,0]\n for j in range(offset,n,k):\n  w=reward[t[j]];dp=[max(dp[1],dp[2])+w[0],max(dp[0],dp[2])+w[1],max(dp[0],dp[1])+w[2]]\n answer+=max(dp)\nprint(answer)\n"}
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');rng=random.Random(18600+TASKS.index(pid));raws:list[str]=[]
    if pid=='abc144_d':
        values=[(1,1,1),(1,2,1),(1,2,2),(100,1,1),(1,100,1),(100,100,1),(100,100,500000),(100,100,499999),(100,100,500001),(100,100,999999)]
        values += [(j,j+1,rng.randint(1,j*j*(j+1))) for j in range(2,9)]
        values.append((100,100,1000000));raws=[line(t) for t in values]
    elif pid=='abc145_d':
        values=[(1,1),(1,2),(2,1),(2,2),(3,3),(1,1000000),(1000000,1)]
        values += [(3*j,j) for j in range(2,11)];values += [(999999,999999),(1000000,1000000)];raws=[line(t) for t in values]
    elif pid=='abc146_d':
        def tree(n:int,e:list[Edge])->str:return f'{n}\n'+''.join(line(x) for x in e)
        raws=[tree(2,[(1,2)]),tree(3,[(1,2),(2,3)])]
        for n in range(4,18):raws.append(tree(n,[(rng.randint(1,j-1),j) for j in range(2,n+1)]))
        raws += [tree(100000,[(j,j+1) for j in range(1,100000)]),tree(100000,[(1,j) for j in range(2,100001)])]
    elif pid=='abc147_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([0,0]),seq([0,2**60-1]),seq([2**60-1]*2),seq([0,1,2,3])]
        for n in range(3,15):raws.append(seq([rng.getrandbits(60) for _ in range(n)]))
        raws += [seq([rng.getrandbits(60) for _ in range(300000)]),seq([2**60-1]*300000)]
    elif pid=='abc148_d':
        def seq(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[seq([1]),seq([2,2]),seq([2,1]),seq([1,2]),seq([1,1,2,3])]
        for n in range(3,14):raws.append(seq([rng.randint(1,n) for _ in range(n)]))
        raws += [seq(list(range(200000,0,-1))),seq(list(range(1,200001)))]
    else:
        def game(k:int,r:int,s:int,p:int,t:str)->str:return f'{len(t)} {k}\n{r} {s} {p}\n{t}\n'
        raws=[game(1,1,1,1,'rr'),game(1,10000,1,2,'rssspr'),game(2,1,10000,2,'rprprp'),game(3,1,2,10000,'rpsrps')]
        for n in range(3,15):raws.append(game(rng.randint(1,n-1),rng.randint(1,10000),rng.randint(1,10000),rng.randint(1,10000),''.join(rng.choice('rsp') for _ in range(n))))
        raws += [game(1,10000,10000,10000,'rsp'*33333+'r'),game(99999,10000,10000,10000,'r'*100000)]
    require(len(raws)==len(set(raws))==18,'18 distinct')
    for raw in raws:validate(pid,raw)
    return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc144_d':('傾きが増えると、こぼさず保持できる体積は減ります。','断面が台形か三角形かを、a*tan(theta)とbで判定し、保持できる体積から角度を二分探索します。','疑似コード: low=0,high=pi/2; 100回theta=(low+high)/2; t=tan(theta); a*t<=bならV=a*(a*b-a*a*t/2)、他はV=a*b*b/(2*t); V>=xならlow=theta、他はhigh=theta; low*180/piを出力。'),
'abc145_d':('二種類の移動の回数は、到着座標から一意に決まります。','(1,2)をA回、(2,1)をB回使うとA=(2Y-X)/3、B=(2X-Y)/3です。非負整数でなければ0、そうなら並べ方の二項係数です。','疑似コード: A=2Y-X,B=2X-Y; 負値または3で割れなければ0; A/=3,B/=3; factorialをMODで計算; factorial[A+B]/(factorial[A]*factorial[B])を逆元で求め出力。'),
'abc146_d':('一つの頂点に接する全ての辺は異なる色が必要です。最大次数が色数の下限です。','根から幅優先で進み、親への辺の色を飛ばしながら子への辺に1から順に色を付ければ、最大次数の色数で塗れます。','疑似コード: K=max(degree); queue=[(root,親辺色0)]; 各uでcolor=1; 未訪問の子vへ親辺色を飛ばしてcolorを設定しqueue追加、color++; Kと元入力の辺順の色を出力。'),
'abc147_d':('XORの各ビットは独立して寄与します。','あるビットが1の個数をcとすると、そのビットが異なる二個の組はc*(N-c)個です。','疑似コード: answer=0; bit=0..59でc=sum((A>>bit)&1); answer+=c*(N-c)*2^bit; MODで割った余りを出力。'),
'abc148_d':('残したい列は必ず1,2,3,...です。','左から順に、次に必要な整数が見つかったときだけ残せば最も長く残せます。1がない場合は不可能です。','疑似コード: target=1; 各aでa==targetならtarget++; target==1なら-1、他はN-(target-1)を出力。'),
'abc149_d':('K回前との制約なので、添字をKで割った余りごとの列に分割できます。','各列で最後に出した手を三種類の状態にして、直前と異なる手からの最大得点を更新します。','疑似コード: 各offset=0..K-1でdp=[0,0,0]; j=offset,offset+K,...でnext[h]=max(dp[g] for g!=h)+勝利時の手hの点数; dp=next; 各列のmax(dp)を足して出力。')}

TITLES={'abc144_d': 'Water Bottle', 'abc145_d': 'Knight', 'abc146_d': 'Coloring Edges on Tree', 'abc147_d': 'Xor Sum 4', 'abc148_d': 'Brick Break', 'abc149_d': 'Prediction and Restriction'}
PUBLISHED_SAMPLES={'abc144_d': [{'input': '2 2 4\n', 'expected': '45.0000000000\n'}, {'input': '12 21 10\n', 'expected': '89.7834636934\n'}, {'input': '3 1 8\n', 'expected': '4.2363947991\n'}], 'abc145_d': [{'input': '3 3\n', 'expected': '2\n'}, {'input': '2 2\n', 'expected': '0\n'}, {'input': '999999 999999\n', 'expected': '151840682\n'}], 'abc146_d': [{'input': '3\n1 2\n2 3\n', 'expected': '2\n1\n2\n'}, {'input': '8\n1 2\n2 3\n2 4\n2 5\n4 7\n5 6\n6 8\n', 'expected': '4\n1\n2\n3\n4\n1\n1\n2\n'}, {'input': '6\n1 2\n1 3\n1 4\n1 5\n1 6\n', 'expected': '5\n1\n2\n3\n4\n5\n'}], 'abc147_d': [{'input': '3\n1 2 3\n', 'expected': '6\n'}, {'input': '10\n3 1 4 1 5 9 2 6 5 3\n', 'expected': '237\n'}, {'input': '10\n3 14 159 2653 58979 323846 2643383 27950288 419716939 9375105820\n', 'expected': '103715602\n'}], 'abc148_d': [{'input': '3\n2 1 2\n', 'expected': '1\n'}, {'input': '3\n2 2 2\n', 'expected': '-1\n'}, {'input': '10\n3 1 4 1 5 9 2 6 5 3\n', 'expected': '7\n'}, {'input': '1\n1\n', 'expected': '0\n'}], 'abc149_d': [{'input': '5 2\n8 7 6\nrsrpr\n', 'expected': '27\n'}, {'input': '7 1\n100 10 1\nssssppr\n', 'expected': '211\n'}, {'input': '30 5\n325 234 123\nrspsspspsrpspsppprpsprpssprpsr\n', 'expected': '4996\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
