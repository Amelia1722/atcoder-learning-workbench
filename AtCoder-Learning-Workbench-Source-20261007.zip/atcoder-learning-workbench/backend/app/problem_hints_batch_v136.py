"""Statement-checked three-stage hints for ABC266–268 B."""
HINTS_V136 = {
 'abc266_b': (
  '求めるxは「Nを998244353で割った余り」を0以上998244353未満にしたものです。負のNでもこの範囲に入る代表元を選びます。',
  'Pythonの%は法が正なら結果が0以上法未満になるので、そのまま N % 998244353 で条件を満たします。',
  '疑似コード:\nMOD = 998244353\nN = input integer\nprint(N % MOD)',
 ),
 'abc267_b': (
  'まずピン1が立っていたらスプリットではありません。倒れている場合だけ、10本のピンを図の7列へまとめて考えます。',
  '7列それぞれに立っているピンがあるかをboolで持ちます。立っている列iとjの間に、立っているピンが1本もない列kが1つでもあればYesです。',
  '疑似コード:\nif S[0] == "1": print("No") and 終了\ncol = 7列それぞれに立っているピンがあるか\nfor i < j:\n  if col[i] and col[j] and iとjの間にFalseの列がある:\n    print("Yes") and 終了\nprint("No")',
 ),
 'abc268_b': (
  'SがTの接頭辞なら、まず|S|≤|T|であり、Sの各文字がTの同じ位置の文字と一致します。',
  '長さを確認したあと、Tの先頭|S|文字とSを比較すれば十分です。Pythonならstartswithも使えます。',
  '疑似コード:\nif len(S) > len(T):\n  print("No")\nelif T[0:len(S)] == S:\n  print("Yes")\nelse:\n  print("No")',
 ),
}
