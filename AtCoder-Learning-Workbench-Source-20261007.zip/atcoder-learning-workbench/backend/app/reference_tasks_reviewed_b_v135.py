"""ABC263–265 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations

import re
from collections import deque

TASKS = ('abc263_b', 'abc264_b', 'abc265_b')
POS = re.compile(r'[1-9][0-9]*', re.ASCII)
NONNEG = re.compile(r'(?:0|[1-9][0-9]*)', re.ASCII)

PUBLISHED_SAMPLES = {
    'abc263_b': [
        {'input': '3\n1 2\n', 'expected': '2\n'},
        {'input': '10\n1 2 3 4 5 6 7 8 9\n', 'expected': '9\n'},
    ],
    'abc264_b': [
        {'input': '3 5\n', 'expected': 'black\n'},
        {'input': '4 5\n', 'expected': 'white\n'},
    ],
    'abc265_b': [
        {'input': '4 1 10\n5 7 5\n2 10\n', 'expected': 'Yes\n'},
        {'input': '4 1 10\n10 7 5\n2 10\n', 'expected': 'No\n'},
    ],
}


def _canonical_lines(raw: str) -> list[str]:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('noncanonical')
    body = raw[:-1]
    if body.endswith('\n'):
        raise ValueError('extra blank line')
    return body.split('\n')


def _ints(line: str, count: int, pattern: re.Pattern[str] = POS) -> list[int]:
    parts = line.split(' ')
    if len(parts) != count or any(pattern.fullmatch(x) is None for x in parts):
        raise ValueError('noncanonical integer row')
    return list(map(int, parts))


def _validate263(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 2 or POS.fullmatch(lines[0]) is None:
        raise ValueError('shape')
    n = int(lines[0])
    if not 2 <= n <= 50:
        raise ValueError('N')
    parents = _ints(lines[1], n - 1)
    for child, p in enumerate(parents, start=2):
        if not 1 <= p < child:
            raise ValueError('parent')
    return n, tuple(parents)


def _validate264(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) != 1:
        raise ValueError('shape')
    r, c = _ints(lines[0], 2)
    if not 1 <= r <= 15 or not 1 <= c <= 15:
        raise ValueError('constraints')
    return r, c


def _validate265(raw: str):
    lines = _canonical_lines(raw)
    if len(lines) < 2:
        raise ValueError('shape')
    n, m, t = _ints(lines[0], 3, NONNEG)
    if not 2 <= n <= 100_000 or not 0 <= m <= n - 2 or not 1 <= t <= 10**9:
        raise ValueError('header')
    if len(lines) != 2 + m:
        raise ValueError('line count')
    a = _ints(lines[1], n - 1)
    if any(not 1 <= x <= 10**9 for x in a):
        raise ValueError('cost')
    bonus = []
    prev = 1
    for line in lines[2:]:
        x, y = _ints(line, 2)
        if not 1 < x < n or not 1 <= y <= 10**9 or x <= prev:
            raise ValueError('bonus')
        prev = x
        bonus.append((x, y))
    return n, m, t, tuple(a), tuple(bonus)


def validate(pid: str, raw: str):
    if pid == 'abc263_b':
        return _validate263(raw)
    if pid == 'abc264_b':
        return _validate264(raw)
    if pid == 'abc265_b':
        return _validate265(raw)
    raise ValueError('unknown task')


def _oracle263(n: int, parents: tuple[int, ...]) -> int:
    children = [[] for _ in range(n + 1)]
    for child, p in enumerate(parents, start=2):
        children[p].append(child)
    q = deque([(1, 0)])
    while q:
        person, depth = q.popleft()
        if person == n:
            return depth
        for child in children[person]:
            q.append((child, depth + 1))
    raise AssertionError('N must be reachable from 1')


def _oracle264(r: int, c: int) -> str:
    board = [['white'] * 15 for _ in range(15)]
    for layer in (0, 2, 4, 6):
        lo = layer
        hi = 14 - layer
        for j in range(lo, hi + 1):
            board[lo][j] = 'black'
            board[hi][j] = 'black'
        for i in range(lo, hi + 1):
            board[i][lo] = 'black'
            board[i][hi] = 'black'
    return board[r - 1][c - 1]


def _oracle265(n: int, m: int, t: int, a: tuple[int, ...], bonus: tuple[tuple[int, int], ...]) -> str:
    bonus_by_room = dict(bonus)
    spent = 0
    gained = 0
    for move, cost in enumerate(a, start=1):
        spent += cost
        if t + gained - spent <= 0:
            return 'No'
        arrived_room = move + 1
        gained += bonus_by_room.get(arrived_room, 0)
    return 'Yes'


def independent_check(pid: str, raw: str, output: str) -> bool:
    try:
        value = validate(pid, raw)
    except (ValueError, TypeError, IndexError):
        return False
    if not isinstance(output, str) or not output or output != output.strip():
        return False
    if pid == 'abc263_b':
        if POS.fullmatch(output) is None:
            return False
        return int(output) == _oracle263(*value)
    if pid == 'abc264_b':
        return output in {'black', 'white'} and output == _oracle264(*value)
    return output in {'Yes', 'No'} and output == _oracle265(*value)


def _family(parents: list[int]) -> str:
    return f'{len(parents) + 1}\n' + ' '.join(map(str, parents)) + '\n'


def _explore(n: int, t: int, a: list[int], bonus: list[tuple[int, int]]) -> str:
    return f'{n} {len(bonus)} {t}\n' + ' '.join(map(str, a)) + '\n' + ''.join(f'{x} {y}\n' for x, y in bonus)


def generate(pid: str) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    out: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            out.append({'category': category, 'input': raw})

    for i, row in enumerate(PUBLISHED_SAMPLES[pid], 1):
        add(f'sample{i}', row['input'])

    if pid == 'abc263_b':
        custom = [
            ('minimum', _family([1])),
            ('n3_star', _family([1, 1])),
            ('n4_star', _family([1, 1, 1])),
            ('n4_depth2', _family([1, 2, 2])),
            ('n5_chain', _family([1, 2, 3, 4])),
            ('n6_branch_to_n', _family([1, 1, 2, 2, 5])),
            ('n7_branch', _family([1, 1, 2, 2, 3, 6])),
            ('n8_parent_of_n_root', _family([1, 1, 2, 2, 3, 3, 1])),
            ('n10_star', _family([1] * 9)),
            ('n12_mixed', _family([1, 1, 2, 2, 4, 3, 7, 6, 8, 10, 9])),
            ('n16_binaryish', _family([max(1, i // 2) for i in range(2, 17)])),
            ('n20_shallow', _family([1 if i % 3 else 2 for i in range(2, 21)])),
            ('n25_ladder', _family([max(1, i - (1 if i % 4 else 3)) for i in range(2, 26)])),
            ('n30_mixed', _family([1 if i < 6 else i // 2 for i in range(2, 31)])),
            ('n40_chain_tail', _family([1] * 19 + list(range(20, 40)))),
        ]
        for category, raw in custom:
            add(category, raw)
        add('constraint_max', _family(list(range(1, 50))))
    elif pid == 'abc264_b':
        coords = [
            ('corner_tl', 1, 1),
            ('corner_tr', 1, 15),
            ('corner_bl', 15, 1),
            ('edge_white', 2, 8),
            ('ring3_black', 3, 8),
            ('ring4_white', 4, 8),
            ('ring5_black', 5, 8),
            ('ring6_white', 6, 8),
            ('ring7_black', 7, 8),
            ('center', 8, 8),
            ('symmetric_a', 13, 11),
            ('symmetric_b', 12, 11),
            ('near_corner', 14, 14),
            ('bottom_edge_mid', 15, 8),
            ('left_inner', 8, 3),
        ]
        for category, r, c in coords:
            add(category, f'{r} {c}\n')
        add('constraint_max', '15 15\n')
    else:
        custom = [
            ('minimum_yes', _explore(2, 2, [1], [])),
            ('minimum_exact_zero_no', _explore(2, 1, [1], [])),
            ('no_bonus_yes', _explore(4, 10, [3, 3, 3], [])),
            ('no_bonus_late_no', _explore(4, 9, [3, 3, 3], [])),
            ('bonus_saves', _explore(5, 6, [3, 3, 3, 3], [(2, 10)])),
            ('bonus_too_late', _explore(5, 3, [3, 1, 1, 1], [(3, 100)])),
            ('multiple_bonus_yes', _explore(6, 7, [3, 3, 5, 5, 5], [(2, 4), (4, 20)])),
            ('multiple_bonus_no', _explore(6, 7, [3, 3, 5, 20, 1], [(2, 4), (4, 10)])),
            ('large_values_yes', _explore(3, 10**9, [999_999_999, 999_999_999], [(2, 10**9)])),
            ('large_values_no', _explore(3, 10**9, [10**9, 1], [(2, 10**9)])),
            ('bonus_each_room_small', _explore(8, 2, [1] * 7, [(i, 1) for i in range(2, 8)])),
            ('alternating_costs', _explore(10, 20, [1, 7, 1, 7, 1, 7, 1, 7, 1], [(3, 5), (6, 5), (9, 5)])),
            ('n20_many_bonus', _explore(20, 15, [2] * 19, [(i, 1 + (i % 4)) for i in range(2, 20)])),
            ('n100_no_bonus', _explore(100, 100, [1] * 99, [])),
            ('n1000_sparse_bonus', _explore(1000, 200, [1] * 999, [(100, 50), (500, 400), (900, 400)])),
        ]
        for category, raw in custom:
            add(category, raw)
        n = 100_000
        add('constraint_max', _explore(n, 10**9, [1] * (n - 1), [(i, 10**9) for i in range(2, n)]))

    if len(out) != 18:
        raise AssertionError((pid, len(out), [x['category'] for x in out]))
    return out
