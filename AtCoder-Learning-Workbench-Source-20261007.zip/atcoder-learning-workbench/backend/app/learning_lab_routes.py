"""REST interface for optional learning lab; separate from submission-sync routes."""
from __future__ import annotations
from fastapi import APIRouter, Query
from .learning_lab import (
 LinkEdit, PrerequisiteEdit, SpecEdit, GenerateRequest, ShrinkRequest, EventInput,
 QuizAnswer, Feedback, audit_report, problem_links, set_problem_link, get_prerequisites,
 set_prerequisite, test_spec, set_spec, reset_spec, get_cases, shrink_cases,
 record_event, get_events, available_quizzes, answer_quiz, mastery,
 lab_recommendations, search_feedback,
)

router=APIRouter(prefix='/api/lab',tags=['learning-lab'])

@router.get('/audit')
def audit():return audit_report()

@router.get('/problems/{problem_id}/links')
def links(problem_id:str):return problem_links(problem_id)

@router.put('/problems/{problem_id}/links')
def links_put(problem_id:str,payload:LinkEdit):return set_problem_link(problem_id,payload)

@router.get('/prerequisites/{anchor}')
def prerequisites(anchor:str):return get_prerequisites(anchor)

@router.put('/prerequisites')
def prerequisites_put(payload:PrerequisiteEdit):return set_prerequisite(payload)

@router.get('/problems/{problem_id}/spec')
def spec(problem_id:str):return test_spec(problem_id)

@router.put('/problems/{problem_id}/spec')
def spec_put(problem_id:str,payload:SpecEdit):return set_spec(problem_id,payload)

@router.delete('/problems/{problem_id}/spec')
def spec_reset(problem_id:str):return reset_spec(problem_id)

@router.post('/problems/{problem_id}/generate')
def generate(problem_id:str,payload:GenerateRequest):return get_cases(problem_id,payload)

@router.post('/problems/{problem_id}/shrink')
def shrink(problem_id:str,payload:ShrinkRequest):return shrink_cases(problem_id,payload.input)

@router.get('/events')
def events(user_id:str,problem_id:str|None=None,limit:int=Query(80,ge=1,le=300)):
    return get_events(user_id,problem_id,limit)

@router.post('/events')
def event_put(user_id:str,payload:EventInput):return record_event(user_id,payload)

@router.get('/mastery')
def mastery_get(user_id:str):return mastery(user_id)

@router.get('/quizzes/{anchor}')
def quizzes(anchor:str):return available_quizzes(anchor)

@router.post('/quizzes/{anchor}/{quiz_id}/answer')
def quiz_answer(anchor:str,quiz_id:str,user_id:str,payload:QuizAnswer):
    return answer_quiz(user_id,anchor,quiz_id,payload)

@router.get('/recommendations')
def recommendations(user_id:str,limit:int=Query(30,ge=1,le=100)):
    return lab_recommendations(user_id,limit)

@router.post('/feedback')
def feedback(user_id:str,payload:Feedback):return search_feedback(user_id,payload)

from .learning_lab import (TemplateInput,LocalQuestion,init_lab_extensions,save_template,
                            templates,delete_template,source_question,similar_problems,audit_code_fixtures)

@router.get('/code-audit')
def code_audit():return audit_code_fixtures()

@router.get('/templates')
def template_list(user_id:str,anchor:str|None=None):return templates(user_id,anchor)

@router.post('/templates')
def template_save(user_id:str,payload:TemplateInput):return save_template(user_id,payload)

@router.delete('/templates/{template_id}')
def template_remove(template_id:int,user_id:str):return delete_template(user_id,template_id)

@router.post('/ask')
def ask(payload:LocalQuestion):return source_question(payload.question)

@router.get('/problems/{problem_id}/similar')
def similar(problem_id:str):return similar_problems(problem_id)


# Stateless statement-driven test preview; no DB writes and no oracle impersonation.
from .statement_tests import (StatementPreview, StatementGeneration,
                              preview_statement, generate_statement_cases)

@router.post('/statement/preview')
def statement_preview(payload:StatementPreview):return preview_statement(payload)

@router.post('/statement/generate')
def statement_generate(payload:StatementGeneration):return generate_statement_cases(payload)


# Precomputed ABC A-G input/expected-output bank; never executes reference code.
from .test_bank import bank_cases, catalog_coverage

@router.get('/test-bank/coverage')
def test_bank_coverage(status:str='all', offset:int=Query(0,ge=0),limit:int=Query(100,ge=1,le=500),q:str='',letter:str=''):
    return catalog_coverage(status,offset,limit,q,letter)

@router.get('/test-bank/{problem_id}')
def test_bank_problem(problem_id:str):
    return bank_cases(problem_id)


# Three-level reveal must go through an atomic, per-user/per-problem DB update.
from .problem_hints import HintReveal, hint_state, reveal_hint

@router.get('/problems/{problem_id}/hints')
def hint_get(problem_id: str, user_id: str):
    return hint_state(user_id, problem_id)

@router.post('/problems/{problem_id}/hints')
def hint_post(problem_id: str, user_id: str, payload: HintReveal):
    return reveal_hint(user_id, problem_id, payload)

@router.get('/hints/progress')
def hint_progress(user_id: str):
    from .problem_hints import all_hint_progress
    return all_hint_progress(user_id)

@router.get('/problems/{problem_id}/constraints')
def problem_constraints(problem_id: str):
    from .problem_hints import get_problem_constraints
    return get_problem_constraints(problem_id)
