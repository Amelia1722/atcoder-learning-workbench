"""Matching, residue interval intersection and reverse flight feasibility."""
from __future__ import annotations
from collections import deque
from itertools import groupby
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(431,437))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Flights=tuple[tuple[int,tuple[tuple[int,int,int],...]],...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==431:
        require(len(rows)==3,'shape');n,m,k=ints(rows[0],3);require(1<=n<=200000 and 1<=m<=200000 and 1<=k<=min(n,m),'size');h,b=ints(rows[1],n),ints(rows[2],m);require(all(1<=v<=10**9 for seq in (h,b) for v in seq),'weights');return k,h,b
    if number==432:
        require(len(rows)==2,'shape');n,x,y=ints(rows[0],3);a=ints(rows[1],n);require(2<=n<=200000 and 1<=x<y<=10**9 and all(1<=v<=10**9 for v in a),'candies');return x,y,a
    if number==433:
        require(len(rows)==1 and 1<=len(rows[0])<=10**6 and re.fullmatch('[0-9]+',rows[0]) is not None,'digits');return (rows[0],)
    if number==434:
        t=ints(rows[0],1)[0];require(1<=t<=100000,'cases');p=1;total=0;cases=[]
        for _ in range(t):
            require(p<len(rows),'header');n,h=ints(rows[p],2);p+=1;require(1<=n<=100000 and 1<=h<=10**9 and p+n<=len(rows),'case');goals=tuple(ints(row,3) for row in rows[p:p+n]);p+=n;total+=n;previous=0
            for time,l,u in goals:require(previous<time<=10**9 and 1<=l<=u<=10**9,'goals');previous=time
            cases.append((h,goals))
        require(total<=100000 and p==len(rows),'aggregate');return (tuple(cases),)
    if number==435:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=500000 and all(1<=v<=n for v in a),'dominoes');return (a,)
    n,m=ints(rows[0],2);require(2<=n<=10**9 and 1<=m<=200000 and len(rows)==m+1,'shape');a=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<n for pair in a for v in pair),'blocks');return (a,)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==431:
        k,h,b=cast(tuple[int,tuple[int,...],tuple[int,...]],data);heads=sorted(h);j=0
        for body in sorted(b):
            if j<len(heads) and heads[j]<=body:j+=1
        return 'Yes' if j>=k else 'No'
    if number==432:
        x,y,a=cast(tuple[int,int,tuple[int,...]],data);gap=y-x;residue=a[0]*x%gap;lower=max(a)*x;upper=min(a)*y
        if lower>upper or any(v*x%gap!=residue for v in a):return '-1'
        weight=upper-(upper-residue)%gap
        return '-1' if weight<lower else str((len(a)*weight-sum(a)*x)//gap)
    if number==433:
        s=cast(str,data[0]);n=len(s);left=[1]*n;right=[1]*n
        for j in range(1,n):
            if s[j]==s[j-1]:left[j]=left[j-1]+1
        for j in range(n-2,-1,-1):
            if s[j]==s[j+1]:right[j]=right[j+1]+1
        return str(sum(min(left[j],right[j+1]) for j in range(n-1) if ord(s[j+1])-ord(s[j])==1))
    if number==434:
        out=[]
        for h,goals in cast(Flights,data[0]):
            low,high=goals[-1][1:];valid=True
            for j in range(len(goals)-2,-1,-1):
                time,l,u=goals[j];elapsed=goals[j+1][0]-time;low=max(l,low-elapsed);high=min(u,high+elapsed)
                if low>high:valid=False;break
            valid &= low-goals[0][0]<=h<=high+goals[0][0]
            out.append('Yes' if valid else 'No')
        return '\n'.join(out)
    if number==435:
        a=cast(tuple[int,...],data[0]);n=len(a);successor=list(range(n+1));successor[0]=1;pending=deque([0]);answer=1
        def next_unvisited(v:int)->int:
            while successor[v]!=v:successor[v]=successor[successor[v]];v=successor[v]
            return v
        while pending:
            j=pending.popleft();limit=min(n,j+a[j]);p=next_unvisited(j+1)
            while p<limit:pending.append(p);answer+=1;successor[p]=next_unvisited(p+1);p=successor[p]
        return str(answer)
    a=cast(tuple[tuple[int,int],...],data[0]);accepted=set()
    for r,c in a:
        if not any((r+dr,c+dc) in accepted for dr in (-1,0,1) for dc in (-1,0,1)):accepted.add((r,c))
    return str(len(accepted))

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc431_c':"n,m,k=map(int,input().split());h=sorted(map(int,input().split()));b=sorted(map(int,input().split()));print('Yes' if all(x<=y for x,y in zip(h[:k],b[-k:])) else 'No')\n",
'abc432_c':"n,x,y=map(int,input().split());a=list(map(int,input().split()));weight=min(a)*y;answer=0;ok=True\nfor v in a:\n extra=weight-v*x\n if extra<0 or extra%(y-x) or extra//(y-x)>v:ok=False\n else:answer+=extra//(y-x)\nprint(answer if ok else -1)\n",
'abc433_c':"from itertools import groupby\ns=input();runs=[(ch,len(list(seq))) for ch,seq in groupby(s)];print(sum(min(a,b) for (x,a),(y,b) in zip(runs,runs[1:]) if int(y)==int(x)+1))\n",
'abc434_c':"t=int(input())\nfor _ in range(t):\n n,h=map(int,input().split());low=high=h;previous=0;ok=True\n for _ in range(n):\n  time,l,u=map(int,input().split());elapsed=time-previous;low=max(1,l,low-elapsed);high=min(u,high+elapsed);previous=time\n  if low>high:ok=False\n print('Yes' if ok else 'No')\n",
'abc435_c':"n=int(input());a=list(map(int,input().split()));reach=1;answer=0\nfor j,v in enumerate(a):\n if j>=reach:break\n answer+=1;reach=max(reach,j+v)\nprint(answer)\n",
'abc436_c':"n,m=map(int,input().split());occupied=set();answer=0\nfor _ in range(m):\n r,c=map(int,input().split());cells=((r,c),(r+1,c),(r,c+1),(r+1,c+1))\n if all(cell not in occupied for cell in cells):occupied.update(cells);answer+=1\nprint(answer)\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17600+number)
    if number==431:
        def robot(k:int,h:list[int],b:list[int])->str:return f'{len(h)} {len(b)} {k}\n'+line(h)+line(b)
        raws=[robot(k,h,b) for k,h,b in ((1,[1],[1]),(1,[2],[1]),(1,[1],[2]),(2,[2,3],[3,2]))];raws.extend(robot(n//2,[rng.randint(1,30) for _ in range(n)],[rng.randint(1,30) for _ in range(n+1)]) for n in range(3,15));raws.extend([robot(200000,[10**9]*200000,[10**9-1]*200000),robot(200000,[10**9]*200000,[10**9]*200000)])
    elif number==432:
        def candy(x:int,y:int,a:list[int])->str:return f'{len(a)} {x} {y}\n'+line(a)
        raws=[candy(x,y,a) for x,y,a in ((1,2,[1,1]),(1,2,[1,2]),(1,3,[1,2]),(3,4,[3,5]))];raws.extend(candy(1+n%3,6+n%3,[rng.randint(1,20) for _ in range(n)]) for n in range(3,15));raws.extend([candy(1,10**9,[1,10**9]*100000),candy(10**9-1,10**9,[10**9]*200000)])
    elif number==433:raws=[s+'\n' for s in ('0','01','90','001122')];raws.extend(''.join(rng.choice('0123456789') for _ in range(n))+'\n' for n in range(2,14));raws.extend(['4'*500000+'5'*500000+'\n','9'*1000000+'\n'])
    elif number==434:
        def flights(cases:list[tuple[int,list[tuple[int,int,int]]]])->str:return f'{len(cases)}\n'+''.join(f'{len(goals)} {h}\n'+''.join(f'{t} {l} {u}\n' for t,l,u in goals) for h,goals in cases)
        raws=[flights(cases) for cases in ([(1,[(1,1,1)])],[(1,[(1,3,3)])],[(2,[(1,1,1)])],[(1,[(1,1,2),(2,2,3)])])]
        # Distinct small cases exercise intervals and infeasible discontinuities.
        for n in range(3,15):
            goals=[(j+1,*sorted((rng.randint(1,30),rng.randint(1,30)))) for j in range(n)];raws.append(flights([(rng.randint(1,30),goals)]))
        raws.extend([flights([(1,[(j+1,1,1) for j in range(100000)])]),flights([(10**9,[(10**9,10**9,10**9)])]*100000)])
    elif number==435:
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[1,2],[2,1],[3,1,1])];raws.extend(arr([rng.randint(1,n) for _ in range(n)]) for n in range(3,15));raws.extend([arr([2]*500000),arr([500000]*500000)])
    else:
        def blocks(n:int,a:list[tuple[int,int]])->str:return f'{n} {len(a)}\n'+''.join(f'{r} {c}\n' for r,c in a)
        raws=[blocks(n,a) for n,a in ((2,[(1,1)]),(2,[(1,1),(1,1)]),(3,[(1,1),(2,2)]),(4,[(1,1),(1,3),(3,1),(3,3)]))];raws.extend(blocks(n,[(rng.randint(1,n-1),rng.randint(1,n-1)) for _ in range(n+1)]) for n in range(3,15));raws.extend([blocks(10**9,[(1+2*j,1+2*j) for j in range(200000)]),blocks(10**9,[(10**9-1,10**9-1)]*200000)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc431_c':('小さい頭と大きい体を選ぶほど組み合わせやすくなります。','最も軽いK個の頭と最も重いK個の体を、それぞれ昇順で対応させます。','疑似コード: H,Bをsort; H[:K]とB[-K:]の対応全てで頭<=体ならYes、他はNo。'),
'abc432_c':('大きな飴を増やすほど共通の重量も大きくなります。','最少個数の子供が全部大きな飴を持つ重量を上限とし、全員について個数が整数で範囲内か調べます。','疑似コード: W=min(A)*Y; 各Aでextra=W-A*X; extra>=0、extra%(Y-X)=0、extra/(Y-X)<=Aなら大飴個数を加算; どれか失敗で-1。'),
'abc433_c':('条件を満たす部分文字列の中央は、数字dからd+1に変わる境目です。','連続する同じ数字を区間に圧縮し、隣接区間の数字が1違うなら短い方の長さだけ作れます。','疑似コード: 同じ数字のrunを作る; 隣接する(d,len1),(d+1,len2)ごとにmin(len1,len2)を加算。'),
'abc434_c':('ある時刻に到達できる高度は連続した区間です。','経過時間だけ上下に広げ、次の目標範囲と交差させます。空になったら不可能です。','疑似コード: low=high=H,prev=0; 各(t,l,u)でd=t-prev; low=max(1,l,low-d),high=min(u,high+d); low>highならNo; 全目標可能ならYes。'),
'abc435_c':('倒れる位置は左から連続した範囲になります。','左から到達範囲を伸ばし、範囲外のドミノへ来たら止めます。区間の右端は含みません。','疑似コード: 0-basedでreach=1; j<reachの間だけ処理しreach=max(reach,j+A[j]); 処理した数を出力。'),
'abc436_c':('ブロックが占めるのは4マスだけです。','占有済みマスを集合で持ち、新しい4マスが全て空ならまとめて登録します。','疑似コード: 各(R,C)で4セルを作り、全てnot in occupiedならoccupiedへ追加しanswer++; answer出力。')}

TITLES={'abc431_c': 'Robot Factory', 'abc432_c': 'Candy Tribulation', 'abc433_c': '1122 Substring 2', 'abc434_c': 'Flapping Takahashi', 'abc435_c': 'Domino', 'abc436_c': '2x2 Placing'}
PUBLISHED_SAMPLES={'abc431_c': [{'input': '6 6 3\n2 7 1 8 2 8\n1 8 2 8 4 5\n', 'expected': 'Yes\n'}, {'input': '1 1 1\n43\n1\n', 'expected': 'No\n'}, {'input': '1 1 1\n100\n100\n', 'expected': 'Yes\n'}, {'input': '12 15 12\n748 169 586 329 972 529 432 519 408 587 138 249\n656 114 632 299 984 755 404 772 155 506 832 854 353 465 387\n', 'expected': 'Yes\n'}], 'abc432_c': [{'input': '3 6 8\n11 10 13\n', 'expected': '18\n'}, {'input': '2 3 4\n3 5\n', 'expected': '-1\n'}, {'input': '8 4 32\n1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '8000000000\n'}], 'abc433_c': [{'input': '1122\n', 'expected': '2\n'}, {'input': '7788788\n', 'expected': '3\n'}, {'input': '2025\n', 'expected': '0\n'}, {'input': '1112222334445556555\n', 'expected': '11\n'}], 'abc434_c': [{'input': '3\n2 5\n3 1 4\n8 9 11\n2 6\n1 1 4\n3 5 8\n10 36\n27 37 38\n30 34 54\n38 20 77\n45 1 36\n49 38 51\n52 31 58\n65 43 60\n71 14 42\n73 36 38\n85 14 29\n', 'expected': 'Yes\nNo\nYes\n'}], 'abc435_c': [{'input': '4\n3 1 4 1\n', 'expected': '4\n'}, {'input': '9\n1 4 1 4 2 1 3 5 6\n', 'expected': '1\n'}, {'input': '10\n5 4 3 2 1 1 2 3 4 5\n', 'expected': '5\n'}], 'abc436_c': [{'input': '4 3\n1 1\n2 2\n2 3\n', 'expected': '2\n'}, {'input': '1000000000 4\n1 1\n1 101\n101 1\n101 101\n', 'expected': '4\n'}, {'input': '8 10\n6 5\n7 3\n6 7\n3 4\n4 2\n3 7\n1 3\n7 4\n6 1\n6 1\n', 'expected': '8\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
