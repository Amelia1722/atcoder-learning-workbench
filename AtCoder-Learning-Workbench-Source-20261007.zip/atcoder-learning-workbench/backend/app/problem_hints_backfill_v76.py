"""Evidence-bound backfill for ABC006 A-B / ABC007 A; public statements checked."""
HINTS_BACKFILL_V76 = {
    'abc006_1': (
        '条件は「3が含まれる」または「3で割り切れる」のどちらかです。Nの範囲も小さいです。',
        'N % 3 == 0 か、10進表記に文字3が含まれるかをORで判定します。',
        '''疑似コード:\nN = read_integer()\nif N % 3 == 0 or "3" in str(N): print("YES")\nelse: print("NO")''',
    ),
    'abc006_2': (
        '次の項は直前3項だけから決まります。大きな値そのものではなく、必要な余りだけ保持できます。',
        '初期値0,0,1から順に3項の和を作り、毎回10007で割った余りへ更新します。',
        '''疑似コード:\nif n <= 3: print([0,0,1][n-1])\nelse:\n  a,b,c = 0,0,1\n  repeat from 4 to n:\n    a,b,c = b,c,(a+b+c)%10007\n  print(c)''',
    ),
    'abc007_1': (
        '一直線に並んだ木では、木と木の間は両端の木そのものより1つ少なくなります。',
        'n本を順番に並べたとき、隣接する組は(1,2),(2,3),...,(n-1,n)なのでn-1個です。',
        '''疑似コード:\nn = read_integer()\nprint(n - 1)''',
    ),
}
