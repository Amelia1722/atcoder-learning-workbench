"""Length-block ranks, circular reflection buckets and coverage inclusion-exclusion."""
from __future__ import annotations
from bisect import bisect_left
from collections import deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(285,291))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'canonical integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def _word_rank(s:str)->int:
    preceding=sum(26**width for width in range(1,len(s)));offset=sum((ord(ch)-65)*26**(len(s)-j-1) for j,ch in enumerate(s));return preceding+offset+1
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==285:
        require(len(rows)==1 and re.fullmatch('[A-Z]{1,12}',rows[0]) is not None and _word_rank(rows[0])<=10**16,'contest id');return (rows[0],)
    if number==286:
        n,a,b=ints(rows[0],3);require(1<=n<=5000 and 1<=a<=10**9 and 1<=b<=10**9 and len(rows)==2 and re.fullmatch('[a-z]+',rows[1]) is not None and len(rows[1])==n,'string/cost');return a,b,rows[1]
    if number in (287,288):
        n,m=ints(rows[0],2);require((2<=n<=200000 if number==287 else 1<=n<=200000) and 0<=m<=min(200000,n*(n-1)//2) and len(rows)==m+1,'shape');edges=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in edges) and len({tuple(sorted(edge)) for edge in edges})==m,'simple graph');return n,edges
    if number==289:
        n,m=ints(rows[0],2);require(1<=n<=10 and 1<=m<=10 and len(rows)==2*m+1,'shape');sets=[]
        for j in range(m):
            c=ints(rows[2*j+1],1)[0];values=ints(rows[2*j+2],c);require(1<=c<=n and all(1<=v<=n for v in values) and all(a<b for a,b in zip(values,values[1:])),'ordered set');sets.append(values)
        return n,tuple(sets)
    n,k=ints(rows[0],2);require(1<=k<=n<=300000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(0<=v<=10**9 for v in a),'elements');return k,a
def _reflection_cost(a:int,b:int,s:str)->int:
    n=len(s);mismatch=[0]*n
    for i,ch in enumerate(s):
        for j in range(i+1,n):
            if ch!=s[j]:mismatch[(i+j)%n]+=1
    return min(rotation*a+mismatch[(2*rotation+n-1)%n]*b for rotation in range(n))
def _endpoint_trace(n:int,edges:tuple[Pair,...])->bool:
    if len(edges)!=n-1:return False
    graph=[[] for _ in range(n+1)]
    for a,b in edges:graph[a].append(b);graph[b].append(a)
    if any(len(graph[j])>2 for j in range(1,n+1)):return False
    ends=[j for j in range(1,n+1) if len(graph[j])==1]
    if len(ends)!=2:return False
    visited=set();previous=0;current=ends[0]
    while current not in visited:
        visited.add(current);options=[v for v in graph[current] if v!=previous]
        if not options:break
        previous,current=current,options[0]
    return len(visited)==n and current==ends[1]
def _cycle_rank(n:int,edges:tuple[Pair,...])->int:
    graph=[[] for _ in range(n+1)]
    for a,b in edges:graph[a].append(b);graph[b].append(a)
    visited=[False]*(n+1);components=0
    for start in range(1,n+1):
        if visited[start]:continue
        components+=1;visited[start]=True;queue=deque([start])
        while queue:
            for v in graph[queue.popleft()]:
                if not visited[v]:visited[v]=True;queue.append(v)
    return len(edges)-n+components
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==285:return str(_word_rank(cast(str,data[0])))
    if number==286:return str(_reflection_cost(*cast(tuple[int,int,str],data)))
    if number==287:return 'Yes' if _endpoint_trace(*cast(tuple[int,tuple[Pair,...]],data)) else 'No'
    if number==288:return str(_cycle_rank(*cast(tuple[int,tuple[Pair,...]],data)))
    if number==289:
        n,sets=cast(tuple[int,tuple[tuple[int,...],...]],data);masks=[sum(1<<(v-1) for v in values) for values in sets]
        return str(sum((-1)**missing.bit_count()*(1<<sum(mask&missing==0 for mask in masks)) for missing in range(1<<n)))
    k,a=cast(tuple[int,tuple[int,...]],data);unique=sorted(set(a));low=0;high=k+1
    while high-low>1:
        middle=(low+high)//2
        if bisect_left(unique,middle)==middle:low=middle
        else:high=middle
    return str(low)
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc285_c':"s=input();answer=0\nfor ch in s:answer=answer*26+ord(ch)-64\nprint(answer)\n",
'abc286_c':"n,a,b=map(int,input().split());s=input();answer=10**30\nfor rotation in range(n):\n mismatch=sum(s[(rotation+j)%n]!=s[(rotation+n-1-j)%n] for j in range(n//2));answer=min(answer,rotation*a+mismatch*b)\nprint(answer)\n",
'abc287_c':"n,m=map(int,input().split());g=[[] for _ in range(n)]\nfor _ in range(m):\n a,b=map(int,input().split());g[a-1].append(b-1);g[b-1].append(a-1)\nseen={0};pending=[0]\nwhile pending:\n for v in g[pending.pop()]:\n  if v not in seen:seen.add(v);pending.append(v)\nprint('Yes' if m==n-1 and len(seen)==n and all(len(row)<=2 for row in g) else 'No')\n",
'abc288_c':"n,m=map(int,input().split());parent=list(range(n));size=[1]*n;answer=0\ndef root(j):\n while j!=parent[j]:parent[j]=parent[parent[j]];j=parent[j]\n return j\nfor _ in range(m):\n a,b=map(int,input().split());u,v=root(a-1),root(b-1)\n if u==v:answer+=1\n else:\n  if size[u]<size[v]:u,v=v,u\n  parent[v]=u;size[u]+=size[v]\nprint(answer)\n",
'abc289_c':"n,m=map(int,input().split());sets=[]\nfor _ in range(m):\n c=int(input());sets.append(set(map(int,input().split())))\nanswer=0\nfor mask in range(1,1<<m):\n covered=set()\n for j in range(m):\n  if mask>>j&1:covered|=sets[j]\n answer+=len(covered)==n\nprint(answer)\n",
'abc290_c':"n,k=map(int,input().split());values=set(map(int,input().split()));answer=0\nwhile answer<k and answer in values:answer+=1\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def _encode_rank(rank:int)->str:
    answer=''
    while rank:rank,digit=divmod(rank-1,26);answer=chr(65+digit)+answer
    return answer
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');n=int(pid[3:6]);rng=random.Random(16800+n)
    if n==285:raws=[_encode_rank(rank)+'\n' for rank in (1,2,25,26,27,28,52,53,676,702,703,704,18278,18279,10**9,10**12,10**16-1,10**16)]
    elif n==286:
        def string(a:int,b:int,s:str)->str:return f'{len(s)} {a} {b}\n{s}\n'
        raws=[string(1,1,'a'),string(1,1,'ab'),string(1,10**9,'aab'),string(10**9,1,'aab')]
        for size in range(4,16):raws.append(string(rng.randint(1,100),rng.randint(1,100),''.join(rng.choice('abcxyz') for _ in range(size))))
        raws.extend([string(1,10**9,'a'*2500+'b'*2500),string(10**9,10**9,'z'*5000)])
    elif n in (287,288):
        def graph(size:int,e:list[Pair])->str:return f'{size} {len(e)}\n'+''.join(line(edge) for edge in e)
        raws=[graph(2 if n==287 else 1,[]),graph(2,[(1,2)]),graph(3,[(1,2),(2,3)]),graph(3,[(1,2),(2,3),(1,3)])]
        for size in range(4,16):e=[(a,b) for a in range(1,size+1) for b in range(a+1,size+1) if rng.randrange(3)==0];raws.append(graph(size,e))
        path=[(j,j+1) for j in range(1,200000)];raws.extend([graph(200000,path),graph(200000,path+[(1,200000)])])
    elif n==289:
        def sets(size:int,s:list[list[int]])->str:return f'{size} {len(s)}\n'+''.join(f'{len(values)}\n'+line(values) for values in s)
        raws=[sets(1,[[1]]),sets(1,[[1],[1]]),sets(2,[[1],[2]]),sets(3,[[1],[2]])]
        for size in range(2,8):
            for count in (3,5):raws.append(sets(size,[sorted(rng.sample(range(1,size+1),rng.randint(1,size))) for _ in range(count)]))
        raws.extend([sets(10,[[j] for j in range(1,11)]),sets(10,[list(range(1,11))]*10)])
    else:
        def array(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[array(1,[0]),array(1,[1]),array(1,[0,1]),array(2,[0,2])]
        for size in range(3,15):raws.append(array(rng.randint(1,size),[rng.randint(0,20) for _ in range(size)]))
        raws.extend([array(300000,list(range(300000))),array(300000,[10**9]*300000)])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc285_c':('Aを1、Zを26とする位取りとして考えられます。','左から読み、現在の値を26倍して文字の番号1から26を足します。AAは26+1=27です。','疑似コード: answer=0; for ch in S: answer=26*answer+(ord(ch)-ord(A)+1); print(answer)。'),
'abc286_c':('回転回数は0からN-1だけ試せば十分です。','回転後の左右対称な文字が異なる組ごとに、1文字の変更が必要です。回転費用と変更費用の合計の最小を取ります。','疑似コード: answer=INF; for r=0..N-1: bad=count(S[(r+j)%N]!=S[(r+N-1-j)%N] for j<N/2); answer=min(answer,r*A+bad*B); print(answer)。'),
'abc287_c':('一本道は連結で、全頂点の次数が2以下です。','辺数N-1、連結、次数2以下を全て確認します。単純グラフという保証のもとでパスになります。','疑似コード: build adjacency; seen=DFS(1); print(Yes if M==N-1 and len(seen)==N and max_degree<=2 else No)。'),
'abc288_c':('各連結成分で、木になるまで余分な辺を削除します。','Union-Findで辺を順に処理します。同じ連結成分を結ぶ辺は閉路を作るので、その本数を答えにします。','疑似コード: answer=0; for edge(u,v): if find(u)==find(v): answer+=1; else: unite(u,v); print(answer)。'),
'abc289_c':('集合の選び方は最大1023通りです。','空でない部分集合を全て試し、選んだ集合の和集合が1からNを全て含むか確認します。','疑似コード: answer=0; for mask=1..2^M-1: covered=union(selected sets); answer+=(len(covered)==N); print(answer)。'),
'abc290_c':('MEXがm以上なら、0からm-1の全てを選ぶ必要があります。','元の列で最初に存在しない非負整数を探します。ただしK個の列のMEXはKを超えられません。','疑似コード: values=set(A); answer=0; while answer<K and answer in values: answer+=1; print(answer)。')}

TITLES={'abc285_c': 'abc285_brutmhyhiizp', 'abc286_c': 'Rotate and Palindrome', 'abc287_c': 'Path Graph?', 'abc288_c': 'Don’t be cycle', 'abc289_c': 'Coverage', 'abc290_c': 'Max MEX'}
PUBLISHED_SAMPLES={'abc285_c': [{'input': 'AB\n', 'expected': '28\n'}, {'input': 'C\n', 'expected': '3\n'}, {'input': 'BRUTMHYHIIZP\n', 'expected': '10000000000000000\n'}], 'abc286_c': [{'input': '5 1 2\nrrefa\n', 'expected': '3\n'}, {'input': '8 1000000000 1000000000\nbcdfcgaa\n', 'expected': '4000000000\n'}], 'abc287_c': [{'input': '4 3\n1 3\n4 2\n3 2\n', 'expected': 'Yes\n'}, {'input': '2 0\n', 'expected': 'No\n'}, {'input': '5 5\n1 2\n2 3\n3 4\n4 5\n5 1\n', 'expected': 'No\n'}], 'abc288_c': [{'input': '6 7\n1 2\n1 3\n2 3\n4 2\n6 5\n4 6\n4 5\n', 'expected': '2\n'}, {'input': '4 2\n1 2\n3 4\n', 'expected': '0\n'}, {'input': '5 3\n1 2\n1 3\n2 3\n', 'expected': '1\n'}], 'abc289_c': [{'input': '3 3\n2\n1 2\n2\n1 3\n1\n2\n', 'expected': '3\n'}, {'input': '4 2\n2\n1 2\n2\n1 3\n', 'expected': '0\n'}, {'input': '6 6\n3\n2 3 6\n3\n2 4 6\n2\n3 6\n3\n1 5 6\n3\n1 3 6\n2\n1 4\n', 'expected': '18\n'}], 'abc290_c': [{'input': '7 3\n2 0 2 3 2 1 9\n', 'expected': '3\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
