"""Private ABC341..346 D: exact constraints and independent oracles."""
from __future__ import annotations
from collections import Counter
from functools import lru_cache
from math import gcd,isqrt
from typing import cast
import heapq,random,re
TASKS=tuple(f'abc{i}_d' for i in range(341,347));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc341_d':
  require(len(rows)==1,'shape');n,m,k=ints(rows[0],3);require(1<=n<=10**8 and 1<=m<=10**8 and n!=m and 1<=k<=10**10,'range');return n,m,k
 if pid=='abc342_d':n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(0<=v<=200000 for v in a),'Ai');return (a,)
 if pid=='abc343_d':
  n,t=ints(rows[0],2);require(1<=n<=200000 and 1<=t<=200000 and len(rows)==t+1,'shape');updates=tuple(ints(r,2) for r in rows[1:]);require(all(1<=a<=n and 1<=b<=10**9 for a,b in updates),'updates');return n,updates
 if pid=='abc344_d':
  require(len(rows)>=3 and re.fullmatch(r'[a-z]{1,100}',rows[0]) is not None,'T');n=ints(rows[1],1)[0];require(1<=n<=100 and len(rows)==n+2,'shape');bags=[]
  for row in rows[2:]:
   fields=row.split(' ');count=ints(fields[0],1)[0];require(1<=count<=10 and len(fields)==count+1 and all(re.fullmatch(r'[a-z]{1,10}',s) is not None for s in fields[1:]),'bag');bags.append(tuple(fields[1:]))
  return rows[0],tuple(bags)
 if pid=='abc345_d':
  n,h,w=ints(rows[0],3);require(1<=n<=7 and 1<=h<=10 and 1<=w<=10 and len(rows)==n+1,'shape');tiles=tuple(ints(r,2) for r in rows[1:]);require(all(1<=a<=10 and 1<=b<=10 for a,b in tiles),'tiles');return h,w,tiles
 n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==3 and re.fullmatch(r'[01]{'+str(n)+'}',rows[1]) is not None,'shape');costs=ints(rows[2],n);require(all(1<=v<=10**9 for v in costs),'costs');return rows[1],costs
def exclusive_period_partition(n:int,m:int,k:int)->int:
 g=gcd(n,m);na=m//g-1;nb=n//g-1;period=n*(m//g);completed,rank=divmod(k-1,na+nb);rank+=1;low=max(0,rank-nb);high=min(rank,na);inf=10**30
 while low<=high:
  i=(low+high)//2;j=rank-i;left_a=n*i if i else -1;right_a=n*(i+1) if i<na else inf;left_b=m*j if j else -1;right_b=m*(j+1) if j<nb else inf
  if left_a>right_b:high=i-1
  elif left_b>right_a:low=i+1
  else:return completed*period+max(left_a,left_b)
 raise AssertionError('partition')
def square_pair_base_sieve(a:tuple[int,...])->int:
 frequencies=Counter(a);zeros=frequencies.get(0,0);n=len(a);maximum=max(a);squarefree=bytearray([1])*(maximum+1)
 for d in range(2,isqrt(maximum)+1):
  square=d*d
  for multiple in range(square,maximum+1,square):squarefree[multiple]=0
 answer=zeros*(n-zeros)+zeros*(zeros-1)//2
 for base in range(1,maximum+1):
  if not squarefree[base]:continue
  count=sum(frequencies.get(base*multiplier*multiplier,0) for multiplier in range(1,isqrt(maximum//base)+1));answer+=count*(count-1)//2
 return answer
def score_occupancy_tree(n:int,updates:tuple[tuple[int,...],...])->list[int]:
 scores=[0]*n;transitions=[];values={0}
 for player,increment in updates:
  old=scores[player-1];new=old+increment;scores[player-1]=new;transitions.append((old,new));values.add(new)
 coordinates={v:i for i,v in enumerate(sorted(values))};length=1
 while length<len(values):length*=2
 tree=[0]*(2*length);counts=[0]*len(values);counts[coordinates[0]]=n;tree[length+coordinates[0]]=1
 for node in range(length+coordinates[0]-1,0,-1):tree[node]=tree[2*node]+tree[2*node+1]
 def change(index:int,delta:int)->None:
  counts[index]+=delta;node=length+index;tree[node]=int(counts[index]>0);node//=2
  while node:tree[node]=tree[2*node]+tree[2*node+1];node//=2
 result=[]
 for old,new in transitions:change(coordinates[old],-1);change(coordinates[new],1);result.append(tree[1])
 return result
def bags_reverse_shortest(target:str,bags:tuple[tuple[str,...],...])->int:
 n=len(bags);distance={(n,len(target)):0};heap=[(0,n,len(target))]
 while heap:
  cost,bag,position=heapq.heappop(heap)
  if distance[bag,position]!=cost:continue
  if bag==0:
   if position==0:return cost
   continue
  edges=[(bag-1,position,0)]+[(bag-1,position-len(word),1) for word in bags[bag-1] if position>=len(word) and target[position-len(word):position]==word]
  for bb,pp,weight in edges:
   value=cost+weight
   if value<distance.get((bb,pp),10**9):distance[bb,pp]=value;heapq.heappush(heap,(value,bb,pp))
 return -1
def tiling_exact_cover(h:int,w:int,tiles:tuple[tuple[int,...],...])->bool:
 n=len(tiles);total=h*w;full=(1<<total)-1;options:list[list[tuple[int,int]]]=[[] for _ in range(total)];areas=[a*b for a,b in tiles]
 for tile,(aa,bb) in enumerate(tiles):
  for a,b in set(((aa,bb),(bb,aa))):
   for row in range(h-a+1):
    for column in range(w-b+1):
     mask=sum(((1<<b)-1)<<((row+r)*w+column) for r in range(a));cells=mask
     while cells:bit=cells&-cells;options[bit.bit_length()-1].append((tile,mask));cells-=bit
 @lru_cache(None)
 def reachable_area(used:int)->int:
  bits=1
  for i,area in enumerate(areas):
   if not used>>i&1:bits|=bits<<area
  return bits
 @lru_cache(None)
 def search(occupied:int,used:int)->bool:
  if occupied==full:return True
  remaining=full^occupied
  if not reachable_area(used)>>(total-occupied.bit_count())&1:return False
  best:list[tuple[int,int]]|None=None
  while remaining:
   bit=remaining&-remaining;remaining-=bit;candidates=[(tile,mask) for tile,mask in options[bit.bit_length()-1] if not used>>tile&1 and not mask&occupied]
   if not candidates:return False
   if best is None or len(candidates)<len(best):best=candidates
  assert best is not None
  return any(search(occupied|mask,used|1<<tile) for tile,mask in best)
 return search(0,0)
def single_equal_alternating(s:str,costs:tuple[int,...])->int:
 n=len(s);prefix=[0]*(n+1);cost_prefix=[0]*(n+1);total=sum(costs)
 for i,(char,cost) in enumerate(zip(s,costs)):
  prefix[i+1]=prefix[i]+(cost if int(char)!=i%2 else 0);cost_prefix[i+1]=cost_prefix[i]+cost
 answer=10**30
 for split in range(1,n):
  # One equal edge flips the alternating phase of the entire suffix.
  phase_zero=prefix[split]+total-cost_prefix[split]-(prefix[n]-prefix[split])
  answer=min(answer,phase_zero,total-phase_zero)
 return answer
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc341_d':return str(exclusive_period_partition(*cast(tuple[int,int,int],d)))+'\n'
 if pid=='abc342_d':return str(square_pair_base_sieve(cast(tuple[int,...],d[0])))+'\n'
 if pid=='abc343_d':return ''.join(str(v)+'\n' for v in score_occupancy_tree(cast(int,d[0]),cast(tuple[tuple[int,...],...],d[1])))
 if pid=='abc344_d':return str(bags_reverse_shortest(cast(str,d[0]),cast(tuple[tuple[str,...],...],d[1])))+'\n'
 if pid=='abc345_d':return ('Yes' if tiling_exact_cover(cast(int,d[0]),cast(int,d[1]),cast(tuple[tuple[int,...],...],d[2])) else 'No')+'\n'
 return str(single_equal_alternating(cast(str,d[0]),cast(tuple[int,...],d[1])))+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE:dict[str,str]={
'abc341_d':'''import math
n,m,k=map(int,input().split());l=n//math.gcd(n,m)*m
def count(x):return x//n+x//m-2*(x//l)
lo=0;hi=1
while count(hi)<k:hi*=2
while hi-lo>1:
 mid=(hi+lo)//2
 if count(mid)>=k:hi=mid
 else:lo=mid
print(hi)
''',
'abc342_d':'''from collections import Counter
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);a=list(it);mx=max(a);spf=list(range(mx+1))
for p in range(2,int(mx**0.5)+1):
 if spf[p]==p:
  for j in range(p*p,mx+1,p):
   if spf[j]==j:spf[j]=p
freq=Counter();zero=0;ans=0
for v in a:
 if v==0:zero+=1;continue
 kernel=1
 while v>1:
  p=spf[v];parity=0
  while v%p==0:v//=p;parity^=1
  if parity:kernel*=p
 ans+=freq[kernel];freq[kernel]+=1
print(ans+zero*(n-zero)+zero*(zero-1)//2)
''',
'abc343_d':'''from collections import Counter
import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);t=next(it);scores=[0]*n;freq=Counter({0:n});out=[]
for _ in range(t):
 a=next(it)-1;b=next(it);old=scores[a];freq[old]-=1
 if freq[old]==0:del freq[old]
 scores[a]+=b;freq[scores[a]]+=1;out.append(str(len(freq)))
print('\\n'.join(out))
''',
'abc344_d':'''t=input();n=int(input());inf=1000;dp=[inf]*(len(t)+1);dp[0]=0
for _ in range(n):
 fields=input().split();nxt=dp[:]
 for pos,cost in enumerate(dp):
  if cost==inf:continue
  for word in fields[1:]:
   if t.startswith(word,pos):nxt[pos+len(word)]=min(nxt[pos+len(word)],cost+1)
 dp=nxt
print(dp[-1] if dp[-1]<inf else -1)
''',
'abc345_d':'''from functools import lru_cache
n,h,w=map(int,input().split());tiles=[tuple(map(int,input().split())) for _ in range(n)];full=(1<<(h*w))-1
@lru_cache(None)
def solve(occ,used):
 if occ==full:return True
 bit=(full^occ)&-(full^occ);r,c=divmod(bit.bit_length()-1,w)
 for i,(aa,bb) in enumerate(tiles):
  if used>>i&1:continue
  for a,b in {(aa,bb),(bb,aa)}:
   if r+a>h or c+b>w:continue
   mask=sum(((1<<b)-1)<<((r+j)*w+c) for j in range(a))
   if not mask&occ and solve(occ|mask,used|1<<i):return True
 return False
print('Yes' if solve(0,0) else 'No')
''',
'abc346_d':'''n=int(input());s=input();c=list(map(int,input().split()));inf=10**30;dp=[[inf]*2 for _ in range(2)]
for b in range(2):dp[b][0]=c[0] if int(s[0])!=b else 0
for i in range(1,n):
 nxt=[[inf]*2 for _ in range(2)]
 for last in range(2):
  for used in range(2):
   for bit in range(2):
    uu=used+(last==bit)
    if uu<=1:nxt[bit][uu]=min(nxt[bit][uu],dp[last][used]+(c[i] if int(s[i])!=bit else 0))
 dp=nxt
print(min(dp[0][1],dp[1][1]))
'''}

def generate(pid:str)->list[Case]:
 rng=random.Random(197000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc341_d':
  triples=[(1,2,1),(2,1,1),(2,3,1),(2,3,2),(2,3,3),(2,4,2),(6,10,7),(99,100,197),(100,99,199),(1,10**8,10**10),(10**8,1,10**10),(99999999,10**8,10**10),(50000000,10**8,10**10)]
  triples += [(rng.randint(2,10000),rng.randint(10001,20000),rng.randint(1,10**10)) for _ in range(4)]
  triples.append((10**8,99999999,10**10));raws=[line(v) for v in triples]
 elif pid=='abc342_d':
  arrays=[(0,0),(0,1),(1,1),(2,8),(2,3),(0,0,1),(1,4,9,16),(2,8,18,32),(6,24,54,96),(200000,200000),(0,200000,199999),(1,2,3,4,5,6,7,8,9)]
  arrays += [tuple(rng.randint(0,200000) for _ in range(size)) for size in (17,100,1000)]
  arrays += [(0,)*200000,(200000,)*200000,tuple(range(1,200001))]
  raws=[line((len(a),))+line(a) for a in arrays]
 elif pid=='abc343_d':
  configurations=[(1,((1,1),)),(2,((1,1),)),(2,((1,1),(2,1))),(3,((1,1),(2,1),(3,1))),(3,((1,2),(2,1),(2,1))),(1,((1,10**9),)*4)]
  for i in range(10):
   n=2+i;t=5+i;configurations.append((n,tuple((rng.randint(1,n),rng.randint(1,10**9)) for _ in range(t))))
  configurations += [(200000,((1,10**9),)*200000),(200000,tuple((i+1,10**9) for i in range(200000)))]
  raws=[line((n,len(updates)))+''.join(line(u) for u in updates) for n,updates in configurations]
 elif pid=='abc344_d':
  configurations=[('a',(('a',),)),('a',(('b',),)),('aa',(('a',),)),('aa',(('a',),('a',))),('abc',(('a','ab'),('bc','c'))),('abc',(('abc','abc'),)),('aaa',(('a','aa'),('a','aa'))),('ab',(('b',),('a',))),('ab',(('a',),('b',))),('a'*100,(('a'*10,),)*10),('a'*100,(('b',),)*100)]
  for i in range(6):
   target=''.join(rng.choice('abc') for _ in range(3+i));bags=tuple(tuple(''.join(rng.choice('abc') for _ in range(rng.randint(1,4))) for _ in range(1+i%4)) for _ in range(3+i));configurations.append((target,bags))
  configurations.append(('a'*100,(('a'*10,)*10,)*100))
  raws=[target+'\n'+line((len(bags),))+''.join(str(len(bag))+' '+' '.join(bag)+'\n' for bag in bags) for target,bags in configurations]
 elif pid=='abc345_d':
  configurations=[(1,1,((1,1),)),(1,1,((2,2),)),(1,2,((2,1),)),(2,2,((1,2),(1,2))),(2,2,((1,1),)*3),(2,2,((2,2),(10,10))),(3,3,((2,2),(1,3),(1,2))),(3,3,((1,3),)*3),(3,4,((2,3),)*2),(4,4,((2,2),)*4),(3,5,((2,3),(3,3))),(4,5,((2,3),(2,3),(2,4))),(5,5,((5,5),)),(5,5,((3,3),(4,4))),(10,10,((1,10),)*7),(10,10,((10,10),)*7),(10,10,((2,10),)*5+((1,1),)*2),(10,10,((10,10),(9,10),(10,9),(9,9),(8,10),(10,8),(8,8)))]
  raws=[line((len(tiles),h,w))+''.join(line(tile) for tile in tiles) for h,w,tiles in configurations]
 else:
  configurations=[('00',(1,1)),('01',(1,1)),('10',(1,1)),('11',(1,1)),('000',(1,2,3)),('010',(1,2,3)),('0110',(10**9,1,1,10**9)),('10101',(1,)*5)]
  for n in (6,7,8,9,10,17,100,1000):configurations.append((''.join(rng.choice('01') for _ in range(n)),tuple(rng.randint(1,10**9) for _ in range(n))))
  configurations += [('01'*100000,(10**9,)*200000),('0'*200000,(10**9,)*200000)]
  raws=[line((len(s),))+s+'\n'+line(costs) for s,costs in configurations]
 require(len(raws)==len(set(raws))==18,'18 distinct')
 result=[]
 for i,raw in enumerate(raws):validate(pid,raw);result.append({'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'case_{i:02}'})
 return result

HINTS:dict[str,tuple[str,str,str]]={
'abc341_d':('値 x 以下にある、片方だけの倍数の個数を考えます。','N と M の最小公倍数の倍数は両方の列にあるので2回引きます。個数は単調増加します。','疑似コード: L=lcm(N,M); count(x)=x//N+x//M-2*(x//L); count(hi)>=K まで hi を倍増; 二分探索で count(x)>=K を初めて満たす x を返す。'),
'abc342_d':('積が平方数になる条件を、素因数の指数の偶奇で表せます。0 は別に数えます。','各正整数から平方数の因子を取り除いた核が等しい2要素だけが平方数の積を作ります。','疑似コード: 最小素因数をふるいで用意; 各正数を素因数分解し奇数回現れる素数の積を key とする; answer+=frequency[key]; frequency[key]++; 0 の個数 z に対して z*(N-z)+z*(z-1)//2 を加算。'),
'abc343_d':('各選手の得点に加え、得点ごとの人数を保持します。','更新前の得点の人数を減らし、0人なら削除します。更新後の得点の人数を増やします。','疑似コード: scores を0、frequency[0]=Nに初期化; 更新(a,b)ごとに old=scores[a]; frequency[old]--; 0ならkey削除; scores[a]+=b; frequency[scores[a]]++; key数を出力。'),
'abc344_d':('袋を順番に処理し、T のどこまで作れたかを状態にします。','同じ袋の文字列を複数回使わないよう、遷移先は新しい配列に書きます。袋を使わない選択も必要です。','疑似コード: dp[0]=0、他はINF; 各袋で next=dpのコピー; 各位置pと袋内文字列sで T[p:p+len(s)]==s なら next[p+len(s)]=min(next[p+len(s)],dp[p]+1); dp=next; 末尾がINFなら-1。'),
'abc345_d':('まだ埋まっていないマスを1つ選び、それを覆うタイルを試します。','タイルの使用済み集合と盤面を管理します。回転した向きも試し、全タイルを使う必要はありません。','疑似コード: search(board,used): 全マスが埋まればtrue; 最初の空きマス(r,c)を選択; 未使用タイルと縦横2向きを試す; (r,c)を左上として盤内かつ空きなら置いて再帰; 成功する枝がなければfalse。'),
'abc346_d':('左から決めると、必要なのは直前のビットと等しい隣接対の個数です。','等しい隣接対を1つだけ許すDPを作ります。文字を反転したときだけその位置の費用を払います。','疑似コード: dp[last][equalCount] を最小費用とする; 最初のビット2通りを初期化; 次のbitごとに newCount=equalCount+(last==bit); newCount<=1なら元文字と異なるときC[i]を加え遷移; 最後の equalCount=1 の最小値を返す。')}

TITLES={'abc341_d': 'Only one of two', 'abc342_d': 'Square Pair', 'abc343_d': 'Diversity of Scores', 'abc344_d': 'String Bags', 'abc345_d': 'Tiling', 'abc346_d': 'Gomamayo Sequence'}
PUBLISHED_SAMPLES={'abc341_d': [{'input': '2 3 5\n', 'expected': '9\n'}, {'input': '1 2 3\n', 'expected': '5\n'}, {'input': '100000000 99999999 10000000000\n', 'expected': '500000002500000000\n'}], 'abc342_d': [{'input': '5\n0 3 2 8 12\n', 'expected': '6\n'}, {'input': '8\n2 2 4 6 3 100 100 25\n', 'expected': '7\n'}], 'abc343_d': [{'input': '3 4\n1 10\n3 20\n2 10\n2 10\n', 'expected': '2\n3\n2\n2\n'}, {'input': '1 3\n1 3\n1 4\n1 3\n', 'expected': '1\n1\n1\n'}, {'input': '10 10\n7 2620\n9 2620\n8 3375\n1 3375\n6 1395\n5 1395\n6 2923\n10 3375\n9 5929\n5 1225\n', 'expected': '2\n2\n3\n3\n4\n4\n5\n5\n6\n5\n'}], 'abc344_d': [{'input': 'abcde\n3\n3 ab abc abcd\n4 f c cd bcde\n2 e de\n', 'expected': '2\n'}, {'input': 'abcde\n3\n2 ab abc\n3 f c bcde\n1 e\n', 'expected': '-1\n'}, {'input': 'aaabbbbcccc\n6\n2 aa aaa\n2 dd ddd\n2 ab aabb\n4 bbaa bbbc bbb bbcc\n2 cc bcc\n3 ccc cccc ccccc\n', 'expected': '4\n'}], 'abc345_d': [{'input': '5 5 5\n1 1\n3 3\n4 4\n2 3\n2 5\n', 'expected': 'Yes\n'}, {'input': '1 1 2\n2 3\n', 'expected': 'No\n'}, {'input': '1 2 2\n1 1\n', 'expected': 'No\n'}, {'input': '5 3 3\n1 1\n2 2\n2 2\n2 2\n2 2\n', 'expected': 'No\n'}], 'abc346_d': [{'input': '5\n00011\n3 9 2 6 4\n', 'expected': '7\n'}, {'input': '4\n1001\n1 2 3 4\n', 'expected': '0\n'}, {'input': '11\n11111100111\n512298012 821282085 543342199 868532399 690830957 973970164 928915367 954764623 923012648 540375785 925723427\n', 'expected': '2286846953\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
