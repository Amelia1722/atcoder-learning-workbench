"""Private reviewed ABC156--161 D tasks."""
from __future__ import annotations
from collections import deque
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(156,162));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS};OUTPUT_MODES:dict[str,str]={}
MOD=1000000007
Case=dict[str,str]
Data=tuple[object,...]
Query=tuple[int,...]|tuple[int,int,str]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def ints(s:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',s) is not None,'integers');a=tuple(map(int,s.split()));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank')
 if pid=='abc156_d':
  require(len(r)==1,'shape');n,a,b=ints(r[0],3);require(2<=n<=10**9 and 1<=a<b<=min(n,200000),'bouquet');return n,a,b
 if pid=='abc157_d':
  n,m,k=ints(r[0],3);require(2<=n<=100000 and 0<=m<=100000 and 0<=k<=100000 and len(r)==m+k+1,'shape');friends=tuple(ints(s,2) for s in r[1:m+1]);blocks=tuple(ints(s,2) for s in r[m+1:]);require(all(1<=a<=n and 1<=b<=n and a!=b for a,b in friends+blocks),'endpoints');f={tuple(sorted(e)) for e in friends};bset={tuple(sorted(e)) for e in blocks};require(len(f)==m and len(bset)==k and f.isdisjoint(bset),'unique/disjoint');return n,friends,blocks
 if pid=='abc158_d':
  require(len(r)>=3 and re.fullmatch(r'[a-z]{1,100000}',r[0]) is not None,'initial string');q=ints(r[1],1)[0];require(1<=q<=200000 and len(r)==q+2,'Q');queries:list[Query]=[]
  for row in r[2:]:
   if row=='1':queries.append((1,))
   else:
    require(re.fullmatch(r'2 [12] [a-z]',row) is not None,'query');_,f,c=row.split();queries.append((2,int(f),c))
  return r[0],tuple(queries)
 if pid=='abc159_d':
  require(len(r)==2,'shape');n=ints(r[0],1)[0];a=ints(r[1],n);require(3<=n<=200000 and all(1<=v<=n for v in a),'balls');return (a,)
 if pid=='abc160_d':
  require(len(r)==1,'shape');n,x,y=ints(r[0],3);require(3<=n<=2000 and 1<=x and x+1<y<=n,'shortcut');return n,x,y
 require(len(r)==1,'shape');k=ints(r[0],1)[0];require(1<=k<=100000,'rank');return (k,)
def segmented_binomial(n:int,k:int)->int:
 k=min(k,n-k)
 if k==0:return 1
 sieve=bytearray(b'\x01')*(k+1);sieve[:2]=b'\x00\x00'
 for p in range(2,int(k**0.5)+1):
  if sieve[p]:sieve[p*p::p]=b'\x00'*((k-p*p)//p+1)
 lo=n-k+1;values=list(range(lo,n+1));answer=1
 for p in range(2,k+1):
  if not sieve[p]:continue
  denominator=0;power=p
  while power<=k:denominator+=k//power;power*=p
  numerator=0
  for j in range((-lo)%p,k,p):
   while values[j]%p==0:values[j]//=p;numerator+=1
  require(numerator>=denominator,'prime valuation');answer=answer*pow(p,numerator-denominator,MOD)%MOD
 for v in values:answer=answer*v%MOD
 return answer
def friend_components(n:int,friends:tuple[tuple[int,int],...],blocks:tuple[tuple[int,int],...])->list[int]:
 adj:list[list[int]]=[[] for _ in range(n)]
 for a,b in friends:adj[a-1].append(b-1);adj[b-1].append(a-1)
 labels=[-1]*n;sizes=[]
 for start in range(n):
  if labels[start]>=0:continue
  label=len(sizes);labels[start]=label;stack=[start];count=0
  while stack:
   u=stack.pop();count+=1
   for v in adj[u]:
    if labels[v]<0:labels[v]=label;stack.append(v)
  sizes.append(count)
 answer=[sizes[labels[u]]-len(adj[u])-1 for u in range(n)]
 for a,b in blocks:
  if labels[a-1]==labels[b-1]:answer[a-1]-=1;answer[b-1]-=1
 return answer
def backward_string(s:str,queries:tuple[Query,...])->str:
 flipped=False;front:list[str]=[];back:list[str]=[]
 for q in queries[::-1]:
  if q[0]==1:flipped=not flipped
  else:
   _,f,c=cast(tuple[int,int,str],q)
   if (f==1)!=flipped:front.append(c)
   else:back.append(c)
 return ''.join(front)+(s[::-1] if flipped else s)+''.join(back[::-1])
def balls_group_exclusion(a:tuple[int,...])->list[int]:
 positions:dict[int,list[int]]={}
 for j,v in enumerate(a):positions.setdefault(v,[]).append(j)
 groups=list(positions.values());contributions=[len(g)*(len(g)-1)//2 for g in groups];prefix=[0]
 for c in contributions:prefix.append(prefix[-1]+c)
 suffix=[0]*(len(groups)+1)
 for j in range(len(groups)-1,-1,-1):suffix[j]=suffix[j+1]+contributions[j]
 answer=[0]*len(a)
 for j,g in enumerate(groups):
  remaining=len(g)-1;value=prefix[j]+suffix[j+1]+remaining*(remaining-1)//2
  for p in g:answer[p]=value
 return answer
def shortcut_bfs(n:int,x:int,y:int)->list[int]:
 adj:list[list[int]]=[[] for _ in range(n)]
 for j in range(n-1):adj[j].append(j+1);adj[j+1].append(j)
 adj[x-1].append(y-1);adj[y-1].append(x-1);answer=[0]*n
 for start in range(n):
  distances=[-1]*n;distances[start]=0;queue=deque([start])
  while queue:
   u=queue.popleft()
   for v in adj[u]:
    if distances[v]<0:distances[v]=distances[u]+1;queue.append(v)
  for v in range(start+1,n):answer[distances[v]]+=1
 return answer[1:]
def lunlun_unrank(k:int)->int:
 counts=[[1]*10]
 while True:
  length=len(counts);total=sum(counts[-1][1:])
  if k<=total:break
  k-=total;previous=counts[-1];counts.append([sum(previous[max(0,d-1):min(10,d+2)]) for d in range(10)])
 digits=[];candidates=range(1,10)
 for remaining in range(length-1,-1,-1):
  for d in candidates:
   ways=counts[remaining][d]
   if k>ways:k-=ways
   else:digits.append(str(d));candidates=range(max(0,d-1),min(10,d+2));break
 return int(''.join(digits))
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc156_d':
  n,a,b=cast(tuple[int,int,int],d);return f'{(pow(2,n,MOD)-1-segmented_binomial(n,a)-segmented_binomial(n,b))%MOD}\n'
 if pid=='abc157_d':return line(friend_components(*cast(tuple[int,tuple[tuple[int,int],...],tuple[tuple[int,int],...]],d)))
 if pid=='abc158_d':return backward_string(*cast(tuple[str,tuple[Query,...]],d))+'\n'
 if pid=='abc159_d':return ''.join(f'{v}\n' for v in balls_group_exclusion(cast(tuple[int,...],d[0])))
 if pid=='abc160_d':return ''.join(f'{v}\n' for v in shortcut_bfs(*cast(tuple[int,int,int],d)))
 return f'{lunlun_unrank(cast(int,d[0]))}\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc156_d':'''n,a,b=map(int,input().split());mod=1000000007
def choose(k):
 numerator=denominator=1
 for j in range(1,k+1):numerator=numerator*(n-j+1)%mod;denominator=denominator*j%mod
 return numerator*pow(denominator,mod-2,mod)%mod
print((pow(2,n,mod)-1-choose(a)-choose(b))%mod)
''',
'abc157_d':'''import sys
it=iter(map(int,sys.stdin.buffer.read().split()));n=next(it);m=next(it);k=next(it);parent=[-1]*n;degree=[0]*n
def find(v):
 while parent[v]>=0:
  if parent[parent[v]]>=0:parent[v]=parent[parent[v]]
  v=parent[v]
 return v
for _ in range(m):
 u=next(it)-1;v=next(it)-1;degree[u]+=1;degree[v]+=1;a=find(u);b=find(v)
 if a!=b:
  if parent[a]>parent[b]:a,b=b,a
  parent[a]+=parent[b];parent[b]=a
answer=[-parent[find(j)]-degree[j]-1 for j in range(n)]
for _ in range(k):
 u=next(it)-1;v=next(it)-1
 if find(u)==find(v):answer[u]-=1;answer[v]-=1
print(*answer)
''',
'abc158_d':'''from collections import deque
s=deque(input());q=int(input());rev=False
for _ in range(q):
 query=input().split()
 if query[0]=='1':rev=not rev
 else:
  _,f,c=query
  if (f=='1')!=rev:s.appendleft(c)
  else:s.append(c)
if rev:s.reverse()
print(''.join(s))
''',
'abc159_d':'''from collections import Counter
n=int(input());a=list(map(int,input().split()));count=Counter(a);total=sum(v*(v-1)//2 for v in count.values());print(*(total-count[v]+1 for v in a),sep='\\n')
''',
'abc160_d':'''n,x,y=map(int,input().split());answer=[0]*n
for i in range(1,n+1):
 for j in range(i+1,n+1):
  d=min(j-i,abs(i-x)+1+abs(j-y),abs(i-y)+1+abs(j-x));answer[d]+=1
print(*answer[1:],sep='\\n')
''',
'abc161_d':'''from collections import deque
k=int(input());q=deque(range(1,10))
for _ in range(k):
 v=q.popleft();d=v%10
 for c in range(max(0,d-1),min(9,d+1)+1):q.append(v*10+c)
print(v)
'''}
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'task');rng=random.Random(18700+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc156_d':raws=[f'{n} {a} {b}\n' for n,a,b in ((2,1,2),(3,1,2),(4,1,3),(5,2,5),(10,1,10),(100,1,2),(100,49,50),(100,99,100),(200000,1,200000),(200000,199999,200000),(200001,1,200000),(200001,199999,200000),(1000000,141421,173205),(999999999,1,2),(10**9,141421,173205),(10**9,1,200000),(10**9,199998,199999),(10**9,199999,200000))]
 elif pid=='abc157_d':
  def social(n:int,f:list[tuple[int,int]],b:list[tuple[int,int]])->str:return f'{n} {len(f)} {len(b)}\n'+''.join(line(e) for e in f+b)
  raws=[social(2,[],[]),social(2,[(2,1)],[]),social(2,[],[(1,2)]),social(3,[(1,2),(3,2)],[(3,1)])]
  for n in range(4,16):
   pairs=[(a,b) for a in range(1,n) for b in range(a+1,n+1)];rng.shuffle(pairs);f=pairs[:n];b=pairs[n:2*n];f=[e if j%2 else e[::-1] for j,e in enumerate(f)];raws.append(social(n,f,b))
  f=[(i,i+1) for i in range(1,100000)]+[(1,100000)];b=[(i,i+2) for i in range(1,99999)]+[(1,99999),(2,100000)];raws+=[social(100000,[],b),social(100000,f,b)]
 elif pid=='abc158_d':
  def text(s:str,q:list[str])->str:return s+'\n'+f'{len(q)}\n'+'\n'.join(q)+'\n'
  raws=[text('a',['1']),text('z',['2 1 a']),text('z',['2 2 a']),text('abc',['1','1'])]
  for n in range(1,13):raws.append(text(''.join(rng.choice('abcxyz') for _ in range(n)),[rng.choice(['1','2 1 a','2 2 z']) for _ in range(n+3)]))
  raws+=[text('a'*100000,['1']*200000),text('z'*100000,['2 1 z' if j%2 else '2 2 z' for j in range(200000)])]
 elif pid=='abc159_d':
  arrays=[[1,1,1],[1,2,3],[1,1,2],[3,3,3],[1,1,2,1,2],[1,2,1,4,2,1,4,1]]
  for n in range(4,14):arrays.append([rng.randint(1,n) for _ in range(n)])
  arrays+=[list(range(1,200001)),[200000]*200000];raws=[f'{len(a)}\n'+line(a) for a in arrays]
 elif pid=='abc160_d':raws=[f'{n} {x} {y}\n' for n,x,y in ((3,1,3),(4,1,3),(4,2,4),(5,2,4),(7,3,7),(10,4,8),(10,1,10),(10,1,3),(10,8,10),(11,3,9),(100,49,51),(100,1,100),(999,1,999),(1000,1,1000),(2000,999,1001),(2000,1,3),(2000,1,2000),(2000,1998,2000))]
 else:raws=[f'{k}\n' for k in (1,2,8,9,10,13,15,20,35,100,999,1000,10000,50000,99997,99998,99999,100000)]
 require(len(raws)==len(set(raws))==18,'distinct18')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}'} for j,raw in enumerate(raws)]
HINTS={
'abc156_d':('空集合以外の選び方から、a本とb本の選び方を引きます。','答えは2^n-1-C(n,a)-C(n,b)です。a,bは200000以下なので分子と分母を順に掛け、分母のmod逆元を使います。','疑似コード: comb(k)=product(n-j+1,j=1..k)*inverse(product(j,j=1..k)) mod; powmod(2,n)-1-comb(a)-comb(b)をmodで正規化して出力。'),
'abc157_d':('友達関係の辺でつながっている人だけが候補になります。','Union-Findで連結成分の人数を求め、本人・直接の友達・同じ成分内のブロック相手を除きます。','疑似コード: 友達全辺をunionしdegreeを計算; answer[i]=component_size(i)-1-degree[i]; ブロック辺u,vが同成分なら両answerを1減らす; 頂点順に出力。'),
'abc158_d':('文字列全体の反転を毎回実行せず、向きだけ記録します。','両端追加をdequeで行います。反転状態なら先頭と末尾への追加先を入れ替え、最後だけ実際に反転します。','疑似コード: deque(S),reverse=false; T1ならreverse反転; T2ならFとreverseで物理追加端を決めappendleft/append; 最後reverseなら反転して出力。'),
'abc159_d':('同じ数字がc個なら、選び方はc*(c-1)/2通りです。','最初の総組数を数えます。値A[k]のボールを一つ除くと、その値の組数だけc-1減ります。','疑似コード: count[value]を集計; total=sum(c*(c-1)/2); 各A[k]についてtotal-(count[A[k]]-1)を一行ずつ出力。'),
'abc160_d':('二点間の最短経路は、直線上の移動か追加辺を一度通る経路です。','全てのi<jを列挙し、直接距離と追加辺を両方向に使う距離の最小を数えます。Nは2000以下です。','疑似コード: 各i<jでd=min(j-i,abs(i-X)+1+abs(j-Y),abs(i-Y)+1+abs(j-X)); count[d]++; count[1..N-1]を出力。'),
'abc161_d':('末尾の数字との差が1以下の数字だけを後ろへ追加します。','1から9を初期キューとして幅優先に生成すると、小さい順に取り出せます。K回目に取り出した値が答えです。','疑似コード: queue=1..9; K回pop v; d=v%10; max(0,d-1)..min(9,d+1)をvの末尾へ付けた数をpush; 最後のvを出力。')}

TITLES={'abc156_d': 'Bouquet', 'abc157_d': 'Friend Suggestions', 'abc158_d': 'String Formation', 'abc159_d': 'Banned K', 'abc160_d': 'Line++', 'abc161_d': 'Lunlun Number'}
PUBLISHED_SAMPLES={'abc156_d': [{'input': '4 1 3\n', 'expected': '7\n'}, {'input': '1000000000 141421 173205\n', 'expected': '34076506\n'}], 'abc157_d': [{'input': '4 4 1\n2 1\n1 3\n3 2\n3 4\n4 1\n', 'expected': '0 1 0 1\n'}, {'input': '5 10 0\n1 2\n1 3\n1 4\n1 5\n3 2\n2 4\n2 5\n4 3\n5 3\n4 5\n', 'expected': '0 0 0 0 0\n'}, {'input': '10 9 3\n10 1\n6 7\n8 2\n2 5\n8 4\n7 3\n10 9\n6 4\n5 8\n2 6\n7 5\n3 1\n', 'expected': '1 3 5 4 3 3 3 3 1 0\n'}], 'abc158_d': [{'input': 'a\n4\n2 1 p\n1\n2 2 c\n1\n', 'expected': 'cpa\n'}, {'input': 'a\n6\n2 2 a\n2 1 b\n1\n2 2 c\n1\n1\n', 'expected': 'aabc\n'}, {'input': 'y\n1\n2 1 x\n', 'expected': 'xy\n'}], 'abc159_d': [{'input': '5\n1 1 2 1 2\n', 'expected': '2\n2\n3\n2\n3\n'}, {'input': '4\n1 2 3 4\n', 'expected': '0\n0\n0\n0\n'}, {'input': '5\n3 3 3 3 3\n', 'expected': '6\n6\n6\n6\n6\n'}, {'input': '8\n1 2 1 4 2 1 4 1\n', 'expected': '5\n7\n5\n7\n7\n5\n7\n5\n'}], 'abc160_d': [{'input': '5 2 4\n', 'expected': '5\n4\n1\n0\n'}, {'input': '3 1 3\n', 'expected': '3\n0\n'}, {'input': '7 3 7\n', 'expected': '7\n8\n4\n2\n0\n0\n'}, {'input': '10 4 8\n', 'expected': '10\n12\n10\n8\n4\n1\n0\n0\n0\n'}], 'abc161_d': [{'input': '15\n', 'expected': '23\n'}, {'input': '1\n', 'expected': '1\n'}, {'input': '13\n', 'expected': '21\n'}, {'input': '100000\n', 'expected': '3234566667\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
