"""Reviewed C tasks with water filling, lifetimes and residue joins."""
from __future__ import annotations
from itertools import product,groupby
from collections import defaultdict
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(365,371))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Queries=tuple[tuple[int,...],...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==365:
        require(len(rows)==2,'shape');n,m=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=200000 and 1<=m<=2*10**14 and all(1<=v<=10**9 for v in a),'subsidy');return m,a
    if number==366:
        q=ints(rows[0],1)[0];require(1<=q<=200000 and len(rows)==q+1,'shape');counts:dict[int,int]={};queries=[];reported=False
        for row in rows[1:]:
            a=ints(row);kind=a[0];require(kind in (1,2,3) and len(a)==(1 if kind==3 else 2),'query')
            if kind==3:reported=True
            else:
                x=a[1];require(1<=x<=10**6 and (kind==1 or counts.get(x,0)>0),'ball');counts[x]=counts.get(x,0)+(1 if kind==1 else -1)
            queries.append(a)
        require(reported,'report guarantee');return (tuple(queries),)
    if number==367:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);a=ints(rows[1],n);require(1<=n<=8 and 2<=k<=10 and all(1<=v<=5 for v in a),'bounds');return k,a
    if number in (368,369):
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=200000 and all(1<=v<=10**9 for v in a),'values');return (a,)
    require(len(rows)==2 and 1<=len(rows[0])<=100 and len(rows[0])==len(rows[1]) and all(re.fullmatch('[a-z]+',s) is not None for s in rows),'strings');return tuple(rows)
def damage(t:int)->int:return t+2*(t//3)
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==365:
        m,a=cast(tuple[int,tuple[int,...]],data)
        if sum(a)<=m:return 'infinite'
        spent=0;ordered=sorted(a);n=len(a)
        for j,v in enumerate(ordered):
            remaining=n-j
            if spent+remaining*v>m:return str((m-spent)//remaining)
            spent+=v
        raise ValueError('budget')
    if number==366:
        queries=cast(Queries,data[0]);events:dict[int,list[tuple[int,int]]]=defaultdict(list);requests=[]
        for t,q in enumerate(queries):
            if q[0]==3:requests.append(t)
            else:events[q[1]].append((t,1 if q[0]==1 else -1))
        boundaries=[]
        for seq in events.values():
            count=0
            for t,delta in seq:
                old=count;count+=delta
                if old==0:boundaries.append((t,1))
                elif count==0:boundaries.append((t,-1))
        boundaries.sort();out=[];p=0;active=0
        for t in requests:
            while p<len(boundaries) and boundaries[p][0]<t:active+=boundaries[p][1];p+=1
            out.append(str(active))
        return '\n'.join(out)
    if number==367:
        k,a=cast(tuple[int,tuple[int,...]],data);split=len(a)//2;right:dict[int,list[tuple[int,...]]]=defaultdict(list)
        for suffix in product(*(range(1,v+1) for v in a[split:])):right[sum(suffix)%k].append(suffix)
        out=[]
        for prefix in product(*(range(1,v+1) for v in a[:split])):
            for suffix in right[-sum(prefix)%k]:out.append(' '.join(map(str,prefix+suffix)))
        return '\n'.join(out)
    if number==368:
        a=cast(tuple[int,...],data[0]);t=0
        for health in a:
            target=damage(t)+health;low=t;high=t+health
            while high-low>1:
                middle=(low+high)//2
                if damage(middle)>=target:high=middle
                else:low=middle
            t=high
        return str(t)
    if number==369:
        a=cast(tuple[int,...],data[0]);answer=len(a)
        for _,seq in groupby(y-x for x,y in zip(a,a[1:])):length=sum(1 for _ in seq);answer+=length*(length+1)//2
        return str(answer)
    s,t=cast(tuple[str,str],data);current=s;out=[]
    while current!=t:
        current=min(current[:j]+t[j]+current[j+1:] for j in range(len(t)) if current[j]!=t[j]);out.append(current)
    return str(len(out))+('' if not out else '\n'+'\n'.join(out))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc365_c':"n,m=map(int,input().split());a=list(map(int,input().split()))\nif sum(a)<=m:print('infinite')\nelse:\n low=0;high=max(a)+1\n while high-low>1:\n  mid=(low+high)//2\n  if sum(min(mid,v) for v in a)<=m:low=mid\n  else:high=mid\n print(low)\n",
'abc366_c':"q=int(input());counts={};active=0\nfor _ in range(q):\n a=list(map(int,input().split()))\n if a[0]==3:print(active)\n else:\n  x=a[1];old=counts.get(x,0);new=old+(1 if a[0]==1 else -1);counts[x]=new;active+=(old==0)-(new==0)\n",
'abc367_c':"n,k=map(int,input().split());a=list(map(int,input().split()));prefix=[]\ndef visit(j,total):\n if j==n:\n  if total%k==0:print(*prefix)\n  return\n for v in range(1,a[j]+1):\n  prefix.append(v);visit(j+1,total+v);prefix.pop()\nvisit(0,0)\n",
'abc368_c':"n=int(input());a=list(map(int,input().split()));t=0\nfor h in a:\n t+=h//5*3;h%=5\n while h>0:\n  t+=1;h-=3 if t%3==0 else 1\nprint(t)\n",
'abc369_c':"n=int(input());a=list(map(int,input().split()));answer=n;length=0;previous=None\nfor x,y in zip(a,a[1:]):\n diff=y-x;length=length+1 if diff==previous else 1;answer+=length;previous=diff\nprint(answer)\n",
'abc370_c':"s=list(input());t=input();out=[]\norder=[j for j in range(len(s)) if s[j]>t[j]]+[j for j in range(len(s)-1,-1,-1) if s[j]<t[j]]\nfor j in order:s[j]=t[j];out.append(''.join(s))\nprint(len(out))\nif out:print(*out,sep='\\n')\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17200+number)
    if number==365:
        def subsidy(m:int,a:list[int])->str:return f'{len(a)} {m}\n'+line(a)
        raws=[subsidy(1,[1]),subsidy(1,[2]),subsidy(1,[1,1]),subsidy(4,[1,2,3])];raws.extend(subsidy(rng.randint(1,500),[rng.randint(1,100) for _ in range(n)]) for n in range(3,15));raws.extend([subsidy(2*10**14-1,[10**9]*200000),subsidy(2*10**14,[10**9]*200000)])
    elif number==366:
        def bag(qs:list[str])->str:return f'{len(qs)}\n'+'\n'.join(qs)+'\n'
        raws=[bag(qs) for qs in (['3'],['1 1','3'],['1 1','2 1','3'],['1 2','1 2','2 2','3'])]
        for n in range(3,15):
            counts:dict[int,int]={};qs=[]
            for _ in range(n+5):
                kind=rng.randint(1,3);present=[x for x,c in counts.items() if c]
                if kind==3:qs.append('3')
                elif kind==2 and present:x=rng.choice(present);qs.append(f'2 {x}');counts[x]-=1
                else:x=rng.randint(1,20);qs.append(f'1 {x}');counts[x]=counts.get(x,0)+1
            qs.append('3');raws.append(bag(qs))
        raws.extend([bag([f'1 {j+1}' for j in range(199999)]+['3']),bag(['1 1000000']*199999+['3'])])
    elif number==367:
        def sequences(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[sequences(k,a) for k,a in ((2,[1]),(2,[2]),(10,[5]),(2,[1,1]))]
        for j in range(12):n=2+j%7;k=2+j%9;a=[rng.randint(1,5) for _ in range(n)];raws.append(sequences(k,a))
        raws.extend([sequences(2,[5]*8),sequences(10,[5]*8)])
    elif number in (368,369):
        def arr(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[arr(a) for a in ([1],[2],[3],[1,2,3])];raws.extend(arr([rng.randint(1,30) for _ in range(n)]) for n in range(3,15));raws.extend([arr([1,2,4,5]*50000),arr([10**9]*200000)])
    else:
        def change(s:str,t:str)->str:return s+'\n'+t+'\n'
        raws=[change(s,t) for s,t in (('a','a'),('a','z'),('z','a'),('az','za'))];raws.extend(change(''.join(rng.choice('abcz') for _ in range(n)),''.join(rng.choice('abcz') for _ in range(n))) for n in range(3,15));raws.extend([change('az'*50,'za'*50),change('z'*100,'a'*100)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc365_c':('上限xが大きくなるほど支給総額は減りません。','全交通費を払えるならinfinite。それ以外は支給総額が予算以下の最大xを二分探索します。','疑似コード: sum(A)<=Mならinfinite; そうでなければlo=0,hi=max(A)+1; midのsum(min(mid,A[i]))<=Mならlo=mid、違えばhi=mid; hi-lo=1でloを出力。'),
'abc366_c':('値ごとに袋にある個数を数えます。','種類数が変わるのは0個から1個、または1個から0個になるときだけです。','疑似コード: count[x]を保持; 追加前0なら種類数++; 削除後0なら種類数--; 種類3のクエリで種類数を出力。'),
'abc367_c':('候補数列は最大5^8通りなので全部調べられます。','各位置を1からR[i]の順に選んで深さ優先探索すると辞書順になります。','疑似コード: visit(i,sum)でv=1..R[i]を順に末尾へ加え再帰; i=Nでsum%K=0なら現在列を出力。'),
'abc368_c':('どの時刻から始めても3回の攻撃の合計ダメージは5です。','体力を5で割った商の分だけ3回ずつ進め、残りは1回ずつ処理します。','疑似コード: 各HでT+=3*(H//5), H%=5; H>0の間T++しT%3=0なら3、そうでなければ1をHから引く; 最後のTを出力。'),
'abc369_c':('長さ2以上の等差数列では、隣り合う差がすべて同じです。','同じ差が続く長さを管理し、各右端で終わる等差部分列の数を足します。','疑似コード: answer=N; 隣接差dを左から見て前の差と同じならrun++、違えばrun=1; answer+=run; 合計を出力。'),
'abc370_c':('最小の操作回数はSとTで異なる位置の数です。','小さくする置換は左から、大きくする置換は右から行うと各途中文字列が辞書順最小になります。','疑似コード: S[i]>T[i]のiを昇順に置換して保存; 次にS[i]<T[i]のiを降順に置換して保存; 保存した列の長さと各文字列を出力。')}

TITLES={'abc365_c': 'Transportation Expenses', 'abc366_c': 'Balls and Bag Query', 'abc367_c': 'Enumerate Sequences', 'abc368_c': 'Triple Attack', 'abc369_c': 'Count Arithmetic Subarrays', 'abc370_c': 'Word Ladder'}
PUBLISHED_SAMPLES={'abc365_c': [{'input': '4 8\n1 3 2 4\n', 'expected': '2\n'}, {'input': '3 20\n5 3 2\n', 'expected': 'infinite\n'}, {'input': '10 23\n2 5 6 5 2 1 7 9 7 2\n', 'expected': '2\n'}], 'abc366_c': [{'input': '8\n1 3\n1 1\n1 4\n3\n2 1\n3\n1 5\n3\n', 'expected': '3\n2\n3\n'}, {'input': '8\n1 2\n1 2\n3\n2 2\n1 4\n1 4\n2 2\n3\n', 'expected': '1\n1\n'}], 'abc367_c': [{'input': '3 2\n2 1 3\n', 'expected': '1 1 2\n2 1 1\n2 1 3\n'}, {'input': '1 2\n1\n', 'expected': '\n'}, {'input': '5 5\n2 3 2 3 2\n', 'expected': '1 1 1 1 1\n1 2 2 3 2\n1 3 1 3 2\n1 3 2 2 2\n1 3 2 3 1\n2 1 2 3 2\n2 2 1 3 2\n2 2 2 2 2\n2 2 2 3 1\n2 3 1 2 2\n2 3 1 3 1\n2 3 2 1 2\n2 3 2 2 1\n'}], 'abc368_c': [{'input': '3\n6 2 2\n', 'expected': '8\n'}, {'input': '9\n1 12 123 1234 12345 123456 1234567 12345678 123456789\n', 'expected': '82304529\n'}, {'input': '5\n1000000000 1000000000 1000000000 1000000000 1000000000\n', 'expected': '3000000000\n'}], 'abc369_c': [{'input': '4\n3 6 9 3\n', 'expected': '8\n'}, {'input': '5\n1 1 1 1 1\n', 'expected': '15\n'}, {'input': '8\n87 42 64 86 72 58 44 30\n', 'expected': '22\n'}], 'abc370_c': [{'input': 'adbe\nbcbc\n', 'expected': '3\nacbe\nacbc\nbcbc\n'}, {'input': 'abcde\nabcde\n', 'expected': '0\n'}, {'input': 'afwgebrw\noarbrenq\n', 'expected': '8\naawgebrw\naargebrw\naarbebrw\naarbebnw\naarbebnq\naarbeenq\naarbrenq\noarbrenq\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
