"""Six reviewed C tasks with remainder states, offline queries and palindrome failure links."""
from __future__ import annotations
from collections import Counter,defaultdict
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(233,239))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
MOD=998244353
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==233:
        n,x=ints(rows[0],2);require(2<=n<=16 and 1<=x<=10**18 and len(rows)==n+1,'shape');bags=[];size=1
        for row in rows[1:]:
            values=ints(row);length=values[0];require(length>=2 and len(values)==length+1 and all(1<=v<=10**9 for v in values[1:]),'bag');size*=length;require(size<=100000,'choice product');bags.append(values[1:])
        return x,tuple(bags)
    if number in (234,238):
        require(len(rows)==1,'shape');n=ints(rows[0],1)[0];require(1<=n<=(10**18 if number==234 else 10**18-1),'rank/range');return (n,)
    if number==235:
        n,q=ints(rows[0],2);require(1<=n<=200000 and 1<=q<=200000 and len(rows)==q+2,'shape');a=ints(rows[1],n);queries=tuple(cast(Pair,ints(row,2)) for row in rows[2:]);require(all(0<=v<=10**9 for v in a) and all(0<=x<=10**9 and 1<=k<=n for x,k in queries),'queries');return a,queries
    if number==236:
        n,m=ints(rows[0],2);require(2<=m<=n<=100000 and len(rows)==3,'shape');s=tuple(rows[1].split(' '));t=tuple(rows[2].split(' '));require(len(s)==n and len(t)==m and len(set(s))==n and all(re.fullmatch('[a-z]{1,10}',name) is not None for name in s+t),'stations');positions={name:j for j,name in enumerate(s)};require(t[0]==s[0] and t[-1]==s[-1] and all(name in positions for name in t) and all(positions[a]<positions[b] for a,b in zip(t,t[1:])),'ordered stops');return s,t
    require(len(rows)==1 and re.fullmatch('[a-z]{1,1000000}',rows[0]) is not None,'word');return (rows[0],)

def _prefix_palindrome(s:str)->bool:
    pattern=s+'|'+s[::-1];failure=[0]*len(pattern)
    for j in range(1,len(pattern)):
        length=failure[j-1]
        while length and pattern[j]!=pattern[length]:length=failure[length-1]
        if pattern[j]==pattern[length]:length+=1
        failure[j]=length
    return all(ch=='a' for ch in s[failure[-1]:])

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==233:
        x,bags=cast(tuple[int,tuple[tuple[int,...],...]],data);states={x:1}
        for bag in bags:
            following:dict[int,int]=defaultdict(int)
            for value,duplicates in Counter(bag).items():
                for remaining,count in states.items():
                    if remaining%value==0:following[remaining//value]+=count*duplicates
            states=following
        return str(states.get(1,0))
    if number==234:
        k=cast(int,data[0]);width=1;block=1
        while k>block:k-=block;width+=1;block*=2
        offset=k-1;answer='2'
        for bit in range(width-2,-1,-1):
            weight=1<<bit
            if offset>=weight:answer+='2';offset-=weight
            else:answer+='0'
        return answer
    if number==235:
        a,queries=cast(tuple[tuple[int,...],tuple[Pair,...]],data);requested:dict[Pair,list[int]]=defaultdict(list)
        for j,query in enumerate(queries):requested[query].append(j)
        counts:Counter[int]=Counter();answer=[-1]*len(queries)
        for index,value in enumerate(a,1):
            counts[value]+=1
            for j in requested.get((value,counts[value]),[]):answer[j]=index
        return '\n'.join(map(str,answer))
    if number==236:
        s,t=cast(tuple[tuple[str,...],tuple[str,...]],data);j=0;answer=[]
        for name in s:
            if j<len(t) and name==t[j]:answer.append('Yes');j+=1
            else:answer.append('No')
        return '\n'.join(answer)
    if number==237:return 'Yes' if _prefix_palindrome(cast(str,data[0])) else 'No'
    n=cast(int,data[0]);width=len(str(n));blocks=width-1;full=(81*((100**blocks-1)//99)+9*((10**blocks-1)//9))//2;partial=n-10**blocks+1;return str((full+partial*(partial+1)//2)%MOD)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError,ZeroDivisionError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc233_c':"n,x=map(int,input().split());bags=[list(map(int,input().split()))[1:] for _ in range(n)];answer=0\ndef dfs(j,value):\n global answer\n if j==n:\n  answer+=value==x;return\n for a in bags[j]:\n  if value*a<=x:dfs(j+1,value*a)\ndfs(0,1);print(answer)\n",
'abc234_c':"k=int(input());print(bin(k)[2:].replace('1','2'))\n",
'abc235_c':"from collections import defaultdict\nn,q=map(int,input().split());a=list(map(int,input().split()));positions=defaultdict(list)\nfor j,v in enumerate(a,1):positions[v].append(j)\nfor _ in range(q):\n x,k=map(int,input().split());print(positions[x][k-1] if len(positions[x])>=k else -1)\n",
'abc236_c':"n,m=map(int,input().split());s=input().split();t=set(input().split());print(*('Yes' if name in t else 'No' for name in s),sep='\\n')\n",
'abc237_c':"s=input();left=len(s)-len(s.lstrip('a'));right=len(s)-len(s.rstrip('a'));core=s.strip('a');print('Yes' if left<=right and core==core[::-1] else 'No')\n",
'abc238_c':"n=int(input());mod=998244353;start=1;answer=0\nwhile start<=n:\n count=min(n,start*10-1)-start+1;answer=(answer+count*(count+1)//2)%mod;start*=10\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16500+number)
    if number==233:
        def bags(x:int,a:list[list[int]])->str:return f'{len(a)} {x}\n'+''.join(line([len(row)]+row) for row in a)
        raws=[bags(1,[[1,1],[1,1]]),bags(1,[[2,2],[1,1]]),bags(6,[[1,2,3],[2,3]]),bags(10**18,[[10**9]*2,[10**9]*2])]
        for j in range(1,13):raws.append(bags(rng.randint(1,100000),[[rng.randint(1,20) for _ in range(2+j%3)] for _ in range(2+j%4)]))
        raws.extend([bags(1,[[1,1] for _ in range(16)]),bags(10**18,[[10**9]*50000,[10**9]*2])])
    elif number==234:raws=[f'{n}\n' for n in (1,2,3,4,7,8,9,15,16,17,31,32,33,10**9,2**59-1,2**59,10**18-1,10**18)]
    elif number==235:
        def queries(a:list[int],q:list[Pair])->str:return f'{len(a)} {len(q)}\n'+line(a)+''.join(line(row) for row in q)
        raws=[queries([0],[(0,1)]),queries([0],[(1,1)]),queries([10**9],[(10**9,1)]),queries([1,1],[(1,1),(1,2),(2,1)])]
        for n in range(3,15):raws.append(queries([rng.randint(0,10) for _ in range(n)],[(rng.randint(0,12),rng.randint(1,n)) for _ in range(n*2)]))
        raws.extend([queries(list(range(200000)),[(v,1) for v in range(199999,-1,-1)]),queries([10**9]*200000,[(10**9,200000)]*200000)])
    elif number==236:
        def route(s:list[str],t:list[str])->str:return f'{len(s)} {len(t)}\n'+' '.join(s)+'\n'+' '.join(t)+'\n'
        def name(j:int)->str:
            text=''
            for _ in range(10):text+=chr(97+j%26);j//=26
            return text
        raws=[route(['a','b'],['a','b']),route(['a','b','c'],['a','c']),route(['a','b','c'],['a','b','c']),route(['z','b','a'],['z','a'])]
        for n in range(4,16):s=[name(j) for j in range(n)];t=[s[0]]+[name(j) for j in range(1,n-1) if rng.randrange(2)]+[s[-1]];raws.append(route(s,t))
        s=[name(j) for j in range(100000)];raws.extend([route(s,[s[0],s[-1]]),route(s,s)])
    elif number==237:raws=[s+'\n' for s in ('a','b','aa','ab','ba','aba','aab','baa','aabaa','aaaba','kasaka','atcoder','php','abba','aabbaa','aabbaaa','b'+'a'*999999,'z'*1000000)]
    else:raws=[f'{n}\n' for n in (1,2,9,10,11,99,100,101,999,1000,1001,998244352,998244353,10**9,10**12-1,10**17,10**18-2,10**18-1)]
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc233_c':('各袋から一つずつ選ぶ方法の総数は10万以下です。','袋を順に選んで積を更新するDFSを行います。正整数なので、Xを超える積はそこで打ち切れます。同じ数のボールも別々に数えます。','疑似コード: DFS(bag,product): if all bags chosen: answer+=(product==X); else: for value in bag: if product*value<=X: DFS(next,product*value); print(answer)。'),
'abc234_c':('0と2だけの数を並べると、0と1だけの二進数と対応します。','Kの二進表現に含まれる1を2に置き換えます。非常に大きな十進整数として出力されるので、文字列のまま扱えます。','疑似コード: digits=binary(K) without prefix; print(replace(digits,1,2))。'),
'abc235_c':('各値が現れる位置を、先頭からの順番で記録します。','値ごとに位置の配列を作り、クエリのk番目を参照します。配列の長さが足りなければ-1です。','疑似コード: for (i,value) in A: positions[value].append(i); for (x,k): print(positions[x][k-1] if size>=k else -1)。'),
'abc236_c':('急行が止まる駅の名前をまとめて記録できます。','急行の駅名を集合にし、普通列車の駅を順に見て、その集合に含まれているか確認します。','疑似コード: express=set(T); for station in S: print(Yes if station in express else No)。'),
'abc237_c':('先頭と末尾に連続しているaを分けて考えます。','先頭のaが末尾より多ければ不可能です。両端のaを除いた中央部分が回文なら、足りない先頭のaを補えます。全てaの場合も可能です。','疑似コード: left=count leading a; right=count trailing a; core=strip both-end a; print(Yes if left<=right and core==reverse(core) else No)。'),
'abc238_c':('桁数が同じ区間では、f(x)は1,2,3,...と増えます。','1桁、2桁と区切り、その区間に含まれる数の個数countからcount*(count+1)/2を加えます。','疑似コード: start=1; while start<=N: count=min(N,10*start-1)-start+1; answer+=count*(count+1)/2 mod998244353; start*=10; print(answer)。')}

TITLES={'abc233_c': 'Product', 'abc234_c': 'Happy New Year!', 'abc235_c': 'The Kth Time Query', 'abc236_c': 'Route Map', 'abc237_c': 'kasaka', 'abc238_c': 'digitnum'}
PUBLISHED_SAMPLES={'abc233_c': [{'input': '2 40\n3 1 8 4\n2 10 5\n', 'expected': '2\n'}, {'input': '3 200\n3 10 10 10\n3 10 10 10\n5 2 2 2 2 2\n', 'expected': '45\n'}, {'input': '3 1000000000000000000\n2 1000000000 1000000000\n2 1000000000 1000000000\n2 1000000000 1000000000\n', 'expected': '0\n'}], 'abc234_c': [{'input': '3\n', 'expected': '22\n'}, {'input': '11\n', 'expected': '2022\n'}, {'input': '923423423420220108\n', 'expected': '220022020000202020002022022000002020002222002200002022002200\n'}], 'abc235_c': [{'input': '6 8\n1 1 2 3 1 2\n1 1\n1 2\n1 3\n1 4\n2 1\n2 2\n2 3\n4 1\n', 'expected': '1\n2\n5\n-1\n3\n6\n-1\n-1\n'}, {'input': '3 2\n0 1000000000 999999999\n1000000000 1\n123456789 1\n', 'expected': '2\n-1\n'}], 'abc236_c': [{'input': '5 3\ntokyo kanda akiba okachi ueno\ntokyo akiba ueno\n', 'expected': 'Yes\nNo\nYes\nNo\nYes\n'}, {'input': '7 7\na t c o d e r\na t c o d e r\n', 'expected': 'Yes\nYes\nYes\nYes\nYes\nYes\nYes\n'}], 'abc237_c': [{'input': 'kasaka\n', 'expected': 'Yes\n'}, {'input': 'atcoder\n', 'expected': 'No\n'}, {'input': 'php\n', 'expected': 'Yes\n'}], 'abc238_c': [{'input': '16\n', 'expected': '73\n'}, {'input': '238\n', 'expected': '13870\n'}, {'input': '999999999999999999\n', 'expected': '762062362\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
