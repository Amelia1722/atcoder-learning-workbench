"""Statement-checked three-stage hints for ABC284–286 B."""
HINTS_V142 = {
    'abc284_b': (
        '各テストケースは独立です。必要なのは、その数列の中に奇数が何個あるかだけです。',
        '各A_iについて `A_i % 2 == 1` か確認し、真ならカウンタを1増やします。これをT個のテストケースごとに繰り返します。',
        '疑似コード:\nread T\nrepeat T times:\n  read N, A\n  ans = 0\n  for x in A:\n    if x % 2 == 1: ans += 1\n  print(ans)',
    ),
    'abc285_b': (
        'iを固定したら、Sの先頭とi文字後ろを左から比較し、初めて同じ文字になった位置で止めればよいです。',
        'iごとにk=0から始め、`S[k] != S[k+i]` の間だけkを増やします。同じ文字になった時点、または比較できる範囲の末尾まで進んだ時点のkが答えです。N≤5000なのでO(N^2)で間に合います。',
        '疑似コード:\nfor i = 1 .. N-1:\n  l = 0\n  while l+i < N and S[l] != S[l+i]:\n    l += 1\n  print(l)',
    ),
    'abc286_b': (
        '`na`を見つけたときだけ`nya`へ置き換えます。置換後の文字列を再び探索する必要はありません。',
        '左から走査し、現在文字と次文字が`n`,`a`なら`nya`を追加して2文字進み、それ以外なら現在文字をそのまま追加して1文字進みます。Pythonなら `S.replace("na", "nya")` でも同じ結果になります。',
        '疑似コード:\ni = 0\nans = ""\nwhile i < N:\n  if i+1 < N and S[i:i+2] == "na":\n    ans += "nya"; i += 2\n  else:\n    ans += S[i]; i += 1\nprint(ans)',
    ),
}
