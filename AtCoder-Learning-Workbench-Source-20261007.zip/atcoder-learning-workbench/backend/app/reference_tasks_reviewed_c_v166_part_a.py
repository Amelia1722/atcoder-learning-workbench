"""Six reviewed C tasks: move differences, bitsets, line windows and marginal gains."""
from __future__ import annotations
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in (239,240,241,243,245,246))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
Pair=tuple[int,int]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==239:
        require(len(rows)==1,'shape');coordinates=ints(rows[0],4);require(all(-10**9<=v<=10**9 for v in coordinates) and coordinates[:2]!=coordinates[2:],'points');return coordinates
    if number==240:
        n,x=ints(rows[0],2);require(1<=n<=100 and 1<=x<=10000 and len(rows)==n+1,'shape');jumps=tuple(cast(Pair,ints(row,2)) for row in rows[1:]);require(all(1<=a<b<=100 for a,b in jumps),'jumps');return x,jumps
    if number==241:
        n=ints(rows[0],1)[0];require(6<=n<=1000 and len(rows)==n+1 and all(len(row)==n and set(row)<={'.','#'} for row in rows[1:]),'grid');return (tuple(rows[1:]),)
    if number==243:
        n=ints(rows[0],1)[0];require(2<=n<=200000 and len(rows)==n+2,'shape');points=tuple(cast(Pair,ints(row,2)) for row in rows[1:-1]);s=rows[-1];require(len(set(points))==n and all(0<=v<=10**9 for p in points for v in p) and len(s)==n and set(s)<={'L','R'},'people');return points,s
    if number==245:
        n,k=ints(rows[0],2);require(1<=n<=200000 and 0<=k<=10**9 and len(rows)==3,'shape');a=ints(rows[1],n);b=ints(rows[2],n);require(all(1<=v<=10**9 for v in a+b),'elements');return k,a,b
    n,k,x=ints(rows[0],3);require(1<=n<=200000 and 1<=k<=10**9 and 1<=x<=10**9 and len(rows)==2,'shape');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'prices');return k,x,a

def _window_line(line:list[bool])->bool:
    count=sum(line[:5])
    for j in range(5,len(line)):
        count+=line[j]
        if count>=4:return True
        count-=line[j-5]
    return False

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==239:
        x,y,u,v=cast(tuple[int,int,int,int],data);moves=[(a,b) for a in range(-2,3) for b in range(-2,3) if a*a+b*b==5];differences={(a-c,b-d) for a,b in moves for c,d in moves};return 'Yes' if (u-x,v-y) in differences else 'No'
    if number==240:
        x,jumps=cast(tuple[int,tuple[Pair,...]],data);baseline=sum(a for a,b in jumps);target=x-baseline
        if target<0:return 'No'
        bits=1
        for a,b in jumps:bits|=bits<<(b-a)
        return 'Yes' if bits>>target&1 else 'No'
    if number==241:
        grid=cast(tuple[str,...],data[0]);n=len(grid)
        for row in grid:
            if _window_line([ch=='#' for ch in row]):return 'Yes'
        for c in range(n):
            if _window_line([grid[r][c]=='#' for r in range(n)]):return 'Yes'
        for direction in (-1,1):
            starts=[(0,c) for c in range(n)]+[(r,0 if direction==1 else n-1) for r in range(1,n)]
            for r,c in starts:
                diagonal=[]
                while r<n and 0<=c<n:diagonal.append(grid[r][c]=='#');r+=1;c+=direction
                if _window_line(diagonal):return 'Yes'
        return 'No'
    if number==243:
        points,s=cast(tuple[tuple[Pair,...],str],data);rights:dict[int,int]={};lefts:dict[int,int]={}
        for (x,y),direction in zip(points,s):
            if direction=='R':rights[y]=min(rights.get(y,10**9+1),x)
            else:lefts[y]=max(lefts.get(y,-1),x)
        return 'Yes' if any(x<lefts.get(y,-1) for y,x in rights.items()) else 'No'
    if number==245:
        k,a,b=cast(tuple[int,tuple[int,...],tuple[int,...]],data);reachable={a[-1],b[-1]}
        for j in range(len(a)-2,-1,-1):reachable={v for v in (a[j],b[j]) if any(abs(v-next_value)<=k for next_value in reachable)}
        return 'Yes' if reachable else 'No'
    k,x,a=cast(tuple[int,int,tuple[int,...]],data);full=sum(v//x for v in a);residual=[v%x for v in a];positive=sum(v>0 for v in residual)
    if k>=full+positive:return '0'
    lo=1;hi=x+1
    while hi-lo>1:
        mid=(lo+hi)//2;count=full+sum(v>=mid for v in residual)
        if count>=k:lo=mid
        else:hi=mid
    count_above=(full if x>lo else 0)+sum(v>lo for v in residual);sum_above=(full*x if x>lo else 0)+sum(v for v in residual if v>lo);return str(sum(a)-sum_above-(k-count_above)*lo)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc239_c':"x,y,u,v=map(int,input().split());moves=[(1,2),(1,-2),(-1,2),(-1,-2),(2,1),(2,-1),(-2,1),(-2,-1)];print('Yes' if any((x+a-u)**2+(y+b-v)**2==5 for a,b in moves) else 'No')\n",
'abc240_c':"n,x=map(int,input().split());reachable={0}\nfor _ in range(n):\n a,b=map(int,input().split());reachable={v+d for v in reachable for d in (a,b) if v+d<=x}\nprint('Yes' if x in reachable else 'No')\n",
'abc241_c':"n=int(input());s=[input() for _ in range(n)];answer=False\nfor r in range(n):\n for c in range(n):\n  for dr,dc in ((0,1),(1,0),(1,1),(1,-1)):\n   rr=r+5*dr;cc=c+5*dc\n   if 0<=rr<n and 0<=cc<n and sum(s[r+j*dr][c+j*dc]=='#' for j in range(6))>=4:answer=True;break\n  if answer:break\n if answer:break\nprint('Yes' if answer else 'No')\n",
'abc243_c':"from collections import defaultdict\nn=int(input());p=[tuple(map(int,input().split())) for _ in range(n)];s=input();rows=defaultdict(list)\nfor (x,y),d in zip(p,s):rows[y].append((x,d))\nanswer=False\nfor row in rows.values():\n right=False\n for x,d in sorted(row):\n  if d=='R':right=True\n  elif right:answer=True\nprint('Yes' if answer else 'No')\n",
'abc245_c':"n,k=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));left=right=True\nfor j in range(1,n):\n left,right=(left and abs(a[j]-a[j-1])<=k) or (right and abs(a[j]-b[j-1])<=k),(left and abs(b[j]-a[j-1])<=k) or (right and abs(b[j]-b[j-1])<=k)\nprint('Yes' if left or right else 'No')\n",
'abc246_c':"n,k,x=map(int,input().split());a=list(map(int,input().split()));used=min(k,sum(v//x for v in a));answer=sum(a)-used*x;k-=used\nif k:answer-=sum(sorted((v%x for v in a),reverse=True)[:k])\nprint(answer)\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(16600+number)
    if number==239:raws=[line(p) for p in [(-10**9,-10**9,-10**9+1,-10**9+1),(0,0,1,1),(0,0,2,2),(0,0,3,3),(0,0,4,0),(0,0,0,4),(0,0,1,0),(0,0,0,1),(0,0,2,0),(0,0,0,2),(0,0,3,1),(0,0,1,3),(0,0,-3,-3),(0,0,4,4),(0,0,5,0),(10**9,10**9,10**9-1,10**9-1),(-10**9,10**9,10**9,-10**9),(-10**9,-10**9,10**9,10**9)]]
    elif number==240:
        def jumps(x:int,p:list[Pair])->str:return f'{len(p)} {x}\n'+''.join(line(t) for t in p)
        raws=[jumps(1,[(1,2)]),jumps(3,[(1,2)]),jumps(2,[(1,2)]),jumps(4,[(1,2),(1,2)])]
        for n in range(3,15):p=[tuple(sorted(rng.sample(range(1,101),2))) for _ in range(n)];raws.append(jumps(rng.randint(1,10000),cast(list[Pair],p)))
        raws.extend([jumps(5050,[(1,100)]*100),jumps(10000,[(99,100)]*100)])
    elif number==241:
        def board(n:int,cells:set[Pair])->str:return f'{n}\n'+''.join(''.join('#' if (r,c) in cells else '.' for c in range(n))+'\n' for r in range(n))
        raws=[board(6,set()),board(6,{(0,c) for c in range(4)}),board(6,{(r,0) for r in range(4)}),board(6,{(r,r) for r in range(4)})]
        for n in range(7,19):raws.append(board(n,{(r,c) for r in range(n) for c in range(n) if rng.randrange(10)==0}))
        raws.extend([board(1000,set()),board(1000,{(r,c) for r in range(1000) for c in range(1000)})])
    elif number==243:
        def collision(p:list[Pair],s:str)->str:return f'{len(p)}\n'+''.join(line(t) for t in p)+s+'\n'
        raws=[collision([(0,0),(1,0)],'LL'),collision([(0,0),(1,0)],'RL'),collision([(0,0),(1,0)],'LR'),collision([(0,0),(0,1)],'RL')]
        for n in range(3,15):raws.append(collision(rng.sample([(x,y) for x in range(20) for y in range(5)],n),''.join(rng.choice('LR') for _ in range(n))))
        raws.extend([collision([(j,10**9) for j in range(200000)],'L'*100000+'R'*100000),collision([(j,10**9) for j in range(199999)]+[(10**9,10**9)],'R'*199999+'L')])
    elif number==245:
        def elements(k:int,a:list[int],b:list[int])->str:return f'{len(a)} {k}\n'+line(a)+line(b)
        raws=[elements(0,[1],[1]),elements(0,[1,2],[2,1]),elements(0,[1,2],[3,4]),elements(1,[1,3],[2,4])]
        for n in range(3,15):raws.append(elements(rng.randint(0,100),[rng.randint(1,1000) for _ in range(n)],[rng.randint(1,1000) for _ in range(n)]))
        raws.extend([elements(0,[1]*199999+[10**9],[1]*199999+[10**9]),elements(10**9,[10**9]*200000,[10**9]*200000)])
    else:
        def coupons(k:int,x:int,a:list[int])->str:return f'{len(a)} {k} {x}\n'+line(a)
        raws=[coupons(1,1,[1]),coupons(1,2,[1]),coupons(1,3,[7]),coupons(3,3,[7])]
        for n in range(3,15):raws.append(coupons(rng.randint(1,1000),rng.randint(1,1000),[rng.randint(1,10**9) for _ in range(n)]))
        raws.extend([coupons(300000,500000000,[500000001+j for j in range(200000)]),coupons(10**9,10**9,[10**9]*200000)])
    require(len(raws)==len(set(raws))==18,'18 unique')
    for raw in raws:validate(pid,raw)
    return [{'category':'minimum' if j==0 else 'constraint_max' if j==17 else f'adversarial_{j:02}','input':raw} for j,raw in enumerate(raws)]
HINTS={
'abc239_c':('距離が√5となる移動は、縦横の変化が1と2の組み合わせです。','最初の点から8通りの候補を調べ、もう一方の点からの距離の二乗が5か確認します。候補座標は入力範囲の外でも構いません。','疑似コード: for (dx,dy) in eight knight moves: p=(x1+dx,y1+dy); if squared_distance(p,p2)==5: Yes; if none: No。'),
'abc240_c':('何回ジャンプしたかと、到達できる座標を状態にします。','各ジャンプで、前の座標にaまたはbを足した新しい座標を作ります。途中のX到達ではなく、N回後にXがあるか判定します。','疑似コード: reachable={0}; for (a,b): reachable={v+d for v in reachable for d in (a,b) if v+d<=X}; print(Yes if X in reachable else No)。'),
'abc241_c':('6マスの列に、すでに黒いマスが4つ以上あれば足りない分を塗れます。','全ての開始位置と、横・縦・二つの斜め方向を調べます。盤面内の6マスに含まれる黒の数を数えます。','疑似コード: for start and direction: if endpoint after5 steps inside board: if count black among6>=4: Yes; if none: No。'),
'abc243_c':('衝突する二人は同じ行にいて、左の人がR、右の人がLです。','Y座標ごとにまとめ、X座標順に見ます。Rを見た後にLがあれば衝突します。','疑似コード: group people by Y; for row sorted by X: right_seen=False; for direction: if R: right_seen=True; elif right_seen: Yes; if none: No。'),
'abc245_c':('各位置でAを選ぶ場合とBを選ぶ場合の到達可否を持ちます。','前の位置の二つの状態それぞれから、差がK以下で移れるか確認し、次の二つの状態を同時に更新します。','疑似コード: canA=canB=True; for i=1..N-1: nextA=(canA and abs(A[i]-A[i-1])<=K) or (canB and abs(A[i]-B[i-1])<=K); nextB similarly; canA,canB=nextA,nextB; print(Yes if either else No)。'),
'abc246_c':('一枚でX円引けるクーポンを先に使うのが最も有利です。','各価格のXによる商を合計し、その枚数までX円ずつ引きます。余りのクーポンは価格の余りが大きい商品から0円にします。','疑似コード: used=min(K,sum(A[i]//X)); answer=sum(A)-used*X; K-=used; answer-=sum(largest K values of A[i]%X); print(answer)。')}

TITLES={'abc239_c': 'Knight Fork', 'abc240_c': 'Jumping Takahashi', 'abc241_c': 'Connect 6', 'abc243_c': 'Collision 2', 'abc245_c': 'Choose Elements', 'abc246_c': 'Coupon'}
PUBLISHED_SAMPLES={'abc239_c': [{'input': '0 0 3 3\n', 'expected': 'Yes\n'}, {'input': '0 1 2 3\n', 'expected': 'No\n'}, {'input': '1000000000 1000000000 999999999 999999999\n', 'expected': 'Yes\n'}], 'abc240_c': [{'input': '2 10\n3 6\n4 5\n', 'expected': 'Yes\n'}, {'input': '2 10\n10 100\n10 100\n', 'expected': 'No\n'}, {'input': '4 12\n1 8\n5 7\n3 4\n2 6\n', 'expected': 'Yes\n'}], 'abc241_c': [{'input': '8\n........\n........\n.#.##.#.\n........\n........\n........\n........\n........\n', 'expected': 'Yes\n'}, {'input': '6\n######\n######\n######\n######\n######\n######\n', 'expected': 'Yes\n'}, {'input': '10\n..........\n#..##.....\n..........\n..........\n....#.....\n....#.....\n.#...#..#.\n..........\n..........\n..........\n', 'expected': 'No\n'}], 'abc243_c': [{'input': '3\n2 3\n1 1\n4 1\nRRL\n', 'expected': 'Yes\n'}, {'input': '2\n1 1\n2 1\nRR\n', 'expected': 'No\n'}, {'input': '10\n1 3\n1 4\n0 0\n0 2\n0 4\n3 1\n2 4\n4 2\n4 4\n3 3\nRLRRRLRLRR\n', 'expected': 'Yes\n'}], 'abc245_c': [{'input': '5 4\n9 8 3 7 2\n1 6 2 9 5\n', 'expected': 'Yes\n'}, {'input': '4 90\n1 1 1 100\n1 2 3 100\n', 'expected': 'No\n'}, {'input': '4 1000000000\n1 1 1000000000 1000000000\n1 1000000000 1 1000000000\n', 'expected': 'Yes\n'}], 'abc246_c': [{'input': '5 4 7\n8 3 10 5 13\n', 'expected': '12\n'}, {'input': '5 100 7\n8 3 10 5 13\n', 'expected': '0\n'}, {'input': '20 815 60\n2066 3193 2325 4030 3725 1669 1969 763 1653 159 5311 5341 4671 2374 4513 285 810 742 2981 202\n', 'expected': '112\n'}]}
SAMPLE_COUNTS={p:len(a) for p,a in PUBLISHED_SAMPLES.items()}
