"""Private ABC303..308 D: exact domains and independent oracles."""
from __future__ import annotations
from collections import Counter,deque
from itertools import groupby
from typing import cast
import random,re
TASKS=tuple(f'abc{i}_d' for i in range(303,309))
CONTESTS={p:p.split('_')[0] for p in TASKS}
PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
CHECKER_IDS:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'fields');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank')
 if pid=='abc303_d':
  require(len(rows)==2,'shape');costs=ints(rows[0],3);require(all(1<=v<=10**9 for v in costs) and re.fullmatch(r'[aA]{1,300000}',rows[1]) is not None,'range');return costs,rows[1]
 if pid=='abc304_d':
  w,h=ints(rows[0],2);require(3<=w<=10**9 and 3<=h<=10**9,'board');n=ints(rows[1],1)[0];require(1<=n<=200000 and len(rows)==n+6,'shape');points=tuple(ints(r,2) for r in rows[2:2+n]);na=ints(rows[2+n],1)[0];a=ints(rows[3+n],na);nb=ints(rows[4+n],1)[0];b=ints(rows[5+n],nb);require(1<=na<=200000 and 1<=nb<=200000,'cuts');require(0<a[0]<=a[-1]<w and 0<b[0]<=b[-1]<h and all(x<y for x,y in zip(a,a[1:])) and all(x<y for x,y in zip(b,b[1:])),'sortedcuts');aset=set(a);bset=set(b);require(len(set(points))==n and all(0<x<w and 0<y<h and x not in aset and y not in bset for x,y in points),'points');return w,h,points,a,b
 if pid=='abc305_d':
  n=ints(rows[0],1)[0];require(3<=n<200000 and n%2==1 and len(rows)>=4,'shape');a=ints(rows[1],n);require(a[0]==0 and a[-1]<=10**9 and all(x<y for x,y in zip(a,a[1:])),'times');q=ints(rows[2],1)[0];require(1<=q<=200000 and len(rows)==q+3,'Q');queries=tuple(ints(r,2) for r in rows[3:]);require(all(0<=l<=r<=a[-1] for l,r in queries),'queries');return a,queries
 if pid=='abc306_d':
  n=ints(rows[0],1)[0];require(1<=n<=300000 and len(rows)==n+1,'shape');dishes=tuple(ints(r,2) for r in rows[1:]);require(all(x in (0,1) and abs(y)<=10**9 for x,y in dishes),'dishes');return (dishes,)
 if pid=='abc307_d':
  n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==2 and len(rows[1])==n and re.fullmatch(r'[a-z()]+',rows[1]) is not None,'S');return (rows[1],)
 h,w=ints(rows[0],2);require(2<=h<=500 and 2<=w<=500 and len(rows)==h+1 and all(len(r)==w and re.fullmatch(r'[a-z]+',r) is not None for r in rows[1:]),'grid');return (tuple(rows[1:]),)
def caps_runs(costs:tuple[int,...],s:str)->int:
 x,y,z=costs;best=[0,10**30]
 for char,group in groupby(s):
  length=sum(1 for _ in group);wanted=int(char=='A');typed=[x if state==wanted else y for state in (0,1)]
  best=[min(best[state]+min(length*typed[state]+(state!=end)*z,z+length*typed[1-state]+(1-state!=end)*z) for state in (0,1)) for end in (0,1)]
 return min(best)
def cake_sweep(points:tuple[tuple[int,...],...],a:tuple[int,...],b:tuple[int,...])->tuple[int,int]:
 def groups(coordinate:int,cuts:tuple[int,...])->list[int]:
  result=[0]*len(points);j=0
  for value,index in sorted((p[coordinate],i) for i,p in enumerate(points)):
   while j<len(cuts) and cuts[j]<value:j+=1
   result[index]=j
  return result
 columns=groups(0,a);rows=groups(1,b);counts=Counter(zip(columns,rows));maximum=max(counts.values());minimum=min(counts.values()) if len(counts)==(len(a)+1)*(len(b)+1) else 0;return minimum,maximum
def sleep_endpoint_sweep(a:tuple[int,...],queries:tuple[tuple[int,...],...])->list[int]:
 endpoints=sorted({v for query in queries for v in query});value:dict[int,int]={};j=0;total=0;previous=0
 for time in endpoints:
  while j+1<len(a) and a[j+1]<=time:
   boundary=a[j+1]
   if j%2:total+=boundary-previous
   previous=boundary;j+=1
  if j%2:total+=time-previous
  previous=time;value[time]=total
 return [value[r]-value[l] for l,r in queries]
def poison_suffix(dishes:tuple[tuple[int,...],...])->int:
 healthy=sick=0
 for kind,value in reversed(dishes):
  if kind==0:healthy,sick=max(healthy,value+healthy),max(sick,value+healthy)
  else:healthy=max(healthy,value+sick)
 return healthy
def parentheses_intervals(s:str)->str:
 stack:list[int]=[];difference=[0]*(len(s)+1)
 for i,c in enumerate(s):
  if c=='(':stack.append(i)
  elif c==')' and stack:start=stack.pop();difference[start]+=1;difference[i+1]-=1
 active=0;out=[]
 for i,c in enumerate(s):
  active+=difference[i]
  if active==0:out.append(c)
 return ''.join(out)
def snuke_reverse_rows(grid:tuple[str,...])->bool:
 h=len(grid);w=len(grid[0]);word='snuke'
 if grid[0][0]!='s' or grid[-1][-1] not in word:return False
 masks=[[0]*h for _ in range(5)]
 for row,s in enumerate(grid):
  for column,char in enumerate(s):
   if char in word:masks[word.index(char)][row]|=1<<column
 visited=[0]*h;pending=[0]*h;queued=[False]*h;visited[-1]=pending[-1]=1<<(w-1);queue=deque([h-1]);queued[-1]=True
 def add(row:int,bits:int)->None:
  new=bits&~visited[row]
  if new:
   visited[row]|=new;pending[row]|=new
   if not queued[row]:queue.append(row);queued[row]=True
 while queue:
  row=queue.popleft();queued[row]=False;delta=pending[row];pending[row]=0
  for phase in range(5):
   bits=delta&masks[phase][row]
   if not bits:continue
   prior=masks[(phase-1)%5];add(row,((bits<<1)|(bits>>1))&prior[row])
   if row:add(row-1,bits&prior[row-1])
   if row+1<h:add(row+1,bits&prior[row+1])
  if visited[0]&1:return True
 return False
def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc303_d':return str(caps_runs(cast(tuple[int,...],d[0]),cast(str,d[1])))+'\n'
 if pid=='abc304_d':return line(cake_sweep(cast(tuple[tuple[int,...],...],d[2]),cast(tuple[int,...],d[3]),cast(tuple[int,...],d[4])))
 if pid=='abc305_d':return ''.join(str(v)+'\n' for v in sleep_endpoint_sweep(cast(tuple[int,...],d[0]),cast(tuple[tuple[int,...],...],d[1])))
 if pid=='abc306_d':return str(poison_suffix(cast(tuple[tuple[int,...],...],d[0])))+'\n'
 if pid=='abc307_d':return parentheses_intervals(cast(str,d[0]))+'\n'
 return ('Yes' if snuke_reverse_rows(cast(tuple[str,...],d[0])) else 'No')+'\n'
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,TypeError,IndexError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)
REFERENCE_CODE={
'abc303_d':'''x,y,z=map(int,input().split());s=input();dp=[0,10**30]
for c in s:
 wanted=int(c=='A');start=[min(dp[0],dp[1]+z),min(dp[1],dp[0]+z)];dp=[start[mode]+(x if mode==wanted else y) for mode in (0,1)]
print(min(dp))
''',
'abc304_d':'''from collections import Counter
from bisect import bisect_left
import sys
read=sys.stdin.buffer.readline;w,h=map(int,read().split());n=int(read());points=[tuple(map(int,read().split())) for _ in range(n)];na=int(read());a=list(map(int,read().split()));nb=int(read());b=list(map(int,read().split()));counts=Counter((bisect_left(a,x),bisect_left(b,y)) for x,y in points)
print(min(counts.values()) if len(counts)==(na+1)*(nb+1) else 0,max(counts.values()))
''',
'abc305_d':'''from bisect import bisect_right
import sys
read=sys.stdin.buffer.readline;n=int(read());a=list(map(int,read().split()));prefix=[0]*n
for i in range(1,n):prefix[i]=prefix[i-1]+(a[i]-a[i-1] if i%2==0 else 0)
def total(t):
 i=bisect_right(a,t)-1;return prefix[i]+(t-a[i] if i%2 else 0)
out=[]
for _ in range(int(read())):
 l,r=map(int,read().split());out.append(str(total(r)-total(l)))
print('\\n'.join(out))
''',
'abc306_d':'''import sys
read=sys.stdin.buffer.readline;healthy=0;sick=-10**30
for _ in range(int(read())):
 kind,value=map(int,read().split())
 if kind==0:healthy=max(healthy,healthy+value,sick+value)
 else:sick=max(sick,healthy+value)
print(max(healthy,sick))
''',
'abc307_d':'''n=int(input());s=input();out=[];opens=[]
for c in s:
 if c=='(':opens.append(len(out));out.append(c)
 elif c==')' and opens:del out[opens.pop():]
 else:out.append(c)
print(''.join(out))
''',
'abc308_d':'''from collections import deque
h,w=map(int,input().split());grid=[input() for _ in range(h)];word='snuke';queue=deque();seen=set()
if grid[0][0]=='s':queue.append((0,0));seen.add((0,0))
while queue:
 r,c=queue.popleft();nextchar=word[(word.index(grid[r][c])+1)%5]
 for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
  rr,cc=r+dr,c+dc
  if 0<=rr<h and 0<=cc<w and (rr,cc) not in seen and grid[rr][cc]==nextchar:seen.add((rr,cc));queue.append((rr,cc))
print('Yes' if (h-1,w-1) in seen else 'No')
'''}
def generate(pid:str)->list[Case]:
 require(pid in TASKS,'pid');rng=random.Random(195000+TASKS.index(pid));raws:list[str]=[]
 if pid=='abc303_d':
  def caps(x:int,y:int,z:int,s:str)->str:return f'{x} {y} {z}\n{s}\n'
  raws=[caps(1,1,1,'a'),caps(1,10**9,1,'A'),caps(10**9,1,10**9,'a'),caps(1,3,3,'AAaA')]
  for n in range(2,14):raws.append(caps(rng.randint(1,10**9),rng.randint(1,10**9),rng.randint(1,10**9),''.join(rng.choice('aA') for _ in range(n))))
  raws+=[caps(1,10**9,1,'A'*150000+'a'*150000),caps(10**9,10**9,10**9,'aA'*150000)]
 elif pid=='abc304_d':
  def cake(w:int,h:int,points:list[tuple[int,int]],a:list[int],b:list[int])->str:return f'{w} {h}\n{len(points)}\n'+''.join(line(p) for p in points)+f'{len(a)}\n'+line(a)+f'{len(b)}\n'+line(b)
  raws=[cake(3,3,[(1,1)],[2],[2]),cake(4,4,[(1,1),(1,3),(3,1),(3,3)],[2],[2]),cake(10**9,10**9,[(999999999,999999999)],[1],[1]),cake(6,6,[(1,1),(1,2),(2,1),(2,2)],[3],[3])]
  for n in range(3,15):w=h=2*n+3;a=list(range(2,w-1,2));b=list(range(2,h-1,2));points=rng.sample([(x,y) for x in range(1,w,2) for y in range(1,h,2)],n);raws.append(cake(w,h,points,a,b))
  raws+=[cake(10**9,10**9,[(2*i+1,2*i+1) for i in range(200000)],list(range(2,400002,2)),list(range(2,400002,2))),cake(10**9,10**9,[(999999999-i,999999999) for i in range(200000)],list(range(1,200001)),list(range(1,200001)))]
 elif pid=='abc305_d':
  def sleep(a:list[int],queries:list[tuple[int,int]])->str:return f'{len(a)}\n'+line(a)+f'{len(queries)}\n'+''.join(line(q) for q in queries)
  raws=[sleep([0,1,2],[(0,0)]),sleep([0,1,2],[(0,2),(1,1),(2,2)]),sleep([0,1,10**9],[(0,10**9)]),sleep([0,5,10],[(0,5),(5,10),(4,6)])]
  for count in range(1,13):a=[0]+sorted(rng.sample(range(1,1001),2*count));queries=[tuple(sorted((rng.randrange(a[-1]+1),rng.randrange(a[-1]+1)))) for _ in range(count+1)];raws.append(sleep(a,queries))
  a=[0]+list(range(1,199998))+[10**9];raws+=[sleep(a,[(i,10**9-i) for i in range(200000)]),sleep(a,[(0,10**9)]*200000)]
 elif pid=='abc306_d':
  def dishes(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
  raws=[dishes([(0,-10**9)]),dishes([(1,10**9)]),dishes([(1,1),(1,2)]),dishes([(1,100),(1,300),(0,-200),(1,500),(1,300)])]
  for n in range(2,14):raws.append(dishes([(rng.randrange(2),rng.randint(-10**9,10**9)) for _ in range(n)]))
  raws+=[dishes([(1,10**9),(0,-1)]*150000),dishes([(0,10**9)]*300000)]
 elif pid=='abc307_d':
  strings=['a','(',')','()','a(b(d))c','a(b)(',')))(((','((a)','a))b((','(a)(b)','(a(b)c)d','(a)b)c(',')a(b)c(', 'abcxyz','(abc','abc)','('*100000+')'*100000,'a'*200000];raws=[f'{len(s)}\n{s}\n' for s in strings]
 else:
  def grid(a:list[str])->str:return f'{len(a)} {len(a[0])}\n'+'\n'.join(a)+'\n'
  raws=[grid(['aa','aa']),grid(['sn','au']),grid(['sn','uk']),grid(['ss','nu'])]
  for size in range(3,15):a=[''.join(rng.choice('snukea') for _ in range(size)) for _ in range(size)];a[0]='s'+a[0][1:];raws.append(grid(a))
  raws+=[grid([''.join('snuke'[(r+c)%5] for c in range(500)) for r in range(500)]),grid(['s'+'a'*499]+['a'*500]*499)]
 require(len(raws)==len(set(raws))==18,'18distinct')
 for raw in raws:validate(pid,raw)
 return [{'input':raw,'category':'minimum' if i==0 else 'constraint_max' if i==17 else f'adversarial_{i:02}'} for i,raw in enumerate(raws)]
HINTS={
'abc303_d':('入力済み文字数とCapsLockの状態を記録します。','各文字の前にCapsLockを切り替えるか、そのままかを考え、文字入力の費用を加えます。','疑似コード: dp=[0,INF]; 各文字でstart[mode]=min(dp[mode],dp[1-mode]+Z); next[mode]=start[mode]+(modeと文字の大小が合えばX、他Y); dp=next; min(dp)出力。'),
'abc304_d':('各イチゴがどの長方形に入るかを調べます。','縦・横の切断位置を二分探索し、同じ区画にある個数を数えます。区画数より記録した区画数が少なければ最小値は0です。','疑似コード: 各(p,q)の区画=(lower_bound(a,p),lower_bound(b,q)); count[区画]++; maxはcount最大; 記録区画数<(A+1)(B+1)ならmin=0、他count最小; min,max出力。'),
'abc305_d':('時刻tまでに寝ていた時間を求めれば、質問は二つの差になります。','起床時刻・就寝時刻ごとの睡眠時間累積を用意し、tの直前の記録を二分探索します。寝ている区間の途中なら端数を加えます。','疑似コード: 各記録で睡眠区間の長さをprefixへ加算; total(t)は直前indexのprefixと、その区間が睡眠ならt-A[index]; 各[l,r]でtotal(r)-total(l)出力。'),
'abc306_d':('お腹を壊していない状態と、壊している状態を分けます。','各料理を食べない場合も残します。解毒料理はどちらからも健康に戻れ、毒料理は健康な場合だけ食べられます。','疑似コード: healthy=0,sick=-INF; 解毒料理ならhealthy=max(healthy,healthy+Y,sick+Y); 毒料理ならsick=max(sick,healthy+Y); 最後max(healthy,sick)出力。'),
'abc307_d':('左から文字を積み、対応する開き括弧の位置を記録します。','閉じ括弧が来たとき、対応する開き括弧があれば、その位置以降の文字をまとめて取り除きます。対応しない括弧は残ります。','疑似コード: out=[],opens=[]; (なら現在out長をopensへ記録し追加; )かつopens非空ならout[opens.pop():]削除; 他はoutへ追加; out連結出力。'),
'abc308_d':('次に移動できる文字は、現在の文字から一意に決まります。','左上がsなら幅優先探索を始めます。snukeの次の文字がある隣接マスだけへ進みます。','疑似コード: 左上sならqueue開始; pop(r,c)してnext=snuke内の次文字; 上下左右の盤内未訪問next文字へ追加; 右下訪問ならYes、他No。')}

TITLES={'abc303_d': 'Shift vs. CapsLock', 'abc304_d': 'A Piece of Cake', 'abc305_d': 'Sleep Log', 'abc306_d': 'Poisonous Full-Course', 'abc307_d': 'Mismatched Parentheses', 'abc308_d': 'Snuke Maze'}
PUBLISHED_SAMPLES={'abc303_d': [{'input': '1 3 3\nAAaA\n', 'expected': '9\n'}, {'input': '1 1 100\naAaAaA\n', 'expected': '6\n'}, {'input': '1 2 4\naaAaAaaAAAAaAaaAaAAaaaAAAAA\n', 'expected': '40\n'}], 'abc304_d': [{'input': '7 6\n5\n6 1\n3 1\n4 2\n1 5\n6 2\n2\n2 5\n2\n3 4\n', 'expected': '0 2\n'}, {'input': '4 4\n4\n1 1\n3 1\n3 3\n1 3\n1\n2\n1\n2\n', 'expected': '1 1\n'}], 'abc305_d': [{'input': '7\n0 240 720 1320 1440 1800 2160\n3\n480 1920\n720 1200\n0 2160\n', 'expected': '480\n0\n960\n'}, {'input': '21\n0 20 62 192 284 310 323 324 352 374 409 452 486 512 523 594 677 814 838 946 1000\n10\n77 721\n255 541\n478 970\n369 466\n343 541\n42 165\n16 618\n222 592\n730 983\n338 747\n', 'expected': '296\n150\n150\n49\n89\n20\n279\n183\n61\n177\n'}], 'abc306_d': [{'input': '5\n1 100\n1 300\n0 -200\n1 500\n1 300\n', 'expected': '600\n'}, {'input': '4\n0 -1\n1 -2\n0 -3\n1 -4\n', 'expected': '0\n'}, {'input': '15\n1 900000000\n0 600000000\n1 -300000000\n0 -700000000\n1 200000000\n1 300000000\n0 -600000000\n1 -900000000\n1 600000000\n1 -100000000\n1 -400000000\n0 900000000\n0 200000000\n1 -500000000\n1 900000000\n', 'expected': '4100000000\n'}], 'abc307_d': [{'input': '8\na(b(d))c\n', 'expected': 'ac\n'}, {'input': '5\na(b)(\n', 'expected': 'a(\n'}, {'input': '2\n()\n', 'expected': '\n'}, {'input': '6\n)))(((\n', 'expected': ')))(((\n'}], 'abc308_d': [{'input': '2 3\nsns\neuk\n', 'expected': 'Yes\n'}, {'input': '2 2\nab\ncd\n', 'expected': 'No\n'}, {'input': '5 7\nskunsek\nnukesnu\nukeseku\nnsnnesn\nuekukku\n', 'expected': 'Yes\n'}]}
SAMPLE_COUNTS={p:len(PUBLISHED_SAMPLES[p]) for p in TASKS}
