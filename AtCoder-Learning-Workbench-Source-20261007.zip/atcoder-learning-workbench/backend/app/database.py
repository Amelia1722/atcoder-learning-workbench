from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "atcoder_learning.sqlite3"

SCHEMA = r"""
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS problems (
  problem_id TEXT PRIMARY KEY,
  contest_id TEXT NOT NULL,
  problem_index TEXT NOT NULL,
  title TEXT NOT NULL,
  contest_title TEXT,
  contest_start_epoch INTEGER,
  difficulty INTEGER,
  is_experimental INTEGER NOT NULL DEFAULT 0,
  url TEXT NOT NULL,
  last_synced_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_problems_contest ON problems(contest_id, problem_index);
CREATE INDEX IF NOT EXISTS idx_problems_difficulty ON problems(difficulty);

CREATE TABLE IF NOT EXISTS tags (
  problem_id TEXT NOT NULL REFERENCES problems(problem_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  source TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  PRIMARY KEY(problem_id, tag, source)
);
CREATE INDEX IF NOT EXISTS idx_tags_tag ON tags(tag);

CREATE TABLE IF NOT EXISTS roadmap (
  problem_id TEXT NOT NULL,
  section TEXT NOT NULL,
  phase TEXT NOT NULL,
  description TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  PRIMARY KEY(problem_id, phase)
);

CREATE TABLE IF NOT EXISTS knowledge_sections (
  anchor TEXT PRIMARY KEY,
  heading TEXT NOT NULL,
  level INTEGER NOT NULL,
  chapter TEXT,
  importance TEXT,
  body_markdown TEXT NOT NULL,
  search_text TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_knowledge_heading ON knowledge_sections(heading);

CREATE TABLE IF NOT EXISTS knowledge_tag_links (
  tag TEXT NOT NULL,
  anchor TEXT NOT NULL REFERENCES knowledge_sections(anchor) ON DELETE CASCADE,
  source TEXT NOT NULL,
  rank INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(tag, anchor)
);
CREATE INDEX IF NOT EXISTS idx_knowledge_tag_links_tag ON knowledge_tag_links(tag);

CREATE TABLE IF NOT EXISTS submissions (
  submission_id INTEGER PRIMARY KEY,
  epoch_second INTEGER NOT NULL,
  problem_id TEXT NOT NULL,
  contest_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  language TEXT,
  point REAL,
  length INTEGER,
  result TEXT NOT NULL,
  execution_time INTEGER,
  source_code TEXT,
  source_fetched_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_submissions_user_time ON submissions(user_id, epoch_second);
CREATE INDEX IF NOT EXISTS idx_submissions_problem ON submissions(problem_id, epoch_second);

CREATE TABLE IF NOT EXISTS solve_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  problem_id TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  ended_at INTEGER,
  elapsed_seconds INTEGER,
  first_ac_submission_id INTEGER,
  status TEXT NOT NULL DEFAULT 'active',
  UNIQUE(user_id, problem_id, started_at)
);
CREATE INDEX IF NOT EXISTS idx_sessions_active ON solve_sessions(user_id, status);

CREATE TABLE IF NOT EXISTS imported_history (
  problem_id TEXT PRIMARY KEY,
  wa_count INTEGER,
  solve_seconds INTEGER,
  note TEXT
);

CREATE TABLE IF NOT EXISTS problem_notes (
  user_id TEXT NOT NULL,
  problem_id TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(user_id, problem_id)
);

CREATE TABLE IF NOT EXISTS atlas_learning_state (
  user_id TEXT PRIMARY KEY,
  state_json TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sync_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
"""


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=30)
    try:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        return con
    except BaseException:
        con.close()
        raise


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    con = connect()
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db() -> None:
    with db() as con:
        con.executescript(SCHEMA)


def get_setting(key: str, default: Any = None) -> Any:
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    if not row:
        return default
    try:
        return json.loads(row["value"])
    except Exception:
        return row["value"]


def set_setting(key: str, value: Any) -> None:
    raw = json.dumps(value, ensure_ascii=False)
    with db() as con:
        con.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, raw),
        )


def get_state(key: str, default: str | None = None) -> str | None:
    with db() as con:
        row = con.execute("SELECT value FROM sync_state WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_state(key: str, value: str) -> None:
    with db() as con:
        con.execute(
            "INSERT INTO sync_state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
