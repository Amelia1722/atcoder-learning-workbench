"""Manually reviewed ABC003–005 B inputs; independent answer oracles.

These are local interpretations of public statements, NOT authenticated HTML.
"""
from __future__ import annotations
import random
import re

TASKS = ('abc003_2', 'abc004_2', 'abc005_2')
ALLOWED = frozenset('atcoder')
SYMBOLS = frozenset('.ox')


def validate(pid: str, raw: str) -> object:
    if not isinstance(raw, str) or not raw.endswith('\n') or '\r' in raw:
        raise ValueError('input must end with LF')
    lines = raw[:-1].split('\n')
    if pid == 'abc003_2':
        if (len(lines) != 2 or len(lines[0]) != len(lines[1])
                or not 1 <= len(lines[0]) <= 10
                or any(re.fullmatch('[a-z@]+', line, re.ASCII) is None for line in lines)):
            raise ValueError('bad card strings')
        return tuple(lines)
    if pid == 'abc004_2':
        rows = [line.split(' ') for line in lines]
        if (len(rows) != 4 or any(len(row) != 4 for row in rows)
                or any(cell not in SYMBOLS for row in rows for cell in row)
                or any(' '.join(row) != line for row, line in zip(rows, lines))):
            raise ValueError('bad 4x4 grid')
        return rows
    if pid == 'abc005_2':
        if len(lines) < 2 or any(re.fullmatch(r'(?:0|[1-9][0-9]*)', line) is None for line in lines):
            raise ValueError('bad integer lines')
        n = int(lines[0])
        if not 1 <= n <= 100 or len(lines) != n + 1:
            raise ValueError('wrong count')
        nums = [int(line) for line in lines[1:]]
        if any(not 1 <= value <= 100 for value in nums):
            raise ValueError('out of domain')
        return nums
    raise ValueError('unknown task')


def independent_answer(pid: str, raw: str) -> str:
    data = validate(pid, raw)
    if pid == 'abc003_2':
        s, t = data
        can = all(a == b or (a == '@' and b in ALLOWED) or
                  (b == '@' and a in ALLOWED) for a, b in zip(s, t))
        return 'You can win' if can else 'You will lose'
    if pid == 'abc004_2':
        grid = data
        return '\n'.join(' '.join(grid[3-i][3-j] for j in range(4)) for i in range(4))
    return str(sorted(data)[0])


def independent_check(pid: str, raw: str, output: str) -> bool:
    return isinstance(output, str) and output == independent_answer(pid, raw)


def generate(pid: str, seed: int = 47) -> list[dict[str, str]]:
    if pid not in TASKS:
        raise ValueError('unknown task')
    rng = random.Random(f'v47:{pid}:{seed}')
    cases: list[dict[str, str]] = []
    seen: set[str] = set()
    def add(category: str, raw: str) -> None:
        validate(pid, raw)
        if raw not in seen:
            seen.add(raw)
            cases.append({'category': category, 'input': raw})

    if pid == 'abc003_2':
        pairs = [('a','a'),('@','a'),('@','@'),('@','z'),('z','@'),('b','b'),
                 ('a','z'),('atcoder','@tcoder'),('ch@ku@ai','choku@@i'),
                 ('aoki','@ok@'),('arc','abc'),('@'*10,'atcoderabc'),
                 ('@'*10,'z'*10),('a'*10,'a'*10),('atcoderabc','atcoderabc')]
        for s,t in pairs:
            add('boundary' if len(s) in (1, 10) else 'normal', f'{s}\n{t}\n')
        while len(cases) < 18:
            n = rng.randint(1,10)
            s = ''.join(rng.choice('atcoderxyz@') for _ in range(n))
            t = ''.join(rng.choice('atcoderxyz@') for _ in range(n))
            add('normal', f'{s}\n{t}\n')
        max_case = '@'*10+'\n'+'atcoderabc'+'\n'
    elif pid == 'abc004_2':
        patterns = [
            ['. . . .','. o o .','. x x .','. . . .'],
            ['o o x x','o o x x','x x o o','x x o o'],
            ['. . . .']*4,['o o o o']*4,['x x x x']*4,
            ['. o x .','o x . o','x . o x','. x o .'],
            ['. . . o','. . o .','. x . .','x . . .'],
        ]
        for grid in patterns:
            add('boundary' if len(set(' '.join(grid))) < 3 else 'normal','\n'.join(grid)+'\n')
        while len(cases)<18:
            grid = [' '.join(rng.choice('.ox') for _ in range(4)) for _ in range(4)]
            add('normal','\n'.join(grid)+'\n')
        max_case = '\n'.join(['x o . x','o x o .','. o x o','x . o x'])+'\n'
    else:
        lists = [[1],[100],[1,100],[100,1],[3,3,3],[3,1,4,1,5],
                 [100]*100,[1]*100,[100]*99+[1], [1]+[100]*99,
                 list(range(1,101)), list(range(100,0,-1))]
        for values in lists:
            add('boundary' if len(values) in (1,100) else 'normal',str(len(values))+'\n'+'\n'.join(map(str,values))+'\n')
        while len(cases)<18:
            n = rng.randint(1,100)
            values = [rng.randint(1,100) for _ in range(n)]
            add('normal',str(n)+'\n'+'\n'.join(map(str,values))+'\n')
        max_case = '100\n'+'\n'.join(['100']*99+['1'])+'\n'
    cases = [row for row in cases if row['input'] != max_case][:17]
    add_max={'category':'constraint_max','input':max_case}
    validate(pid,max_case)
    cases.append(add_max)
    if len(cases)!=18 or len({r['input'] for r in cases})!=18:
        raise ValueError('generated cases not distinct')
    return cases
