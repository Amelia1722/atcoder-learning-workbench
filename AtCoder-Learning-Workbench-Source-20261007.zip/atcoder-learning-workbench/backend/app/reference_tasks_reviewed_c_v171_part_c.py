"""Reviewed C tasks with circular allowance events and offline leftmost ball merges."""
from __future__ import annotations
from collections import Counter
from heapq import heapify,heappop,heappush
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_c' for n in range(346,352))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES={'abc350_c':'semantic'}
Case=dict[str,str]
Data=tuple[object,...]
def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a
def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==346:
        require(len(rows)==2,'shape');n,k=ints(rows[0],2);require(1<=n<=200000 and 1<=k<=2*10**9,'bounds');a=ints(rows[1],n);require(all(1<=v<=2*10**9 for v in a),'values');return k,a
    if number==347:
        require(len(rows)==2,'shape');n,a,b=ints(rows[0],3);require(1<=n<=200000 and 1<=a<=10**9 and 1<=b<=10**9,'bounds');days=ints(rows[1],n);require(all(1<=v<=10**9 for v in days) and all(x<y for x,y in zip(days,days[1:])),'days');return a,b,days
    if number==348:
        n=ints(rows[0],1)[0];require(1<=n<=200000 and len(rows)==n+1,'shape');beans=tuple(ints(row,2) for row in rows[1:]);require(all(1<=v<=10**9 for pair in beans for v in pair),'beans');return (beans,)
    if number==349:
        require(len(rows)==2 and 3<=len(rows[0])<=100000 and re.fullmatch('[a-z]+',rows[0]) is not None and re.fullmatch('[A-Z]{3}',rows[1]) is not None,'airport');return tuple(rows)
    require(len(rows)==2,'shape');n=ints(rows[0],1)[0];require((2<=n<=200000 if number==350 else 1<=n<=200000),'length');a=ints(rows[1],n);require(set(a)==set(range(1,n+1)) if number==350 else all(0<=v<=10**9 for v in a),'values');return (a,)
def merge_leftmost(a:tuple[int,...])->int:
    values=list(a);n=len(a);previous=[j-1 for j in range(n)];following=[j+1 if j+1<n else -1 for j in range(n)];alive=[True]*n;pending=[j for j in range(n-1) if values[j]==values[j+1]];heapify(pending);remaining=n
    while pending:
        left=heappop(pending)
        if not alive[left]:continue
        right=following[left]
        if right==-1 or values[left]!=values[right]:continue
        values[left]+=1;alive[right]=False;remaining-=1;following[left]=following[right]
        if following[left]!=-1:previous[following[left]]=left
        before=previous[left]
        if before!=-1 and values[before]==values[left]:heappush(pending,before)
        after=following[left]
        if after!=-1 and values[left]==values[after]:heappush(pending,left)
    return remaining
def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==346:
        k,a=cast(tuple[int,tuple[int,...]],data);present=sorted({v for v in a if v<=k});answer=0;previous=0
        for value in present+[k+1]:answer+=(value-previous-1)*(value+previous)//2;previous=value
        return str(answer)
    if number==347:
        a,b,days=cast(tuple[int,int,tuple[int,...]],data);period=a+b;events:Counter[int]=Counter()
        for day in days:
            start=(-day)%period;end=start+a-1
            if end<period:events[start]+=1;events[end+1]-=1
            else:events[start]+=1;events[period]-=1;events[0]+=1;events[end%period+1]-=1
        active=0
        for offset,change in sorted(events.items()):
            active+=change
            if offset<period and active==len(days):return 'Yes'
        return 'No'
    if number==348:
        beans=cast(tuple[tuple[int,int],...],data[0]);colors={color for score,color in beans};low=0;high=10**9+1
        while high-low>1:
            middle=(low+high)//2;bad={color for score,color in beans if score<middle}
            if len(bad)<len(colors):low=middle
            else:high=middle
        return str(low)
    if number==349:
        s,t=cast(tuple[str,str],data);target=t.lower()[:2] if t[-1]=='X' else t.lower();counts=[1]+[0]*len(target)
        for char in s:
            for j in range(len(target),0,-1):
                if char==target[j-1]:counts[j]+=counts[j-1]
        return 'Yes' if counts[-1] else 'No'
    if number==350:
        a=cast(tuple[int,...],data[0]);seen=set();swaps=[]
        for start in range(len(a)):
            if start in seen:continue
            cycle=[];j=start
            while j not in seen:seen.add(j);cycle.append(j);j=a[j]-1
            for j in cycle[1:]:swaps.append((min(start,j)+1,max(start,j)+1))
        return str(len(swaps))+('' if not swaps else '\n'+'\n'.join(f'{i} {j}' for i,j in swaps))
    return str(merge_leftmost(cast(tuple[int,...],data[0])))
def independent_check(pid:str,raw:str,actual:str)->bool:
    try:
        if pid=='abc350_c':
            a=list(cast(tuple[int,...],validate(pid,raw)[0]));rows=actual.removesuffix('\n').split('\n');k=ints(rows[0],1)[0];require(0<=k<len(a) and len(rows)==k+1,'operation count')
            for row in rows[1:]:i,j=ints(row,2);require(1<=i<j<=len(a),'swap');a[i-1],a[j-1]=a[j-1],a[i-1]
            return a==list(range(1,len(a)+1))
        return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:
    return independent_check(pid,raw,expected) and independent_check(pid,raw,stdout) if pid=='abc350_c' else expected.removesuffix('\n')==stdout.removesuffix('\n')
REFERENCE_CODE={
'abc346_c':"n,k=map(int,input().split());a=set(map(int,input().split()));print(k*(k+1)//2-sum(v for v in a if v<=k))\n",
'abc347_c':"n,a,b=map(int,input().split());d=sorted(set(v%(a+b) for v in map(int,input().split())));gaps=[d[j+1]-d[j] for j in range(len(d)-1)]+[d[0]+a+b-d[-1]];print('Yes' if max(gaps)>b else 'No')\n",
'abc348_c':"n=int(input());worst={}\nfor _ in range(n):\n a,c=map(int,input().split());worst[c]=min(worst.get(c,a),a)\nprint(max(worst.values()))\n",
'abc349_c':"s=input();t=input().lower();t=t[:2] if t[-1]=='x' else t;matched=0\nfor ch in s:\n if matched<len(t) and ch==t[matched]:matched+=1\nprint('Yes' if matched==len(t) else 'No')\n",
'abc350_c':"n=int(input());a=list(map(int,input().split()));position=[0]*(n+1)\nfor j,v in enumerate(a):position[v]=j\nswaps=[]\nfor i in range(n):\n if a[i]==i+1:continue\n j=position[i+1];other=a[i];a[i],a[j]=a[j],a[i];position[i+1]=i;position[other]=j;swaps.append((i+1,j+1))\nprint(len(swaps))\nfor i,j in swaps:print(i,j)\n",
'abc351_c':"n=int(input());a=list(map(int,input().split()));stack=[]\nfor v in a:\n stack.append(v)\n while len(stack)>=2 and stack[-1]==stack[-2]:stack.pop();stack[-1]+=1\nprint(len(stack))\n"}
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17100+number)
    if number==346:
        def missing(k:int,a:list[int])->str:return f'{len(a)} {k}\n'+line(a)
        raws=[missing(k,a) for k,a in ((1,[1]),(1,[2]),(3,[1,1]),(3,[1,3,5]))];raws.extend(missing(rng.randint(1,100),[rng.randint(1,150) for _ in range(n)]) for n in range(3,15));raws.extend([missing(2*10**9,list(range(1,200001))),missing(2*10**9,[2*10**9]*200000)])
    elif number==347:
        def holidays(a:int,b:int,days:list[int])->str:return f'{len(days)} {a} {b}\n'+line(days)
        raws=[holidays(a,b,d) for a,b,d in ((1,1,[1]),(1,1,[1,2]),(2,1,[1,3]),(2,3,[4,5,6]))];raws.extend(holidays(rng.randint(1,20),rng.randint(1,20),sorted(rng.sample(range(1,1000),n))) for n in range(3,15));raws.extend([holidays(100000,999999999,list(range(1,200001))),holidays(10**9,10**9,list(range(999800001,1000000001)))])
    elif number==348:
        def beans(a:list[tuple[int,int]])->str:return f'{len(a)}\n'+''.join(line(v) for v in a)
        raws=[beans(a) for a in ([(1,1)],[(1,1),(2,1)],[(1,1),(2,2)],[(100,1),(1,1),(2,2)])];raws.extend(beans([(rng.randint(1,100),rng.randint(1,10)) for _ in range(n)]) for n in range(3,15));raws.extend([beans([(j+1,j+1) for j in range(200000)]),beans([(10**9,10**9)]*200000)])
    elif number==349:
        raws=[s+'\n'+t+'\n' for s,t in (('aaa','AAA'),('aaa','AAX'),('abc','ACB'),('abc','ABX'))];raws.extend(''.join(rng.choice('abcx') for _ in range(n))+'\n'+''.join(rng.choice('ABCX') for _ in range(3))+'\n' for n in range(4,16));raws.extend(['a'*99998+'bc\nABC\n','z'*100000+'\nZZZ\n'])
    elif number==350:
        def permutation(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[permutation(a) for a in ([1,2],[2,1],[2,3,1],[3,1,2])]
        for n in range(4,16):a=list(range(1,n+1));rng.shuffle(a);raws.append(permutation(a))
        raws.extend([permutation(list(range(200000,0,-1))),permutation(list(range(2,200001))+[1])])
    else:
        def balls(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[balls(a) for a in ([0],[0,0],[0,0,0],[0,1,0])];raws.extend(balls([rng.randint(0,8) for _ in range(n)]) for n in range(3,15));raws.extend([balls([j%2 for j in range(200000)]),balls([10**9]*200000)])
    require(len(raws)==len(set(raws))==18,'unique cases');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]
HINTS={
'abc346_c':('1からKの総和から、現れる値を引きます。','同じ値を何度も引かないよう集合にし、Kを超える値は除きます。','疑似コード: answer=K*(K+1)/2; values=set(A); 各v<=Kでanswer-=v; answerを出力。'),
'abc347_c':('予定の日を週の長さで割った余りだけ考えます。','円周上の予定間隔にB日より大きな間隔があれば、平日B日をその空間に置けます。','疑似コード: residues=sort(set(D mod (A+B))); 隣接差と末尾から先頭への周回差の最大を求める; 最大差>BならYes、他はNo。'),
'abc348_c':('色ごとに最悪のおいしさを求めます。','各色の最小値を辞書へ保持し、それらの最大値を答えます。','疑似コード: 各(a,c)でworst[c]=min(worst[c],a); max(worst.values())を出力。'),
'abc349_c':('文字の順番を保つ部分列を探します。','Tの末尾がXなら最後の1文字を省いてよいです。必要な文字をSの左から順に探します。','疑似コード: Tを小文字化; 末尾xなら先頭2文字のみ; matched=0; Sの各文字で次のT文字と一致すればmatched++; 全て一致ならYes。'),
'abc350_c':('小さい値から正しい位置へ移します。','各値の現在位置を持ち、i番目へ値iを移す交換を行います。','疑似コード: position[value]を作る; 各iでA[i]!=iならj=position[i]と交換し2値のposition更新; 交換回数と各(i,j)を出力。'),
'abc351_c':('右端のボールだけを比較するのでスタックを使えます。','大きさそのものではなく指数を記録します。同じ指数2つを消して指数+1にします。','疑似コード: 各指数aをstackへ追加; 末尾2値が同じ間、1つpopし残る末尾を+1; 最後のstack長を出力。')}

TITLES={'abc346_c': 'Σ', 'abc347_c': 'Ideal Holidays', 'abc348_c': 'Colorful Beans', 'abc349_c': 'Airport Code', 'abc350_c': 'Sort', 'abc351_c': 'Merge the balls'}
PUBLISHED_SAMPLES={'abc346_c': [{'input': '4 5\n1 6 3 1\n', 'expected': '11\n'}, {'input': '1 3\n346\n', 'expected': '6\n'}, {'input': '10 158260522\n877914575 24979445 623690081 262703497 24979445 1822804784 1430302156 1161735902 923078537 1189330739\n', 'expected': '12523196466007058\n'}], 'abc347_c': [{'input': '3 2 5\n1 2 9\n', 'expected': 'Yes\n'}, {'input': '2 5 10\n10 15\n', 'expected': 'No\n'}, {'input': '4 347 347\n347 700 705 710\n', 'expected': 'Yes\n'}], 'abc348_c': [{'input': '4\n100 1\n20 5\n30 5\n40 1\n', 'expected': '40\n'}, {'input': '10\n68 3\n17 2\n99 2\n92 4\n82 4\n10 3\n100 2\n78 1\n3 1\n35 4\n', 'expected': '35\n'}], 'abc349_c': [{'input': 'narita\nNRT\n', 'expected': 'Yes\n'}, {'input': 'losangeles\nLAX\n', 'expected': 'Yes\n'}, {'input': 'snuke\nRNG\n', 'expected': 'No\n'}], 'abc350_c': [{'input': '5\n3 4 1 2 5\n', 'expected': '2\n1 3\n2 4\n'}, {'input': '4\n1 2 3 4\n', 'expected': '0\n'}, {'input': '3\n3 1 2\n', 'expected': '2\n1 2\n2 3\n'}], 'abc351_c': [{'input': '7\n2 1 1 3 5 3 3\n', 'expected': '3\n'}, {'input': '5\n0 0 0 1 2\n', 'expected': '4\n'}]}
SAMPLE_COUNTS={pid:len(samples) for pid,samples in PUBLISHED_SAMPLES.items()}
