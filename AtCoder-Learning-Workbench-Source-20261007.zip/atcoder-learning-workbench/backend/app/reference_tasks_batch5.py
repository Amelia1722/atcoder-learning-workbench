"""Official-statement-based input validators and independent answers: ABC100 / ABC102 A-C."""
from __future__ import annotations
from random import Random
from math import gcd

SAMPLE = {
 'abc100_a':('5 4\n','Yay!','1<=A,B<=16; A+B<=16'),
 'abc100_b':('0 5\n','5','D in {0,1,2}; 1<=N<=100'),
 'abc100_c':('3\n5 2 4\n','3','1<=N<=10000; 1<=Ai<=10^9'),
 'abc102_a':('3\n','6','1<=N<=10^9'),
 'abc102_b':('4\n1 4 6 3\n','5','2<=N<=100; 1<=Ai<=10^9'),
 'abc102_c':('5\n2 2 3 5 5\n','2','1<=N<=200000; 1<=Ai<=10^9'),
}
BATCH5={pid:{'sample_input':a,'sample_output':b,
             'source_url':f'https://atcoder.jp/contests/{pid[:6]}/tasks/{pid}',
             'constraints':c} for pid,(a,b,c) in SAMPLE.items()}


def validate(pid,data):
    if pid not in BATCH5:raise ValueError('未対応問題')
    tok=data.split()
    if not tok or any(not s.isascii() or not s.isdecimal() for s in tok):raise ValueError('非負整数のみ入力できます')
    z=list(map(int,tok))
    if pid=='abc100_a':
        if len(z)!=2 or not 1<=z[0]<=16 or not 1<=z[1]<=16 or sum(z)>16:
            raise ValueError('A/Bの個数制約違反')
        return tuple(z)
    if pid=='abc100_b':
        if len(z)!=2 or z[0] not in (0,1,2) or not 1<=z[1]<=100:
            raise ValueError('D/Nの制約違反')
        return tuple(z)
    if pid=='abc102_a':
        if len(z)!=1 or not 1<=z[0]<=10**9:raise ValueError('Nの制約違反')
        return z[0]
    n=z[0];a=z[1:]
    low,high=(1,10000) if pid=='abc100_c' else (2,100) if pid=='abc102_b' else (1,200000)
    if not low<=n<=high or len(a)!=n or any(not 1<=x<=10**9 for x in a):
        raise ValueError('N/配列要素制約違反')
    return a


def generate(pid,count,seed,include_large):
    if pid not in BATCH5 or not 1<=count<=80:raise ValueError('問題ID/件数が不正')
    rng=Random(seed);cases=[];seen=set()
    def add(category,data):
        validate(pid,data)
        if data not in seen:
            seen.add(data);cases.append({'category':category,'input':data})
        elif category=='constraint_max':
            next(c for c in cases if c['input']==data)['category']='constraint_max'
    def arr(category,a):add(category,str(len(a))+'\n'+' '.join(map(str,a))+'\n')
    if pid=='abc100_a':
        for a,b in [(1,1),(8,8),(5,4),(11,4),(8,1),(1,8),(9,1),(1,9),(7,8),(8,7),(16,0)]:
            if b>=1:add('usual',f'{a} {b}\n')
        while len(cases)<count:
            a=rng.randint(1,15);b=rng.randint(1,16-a);add('random',f'{a} {b}\n')
        if include_large:add('constraint_max','8 8\n')
    elif pid=='abc100_b':
        for d in (0,1,2):
            for n in (1,5,11,85,99,100):add('usual',f'{d} {n}\n')
        while len(cases)<count:add('random',f'{rng.randint(0,2)} {rng.randint(1,100)}\n')
        if include_large:add('constraint_max','2 100\n')
    elif pid=='abc102_a':
        for n in (1,2,3,4,10,99,100,101,10**9-1,10**9):add('boundary',f'{n}\n')
        while len(cases)<count:add('random',f'{rng.randint(1,10**9)}\n')
        if include_large:add('constraint_max',f'{10**9}\n')
    elif pid=='abc100_c':
        for a in ([1],[2],[5,2,4],[1,3,5],[2,4,8],[2**29]*100,[1]*100,
                  [2**29]*10000,[1]*10000,[2**29,2**29,1]):arr('usual',a)
        while len(cases)<count:
            n=rng.randint(1,80);a=[rng.randint(1,10**9) for _ in range(n)];arr('random',a)
        if include_large:arr('constraint_max',[2**29]*10000)
    elif pid=='abc102_b':
        for a in ([1,1],[1,10**9],[1,4,6,3],[10**9,1],[1]*5,[1]*100,[1,10**9]*50,list(range(1,101))):arr('usual',a)
        while len(cases)<count:arr('random',[rng.randint(1,10**9) for _ in range(rng.randint(2,100))])
        if include_large:arr('constraint_max',[1,10**9]*50)
    else:
        for a in ([1],[10**9],[2,2,3,5,5],[1,2,3,4,5,6,7,8,9],
                  [6,5,4,3,2,1],[1]*100,[10**9]*100,[1,10**9]*100):arr('usual',a)
        while len(cases)<count:arr('random',[rng.randint(1,10**9) for _ in range(rng.randint(1,100))])
        if include_large:arr('constraint_max',[1]*200000)
    if include_large:
        maximum=[c for c in cases if c['category']=='constraint_max']
        if not maximum:raise RuntimeError('最大ケース生成失敗')
        maximum=maximum[-1]
        return [c for c in cases if c['input']!=maximum['input']][:count]+[maximum]
    return cases[:count]


def independent_check(pid,data,expected):
    v=validate(pid,data);s=expected.strip()
    if pid=='abc100_a':
        a,b=v;return s==('Yay!' if max(a,b)<=8 else ':(')
    if pid=='abc100_b':
        d,n=v;valid=[x for x in range(1,102) if x%100];return s==str(valid[n-1]*100**d)
    if pid=='abc100_c':
        count=0
        for value in v:
            while value&1==0:
                count+=1;value>>=1
        return s==str(count)
    if pid=='abc102_a':return s==str(v*2//gcd(v,2))
    if pid=='abc102_b':
        return s==str(max(abs(a-b) for a in v for b in v))
    if pid=='abc102_c':
        shifted=sorted(x-i for i,x in enumerate(v,1))
        median=shifted[len(v)//2]
        return s==str(sum(abs(x-median) for x in shifted))
    raise AssertionError(pid)
