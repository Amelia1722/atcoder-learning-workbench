"""Private ABC425..430 D domains and independently structured oracles."""
from __future__ import annotations
from collections import Counter
from array import array
from functools import lru_cache
from typing import cast
import random,re
TASKS=tuple(f'abc{n}_d' for n in range(425,431));CONTESTS={p:p.split('_')[0] for p in TASKS};PROBLEM_INDEXES={p:'D' for p in TASKS}
OUTPUT_MODES:dict[str,str]={};CHECKER_IDS:dict[str,str]={};Case=dict[str,str];Data=tuple[object,...]
def require(ok:bool,label:str)->None:
 if not ok:raise ValueError(label)
def ints(row:str,count:int|None=None)->tuple[int,...]:
 require(re.fullmatch(r'(?:0|[1-9][0-9]*)(?: (?:0|[1-9][0-9]*))*',row) is not None,'integer fields');a=tuple(map(int,row.split()));require(count is None or len(a)==count,'field count');return a
def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'
def validate(pid:str,raw:str)->Data:
 require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');r=raw[:-1].split('\n');require(all(r),'blank rows')
 if pid=='abc425_d':
  h,w=ints(r[0],2);require(h>=2 and w>=2 and h*w<=300000 and len(r)==h+1,'shape');require(all(re.fullmatch('[.#]{'+str(w)+'}',row) is not None for row in r[1:]),'grid');return h,w,tuple(r[1:])
 if pid=='abc426_d':
  t=ints(r[0],1)[0];require(1<=t<=200000 and len(r)==1+2*t,'T/rows');strings=[];total=0
  for i in range(t):
   n=ints(r[2*i+1],1)[0];s=r[2*i+2];require(2<=n<=500000 and re.fullmatch('[01]{'+str(n)+'}',s) is not None,'N/S');total+=n;strings.append(s)
  require(total<=500000,'sum N');return (tuple(strings),)
 if pid=='abc427_d':
  t=ints(r[0],1)[0];require(1<=t<=100000,'T implicit sumN bound');at=1;sum_n=sum_m=0;cases=[]
  for _ in range(t):
   require(at+1<len(r),'case rows');n,m,k=ints(r[at],3);s=r[at+1];at+=2;require(2<=n<=200000 and 2<=m<=200000 and 1<=k<=10 and re.fullmatch('[AB]{'+str(n)+'}',s) is not None and at+m<=len(r),'shape');edges=tuple(ints(row,2) for row in r[at:at+m]);at+=m;require(all(1<=u<=n and 1<=v<=n for u,v in edges) and len(set(edges))==m and len({u for u,v in edges})==n,'unique edges/outdegree');cases.append((n,k,s,edges));sum_n+=n;sum_m+=m
  require(at==len(r) and sum_n<=200000 and sum_m<=200000,'rows/sums');return (tuple(cases),)
 if pid=='abc428_d':
  t=ints(r[0],1)[0];require(1<=t<=300000 and len(r)==t+1,'T/rows');cases=tuple(ints(row,2) for row in r[1:]);require(all(1<=c<=200000000 and 1<=d<=5000000000 for c,d in cases),'C/D');return (cases,)
 if pid=='abc429_d':
  require(len(r)==2,'rows');n,m,c=ints(r[0],3);a=ints(r[1],n);require(1<=n<=500000 and 1<=m<=10**12 and 1<=c<=n and all(0<=v<m for v in a),'N/M/C/A');return m,c,a
 require(len(r)==2,'rows');n=ints(r[0],1)[0];a=ints(r[1],n);require(1<=n<=500000 and len(set(a))==n and all(1<=v<=10**9 for v in a),'N/X');return (a,)

@lru_cache(maxsize=32)
def automaton_bitset_parallel(h:int,w:int,grid:tuple[str,...])->int:
 # Bits store the whole black set. Four shifts compute all neighbor sets at
 # once; Boolean algebra selects exactly one neighbor without scalar counts.
 black=int(''.join(grid).translate(str.maketrans('.#','01'))[::-1],2)
 full=(1<<(h*w))-1;first_column=full//((1<<w)-1);last_column=first_column<<(w-1)
 east_mask=full^first_column;west_mask=full^last_column
 while True:
  north=black>>w;south=(black<<w)&full;east=(black<<1)&east_mask;west=(black>>1)&west_mask
  vertical=north^south;horizontal=east^west
  multiple=(north&south)|(east&west)|(vertical&horizontal)
  additions=(vertical^horizontal)&~multiple&~black
  if not additions:return black.bit_count()
  black|=additions

def endpoint_surviving_interval(s:str)->int:
 # Original unmoved characters form a contiguous interval. Every original
 # wrong bit costs >=1 flip, and every displaced correct bit costs >=2 flips.
 n=len(s);answer=2*n
 for target in '01':
  before=0;inside=after=2*n+1
  for char in s:
   removed=2 if char==target else 1
   before,inside,after=before+removed,min(before,inside) if char==target else 2*n+1,min(inside,after)+removed
  answer=min(answer,before,inside,after)
 return answer

def game_retrograde_worklist(n:int,k:int,s:str,edges:tuple[tuple[int,...],...])->bool:
 incoming=[[] for _ in range(n)];degree=array('I',[0])*n
 for u,v in edges:incoming[v-1].append(u-1);degree[u-1]+=1
 layers=2*k+1;winning=bytearray(n*layers);remaining=degree*layers
 queue=array('I',(v for v,char in enumerate(s) if char=='A'))
 for v in queue:winning[v]=1
 cursor=0;goal=2*k*n
 while cursor<len(queue):
  state=queue[cursor];cursor+=1;layer,child=divmod(state,n)
  if layer==2*k:continue
  parent_layer=layer+1;offset=parent_layer*n
  for parent in incoming[child]:
   target=offset+parent
   if winning[target]:continue
   if parent_layer%2:remaining[target]-=1
   if parent_layer%2==0 or remaining[target]==0:
    winning[target]=1
    if target==goal:return True
    queue.append(target)
 return False

def sqrt_newton(value:int)->int:
 if value<2:return value
 x=1<<((value.bit_length()+1)//2)
 while True:
  y=(x+value//x)//2
  if y>=x:return x
  x=y
def decimal_prefix_squares(c:int,d:int)->int:
 low=c+1;high=c+d;answer=0;power=10**len(str(low))
 while power//10<=high:
  left=max(low,power//10);right=min(high,power-1)
  if left<=right:answer+=sqrt_newton(c*power+right)-sqrt_newton(c*power+left-1)
  power*=10
 return answer

def circle_weighted_window(m:int,c:int,a:tuple[int,...])->int:
 buckets=sorted(Counter(a).items());size=len(buckets);positions=[p for p,w in buckets];weights=[w for p,w in buckets];end=total=answer=0
 for start in range(size):
  while total<c:total+=weights[end%size];end+=1
  gap=(positions[start]-positions[start-1]) if start else positions[0]+m-positions[-1];answer+=gap*total;total-=weights[start]
 return answer

def neighbor_reverse_removals(a:tuple[int,...])->list[int]:
 points=sorted((0,)+a);n=len(points);index={v:i for i,v in enumerate(points)};previous=list(range(-1,n-1));following=list(range(1,n))+[-1]
 def distance(i:int)->int:
  left=previous[i];right=following[i];return min(points[i]-points[left] if left>=0 else 10**18,points[right]-points[i] if right>=0 else 10**18)
 distances=[distance(i) for i in range(n)];total=sum(distances);answers=[0]*len(a)
 for count in range(len(a),0,-1):
  answers[count-1]=total
  if count==1:break
  i=index[a[count-1]];left=previous[i];right=following[i];total-=distances[i]
  if left>=0:following[left]=right
  if right>=0:previous[right]=left
  for j in (left,right):
   if j>=0:other=distance(j);total+=other-distances[j];distances[j]=other
 return answers

def oracle(pid:str,raw:str)->str:
 d=validate(pid,raw)
 if pid=='abc425_d':return str(automaton_bitset_parallel(*cast(tuple[int,int,tuple[str,...]],d)))+'\n'
 if pid=='abc426_d':return ''.join(str(endpoint_surviving_interval(s))+'\n' for s in cast(tuple[str,...],d[0]))
 if pid=='abc427_d':return ''.join(('Alice' if game_retrograde_worklist(*case) else 'Bob')+'\n' for case in cast(tuple[tuple[int,int,str,tuple[tuple[int,...],...]],...],d[0]))
 if pid=='abc428_d':return ''.join(str(decimal_prefix_squares(c,v))+'\n' for c,v in cast(tuple[tuple[int,int],...],d[0]))
 if pid=='abc429_d':return str(circle_weighted_window(*cast(tuple[int,int,tuple[int,...]],d)))+'\n'
 return ''.join(str(v)+'\n' for v in neighbor_reverse_removals(cast(tuple[int,...],d[0])))
def independent_check(pid:str,raw:str,actual:str)->bool:
 try:return actual.removesuffix('\n')==oracle(pid,raw).removesuffix('\n')
 except (ValueError,IndexError,TypeError):return False
def official_expected_matches_reference(pid:str,raw:str,expected:str,actual:str)->bool:return independent_check(pid,raw,expected) and independent_check(pid,raw,actual)

def generate(pid:str)->list[Case]:
 rng=random.Random(int(pid[3:6]));rows:list[str]=[]
 if pid=='abc425_d':
  def board(g:list[str])->str:return line([len(g),len(g[0])])+''.join(row+'\n' for row in g)
  boards=[['..','..'],['##','##'],['#.','..'],['##','..'],['#.','.#'],['#..','...'],['...','.#.','...'],['#.#','...','#.#']];rows=[board(g) for g in boards]
  for h,w in ((2,5),(5,2),(3,4),(4,3),(5,5),(9,10),(20,21)):rows.append(board([''.join(rng.choice('.#') for _ in range(w)) for _ in range(h)]))
  rows+=[board(['#'+'.'*149999,'.'*150000]),board(['#.' if i==0 else '..' for i in range(150000)]),board(['#'*600 for _ in range(500)])]
 elif pid=='abc426_d':
  def pack(strings:list[str])->str:return str(len(strings))+'\n'+''.join(str(len(s))+'\n'+s+'\n' for s in strings)
  rows=[pack([s]) for s in ['00','11','01','10','010','101','00100','11011','001100','011110','010101','111000111']];rows.append(pack([''.join(rng.choice('01') for _ in range(i)) for i in range(2,80)]));rows.append(pack(['01']*200000));rows.append(pack(['0'*500000]));rows.append(pack(['1'*500000]));rows.append(pack(['0'*125000+'1'*250000+'0'*125000]));rows.append(pack(['01'*250000]))
 elif pid=='abc427_d':
  def pack(cases:list[tuple[int,int,str,list[tuple[int,int]]]])->str:return str(len(cases))+'\n'+''.join(line([n,len(e),k])+s+'\n'+''.join(line(v) for v in e) for n,k,s,e in cases)
  rows=[pack([(2,1,'AB',[(1,1),(2,2)])]),pack([(2,1,'BA',[(1,2),(2,1)])]),pack([(2,10,'AB',[(1,2),(2,1)])]),pack([(2,1,'AB',[(1,1),(1,2),(2,1),(2,2)])])]
  for n in range(3,14):
   e={(u,rng.randrange(1,n+1)) for u in range(1,n+1)};e.update((rng.randrange(1,n+1),rng.randrange(1,n+1)) for _ in range(n));rows.append(pack([(n,rng.randrange(1,11),''.join(rng.choice('AB') for _ in range(n)),sorted(e))]))
  rows.append(pack([(2,10,'AB',[(1,1),(2,2)])]*100000));rows.append(pack([(100000,10,'AB'*50000,[(i,(i%100000)+1) for i in range(1,100001)]+[(i,((i+1)%100000)+1) for i in range(1,100001)])]));rows.append(pack([(200000,10,'A'*199999+'B',[(i,i+1) for i in range(1,200000)]+[(200000,1)])]))
 elif pid=='abc428_d':
  def pack(cases:list[tuple[int,int]])->str:return str(len(cases))+'\n'+''.join(line(v) for v in cases)
  rows=[pack([v]) for v in [(1,1),(1,10),(9,1),(9,90),(10,1),(99,2),(999,2),(99999999,2),(200000000,1),(1,5000000000),(200000000,5000000000),(183,1000)]]
  rows.append(pack([(rng.randrange(1,1000000),rng.randrange(1,1000000)) for _ in range(80)]));rows.append(pack([(1,1)]*300000));rows.append(pack([(10**i-1,2) for i in range(1,9)]));rows.append(pack([(1,10**i) for i in range(1,10)]));rows.append(pack([(rng.randrange(1,200000001),rng.randrange(1,5000000001)) for _ in range(300000)]));rows.append(pack([(200000000,5000000000)]*300000))
 elif pid=='abc429_d':
  def circle(m:int,c:int,a:list[int])->str:return line([len(a),m,c])+line(a)
  rows=[circle(1,1,[0]),circle(10**12,1,[0]),circle(10,2,[0,0,9]),circle(10,3,[0,0,9]),circle(10,1,[1,3,5]),circle(10,2,[1,3,5]),circle(10,3,[1,3,5]),circle(2,2,[0,1,1])]
  for n in range(9,16):rows.append(circle(100,rng.randrange(1,n+1),[rng.randrange(100) for _ in range(n)]))
  rows+=[circle(10**12,250000,[i*2000000 for i in range(500000)]),circle(10**12,250001,[0]*250000+[10**12-1]*250000),circle(10**12,500000,[10**12-1]*500000)]
 else:
  def arrivals(a:list[int])->str:return str(len(a))+'\n'+line(a)
  rows=[arrivals([1]),arrivals([10**9]),arrivals([1,2]),arrivals([2,1]),arrivals([10,5,15]),arrivals([8,1,2,3,7,6]),arrivals([1,10**9,2,10**9-1])]
  for n in range(8,16):rows.append(arrivals(rng.sample(range(1,1000000),n)))
  rows+=[arrivals(list(range(1,500001))),arrivals(rng.sample(range(1,10**9+1),500000)),arrivals([10**9]+list(range(1,500000)))]
 require(len(rows)==len(set(rows))==18,'18 distinct');return [{'input':row,'category':'minimum' if i==0 else 'constraint_max' if i==17 else 'boundary' if i>=15 else 'varied'} for i,row in enumerate(rows)]

REFERENCE_CODE={
'abc425_d':'''import sys
h,w=map(int,input().split());g=[input() for _ in range(h)];black=bytearray(c=='#' for row in g for c in row);count=bytearray(h*w)
def adjacent(i):
 if i>=w:yield i-w
 if i+w<h*w:yield i+w
 if i%w:yield i-1
 if i%w+1<w:yield i+1
for i,b in enumerate(black):
 if b:
  for j in adjacent(i):count[j]+=1
front=[i for i in range(h*w) if not black[i] and count[i]==1];answer=sum(black)
while front:
 active=[i for i in front if not black[i] and count[i]==1]
 for i in active:black[i]=1
 answer+=len(active);pending=[]
 for i in active:
  for j in adjacent(i):
   count[j]+=1
   if not black[j] and count[j]==1:pending.append(j)
 front=pending
print(answer)
''',
'abc426_d':'''import sys
from itertools import groupby
it=iter(sys.stdin.buffer.read().split());t=int(next(it));out=[]
for _ in range(t):
 n=int(next(it));s=next(it);zeros=s.count(48);best=2*n
 for c,group in groupby(s):
  length=sum(1 for _ in group);same=zeros if c==48 else n-zeros;best=min(best,n+same-2*length)
 out.append(str(best))
print('\\n'.join(out))
''',
'abc427_d':'''import sys
it=iter(sys.stdin.buffer.read().split());t=int(next(it));out=[]
for _ in range(t):
 n=int(next(it));m=int(next(it));k=int(next(it));s=next(it);adj=[[] for i in range(n)]
 for i in range(m):u=int(next(it))-1;v=int(next(it))-1;adj[u].append(v)
 win=[c==65 for c in s]
 for remaining in range(1,2*k+1):
  if remaining%2:win=[all(win[v] for v in row) for row in adj]
  else:win=[any(win[v] for v in row) for row in adj]
 out.append('Alice' if win[0] else 'Bob')
print('\\n'.join(out))
''',
'abc428_d':'''import sys,math
it=iter(map(int,sys.stdin.buffer.read().split()));t=next(it);out=[]
for _ in range(t):
 c=next(it);d=next(it);answer=0
 for digits in range(len(str(c+1)),len(str(c+d))+1):
  power=10**digits;lo=max(c+1,power//10);hi=min(c+d,power-1)
  answer+=math.isqrt(c*power+hi)-math.isqrt(c*power+lo-1)
 out.append(str(answer))
print('\\n'.join(out))
''',
'abc429_d':'''import sys,bisect
n,m,c=map(int,input().split());a=sorted(map(int,input().split()));b=a+[v+m for v in a];answer=0
for i in range(n):
 if i and a[i]==a[i-1]:continue
 gap=a[i]-a[i-1] if i else a[0]+m-a[-1];end=bisect.bisect_right(b,b[i+c-1]);answer+=gap*(end-i)
print(answer)
''',
'abc430_d':'''import sys,bisect
n=int(input());a=list(map(int,input().split()));coordinates=sorted([0]+a);rank={x:i+1 for i,x in enumerate(coordinates)};size=n+1;bit=[0]*(size+1);dist=[0]*(size+1);total=0;active=1
def add(i):
 while i<=size:bit[i]+=1;i+=i&-i
def prefix(i):
 result=0
 while i:result+=bit[i];i-=i&-i
 return result
def kth(k):
 i=0;step=1<<(size.bit_length()-1)
 while step:
  j=i+step
  if j<=size and bit[j]<k:k-=bit[j];i=j
  step>>=1
 return i+1
add(1);out=[]
for x in a:
 i=rank[x];k=prefix(i-1);left=kth(k);right=kth(k+1) if k<active else 0;lx=coordinates[left-1];near=x-lx
 if right:near=min(near,coordinates[right-1]-x)
 total+=near
 new=x-lx if active==1 else min(dist[left],x-lx);total+=new-dist[left];dist[left]=new
 if right:new=min(dist[right],coordinates[right-1]-x);total+=new-dist[right];dist[right]=new
 dist[i]=near;add(i);active+=1;out.append(str(total))
print('\\n'.join(out))
'''}
HINTS:dict[str,tuple[str,str,str]]={
'abc425_d':('同じ操作回で黒くなるマスをまとめて扱います。途中で隣接数を変えて次のマスを即座に黒くすると同時更新になりません。','各マスの黒い隣接数を保持します。現在の候補から隣接数1のマスをまとめて黒くしてから、隣接数を増やして次回候補を作ります。','疑似コード: count=初期黒隣接数、front=白かつcount1。while front: active=条件を満たす候補。全activeを黒にする。全activeの隣接countを増やし、白でcountが1に達したマスを次frontへ。黒数を出力。'),
'abc426_d':('一度も動かさずに残る元の文字は、連続する区間になります。同じ文字の長い区間を残すと得です。','最終文字と違う文字は一回以上、同じ文字でも取り除いたものは二回以上反転が必要です。残す同じ文字の区間を最長にします。','疑似コード: 0と1の総数を数える。同じ文字の各連続区間で、cost=N+その文字の総数-2*区間長を計算。最小costを出力。'),
'abc427_d':('残り手数と駒の位置から、Alice が勝てるかを考えます。双方が K 回ずつ動くので総手数は 2K です。','手数0では頂点文字が勝敗です。Alice の手なら勝つ行き先が一つあればよく、Bob の手ならすべての行き先で Alice が勝つ必要があります。','疑似コード: win[v]=(S[v]==A)。remaining=1..2Kで、奇数ならnext[v]=all(win[u])、偶数ならnext[v]=any(win[u])、uはvの行き先。win=next。最後のwin[1]で勝者を出力。'),
'abc428_d':('C+x の桁数が同じ範囲では、連結した整数は C*10^桁数+(C+x) です。','桁数ごとに C+x の区間を切り分けます。整数区間 [L,R] の平方数の個数は floor(sqrt(R))-floor(sqrt(L-1)) です。','疑似コード: y=C+1..C+Dを十進桁境界で分割。各kでlo=max(C+1,10^(k-1))、hi=min(C+D,10^k-1)。isqrt(C*10^k+hi)-isqrt(C*10^k+lo-1)を足す。'),
'abc429_d':('最初に出会う人の位置が同じ出発点をまとめます。同じ位置にいる人はまとめて出会います。','人の位置を整列して二周分を用意します。最初の人から C 人目の位置の集団の末尾まで数え、直前の位置との距離を掛けます。','疑似コード: aをsort、b=a+(a+M)。各異なる位置の先頭iでgap=直前位置との差(先頭は一周を補正)、end=bisect_right(b,b[i+C-1])。answer+=gap*(end-i)。'),
'abc430_d':('新しい人が加わったとき、最寄り距離が変わる可能性がある既存の人は左右の隣人だけです。','全座標を圧縮し Fenwick 木で到着済みの座標を管理します。順序統計で左右の隣人を求め、三人分の距離だけ更新します。','疑似コード: 原点を登録。各Xでprefix個数とkthから左・右の人を取得。新しい人の最寄り距離を足し、左右の距離をmin(元距離,Xとの差)へ更新(最初の原点だけ特別)。Xを登録して総和を出力。')}
REFERENCE_SNIPPETS=REFERENCE_CODE

TITLES={'abc425_d': 'Ulam-Warburton Automaton', 'abc426_d': 'Pop and Insert', 'abc427_d': 'The Simple Game', 'abc428_d': '183184', 'abc429_d': 'On AtCoder Conference', 'abc430_d': 'Neighbor Distance'}
PUBLISHED_SAMPLES={'abc425_d': [{'input': '9 9\n.........\n.........\n.........\n.........\n....#....\n.........\n.........\n.........\n.........\n', 'expected': '57\n'}, {'input': '2 2\n..\n..\n', 'expected': '0\n'}, {'input': '10 10\n..........\n....#.....\n#.......#.\n......#...\n.......#..\n.....#....\n..........\n..........\n..#...#...\n.......#..\n', 'expected': '64\n'}], 'abc426_d': [{'input': '3\n5\n01001\n3\n000\n15\n110010111100101\n', 'expected': '4\n0\n16\n'}], 'abc427_d': [{'input': '3\n4 6 2\nAABB\n1 2\n2 3\n3 1\n3 3\n3 4\n4 2\n4 6 2\nABAB\n1 2\n2 3\n3 1\n3 3\n3 4\n4 2\n5 8 3\nABABB\n1 2\n2 2\n2 3\n3 1\n3 4\n4 4\n4 5\n5 3\n', 'expected': 'Alice\nBob\nBob\n'}], 'abc428_d': [{'input': '4\n4 80\n183 5000\n18 10\n824 5000000000\n', 'expected': '3\n2\n0\n1421\n'}], 'abc429_d': [{'input': '5 3 2\n1 2 1 0 1\n', 'expected': '9\n'}, {'input': '1 1000000000000 1\n1\n', 'expected': '1000000000000\n'}], 'abc430_d': [{'input': '10\n5 2 7 4 108728325 390529120 597713292 322456626 845148281 812604915\n', 'expected': '10\n7\n8\n8\n108728326\n390529121\n523096670\n452057486\n699492475\n517144218\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
