"""ABC200–202 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re
TASKS=('abc200_b','abc201_b','abc202_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NAME=re.compile(r'[A-Za-z0-9]{1,15}',re.ASCII)
S202=re.compile(r'[01689]{1,100000}',re.ASCII)
PUBLISHED_SAMPLES={
 'abc200_b':[
  {'input':'2021 4\n','expected':'50531\n'},
  {'input':'40000 2\n','expected':'1\n'},
  {'input':'8691 20\n','expected':'84875488281\n'},
 ],
 'abc201_b':[
  {'input':'3\nEverest 8849\nK2 8611\nKangchenjunga 8586\n','expected':'K2\n'},
  {'input':'4\nKita 3193\nAino 3189\nFuji 3776\nOkuhotaka 3190\n','expected':'Kita\n'},
  {'input':'4\nQCFium 2846\nchokudai 2992\nkyoprofriends 2432\npenguinman 2390\n','expected':'QCFium\n'},
 ],
 'abc202_b':[
  {'input':'0601889\n','expected':'6881090\n'},
  {'input':'86910\n','expected':'01698\n'},
  {'input':'01010\n','expected':'01010\n'},
 ],
}
def _ints(line:str,count:int)->list[int]:
    p=line.split(' ')
    if len(p)!=count or any(POS.fullmatch(x) is None for x in p): raise ValueError('noncanonical positive integer row')
    return list(map(int,p))
def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc200_b':
        if len(lines)!=1: raise ValueError('shape')
        n,k=_ints(lines[0],2)
        if not (1<=n<=10**5 and 1<=k<=20): raise ValueError('range')
        return n,k
    if pid=='abc201_b':
        if not lines or POS.fullmatch(lines[0]) is None: raise ValueError('shape/N')
        n=int(lines[0])
        if not 2<=n<=1000 or len(lines)!=n+1: raise ValueError('range/shape')
        rows=[]; names=set(); heights=set()
        for line in lines[1:]:
            p=line.split(' ')
            if len(p)!=2 or NAME.fullmatch(p[0]) is None or POS.fullmatch(p[1]) is None: raise ValueError('row syntax')
            h=int(p[1])
            if h>10**5 or p[0] in names or h in heights: raise ValueError('row constraints')
            names.add(p[0]); heights.add(h); rows.append((p[0],h))
        return rows
    if len(lines)!=1 or S202.fullmatch(lines[0]) is None: raise ValueError('string')
    return lines[0]
def _ans200(v):
    n,k=v
    for _ in range(k):
        n = n//200 if n%200==0 else n*1000+200
    return n
def _ans201(rows):
    a=sorted(rows,key=lambda x:x[1],reverse=True)
    return a[1][0]
def _ans202(s):
    mp={'0':'0','1':'1','6':'9','8':'8','9':'6'}
    return ''.join(mp[c] for c in reversed(s))
def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or '\n' in output or output!=output.strip(): return False
    if pid=='abc200_b': return POS.fullmatch(output) is not None and int(output)==_ans200(v)
    if pid=='abc201_b': return NAME.fullmatch(output) is not None and output==_ans201(v)
    return S202.fullmatch(output) is not None and output==_ans202(v)
def _201(rows): return f'{len(rows)}\n'+''.join(f'{s} {h}\n' for s,h in rows)
def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc200_b':
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        vals=[('min','1 1\n'),('div_once','200 1\n'),('div_twice','80000 2\n'),('append_once','7 1\n'),('append_then_div','7 2\n'),('nmax_k1','100000 1\n'),('kmax_small','1 20\n'),('kmax_div','80000 20\n'),('multiple','600 3\n'),('near_multiple','199 4\n'),('just_over','201 4\n'),('large_odd','99999 5\n'),('powerish','400 10\n'),('samplelike','2020 6\n')]
        for c,raw in vals:add(c,raw)
        add('constraint_max','100000 20\n')
    elif pid=='abc201_b':
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        cases=[
          ('n2', [('A',1),('B',2)]),('n2_reverse',[('A',100000),('B',1)]),('second_first',[('S',9),('T',10),('U',1)]),
          ('second_last',[('S',10),('T',1),('U',9)]),('height_bounds',[('Low',1),('High',100000),('Mid',99999)]),
          ('name15',[('abcdefghijklmno',2),('Z',3),('A',1)]),('mixed_names',[('a1',4),('B2',2),('C3',3),('d4',1)]),
          ('n10',[(f'M{i}',i+1) for i in range(10)]),('descending',[(f'D{i}',100-i) for i in range(20)]),
          ('spaced',[(f'X{i}',i*100+1) for i in range(30)]),('n50',[(f'N{i}',5000+i*7) for i in range(50)]),
          ('n100',[(f'P{i}',i+100) for i in range(100)]),('second_unique',[('Top',100000),('Second',99999),('Low',1)]),
          ('case_sensitive',[('a',1),('A',3),('b',2)]),
        ]
        for c,rows in cases:add(c,_201(rows))
        rows=[(f'M{i:04d}',i+1) for i in range(1000)]; add('constraint_max',_201(rows))
    else:
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        vals=[('one0','0\n'),('one1','1\n'),('one6','6\n'),('one8','8\n'),('one9','9\n'),('pair69','69\n'),('pair96','96\n'),('zeros','00000\n'),('ones','11111\n'),('eights','88888\n'),('mixed','01689\n'),('pal_rotation','1691\n'),('long_pattern',('01689'*20)+'\n'),('long_1000',('69'*500)+'\n')]
        for c,raw in vals:add(c,raw)
        add('constraint_max',('01689'*20000)+'\n')
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
