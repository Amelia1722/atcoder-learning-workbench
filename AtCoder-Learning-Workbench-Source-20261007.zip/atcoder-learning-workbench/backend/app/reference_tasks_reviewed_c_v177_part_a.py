"""Reviewed exact-domain C tasks with independently authored oracles."""
from __future__ import annotations
from collections import Counter,deque
from typing import cast
import random,re

TASKS=tuple(f'abc{n}_c' for n in range(443,449))
CONTESTS={p:p.split('_')[0] for p in TASKS}
OUTPUT_MODES:dict[str,str]={}
Case=dict[str,str]
Data=tuple[object,...]
EggCases=tuple[tuple[int,tuple[int,...],tuple[int,...]],...]

def require(ok:bool,label:str)->None:
    if not ok:raise ValueError(label)

def ints(row:str,count:int|None=None)->tuple[int,...]:
    require(re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?: (?:0|-?[1-9][0-9]*))*',row) is not None,'integers');a=tuple(map(int,row.split(' ')));require(count is None or len(a)==count,'fields');return a

def valid_lengths(a:tuple[int,...])->tuple[int,...]:
    counts=Counter(a);largest=max(a);smallest=min(a);out=[]
    for length in sorted({largest,smallest+largest}):
        left=counts.copy();left.pop(length,None);ok=True
        for value,count in left.items():
            mate=length-value
            if mate<=0 or (count%2 if mate==value else left.get(mate,0)!=count):ok=False;break
        if ok:out.append(length)
    return tuple(out)

def egg_count(d:int,a:tuple[int,...],b:tuple[int,...],check:bool=True)->int:
    eggs:deque[int]=deque()
    for day,(supplied,used) in enumerate(zip(a,b)):
        eggs.extend([day]*supplied)
        if check:require(len(eggs)>=used,'no egg shortage')
        for _ in range(used):eggs.popleft()
        while eggs and eggs[0]<=day-d:eggs.popleft()
    return len(eggs)

def validate(pid:str,raw:str)->Data:
    require(pid in TASKS and raw.endswith('\n') and '\r' not in raw,'task/newline');rows=raw[:-1].split('\n');require(all(rows),'blank');number=int(pid[3:6])
    if number==443:
        n,t=ints(rows[0],2);require(0<=n<=300000 and 1<=t<=10**9 and len(rows)==(2 if n else 1),'shape');a=ints(rows[1],n) if n else ();previous=0;reopen=0
        for v in a:
            require(previous<v<=t and v!=reopen,'ordered events/no simultaneous reopen');previous=v
            if v>reopen:reopen=v+100
        return t,a
    if number==444:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=300000 and all(1<=v<=10**9 for v in a),'sticks');require(bool(valid_lengths(a)),'solution existence');return (a,)
    if number==445:
        require(len(rows)==2,'shape');n=ints(rows[0],1)[0];a=ints(rows[1],n);require(1<=n<=500000 and all(j<=v<=n for j,v in enumerate(a,1)),'forward destinations');return (a,)
    if number==446:
        t=ints(rows[0],1)[0];require(1<=t<=200000,'cases');p=1;total=0;cases=[]
        for _ in range(t):
            require(p+2<len(rows),'case shape');n,d=ints(rows[p],2);require(1<=d<=n<=200000,'case size');a,b=ints(rows[p+1],n),ints(rows[p+2],n);p+=3;total+=n;require(all(1<=v<=10 for seq in (a,b) for v in seq),'egg amounts');egg_count(d,a,b);cases.append((d,a,b))
        require(total<=200000 and p==len(rows),'aggregate');return (tuple(cases),)
    if number==447:
        require(len(rows)==2 and all(1<=len(s)<=300000 and re.fullmatch('[A-Z]+',s) for s in rows),'strings');return tuple(rows)
    n,q=ints(rows[0],2);require(6<=n<=300000 and 1<=q<=200000 and len(rows)==2+2*q,'shape');a=ints(rows[1],n);require(all(1<=v<=10**9 for v in a),'ball values');queries=[];total=0
    for p in range(2,len(rows),2):
        k=ints(rows[p],1)[0];require(1<=k<=5,'K');b=ints(rows[p+1],k);require(all(1<=v<=n for v in b) and all(x<y for x,y in zip(b,b[1:])),'ordered distinct exclusions');total+=k;queries.append(b)
    require(total<=400000,'total K');return a,tuple(queries)

def oracle(pid:str,raw:str)->str:
    data=validate(pid,raw);number=int(pid[3:6])
    if number==443:
        t,a=cast(tuple[int,tuple[int,...]],data);hidden=0;j=0
        while j<len(a):
            start=a[j];end=start+100;hidden+=min(end,t)-start;j+=1
            while j<len(a) and a[j]<end:j+=1
        return str(t-hidden)
    if number==444:return ' '.join(map(str,valid_lengths(cast(tuple[int,...],data[0]))))
    if number==445:
        a=cast(tuple[int,...],data[0]);parent=[v-1 for v in a];out=[]
        for start in range(len(a)):
            node=start
            while parent[node]!=node:parent[node]=parent[parent[node]];node=parent[node]
            out.append(str(node+1))
        return ' '.join(out)
    if number==446:return '\n'.join(str(egg_count(d,a,b,False)) for d,a,b in cast(EggCases,data[0]))
    if number==447:
        s,t=cast(tuple[str,str],data)
        if s.replace('A','')!=t.replace('A',''):return '-1'
        left=[len(v) for v in re.split('[B-Z]',s)];right=[len(v) for v in re.split('[B-Z]',t)];return str(sum(abs(x-y) for x,y in zip(left,right)))
    a,queries=cast(tuple[tuple[int,...],tuple[tuple[int,...],...]],data);n=len(a);size=1
    while size<n:size*=2
    tree=[10**9+1]*(2*size);tree[size:size+n]=a
    for j in range(size-1,0,-1):tree[j]=min(tree[j*2],tree[j*2+1])
    def interval(l:int,r:int)->int:
        l+=size;r+=size;best=10**9+1
        while l<r:
            if l&1:best=min(best,tree[l]);l+=1
            if r&1:r-=1;best=min(best,tree[r])
            l//=2;r//=2
        return best
    out=[]
    for b in queries:
        left=0;best=10**9+1
        for v in b:best=min(best,interval(left,v-1));left=v
        out.append(str(min(best,interval(left,n))))
    return '\n'.join(out)

def independent_check(pid:str,raw:str,actual:str)->bool:
    try:return actual.removesuffix('\n')==oracle(pid,raw)
    except (ValueError,IndexError,TypeError,OverflowError):return False

def official_expected_matches_reference(pid:str,raw:str,expected:str,stdout:str)->bool:return expected.removesuffix('\n')==stdout.removesuffix('\n')

REFERENCE_CODE={
'abc443_c':"n,t=map(int,input().split());a=list(map(int,input().split())) if n else [];opened=0;answer=0\nfor v in a:\n if v>opened:answer+=v-opened;opened=v+100\nprint(answer+max(0,t-opened))\n",
'abc444_c':"n=int(input());a=sorted(map(int,input().split()));out=[]\nfor length in sorted({a[-1],a[0]+a[-1]}):\n b=[v for v in a if v!=length];ok=len(b)%2==0\n if ok:ok=all(b[j]+b[-1-j]==length for j in range(len(b)//2))\n if ok:out.append(length)\nprint(*out)\n",
'abc445_c':"n=int(input());a=list(map(int,input().split()));answer=[0]*n\nfor j in range(n-1,-1,-1):answer[j]=j+1 if a[j]==j+1 else answer[a[j]-1]\nprint(*answer)\n",
'abc446_c':"from collections import deque\nt=int(input())\nfor _ in range(t):\n n,d=map(int,input().split());a=list(map(int,input().split()));b=list(map(int,input().split()));batches=deque();total=0\n for j in range(n):\n  batches.append([j,a[j]]);total+=a[j];need=b[j];total-=need\n  while need:\n   used=min(need,batches[0][1]);need-=used;batches[0][1]-=used\n   if batches[0][1]==0:batches.popleft()\n  while batches and batches[0][0]<=j-d:total-=batches.popleft()[1]\n print(total)\n",
'abc447_c':"s=input();t=input();i=j=answer=0;ok=True\nwhile i<len(s) or j<len(t):\n left=right=0\n while i<len(s) and s[i]=='A':left+=1;i+=1\n while j<len(t) and t[j]=='A':right+=1;j+=1\n answer+=abs(left-right)\n if i==len(s) or j==len(t):ok=i==len(s) and j==len(t);break\n if s[i]!=t[j]:ok=False;break\n i+=1;j+=1\nprint(answer if ok else -1)\n",
'abc448_c':"n,q=map(int,input().split());a=list(map(int,input().split()));candidates=sorted(range(n),key=lambda j:a[j])[:6]\nfor _ in range(q):\n k=int(input());excluded=set(int(v)-1 for v in input().split());print(next(a[j] for j in candidates if j not in excluded))\n"}

def line(a:list[int]|tuple[int,...])->str:return ' '.join(map(str,a))+'\n'

def generate(pid:str)->list[Case]:
    require(pid in TASKS,'task');number=int(pid[3:6]);rng=random.Random(17700+number)
    if number==443:
        def work(t:int,a:list[int])->str:return f'{len(a)} {t}\n'+(line(a) if a else '')
        raws=[work(1,[]),work(1,[1]),work(101,[1]),work(102,[1,102])]
        for n in range(3,15):
            a=list(range(1,101*n+1,101));raws.append(work(101*n+100,a))
        raws.extend([work(10**9,[101*(j//100)+j%100+1 for j in range(300000)]),work(10**9,[101*j+1 for j in range(299999)]+[10**9])])
    elif number==444:
        def sticks(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[sticks([1]),sticks([1,1]),sticks([1,2,3]),sticks([2,2,2])]
        for n in range(3,15):
            length=n+5;a=[]
            for _ in range(n):
                v=rng.randint(1,length-1);a.extend([v,length-v])
            if n%2:a.append(length)
            rng.shuffle(a);raws.append(sticks(a))
        raws.extend([sticks([1,10**9-1]*150000),sticks([10**9]*300000)])
    elif number==445:
        def board(a:list[int])->str:return f'{len(a)}\n'+line(a)
        raws=[board([1]),board([2,2]),board([1,2]),board([2,3,3])];raws.extend(board([rng.randint(j,n) for j in range(1,n+1)]) for n in range(3,15));raws.extend([board(list(range(2,500001))+[500000]),board([500000]*500000)])
    elif number==446:
        def eggs(cases:list[tuple[int,list[int],list[int]]])->str:return f'{len(cases)}\n'+''.join(f'{len(a)} {d}\n'+line(a)+line(b) for d,a,b in cases)
        raws=[eggs([(1,[1],[1])]),eggs([(1,[10],[1])]),eggs([(1,[2,1],[1,2])]),eggs([(2,[10,1,1],[1,1,1])])]
        for n in range(3,15):
            a=[rng.randint(1,10) for _ in range(n)];b=[rng.randint(1,v) for v in a];raws.append(eggs([(rng.randint(1,n),a,b)]))
        raws.extend([eggs([(1,[10],[10])]*200000),eggs([(200000,[10]*200000,[10]*200000)])])
    elif number==447:
        raws=[s+'\n'+t+'\n' for s,t in (('A','A'),('A','B'),('A','AA'),('AB','BA'))];raws.extend(''.join(rng.choice('AABC') for _ in range(n))+'\n'+''.join(rng.choice('AABC') for _ in range(n+1))+'\n' for n in range(3,15));raws.extend(['A'*299999+'B\n'+'B'+'A'*299999+'\n','Z'*300000+'\n'+'Z'*300000+'\n'])
    else:
        def balls(a:list[int],qs:list[tuple[int,...]])->str:return f'{len(a)} {len(qs)}\n'+line(a)+''.join(f'{len(b)}\n'+line(b) for b in qs)
        raws=[balls([1]*6,[(1,)]),balls([1,2,3,4,5,6],[(1,2,3,4,5)]),balls([6,5,4,3,2,1],[(6,)]),balls([1,1,2,2,3,3],[(1,2)])]
        for n in range(6,18):raws.append(balls([rng.randint(1,100) for _ in range(n)],[tuple(sorted(rng.sample(range(1,n+1),rng.randint(1,5)))) for _ in range(n)]))
        raws.extend([balls(list(range(1,300001)),[(1,2,3,4,5)]*80000),balls([10**9]*300000,[(299999,300000)]*200000)])
    require(len(raws)==len(set(raws))==18,'distinct');return [{'input':raw,'category':'minimum' if j==0 else 'constraint_max' if j==17 else 'boundary' if j<4 or j==16 else 'deterministic_random'} for j,raw in enumerate(raws)]

HINTS={
'abc443_c':('閉じている100秒間に青木君が通っても、再開時刻は変わりません。','次の再開時刻より後の通過だけを閉じるイベントとして処理します。','疑似コード: open=0,ans=0; 各AでA>openならans+=A-open,open=A+100; 最後にmax(0,T-open)を加算。'),
'abc444_c':('元の長さの候補は最大の断片、または最小と最大の断片の和です。','候補Lそのものの断片は残し、残りを昇順と降順から対応させて和を調べます。','疑似コード: sort(A); L=max(A),min(A)+max(A)についてL以外の列Bを作る; Bが偶数長で全ての両端ペアの和がLなら出力。'),
'abc445_c':('移動先は現在の位置以上なので、最後は自分を指すマスに止まります。','右から答えを決めると、移動先の最終到達位置が既に分かります。','疑似コード: i=Nから1へ; A[i]=iならdest[i]=i、他はdest[i]=dest[A[i]]; destを出力。'),
'abc446_c':('仕入れた日ごとの在庫を、古い順に並べて管理します。','昼に先頭の卵から使い、夜にD日以上古い在庫を取り除きます。','疑似コード: 日iのバッチをdequeへ; B[i]個を先頭から消費; 日付<=i-Dのバッチを除去; 最終在庫合計を出力。'),
'abc447_c':('A以外の文字の列は操作しても変わりません。','A以外の文字の間ごとにAの個数を数え、その差の絶対値を足します。','疑似コード: removeA(S)!=removeA(T)なら-1; 各非A文字の前後のA連長を対応させ、abs(個数差)を合計。'),
'abc448_c':('取り出すボールは最大5個なので、小さい方から6個あれば十分です。','値の小さい6個の番号を保持し、除外されていない最初の番号を探します。','疑似コード: 値順に上位6個の番号を保存; 各queryのBを集合へ; 候補を小さい順に調べ集合にない最初のAを出力。')}

TITLES={'abc443_c': 'Chokutter Addiction', 'abc444_c': 'AtCoder Riko', 'abc445_c': 'Sugoroku Destination', 'abc446_c': 'Omelette Restaurant', 'abc447_c': 'Insert and Erase A', 'abc448_c': 'Except and Min'}
PUBLISHED_SAMPLES={'abc443_c': [{'input': '5 700\n100 150 300 350 700\n', 'expected': '500\n'}, {'input': '0 1000000000\n', 'expected': '1000000000\n'}, {'input': '10 1234\n395 424 588 745 773 863 910 958 1102 1195\n', 'expected': '734\n'}], 'abc444_c': [{'input': '4\n10 5 5 10\n', 'expected': '10 15\n'}, {'input': '3\n4 4 4\n', 'expected': '4\n'}, {'input': '6\n10 187 344 100 434 257\n', 'expected': '444\n'}], 'abc445_c': [{'input': '7\n2 4 7 5 5 6 7\n', 'expected': '5 5 7 5 5 6 7\n'}, {'input': '5\n1 2 3 4 5\n', 'expected': '1 2 3 4 5\n'}, {'input': '15\n11 3 10 7 15 10 10 11 11 13 11 12 14 14 15\n', 'expected': '11 14 14 14 15 14 14 11 11 14 11 12 14 14 15\n'}], 'abc446_c': [{'input': '3\n3 1\n7 2 3\n1 3 2\n3 2\n7 2 3\n1 3 2\n2 1\n2 1\n1 2\n', 'expected': '3\n5\n0\n'}], 'abc447_c': [{'input': 'ABC\nBACA\n', 'expected': '3\n'}, {'input': 'ABC\nARC\n', 'expected': '-1\n'}, {'input': 'ABC\nABC\n', 'expected': '0\n'}, {'input': 'AAAWAZAAAABAAAU\nAWAAZABAAAAAUA\n', 'expected': '9\n'}], 'abc448_c': [{'input': '6 6\n3 2 5 9 1 2\n2\n4 5\n5\n1 2 3 4 6\n3\n2 5 6\n4\n1 2 5 6\n1\n5\n3\n1 2 3\n', 'expected': '2\n1\n3\n5\n2\n1\n'}]}
SAMPLE_COUNTS={p:len(rows) for p,rows in PUBLISHED_SAMPLES.items()}
