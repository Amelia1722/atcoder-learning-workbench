"""ABC203–205 B, reviewed against public AtCoder statements; HTML not archived."""
from __future__ import annotations
import re
TASKS=('abc203_b','abc204_b','abc205_b')
POS=re.compile(r'[1-9][0-9]*',re.ASCII)
NONNEG=re.compile(r'0|[1-9][0-9]*',re.ASCII)
PUBLISHED_SAMPLES={
 'abc203_b':[
  {'input':'1 2\n','expected':'203\n'},
  {'input':'3 3\n','expected':'1818\n'},
 ],
 'abc204_b':[
  {'input':'3\n6 17 28\n','expected':'25\n'},
  {'input':'4\n8 9 10 11\n','expected':'1\n'},
 ],
 'abc205_b':[
  {'input':'5\n3 1 2 4 5\n','expected':'Yes\n'},
  {'input':'6\n3 1 4 1 5 2\n','expected':'No\n'},
  {'input':'3\n1 2 3\n','expected':'Yes\n'},
  {'input':'1\n1\n','expected':'Yes\n'},
 ],
}
def _split(line:str,pat,count:int)->list[int]:
    p=line.split(' ')
    if len(p)!=count or any(pat.fullmatch(x) is None for x in p): raise ValueError('noncanonical integer row')
    return list(map(int,p))
def validate(pid:str,raw:str):
    if pid not in TASKS or not isinstance(raw,str) or not raw.endswith('\n') or '\r' in raw: raise ValueError('noncanonical/unknown task')
    lines=raw[:-1].split('\n')
    if pid=='abc203_b':
        if len(lines)!=1: raise ValueError('shape')
        n,k=_split(lines[0],POS,2)
        if not (1<=n<=9 and 1<=k<=9): raise ValueError('range')
        return n,k
    if not lines or POS.fullmatch(lines[0]) is None: raise ValueError('shape/N')
    n=int(lines[0])
    if not 1<=n<=1000 or len(lines)!=2: raise ValueError('range/shape')
    if pid=='abc204_b':
        a=_split(lines[1],NONNEG,n)
        if any(x>1000 for x in a): raise ValueError('A range')
        return a
    a=_split(lines[1],POS,n)
    if any(x>n for x in a): raise ValueError('A range')
    return a
def _ans203(v):
    n,k=v
    # Closed-form sum, independent of the reference's nested loops.
    return 100*k*n*(n+1)//2 + n*k*(k+1)//2
def _ans204(a):
    return sum(a-10 for a in a if a>10)
def _ans205(a):
    n=len(a); seen=[False]*(n+1)
    for x in a:
        if seen[x]: return 'No'
        seen[x]=True
    return 'Yes' if all(seen[1:]) else 'No'
def independent_check(pid:str,raw:str,output:str)->bool:
    try:v=validate(pid,raw)
    except (ValueError,TypeError,IndexError): return False
    if not isinstance(output,str) or not output or '\n' in output or output!=output.strip(): return False
    if pid=='abc203_b': return POS.fullmatch(output) is not None and int(output)==_ans203(v)
    if pid=='abc204_b': return NONNEG.fullmatch(output) is not None and int(output)==_ans204(v)
    return output in ('Yes','No') and output==_ans205(v)
def _arr(a): return f'{len(a)}\n'+' '.join(map(str,a))+'\n'
def generate(pid:str)->list[dict[str,str]]:
    if pid not in TASKS: raise ValueError('unknown task')
    out=[]; seen=set()
    def add(cat,raw):
        validate(pid,raw)
        if raw not in seen: seen.add(raw); out.append({'category':cat,'input':raw})
    if pid=='abc203_b':
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        vals=[
          ('min','1 1\n'),('n1_k9','1 9\n'),('n9_k1','9 1\n'),('square2','2 2\n'),('square4','4 4\n'),
          ('n2_k9','2 9\n'),('n9_k2','9 2\n'),('n3_k9','3 9\n'),('n9_k3','9 3\n'),('n5_k7','5 7\n'),
          ('n7_k5','7 5\n'),('n8_k8','8 8\n'),('n4_k9','4 9\n'),('n9_k4','9 4\n'),('n6_k6','6 6\n'),
        ]
        for c,raw in vals:add(c,raw)
        add('constraint_max','9 9\n')
    elif pid=='abc204_b':
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        cases=[
          ('n1_zero',[0]),('n1_ten',[10]),('n1_eleven',[11]),('n1_max',[1000]),('all_below',[0,1,9,10]),
          ('all_above',[11,12,100,1000]),('threshold_mix',[9,10,11]),('zeros_and_max',[0,1000,0,1000]),
          ('ascending',list(range(0,21))),('descending',list(range(20,-1,-1))),('all10',[10]*50),('all11',[11]*50),
          ('n100',[i%1001 for i in range(100)]),('n999',[10 if i%2==0 else 11 for i in range(999)]),('large_mixed',[1000,10,0,999,11,9]),
        ]
        for c,a in cases:add(c,_arr(a))
        add('constraint_max',_arr([1000]*1000))
    else:
        for i,row in enumerate(PUBLISHED_SAMPLES[pid],1): add(f'sample{i}',row['input'])
        cases=[
          ('n2_yes',[1,2]),('n2_yes_rev',[2,1]),('n2_no_dup',[1,1]),
          ('n3_dup_high',[1,3,3]),('n4_cycle',[2,3,4,1]),('n4_dup',[2,2,3,4]),('n5_reverse',[5,4,3,2,1]),
          ('n10_identity',list(range(1,11))),('n10_rotate',list(range(2,11))+[1]),('n10_dup',list(range(1,10))+[9]),
          ('n100_reverse',list(range(100,0,-1))),('n100_dup',list(range(1,100))+[99]),('n999_rotate',list(range(2,1000))+[1]),
        ]
        for c,a in cases:add(c,_arr(a))
        add('constraint_max',_arr(list(range(1000,0,-1))))
    if len(out)!=18 or len(seen)!=18 or out[-1]['category']!='constraint_max': raise ValueError(f'{pid}: expected 18 distinct cases ending constraint_max, got {len(out)}')
    return out
