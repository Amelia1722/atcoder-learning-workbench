"""Evidence-bound backfill for ABC003 A-B / ABC004 A; public statements checked."""
HINTS_BACKFILL_V74 = {
    'abc003_1': (
        '1からNまでが同じ確率で出るので、まずその平均の目を求めてください。',
        '1からNまでの平均は(N+1)/2です。1目あたり1万円なので、円へ直して計算します。',
        '''疑似コード:
average_face = (N + 1) / 2
print(average_face * 10000)''',
    ),
    'abc003_2': (
        '@が置き換えられる文字はa,t,c,o,d,e,rだけです。各位置を独立に比較してください。',
        '同じ文字ならそのままOKです。異なる場合は、一方が@で他方がatcoderのどれかならOK、それ以外は負けです。',
        '''疑似コード:
allowed = set("atcoder")
for a,b in zip(S,T):
  if a == b: continue
  if a == "@" and b in allowed: continue
  if b == "@" and a in allowed: continue
  print("You will lose"); stop
print("You can win")''',
    ),
    'abc004_1': (
        '返す金額は借りた金額Nのちょうど2倍です。',
        '追加の条件分岐は不要で、Nに2を掛けた値を出力します。',
        '''疑似コード:
N = read_integer()
print(2 * N)''',
    ),
}
